/**
 * lib/render-cards.mjs — shared renderer: a 3x3 grid of "novel cover" shaped
 * cards (portrait, rounded corners, like a book/VN box art), used by the
 * catalog, deck and collection commands.
 *
 * Needs:  npm install @napi-rs/canvas
 *
 * renderCardGrid(cards, opts) -> Promise<Buffer>  (PNG)
 *
 * Each card: { title, subtitle, stars, rarity, imagePath, imageBuffer, locked, empty }
 *   - imagePath: absolute path to the character's art (e.g. images/god-series/namidrek.jpg)
 *   - imageBuffer: raw bytes, used instead of imagePath if given (e.g. from a .bird file)
 *   - locked: true -> art is dimmed and a 🔒 is drawn (not owned yet)
 *   - empty: true -> draws a dashed "Empty slot" box instead of a card (for deck gaps)
 */
import { createCanvas, loadImage } from '@napi-rs/canvas'

const COLS = 3, ROWS = 3, PER_PAGE = COLS * ROWS
const CARD_W = 220, CARD_H = 330           // 2:3 "book cover" ratio
const GAP = 24, PAD = 36, HEADER_H = 90, FOOTER_H = 50

const RARITY_COLORS = {
  common: '#8a8a86', rare: '#3b82f6', epic: '#a855f7',
  legendary: '#f59e0b', mythic: '#ef4444', divinity: '#111111',
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath()
  ctx.moveTo(x + r, y)
  ctx.arcTo(x + w, y, x + w, y + h, r)
  ctx.arcTo(x + w, y + h, x, y + h, r)
  ctx.arcTo(x, y + h, x, y, r)
  ctx.arcTo(x, y, x + w, y, r)
  ctx.closePath()
}

function wrapLine(ctx, text, maxWidth) {
  if (ctx.measureText(text).width <= maxWidth) return text
  while (text.length > 1 && ctx.measureText(text + '…').width > maxWidth) text = text.slice(0, -1)
  return text + '…'
}

async function drawCard(ctx, card, x, y) {
  if (card.empty) {
    ctx.save()
    ctx.strokeStyle = '#555'; ctx.setLineDash([8, 6]); ctx.lineWidth = 2
    roundRect(ctx, x, y, CARD_W, CARD_H, 14); ctx.stroke()
    ctx.setLineDash([])
    ctx.fillStyle = '#777'; ctx.font = '16px sans-serif'; ctx.textAlign = 'center'
    ctx.fillText('Empty slot', x + CARD_W / 2, y + CARD_H / 2)
    ctx.restore()
    return
  }

  roundRect(ctx, x, y, CARD_W, CARD_H, 14)
  ctx.save(); ctx.clip()
  ctx.fillStyle = '#20201e'; ctx.fillRect(x, y, CARD_W, CARD_H)

  const src = card.imageBuffer ?? card.imagePath
  if (src) {
    try {
      const img = await loadImage(src)
      const scale = Math.max(CARD_W / img.width, (CARD_H - 70) / img.height)
      const w = img.width * scale, h = img.height * scale
      ctx.drawImage(img, x + (CARD_W - w) / 2, y + (w ? (CARD_H - 70 - h) / 2 : 0), w, h)
    } catch { /* missing art falls back to the placeholder background */ }
  }

  // bottom label band
  const bandY = y + CARD_H - 70
  const grad = ctx.createLinearGradient(0, bandY, 0, y + CARD_H)
  grad.addColorStop(0, 'rgba(0,0,0,0)'); grad.addColorStop(0.35, 'rgba(0,0,0,.85)')
  ctx.fillStyle = grad; ctx.fillRect(x, bandY - 40, CARD_W, 110)

  ctx.textAlign = 'left'
  ctx.fillStyle = '#fff'; ctx.font = 'bold 16px sans-serif'
  ctx.fillText(wrapLine(ctx, card.title ?? '???', CARD_W - 20), x + 12, y + CARD_H - 44)

  if (card.subtitle) {
    ctx.fillStyle = '#ccc'; ctx.font = '12px sans-serif'
    ctx.fillText(wrapLine(ctx, card.subtitle, CARD_W - 20), x + 12, y + CARD_H - 26)
  }

  if (card.stars) {
    ctx.fillStyle = '#ffd34d'; ctx.font = '13px sans-serif'
    ctx.fillText('★'.repeat(card.stars), x + 12, y + CARD_H - 8)
  }

  if (card.rarity) {
    const c = RARITY_COLORS[card.rarity] ?? '#555'
    ctx.fillStyle = c; roundRect(ctx, x + CARD_W - 86, y + 10, 76, 22, 11); ctx.fill()
    ctx.fillStyle = '#fff'; ctx.font = 'bold 11px sans-serif'; ctx.textAlign = 'center'
    ctx.fillText(card.rarity.toUpperCase(), x + CARD_W - 48, y + 25)
    ctx.textAlign = 'left'
  }
  ctx.restore() // clip

  ctx.strokeStyle = 'rgba(255,255,255,.15)'; ctx.lineWidth = 1
  roundRect(ctx, x + 0.5, y + 0.5, CARD_W - 1, CARD_H - 1, 14); ctx.stroke()

  if (card.locked) {
    ctx.fillStyle = 'rgba(0,0,0,.55)'; roundRect(ctx, x, y, CARD_W, CARD_H, 14); ctx.fill()
    ctx.fillStyle = '#fff'; ctx.font = '34px sans-serif'; ctx.textAlign = 'center'
    ctx.fillText('🔒', x + CARD_W / 2, y + CARD_H / 2 + 12)
    ctx.textAlign = 'left'
  }
}

/**
 * @param {object[]} cards   up to 9 cards for this page
 * @param {object} opts
 * @param {string} opts.title       header text, e.g. "Catalog", "Your Deck"
 * @param {number} [opts.page]      1-based page number, for the footer
 * @param {number} [opts.totalPages]
 * @param {string} [opts.footerNote] extra line under the pagination, e.g. "12 / 48 owned"
 * @returns {Promise<Buffer>} PNG bytes
 */
export async function renderCardGrid(cards, opts = {}) {
  const gridW = COLS * CARD_W + (COLS - 1) * GAP
  const gridH = ROWS * CARD_H + (ROWS - 1) * GAP
  const W = gridW + PAD * 2, H = gridH + PAD * 2 + HEADER_H + FOOTER_H

  const canvas = createCanvas(W, H)
  const ctx = canvas.getContext('2d')

  const bg = ctx.createLinearGradient(0, 0, 0, H)
  bg.addColorStop(0, '#15151a'); bg.addColorStop(1, '#0c0c0f')
  ctx.fillStyle = bg; ctx.fillRect(0, 0, W, H)

  ctx.fillStyle = '#fff'; ctx.font = 'bold 30px sans-serif'; ctx.textAlign = 'left'
  ctx.fillText(opts.title ?? 'Cards', PAD, 54)

  const list = cards.slice(0, PER_PAGE)
  while (list.length < PER_PAGE) list.push({ empty: true })

  for (let i = 0; i < PER_PAGE; i++) {
    const col = i % COLS, row = Math.floor(i / COLS)
    const x = PAD + col * (CARD_W + GAP)
    const y = PAD + HEADER_H + row * (CARD_H + GAP)
    await drawCard(ctx, list[i], x, y)
  }

  ctx.textAlign = 'center'; ctx.fillStyle = '#aaa'; ctx.font = '15px sans-serif'
  let footerY = H - FOOTER_H + 22
  if (opts.page && opts.totalPages) {
    ctx.fillText(`Page ${opts.page} / ${opts.totalPages}`, W / 2, footerY)
    footerY += 20
  }
  if (opts.footerNote) ctx.fillText(opts.footerNote, W / 2, footerY)

  return canvas.toBuffer('image/png')
}

export const CARDS_PER_PAGE = PER_PAGE
