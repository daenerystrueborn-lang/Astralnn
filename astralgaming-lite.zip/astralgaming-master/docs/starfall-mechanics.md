# Starfall Champion Package — Implementation Notes

Owner-supplied design: `docs/starfall-seong-ha-kit.md`. This file records how
that kit is wired, what works today, and what is deliberately not finished.
Everything here is a no-op for players with no Starfall prize.

## Components and where they live

| Prize | Design | Implementation |
|---|---|---|
| Seong-ha — Hymn of the Shield | Lethal ally damage becomes Debt on Seong-ha; fires back after 2 turns | `seongHaHymnSave()` in `lib/starfall-champion.js`, called from `applyIncomingDamage()` (solo/boss/duel) and from `handlePartyMemberDown()` (party). The save sets hp=1 and arms `battleState.seonghaHymn` with `dueTurn = turn + 2` (Astral Witch: +5). The Debt is collected at the top of the owner's turn by `starfallTurnTick()` |
| Seong-ha — Cage of the World | Locks one enemy for 6 turns (10 in witch form), can't be dispelled, allies hit full damage | `.cage` (plugins/cage.js) → `castCage()`. The `cage` effect type is new in `lib/effects.js` and counts as hard control in `processStatusTurn()` — the prisoner skips its turn. Sanctum/void refuse it (it is in `NEGATIVE_EFFECT_TYPES`); `cure`'s strip list deliberately excludes it |
| Astral Witch | 10-turn cage, 5-turn hymn window, Written Stars (2× 150% INT unblockable + constellation) | Same code paths; `cageTurns()`/`hymnWindow()` read the equipped skin. Stars floor the prisoner at 1 HP — a tick can never fire the kill |
| Starborn Seraph — Six Laws | Silence / Mercy / Distance / Truth / Weight / Last Word | Mercy: struck hits capped at 25% maxHp (in `applyIncomingDamage()`). Distance: 25% of struck hits simply fail to close (same funnel). Truth: `blind` refused on her (checked in `addStatusEffect()`, read off `entity.characterSkins.equipped` — no import needed). Weight: enemy AGI weakened to 40% every turn (refreshed, never stacked). Last Word: enemy ≤40% HP is stunned once per battle. Silence is **not implemented** (would need a target-choice surface for duels; there is no enemy-skill-tax mechanic in the solo engine) |
| Heaven's Orrery | Both forms worn → cage also carries the Six Laws | Owning both forms (skin inventory) satisfies `heavensOrrery()`; the cage then calls Written Stars. The "any use in a battle" clause is approximated by ownership — noted, not silently dropped |
| Karren (party) | Support healing for party modes | On her own turn, heals the most-wounded living member for 12% of her max HP (`karrenPartyPulse()` in plugins/party.js). Her Pages abilities (Redact/Footnote/Errata) are **not implemented** — they need a command surface and an event ledger that doesn't exist yet |
| Burning Cathedral | Ultimate domain, 4 turns: Ledger, Sanctuary, Bell, Sealed Doors | `.skill Burning Cathedral` (solo, boss, duel) → `armCathedral()`. Sanctuary: struck hits can never carry the holder below 1 HP (clamped in `applyIncomingDamage()` and in `applyPartyHpDamage()`). Ledger: every struck hit that reaches the HP bar is recorded on `battleState.cathedral.dealtByEnemy`; each turn the foe takes that accumulated total (floored at 1 HP — it cannot kill through a tick). Bell: each turn the strongest enemy buff is stripped and paid out as a 2-turn shield on the caster. Sealed Doors: enforced in `.flee` and `.dparty flee` only — there is no central "cannot teleport" gate to hook yet |
| Edo Tensei no Jutsu | Revives one random fallen ally, once per match | `.skill Edo Tensei no Jutsu` arms the rite (solo/duel; refusal is free). The holder survives a lethal blow at 30% max HP (once per battle) — consumed in the same funnels as Hymn. In party fights, a living holder anywhere in the party may spend their rite to pull the falling member back at 30% (`handlePartyMemberDown()` picks a random eligible sponsor). Random-ally choice among *several simultaneously fallen* members is approximated (party members are resolved one at a time) |
| Ha-neul (summon) | Tether; absorbs 35% of struck blows as Weight; chains break at each 15% of max HP absorbed; Rend each turn; Release on command | `haNeulAbsorb()` in the struck-hit funnels (solo/boss/duel/party). Rend fires per turn (`starfallTurnTick()`). `.haneul` shows the tether; `.haneul release` spends everything for 200% true damage — the only Starfall effect allowed to kill, and it settles through `handleVictory()`. 6 turns or 6 chains; chain 2/4/6 boons: a 15% vow-shield, a cleanse of hostile statuses, a head of light (+25% damage, 40% reduction for 2 turns) |
| Ghostblade | Soul-strike pierces invulnerability/immunity; Requiem Roster (12 names) | Soul-strike: any boss answer that reduces an ENEMY_TAKE_DAMAGE hit to 0 is pierced and the hit lands as thrown (`applyBossSpecial()` in lib/boss-engine.js) — this is the game's actual "nothing lands" surface. Requiem Roster: every kill is credited centrally in `handleVictory()` and written to `player.ghostbladeRoster` (cap 12). Reciting a name as a spirit ally is **not implemented** — no summon surface exists for it yet |

## Deliberately not finished (says the owner or needs design)

- **Law of Silence** (strike one enemy skill from the record): no solo enemy-skill
  tax surface exists; needs an owner decision on scope for duels.
- **Karren's Redact/Footnote/Errata** and the Pages resource.
- **Ha-neul cross-guard** (soaking damage aimed at an ally other than her
  owner): v1 absorbs only damage aimed at her owner, in both solo and party.
- **Ghostblade name-recitation**: roster collects names; the summon move does
  not exist.
- **Heaven's Orrery battle-use clause**: approximated by owning both forms.
- **Ledger balance**: the wipe/collected damage cannot benefit from formations
  or potions — it is raw HP-bar loss. It also cannot kill through a tick (floors
  at 1 HP); only real attacks/commands end the fight.
- **Pvp (duel) notes**: the two mythic skills arm rather than strike; the
  Ledger/Rend/Bell/Debt run against the opponent via a copied snapshot and are
  applied after the actor's own write. Cage has no duel verb yet. Karren pulse
  and Ha-neul Release are disabled in duels. Party fights have no skill slots,
  so Burning Cathedral/Edo Tensei can't be cast there; party gets the saves,
  the absorb, the clamps and the pulse instead.

## Bugs fixed on the way in

- Duel clock **double-counted** the Starfall tick: `starfallTurnTick()`'s
  `dealTrueDamage()` mutated the foe's HP even in `applyToFoe: false` mode,
  and `plugins/pvp.js` passed the live `getPlayer()` record (same object) as
  the "snapshot", so `writeOpponent()` subtracted the ledger twice. The tick
  is now read-only on the foe in `applyToFoe: false` mode and the duel passes
  a `structuredClone` — the opponent pays the ledger exactly once.
  `scripts/check-starfall-battle.mjs` §I locks this in.
- Starfall prizes routed wrongly on grant (skins/PFP/banner never reached
  `characterSkins`/`profileCosmetics`) — fixed with a real grant test
  (`grant-test.mjs`).
- Starfall art fell under one dead remote host class; Starfall prize images
  are all `starfall/…` relative paths resolved against `images/starfall/`.
- `graceCut` was feeding the reported damage from `sustain.damage` after the
  Sanctuary/absorb reductions had been computed separately, so the log line
  could report a 5000-damage hit on a 99-damage bar. It now reads the
  post-reduction number.
- `resolvePlayerHpZero()` gains the Sanctuary → Hymn → Edo saves after the
  Dreamlands no-saves rule, so DoT deaths (which never pass through
  `applyIncomingDamage()`) are covered too.

## Ha-neul narration

Every absorb now prints one short line (`🪽 Ha-neul drinks in *N*.`); chain
breaks keep their own louder lines. Before this, a 210-damage soak landed
with zero feedback and the summon felt asleep.

## Spin copy vs. the real odds (the "re-zero" report)

Owner correction: the odds are **not for public copy**. An earlier revision of
this branch printed the per-wallet dead zone (350 gems / 400 solars, rate rises
at 500/700) into `.starfall info` and the banner card — reverted. Player-facing
text now says only that premiums are one-time and that winning never resets
counters; the dead zone and rate table stay owner-private in
`data/starfall.json`. The mechanics, for the record: the spin has a per-wallet
dead zone (premium chance 0 below the wallet threshold, rising at 500/700
wallet spins); `spins`, `gemsSpins` and `solarsSpins` never reset on a win, and
neither does `premiumsWon`. A player who splits wallets can show a high
lifetime count with 0 premium chance on both — that is the per-wallet design,
not a re-zero, and public copy does not disclose it.

## Verification

- `node scripts/check-starfall-battle.mjs` — 65 in-battle integration checks:
  a scripted dungeon fight through `processStatusTurn()` +
  `applyIncomingDamage()` (Sanctuary holds → nave falls → Hymn → death),
  cage cast six moves into a fight (base 6 turns / witch 10 / Orrery Written
  Stars), seal-the-door gates, Hymn→Debt collection, Edo save, DoT-death
  rescue in `resolvePlayerHpZero()`, all six Ha-neul chains end-to-end, the
  duel tick (snapshot untouched, foe charged once), boss Infinity piercing
  with/without the spear, Karren's party pulse against a fake db.
- `node scripts/check-starfall-mechanics.mjs` — 26 unit checks over the kit
  (arming, cage, debt, ledger, bell, chains, release, roster).
- `node scripts/check-starfall-grants.mjs` — every premium prize lands in the
  right destination exactly once.
- `npm run check:starfall` — spin odds/wipe/economy invariants.

## Wipe

`lib/starfall-wipe.js` removes all of the above from every player: the two
characters, both skills, both skins, Ha-neul, Ghostblade, the PFP/banner,
`ghostbladeRoster`, and the three Starfall boxes. Skins and cosmetics are
stripped from `characterSkins`/`profileCosmetics`. An equipped Ghostblade is
also taken off properly — its `statBonuses` (+380 STR, +60 AGI) are folded
back out of `player.stats` and the slot and its durability entry are cleared;
deleting the inventory id alone would have left the strength on the bearer.
`ghostblade` itself stays in `data/items.json` — wiped players lose the copy,
not the definition.
