# Starfall — Seong-ha kit and premium prize powers

Owner-supplied specification. Keep this as the source of truth for the new Starfall character spin.

## SEONG-HA

Title: The Last Vanguard of the Fallen Choir

Role: Frontline spear duelist / anti-death support

Personality: Dry, blunt, and protective. She is the last of a twelve-voice Choir and still sets out twelve cups at camp. She goes very quiet when an ally is hurt.

---

## BASE FORM

### PASSIVE: Hymn of the Shield

When an ally would take lethal damage, they do not die. The damage is moved onto Seong-ha as Debt. After 2 turns, all Debt is fired back at whoever dealt it as unblockable true damage.

### SKILL: Cage of the World

Seong-ha traps one enemy in a cage of the world itself for 6 turns.

- The caged enemy cannot act, move, or be swapped out.
- The cage cannot be dispelled or cleansed.
- Your team can still deal full damage to the caged enemy the whole time.
- If the caged enemy is a boss, they are caged but gain no immunity bonus.

---

## ASTRAL WITCH

(Collectible character and in-battle transformation)

### UPGRADE: Cage of the World, Extended

The cage now lasts 10 turns.

### UPGRADE: Hymn of the Shield, Extended

Allies under Hymn of the Shield cannot die for 5 turns (up from 2). The Debt is released at the end of that window.

### SKILL: Written Stars

Seong-ha opens the sky and drops millions of stars on the battlefield. The screen fills with falling starlight, and every star is a hit.

- Deals massive AoE damage to all enemies.
- Leaves a constellation on each enemy, which marks them for bonus damage from every ally.
- Stars that land on caged enemies hit twice.

### PASSIVE: Tidewalk

She steps into any water or reflection and comes out of any other one.

---

## STARBORN SERAPH

(Collectible character and in-battle transformation)

### CORE: Six Laws (all active at once, nothing is burned)

1. Law of Silence: One enemy skill is struck from the record and can never be cast again this battle.
2. Law of Mercy: Allies cannot be reduced below their current HP band.
3. Law of Distance: Enemy melee attacks fail unless they touch the ground she names.
4. Law of Truth: Illusions, stealth, and phase effects stop working.
5. Law of Weight: The strongest enemy becomes as slow as they are heavy.
6. Law of the Last Word: Any enemy under 40% HP obeys one command from her.

Forms: Only one is active at a time.

### FUSION: Heaven's Orrery

If both forms were used in a battle, she can combine them. Cage of the World, Hymn of the Shield, and Written Stars all carry the Six Laws at the same time.

---

## SUPPORT: KARREN (The Archivist)

Resource: Pages

- Redact: Removes all damage from the last 2 turns. It never happened.
- Footnote: Copies a buff from one ally onto another.
- Errata: Spends 3 Pages to change one event in the record, such as who was hit or who took the kill.
- Synergy: Karren holds Ha-neul's real name, so Seong-ha can resummon Ha-neul for free while Karren is alive.

Karren is supportive healing for party modes.

---

## ULTIMATE: BURNING CATHEDRAL (Domain)

A black-gold cathedral rises around the whole battlefield for 4 turns.

- Ledger of Flame: Enemies burn for the total damage they have dealt to allies this battle.
- Sanctuary: Allies cannot drop below 1 HP and are cleansed each turn.
- The Bell: Each turn it tolls and strips the strongest enemy buff, giving it to your team.
- Sealed Doors: Nothing can flee, teleport, or summon in or out.

---

## SKILL 2: EDO TENSEI NO JUTSU

Effect: Revives one random fallen ally to fight again, once per match.

Art has not been supplied yet; the spin shows this prize as text only.

---

## SUMMON: HA-NEUL (The Chained Angel)

Type: Tether summon. It is not a pet or beast. It is a headless stone-and-feather angel bound by 6 chains, each carrying a Vow.

- Unwitnessed: Single-target attacks cannot pick it as a target.
- Guard: It absorbs all damage dealt to allies and stores it as Weight.
- Rend: It attacks with the stored Weight.
- Release: It lets go of all Weight at once.
- Each broken chain gives a boon (a shield, a silence, a revive, and so on).
- When the 6th chain breaks, it grows a head of light for 2 turns and every ally takes on her highest stat.
- Duration: 6 turns, or until all chains break.

---

## WEAPON: GHOSTBLADE (Mythic Spear)

- Soul-strike: Its attacks ignore invulnerability and damage immunity.
- Requiem Roster: Every enemy killed has its name written into the blade (12 names, one per Choir seat). She can recite a name to summon that enemy as a spirit ally for 2 turns, using one of its own skills.
- Full roster: All 12 names sing together, and the blade casts any stolen skill once for free.
