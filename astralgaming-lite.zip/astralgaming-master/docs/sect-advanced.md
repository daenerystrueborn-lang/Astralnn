# The later Sect Empire systems

Four systems sit on top of the original Sect Empire, plus one long-overdue
extension to the trades. Each one is data-driven and has exactly one write
path; none of them creates a second world or a second fight.

## 1. Bloodlines — inherited, not bought

Data: `data/sect-bloodlines.json`. Rules: `lib/sect-bloodlines.js`.
Command: `.sect bloodline` (also `.bloodline`).

A bloodline is carried as MEMORY on the player's Sect record. There are three
ways to get it:

* a sensei who is already carrying a line passes a share when a student
  accepts the teaching bond (`lib/sect-commands.js` calls `echoFromMaster()`);
* a tamed beast of the same element passes its share when caught or fed
  (`lib/sect-beasts.js` calls `echoFromBeast()`);
* the daily rite at the player's own sect spends 25 contribution for 12 memory
  of one line, once per line per day.

Awakening a line spends `memoryNeeded` memory plus the materials in the data
record. From then on it changes the cave bar, the four base stats in
`makePlayerSide()`, and one fight trigger that is fired by the ordinary
artifact-effect engine. `.sect bloodline rest` puts it down and keeps half the
memory. Nothing is read from another player's document during a fight.

## 2. Beast taming

Data: `data/sect-beasts.json`. Rules: `lib/sect-beasts.js`.
Commands: `.sect beast tame|set|feed` (also `.beast`).

Each beast names its own bait, its realm tier and its element. A taming attempt
spends one bait and rolls a chance from the player's realm, the beast's tier
and fortune; a failed attempt spends the bait and says the chance it missed.
A caught beast is a record in `profile.beasts.book`; one can be active.

Feeding an active beast spends two herbs of its own tier and raises the BOND,
capped at `tier × bondCapPerTier`. The bond scales both its stat share and its
cave share; the beast also brings one trigger into the fight and leaves blood
memory of its element. There is no separate pet battlefield.

## 3. Sect bonds — friends and enemies inside the mountain

Data: `data/sect-bonds.json`. Rules: `lib/sect-bonds.js`.
Commands: `.sect bonds friend|rival|accept|end` (also `.bonds`).

Both sides must be in the same sect and past stage 3. A friendship is a
request and an acceptance; a rivalry is declared outright. Every resulting
bond is written to BOTH player records in one growth-locked update, with the
other player whispered. Five of each are allowed.

Friends add 5% cave progress and 4% earned contribution each, plus a small
defensive stat share. Rivals add 6% attack and 4% speed each but cost 3% cave
focus; both contribute a small combat modifier. Contribution is applied in
`earnContribution()` only, so an admin grant is never multiplied.

## 4. Time cycles

Data: `data/sect-time.json`. Rules: `lib/sect-time.js`.
Command: `.sect time` (also `.time`); a one-line report sits on `.sect`.

Four windows cover all 24 hours in the world's UTC+1 clock. Orthodox,
alchemy and body sects are *yang*: morning 1.18, day 1.08, dusk 1.00,
night 0.88. Demonic sects are *yin*: the mirror of that. The Academy is
*balanced* at 1.04 throughout. The multiplier is applied once, inside
`addSectProgress()`, after pill toxin and before the bar, so cave work,
hunting, tasks and progress pills all obey the same hour.

## 5. Work past Nascent Soul

The old content stopped at grade 4 (Nascent Soul). Now:

* profession levels run to 12, and the content grades to 9;
* `data/sect-materials.json` has tiers 5–9: herb, ore, paper, core and a rare;
* alchemy generates recipes for every grade a pill supports, including the
  five breakthrough pills past Nascent Soul and three new high-grade formulas;
* forging, formations and talismans each have level 5–9 recipes;
* master furnaces (tiers 5–9) are earned by stage and only usable in a hall
  that teaches the trade; see `craft.masterFurnace.stages`;
* the artifact catalogue adds dharma, heaven and divine pieces. Divine pieces
  have real triggers: the Heaven Seal Blade revives its bearer once per fight
  through a new engine action, and the Worldtree Crown returns HP and Qi every
  third turn.

## Validation

`npm run check:sect-advanced` runs the data validators and pushes one example
through each system, including the new divine death trigger. Also run
`node scripts/check-imports.mjs` and `npm run check:god-series --silent`.
