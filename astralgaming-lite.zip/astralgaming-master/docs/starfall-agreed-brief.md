# Starfall Character Spin: Agreed Brief

Everything under "Agreed" was confirmed by the owner. Anything under "Open" still needs an answer. Do not invent values for open items.

---

## 1. Concept

- **Starfall** is the name of the **spin and banner only**. It is not a character's name.
- The current Starfall reward pool is **ended and replaced** by this new spin.
- The featured character is **Seong-ha** (성하, 星河, "star river", the Korean word for the Milky Way). She is Korean.
- Use the NEW Starfall banner image saved at `images/starfall/starfall-banner.jpg`. Do NOT reuse the old `starfall` / `starfall-banner` art keys in `lib/image.js`.
- Not exclusive: anyone can win anything. No one-of-one lock, and no `spin-locks` calls.
- The pool is bottomless: players can keep spinning.

## 2. Price (agreed)

- **3 Gems per spin**, or **80,000 Solars per spin**. The player chooses the wallet.
- The current engine supports only one currency per spin, so this needs real changes to the pricing and charge path.
- The chosen wallet must be validated **before** charging.
- Charge, roll, grant, spin-count update and Astral Pass award must all stay inside the **same `updatePlayer()` mutator**.
- The result caption must say which wallet paid.
- Check the mini-app entry in `lib/miniapp/app.html`, since it is a second entry point.

## 3. Premium prizes (agreed): 10 items

| # | Prize | Type | Art file |
|---|---|---|---|
| 1 | Seong-ha | Character | `seong_ha_base.jpg` |
| 2 | Seong-ha: Astral Witch | Form 1 | `seong_ha_astral_witch.jpg` |
| 3 | Seong-ha: Starborn Seraph | Form 2 | `seong_ha_starborn_seraph.jpg` |
| 4 | Karren | Support character | `support_karren.jpg` |
| 5 | Burning Cathedral | Skill 1 | `skill_burning_cathedral.jpg` |
| 6 | Edo Tensei no Jutsu | Skill 2 | art still missing |
| 7 | Ha-neul (하늘) | Summon | `summon_ha_neul.jpg` |
| 8 | Ghostblade | Weapon | `weapon_ghostblade.jpg` |
| 9 | PFP | Cosmetic | `pfp.jpg` |
| 10 | Banner | Cosmetic | `banner.jpg` |

Notes:
- **Ha-neul** (하늘, meaning "sky" or "heaven") is the Korean girl's name for the chained angel summon. It replaces Bicheon, which the owner rejected because Omniscient Reader's Viewpoint already uses it. Image: `summon_ha_neul.jpg`.
- **Astral Witch and Starborn Seraph are Seong-ha skins, not separate character entries.**
- Names marked as the assistant's own ideas (**Astral Witch**, **Starborn Seraph**) can be changed. "Burning Cathedral" assumes the owner's "bursh" meant "church". "Karren" comes from the owner's filename.
- Full powers are in `docs/starfall-seong-ha-kit.md`.
- Karren is party-mode support healing. PFP and banner are equippable cosmetics only.
- Seong-ha's title, story, ability and personality are still to be designed by the assistant unless the owner supplies them.

## 4. Premium rules (agreed)

- **Every premium prize is one-time only.** Once a player owns one, it can never drop for them again.
- **No duplicates on premium**, so no duplicate compensation is needed there.
- **Forms can drop before the player owns Seong-ha.**
- **When a player owns all 10 premium prizes, Starfall ends for them.**
- **Rarity ranking:** Seong-ha and her two skills are the rarest, then the two forms, then the support character, summon and weapon, and the PFP and banner are the most common premium prizes.
- The earlier suggested weights (Seong-ha 3, skills 4 each, forms 5 each, support 12, summon 15, weapon 17, banner 15, PFP 20) are **proposals, not agreed**.

## 5. Spin structure

- Each spin picks one band, then fills **5 item slots** from that band. A spin never mixes bands.
- A premium spin gives **1 premium prize + 4 box slots**.
- A box spin or Solars spin fills all 5 slots from its own band.
- **Dead zone per wallet.** Spinning with Gems pays no premium on spins 1-350. Spinning with Solars pays no premium on spins 1-400. From the next spin on, premium is live.
- **No pity.** The headline rate is a chance, not a countdown. 1 in 300 does not guarantee a prize by spin 300, the same as the frontier pirate token.
- **Seong-ha character rate:** flat **1 in 300** once the wallet dead zone is past.
- After **500 wallet spins**, her rate becomes **1 in 200**.
- After **700 wallet spins**, her rate becomes **1 in 100**.
- **Other premium prizes are 1 in 150 each**, improving to **1 in 100** after 500 wallet spins and **1 in 60** after 700.
- Rates are tracked per wallet (`gemsSpins` / `solarsSpins`), so a player cannot bank Gems progress and cash it out with Solars.
- The rate is per spin; individual prizes have their own weights inside the premium band. **Seong-ha herself is the hardest single prize.**
- Max 50 spins per command (existing behaviour, unchanged unless the owner says otherwise).

## 6. Filler boxes (agreed in principle)

Five box types:

- **Iron:** low Solars and low-tier equipment.
- **Gold:** mid Solars and mid-tier equipment.
- **Silver:** best armor and gear.
- **Diamond:** medium gold and slightly good items. The hardest box to get.
- **Potion:** mid-tier potions. Art: `box_potion.jpg`.

The owner said the assistant designing the boxes will decide the exact contents and rarities. The earlier tension is still open: Diamond is the hardest to get, but Silver holds the best gear. Resolve it when designing.

## 7. Solars prizes and duplicates

- Solars wins are mini packs in the **10,000 to 30,000** range. Each Solars-band slot rolls one pack; weights are 70% / 25% / 5%, so a five-slot spin averages 67,500 Solars against an 80,000 cost.
- **The old 5,000 Solars duplicate compensation does NOT apply** anywhere in the new spin.
- Keep the 80,000 Solars price from being a profit machine. A 5-slot Solars spin should return clearly less than 80k on average.

## 8. Player data (agreed)

- **Old Starfall progress is kept** (lifetime spins, headline wins, gems spent). Do not wipe `player.starfall`.
- Check that old state still works with the new pool. For example, old headline wins refer to prizes that no longer exist.

## 9. Open items

1. ~~Odds as players collect.~~ Implemented as remove-and-renormalize; Starfall ends when all 10 are owned.
2. ~~Final weights for premium prizes and exact box contents.~~ Designed in `data/starfall.json`.
3. **Stat numbers / balance values** for Seong-ha, Karren, Ha-neul and Ghostblade. Effects are agreed in `starfall-seong-ha-kit.md`; full battle mechanics are a later pass.
4. **Skill 2 art:** Edo Tensei no Jutsu has no art yet; the spin uses text only for that prize.

## 10. Art files

`seong_ha_base.jpg`, `seong_ha_astral_witch.jpg`, `seong_ha_starborn_seraph.jpg`, `support_karren.jpg`, `skill_burning_cathedral.jpg`, `weapon_ghostblade.jpg`, `summon_ha_neul.jpg`, `pfp.jpg`, `banner.jpg`, `box_potion.jpg`
