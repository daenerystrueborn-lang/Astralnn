# Gods Among Us — build brief (volume 2)

Owner-supplied premise, condensed; locked build decisions; outline for sign-off
before any prose is written.

## Owner's premise (source of truth)

**GODS AMONG US** — "A version of different mirrors of myself. It's all white."
Story-driven apocalypse adventure, 20 chapters, 4 acts, ~90–135 beats/chapter.
The player is **Ren**: a scavenger with almost no memory who meets **Amiya**, a
girl with even less. They become each other's world. She is **Amiya, God of
Stars**, and she is the reason the world ended — every god was a mirror of her,
and so was he. In the end both give up everything for the other, and the one who
pays the highest price is the one who forgets.

Act I — WHITE (1–5): wake in a collapsed observatory with one rule — don't look
at the sky. Echoes (pale afterimages repeating last moments). Finds Amiya in a
crater, no name, no memory; takes "Amiya" because it's the only word she says in
her sleep. Rules of the ruins. First fall of dead lights when she laughs. The
monument: seven statues, six shattered, one faceless intact — THE SEVEN WHO
ENDED IT. She touches it, nosebleeds, her hand glows. Campfire; his reflection
lags a heartbeat in a dead screen.

Act II — MIRRORS (6–10): the City of Glass — every surface a mirror; each
version of them asks a question, the answers are remembered. One hidden mirror:
Amiya crowned in stars, a face she doesn't recognize; she shatters it in panic.
Meeting **Orren, the Last Tide**, a dying god — kneels, then tries to kill her;
Ren stops him. "She doesn't remember because she chose to forget," dies before
explaining. Orren's relic: the gods bleached the world to hide it from the
**Hollow**, an alien swarm hunting anything that shines; Amiya was the brightest
beacon. Ren tells Amiya most of it. That night he finds notes in his own
handwriting he doesn't remember. The sky opens — the Hollow found them; they run
for the old launch complex; the sky turns black with millions of ships.

Act III — THE SWARM (11–15): survival. Every time Amiya protects him, her glow
grows brighter. Cornered in a dead stadium, Ren steps in front of a Hollow lance
— "You laughed near the dead lights. I wanted to see it again." He dies; her
memory shatters back in. Her power erupts — erases a thousand ships; the white
sky becomes living constellations; every star makes her colder; Ren's body at
her feet bleaches white. The Seven Truths: the gods were never seven beings —
she split herself into seven mirrors (war, time, tides, silence, hunger, hope,
memory); six died holding the white wall; she chose to forget because a god who
remembered would have burned the world to save it. The Law of One Life: divinity
can be traded for exactly one mortal life. Six dead mirrors beg her to finish the
war; she looks at the fading boy: "I spent a whole age being a god. I was only a
person for a little while, and he was there for all of it."

Act IV — THE WHITE PAGE (16–20): Ren drifts in the white void; the six mirrors
reveal he is the **seventh** — the human piece she kept so she'd never forget
what being loved felt like; his Chapter 5 lag was hers; his sacrifice counted
because it was his. Warning: a mirror can't come back whole. The white is a blank
page; Ren turns to the player — he felt every choice. Amiya kneels over his body
and gives up everything: constellations go out one by one, her crown dissolves,
every ounce of godhood becomes chains of resurrection; the memories he had of
her rise into the sky as stars. He wakes, a mortal girl kneeling before him; he
doesn't know her; he smiles and asks "Why would you do that?" — "Because you did
it first."; she introduces herself for the first time: "Hi. My name is Amiya."
Chapter 20: her last divinity ignites every star at once, the Hollow burn in a
silent supernova, the white wall falls, color spreads inward. Two ordinary
people on a hill; she hums the melody from Chapter 1; he hums along without
knowing why. Final line: "It was never all white. It just needed someone to look."

## Locked build decisions (owner)

- **Unlock on completion: Amiya**, a brand-new original playable character.
- **Price: 50 gems, one time, per account.** Book 1 stays free; this is the only
  paid volume. Charged on purchase with an explicit confirm (`.story buy`).
- **Cadence: unchanged** — 1 chapter/day, 3 for Premium. DM-only.
- **NO rename of the player** — prose always says Ren; the typed-name beats are
  dropped (Ch17/Ch20 adapted; see outline).
- **Branching: mechanically real, my call.** A hidden per-player "remembered
  light" tally accumulates on the Chapter 6 mirror choices; Ch17–20 vary by it.
- **Mirrors (Ch6): 7 choice beats** (6 visions + the hidden crowned mirror).
- **Density/length: Book-1 class** — ~90–135 beats/chapter, 20 chapters.
- **Content lines: young adults, strictly platonic bond** (found-family /
  witness, never romance). Dark literary tone everywhere else.
- **Attached images (download.jpeg, Amiya.jpeg): reference only — NOT shipped.**
  download.jpeg is watermarked third-party fan art; Amiya.jpeg is of unclear
  provenance and reads adapted from existing property. Build generates ORIGINAL
  art (cover + Amiya portrait) instead. If the owner holds licenses, swap the
  files before release.

## My answers to the rest (owner delegated)

- **Reward kit:** Amiya, 4★ `starlit`, exclusive, INT, atk ≈ 1900 — exclusive
  4★ band (Ariel/Delta class). Ability draft for sign-off (see Character build).
- **Perks:** one item, `chains_of_resurrection`, offhand relic (+INT/+def),
  pure stat flavor, no utility sprawl. No new story-flag perks (nothing to
  consume them in v1).
- **Ending variation:** light tally 0–3 (default) vs 4+ (bright ending); only
  the last star's description and the Ch20 benediction differ. Whole ending
  never branches in structure.
- **Cadence of release:** Act-by-Act authoring, system checks in the same PRs.

## Character build — Amiya, the God of Stars (draft for sign-off)

- `id: "amiya"`, `name: "Amiya, the God of Stars"`, `emoji: "🌟"`,
  `rarity: "starlit"`, `stars: 4`, `exclusive: true`, `gemPrice: null`,
  `combat.atkType: "int"`, `atk 1900, def 1100, agi 1100`.
- `ability.name: "The Star That Remembers"`, flavor: she does not fall where
  she has already fallen — once per battle, a lethal blow leaves her at 1 HP
  and her next attack lands +50% harder; the light "keeps the memory of its own
  brightness" motif.
  Implementation: one lethal-checkpoint hook in `applyIncomingDamage()` (same
  family as Hymn/Edo — sits after Edo, once per battle, no battleState keys
  beyond `amiyaUsed`). One passive, no new systems, no PvP special case beyond
  the standard funnel behavior. If the owner wants it weaker, it becomes raw
  flavor (passive removed, book stays the reward).
- Quotes/voice: warm, exact, unstoppable calm; "six were spent holding the
  sky. I am what's left of the light." (draft set to be written with the kit)

## Engine work (small, contained)

1. `data/story-gods-among-us.json` (volume id `gods-among-us`) generated from
   per-chapter fragments in `story/gods-among-us-json/` + the same
   `story/build-volume.mjs` validation (choice keys, ≤3 options, no duplicates).
2. `lib/game-data.js`: one-line `storyVolumes` registration.
3. Purchase gate in `plugins/story.js`: volume carries `unlock: { gems: 50 }`;
   first `.story enter gods-among-us` → price prompt; `.story buy gods-among-us`
   → atomic deduct + `storyProgress.volumes['gods-among-us'].purchased = true`
   inside `updatePlayer()`; unlisted/locked in the picker otherwise. Book 1
   unchanged.
4. Light tally: `lib/story-engine.js` choice resolution adds each picked
   option's optional `light` weight into `state.light` (default 0). New beat
   type `"iflight"` with `min` + `beats`/`elseBeats` for the Ch17/Ch20
   variations. Skipping is the failure mode, never a crash.
5. NO rename machinery (dropped per owner).
6. Amiya into `data/characters.json` (+ the lethal-checkpoint hook) — tests.
7. `lib/version.js`: unreleased changelog entry.
8. Original art: cover (`lib/assets/story/gods-among-us/cover.jpg`, mounted
   `/assets/story` on the API like Starfall's) + Amiya portrait; no watermark,
   no rabbit-ear Amiya.
9. New check script `scripts/check-gods-among-us.mjs`: volume loads, chapters
   ordered/requirements valid, price-gate deducts exactly once, light tally
   accumulates and the conditional beats gate correctly, Amiya kit hook fires
   in a synthetic fight (mirrors the Starfall harness approach).

## Chapter outline

Density ~100 beats/chapter; `choice` beats are inline branches (options carry
per-option beats); mirror beats (Ch6) carry `light` weights (0 honest-but-safe /
guarded, 1 honest truth, +2 for the hidden crowned mirror; total 0–8; tiers:
0–3 quiet ending, 4+ bright ending).

- **1 Static** (~95): wake in collapsed observatory; one rule on his arm — don't
  look up. Routine survives the Echoes; outline of the city; ending beat: a
  living voice humming a melody he somehow knows. [choice: how he plays it —
  bawl it out / get up / lie still] [plea: none] [battle: none]
- **2 The Girl in the Crater** (~100): follow the melody; crater; Amiya, warm in
  a cold world; the Hollow Scout sniffs around her and leaves empty-handed
  (plants the "she is the beacon" mystery); Ren improvises a scare with scrap +
  fire; she takes the name Amiya (the only word she says in her sleep).
  [battle: scrap-scare set piece (scripted, unwinnable-by-design if fled wrongly)]
- **3 Rules of the Ruins** (~100): survival lessons vs her lessons (she says the
  sky "feels like home"); she laughs, the dead lights flicker on; he notices,
  says nothing. [choice: trust her looking up / hold the rule]
- **4 The Fallen Gods** (~105): the monument of seven; six shattered, one
  faceless intact — THE SEVEN WHO ENDED IT; her nosebleeds, her hand glows; he
  lies: "a trick of the light." First protection. [battle: none; plea: none]
- **5 Camp Fire, Cold Stars** (~95): fire, the little food they have; "If you
  could be anyone, who?" — he can't answer; his reflection lags a heartbeat.
  Act curtain. [quiet chapter; 1 choice]
- **6 The City of Glass** (~135): every surface a mirror; the long corridor of
  versions; 7 mirror choice beats (soldier Ren / the general who finished the
  war, queen Amiya / the ruler who never fell, child Amiya / the one who was
  saved, hollow-eyed Ren / the one who gave up, "who are you?" / the identity
  mirror, the last mirror at the exit / the courtier, the crowned Amiya hidden
  behind the service passage / light +2 if you follow it). Answers recorded as
  light. [7 choices; no battle — the city is not hostile, just honest]
- **7 The First God** (~110): Orren, the Last Tide, dying on the high beach; he
  kneels, then tries to kill her; Ren stops him; "She doesn't remember because
  she chose to forget." Orren dies before explaining. [battle: scripted interrupt]
- **8 What the Gods Did** (~100): the relic; the bleaching to hide Earth from
  the Hollow; Amiya, the brightest of them. First full-truth beat of how the
  world ended; ends with them not looking at him differently — yet.
  [choice: how much to tell her — full / partial] [battle: none]
- **9 The Distance Between Us** (~110): the telling; hurt, then the odd calm —
  "Then why do I feel like I'm already forgiven?"; a night apart; alone, Ren
  finds his own handwriting he doesn't remember. [choice: who writes to self —
  he reads it aloud to nobody / burns it / keeps it]
- **10 The Sky Opens** (~110): the split of light; the Hollow found them; run
  for the old launch complex; ends with the sky black with ships.
  [battle: one Hollow wave — the swarm's true arrival; scripted]
- **11 Millions** (~135): survival chapter — ruins full of units; run / hide /
  improvise; every time she protects him, brighter; he is clearly not strong
  enough no matter what he does. [battle: 2 scripted Hollow encounters — max
  one real loss state (knocked down, not killed)]
- **12 The Ambush (First Sacrifice)** (~125): dead stadium; the lance about to
  pierce her; he steps in on purpose — "You laughed near the dead lights. I
  wanted to see it again." He dies; her memory shatters back in. [scripted
  sacrifice — no way out offered; this is the story doing what it does]
- **13 Amiya, God of Stars** (~120): power floods in grief — white sky → living
  constellations; a thousand ships erased in one sweep; each star colder;
  Ren's body at her feet bleaches white like the world. [battle: the set piece
  — no player agency by design; plea: none; this chapter cannot be failed]
- **14 The Seven Truths** (~110): full memory returns. The seven mirrors — war,
  time, tides, silence, hunger, hope, memory — she is the last one holding the
  wall; she chose to forget because a remembering god would burn the world to
  save it. No battle; the storm ends before this chapter starts. [choice: the
  mirror she names first — player names which mirror died loudest; flavor only]
- **15 The Law of One Life** (~115): the trade law — divinity for one mortal
  life; the six dead mirrors beg her to finish the war — billions against one;
  she looks at the fading boy: "I spent a whole age being a god. I was only a
  person for a little while, and he was there for all of it."
  [choice: the clincher — "finish it" / "save him" as the mirrors frame it,
  both end the same way; the telling differs]
- **16 The Seventh Mirror** (~115): white void; six mirrors stand at the edges;
  he is the seventh — the human piece she kept so she would never forget what
  being loved felt like; the Chapter 5 reflection lag was hers; his sacrifice
  counted because it was his choice. Warning: a mirror can't come back whole.
  [choice: what he asks the mirrors — "who was I?" / "will she be okay?" /
  "why was I afraid of the sky?" — the mirrors' answers vary; light-sensitive
  beat flavor]
- **17 The Fourth Wall** (~120): the white is a blank page; Ren turns to the
  player and says "You were with me the whole time. Every choice, I felt you
  make it." He asks the player to remember her, because he can't. (Rename
  beats removed; the "you" is the reader.) [light >= 4: his memory of the
  choices is brighter and the ask is gentler; light <= 3: he asks twice,
  apologetic; both deliver the same ask]
- **18 The Trade (Second Sacrifice)** (~115): she kneels over his body and gives
  up everything; constellations out one by one; her crown dissolves; godhood
  becomes chains of resurrection; his memories of her rise into the sky as
  stars. [no battle; no player agency; this chapter cannot be failed]
- **19 Why Would You Do That** (~105): he wakes wrapped in chains; an ordinary
  mortal girl kneels under him; he doesn't know her; he smiles, confused —
  "Why would you do that?" / "Because you did it first." / "Hi. My name is
  Amiya." Mirrors Chapter 2 with the roles swapped; he starts over from zero.
  [light >= 4: for one heartbeat, something moves behind his eyes that neither
  of them names; light <= 3: nothing moves, and that is the point]
- **20 All the Colors** (~100): the chains break; her last divinity lights every
  star; the Hollow burn in one silent supernova; the wall falls; color spreads
  inward — green, blue, the red of a real sunrise. Two ordinary people on a
  hill; she hums the melody; he hums along without knowing why; the player's
  remembered light decides how the sky remembers them (4+ = one star burns a
  little brighter than the rest — "the one that was loved"; <= 3 = the new sky
  is uniform and ordinary, which is its own mercy). Last line: "It was never
  all white. It just needed someone to look." → grants Amiya + Chains of
  Resurrection + completion flags.

## Required sign-off before prose

1. This outline (chapter by chapter) — approve/correct beats.
2. Amiya's kit draft (The Star That Remembers).
3. The single bright/quiet ending split (Ch17/19/20 variations only; no route
   structure).
4. Original-art commission green-light (cover + portrait, generated by me).
