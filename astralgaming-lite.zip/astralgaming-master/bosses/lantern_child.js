/**
 * The Lantern Child — tier champion of the Lantern Fields.
 *
 * Grade: DREAD | Floor: 125 of Lantern Fields (cumulative floor 125)
 * Slot: data/dreamlands-bosses.json → lantern_fields / 125
 *
 * An ELITE nightmare, not a boss: a lighter voice kit (an entrance, one mid
 * fight line, a defeat line, drops) and no special of its own. Beating it
 * unlocks Sleepwood — see lib/dreamlands-core.js's lock rule and
 * plugins/dungeon.js's champion conquest.
 *
 * Stats are pinned (statOverride) rather than drawn from BOSS_BALANCE because
 * the Dreamlands run their own curve: this is the cumulative floor 125 target
 * from DREAMLAND_DIFFICULTY, doubled into a champion.
 *
 * 2026-10-07 — 26,000/650/2,900 to 38,000/720/3,000. The audit measured the
 * realm's FIRST champion at 3.9 of the strongest account's own skill turns, i.e.
 * quicker than a Caged Dimension trash mob, and 7.4 for the realm's own
 * reference. The gate is now ~11 turns for the reference and ~9.5 for the whale,
 * with Defence and Attack left where they were: it is HP that decides how long a
 * champion lasts, and raising its ATK would only hurt the under-levelled
 * challengers, who already take 60% to 100% of their HP bar from one blow.
 */

export const lantern_child = {
  id: 'lantern_child',
  name: 'The Lantern Child',
  floor: 125,
  grade: 'SSS',
  emoji: '🏮',
  image: null,               // art slot: champion_lantern (data/dreamlands-art.json)
  dreamlandsArtSlot: 'champion_lantern',
  champion: true,

  statOverride: { hp: 38_000, def: 720, atk: 3_000 },
  hp: 38_000,
  maxHp: 38_000,
  atk: 3_000,
  def: 720,
  exp: 30_000,
  gold: 20_000,
  type: 'dream',
  weakTo: [],
  resistTo: [],

  personality: 'waiting-patient',
  voice: 'A small, polite voice from behind a light. It asks before it takes, which somehow makes it worse.',

  lore: `Nobody hangs the lanterns. They are lit at dusk anyway, every dusk, by a child who is not one anymore and never says so.

It walks the rows with a light in each hand and stops at every traveller to ask whether they would like to sleep. It asks so nicely that people say yes. They are still standing in the field, mostly.

It does not know it is the reason the field is warm. It thinks it is keeping everyone company.`,

  entrance: [
    'One lantern at the end of the row is walking toward you, and it is not a lantern.',
    '"You are new," says the light, in a small, pleased voice. "Would you like to rest? Everyone rests here."',
    'Two hands lift, each holding a light, and the field behind it goes dark in a long, orderly line.',
  ],

  phases: {
    50: [
      '"You are still awake," it says, and for the first time it sounds a little unsure. "That is not how this goes."',
      'The lights in its hands flare, and the field leans in to watch.',
    ],
  },

  attacks: ['A Light Held Out', 'Lullaby Row', 'Dusk Comes Early'],

  attackNarratives: {
    'A Light Held Out': [
      'It offers you a lantern like a hand, and the light goes into your eyes and stays there.',
    ],
    'Lullaby Row': [
      'It hums the harvest song, slower than the field knows it, and the rows hum back.',
    ],
    'Dusk Comes Early': [
      'Every lantern in the field goes out at once, and the dark arrives with its arms open.',
    ],
  },

  tauntLines: ['"Sit down," it says kindly. "The field will keep you."'],

  hitLines: ['"That was loud," it says, in a much smaller voice.'],

  dodgeLines: ['"You moved," it says, delighted. "Nobody moves."'],

  /** One mid fight line is all a champion gets — see the spec's lighter kit. */
  victoryLines: [
    '"You are still awake," it says, and puts the lanterns down, one at a time, and does not pick them up again.',
  ],

  defeatLines: [
    'The light goes out of its hands, and the field keeps burning without it, which is the loneliest thing that has happened here.',
    'It sits down in the row it was born in, and the fog closes over it, and the lanterns go on being lit by nobody.',
  ],

  drops: ['dream_dust', 'dawn_tonic', 'foglight_blade', 'hollow_lantern_charm'],
  dropChances: { dream_dust: 1, dawn_tonic: 0.35, foglight_blade: 0.25, hollow_lantern_charm: 0.25 },

  conquestTitle: 'Lantern Warden',
}
