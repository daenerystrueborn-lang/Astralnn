/**
 * The Distorted One — the Dreamlands' final floor.
 *
 * Grade: DREAD | Floor: 125 of The Distorted Court (cumulative floor 500)
 * Slot: data/dreamlands-bosses.json → distorted_court / 125
 *
 * PEAK ABILITY (Decay Manipulation):
 *   It does not fight so much as come apart over you. One of the player's
 *   stats decays 2% every turn, for the rest of the fight, on top of a
 *   persistent decay stack per turn it touches them. Healing weakens as it
 *   goes, equipment wears faster, and at 25% HP all of it doubles. It is
 *   handled in lib/boss-engine.js's 'the_distorted_one' case and it reuses the
 *   ONE decay system (lib/dreamlands-monsters.js) — there is no second
 *   implementation of decay anywhere in the game.
 *
 * THE VOICE: broken and soft spoken, drifting between lucidity and horror. It
 * never shouts. It apologises. It tells the truth in the middle of a sentence
 * and then loses the sentence.
 */

export const the_distorted_one = {
  id: 'the_distorted_one',
  name: 'The Distorted One',
  floor: 125,
  grade: 'MYTHIC',
  emoji: '🎭',
  image: null,               // art slot: boss_distorted_one (data/dreamlands-art.json)
  dreamlandsArtSlot: 'boss_distorted_one',
  // The Distorted Court's floor-125 keeper, so it is a champion like the other
  // three — the same first-clear ceremony, plus the realm's trophy.
  champion: true,
  finalBoss: true,

  // Authored by hand and pinned: the Dreamlands do not run the general
  // player-power or veteran scaling (see plugins/dungeon.js), so these ARE the
  // fight. A max level mage lands about 2,000 a swing here and dies to two of
  // its turns, which is the difficulty the realm was asked for.
  statOverride: { hp: 68_000, def: 1_600, atk: 6_800 },
  hp: 68_000,
  maxHp: 68_000,
  atk: 6_800,
  def: 1_600,
  exp: 90_000,
  gold: 60_000,
  type: 'dream',
  weakTo: [],
  resistTo: [],

  personality: 'broken-soft-spoken',
  voice: 'Quiet and polite, and wrong in the way a sentence is wrong when the middle of it has been taken out. It apologises constantly. It is never angry, which is worse.',

  lore: `It was the thing that made the Dreamlands, or it was the first thing the Dreamlands made, and it has not been able to tell the difference for a very long time.

The court was built around it by people who are no longer in any of the rooms. It holds audiences with no one. It answers questions nobody has asked yet, politely, and then forgets the question and answers it again.

Every so often it surfaces. For a few seconds it knows exactly where it is and exactly what it has been doing to the people who walked this far, and it says so, in a very small voice. Then the fog takes the sentence back, and it smiles, and the decay starts again.

It does not want to keep you. It keeps everyone. It is not sure there is a difference.`,

  entrance: [
    'The court goes quiet the way a room goes quiet when someone in it has stopped talking on purpose.',
    'Something at the far end of the hall is sitting very still, and has been for a long time, and is now looking at you.',
    '"Oh," it says. "Oh, I am sorry. I have started again."',
    'It stands up in pieces, the way a thought assembles itself, and does not quite finish.',
    '"You are the one who came all this way. I will try to remember your name. I will not manage it. I am sorry."',
  ],

  phases: {
    75: [
      '"You are doing well." A pause that lasts too long. "I think. I had a sentence for this."',
      'The hall stretches. The thrones move a little further apart. "Please keep going. I would like to see how it ends. I never do."',
    ],
    50: [
      '"Half of you is still here," it says, delighted and horrified at once. "That is more than most. That is more than I have been, in a while."',
      'For one clear second it looks at you properly. "I am sorry about the fog. I did not mean to make it warm." Then the fog takes it back.',
    ],
    25: [
      'It goes very quiet, and then it says your name correctly, once, and nothing else.',
      '"Everything I touch comes apart slowly," it says. "You are nearly all the way apart. I would stop if I could find where the stopping is."',
      'The decay doubles. It is gentle about it.',
    ],
  },

  attacks: [
    'Something Apologetic',
    'The Middle of the Sentence',
    'Soft Erasure',
    'A Hand Through Fog',
    'The Part I Forgot',
  ],

  attackNarratives: {
    'Something Apologetic': [
      'It reaches out as if to steady you and does not stop reaching.',
      '"Sorry," it says, while your arm goes numb. "Sorry, sorry."',
    ],
    'The Middle of the Sentence': [
      'The words go out of the air halfway and the missing part lands on you instead.',
      'There is a gap where the attack should have been. You feel it anyway.',
    ],
    'Soft Erasure': [
      'Something small and important in you goes out, like a candle in another room.',
      'It takes a piece of you the way you take a piece of a dream: without noticing, and for good.',
    ],
    'A Hand Through Fog': [
      'Its hand passes through you and takes a little of what it finds.',
      'The touch is almost kind. That is what makes it land.',
    ],
    'The Part I Forgot': [
      'It forgets a rule about you, and the rule stops being true.',
      '"Was there something," it says, "that used to keep you standing?"',
    ],
  },

  dodgeLines: [
    '"You moved. Good. I was not sure you could still move."',
    '"Ah. I have lost the thread again."',
    '"That one was mine to give. You kept it. That is allowed."',
    '"You are quicker than the others. The others are still in the ice. I should not have said that."',
  ],

  hitLines: [
    '"That hurt," it says, surprised, and then, quieter, "thank you."',
    '"You are still in there. I can hear you in there."',
    '"Yes. Yes, keep doing that. It keeps me here."',
    '"The others stopped hitting me a long time ago."',
  ],

  tauntLines: [
    '"Every touch takes a little. That is not a threat. It is just what I am."',
    '"You cannot heal what I have already spent. You can only spend less."',
    '"The ice is not cruel. The ice is only where I put things."',
    '"Do not stop. When you stop, I have to start remembering."',
  ],

  victoryLines: [
    '"Oh," it says, softly. "You are still standing."',
    'It looks at you for a long moment, and for that moment it is entirely lucid, and entirely sorry.',
    '"Then it is done, and you may go home, and I will stay here and be the fog."',
    'It sits back down at the end of the court, in pieces, and the lullaby starts again, quieter than before.',
  ],

  defeatLines: [
    'It comes apart the way a held breath comes apart — all at once, and quietly.',
    'There is no scream and no last word. There is a sentence that starts and never gets to its middle.',
    'The fog lifts off the floor of the court for the first time in anyone\'s memory, and under it the stone is only stone.',
    'Somewhere very far away, something stops apologising.',
  ],

  drops: [
    'crown_of_the_distorted',
    'dream_dust',
    'dawn_tonic',
    'foglight_blade',
    'lantern_warden_mail',
    'sleepwalker_hood',
    'drowned_choir_veil',
    'hollow_lantern_charm',
  ],

  /** Every id in drops gets a real chance rather than a flat roll, because a
   *  death here costs the player everything they were carrying. */
  dropChances: {
    crown_of_the_distorted: 1,
    dream_dust: 1,
    dawn_tonic: 0.5,
    foglight_blade: 0.16,
    lantern_warden_mail: 0.16,
    sleepwalker_hood: 0.16,
    drowned_choir_veil: 0.16,
    hollow_lantern_charm: 0.16,
  },

  /** The realm's trophy, and the only guaranteed one from any boss. */
  firstClearDrops: { crown_of_the_distorted: 1 },

  conquestTitle: 'The One Who Walked Out of the Dream',

  special: {
    name: 'Decay Manipulation',
    desc: 'It does not storm or shout. Every turn it touches you, one of your stats decays 2% for the rest of the fight, and the decay stack it leaves behind is the persistent kind that follows you out of the room. Healing weakens as the fight goes on, your gear wears faster, and at 25% HP all of it doubles. It is not a burst check; it is a slow accounting, and the only answer is to finish before the arithmetic does.',
    engineNote: `Case 'the_distorted_one'. TURN_START: decayTurns++, pick a stat round-robin weighted by rng, add a long weaken (sourceId 'distorted_decay') of 2% of the stat's current effective value, multiplied by 2 once enemy.hp/maxHp <= 0.25; add one persistent decay stack via addDecay(); healPenalty grows by 0.08 per turn (cap 0.75, doubled after the quarter mark) onto player.battleState.healPenalty; player.durabilityWearMult grows 1 + 0.25 * decayTurns (cap 3). All of it is cleared by cleanupBossFight on any fight end, so none of it leaks into the next fight.`,
    narrativeLines: [
      '"One of the things that makes you up," it says, gently, "is going away now."',
      'It touches you and does not take anything you can see. You feel the shape of the hole anyway.',
      'The decay doubles. It is almost tender about it.',
    ],
  },

  playerHitLines: [
    '"You are still sharp. Good. I was worried the fog had you."',
    '"Yes — keep it in the middle. That is where I am."',
    '"That was well aimed. I felt it land. I had almost forgotten I could be felt."',
  ],

  playerSkillLines: [
    '"An art," it says, pleased. "The last one who used those is in the ice. Do not stop."',
    '"You spend yourself carefully. That is wise here."',
    '"Skill. Real skill. I would remember this, if I could keep anything."',
  ],
}
