/**
 * The Sleepwood Mother — tier champion of Sleepwood.
 *
 * Grade: SSS | Floor: 125 of Sleepwood (cumulative floor 250)
 * Slot: data/dreamlands-bosses.json → sleepwood / 125
 *
 * An ELITE nightmare with a champion's lighter voice kit. Beating it unlocks
 * the Drowned Chapel. Stats pinned for the cumulative floor 250 target.
 */

export const sleepwood_mother = {
  id: 'sleepwood_mother',
  name: 'The Sleepwood Mother',
  floor: 125,
  grade: 'SSS',
  emoji: '🌲',
  image: null,               // art slot: champion_sleepwood
  dreamlandsArtSlot: 'champion_sleepwood',
  champion: true,

  statOverride: { hp: 48_000, def: 980, atk: 4_000 },
  hp: 40_000,
  maxHp: 40_000,
  atk: 3_900,
  def: 900,
  exp: 45_000,
  gold: 30_000,
  type: 'dream',
  weakTo: [],
  resistTo: [],

  personality: 'patient-heavy',
  voice: 'Enormous, slow and unbearably gentle. She talks to you the way a mother talks to a child who is already asleep.',

  lore: `The Sleepwood is her body. That is not a metaphor, or not entirely one: the roots under the fog are hers, and every tree that leans toward the path is leaning to hear you better.

She has put every traveller who ever entered her wood to sleep, and she has kept them, and she calls that keeping them safe. The ones in the ice are not hers. She is privately offended by the ice.

She will not stand up to fight you. She does not need to. She has been sitting there for a thousand years with her eyes closed, and she fights you the way a mother reaches across a table.`,

  entrance: [
    'The trees on both sides of the path bend inward at the same time, all the way down, as far as you can hear.',
    '"There you are," says the wood, in a voice that is made of the wood. "You walked so far. Lie down."',
    'Something under the fog is breathing in time with the trees, and it is very much larger than the trees.',
  ],

  phases: {
    50: [
      '"You are still standing," she says, and sounds almost proud, which is worse than anger. "Good. Then I will hold you properly."',
      'The roots come up through the fog without hurrying, the way a hand comes up out of a sleeve.',
    ],
  },

  attacks: ['Roots, Patiently', 'A Bed of Leaves', 'Rock the Bough'],

  attackNarratives: {
    'Roots, Patiently': [
      'Roots rise through the fog and take your ankles, and wait, because they can wait.',
    ],
    'A Bed of Leaves': [
      'The wood lies down under you all at once. It is soft. It is entirely soft.',
    ],
    'Rock the Bough': [
      'Every tree in the wood moves together, once, and the whole world rocks like a cradle.',
    ],
  },

  tauntLines: ['"Sleep," she says, the way a door closes. "You were sleeping before you got here."'],

  hitLines: ['"That does not reach the wood," she says, and means it sympathetically.'],

  dodgeLines: ['"Quick, quick," she says. "The quick ones sleep deepest."'],

  victoryLines: [
    '"There," she says, as you go down. "I have you. Nothing will touch you again. Nothing at all."',
  ],

  defeatLines: [
    'The roots let go of the world slowly, one hillside at a time, and the wood stops leaning.',
    'The fog goes thin, and the trees stand up straight for the first time in a thousand years, and sigh, and are only trees.',
  ],

  drops: ['dream_dust', 'dawn_tonic', 'foglight_blade', 'lantern_warden_mail'],
  dropChances: { dream_dust: 1, dawn_tonic: 0.4, foglight_blade: 0.25, lantern_warden_mail: 0.25 },

  conquestTitle: 'The Woods Remember You',
}
