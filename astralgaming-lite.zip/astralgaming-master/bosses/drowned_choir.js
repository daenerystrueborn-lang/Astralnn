/**
 * The Drowned Choir — tier champion of the Drowned Chapel.
 *
 * Grade: SSS+ | Floor: 125 of the Drowned Chapel (cumulative floor 375)
 * Slot: data/dreamlands-bosses.json → drowned_chapel / 125
 *
 * An ELITE nightmare with a champion's lighter voice kit — many mouths, one
 * hymn. Beating it unlocks The Distorted Court.
 *
 * ITS FIRST DEFEAT DROPS THE FIRST DAWN TONIC (see the drops list and
 * lib/dreamlands-death.js's first-clear hook): it is the only guaranteed
 * source in the game, and after that the tonic is a rare drop from the deeper
 * nightmares, which is exactly what the owner asked for ("you get that around
 * floor 375").
 */

export const drowned_choir = {
  id: 'drowned_choir',
  name: 'The Drowned Choir',
  floor: 125,
  grade: 'SSS+',
  emoji: '⛪',
  image: null,               // art slot: champion_chapel
  dreamlandsArtSlot: 'champion_chapel',
  champion: true,

  statOverride: { hp: 52_000, def: 1_200, atk: 4_900 },
  hp: 52_000,
  maxHp: 52_000,
  atk: 4_900,
  def: 1_200,
  exp: 60_000,
  gold: 40_000,
  type: 'dream',
  weakTo: [],
  resistTo: [],

  personality: 'many-mouthed',
  voice: 'A congregation answering itself. It never sings alone, and every voice in it is slightly off the note, on purpose.',

  lore: `The chapel drowned with the whole valley, and the choir kept singing, because nobody told it to stop.

It is not one thing. It is everyone who was in the pews when the water came, holding one note between them, and the note has worn all of them into the same shape. It sings the way a crowd breathes: without deciding to.

It does not want converts. It has enough. It only wants you to stand still and listen until you are part of the harmony, and the harmony is very patient, and the water has not moved in four hundred years.`,

  entrance: [
    'The water in the chapel is standing perfectly still, and every drop of it is singing.',
    'The pews are empty. The sound is coming from the pews.',
    '"WELCOME," sings the whole room at once, in forty voices, none of them quite the same note.',
    'Under the surface, in a row, something that is not one shape opens what might be a mouth.',
  ],

  phases: {
    50: [
      '"STAY," it sings, and the word goes through the water and through you and comes out the other side slightly wrong.',
      'The hymn drops a half step. Every hair on your arms stands up in time with it.',
    ],
  },

  attacks: ['The Descant', 'Full Chorus', 'Held Under'],

  attackNarratives: {
    'The Descant': [
      'One voice separates from the choir and goes up above the rest, and takes the strength out of your arms with it.',
    ],
    'Full Chorus': [
      'Forty mouths find the same note at once. The chapel walls do not move. You do.',
    ],
    'Held Under': [
      'The water rises just enough to hold your face, and it is warm, and it is singing.',
    ],
  },

  tauntLines: ['"LISTEN," it sings. "You are nearly in tune already."'],

  hitLines: ['The hymn falters for half a bar, and finds itself again, slightly angrier.'],

  dodgeLines: ['"OFF THE BEAT," it sings. "Come back to the beat."'],

  victoryLines: [
    '"THERE," it sings, in all its voices, as the water closes over you. "Now you are harmony."',
  ],

  defeatLines: [
    'The hymn comes apart into forty people, and then into forty sounds, and then into the ordinary drip of a flooded room.',
    'The last voice is a woman\'s, and it says one clear word before it goes: "Thank you."',
  ],

  drops: ['dream_dust', 'dawn_tonic', 'drowned_choir_veil', 'sleepwalker_hood', 'hollow_lantern_charm'],
  dropChances: { dream_dust: 1, dawn_tonic: 0.6, drowned_choir_veil: 0.3, sleepwalker_hood: 0.3, hollow_lantern_charm: 0.3 },

  /** First time only: the Dawn Tonic is guaranteed, not rolled. */
  firstClearDrops: { dawn_tonic: 1 },

  conquestTitle: 'The Choir Knows Your Name',
}
