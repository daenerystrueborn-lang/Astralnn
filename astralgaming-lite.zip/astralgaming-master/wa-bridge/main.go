// wa-bridge — a thin whatsmeow sidecar for the bot.
//
// The Node bot spawns this binary and talks to it over stdin/stdout using one
// JSON object per line. stdout is RESERVED for that protocol; all logging goes
// to stderr.
//
//	Node -> Go : {"id":N,"cmd":"send","args":{...}}
//	Go -> Node : {"id":N,"ok":true,"data":{...}}  or  {"id":N,"ok":false,"error":"..."}
//	Go -> Node : {"event":"message","data":{...}}  (unsolicited)
//
// Pairing: at most PAIR_WINDOW (60s) from the moment a pairing code is
// requested. If the phone has not linked inside that window the connection is
// torn down and a "close" event with reason "pairing_timeout" is emitted.
package main

import (
	"bufio"
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"os"
	"runtime/debug"
	"strings"
	"sync"
	"time"

	_ "github.com/mattn/go-sqlite3"
	"google.golang.org/protobuf/encoding/protojson"

	"go.mau.fi/whatsmeow"
	"go.mau.fi/whatsmeow/proto/waE2E"
	"go.mau.fi/whatsmeow/store"
	"go.mau.fi/whatsmeow/store/sqlstore"
	"go.mau.fi/whatsmeow/types"
	"go.mau.fi/whatsmeow/types/events"
	waLog "go.mau.fi/whatsmeow/util/log"
)

// PAIR_WINDOW is the hard limit for the whole pairing flow (code issued ->
// phone confirmed). Change here if you ever want a different limit.
const PAIR_WINDOW = 60 * time.Second

var (
	client *whatsmeow.Client
	outMu  sync.Mutex
	out    = bufio.NewWriter(os.Stdout)

	pairRequestMu sync.Mutex
	pairMu        sync.Mutex
	pairTimer     *time.Timer
	pairActive    bool
)

type request struct {
	ID   int64           `json:"id"`
	Cmd  string          `json:"cmd"`
	Args json.RawMessage `json:"args"`
}

func emit(v any) {
	b, err := json.Marshal(v)
	if err != nil {
		fmt.Fprintln(os.Stderr, "emit marshal:", err)
		return
	}
	outMu.Lock()
	out.Write(b)
	out.WriteByte('\n')
	out.Flush()
	outMu.Unlock()
}

func event(name string, data any) { emit(map[string]any{"event": name, "data": data}) }

func reply(id int64, data any, err error) {
	if err != nil {
		emit(map[string]any{"id": id, "ok": false, "error": err.Error()})
		return
	}
	emit(map[string]any{"id": id, "ok": true, "data": data})
}

func jidStr(j types.JID) string {
	if j.IsEmpty() {
		return ""
	}
	return j.String()
}

func parseJID(s string) (types.JID, error) {
	if !strings.Contains(s, "@") {
		return types.NewJID(s, types.DefaultUserServer), nil
	}
	return types.ParseJID(s)
}

// ── pairing window ─────────────────────────────────────────────────────────

func startPairWindow(window time.Duration) {
	pairMu.Lock()
	defer pairMu.Unlock()
	if pairTimer != nil {
		pairTimer.Stop()
	}
	pairActive = true
	pairTimer = time.AfterFunc(window, func() {
		pairMu.Lock()
		active := pairActive
		pairActive = false
		pairMu.Unlock()
		if !active || client == nil || client.Store.ID != nil {
			return
		}
		fmt.Fprintln(os.Stderr, "pairing window (60s) expired — disconnecting")
		client.Disconnect()
		event("close", map[string]any{"statusCode": 408, "reason": "pairing_timeout"})
	})
}

func endPairWindow() {
	pairMu.Lock()
	defer pairMu.Unlock()
	pairActive = false
	if pairTimer != nil {
		pairTimer.Stop()
		pairTimer = nil
	}
}

// ── events ─────────────────────────────────────────────────────────────────

var pjson = protojson.MarshalOptions{UseProtoNames: false, EmitUnpopulated: false}

// recoverPanic keeps one bad event or command from killing the whole sidecar,
// which would take every connected session down with it. The panic and its
// stack go to stderr (the Node side keeps that as the exit reason). It must be
// deferred directly, because recover() only works in the deferred function.
func recoverPanic(where string) {
	if r := recover(); r != nil {
		fmt.Fprintf(os.Stderr, "panic: recovered in %s: %v\n%s\n", where, r, debug.Stack())
	}
}

func onEvent(raw any) {
	defer recoverPanic("event handler")
	switch e := raw.(type) {
	case *events.Connected:
		endPairWindow()
		me := jidStr(client.Store.GetJID())
		lid := jidStr(client.Store.GetLID())
		event("open", map[string]any{"id": me, "lid": lid, "name": client.Store.PushName})
	case *events.PairSuccess:
		endPairWindow()
		event("paired", map[string]any{"id": jidStr(e.ID), "lid": jidStr(e.LID)})
	case *events.Disconnected:
		// whatsmeow reconnects by itself; only report if we are not pairing.
		event("transient_disconnect", map[string]any{})
	case *events.LoggedOut:
		event("close", map[string]any{"statusCode": 401, "reason": "logged_out"})
	case *events.StreamReplaced:
		event("close", map[string]any{"statusCode": 440, "reason": "conflict"})
	case *events.ClientOutdated:
		event("close", map[string]any{"statusCode": 405, "reason": "client_outdated"})
	case *events.TemporaryBan:
		event("close", map[string]any{"statusCode": 403, "reason": "temporary_ban"})
	case *events.Message:
		mj, err := pjson.Marshal(e.Message)
		if err != nil {
			fmt.Fprintln(os.Stderr, "message marshal:", err)
			return
		}
		pn, lid := senderAddresses(e)
		event("message", map[string]any{
			"key": map[string]any{
				"remoteJid":      jidStr(e.Info.Chat),
				"id":             e.Info.ID,
				"fromMe":         e.Info.IsFromMe,
				"participant":    participant(e),
				"participantAlt": jidStr(e.Info.SenderAlt),
				// The two spellings of the sender (see senderAddresses).
				// The Node side needs the phone jid to find the player
				// record: in a LID-addressed group the participant is a
				// @lid id whose digits are NOT the phone number, so
				// without this the same person is unrecognisable there
				// while being perfectly known in their DM.
				"participantPn":  pn,
				"participantLid": lid,
				"senderPn":       pn,
				"senderLid":      lid,
				"chatPn":         chatPhone(e),
				"addressingMode": string(e.Info.AddressingMode),
			},
			"pushName":         e.Info.PushName,
			"messageTimestamp": e.Info.Timestamp.Unix(),
			"isGroup":          e.Info.IsGroup,
			"isViewOnce":       e.IsViewOnce,
			"isEdit":           e.IsEdit,
			"message":          json.RawMessage(mj),
		})
	case *events.GroupInfo:
		for action, list := range map[string][]types.JID{
			"add": e.Join, "remove": e.Leave, "promote": e.Promote, "demote": e.Demote,
		} {
			if len(list) == 0 {
				continue
			}
			ps := make([]string, 0, len(list))
			for _, j := range list {
				ps = append(ps, jidStr(j))
			}
			author := ""
			if e.Sender != nil {
				author = jidStr(*e.Sender)
			}
			event("group-participants", map[string]any{
				"id": jidStr(e.JID), "action": action, "participants": ps, "author": author,
			})
		}
	case *events.JoinedGroup:
		event("group-participants", map[string]any{
			"id": jidStr(e.JID), "action": "add", "participants": []string{jidStr(client.Store.GetJID())},
			"author": "",
		})
	}
}

func participant(e *events.Message) string {
	if e.Info.IsGroup {
		return jidStr(e.Info.Sender)
	}
	return ""
}

// senderOf is the address the Node side treats as "from": the group
// participant, or the chat itself in a 1:1.
func senderOf(e *events.Message) types.JID {
	if e.Info.IsGroup {
		return e.Info.Sender
	}
	return e.Info.Chat
}

// chatPhone is the phone-number JID of the chat, for DMs only - a group's
// "phone jid" is meaningless.
func chatPhone(e *events.Message) string {
	if e.Info.IsGroup {
		return ""
	}
	if e.Info.Chat.Server == types.DefaultUserServer {
		return jidStr(e.Info.Chat)
	}
	return jidStr(altJID(e.Info.Chat, phoneOf))
}

// altJID resolves jid to its other spelling through fn, under a short timeout
// so a slow LID-map query can never wedge the message stream.
func altJID(jid types.JID, fn func(context.Context, types.JID) types.JID) types.JID {
	if jid.IsEmpty() || client == nil || client.Store == nil || client.Store.LIDs == nil {
		return types.EmptyJID
	}
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	return fn(ctx, jid)
}

// The LID map lives on the device store and is filled from group metadata and
// contact sync, so it is the authoritative local answer for "which phone
// number is this LID" once WhatsApp has told us once.
func phoneOf(ctx context.Context, jid types.JID) types.JID {
	if jid.IsEmpty() || jid.Server != types.HiddenUserServer {
		return types.EmptyJID
	}
	pn, err := client.Store.LIDs.GetPNForLID(ctx, jid)
	if err != nil {
		return types.EmptyJID
	}
	return pn
}

func lidOf(ctx context.Context, jid types.JID) types.JID {
	if jid.IsEmpty() || jid.Server != types.DefaultUserServer {
		return types.EmptyJID
	}
	lid, err := client.Store.LIDs.GetLIDForPN(ctx, jid)
	if err != nil {
		return types.EmptyJID
	}
	return lid
}

// senderAddresses returns the sender's phone-number JID and LID, whichever of
// the two the visible address is not. SenderAlt already carries the answer
// when WhatsApp supplied it (it is the alternative address of the sender), so
// the LID map is only consulted when it did not.
func senderAddresses(e *events.Message) (string, string) {
	sender := senderOf(e)
	pn, lid := types.EmptyJID, types.EmptyJID
	switch sender.Server {
	case types.DefaultUserServer:
		pn = sender
		if e.Info.SenderAlt.Server == types.HiddenUserServer {
			lid = e.Info.SenderAlt
		} else {
			lid = altJID(sender, lidOf)
		}
	case types.HiddenUserServer:
		lid = sender
		if e.Info.SenderAlt.Server == types.DefaultUserServer {
			pn = e.Info.SenderAlt
		} else {
			pn = altJID(sender, phoneOf)
		}
	}
	return jidStr(pn), jidStr(lid)
}

// ── group metadata ─────────────────────────────────────────────────────────

func groupJSON(g *types.GroupInfo) map[string]any {
	parts := make([]map[string]any, 0, len(g.Participants))
	for _, p := range g.Participants {
		admin := any(nil)
		if p.IsSuperAdmin {
			admin = "superadmin"
		} else if p.IsAdmin {
			admin = "admin"
		}
		parts = append(parts, map[string]any{
			"id": jidStr(p.JID), "lid": jidStr(p.LID), "phoneNumber": jidStr(p.PhoneNumber), "admin": admin,
		})
	}
	return map[string]any{
		"id": jidStr(g.JID), "subject": g.Name, "desc": g.Topic,
		"owner": jidStr(g.OwnerJID), "creation": g.GroupCreated.Unix(),
		"announce": g.IsAnnounce, "restrict": g.IsLocked,
		"addressingMode": string(g.AddressingMode),
		"size":           len(g.Participants), "participants": parts,
	}
}

// ── command handling ───────────────────────────────────────────────────────

func handle(req request) {
	ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
	defer cancel()
	defer func() {
		if r := recover(); r != nil {
			fmt.Fprintf(os.Stderr, "panic: recovered in command %q: %v\n%s\n", req.Cmd, r, debug.Stack())
			reply(req.ID, nil, fmt.Errorf("bridge panicked on %q: %v", req.Cmd, r))
		}
	}()
	data, err := dispatch(ctx, req.Cmd, req.Args)
	reply(req.ID, data, err)
}

func dispatch(ctx context.Context, cmd string, raw json.RawMessage) (any, error) {
	var a map[string]any
	if len(raw) > 0 {
		decoder := json.NewDecoder(bytes.NewReader(raw))
		decoder.UseNumber()
		_ = decoder.Decode(&a)
	}
	str := func(k string) string { s, _ := a[k].(string); return s }
	boolean := func(k string) bool { b, _ := a[k].(bool); return b }

	switch cmd {
	case "ping":
		return map[string]any{"pong": true}, nil

	case "pair":
		pairRequestMu.Lock()
		defer pairRequestMu.Unlock()
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		if client.Store.ID != nil {
			return nil, fmt.Errorf("already registered")
		}
		// Connecting and requesting the code share the caller's remaining budget.
		// A JS command timeout must not leave a 90s request running in Go.
		window := PAIR_WINDOW
		if rawMS, ok := a["windowMs"].(json.Number); ok {
			if ms, err := rawMS.Int64(); err == nil && ms >= 1000 && time.Duration(ms)*time.Millisecond < window {
				window = time.Duration(ms) * time.Millisecond
			}
		}
		deadline := time.Now().Add(window)
		requestCtx, cancel := context.WithTimeout(ctx, min(window, 30*time.Second))
		defer cancel()
		if err := connectForPairing(requestCtx, client); err != nil {
			return nil, err
		}
		code, err := client.PairPhone(requestCtx, str("phone"), true, whatsmeow.PairClientChrome, "Chrome (Linux)")
		if err != nil {
			return nil, err
		}
		remaining := time.Until(deadline)
		if remaining <= 0 {
			client.Disconnect()
			return nil, context.DeadlineExceeded
		}
		startPairWindow(remaining)
		return map[string]any{"code": code, "expiresInMs": remaining.Milliseconds()}, nil

	case "logout":
		endPairWindow()
		return nil, client.Logout(ctx)

	case "disconnect":
		endPairWindow()
		client.Disconnect()
		return nil, nil

	case "send":
		to, err := parseJID(str("jid"))
		if err != nil {
			return nil, err
		}
		msg := &waE2E.Message{}
		mj, _ := json.Marshal(a["message"])
		if err := unmarshalMessageJSON(mj, msg); err != nil {
			return nil, fmt.Errorf("bad message: %w", err)
		}
		extra := whatsmeow.SendRequestExtra{}
		if id := str("id"); id != "" {
			extra.ID = id
		}
		resp, err := client.SendMessage(ctx, to, msg, extra)
		if err != nil {
			return nil, err
		}
		return map[string]any{"id": resp.ID, "timestamp": resp.Timestamp.Unix()}, nil

	case "revoke":
		chat, _ := parseJID(str("jid"))
		sender := types.EmptyJID
		if s := str("participant"); s != "" {
			sender, _ = parseJID(s)
		}
		if boolean("fromMe") {
			sender = types.EmptyJID // whatsmeow: empty sender = own message
		}
		resp, err := client.SendMessage(ctx, chat, client.BuildRevoke(chat, sender, str("msgId")))
		if err != nil {
			return nil, err
		}
		return map[string]any{"id": resp.ID}, nil

	case "edit":
		chat, _ := parseJID(str("jid"))
		nm := &waE2E.Message{}
		mj, _ := json.Marshal(a["message"])
		if err := unmarshalMessageJSON(mj, nm); err != nil {
			return nil, err
		}
		resp, err := client.SendMessage(ctx, chat, client.BuildEdit(chat, str("msgId"), nm))
		if err != nil {
			return nil, err
		}
		return map[string]any{"id": resp.ID}, nil

	case "upload": // {path, type: image|video|audio|document}
		b, err := os.ReadFile(str("path"))
		if err != nil {
			return nil, err
		}
		mt := map[string]whatsmeow.MediaType{
			"image": whatsmeow.MediaImage, "sticker": whatsmeow.MediaImage,
			"video": whatsmeow.MediaVideo, "audio": whatsmeow.MediaAudio,
			"document": whatsmeow.MediaDocument,
		}[str("type")]
		if mt == "" {
			return nil, fmt.Errorf("unknown media type %q", str("type"))
		}
		up, err := client.Upload(ctx, b, mt)
		if err != nil {
			return nil, err
		}
		return map[string]any{
			"url": up.URL, "directPath": up.DirectPath,
			"mediaKey":      base64.StdEncoding.EncodeToString(up.MediaKey),
			"fileEncSha256": base64.StdEncoding.EncodeToString(up.FileEncSHA256),
			"fileSha256":    base64.StdEncoding.EncodeToString(up.FileSHA256),
			"fileLength":    up.FileLength,
		}, nil

	case "download": // {message: waE2E.Message json, out: file path}
		msg := &waE2E.Message{}
		mj, _ := json.Marshal(a["message"])
		if err := unmarshalMessageJSON(mj, msg); err != nil {
			return nil, err
		}
		b, err := client.DownloadAny(ctx, msg)
		if err != nil {
			return nil, err
		}
		if err := os.WriteFile(str("out"), b, 0o600); err != nil {
			return nil, err
		}
		return map[string]any{"size": len(b)}, nil

	case "groupMetadata":
		j, err := parseJID(str("jid"))
		if err != nil {
			return nil, err
		}
		g, err := client.GetGroupInfo(ctx, j)
		if err != nil {
			return nil, err
		}
		return groupJSON(g), nil

	case "groupFetchAll":
		gs, err := client.GetJoinedGroups(ctx)
		if err != nil {
			return nil, err
		}
		res := map[string]any{}
		for _, g := range gs {
			res[jidStr(g.JID)] = groupJSON(g)
		}
		return res, nil

	case "groupParticipantsUpdate":
		j, _ := parseJID(str("jid"))
		var ps []types.JID
		if arr, ok := a["participants"].([]any); ok {
			for _, p := range arr {
				if s, ok := p.(string); ok {
					pj, err := parseJID(s)
					if err == nil {
						ps = append(ps, pj)
					}
				}
			}
		}
		res, err := client.UpdateGroupParticipants(ctx, j, ps, whatsmeow.ParticipantChange(str("action")))
		if err != nil {
			return nil, err
		}
		out := make([]map[string]any, 0, len(res))
		for _, r := range res {
			out = append(out, map[string]any{"status": "200", "jid": jidStr(r.JID)})
		}
		return out, nil

	case "groupUpdateSubject":
		j, _ := parseJID(str("jid"))
		return nil, client.SetGroupName(ctx, j, str("value"))
	case "groupUpdateDescription":
		j, _ := parseJID(str("jid"))
		return nil, client.SetGroupTopic(ctx, j, "", "", str("value"))
	case "groupSettingUpdate":
		j, _ := parseJID(str("jid"))
		switch str("setting") {
		case "announcement":
			return nil, client.SetGroupAnnounce(ctx, j, true)
		case "not_announcement":
			return nil, client.SetGroupAnnounce(ctx, j, false)
		case "locked":
			return nil, client.SetGroupLocked(ctx, j, true)
		case "unlocked":
			return nil, client.SetGroupLocked(ctx, j, false)
		}
		return nil, fmt.Errorf("unknown setting")
	case "groupLeave":
		j, _ := parseJID(str("jid"))
		return nil, client.LeaveGroup(ctx, j)
	case "groupInviteCode":
		j, _ := parseJID(str("jid"))
		link, err := client.GetGroupInviteLink(ctx, j, false)
		return strings.TrimPrefix(link, whatsmeow.InviteLinkPrefix), err
	case "groupRevokeInvite":
		j, _ := parseJID(str("jid"))
		link, err := client.GetGroupInviteLink(ctx, j, true)
		return strings.TrimPrefix(link, whatsmeow.InviteLinkPrefix), err
	case "groupAcceptInvite":
		j, err := client.JoinGroupWithLink(ctx, str("code"))
		return jidStr(j), err
	case "groupGetInviteInfo":
		g, err := client.GetGroupInfoFromLink(ctx, str("code"))
		if err != nil {
			return nil, err
		}
		return groupJSON(g), nil

	case "onWhatsApp":
		var phones []string
		if arr, ok := a["jids"].([]any); ok {
			for _, p := range arr {
				if s, ok := p.(string); ok {
					phones = append(phones, "+"+strings.Split(s, "@")[0])
				}
			}
		}
		rs, err := client.IsOnWhatsApp(ctx, phones)
		if err != nil {
			return nil, err
		}
		out := make([]map[string]any, 0, len(rs))
		for _, r := range rs {
			out = append(out, map[string]any{"jid": jidStr(r.JID), "exists": r.IsIn})
		}
		return out, nil

	case "profilePictureUrl":
		j, _ := parseJID(str("jid"))
		info, err := client.GetProfilePictureInfo(ctx, j, &whatsmeow.GetProfilePictureParams{})
		if err != nil || info == nil {
			return nil, err
		}
		return info.URL, nil

	case "readMessages":
		chat, _ := parseJID(str("jid"))
		sender := types.EmptyJID
		if s := str("participant"); s != "" {
			sender, _ = parseJID(s)
		} else {
			sender = chat
		}
		return nil, client.MarkRead(ctx, []types.MessageID{str("msgId")}, time.Now(), chat, sender)

	case "presence":
		state := str("state")
		if j := str("jid"); j != "" {
			jj, _ := parseJID(j)
			cp := types.ChatPresenceComposing
			if state == "paused" {
				cp = types.ChatPresencePaused
			}
			media := types.ChatPresenceMediaText
			if state == "recording" {
				media = types.ChatPresenceMediaAudio
			}
			return nil, client.SendChatPresence(ctx, jj, cp, media)
		}
		p := types.PresenceAvailable
		if state == "unavailable" {
			p = types.PresenceUnavailable
		}
		return nil, client.SendPresence(ctx, p)
	}
	return nil, fmt.Errorf("unknown command %q", cmd)
}

// ── main ───────────────────────────────────────────────────────────────────

func main() {
	dbPath := os.Getenv("WA_DB")
	if dbPath == "" {
		dbPath = "whatsmeow.db"
	}
	ctx := context.Background()
	// stdout is the protocol channel, so whatsmeow's own logger stays silent.
	elog := waLog.Noop

	container, err := sqlstore.New(ctx, "sqlite3", "file:"+dbPath+"?_foreign_keys=on&_busy_timeout=10000", elog)
	if err != nil {
		fmt.Fprintln(os.Stderr, "db:", err)
		os.Exit(2)
	}
	var dev *store.Device
	dev, err = container.GetFirstDevice(ctx)
	if err != nil {
		fmt.Fprintln(os.Stderr, "device:", err)
		os.Exit(2)
	}
	store.DeviceProps.Os = ptr("Ubuntu")
	client = whatsmeow.NewClient(dev, elog)
	client.AddEventHandler(onEvent)

	// Tell the Node side whether this device is already linked.
	event("ready", map[string]any{"registered": client.Store.ID != nil})

	// Linked devices connect straight away. Unlinked ones wait for "pair",
	// which opens the socket itself.
	if client.Store.ID != nil {
		go func() {
			if err := client.Connect(); err != nil {
				event("close", map[string]any{"statusCode": 500, "reason": err.Error()})
			}
		}()
	}

	sc := bufio.NewScanner(os.Stdin)
	sc.Buffer(make([]byte, 0, 1<<20), 64<<20)
	for sc.Scan() {
		var req request
		if err := json.Unmarshal(sc.Bytes(), &req); err != nil {
			fmt.Fprintln(os.Stderr, "bad request:", err)
			continue
		}
		go handle(req)
	}
	// stdin closed => parent died; shut down cleanly.
	client.Disconnect()
}

func ptr[T any](v T) *T { return &v }
