package main

import (
	"context"
	"fmt"

	"go.mau.fi/whatsmeow"
	"go.mau.fi/whatsmeow/types/events"
)

type pairingConnector interface {
	IsConnected() bool
	ConnectContext(context.Context) error
	Disconnect()
	AddEventHandler(whatsmeow.EventHandler) uint32
	RemoveEventHandler(uint32) bool
}

// ConnectContext only opens the transport. PairPhone must wait for events.QR,
// which confirms the login handshake is ready (per whatsmeow's PairPhone docs).
// The Node settle delay happens BEFORE Go connects, so it cannot do this job.
func connectForPairing(ctx context.Context, conn pairingConnector) error {
	if conn.IsConnected() {
		return ctx.Err()
	}
	ready := make(chan error, 1)
	handler := conn.AddEventHandler(func(raw any) {
		var err error
		switch raw.(type) {
		case *events.QR:
		case *events.ClientOutdated:
			err = fmt.Errorf("WhatsApp client is outdated; update the whatsmeow bridge")
		case *events.Disconnected:
			err = fmt.Errorf("WhatsApp disconnected before the pairing handshake was ready")
		default:
			return
		}
		select {
		case ready <- err:
		default:
		}
	})
	defer conn.RemoveEventHandler(handler)

	// Whatsmeow retains the ConnectContext context for its read/keepalive loops.
	// Cancelling the command context after returning a code would immediately
	// close the login socket. Forward cancellation only until the handshake is
	// ready; afterwards Disconnect()/the pairing timer owns the connection.
	connectionCtx, cancelConnection := context.WithCancel(context.WithoutCancel(ctx))
	stopCancel := context.AfterFunc(ctx, cancelConnection)
	keepConnection := false
	defer func() {
		stopCancel()
		if !keepConnection {
			cancelConnection()
			conn.Disconnect()
		}
	}()
	if err := conn.ConnectContext(connectionCtx); err != nil {
		return err
	}
	select {
	case err := <-ready:
		if err != nil {
			return err
		}
		if !stopCancel() || ctx.Err() != nil {
			return ctx.Err()
		}
		keepConnection = true
		return nil
	case <-ctx.Done():
		return fmt.Errorf("waiting for WhatsApp pairing handshake: %w", ctx.Err())
	}
}
