#!/usr/bin/env sh
# Builds the whatsmeow bridge into ./wa-bridge/bin/wa-bridge.
# Needs Go >= 1.26 and a C compiler (go-sqlite3 uses cgo).
set -eu
cd "$(dirname "$0")"

# The Docker runtime receives a binary from the Go build stage. This is an
# explicit opt-out, not a swallowed build error, and requires that artifact.
if [ "${WA_BRIDGE_SKIP_BUILD:-0}" = "1" ]; then
  if [ ! -x bin/wa-bridge ]; then
    echo "[wa-bridge] WA_BRIDGE_SKIP_BUILD=1 requires an executable bin/wa-bridge" >&2
    exit 1
  fi
  echo "[wa-bridge] using the prebuilt binary"
  exit 0
fi

if ! command -v go >/dev/null 2>&1; then
  echo "[wa-bridge] Go 1.26+ is required. Use the Railway Dockerfile, or install Go and a C compiler, then run npm run build:bridge." >&2
  exit 1
fi

# Resolve the committed dependency graph; never tidy/upgrade it during deploy.
export GOTOOLCHAIN="${GOTOOLCHAIN:-auto}"
go mod download
go mod verify
mkdir -p bin
CGO_ENABLED=1 go build -mod=readonly -trimpath -ldflags="-s -w" -o bin/wa-bridge .
echo "built: $(pwd)/bin/wa-bridge"
