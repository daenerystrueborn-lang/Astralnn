package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"strings"

	"google.golang.org/protobuf/encoding/protojson"
	"google.golang.org/protobuf/proto"
	"google.golang.org/protobuf/reflect/protoreflect"
)

// unmarshalMessageJSON accepts the protobuf-JSON field names produced by both
// transports used by this project:
//
//   - whatsmeow/protojson: stanzaID, mentionedJID, fileSHA256, URL, ...
//   - Baileys/protobufjs: stanzaId, mentionedJid, fileSha256, url, ...
//
// The Node side deliberately keeps exposing Baileys-shaped messages to the
// rest of the bot. protojson field matching is case-sensitive, however, so a
// quoted reply used to fail before it reached WhatsApp with:
//
//     unknown field "stanzaId"
//
// Resolve aliases against the actual protobuf descriptor before doing the
// strict protojson decode. Unknown fields are intentionally left untouched so
// protojson still rejects typos instead of silently dropping message data.
func unmarshalMessageJSON(raw []byte, dst proto.Message) error {
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.UseNumber() // do not round uint64 timestamps/file lengths through float64

	var value any
	if err := decoder.Decode(&value); err != nil {
		return fmt.Errorf("decode message JSON: %w", err)
	}

	normalized := normalizeMessageJSON(value, dst.ProtoReflect().Descriptor())
	canonical, err := json.Marshal(normalized)
	if err != nil {
		return fmt.Errorf("encode normalized message JSON: %w", err)
	}
	return protojson.Unmarshal(canonical, dst)
}

func normalizeMessageJSON(value any, descriptor protoreflect.MessageDescriptor) any {
	object, ok := value.(map[string]any)
	if !ok {
		return value
	}

	fields := descriptor.Fields()
	normalized := make(map[string]any, len(object))
	for name, fieldValue := range object {
		field := messageFieldByAlias(fields, name)
		if field == nil {
			// Keep this key so protojson can return its normal unknown-field error.
			normalized[name] = fieldValue
			continue
		}
		normalized[field.JSONName()] = normalizeFieldJSON(fieldValue, field)
	}
	return normalized
}

func messageFieldByAlias(fields protoreflect.FieldDescriptors, name string) protoreflect.FieldDescriptor {
	if field := fields.ByJSONName(name); field != nil {
		return field
	}
	if field := fields.ByTextName(name); field != nil {
		return field
	}
	for i := 0; i < fields.Len(); i++ {
		field := fields.Get(i)
		if strings.EqualFold(name, field.JSONName()) || strings.EqualFold(name, field.TextName()) {
			return field
		}
	}
	return nil
}

func normalizeFieldJSON(value any, field protoreflect.FieldDescriptor) any {
	if field.IsMap() {
		mapValue := field.MapValue()
		if mapValue.Kind() != protoreflect.MessageKind && mapValue.Kind() != protoreflect.GroupKind {
			return value
		}
		object, ok := value.(map[string]any)
		if !ok {
			return value
		}
		for key, item := range object {
			object[key] = normalizeMessageJSON(item, mapValue.Message())
		}
		return object
	}

	if field.IsList() {
		if field.Kind() != protoreflect.MessageKind && field.Kind() != protoreflect.GroupKind {
			return value
		}
		items, ok := value.([]any)
		if !ok {
			return value
		}
		for i, item := range items {
			items[i] = normalizeMessageJSON(item, field.Message())
		}
		return items
	}

	if field.Kind() == protoreflect.MessageKind || field.Kind() == protoreflect.GroupKind {
		return normalizeMessageJSON(value, field.Message())
	}
	return value
}
