#!/usr/bin/env python3
"""
voice_music.py — play music in a Telegram group's voice chat.

WHY THIS IS NOT PART OF THE NODE BOT
------------------------------------
The Telegram Bot API cannot join a voice chat or stream audio into one. There
is no bot method for it, in any framework — python-telegram-bot included. The
only way to play music in a voice chat is a *user account* connected over
MTProto (Telegram's client protocol), which is what this process does:

    Pyrogram  → logs in as a real Telegram account (API_ID/API_HASH + session)
    py-tgcalls → joins the group's voice chat and streams the audio

So this is a SEPARATE process from main-all.js / main-telegram.js, with its own
credentials, and it plays music — it does not run game commands. The game bot
still sends .song files through the normal Bot API (sendAudio), which works
fine and needs none of this.

RISK
----
A user account automated like this can be limited or banned by Telegram. Use a
DEDICATED account, not your personal one, and not the number you care about.
It must be a member of the group and a group admin to manage voice chats.

SETUP
-----
1. https://my.telegram.org → API development tools → create an app.
   Copy API_ID and API_HASH into .env (see .env.example in this folder).
2. python3 -m venv .venv && source .venv/bin/activate
   pip install -r requirements.txt
3. First run: SESSION_STRING is empty, so Pyrogram asks for the phone number
   and the login code once. It prints a session string — save it in .env so
   later runs never need the code.
4. Run:  python voice_music.py
"""

import asyncio
import os
import re
import shutil
import tempfile
from pathlib import Path

from dotenv import load_dotenv
from pyrogram import Client, filters
from pyrogram.types import Message
from pytgcalls import PyTgCalls
from pytgcalls.types import MediaStream

load_dotenv()

API_ID = int(os.environ.get("API_ID", "0") or 0)
API_HASH = os.environ.get("API_HASH", "")
SESSION_STRING = os.environ.get("SESSION_STRING", "")
# Only these groups may be controlled. Comma-separated chat ids (-100…).
# Empty = every group the account is in, which is convenient for testing and a
# bad idea in production.
ALLOWED_CHATS = {
    int(x) for x in re.split(r"[,\s]+", os.environ.get("MUSIC_ALLOWED_CHATS", "")) if x.strip()
}
PREFIX = os.environ.get("MUSIC_PREFIX", "/")
DOWNLOAD_DIR = Path(os.environ.get("MUSIC_DOWNLOAD_DIR", tempfile.gettempdir())) / "astral-music"

if not API_ID or not API_HASH:
    raise SystemExit("API_ID / API_HASH missing — see music-sidecar/README.md")

DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)

app = Client("astral-music", api_id=API_ID, api_hash=API_HASH, session_string=SESSION_STRING or None)
calls = PyTgCalls(app)


def allowed(message: Message) -> bool:
    return not ALLOWED_CHATS or message.chat.id in ALLOWED_CHATS


def is_group_admin(message: Message) -> bool:
    """Only admins may start/stop the music. Falls back to False on any error."""
    try:
        member = message.chat.get_member(message.from_user.id) if message.from_user else None
    except Exception:
        return False
    return bool(member and member.status in ("creator", "administrator"))


async def download(query_or_url: str) -> Path:
    """
    Resolve a search term or URL to a local audio file with yt-dlp.

    Done here (not in the Node bot) so this process has no dependency on the
    game's ffmpeg pipeline — it only needs a playable file.
    """
    import yt_dlp

    outtmpl = str(DOWNLOAD_DIR / "%(id)s.%(ext)s")
    ydl_opts = {
        "format": "bestaudio/best",
        "outtmpl": outtmpl,
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "default_search": "ytsearch1",
        "postprocessors": [{"key": "FFmpegExtractAudio", "preferredcodec": "m4a"}],
    }

    def _run():
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(query_or_url, download=True)
            if "entries" in info:
                info = info["entries"][0]
            return Path(ydl.prepare_filename(info)).with_suffix(".m4a")

    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, _run)


@app.on_message(filters.command(["play", "music"], prefixes=PREFIX) & filters.group)
async def play(client: Client, message: Message):
    if not allowed(message):
        return
    if not is_group_admin(message):
        return await message.reply_text("Only admins can control the music.")

    query = " ".join(message.command[1:]).strip()
    if not query:
        return await message.reply_text(f"Usage: {PREFIX}play <song name or link>")

    status = await message.reply_text(f"🔎 Searching: {query}")
    try:
        path = await download(query)
    except Exception as err:  # noqa: BLE001 — surface the reason to the chat
        return await status.edit_text(f"❌ Could not fetch audio.\n{err}")

    try:
        await calls.play(message.chat.id, MediaStream(str(path)))
    except Exception as err:  # noqa: BLE001
        return await status.edit_text(
            "❌ Could not join the voice chat.\n"
            f"{err}\n\nStart a voice chat in the group first, and make sure this account is an admin."
        )

    await status.edit_text(f"🎵 Playing: {path.stem}")


@app.on_message(filters.command("stop", prefixes=PREFIX) & filters.group)
async def stop(client: Client, message: Message):
    if not allowed(message) or not is_group_admin(message):
        return
    await calls.leave_group_call(message.chat.id)
    await message.reply_text("⏹ Stopped.")


@app.on_message(filters.command("pause", prefixes=PREFIX) & filters.group)
async def pause(client: Client, message: Message):
    if not allowed(message) or not is_group_admin(message):
        return
    await calls.pause_stream(message.chat.id)
    await message.reply_text("⏸ Paused.")


@app.on_message(filters.command("resume", prefixes=PREFIX) & filters.group)
async def resume(client: Client, message: Message):
    if not allowed(message) or not is_group_admin(message):
        return
    await calls.resume_stream(message.chat.id)
    await message.reply_text("▶️ Resumed.")


@app.on_message(filters.command("gleave", prefixes=PREFIX) & filters.group)
async def leave(client: Client, message: Message):
    """Leave the call but stay in the group (unlike /stop, which also leaves)."""
    if not allowed(message) or not is_group_admin(message):
        return
    await calls.leave_group_call(message.chat.id)
    await message.reply_text("👋 Left the voice chat.")


async def main():
    await app.start()
    await calls.start()
    me = await app.get_me()
    print(f"🎧 voice_music ready as @{me.username or me.id}")
    print(f"   groups: {sorted(ALLOWED_CHATS) if ALLOWED_CHATS else 'ANY (set MUSIC_ALLOWED_CHATS)'}")
    print(f"   on-disk audio: {DOWNLOAD_DIR}")
    if not SESSION_STRING:
        print(f"   session string: {await app.export_session_string()}")
        print("   ^ save this in .env as SESSION_STRING")
    # Keep the process alive; Pyrogram/pytgcalls run their own loops.
    await asyncio.Event().wait()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("bye")
