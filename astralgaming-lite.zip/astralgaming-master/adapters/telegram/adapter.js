/**
 * adapter.js — grammY ↔ pipeline translation, and nothing else.
 *
 * This file decodes Telegram updates into ctx and hands them to
 * lib/platform/pipeline.js's runCommand(), which owns every gate from "this is
 * a valid command" onwards. It deliberately contains NO game rules: the only
 * policy here is the Telegram-platform policy the owner set —
 *
 *   • the prefix is '/' (the global '.' still parses, because every help
 *     string in the bot prints '.')
 *   • DMs are locked except for a small allowlist that includes linking —
 *     plus the owner (always) and Premium holders (50 commands a day), both
 *     of which handler.js has always granted and this file used to not
 *   • a bare /start always answers, because it is the first thing Telegram
 *     sends and silence there reads as "the bot is dead"
 *
 * Everything game-shaped (ban, jail, night, battle, sect, hunger, Dreamlands)
 * belongs in the shared gate chain, not here. See docs + pipeline.js.
 */
import { Bot } from 'grammy'
import { config } from '../../config.js'
import { runCommand, parseCommand } from '../../lib/platform/pipeline.js'
import { registerCommandMenu } from '../../lib/telegram-command-menu.js'
import { miniappPublicUrl } from '../../lib/miniapp/run.js'
import { setHealthProvider, getHealthProvider } from '../../lib/bot-health.js'
import { recordGroupSighting } from '../../lib/telegram-groups.js'
import { createTelegramGuard } from '../../lib/telegram-guard.js'
import { rememberUser, forgetMember, forgetChat } from '../../lib/telegram-moderation.js'
import { getLink, resolveLinkedId } from '../../lib/account-link.js'
import { getPlayer, updatePlayer } from '../../lib/player-repo.js'
import { toPlayerId } from '../../lib/platform/identity.js'
import { isPlatformOwner } from '../../lib/platform/permissions.js'
import { createTelegramSender } from './send.js'
import {
  battleScreenRowMode,
  createContextFactory,
  isBattleScreenMessage,
  messageText,
  setBattleScreenRow,
} from './context.js'
import { dmPlayAllowed, groupOnlyNotice } from '../../lib/dm-policy.js'
import {
  dmAllowanceForPlayer,
  consumePremiumDmSlot,
  PREMIUM_DM_LIMIT,
  formatTimeUntilReset,
} from '../../lib/premium-perks.js'
import {
  askRejectionReason,
  clearRejection,
  decidePayOrder,
  decisionText,
  getPayOrder,
  pendingRejection,
  setTelegramDesk,
} from '../../lib/pay-orders.js'

/**
 * Commands that work in a private chat even though DMs are closed.
 *
 * `link`/`connect`/`code` are the whole point of the allowance: proving you can
 * read the master account's notification bell is what proves the character is
 * yours, and that conversation happens in a DM. `start` is Telegram's own
 * handshake. Everything else must be typed in a group.
 */
import { hasPendingStoryChoice, handleStoryChoiceReply } from '../../plugins/story.js'

export const DM_ALLOWED_COMMANDS = new Set([
  'start', 'help', 'link', 'connect', 'code', 'mycode', 'linkcode', 'connectcode',
  'ping', 'menu', 'register', 'signup', 'myid', 'id',
  // Read-only lookups on your own character. `register` in a DM is supported
  // (see the header) and its success message tells the player to go play in
  // the group — but a brand-new player will type /profile first, and answering
  // that with "DMs are closed" immediately after creating their character is
  // how a working flow reads as a broken one. Nothing here changes state, and
  // every one of them is scoped to the caller.
  'profile', 'me', 'stats', 'allcommands',
  // Premium / purchase desks must stay reachable so a locked player can see
  // what they own, read the plans, and find the WhatsApp purchase route.
  // Telegram-native money commands are still refused by plugins-telegram.
  'premium', 'vip', 'topup', 'gems', 'buygems', 'buysolars', 'monds', 'mond',
  'buymonds', 'mondshop', 'gm', 'gameshop', 'season', 'seasons', 'seasoninfo',
  'story', 'story-mode', 'preorder', 'pre-order', 'promo', 'promos', 'promogems',
  'elite', 'elitepass', 'buyelite', 'astral-pass', 'astralpass', 'apass', 'ap',
  'character', 'characters', 'char',
  // The gate pillar's read screens. A gate opens in a GROUP and is claimed
  // there, but the board, the rank ladder and a player's own gate record are
  // reference, like .season — a Premium-locked player can still read them.
  'gate', 'gates', 'gateboard',
])

/**
 * The chat menu button — the thing a player taps to open the Mini App.
 *
 * Telegram has two independent knobs here and they are easy to confuse:
 *
 *   • the / COMMAND PALETTE (setMyCommands) — a list, opened by typing "/"
 *   • the MENU BUTTON (setChatMenuButton) — ONE button beside the message box
 *
 * This sets the second. It is deliberately opt-in (`MINIAPP_ENABLED`): changing
 * the menu button rewrites the UI for every user of the bot, which is not a
 * thing a deploy should do the moment someone pushes a web app. With the flag
 * off, the button keeps Telegram's default behaviour and every command still
 * works.
 *
 * The URL must be public HTTPS — Telegram refuses http and localhost outright,
 * and the failure surfaces in the client as a menu that does nothing. That is
 * checked here so the boot log can say why instead of leaving it to be guessed.
 */
export async function registerMenuButton(bot) {
  if (!config.miniappEnabled) return { ok: false, reason: 'disabled' }

  const url = miniappPublicUrl()
  if (!/^https:\/\//.test(url)) {
    return { ok: false, reason: 'insecure_url', url }
  }

  try {
    await bot.api.setChatMenuButton({
      menu_button: { type: 'web_app', text: 'Play', web_app: { url } },
    })
    return { ok: true, url }
  } catch (err) {
    return { ok: false, reason: 'api_error', error: err?.message ?? String(err), url }
  }
}

/**
 * What a DM gets instead of the command it asked for.
 *
 * Two versions, because one blanket notice was a dead end for exactly the
 * people it was written for: a linked player typing /me was told to "send
 * /link <username>", which answers "Already linked" and stops — no mention of
 * where to play, and no way to see which character they were linked to.
 *
 * The unlinked version is the real linking flow, end to end. It used to stop
 * after step 1, so anyone following it requested a code and then had no idea
 * they were supposed to come back and type it. See startText() for the same
 * three steps.
 */
/**
 * What `/start` says in a fresh private chat.
 *
 * DM gameplay is a Premium allowance, matching the WhatsApp DM lock. Groups
 * remain the free place to play; this chat is for linking, account/purchase
 * desks, and Premium holders' private commands.
 */
function startText() {
  return (
    `⚔️ *${config.telegramBotName}* ⚔️\n\n` +
    `I run the Astral RPG, one character shared with WhatsApp and the site.\n\n` +
    `*Groups are the free game:* fights, dungeons, shop, daily, PvP, cards, ` +
    `and guild business.\n\n` +
    `*Private DM gameplay is Premium:* active holders get ` +
    `${PREMIUM_DM_LIMIT} non-whitelisted DM commands per day, plus the usual ` +
    `Premium perks. Account linking, registration, and the purchase/status ` +
    `desks stay reachable here.\n\n` +
    `*New here?*\n` +
    `\`/register\` makes your character, then play in a group.\n\n` +
    `*Playing already?*\n` +
    `Link this Telegram account to your character:\n` +
    `*1.* \`/link <your in-game username>\`\n` +
    `*2.* Read the 6-digit code on WhatsApp with \`.code\`, or from the 🔔 bell on the site\n` +
    `*3.* Come back and send just the code, \`/link 481920\`\n\n` +
    `_Command prefix: / (and . still works, because every guide prints it)._`
  )
}

function dmBlockedText(db, platformId, gate) {
  const pr = config.telegramPrefix
  if (gate?.reason === 'dm-cap') {
    const reset = gate.allowance?.resetAt ? formatTimeUntilReset(gate.allowance.resetAt) : 'soon'
    return (
      `🔒 *You've used all ${PREMIUM_DM_LIMIT} Premium DM commands today.*\n\n` +
      `Your cap resets in *${reset}*. Account, purchase, and status commands ` +
      `still work here, and groups are always open for play.`
    )
  }

  if (gate?.reason === 'premium-required') {
    return (
      '🔒 *DM gameplay is Premium.*\n\n' +
      `Active Premium holders get ${PREMIUM_DM_LIMIT} non-whitelisted DM ` +
      'commands per day. Groups remain free for everyone.\n\n' +
      `• *${pr}premium plans* — view the plans\n` +
      `• *${pr}premium status* — check your subscription\n` +
      `Premium is bought on WhatsApp with *${config.prefix}premium buy <plan>*.`
    )
  }

  let name = null
  try {
    const link = getLink(db, platformId)
    if (link) {
      const linked = getPlayer(db, link.masterId)
      name = linked?.username ?? linked?.name ?? null
    }
  } catch {
    name = null
  }

  if (name) {
    return (
      '🔒 *Register first.*\n\n' +
      `✅ This account is linked to *@${name}*, but that character still ` +
      'needs a registered profile before DM gameplay can be checked.\n\n' +
      '*`/link`* shows your link status. *`/link remove`* unlinks this account.'
    )
  }

  return (
    '🔒 *Register first.*\n\n' +
    '*New here?* `/register` makes your character, then play in a group.\n\n' +
    '*Playing already?* Link this account to your character:\n' +
    '*1.* `/link <your in-game username>`\n' +
    '*2.* Read the 6-digit code on WhatsApp with `.code`, or from the 🔔 bell on the site\n' +
    '*3.* Come back and send just the code, `/link 481920`'
  )
}

/**
 * Handle a `k:` tap: rearrange the keyboard of the message it came from.
 *
 * Today that is the battle card's skill picker (`k:skills` / `k:back`). The
 * renderer (lib/battle-frame-render.mjs) owns the button rows, so this only
 * has to remember WHICH row is open and repaint it — the import is lazy
 * because that module pulls in the canvas renderer, and a bot with no battles
 * running should never pay for it.
 *
 * A tap that cannot be honoured (no message, no player, no skills) leaves the
 * keyboard exactly as it was: a dead button is better than an error bump.
 */
async function handleKeyboardTap(db, sender, tctx, action) {
  const message = tctx.callbackQuery?.message
  if (!message?.message_id || !message.chat?.id) return

  const chatId = message.chat.id
  const userId = tctx.from?.id
  if (!userId) return

  // The screen key is the LINKED character id, because that is what
  // buildContext passes to battleScreen() when the card is painted
  // (`from` = resolveLinkedId(platformId)). Keying here on the raw tg: id
  // meant the picker a player opened and the row the card remembered were
  // two different entries, so the pad snapped shut on the next turn.
  const platformId = toPlayerId('telegram', userId)
  let playerId = platformId
  try {
    playerId = resolveLinkedId(db, platformId)
  } catch {
    playerId = platformId
  }
  const mode = action === 'skills' ? 'skills' : 'default'

  setBattleScreenRow(chatId, playerId, mode)

  const { battleActionButtons, equippedSkillButtons } = await import('../../lib/battle-frame-render.mjs')
  const { skills: allSkills } = await import('../../lib/game-data.js')

  let player = null
  try {
    player = getPlayer(db, playerId)
  } catch {
    player = null
  }

  const rows = battleActionButtons(null, {
    mode,
    skills: equippedSkillButtons(player, allSkills),
  })

  await sender.editButtons(chatId, message.message_id, rows)
}

/**
 * Everything the DM gate needs to know about one command typed in a DM.
 *
 * Split out of handleMessage because button taps are a second door into the
 * same commands: `callback_query:data` re-enters runCommand directly, and it
 * used to skip the DM lock entirely — a keyboard left in a DM could run a
 * group-only command. Both doors now ask this one function.
 *
 * Mirrors handler.js's DM lock:
 *   • the OWNER is never walled; both the raw tg: id and the linked master id
 *     are checked, because a linked owner may arrive under a WhatsApp id.
 *   • whitelisted account/purchase/status commands stay reachable so a locked
 *     player can register, link, read plans, and find the purchase route.
 *   • active Premium holders get PREMIUM_DM_LIMIT non-whitelisted DM commands
 *     per calendar day. Everyone else plays in groups.
 */
function dmGate(db, platformId, cmd) {
  const playerId = resolveLinkedId(db, platformId)
  const isOwner = isPlatformOwner(platformId) || isPlatformOwner(playerId)
  const whitelisted = DM_ALLOWED_COMMANDS.has(cmd)

  let player = null
  try {
    player = getPlayer(db, playerId)
  } catch {
    player = null // a malformed record must not crash the gate
  }

  const policy = dmPlayAllowed(cmd, player)
  if (!isOwner && policy.reason === 'group-only') {
    return { allowed: false, isOwner, whitelisted, groupOnly: true, reason: 'group-only', player, playerId }
  }

  if (isOwner || whitelisted) {
    return { allowed: true, isOwner, whitelisted, player, playerId }
  }

  if (!player) {
    return { allowed: false, isOwner, whitelisted, reason: 'unregistered', player, playerId }
  }

  const allowance = dmAllowanceForPlayer(player)
  if (!allowance.isPremium) {
    return { allowed: false, isOwner, whitelisted, reason: 'premium-required', allowance, player, playerId }
  }
  if (allowance.allowed <= 0) {
    return { allowed: false, isOwner, whitelisted, reason: 'dm-cap', allowance, player, playerId }
  }

  return { allowed: true, isOwner, whitelisted, allowance, player, playerId }
}

/**
 * Build and initialise the bot. Returns handles rather than starting polling,
 * so the entry point can install shutdown handlers first — otherwise a Ctrl-C
 * between start() and the handlers leaves a half-open socket behind.
 */
export async function createTelegramBot({ db }) {
  if (!config.telegramToken) {
    throw new Error('TELEGRAM_TOKEN is empty — set it in .env (see .env.example)')
  }

  const bot = new Bot(config.telegramToken)
  const sender = createTelegramSender({ api: bot.api })
  // The payment desk: lib/pay-orders.js DMs proofs through this handle. The
  // API server is built before the poller starts and a WhatsApp-only deploy
  // never gets here, so the seam is a registration rather than a parameter.
  setTelegramDesk(bot.api)
  const buildContext = createContextFactory({ db, bot, sender })

  /**
   * Charge one Premium DM slot after a non-whitelisted command actually ran.
   * Mirrors handler.js: unknown/refused commands do not burn a slot, and the
   * purchase/status whitelist never burns one either.
   */
  async function chargeTelegramDmSlot(gate, chatId) {
    if (!gate || gate.isOwner || gate.whitelisted || !gate.playerId) return
    let left = null
    try {
      await updatePlayer(db, gate.playerId, fresh => {
        const res = consumePremiumDmSlot(fresh)
        if (res.consumed) left = res.allowance.allowed
        return fresh
      })
    } catch {
      return
    }
    if (left != null && left > 0 && left <= 5 && chatId) {
      await sender.sendText(
        chatId,
        `👑 *${left} Premium DM command${left === 1 ? '' : 's'} left today.* ` +
        `Groups stay free, and account/purchase commands do not burn this cap.`,
      ).catch(() => {})
    }
  }

  await bot.init()

  // Publish the / autocomplete list before announcing readiness, so the first
  // thing a player taps in a fresh client is a working command.
  const menuButton = await registerMenuButton(bot)
  if (menuButton.ok) {
    console.log(`[telegram] menu button → Mini App at ${menuButton.url}`)
    const username = bot.botInfo?.username
    if (username) {
      // The direct link BotFather shows on the Mini Apps page. Printing it here
      // means the owner can paste it into a pinned message without hunting.
      console.log(`[telegram] direct link: https://t.me/${username}?startapp=play`)
    }
  } else if (menuButton.reason === 'insecure_url') {
    console.warn(
      `[telegram] MINIAPP_ENABLED is on but ${menuButton.url} is not https — ` +
      'Telegram will not open it. Set PUBLIC_API_URL (or MINIAPP_URL) to the public https origin.',
    )
  } else if (menuButton.reason === 'api_error') {
    console.warn(`[telegram] setChatMenuButton failed: ${menuButton.error}`)
  }

  const registered = await registerCommandMenu(bot)
  if (registered.players) {
    console.log(
      `[telegram] / menu: ${registered.players} player commands, ` +
      `${registered.admins} for chat admins (moderation included there only)`,
    )
  }

  // An empty owner list is not a warning — it is a bot with no owner: /main
  // can never register the main group, every owner command is refused, and the
  // owner is treated as a normal player in DMs. There is no fallback to the
  // WhatsApp owner numbers on purpose (they are phone numbers, not Telegram
  // ids), so say so loudly at boot instead of letting it be discovered one
  // command at a time.
  if (!config.telegramOwnerIds?.length) {
    console.warn(
      '[telegram] TELEGRAM_OWNER_IDS is empty — nobody can run owner commands or /main, ' +
      'and the owner will be treated as an ordinary player in DMs. ' +
      'Send /myid to the bot in a DM, then set TELEGRAM_OWNER_IDS to that number.',
    )
  }

  // Health for `.health`/`.ping`. MERGE with whatever main.js installed:
  // replacing it would hide the WhatsApp socket and send-queue numbers that
  // lib/bot-health.js exists to report, which is exactly the blindness it was
  // written to fix. `telegram` is a sibling key, never an overwrite.
  const baseProvider = getHealthProvider()
  setHealthProvider(() => {
    let base = null
    try {
      base = baseProvider ? baseProvider() : null
    } catch {
      base = null
    }
    return {
      ...(base && typeof base === 'object' ? base : {}),
      telegram: {
        botId: bot.botInfo?.id ?? null,
        username: bot.botInfo?.username ?? null,
        queuedChats: sender.queue.size(),
        at: Date.now(),
      },
    }
  })

  bot.catch((err) => {
    const e = err?.error ?? err
    process.stderr.write(`[telegram] handler failed: ${e?.stack ?? e?.message ?? e}\n`)
  })

  // ── group moderation, before anything else ───────────────────────────────
  // Telegram's equivalent of handler.js's runModerationScans(): the rules that
  // act on messages which are NOT commands — a link posted, a flood, a muted
  // member talking, a locked group. Registered with bot.use() so it is the
  // first thing every update goes through and it can stop an update dead
  // (grammY middleware: not calling next() ends the chain).
  //
  // This has to be installed before bot.command('start') and bot.on('message'),
  // because grammY runs middleware in registration order.
  //
  // It fails OPEN: a throw in the guard is logged and the update continues to
  // the command handler. A broken moderation rule must not silence the game.
  let guard = null
  try {
    guard = createTelegramGuard({ db, api: bot.api, botId: bot.botInfo?.id })
  } catch (err) {
    console.error(`[telegram] guard could not be installed: ${err?.message ?? err}`)
  }

  if (guard) {
    bot.use(async (tctx, next) => {
      try {
        if (await guard.check(tctx)) return
      } catch (err) {
        process.stderr.write(`[telegram] guard failed: ${err?.stack ?? err}\n`)
      }
      await next()
    })
  }

  // ── membership changes ───────────────────────────────────────────────────
  // Kept even though nothing greets anyone yet: it is the only reliable moment
  // the bot learns that a member was promoted/demoted/kicked, and the
  // permission caches in lib/telegram-moderation.js would otherwise keep
  // saying "admin" for up to a minute after the rights were taken away.
  bot.on('chat_member', async (tctx) => {
    const update = tctx.chatMember
    if (!update?.chat || !update.new_chat_member) return
    const chat = update.chat
    if (chat.type !== 'group' && chat.type !== 'supergroup') return

    const member = update.new_chat_member
    rememberUser(member.user)
    forgetMember(chat.id, member.user?.id)
    if (String(member.user?.id) === String(bot.botInfo?.id)) forgetChat(chat.id)

    const isAdmin = member.status === 'creator' || member.status === 'administrator'
    recordGroupSighting(chat.id, chat.title ?? '', String(member.user?.id ?? ''), isAdmin)
      .catch(() => {})
  })

  // ── /start ───────────────────────────────────────────────────────────────
  // Answered directly, never through runCommand: 'start' is not a game
  // command, and a plugin named `start` must not be able to shadow the
  // handshake every new user triggers.
  bot.command('start', async (tctx) => {
    try {
      // Through the sender, not tctx.reply: startText() is written in the
      // bot's WhatsApp markdown, and only the sender converts it to HTML.
      await sender.sendText(tctx.chat.id, startText())
    } catch (err) {
      console.error(`[telegram] /start reply failed: ${err?.message ?? err}`)
    }
  })

  // ── one inbound handler for text and captioned media ─────────────────────
  async function handleMessage(tctx) {
    const message = tctx.message
    if (!message || !tctx.from || tctx.from.is_bot) return

    const body = messageText(message)
    // Photos with no caption can never be a command, but they ARE the payload
    // for .setpfp/.setbanner — those arrive as a reply or as photo+caption, so
    // the text path covers them. Nothing to do with an empty body.
    if (!body.trim()) return

    const chat = message.chat
    const isGroup = chat.type === 'group' || chat.type === 'supergroup'

    // Remember who this is, so a later `.kick @theirname` can be resolved: a
    // bare @mention carries no id, and this Map is the only place the two are
    // ever seen together.
    rememberUser(tctx.from)

    // Per-group sighting, so the DM config screen can list the groups this
    // person administers (Telegram exposes no such query).
    if (isGroup) {
      recordGroupSighting(chat.id, chat.title ?? '', String(tctx.from.id), false).catch(() => {})
    }

    // ── the owner naming a reason ──────────────────────────────────────────
    // Pressing ❌ Reject asks "why?" with Telegram's force-reply prompt, and
    // the answer is an ordinary line of chat. It has to be claimed BEFORE
    // parseCommand() sees a non-command and drops it. Owner only, DM only, and
    // only while a question is actually open (lib/pay-orders.js holds it for
    // ten minutes) — so a normal message can never be mistaken for a verdict.
    if (!isGroup && !/^[/.!]/.test(body.trim())) {
      const deskId = toPlayerId('telegram', tctx.from.id)
      const asked = pendingRejection(deskId)
      if (asked && isPlatformOwner(deskId)) {
        const result = await decidePayOrder(db, asked.id, {
          status: 'rejected',
          reason: body.trim(),
          decidedBy: deskId,
        })
        clearRejection(deskId)
        await sender.sendText(chat.id, decisionText(result)).catch(() => {})
        return
      }
    }

    const parsed = parseCommand(body, [config.telegramPrefix, config.prefix])

    // ── Story Mode choice-reply bypass ──────────────────────────────────────
    // A story choice is answered with a BARE "1", "2" or "3". That is not a
    // command, so parseCommand() returns null and the reader's answer used to
    // be dropped on the floor: the chapter stopped at the choice and nothing
    // they typed could move it. On WhatsApp this seam exists in handler.js;
    // Telegram had no equivalent, which is why story mode was unplayable here.
    //
    // It has to sit ABOVE the DM lock too, or the answer is refused with
    // "DMs are closed" before anything ever reads it.
    //
    // Prefixed commands skip it entirely, so a mid-chapter /premium or /story
    // still works, and groups are excluded because a story is read in a DM.
    if (!isGroup && !body.trim().startsWith(config.telegramPrefix) && !body.trim().startsWith(config.prefix)) {
      const maybePlayer = getPlayer(db, toPlayerId('telegram', tctx.from.id))
      if (hasPendingStoryChoice(maybePlayer)) {
        const storyCtx = {
          db,
          from: toPlayerId('telegram', tctx.from.id),
          sender: String(chat.id),
          sock: null,
          args: [],
          reply: (text) => sender.sendText(chat.id, String(text ?? ''), { replyTo: message?.message_id }),
        }
        const consumed = await handleStoryChoiceReply(storyCtx, maybePlayer, body).catch((err) => {
          console.error(`[telegram] story choice failed: ${err?.stack ?? err}`)
          return false
        })
        if (consumed) return
      }
    }

    if (!parsed) return

    const { cmd, args } = parsed

    // ── DM lock ────────────────────────────────────────────────────────────
    // See dmGate(): owner exempt, account/purchase/status whitelist reachable,
    // Premium holders get a daily DM allowance, everyone else plays in groups.
    const platformId = toPlayerId('telegram', tctx.from.id)
    const gate = dmGate(db, platformId, cmd)

    if (!isGroup && !gate.allowed) {
      const line = gate.groupOnly
        ? groupOnlyNotice(cmd, { prefix: config.telegramPrefix })
        : dmBlockedText(db, platformId, gate)
      await sender.sendText(chat.id, line).catch(() => {})
      return
    }

    const ctx = buildContext(tctx, {
      cmd,
      args,
      body,
      prefix: body.startsWith(config.telegramPrefix) ? config.telegramPrefix : config.prefix,
    })

    try {
      const handled = await runCommand(ctx)
      if (handled && !isGroup) await chargeTelegramDmSlot(gate, chat.id)

      // NO fallback reply here. runCommand() -> dispatch() already answered an
      // unknown command, so an extra line would send two messages for a typo.
    } catch (err) {
      process.stderr.write(`[telegram] command '${cmd}' failed: ${err?.stack ?? err}\n`)
    }
  }

  bot.on('message', handleMessage)

  // ── button taps ──────────────────────────────────────────────────────────
  // Encoding: `c:<command>`. Every button id in this bot is already a complete,
  // typeable command (lib/interactive-buttons.js), so a tap is just the typed
  // command re-entered through the same pipeline — one code path, no parallel
  // button handlers that can drift from the text version.
  bot.on('callback_query:data', async (tctx) => {
    // First, always: an unanswered callback leaves the client spinning.
    await tctx.answerCallbackQuery().catch(() => {})

    const data = tctx.callbackQuery?.data ?? ''

    // ── k: keyboard-only navigation ─────────────────────────────────────
    // Some taps do not RUN anything, they open a different pad: the battle
    // card's ✨ Skill swaps attack/defend for the player's equipped skills, and
    // ↩️ Back swaps them back. Routing those through `c:` would have executed
    // the word `skills` as a command, and sending a message to explain a
    // keyboard is worse than just showing it.
    if (data.startsWith('k:')) {
      await handleKeyboardTap(db, sender, tctx, data.slice(2)).catch((err) =>
        process.stderr.write(`[telegram] keyboard tap '${data}' failed: ${err?.message ?? err}\n`),
      )
      return
    }

    // ── the payment desk buttons ───────────────────────────────────────────
    // `payok:` / `payno:` sit under the proof DM (lib/pay-orders.js). They are
    // not commands — Verify is one write and Reject needs a second message —
    // so they get their own branch, and both end in the same decidePayOrder()
    // the typed `.payverify` / `.payreject` use. Owner only: the buttons are
    // only ever sent to the owner's DM, but a forwarded message carries them
    // too, and a tap is not proof of identity.
    if (data.startsWith('payok:') || data.startsWith('payno:')) {
      const deskId = toPlayerId('telegram', tctx.from.id)
      if (!isPlatformOwner(deskId)) return
      const chatId = tctx.callbackQuery?.message?.chat?.id
      const id = data.slice('payok:'.length)
      if (!chatId || !id) return

      if (data.startsWith('payok:')) {
        const result = await decidePayOrder(db, id, { status: 'verified', decidedBy: deskId })
        await sender.sendText(chatId, decisionText(result)).catch(() => {})
        await tctx.editMessageReplyMarkup({ reply_markup: { inline_keyboard: [] } }).catch(() => {})
        return
      }

      // Reject: ask for the words first. The order is not touched until the
      // reason arrives, so a stray tap cannot refuse a real payment.
      const known = getPayOrder(db, id)
      if (!known) {
        await sender.sendText(chatId, `❌ No order with the id ${id}.`).catch(() => {})
        return
      }
      if (known.status !== 'pending') {
        await sender.sendText(chatId, decisionText({ order: known, changed: false })).catch(() => {})
        await tctx.editMessageReplyMarkup({ reply_markup: { inline_keyboard: [] } }).catch(() => {})
        return
      }
      askRejectionReason(deskId, id)
      await bot.api
        .sendMessage(
          chatId,
          `✍️ Why is ${known.id} being rejected?\n\n` +
          'The player reads this line in the app, so make it useful — ' +
          '"the screenshot is cut off" or "that is the weekly price".\n\n' +
          `Send the reason as a reply, or ${config.telegramPrefix}payverify ${known.id} to accept instead.`,
          {
            reply_markup: {
              force_reply: true,
              input_field_placeholder: 'Why? The player sees this.',
            },
          },
        )
        .catch(() => {})
      return
    }

    if (!data.startsWith('c:')) return
    const command = data.slice(2)
    if (!command) return

    const parsed = parseCommand(command.startsWith('/') || command.startsWith('.')
      ? command
      : `${config.telegramPrefix}${command}`, [config.telegramPrefix, config.prefix])
    if (!parsed) return

    const message = tctx.callbackQuery.message

    // Button taps are a SECOND door into the same commands, and this door used
    // to skip the DM lock entirely: a keyboard left behind in a DM could run a
    // command the typed path refuses. Same gate, same wall, same Premium
    // charge — otherwise the lock is decorative.
    const cbChat = message?.chat
    const cbIsGroup = cbChat?.type === 'group' || cbChat?.type === 'supergroup'
    const cbPlatformId = toPlayerId('telegram', tctx.from.id)
    const cbGate = cbIsGroup ? null : dmGate(db, cbPlatformId, parsed.cmd)
    if (cbGate && !cbGate.allowed) {
      if (cbChat?.id) {
        const line = cbGate.groupOnly
          ? groupOnlyNotice(parsed.cmd, { prefix: config.telegramPrefix })
          : dmBlockedText(db, cbPlatformId, cbGate)
        await sender.sendText(cbChat.id, line).catch(() => {})
      }
      return
    }

    const ctx = buildContext(tctx, {
      cmd: parsed.cmd,
      args: parsed.args,
      body: parsed.body,
      prefix: config.telegramPrefix,
    })

    try {
      const handled = await runCommand(ctx)
      if (handled && !cbIsGroup) await chargeTelegramDmSlot(cbGate, cbChat?.id)
    } catch (err) {
      process.stderr.write(`[telegram] callback '${parsed.cmd}' failed: ${err?.stack ?? err}\n`)
    }

    // A consumed flow must not be tappable again — EXCEPT /menu, whose buttons
    // are a section switcher, and the LIVE BATTLE SCREEN, whose keyboard is the
    // fight's control pad and is re-rendered by every turn. Clearing either
    // turns a permanent control into a single-use button.
    //
    // The battle check is by message id, not by command name: the same /attack
    // typed in the chat has no keyboard to keep, while the one tapped on the
    // battle card must keep the full pad (attack/skill/defend/flee) so the
    // player can chain turns without touching the keyboard.
    const keepKeyboard =
      parsed.cmd === 'menu' || isBattleScreenMessage(message?.chat?.id, message?.message_id)
    if (message?.message_id && !keepKeyboard) {
      sender.clearKeyboard(message.chat.id, message.message_id).catch(() => {})
    }
  })

  // ── polling ──────────────────────────────────────────────────────────────
  // bot.start() handles updates ONE AT A TIME: it awaits handleUpdate() before
  // fetching the next one. So a single slow command (a battle render, a Mongo
  // round trip, a big menu) holds up every other message in every other chat,
  // and the bot reads as "slow" while nothing is actually wrong. That is what
  // this loop replaces.
  //
  // Concurrency is per CHAT, not global: two groups (or a group and a DM) run
  // in parallel, while updates from the same chat stay strictly in order. The
  // per-player write queue in lib/player-repo.js assumes that order, and
  // reordering two taps from one player is how you lose an update.
  const ALLOWED_UPDATES = ['message', 'edited_message', 'callback_query', 'chat_member']
  const MAX_IN_FLIGHT = 24
  const chatChains = new Map()

  function chatKeyOf(update) {
    const chat =
      update.message?.chat ??
      update.edited_message?.chat ??
      update.callback_query?.message?.chat ??
      update.chat_member?.chat
    return String(chat?.id ?? 'global')
  }

  /** Run `task` after everything already queued for this chat. */
  function serialPerChat(key, task) {
    const prev = chatChains.get(key) ?? Promise.resolve()
    const next = prev.then(task, task)
    const settled = next.catch(() => {})
    chatChains.set(key, settled)
    // Drop the entry once it is the tail again, so the map tracks active chats
    // rather than every chat the bot has ever seen.
    settled.then(() => {
      if (chatChains.get(key) === settled) chatChains.delete(key)
    })
    return next
  }

  function startPolling() {
    const controller = new AbortController()
    let offset = 0
    let inFlight = 0

    const loop = (async () => {
      // A webhook left behind by another deploy makes getUpdates fail with 409
      // forever and the bot looks dead. This adapter never sets one, so
      // clearing it is always safe.
      try {
        await bot.api.deleteWebhook({ drop_pending_updates: false })
      } catch (err) {
        console.warn(`[telegram] deleteWebhook failed (continuing): ${err?.message ?? err}`)
      }

      let backoff = 1000
      while (!controller.signal.aborted) {
        let updates
        try {
          updates = await bot.api.getUpdates(
            { offset, timeout: 25, allowed_updates: ALLOWED_UPDATES },
            controller.signal,
          )
          backoff = 1000
        } catch (err) {
          if (controller.signal.aborted) break
          // 409 here means another process is polling the same token; saying so
          // once is worth more than a silent retry loop.
          console.error(`[telegram] getUpdates failed (retrying in ${backoff}ms): ${err?.message ?? err}`)
          await new Promise((r) => setTimeout(r, backoff))
          backoff = Math.min(backoff * 2, 30_000)
          continue
        }

        for (const update of updates) {
          offset = Math.max(offset, update.update_id + 1)
          // Backpressure: a flood (a busy battle group) must not be handled by
          // starting unbounded work. Nothing is dropped, we just poll slower.
          while (inFlight >= MAX_IN_FLIGHT && !controller.signal.aborted) {
            await new Promise((r) => setTimeout(r, 25))
          }
          inFlight++
          serialPerChat(chatKeyOf(update), () => bot.handleUpdate(update))
            .catch((err) =>
              process.stderr.write(`[telegram] update ${update.update_id} failed: ${err?.stack ?? err}\n`),
            )
            .finally(() => { inFlight-- })
        }
      }
    })()

    return {
      done: loop,
      stop: async () => {
        controller.abort()
        // The in-flight long poll can take up to `timeout` seconds to return;
        // a redeploy must not wait that out. Abort first, then stop waiting.
        await Promise.race([
          loop.catch(() => {}),
          new Promise((r) => setTimeout(r, 1500)),
        ])
      },
    }
  }

  let polling = null

  return {
    bot,
    sender,
    start: () => {
      polling = startPolling()
      return polling.done
    },
    stop: async () => {
      await polling?.stop()
      polling = null
      // Harmless no-op: nothing called bot.start(), but bot.stop() is the
      // documented way to leave the API in a clean state.
      await bot.stop().catch(() => {})
    },
  }
}
