/**
 * send.js — the Telegram side of ctx.reply().
 *
 * One place turns a WhatsApp-style reply into a Telegram message: convert the
 * markdown, split what's too long, pace it per chat, and retry once on 429.
 * Everything the plugins do passes through here, which is why the formatting
 * and chunking rules live behind it rather than in each of ~410 plugins.
 *
 * The returned value is a grammY Message for the FIRST piece, so
 * `const sent = await ctx.reply(...)` + `ctx.editReply(sent, ...)` keeps
 * working exactly as it does on WhatsApp (plugins/walk.js, plugins/reborn.js
 * and the cinematics depend on that).
 */
import { InputFile } from 'grammy'
import { config } from '../../config.js'
import { getPlatform } from '../../lib/platform/capabilities.js'
import { splitCaption } from '../../lib/platform/chunk.js'
import { whatsappToHtml, chunkTelegramHtml } from '../../lib/platform/telegram-format.js'
import { createChatQueue, retryAfterMs } from '../../lib/platform/send-queue.js'
import { normalizePhoto } from './photo.js'

import { existsSync, readFileSync, statSync } from 'node:fs'
import { mkdtemp, writeFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

const PLATFORM = getPlatform('telegram')

/**
 * ── Pacing knobs ─────────────────────────────────────────────────────────
 *
 * `burst` is what makes the bot feel instant: the first few sends in a chat
 * leave immediately (a reply, its follow-up line, the reward card — one turn),
 * and only once a chat has spent its burst does the queue fall back to the
 * conservative 1/second Telegram asks for. See lib/platform/send-queue.js.
 *
 * `interval` is the sustained rate AFTER the burst, deliberately close to
 * Telegram's documented ~1 message/second per chat. Lowering it via
 * TELEGRAM_SEND_INTERVAL_MS is supported for a bot whose groups are calm, but
 * a battle inside one group will start answering 429 — the number is a
 * trade-off, not a bug.
 */
function envNumber(name, fallback) {
  const raw = Number(process.env[name])
  return Number.isFinite(raw) && raw > 0 ? raw : fallback
}

export const DEFAULT_SEND_INTERVAL_MS = envNumber('TELEGRAM_SEND_INTERVAL_MS', 700)
export const DEFAULT_SEND_BURST = envNumber('TELEGRAM_SEND_BURST', 5)

/**
 * @param {object} opts
 * @param {import('grammy').Api} opts.api
 * @param {number} [opts.minIntervalMs]  per-chat pacing, once the burst is spent
 * @param {number} [opts.burst]          sends allowed immediately in one chat
 */
export function createTelegramSender({ api, minIntervalMs = DEFAULT_SEND_INTERVAL_MS, burst = DEFAULT_SEND_BURST }) {
  const queue = createChatQueue({ minIntervalMs, burst })

  /**
   * Run one API call through the chat's queue, honouring Telegram's own
   * `retry_after` for that chat on a 429. One retry only: a persistent 429
   * means something is wrong beyond pacing, and looping would stall the queue
   * for everyone in that group.
   */
  async function call(chatId, fn) {
    const attempt = () => queue.run(chatId, fn)
    try {
      return await attempt()
    } catch (err) {
      const wait = retryAfterMs(err)
      if (!wait) throw err
      queue.hold(chatId, wait)
      return attempt()
    }
  }

  /** Convert + chunk, dropping empty fragments. */
  function prepare(text) {
    const html = whatsappToHtml(text)
    return chunkTelegramHtml(html, PLATFORM.textLimit)
  }

  /**
   * Send text, split across as many messages as the 4,096 limit requires.
   * Returns the first sent message (or null when there was nothing to send).
   */
  async function sendText(chatId, text, { replyTo = null, disablePreview = false, previewUrl = null, buttons = null } = {}) {
    const pieces = prepare(text)
    let first = null

    for (const [i, piece] of pieces.entries()) {
      const extra = { parse_mode: 'HTML' }
      // Thread the reply target onto the first piece only: replying with every
      // chunk quotes the same message N times and looks like a bug.
      if (replyTo && i === 0) extra.reply_parameters = { message_id: replyTo, allow_sending_without_reply: true }
      // An explicit previewUrl is how replyCard degrades (WhatsApp's ad card has
      // no Telegram equivalent); otherwise honour disablePreview.
      if (previewUrl) extra.link_preview_options = { url: previewUrl, prefer_large_media: true }
      else if (disablePreview) extra.link_preview_options = { is_disabled: true }
      // Buttons ride the FIRST piece only: the rest are continuation text, and
      // a keyboard repeated per chunk is both wrong and unclickable.
      const markup = i === 0 ? replyMarkup(buttons) : null
      if (markup) extra.reply_markup = markup

      try {
        const sent = await call(chatId, () => api.sendMessage(chatId, piece, extra))
        if (!first) first = sent
      } catch (err) {
        // A rejected piece must never swallow the rest of the message, but it
        // must not be silent either: log with enough to reproduce.
        console.error(
          `[telegram] sendText failed chat=${chatId} piece=${i + 1}/${pieces.length}: ${err?.message ?? err}`,
        )
        if (!first) throw err
      }
    }
    return first
  }

/**
 * Media the bot links to, downloaded once for Telegram.
 *
 * Most of this game's artwork is referenced by URL (ImgBB banners, item art on
 * our own origin, cinematic backgrounds). Handing those URLs to the Bot API
 * means TELEGRAM has to fetch them, from Telegram's data centres, with no
 * referer and no user agent — and a host that blocks that (i.postimg.cc, some
 * Cloudflare setups) makes the Bot API reject the entire message with
 * "wrong file identifier/HTTP URL specified". The player loses the picture and,
 * on a caption path, sometimes the words with it.
 *
 * So we fetch it ourselves instead. Small media lives in an in-memory cache
 * for an hour (a 100 KB menu icon should not be re-downloaded on every tap).
 * Anything bigger is written to a temp directory, sent as a file, and DELETED
 * the moment the upload returns — that is the only case that touches disk, and
 * nothing survives it.
 *
 * ── Two things that make the picture actually arrive ─────────────────────
 *
 * 1. PHOTOS ARE NORMALISED (./photo.js). The shipped menu icon was a
 *    progressive JPEG; Telegram answered `IMAGE_PROCESS_FAILED` and the menu
 *    arrived with its caption and buttons but no art. Re-encoding to baseline
 *    happens here, on whichever path the bytes came from — a local file or a
 *    download — so no plugin author has to know to save their banner a
 *    particular way. See adapters/telegram/photo.js for the full story, and
 *    note that the re-encode no longer depends on any one native module: the
 *    shipped art is baseline to begin with, sharp handles the rest, and
 *    @napi-rs/canvas (already needed to draw every card) covers a host where
 *    sharp will not load. If Telegram refuses the result anyway, the photo is
 *    resent as a DOCUMENT — a method it never re-encodes — so the art is
 *    never lost outright. See isPhotoDecodeError() below.
 *
 * 2. A SENT PHOTO IS SENT AS A FILE ID THE SECOND TIME. Telegram echoes a
 *    `file_id` for every upload, and resending that id costs no upload and no
 *    download: the menu, the profile card and every chapter banner in a
 *    cinematic get visibly faster on their second appearance. The id is
 *    dropped the moment Telegram ever rejects it (a re-uploaded file, a
 *    different bot token), and the send falls back to the bytes.
 *
 * Never throws: on any failure the original URL/path is handed to Telegram
 * exactly as before, so a host we cannot reach either is no worse off.
 */
const MEDIA_CACHE_MS = 60 * 60_000
const MEDIA_CACHE_MAX_ENTRIES = 24
/** Above this, media goes to a temp file instead of sitting in memory. */
const MEDIA_INLINE_MAX = 2 * 1024 * 1024
const MEDIA_TIMEOUT_MS = 10_000

/** Bot API limits, with headroom: exceeding them is a hard rejection. */
const MEDIA_LIMIT_BYTES = {
  sendPhoto: 8 * 1024 * 1024,
  sendAnimation: 48 * 1024 * 1024,
  sendVideo: 48 * 1024 * 1024,
  sendDocument: 48 * 1024 * 1024,
  sendAudio: 48 * 1024 * 1024,
}
const MEDIA_LIMIT_DEFAULT = 48 * 1024 * 1024

const mediaCache = new Map()   // source key -> { payload, at }
const fileIdCache = new Map()  // `${method}:${source key}` -> Telegram file_id
/** Media methods whose responses carry a reusable file id. */
const FILE_ID_METHODS = new Set(['sendPhoto', 'sendDocument'])
/** chatId -> { at, detail } once a chat has refused a photo for lack of rights. */
const photoRightsBlocked = new Map()
/** How long a rights refusal is remembered before trying the photo again. */
const PHOTO_BLOCK_MS = 60_000
const warnedSources = new Set()

/** Telegram's own wording when a remembered file id is no longer valid. */
function isStaleFileIdError(err) {
  const message = String(err?.description ?? err?.message ?? '')
  return /wrong file identifier|file is not found|FILE_ID_INVALID|invalid file_id/i.test(message)
}

/**
 * Telegram's own wording when its image pipeline refuses a photo.
 *
 * These are 400s raised by Telegram *after* the bytes arrived and uploaded
 * fine: it decodes every photo to build its own sizes, and refuses a handful
 * of perfectly valid JPEG shapes on the way. Nothing the bot did is wrong and
 * resending the same bytes as a photo will fail identically, so the only
 * useful next move is to change the METHOD — see the document retry below.
 */
/**
 * Telegram's wording when the CHAT forbids media from this bot.
 *
 * Different from a decode refusal in every way that matters: retrying the same
 * bytes as a photo can never succeed, while the same bytes as a DOCUMENT may —
 * `can_send_photos` and `can_send_documents` are separate permission flags.
 */
function isPhotoRightsError(err) {
  const message = String(err?.description ?? err?.message ?? '')
  return /not enough rights to send (photos|media|pictures)|CHAT_SEND_PHOTOS_FORBIDDEN|CHAT_SEND_MEDIA_FORBIDDEN|have no rights to send a (photo|media)|CHAT_RESTRICTED/i.test(message)
}

function isPhotoDecodeError(err) {
  const message = String(err?.description ?? err?.message ?? '')
  return /IMAGE_PROCESS_FAILED|PHOTO_INVALID_DIMENSIONS|IMAGE_SIZE_INVALID|PHOTO_SAVE_FILE_INVALID/i.test(message)
}

function rememberMedia(key, payload) {
  mediaCache.set(key, { payload, at: Date.now() })
  while (mediaCache.size > MEDIA_CACHE_MAX_ENTRIES) {
    const oldest = mediaCache.keys().next().value
    mediaCache.delete(oldest)
  }
}

/** A guard, then the original source: never lose a message over a download. */
function handOverToTelegram(source, err) {
  if (!warnedSources.has(source)) {
    warnedSources.add(source)
    console.warn(
      `[telegram] could not prepare media, handing the source over: ${source} — ${err?.message ?? err}`,
    )
  }
  return { payload: source }
}

function extensionFor(source, method) {
  const fromPath = String(source).split('?')[0].match(/\.([a-z0-9]{2,5})$/i)?.[1]
  if (fromPath) return fromPath.toLowerCase()
  if (method === 'sendPhoto') return 'jpg'
  if (method === 'sendAnimation') return 'gif'
  if (method === 'sendAudio') return 'mp3'
  if (method === 'sendVideo') return 'mp4'
  return 'bin'
}

/**
 * Turn whatever a plugin passed as "an image" into bytes Telegram will accept.
 *
 * @returns {Promise<{buffer: Buffer}>} the (possibly re-encoded) bytes
 */
async function photoBytes(buffer, source) {
  const { buffer: out, changed, reason } = await normalizePhoto(buffer)
  if (changed) {
    console.log(`[telegram] re-encoded photo (${reason}) before upload: ${source}`)
  }
  return out
}

/**
 * @returns {Promise<{payload: any, source?: string, cleanup?: () => Promise<void>}>}
 *   `payload` is what the API call gets, `source` keys the file-id cache, and
 *   `cleanup` removes any temp file. The caller MUST await cleanup after send.
 */
async function prepareMedia(payloadIn, method) {
  if (payloadIn == null) return { payload: payloadIn }
  if (payloadIn instanceof InputFile) return { payload: payloadIn }
  if (Buffer.isBuffer(payloadIn)) {
    return {
      payload: method === 'sendPhoto' ? await photoBytes(payloadIn, 'buffer') : payloadIn,
    }
  }

  // A path on our own disk: the Bot API cannot open one, it wants bytes.
  // This is what makes the shipped menu artwork work at all.
  if (typeof payloadIn === 'string' && !/^https?:\/\//i.test(payloadIn)) {
    try {
      if (!existsSync(payloadIn)) return handOverToTelegram(payloadIn, new Error('file not found'))

      // Cached by path + mtime + size, so the re-encode happens once per
      // version of the file rather than once per menu tap, and dropping a
      // replacement icon in the repo still takes effect on the next restart.
      const stat = statSync(payloadIn)
      const source = `file:${payloadIn}:${stat.mtimeMs}:${stat.size}`
      const cached = mediaCache.get(source)
      if (cached && Date.now() - cached.at < MEDIA_CACHE_MS) {
        return { payload: cached.payload, source }
      }

      const raw = readFileSync(payloadIn)
      const payload = method === 'sendPhoto' ? await photoBytes(raw, payloadIn) : raw
      rememberMedia(source, payload)
      return { payload, source }
    } catch (err) {
      return handOverToTelegram(payloadIn, err)
    }
  }

  if (typeof payloadIn !== 'string') return { payload: payloadIn }

  const source = `url:${payloadIn}`
  const cached = mediaCache.get(source)
  if (cached && Date.now() - cached.at < MEDIA_CACHE_MS) {
    return { payload: cached.payload, source }
  }

  const limit = MEDIA_LIMIT_BYTES[method] ?? MEDIA_LIMIT_DEFAULT

  try {
    const res = await fetch(payloadIn, { signal: AbortSignal.timeout(MEDIA_TIMEOUT_MS) })
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    const declared = Number(res.headers.get('content-length') ?? 0)
    if (declared && declared > limit) throw new Error(`too large: ${declared} bytes`)
    let buf = Buffer.from(await res.arrayBuffer())
    if (buf.length > limit) throw new Error(`too large: ${buf.length} bytes`)

    if (method === 'sendPhoto') buf = await photoBytes(buf, payloadIn)

    if (buf.length <= MEDIA_INLINE_MAX) {
      rememberMedia(source, buf)
      return { payload: buf, source }
    }

    // Big media: a temp file, deleted by cleanup() as soon as the send returns.
    const dir = await mkdtemp(join(tmpdir(), 'astral-tg-'))
    const file = join(dir, `media.${extensionFor(payloadIn, method)}`)
    await writeFile(file, buf)
    return {
      payload: new InputFile(file),
      source,
      cleanup: () => rm(dir, { recursive: true, force: true }).catch(() => {}),
    }
  } catch (err) {
    return handOverToTelegram(payloadIn, err)
  }
}

  /**
   * Inline keyboard rows -> Bot API reply_markup.
   *
   * Each button's `data` is `c:<command>`, which the adapter's
   * callback_query:data handler already routes through runCommand — the same
   * path every other tappable thing in this bot uses, so a button can never
   * mean something the typed command does not.
   */
  function replyMarkup(rows) {
    if (!Array.isArray(rows) || !rows.length) return null
    const inline_keyboard = rows
      .map(row => row.filter(Boolean).map(btn => ({
        text: String(btn.text ?? '').slice(0, 64),
        callback_data: String(btn.data ?? '').slice(0, 64),
      })))
      .filter(row => row.length)
    return inline_keyboard.length ? { inline_keyboard } : null
  }

  /** Media with a caption, honouring Telegram's 1,024-char caption slot. */
  async function sendMedia(chatId, method, payloadIn, caption = '', { replyTo = null, buttons = null } = {}) {
    // ── Does this chat even allow photos? ─────────────────────────────────
    // A group can forbid media for a bot while allowing its text, and Telegram
    // then answers `not enough rights to send photos to the chat` — the exact
    // shape of "the banner shows in my DM and not in the group". Once a chat
    // has refused a photo, the next minute of sends go STRAIGHT to document
    // instead of paying for a call that cannot succeed. The block expires, so
    // fixing the permission in Telegram takes effect without a restart.
    let activeMethod = method
    const blocked = method === 'sendPhoto' ? photoRightsBlocked.get(chatId) : null
    if (blocked && Date.now() - blocked.at < PHOTO_BLOCK_MS) {
      activeMethod = 'sendDocument'
    }

    // Every media type, not just photos: .battle GIFs, cinematic videos and
    // documents hit the same "Telegram cannot fetch that URL" wall.
    const { payload, cleanup, source } = await prepareMedia(payloadIn, activeMethod)
    const [head, overflow] = splitCaption(whatsappToHtml(caption), PLATFORM.captionLimit)
    const extra = { parse_mode: 'HTML' }
    if (replyTo) extra.reply_parameters = { message_id: replyTo, allow_sending_without_reply: true }
    // Buttons ride on the first piece only: the overflow text below is a
    // separate message and Telegram would render a second, dead keyboard.
    const markup = replyMarkup(buttons)
    if (markup) extra.reply_markup = markup

    // A picture this bot has already uploaded once can go out as Telegram's own
    // file id: no download, no upload, no decode. Keyed by method+source so a
    // GIF and a still of the same URL never cross, and skipped for one-off
    // buffers (there is nothing stable to key them on). Documents are cached
    // too — that is the method a restricted group gets, and it should be as
    // cheap on the second /menu as the photo is in a DM.
    const fileIdKey = source && FILE_ID_METHODS.has(activeMethod) ? `${activeMethod}:${source}` : null
    const knownFileId = fileIdKey ? fileIdCache.get(fileIdKey) : null

    const uploadArg = () => {
      if (payload instanceof InputFile || typeof payload === 'string') return payload
      // An explicit filename, always: some Bot API deployments refuse a part
      // with no filename, and `photo.jpg` is what the API expects for photos.
      return new InputFile(payload, activeMethod === 'sendPhoto' ? 'photo.jpg' : undefined)
    }

    const sendWith = (asMethod) =>
      call(chatId, () =>
        api[asMethod](
          chatId,
          asMethod === activeMethod && knownFileId ? knownFileId : uploadArg(),
          head ? { ...extra, caption: head } : extra,
        ),
      )

    let sent
    let sentAs = activeMethod
    try {
      try {
        sent = await sendWith(activeMethod)
      } catch (err) {
        // The remembered id is the one thing here that can go stale (a
        // re-uploaded banner, a rotated bot token). Forget it and send the
        // bytes — once, so a genuine failure is not retried forever.
        if (knownFileId && isStaleFileIdError(err)) {
          fileIdCache.delete(fileIdKey)
          sent = await call(chatId, () => api[activeMethod](chatId, uploadArg(), head ? { ...extra, caption: head } : extra))
        } else {
          throw err
        }
      }
    } catch (err) {
      const detail = err?.description ?? err?.message ?? err
      const which = source ?? (Buffer.isBuffer(payload) ? `<buffer ${payload.length}b>` : typeof payload)
      const photoRefused = activeMethod === 'sendPhoto' && (isPhotoDecodeError(err) || isPhotoRightsError(err))

      // ── The last resort that still shows the picture ────────────────────
      // Two different refusals land here, and one answer covers both:
      //
      //   • the image pipeline would not DECODE the bytes (./photo.js already
      //     re-encoded them; there is nothing left to try as a photo), or
      //   • the CHAT does not let this bot post photos at all — a group whose
      //     "Send Photos" is off for members, or a bot an admin restricted to
      //     text. Text is unaffected, which is why the symptom reads as "the
      //     picture is missing in the group but fine in my DM".
      //
      // A DOCUMENT is a different permission AND is never re-encoded, so the
      // same bytes usually go through: the menu arrives as a file bubble with
      // the art visible. `sendDocument` is tried even when the photo failed on
      // rights, because `can_send_documents` is a separate Telegram flag.
      //
      // The temp file from prepareMedia() is still on disk here: cleanup runs
      // in the finally below, after this retry.
      if (photoRefused) {
        const why = isPhotoRightsError(err)
          ? 'this chat does not allow me to send photos (enable "Send Photos" for members, or make me an admin)'
          : 'Telegram refused to decode the photo'
        console.warn(
          `[telegram] sendPhoto failed chat=${chatId} source=${which}: ${detail} — ${why}; resending as a document`,
        )
        if (isPhotoRightsError(err)) photoRightsBlocked.set(chatId, { at: Date.now(), detail })

        sent = await call(chatId, () =>
          api.sendDocument(chatId, uploadArg(), head ? { ...extra, caption: head } : extra),
        )
        sentAs = 'sendDocument'
      } else {
        // Say WHICH picture and WHICH API complaint. Without this the only
        // trace of a rejected upload is the caller's generic "retrying
        // without art", which is how a broken menu icon went unexplained
        // for a release.
        console.error(`[telegram] ${activeMethod} failed chat=${chatId} source=${which}: ${detail}`)
        throw err
      }
    } finally {
      // The temp directory from prepareMedia() does not outlive the upload,
      // whether the send succeeded, threw, or was rate-limited and retried.
      await cleanup?.()
    }

    // Remember what Telegram called this picture, for the next send. Cached
    // under the method that actually carried it, so a group that only accepts
    // documents gets the document id back while a DM keeps using the photo id.
    const uploadedId = Array.isArray(sent?.photo) && sent.photo.length
      ? sent.photo[sent.photo.length - 1].file_id
      : sent?.document?.file_id ?? null
    const cacheKeyFor = source && FILE_ID_METHODS.has(sentAs) ? `${sentAs}:${source}` : null
    if (cacheKeyFor && uploadedId) fileIdCache.set(cacheKeyFor, uploadedId)

    // Never silently drop the rest of a caption.
    if (overflow.trim()) await sendText(chatId, overflow)
    return sent
  }

  return {
    api,
    queue,
    sendText,
    sendPhoto: (chatId, image, caption, opts) => sendMedia(chatId, 'sendPhoto', image, caption, opts),
    /** Photo with a caption AND an inline keyboard — Telegram's native menu shape. */
    sendPhotoButtons: (chatId, image, caption, buttons, opts) =>
      sendMedia(chatId, 'sendPhoto', image, caption, { ...(opts ?? {}), buttons }),
    // Telegram: a real sendAnimation. sendPhoto would render a GIF's first
    // frame only — the same trap lib/image.js:558 documents.
    sendAnimation: (chatId, image, caption, opts) => sendMedia(chatId, 'sendAnimation', image, caption, opts),
    sendDocument: (chatId, file, caption, opts) => sendMedia(chatId, 'sendDocument', file, caption, opts),
    sendAudio: (chatId, file, caption, opts) => {
      const extra = opts ?? {}
      return sendMedia(chatId, 'sendAudio', file, caption, extra)
    },
    /** Edit a message this bot sent. Fails by design after 48h — callers tolerate it. */
    editText: (chatId, messageId, text) =>
      call(chatId, () =>
        api.editMessageText(chatId, messageId, chunkTelegramHtml(whatsappToHtml(String(text ?? '')), PLATFORM.textLimit - 64)[0] ?? ' '),
      ),
    /**
     * Replace the PICTURE of a message the bot already sent, caption and
     * keyboard included.
     *
     * This is what makes a fight (or a shop, or any multi-step screen) a
     * single message that changes instead of a waterfall of new ones: Telegram
     * edits the media in place, the bubble keeps its position in the chat, and
     * there is no notification per turn.
     *
     * The API only takes a file_id, a URL, or a fresh upload here — never a
     * local path — so the bytes go through prepareMedia() exactly as a new
     * send would.
     */
    editMedia: async (chatId, messageId, method, payloadIn, caption = '', { buttons = null } = {}) => {
      const type = method === 'sendAnimation' ? 'animation' : 'photo'
      const { payload, cleanup, source } = await prepareMedia(payloadIn, method)
      const [head, overflow] = splitCaption(whatsappToHtml(caption), PLATFORM.captionLimit)

      const media = {
        type,
        media:
          payload instanceof InputFile || typeof payload === 'string'
            ? payload
            : new InputFile(payload, type === 'photo' ? 'photo.jpg' : undefined),
      }
      if (head) {
        media.caption = head
        media.parse_mode = 'HTML'
      }

      const extra = {}
      const markup = replyMarkup(buttons)
      if (markup) extra.reply_markup = markup

      try {
        const edited = await call(chatId, () => api.editMessageMedia(chatId, messageId, media, extra))
        // A caption that does not fit the 1,024 slot still has to be readable;
        // this mirrors sendMedia()'s overflow rule rather than truncating it.
        if (overflow.trim()) await sendText(chatId, overflow)
        return edited
      } catch (err) {
        console.error(
          `[telegram] editMedia failed chat=${chatId} message=${messageId} source=${source ?? typeof payload}: ${
            err?.description ?? err?.message ?? err
          }`,
        )
        throw err
      } finally {
        await cleanup?.()
      }
    },

    /** Swap the inline keyboard of a message without touching its picture. */
    editButtons: (chatId, messageId, buttons) => {
      const markup = replyMarkup(buttons) ?? { inline_keyboard: [] }
      return call(chatId, () => api.editMessageReplyMarkup(chatId, messageId, { reply_markup: markup }))
    },

    /** Drop a used inline keyboard so a stale tap can't double-fire a flow. */
    clearKeyboard: (chatId, messageId) =>
      call(chatId, () => api.editMessageReplyMarkup(chatId, messageId, { reply_markup: { inline_keyboard: [] } })),
  }
}

/**
 * Resolve a Telegram file_id to bytes.
 *
 * Bot API caps downloads at 20 MB, and the HTTP path embeds the token — this is
 * the only place that should ever build it.
 */
export async function downloadTelegramFile(api, fileId, { maxBytes = 12 * 1024 * 1024 } = {}) {
  const file = await api.getFile(fileId)
  if (!file?.file_path) throw new Error('Telegram getFile returned no file_path')
  if (Number(file.file_size) > maxBytes) {
    throw new Error(`File too large: ${Math.round(file.file_size / 1048576)} MB`)
  }
  const url = `https://api.telegram.org/file/bot${config.telegramToken}/${file.file_path}`
  const res = await fetch(url)
  if (!res.ok) throw new Error(`Telegram file download failed: HTTP ${res.status}`)
  return Buffer.from(await res.arrayBuffer())
}
