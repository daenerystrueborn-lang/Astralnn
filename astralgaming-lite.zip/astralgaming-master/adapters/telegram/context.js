/**
 * context.js — turn a grammY update into the ctx every plugin already expects.
 *
 * The contract is handler.js:1103 (the WhatsApp ctx). Anything a plugin reads
 * from ctx on WhatsApp must exist here with the same meaning, or a command
 * that works there dies here with "Cannot read properties of undefined".
 *
 * The two identity rules that keep one human as one character:
 *
 *   platformId  'tg:847362…'  — this Telegram account, namespaced
 *                              (lib/platform/identity.js)
 *   from        resolveLinkedId(platformId)
 *                              — the WhatsApp character it's linked to, or the
 *                                platform id itself when there's no link. The
 *                                alias is resolved HERE, in the adapter,
 *                                exactly as lib/account-link.js prescribes, so
 *                                no game plugin has to know links exist.
 *
 * `sender` is the CHAT id, not the user id — pipeline.js passes it to
 * getGroupSettings(), where `tg:-100123…` simply becomes its own settings key.
 */
import { config } from '../../config.js'
import { resolveLinkedId } from '../../lib/account-link.js'
import { toPlayerId, toNativeId } from '../../lib/platform/identity.js'
import { isChatAdminNative, botRights, kickMember } from '../../lib/telegram-moderation.js'
import { downloadTelegramFile } from './send.js'

/** The 20 MB Bot API download limit, less headroom. Avatars and screenshots fit. */
const MAX_ATTACHMENT_BYTES = 12 * 1024 * 1024

/** Photo sizes are ascending; the last one is the largest Telegram kept. */
function pickAttachment(message) {
  if (!message) return null
  if (Array.isArray(message.photo) && message.photo.length) {
    return { fileId: message.photo[message.photo.length - 1].file_id, kind: 'photo' }
  }
  if (message.document) return { fileId: message.document.file_id, kind: 'document' }
  if (message.video) return { fileId: message.video.file_id, kind: 'video' }
  if (message.animation) return { fileId: message.animation.file_id, kind: 'animation' }
  return null
}

/** Text of a message, whatever kind it arrived as. */
export function messageText(message) {
  if (!message) return ''
  return message.text ?? message.caption ?? ''
}

/**
 * A WhatsApp-shaped `sock` facade for the 21 plugins that still reach for it
 * (auction, guild, party, premium…). Deliberately minimal: it exists so those
 * plugins run unchanged on day one, NOT as the long-term API. New code should
 * use ctx.reply / ctx.sendTo. `interactiveMessages` stays false so
 * lib/interactive-buttons.js keeps refusing to build WhatsApp cards here.
 */
function buildSockFacade({ bot, sender, senderApi }) {
  const chatId = (jid) => toNativeId(String(jid ?? ''))

  return {
    user: { id: bot.botInfo?.id ?? null },
    interactiveMessages: false,

    async sendMessage(jid, content = {}, _options = {}) {
      const target = chatId(jid) || chatId(sender)
      if (content.text) return senderApi.sendText(target, content.text)
      if (content.image) return senderApi.sendPhoto(target, content.image, content.caption ?? '')
      if (content.video) return senderApi.sendAnimation(target, content.video, content.caption ?? '')
      if (content.audio) return senderApi.sendAudio(target, content.audio, content.caption ?? '')
      if (content.document) return senderApi.sendDocument(target, content.document, content.caption ?? '')
      if (content.caption) return senderApi.sendText(target, content.caption)
      return null
    },

    /** `getChat` + `getChatAdministrators` in Baileys' metadata shape. */
    async groupMetadata(jid) {
      const target = chatId(jid) || chatId(sender)
      const [chat, admins] = await Promise.all([
        bot.api.getChat(target),
        bot.api.getChatAdministrators(target).catch(() => []),
      ])
      const adminIds = new Set(admins.map(a => String(a.user.id)))
      return {
        id: target,
        subject: chat.title ?? '',
        desc: chat.description ?? '',
        participants: admins.map(a => ({
          id: toPlayerId('telegram', a.user.id),
          admin: a.status === 'creator' ? 'superadmin' : 'admin',
        })),
        // Count only — Telegram never hands over the full member list.
        size: chat.member_count ?? adminIds.size,
      }
    },

    async groupParticipantsUpdate(jid, ids, action) {
      const target = chatId(jid) || chatId(sender)
      for (const id of ids ?? []) {
        const userId = toNativeId(String(id))
        // 'remove' means kick, not ban: Telegram's only removal is a ban, so
        // lib/telegram-moderation.js bans then unbans. Leaving a bare
        // banChatMember here would silently make every `.kick` permanent.
        if (action === 'remove') await kickMember(bot.api, target, userId)
        if (action === 'add') await bot.api.unbanChatMember(target, userId, { only_if_banned: true })
      }
      return true
    },
  }
}

/**
 * @param {object} deps
 * @param {object} deps.db
 * @param {import('grammy').Bot} deps.bot
 * @param {object} deps.sender  output of createTelegramSender()
 */
/**
 * ── One message per fight ──────────────────────────────────────────────────
 *
 * A turn-based fight renders a new frame every turn. Sent as new messages that
 * is a waterfall: the chat jumps, every turn buzzes a notification, and a long
 * boss fight leaves thirty pictures nobody scrolls back through. Telegram can
 * EDIT a message's media, so the same fight can be ONE bubble that changes.
 *
 * The registry below remembers which message belongs to which fight:
 *   key = `${chatId}:${playerId}`  →  { messageId, method, at }
 *
 * It is deliberately in memory, not the database: losing it costs exactly one
 * extra message (the next turn sends a new screen), while writing it on every
 * turn would put a Mongo round trip in front of every attack.
 */
const battleScreens = new Map()
/** A screen untouched for this long is treated as finished. */
const SCREEN_IDLE_MS = 15 * 60_000
const SCREEN_MAX_ENTRIES = 500

function screenKey(chatId, playerId) {
  return `${chatId}:${playerId}`
}

function rememberScreen(key, value) {
  battleScreens.set(key, { ...value, at: Date.now() })
  while (battleScreens.size > SCREEN_MAX_ENTRIES) {
    battleScreens.delete(battleScreens.keys().next().value)
  }
}

/** Forget the fight in this chat (the caller knows it is over). */
export function endBattleScreen(chatId, playerId) {
  battleScreens.delete(screenKey(chatId, playerId))
}

/**
 * Which keyboard row the live card is showing: 'default' or 'skills'.
 *
 * Kept here rather than in the caller because it must SURVIVE a turn: a player
 * who opens the skill picker and casts one skill expects the picker to still be
 * there on the next frame, not to snap back to attack/defend.
 */
export function setBattleScreenRow(chatId, playerId, mode) {
  const key = screenKey(chatId, playerId)
  const current = battleScreens.get(key)
  if (current) battleScreens.set(key, { ...current, mode, at: Date.now() })
  else battleScreens.set(key, { mode, at: Date.now() })
}

/** The current row for this chat, or 'default'. */
export function battleScreenRowMode(chatId, playerId) {
  return battleScreens.get(screenKey(chatId, playerId))?.mode === 'skills' ? 'skills' : 'default'
}

/** True when this message IS the live battle screen (keyboards must survive). */
export function isBattleScreenMessage(chatId, messageId) {
  for (const [key, value] of battleScreens) {
    if (value.messageId === messageId && key.startsWith(`${chatId}:`)) return true
  }
  return false
}

export function createContextFactory({ db, bot, sender }) {
  return function buildContext(tctx, { cmd, args, body, prefix }) {
    const message = tctx.message ?? tctx.editedMessage ?? tctx.callbackQuery?.message
    const chat = message?.chat ?? tctx.chat
    const user = tctx.from ?? tctx.callbackQuery?.from

    const isGroup = chat.type === 'group' || chat.type === 'supergroup'
    const platformId = toPlayerId('telegram', user.id)
    const from = resolveLinkedId(db, platformId)
    const chatPlayerId = toPlayerId('telegram', chat.id)

    const attachment = pickAttachment(message)

    return {
      // ── identity ────────────────────────────────────────────────────────
      platform: 'telegram',
      platformId,          // this Telegram account, unlinked ('tg:…')
      /**
       * The name Telegram shows for this person.
       *
       * WhatsApp hands the handler `msg.pushName`, and plugins/register.js
       * uses it to name a new character without asking. Telegram has no such
       * field on the update, so without this the guided `/register` flow in a
       * DM always fell through to "type your name" — a dead end, because a
       * bare name is not a command and the adapter (rightly) ignores
       * non-commands. Same field, same meaning, whatever platform fills it.
       */
      pushName: ([user.first_name, user.last_name].filter(Boolean).join(' ') || user.username || '').trim(),
      from,                // character id plugins key on
      sender: chatPlayerId, // chat id — group settings are keyed on this
      isGroup,
      JID: chatPlayerId,   // legacy alias some plugins read
      botName: config.telegramBotName,
      prefix,

      // ── message ─────────────────────────────────────────────────────────
      cmd,
      args,
      body,
      message,             // grammY message — extractTarget() reads this
      msg: message,        // mirror, so legacy extractTarget(ctx.msg) works
      bot,                 // lib/image.js / walk.js expect ctx.bot.api
      chat,
      chatTitle: chat.title ?? chat.username ?? '',
      replyTo: message?.reply_to_message ?? null,

      // ── db handle (runCommand fills player/playerId/save) ───────────────
      db,

      // ── messaging ───────────────────────────────────────────────────────
      reply: (text) =>
        sender.sendText(chat.id, String(text ?? ''), { replyTo: message?.message_id }),

      editReply: (sent, text) =>
        sent?.message_id
          ? sender.editText(chat.id, sent.message_id, String(text ?? ''))
          : sender.sendText(chat.id, String(text ?? '')),

      /**
       * A text message that carries an inline keyboard.
       *
       * Telegram's own idiom for "here is the situation, choose": a PvP
       * challenge that arrives with ✅ Accept / ❌ Decline under it is one tap,
       * and a tap is just `c:pvp accept` — the same command a player would
       * type, so the button cannot mean anything else.
       */
      replyWithButtons: (text, buttons) =>
        sender.sendText(chat.id, String(text ?? ''), { replyTo: message?.message_id, buttons }),

      replyImage: (image, caption = '') => sender.sendPhoto(chat.id, image, String(caption ?? '')),

      /**
       * A picture with a caption AND an inline keyboard — the shape every
       * "look at this, now choose" screen wants (a shop page with ◀ ▶, a wild
       * card with a Catch button). Falls back to the plain photo on a platform
       * or sender that cannot carry a keyboard, so callers never branch.
       */
      replyImageButtons: (image, caption = '', buttons = null) =>
        typeof sender.sendPhotoButtons === 'function' && Array.isArray(buttons) && buttons.length
          ? sender.sendPhotoButtons(chat.id, image, String(caption ?? ''), buttons)
          : sender.sendPhoto(chat.id, image, String(caption ?? '')),

      /**
       * Photo + caption + tappable sections. Telegram's own menu idiom, and
       * the reason its menu does not have to look like WhatsApp's: a section
       * is one tap instead of `/menu Adventurer` typed out.
       *
       * Falls back to a plain photo, then to plain text, rather than losing
       * the menu because one CDN would not serve the banner.
       */
      replyPhotoButtons: async (image, caption = '', buttons = []) => {
        try {
          return await sender.sendPhotoButtons(chat.id, image, String(caption ?? ''), buttons)
        } catch (err) {
          console.error(`[telegram] menu photo+buttons failed, retrying without art: ${err?.message ?? err}`)
          try {
            return await sender.sendPhoto(chat.id, image, String(caption ?? ''))
          } catch (err2) {
            console.error(`[telegram] menu photo failed, sending text only: ${err2?.message ?? err2}`)
            return sender.sendText(chat.id, String(caption ?? ''), { replyTo: message?.message_id })
          }
        }
      },

      /**
       * The LIVE battle screen: one message per fight, edited each turn.
       *
       * First frame (or a new fight, or a GIF after stills) is a normal send;
       * every later turn replaces the picture, the caption and the action
       * buttons of the message that is already there. The chat stays still,
       * nothing buzzes twice, and the fight reads like a console screen.
       *
       * Failure is graceful in both directions: an edit Telegram refuses (the
       * message was deleted, or is too old to edit) falls back to sending a
       * fresh screen, and a chat that cannot take photos at all falls through
       * to the sender's own document fallback — see send.js.
       *
       * @param {object} frame
       * @param {Buffer|string} frame.image  rendered turn frame
       * @param {'photo'|'gif'} [frame.kind]
       * @param {string} frame.caption       the turn text, markdown-ish as usual
       * @param {Array} [frame.buttons]      [[{ text, data }]] action keyboard
       * @param {boolean} [frame.fresh]      force a new message (fight start)
       */
      battleScreen: async ({ image, kind = 'photo', caption = '', buttons = null, fresh = false } = {}) => {
        const key = screenKey(chat.id, from)
        const method = kind === 'gif' ? 'sendAnimation' : 'sendPhoto'
        const previous = battleScreens.get(key)
        const stale = previous && Date.now() - previous.at > SCREEN_IDLE_MS
        const canEdit =
          !fresh &&
          !stale &&
          previous &&
          previous.method === method &&
          typeof sender.editMedia === 'function'

        // The pad keeps whichever row is open (see setBattleScreenRow).
        const sendFresh = async () => {
          const sent =
            method === 'sendAnimation'
              ? await sender.sendAnimation(chat.id, image, String(caption ?? ''), { buttons })
              : await sender.sendPhotoButtons(chat.id, image, String(caption ?? ''), buttons)
          if (sent?.message_id) {
            rememberScreen(key, { messageId: sent.message_id, method, mode: previous?.mode ?? 'default' })
          }
          return sent
        }

        if (canEdit) {
          try {
            const edited = await sender.editMedia(
              chat.id,
              previous.messageId,
              method,
              image,
              String(caption ?? ''),
              { buttons },
            )
            rememberScreen(key, { messageId: previous.messageId, method, mode: previous.mode ?? 'default' })
            return edited
          } catch {
            // The message is gone or too old to edit: fall through to a new
            // screen rather than losing the turn.
            battleScreens.delete(key)
          }
        }

        return sendFresh()
      },

      /** 'default' or 'skills' — which pad row the live card should show. */
      battleRowMode: () => battleScreenRowMode(chat.id, from),

      replyGif: (image, caption = '') => sender.sendAnimation(chat.id, image, String(caption ?? '')),

      /**
       * WhatsApp's external-ad card has no Telegram equivalent, and the
       * `linkPreviewCard` capability is deliberately absent from the Telegram
       * descriptor. Degrade honestly: the words always send, with the source
       * URL attached as a large preview when there is one.
       */
      replyCard: ({ text = '', title = '', body = '', thumbnailUrl, sourceUrl } = {}) => {
        const composed = [title && `*${title}*`, body, text].filter(Boolean).join('\n\n')
        return sender.sendText(chat.id, composed || String(sourceUrl ?? ''), {
          replyTo: message?.message_id,
          previewUrl: sourceUrl || undefined,
        })
      },

      /** Image the player sent (or quoted). Buffer or null — never throws. */
      getAttachment: async () => {
        const target = attachment ?? pickAttachment(message?.reply_to_message)
        if (!target) return null
        try {
          return await downloadTelegramFile(bot.api, target.fileId, { maxBytes: MAX_ATTACHMENT_BYTES })
        } catch (err) {
          console.error(`[telegram] attachment download failed: ${err?.message ?? err}`)
          return null
        }
      },

      // ── permissions (lib/platform/permissions.js calls these) ───────────
      //
      // Both go through lib/telegram-moderation.js's short-TTL cache. These are
      // asked by ~30 admin-gated commands, and macOS-fast or not, a
      // `getChatMember` round trip before every one of them is exactly the
      // "Telegram feels slower than WhatsApp" complaint. 60 seconds of
      // staleness costs at most one refused API call; it never grants access
      // (a failed lookup returns false, never true).
      isChatAdmin: async () => {
        if (!isGroup) return false
        return isChatAdminNative(bot.api, chat.id, user.id)
      },

      isBotAdmin: async () => {
        if (!isGroup || !bot.botInfo?.id) return false
        const rights = await botRights(bot.api, chat.id, bot.botInfo.id)
        return rights.isAdmin
      },

      /** Raw Bot API for the Telegram moderation plugins (delete/kick/mute). */
      api: bot.api,

      // ── compatibility bridge (see the header) ───────────────────────────
      sock: buildSockFacade({ bot, sender: chatPlayerId, senderApi: sender }),
    }
  }
}
