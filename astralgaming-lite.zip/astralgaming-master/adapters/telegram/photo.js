/**
 * photo.js — make sure the bytes we hand to `sendPhoto` are bytes Telegram
 * can actually decode.
 *
 * ── The bug this file exists for ─────────────────────────────────────────
 * `.menu` on Telegram arrived with its caption and its section buttons but
 * with no picture above them. Nothing in the bot was wrong: the bot uploaded
 * `lib/assets/ui/telegram-menu.jpg` (61 KB, 736×736) exactly as it found it,
 * and the Bot API answered `400 Bad Request: IMAGE_PROCESS_FAILED` — Telegram
 * could not decode that particular JPEG. `ctx.replyPhotoButtons()` then did
 * what it promises (retry without the keyboard, then fall back to text), so
 * the player got a menu with no art and the log got one line nobody was
 * watching.
 *
 * The file was a **progressive** JPEG. Telegram's photo pipeline re-encodes
 * every upload to its own sizes and rejects a handful of perfectly valid
 * JPEG variants on the way (progressive scans, CMYK colour, odd ICC profiles,
 * absurd dimensions). It is not documented, it is not stable, and it is not
 * something a plugin author can know about the day they drop a new banner in
 * the repo. So the fix belongs here, once: decode and re-encode every photo
 * to a plain **baseline, sRGB, 4:2:0 JPEG**, stripped of EXIF, sized inside
 * Telegram's documented limits. What leaves this module is what every phone
 * on earth produces, i.e. the one shape Telegram has never refused.
 *
 * ── Why this is not "always recompress everything" ───────────────────────
 * Re-encoding costs CPU and a little quality, so a photo that is already
 * baseline sRGB and inside the limits is passed through untouched. Only the
 * shapes that are known to fail (progressive, CMYK, > 2560px, > 4.5 MB) are
 * rewritten — which for this bot's shipped art means the menu icon, and for
 * ImgBB banners means nothing at all.
 *
 * ── Sharp is optional, and it is not the only encoder ────────────────────
 * `sharp` is a native module. If it is missing or fails to load (a slim
 * deploy, an `npm ci --omit=optional` host where the platform prebuild is
 * gone, a base image whose glibc is too old), "degrade to the original bytes"
 * is NOT an acceptable answer: the original bytes here are precisely the
 * ones Telegram refuses, so the menu loses its picture and the only trace is
 * one warning line. That is what happened in the field.
 *
 * So there are three independent layers:
 *   1. the shipped art is already baseline (`lib/assets/ui/telegram-menu.jpg`),
 *      so the common case needs no encoder at all;
 *   2. `@napi-rs/canvas`, a dependency the bot already loads for every card it
 *      draws, decodes and re-encodes when sharp cannot — Skia's JPEG encoder
 *      only ever writes baseline, which is exactly what we want;
 *   3. send.js retries a refused photo as a document, which Telegram never
 *      re-encodes, so the art still reaches the chat.
 *
 * The metadata questions below are answered in PURE JAVASCRIPT for JPEGs
 * (marker walk, ~40 lines) so "does this need rewriting?" never depends on a
 * native module either.
 */

/** Telegram rejects photos whose sides sum above this (documented). */
const MAX_SIDE_SUM = 10_000
/** Our own cap: a menu banner does not need to be 4000px wide. */
const MAX_SIDE = 2_560
/** Re-encode above this; Telegram's hard photo limit is 10 MB. */
const MAX_BYTES = 4.5 * 1024 * 1024
/** Telegram rejects a photo whose width/height ratio exceeds 20 (documented). */
const MAX_ASPECT = 20
const JPEG_QUALITY = 88

/** Formats `sendPhoto` understands natively. Anything else is left alone. */
const PHOTO_FORMATS = new Set(['jpeg', 'png', 'webp'])

let sharpPromise = null

/**
 * Load sharp once. Returns null when it cannot be loaded — callers treat that
 * as "no normalisation available" rather than an error.
 */
async function loadSharp() {
  if (!sharpPromise) {
    sharpPromise = import('sharp')
      .then((mod) => mod.default ?? mod)
      .catch((err) => {
        console.warn(`[telegram] sharp unavailable, photos will use the canvas encoder: ${err?.message ?? err}`)
        return null
      })
  }
  return sharpPromise
}

let canvasPromise = null

/**
 * Load @napi-rs/canvas once — the fallback encoder.
 *
 * It is a real dependency of this bot (every rendered card, profile image and
 * title glyph goes through it), so it is present on any host that can draw a
 * battle card. Returns null if even that cannot load, and callers then fall
 * back to sending the original bytes.
 */
async function loadCanvas() {
  if (!canvasPromise) {
    canvasPromise = import('@napi-rs/canvas')
      .then((mod) => mod)
      .catch((err) => {
        console.warn(`[telegram] canvas unavailable, sending photos as-is: ${err?.message ?? err}`)
        return null
      })
  }
  return canvasPromise
}

/** Content sniffing, so a Buffer that is not an image is never handed to sharp. */
function sniffFormat(buf) {
  if (!Buffer.isBuffer(buf) || buf.length < 12) return null
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'jpeg'
  if (buf.slice(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png'
  if (buf.slice(0, 4).toString('ascii') === 'RIFF' && buf.slice(8, 12).toString('ascii') === 'WEBP') return 'webp'
  if (buf.slice(0, 6).toString('ascii') === 'GIF87a' || buf.slice(0, 6).toString('ascii') === 'GIF89a') return 'gif'
  return null
}

/**
 * Read a JPEG's shape WITHOUT any native module.
 *
 * Walks the segment markers to the frame header and answers the only three
 * questions photoRejectionReason() needs: how big is it, is it progressive,
 * and does it carry an Adobe/CMYK segment. Anything it cannot answer comes
 * back as 0 / false, which callers read as "nothing known to be wrong".
 *
 * Exported so tests and scripts/check-runtime.mjs can check a shipped banner
 * against Telegram's limits on any machine, with no image library installed.
 *
 * @param {Buffer} buf
 * @returns {{format: string, width: number, height: number, isProgressive: boolean, adobe: boolean}|null}
 *   null when this is not a JPEG (callers should then leave it alone).
 */
export function jpegInfo(buf) {
  if (!Buffer.isBuffer(buf) || sniffFormat(buf) !== 'jpeg') return null

  const info = {
    format: 'jpeg',
    width: 0,
    height: 0,
    isProgressive: false,
    adobe: buf.includes('Adobe'),
  }

  let off = 2 // past SOI
  while (off + 3 < buf.length) {
    if (buf[off] !== 0xff) { off += 1; continue }
    const marker = buf[off + 1]
    // Fill bytes, standalone markers (SOI/EOI/RSTn/TEM) carry no length.
    if (marker === 0xff) { off += 1; continue }
    if (marker === 0xd8 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) { off += 2; continue }
    if (marker === 0xd9) break

    const len = buf.readUInt16BE(off + 2)
    if (len < 2) break

    // SOF0..SOF15, minus DHT(C4) / JPG(C8) / DAC(CC), which share the range.
    const isFrame = marker >= 0xc0 && marker <= 0xcf
      && marker !== 0xc4 && marker !== 0xc8 && marker !== 0xcc
    if (isFrame) {
      info.height = buf.readUInt16BE(off + 5)
      info.width = buf.readUInt16BE(off + 7)
      // C2/C6/CA/CE are the progressive frames.
      info.isProgressive = marker === 0xc2 || marker === 0xc6 || marker === 0xca || marker === 0xce
      return info
    }
    off += 2 + len
  }
  return info
}

/**
 * Sharp-shaped metadata for a buffer, from whichever source can supply it.
 *
 * sharp is authoritative when it is installed (it knows PNG/WebP too). Without
 * it, a JPEG is still fully understood by jpegInfo(); anything else returns
 * null, i.e. "no reason to touch these bytes".
 */
async function readMetadata(buf, sharp) {
  if (sharp) {
    try {
      return await sharp(buf).metadata()
    } catch (err) {
      console.warn(`[telegram] photo metadata unreadable, sending as-is: ${err?.message ?? err}`)
      return null
    }
  }
  return jpegInfo(buf)
}

/**
 * Does this photo need rewriting before upload?
 *
 * Exported so tests (and `/guard`-style diagnostics) can answer the question
 * without re-encoding anything.
 *
 * @param {object} meta  sharp metadata
 * @param {number} bytes
 * @returns {string|null} the reason, or null when the photo is fine as-is
 */
export function photoRejectionReason(meta, bytes) {
  if (!meta) return 'unreadable image'
  if (!PHOTO_FORMATS.has(meta.format)) return `unsupported format ${meta.format}`
  if (meta.space && meta.space !== 'srgb' && meta.space !== 'b-w') return `colour space ${meta.space}`
  if (meta.format === 'jpeg' && meta.isProgressive) return 'progressive JPEG'
  const w = Number(meta.width) || 0
  const h = Number(meta.height) || 0
  if (!w || !h) return 'unknown dimensions'
  if (w > MAX_SIDE || h > MAX_SIDE) return `oversized ${w}x${h}`
  if (w + h > MAX_SIDE_SUM) return `dimensions over Telegram's limit ${w}x${h}`
  if (Math.max(w, h) / Math.min(w, h) > MAX_ASPECT) return `aspect ratio over Telegram's ${MAX_ASPECT}:1 (${w}x${h})`
  if (Number(bytes) > MAX_BYTES) return `file too large (${Math.round(bytes / 1024)} KB)`
  return null
}

/**
 * The exact box a photo has to fit in, computed from its source size.
 *
 * Three of Telegram's documented rules in one place: no side over our own
 * 2,560 cap, width + height under 10,000 (implied), and a width/height ratio
 * of at most 20:1. The ratio is satisfied by PADDING the short side, never by
 * cropping — a 3000x100 banner keeps every pixel it had and gains white
 * margin, which is a far better outcome than a refused photo.
 *
 * @returns {{width: number, height: number, padded: boolean}}
 */
export function telegramBox(srcWidth, srcHeight) {
  const w = Number(srcWidth) || 0
  const h = Number(srcHeight) || 0
  if (!w || !h) return { width: MAX_SIDE, height: MAX_SIDE, padded: false }

  const scale = Math.min(1, MAX_SIDE / Math.max(w, h))
  let width = Math.max(1, Math.round(w * scale))
  let height = Math.max(1, Math.round(h * scale))

  let padded = false
  if (width / height > MAX_ASPECT) {
    height = Math.ceil(width / MAX_ASPECT)
    padded = true
  } else if (height / width > MAX_ASPECT) {
    width = Math.ceil(height / MAX_ASPECT)
    padded = true
  }
  return { width, height, padded }
}

/**
 * Re-encode via sharp: baseline, sRGB, 4:2:0, EXIF stripped and orientated.
 * @returns {Promise<Buffer|null>} null when sharp is absent or refused.
 */
async function reencodeWithSharp(sharp, input, meta) {
  if (!sharp) return null
  try {
    // The box that satisfies all of Telegram's dimension rules at once.
    const box = telegramBox(meta?.width, meta?.height)
    const out = await sharp(input)
      // Bake EXIF orientation into the pixels: Telegram ignores the EXIF tag,
      // so a phone screenshot tagged "rotate 90" would arrive sideways.
      .rotate()
      // `contain` letterboxes into the exact box, which is what pads an
      // over-wide banner out to Telegram's 20:1 rule instead of cropping it.
      .resize({
        width: box.width,
        height: box.height,
        fit: 'contain',
        background: '#ffffff',
        withoutEnlargement: true,
      })
      .jpeg({
        quality: JPEG_QUALITY,
        // The whole point of the module: baseline, never progressive.
        progressive: false,
        // Strip EXIF/ICC: Telegram re-encodes anyway, and a stray CMYK ICC
        // profile is one of the shapes that gets rejected.
        chromaSubsampling: '4:2:0',
      })
      .toBuffer()
    return out?.length ? out : null
  } catch (err) {
    console.warn(`[telegram] sharp re-encode failed: ${err?.message ?? err}`)
    return null
  }
}

/**
 * Re-encode via @napi-rs/canvas — the sharp-free path.
 *
 * Skia decodes the progressive/CMYK JPEGs Telegram chokes on, and its JPEG
 * encoder only writes BASELINE, which is exactly the shape Telegram accepts
 * without argument. A white matte is painted first because JPEG has no alpha
 * and a transparent PNG would otherwise arrive with black edges.
 *
 * @returns {Promise<Buffer|null>} null when canvas is absent or refused.
 */
async function reencodeWithCanvas(input, meta) {
  const canvas = await loadCanvas()
  if (!canvas) return null
  try {
    const image = await canvas.loadImage(input)
    const srcW = image.width || 0
    const srcH = image.height || 0
    if (!srcW || !srcH) return null

    // Same box as the sharp path, never enlarging: a 4000px banner becomes
    // 2560px, a 736px menu icon stays exactly as it is.
    const { width, height } = telegramBox(meta?.width || srcW, meta?.height || srcH)

    const out = canvas.createCanvas(width, height)
    const g = out.getContext('2d')
    g.fillStyle = '#ffffff'
    g.fillRect(0, 0, width, height)

    // Centred inside the box: the picture is never cropped, only letterboxed
    // when Telegram's 20:1 rule needs padding.
    const scale = Math.min(width / srcW, height / srcH)
    const drawW = Math.max(1, Math.round(srcW * scale))
    const drawH = Math.max(1, Math.round(srcH * scale))
    g.drawImage(image, Math.round((width - drawW) / 2), Math.round((height - drawH) / 2), drawW, drawH)

    const bytes = out.toBuffer('image/jpeg', JPEG_QUALITY)
    return bytes?.length ? bytes : null
  } catch (err) {
    console.warn(`[telegram] canvas re-encode failed: ${err?.message ?? err}`)
    return null
  }
}

/**
 * Re-encode a photo to a baseline sRGB JPEG Telegram will always accept.
 *
 * Never throws. Returns the ORIGINAL buffer when:
 *   • it is not a photo we can read (a GIF, a PDF, a video frame),
 *   • the photo was already fine,
 *   • neither encoder could do the job.
 *
 * The one case that used to return the original bytes and should not have:
 * a progressive JPEG on a host without sharp. Canvas covers it now, and
 * send.js covers even that by retrying the photo as a document.
 *
 * @param {Buffer} input
 * @returns {Promise<{buffer: Buffer, changed: boolean, reason: string|null}>}
 */
export async function normalizePhoto(input) {
  if (!Buffer.isBuffer(input) || !input.length) {
    return { buffer: input, changed: false, reason: null }
  }

  const sniffed = sniffFormat(input)
  // GIFs are sent as animations, never as photos — and re-encoding one here
  // would flatten it to its first frame.
  if (!sniffed || sniffed === 'gif') {
    return { buffer: input, changed: false, reason: null }
  }

  const sharp = await loadSharp()
  const meta = await readMetadata(input, sharp)
  // Nothing readable: a file Telegram *might* still accept. Leave it exactly
  // as it was rather than replacing a readable image with nothing.
  if (!meta) return { buffer: input, changed: false, reason: null }

  const reason = photoRejectionReason(meta, input.length)
  // Nothing wrong: pass the original bytes through untouched.
  if (!reason) return { buffer: input, changed: false, reason: null }

  const out = (await reencodeWithSharp(sharp, input, meta)) ?? (await reencodeWithCanvas(input, meta))
  if (!out) {
    // Both encoders are gone. Say so once, loudly: the next thing that
    // happens is send.js sending this as a document instead of a photo.
    console.warn(
      `[telegram] no JPEG encoder available, ${reason} photo cannot be normalised: sending as document`,
    )
    return { buffer: input, changed: false, reason }
  }
  return { buffer: out, changed: true, reason }
}
