/**
 * /kick — remove a member from THIS group (Telegram).
 *
 * A kick on Telegram is not an API call: the only removal is `banChatMember`,
 * which also blocks re-entry. lib/telegram-moderation.js's kickMember() bans
 * and immediately unbans, so the person is out of the room but can come back
 * if someone invites them again. `.ban` is the one that keeps them out.
 *
 * Who may run it: the bot owner, a global bot mod, or an admin of this group.
 * That is deliberately looser than the WhatsApp `.kick` (owner/mods only):
 * being an admin of a Telegram group IS the authority to remove people from
 * it, and unlike WhatsApp's LID matching, `getChatMember()` answers the
 * question authoritatively. See the header of lib/telegram-moderation.js for
 * the reasoning and for what stays staff-only (account-wide bans).
 *
 * The target comes from a reply, a tapped mention, `@username` the bot has
 * seen, or a numeric id — `resolveTarget()` in that order.
 */
import { isPlatformOwner } from '../lib/platform/permissions.js'
import { isMod } from '../lib/mod-repo.js'
import {
  resolveTarget, canModerate, botRights, kickMember,
  MOD_GROUP_ONLY, MOD_NOT_ALLOWED, modNeedsAdminRights,
  mention, isChatAdminNative,
} from '../lib/telegram-moderation.js'

const usage = (pr) =>
  `❌ Who should I remove?\n\n` +
  `*Usage:*\n` +
  `• reply to their message with \`${pr}kick\`\n` +
  `• \`${pr}kick @username\`\n` +
  `• \`${pr}kick 847362910\` (their numeric id)\n\n` +
  `_The bot must be an admin here with "Ban users" allowed._`

export default {
  name: 'kick',
  aliases: [],
  category: 'utility',
  platforms: ['telegram'],
  requiresPlayer: false,
  modTool: true,
  description: 'Remove a member from this group (reply to their message or @mention them)',

  async run(ctx) {
    const pr = ctx.prefix ?? '/'

    if (!ctx.isGroup) return ctx.reply(MOD_GROUP_ONLY)
    if (!(await canModerate(ctx))) return ctx.reply(MOD_NOT_ALLOWED)

    const target = resolveTarget(ctx.message, ctx.args)
    if (!target) return ctx.reply(usage(pr))

    if (String(target.id) === String(ctx.message?.from?.id)) {
      return ctx.reply(`❌ You cannot kick yourself.`)
    }
    const targetPlayerId = target.playerId ?? (String(target.id).startsWith('@') ? null : `tg:${target.id}`)
    if (targetPlayerId && isPlatformOwner(targetPlayerId)) {
      return ctx.reply(`❌ I cannot kick the bot owner.`)
    }
    const callerIsOwner = isPlatformOwner(ctx.platformId) || isPlatformOwner(ctx.from)
    if (!callerIsOwner && targetPlayerId && isMod(ctx.db, targetPlayerId)) {
      return ctx.reply(`❌ Cannot kick a bot mod — only the bot owner can do that.`)
    }

    // Refuse up front when the bot's own rights make the action impossible,
    // with the reason. An action that fails silently is the bug report.
    const rights = await botRights(ctx.bot.api, ctx.chat.id, ctx.bot.botInfo?.id, { force: true })
    const blocked = modNeedsAdminRights(rights)
    if (!rights.canRestrict) {
      return ctx.reply(
        blocked ??
        `⚠️ I am an admin here but I do not have the *Ban users* permission, so I cannot remove anyone. ` +
        `Ask a group owner to tick it under Administrators.`,
      )
    }

    // Do not waste an API call on someone Telegram will refuse anyway.
    if (target.user?.id || /^\d+$/.test(String(target.id))) {
      const isTargetAdmin = await isChatAdminNative(ctx.bot.api, ctx.chat.id, target.id, { force: true })
      if (isTargetAdmin) {
        return ctx.reply(`❌ ${target.name} is an admin of this group — remove their admin rights first.`)
      }
    }

    const res = await kickMember(ctx.bot.api, ctx.chat.id, target.id)
    if (!res.ok) {
      return ctx.reply(`❌ Could not remove ${target.name} — ${res.error}`)
    }

    return ctx.reply(
      `🚪 ${mention(target.id, target.name)} was removed from the group.` +
      (res.banned
        ? `\n⚠️ Telegram kept them banned (the unban step failed: ${res.warning}), so they cannot rejoin until ` +
          `\`${pr}unban\` is run.`
        : `\n_They can join again if someone invites them. Use_ \`${pr}ban\` _to keep them out._`),
    )
  },
}
