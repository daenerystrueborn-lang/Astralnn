/**
 * /ban  /tban  /unban — keep someone out, and (for staff) out of the bot.
 *
 * Telegram's `.ban` has two independent halves and it matters which one ran:
 *
 *   the CHAT ban   `banChatMember` — they cannot rejoin this group until they
 *                  are unbanned. Group admins may set this.
 *   the BOT ban    lib/ban-repo.js — every command they send is refused, in
 *                  every group and DM. Owner/global-mod ONLY, because a group
 *                  admin must never be able to take an account out of the
 *                  whole game from their own group.
 *
 * Both are attempted and both are reported separately, because "half worked"
 * is a real and common outcome: a group admin running `.ban` gets the chat ban
 * and a line saying the account-wide half needs a mod.
 *
 * `.tban 10m` (or `.ban 10m`) is a temporary chat ban — Telegram's own
 * `until_date`, so it lifts itself even if the bot is down when it expires.
 * `/unban` reverses both halves, and `/unban` with a numeric id or @username
 * reaches someone who is no longer in the group (the appeals case).
 */
import { banUser, unbanUser, getBan } from '../lib/ban-repo.js'
import { isMod } from '../lib/mod-repo.js'
import { isPlatformOwner } from '../lib/platform/permissions.js'
import {
  resolveTarget, canModerate, isAccountStaff, botRights, banMember, unbanMember,
  MOD_GROUP_ONLY, MOD_NOT_ALLOWED, modNeedsAdminRights,
  mention,
} from '../lib/telegram-moderation.js'

const UNITS = { s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000 }
const MAX_MS = 365 * 86_400_000

function parseDuration(input) {
  const raw = String(input ?? '').trim().toLowerCase()
  const m = raw.match(/^(\d+)\s*([smhd])?$/)
  if (!m) return null
  const n = parseInt(m[1], 10)
  if (!n) return null
  const ms = n * (UNITS[m[2] ?? 'm'] ?? 60_000)
  return ms > MAX_MS ? null : ms
}

function human(ms) {
  const mins = Math.round(ms / 60_000)
  if (mins < 60) return `${mins}m`
  const hours = Math.round(mins / 60)
  if (hours < 48) return `${hours}h`
  return `${Math.round(hours / 24)}d`
}

export default {
  name: 'ban',
  aliases: ['tban', 'unban'],
  category: 'admin',
  platforms: ['telegram'],
  requiresPlayer: false,
  modTool: true,
  description: 'Remove a member and keep them out; /unban reverses it',
  subcommands: [
    { cmd: '@user [reason]', desc: 'remove and block from this group (+ bot ban for staff)' },
    { cmd: '@user 10m', desc: 'temporary chat ban — 1m / 2h / 7d' },
    { cmd: 'unban @user', desc: 'lift the chat ban and the bot ban' },
  ],

  async run(ctx) {
    const pr = ctx.prefix ?? '/'
    const cmd = ctx.cmd

    if (!ctx.isGroup) return ctx.reply(MOD_GROUP_ONLY)
    if (!(await canModerate(ctx))) return ctx.reply(MOD_NOT_ALLOWED)

    const target = resolveTarget(ctx.message, ctx.args)
    if (!target) {
      return ctx.reply(
        `❌ Who?\n\n` +
        `*Usage:* reply to their message, or \`${pr}${cmd} @username${cmd === 'unban' ? '' : ' [reason|10m]'}\`.`,
      )
    }

    const targetPlayerId = target.playerId ?? (target.id.startsWith('@') ? null : `tg:${target.id}`)
    const who = target.id.startsWith('@') ? target.id : mention(target.id, target.name)

    if (String(target.id) === String(ctx.message?.from?.id)) {
      return ctx.reply(`❌ You cannot ${cmd} yourself.`)
    }
    if (targetPlayerId && isPlatformOwner(targetPlayerId)) {
      return ctx.reply(`❌ I cannot ${cmd} the bot owner.`)
    }
    const callerIsOwner = isPlatformOwner(ctx.platformId) || isPlatformOwner(ctx.from)
    if (cmd !== 'unban' && !callerIsOwner && targetPlayerId && isMod(ctx.db, targetPlayerId)) {
      return ctx.reply(`❌ Mods cannot ban another bot mod — only the bot owner can do that.`)
    }
    if (!targetPlayerId) {
      return ctx.reply(
        `❌ I have not seen ${target.name} post here, so I cannot match that name to an ` +
        `account. Reply to their message instead, or use their numeric id.`,
      )
    }

    // ── /unban ───────────────────────────────────────────────────────────
    if (cmd === 'unban') {
      const chatRes = await unbanMember(ctx.bot.api, ctx.chat.id, target.id)
      const wasBannedInBot = Boolean(getBan(ctx.db, targetPlayerId))
      if (wasBannedInBot) {
        if (!isAccountStaff(ctx)) {
          return ctx.reply(
            `⚠️ Chat ban lifted${chatRes.ok ? '' : ` (Telegram said: ${chatRes.error})`}, but ` +
            `${who} is also banned from the bot account-wide, and only a bot mod or the owner can lift that.`,
          )
        }
        await unbanUser(ctx.db, targetPlayerId, ctx.platformId ?? ctx.from)
      }
      return ctx.reply(
        `🔓 ${who} is unbanned` +
        (wasBannedInBot ? ' from this group *and* from the bot.' : ' in this group.') +
        (chatRes.ok ? '' : `\n_(Telegram said: ${chatRes.error} — they may not have been banned here.)_`),
      )
    }

    // ── /ban, /tban ──────────────────────────────────────────────────────
    const durationArg = ctx.args.find(a => /^\d+\s*[smhd]$/i.test(String(a ?? '')))
    const untilDate = durationArg ? Date.now() + (parseDuration(durationArg) ?? 0) : null
    if (durationArg && !parseDuration(durationArg)) {
      return ctx.reply(`❌ Bad duration. Use *1m*, *2h*, *7d* (max 365d).`)
    }

    const reason = ctx.args.filter(a => a !== durationArg).join(' ').trim() || null

    const rights = await botRights(ctx.bot.api, ctx.chat.id, ctx.bot.botInfo?.id, { force: true })
    // Only a missing right that the action actually needs is worth mentioning;
    // Telegram's own refusal carries the detail when the call is attempted.
    const blocked = modNeedsAdminRights(rights)
    const chatRes = await banMember(ctx.bot.api, ctx.chat.id, target.id, { untilDate })

    // Account-wide half: staff only, and never for a temporary chat ban (a
    // 10-minute group ban must not lock someone out of the whole game).
    let botBanned = false
    if (isAccountStaff(ctx) && !untilDate) {
      await banUser(ctx.db, targetPlayerId, ctx.platformId ?? ctx.from, reason)
      botBanned = true
    }

    const lines = []
    if (chatRes.ok) {
      lines.push(
        untilDate
          ? `🚫 ${who} is banned from this group for *${human(untilDate - Date.now())}*.`
          : `🚫 ${who} is banned from this group.`,
      )
    } else {
      lines.push(`❌ Could not ban ${who} from this group — ${chatRes.error}`)
      if (blocked) lines.push(blocked)
    }

    if (botBanned) {
      lines.push(`⛔ Also banned from the bot: every command is refused until \`${pr}unban\`.`)
    } else if (isAccountStaff(ctx)) {
      lines.push(`_Chat ban only — a temporary ban never touches their bot access._`)
    } else {
      lines.push(
        `_Chat ban only. To block them from the bot in every group, ask a bot mod or the owner._`,
      )
    }

    if (reason) lines.push(`Reason: _${reason}_`)

    return ctx.reply(lines.join('\n'))
  },
}
