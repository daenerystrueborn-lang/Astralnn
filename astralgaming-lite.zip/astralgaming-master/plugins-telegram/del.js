/**
 * /del — delete a message, the way a moderator means it.
 *
 *   /del                 reply to the message you want gone
 *   /del 3               that message and the 2 above it (a small clean-up)
 *
 * Telegram has no "delete the last N messages" call and no way to enumerate a
 * chat's history, so a purge works from a REPLY outwards: `deleteMessages`
 * accepts up to 100 ids, and message ids in a chat are sequential, which makes
 * "this one and the few before it" a safe, bounded request. The command message
 * itself is always removed too, so a moderation action leaves no litter.
 *
 * Requires the bot to be an admin with `can_delete_messages`; anything else and
 * Telegram refuses, which this reports verbatim rather than guessing.
 */
import {
  canModerate, botRights, deleteMessage,
  MOD_GROUP_ONLY, MOD_NOT_ALLOWED, modNeedsAdminRights,
} from '../lib/telegram-moderation.js'

/** How far back `/del n` may reach — a clean-up, not a history wipe. */
const MAX_RANGE = 20

export default {
  name: 'del',
  aliases: ['delete', 'rm'],
  category: 'utility',
  platforms: ['telegram'],
  requiresPlayer: false,
  modTool: true,
  description: 'Delete the message you reply to (and optionally the few above it)',
  subcommands: [
    { cmd: '', desc: 'delete the replied-to message' },
    { cmd: '<n>', desc: 'delete that message and up to n-1 above it' },
  ],

  async run(ctx) {
    const pr = ctx.prefix ?? '/'

    if (!ctx.isGroup) return ctx.reply(MOD_GROUP_ONLY)
    if (!(await canModerate(ctx))) return ctx.reply(MOD_NOT_ALLOWED)

    const replied = ctx.message?.reply_to_message
    if (!replied) {
      return ctx.reply(
        `❌ Reply to the message you want deleted, then send \`${pr}del\`.\n\n` +
        `_Optional:_ \`${pr}del 3\` _also clears the two messages above it._`,
      )
    }

    const rights = await botRights(ctx.bot.api, ctx.chat.id, ctx.bot.botInfo?.id, { force: true })
    if (!rights.canDelete) {
      return ctx.reply(modNeedsAdminRights(rights) ??
        `⚠️ I am an admin here but without the *Delete messages* permission, so I cannot remove anything.`)
    }

    const requested = parseInt(ctx.args?.[0] ?? '1', 10)
    const count = Number.isFinite(requested) ? Math.min(Math.max(requested, 1), MAX_RANGE) : 1

    // Telegram refuses to delete a message the bot did not send through some
    // paths; the API call is the honest test, not a pre-check.
    let deleted = 0
    let lastError = null
    for (let i = 0; i < count; i++) {
      const id = replied.message_id + i
      const res = await deleteMessage(ctx.bot.api, ctx.chat.id, id)
      if (res.ok) deleted++
      else if (i === 0) lastError = res.error
    }

    // The command itself never stays behind: a moderator's "/del" in the chat
    // is noise, and leaving it would also leave the reply chain pointing at a
    // message that no longer exists.
    await deleteMessage(ctx.bot.api, ctx.chat.id, ctx.message.message_id)

    // The confirmation is useful for a second and noise after that, so it
    // removes itself. Best-effort: if the delete fails the line simply stays.
    const ephemeral = async (text) => {
      const sent = await ctx.reply(text)
      if (sent?.message_id) {
        setTimeout(() => {
          deleteMessage(ctx.bot.api, ctx.chat.id, sent.message_id).catch(() => {})
        }, 6_000).unref?.()
      }
      return sent
    }

    if (!deleted) {
      return ephemeral(`❌ Could not delete that message — ${lastError ?? 'unknown error'}`)
    }
    if (deleted < count) {
      return ephemeral(
        `🧹 Deleted *${deleted}* of ${count} messages. ` +
        `_The rest are too old for Telegram to remove, or were already gone._`,
      )
    }
    return ephemeral(`🧹 Deleted *${deleted}* message${deleted === 1 ? '' : 's'}.`)
  },
}
