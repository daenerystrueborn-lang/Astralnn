/**
 * /main — designate THIS group as the bot's home.
 *
 * Telegram gives a bot no way to know which of its groups is "the main one",
 * and the owner should not have to hunt for a -100… chat id in a client that
 * hides it. So the group the owner runs /main in becomes:
 *
 *   • the main group (lib/telegram-main-group.js), and
 *   • a card-spawn group (lib/card-spawn-groups.js), because cards should drop
 *     where the players already are.
 *
 * Owner-only, group-only. `.main` also works — every help string in this bot
 * prints '.', so the adapter accepts both prefixes on Telegram.
 */
import { config } from '../config.js'
import { isPlatformOwner } from '../lib/platform/permissions.js'
import { addCardSpawnGroup, getCardSpawnGroups, removeCardSpawnGroup } from '../lib/card-spawn-groups.js'
import { getMainGroup, setMainGroup, clearMainGroup } from '../lib/telegram-main-group.js'

const pr = config.telegramPrefix

/**
 * Owner here can mean two different ids: the Telegram account is either linked
 * to the owner's WhatsApp character (in which case ctx.from is that character
 * id) or unlinked (ctx.platformId, 'tg:…'). Check both — otherwise the owner
 * who linked would lose every admin command they have on WhatsApp.
 */
function isOwner(ctx) {
  return isPlatformOwner(ctx.platformId) || isPlatformOwner(ctx.from)
}

export default {
  name: 'main',
  aliases: ['setmain', 'homegroup'],
  category: 'admin',
  platforms: ['telegram'],
  description: 'Make this group the main group and a card-spawn group (owner only)',

  async run(ctx) {
    if (!ctx.isGroup) {
      return ctx.reply(
        `⚠️ Run *${pr}main* inside the group you want as the main one — a DM has no group to register.`,
      )
    }
    if (!isOwner(ctx)) {
      return ctx.reply('❌ Only the bot owner can set the main group.')
    }

    const sub = (ctx.args[0] ?? '').toLowerCase()

    if (sub === 'status') {
      const main = await getMainGroup()
      const spawns = await getCardSpawnGroups()
      return ctx.reply(
        `📌 *Main group:*\n` +
          `${main.chatId ? `${main.title ? `${main.title}\n` : ''}\`${main.chatId}\`` : '_not set_'}\n\n` +
          `🃏 *Card-spawn groups (${spawns.length}):*\n` +
          (spawns.length ? spawns.map(s => `• \`${s}\``).join('\n') : '_none_') +
          `\n\nSet this one with *${pr}main*, or remove it with *${pr}main off*.`,
      )
    }

    if (sub === 'off' || sub === 'remove' || sub === 'clear') {
      const main = await getMainGroup()
      await removeCardSpawnGroup(ctx.sender)
      if (main.chatId === ctx.sender) await clearMainGroup()
      return ctx.reply('🗑️ This group is no longer the main group or a card-spawn group.')
    }

    const record = await setMainGroup(ctx.sender, ctx.chatTitle || null)
    const spawns = await getCardSpawnGroups()
    if (!spawns.includes(ctx.sender)) await addCardSpawnGroup(ctx.sender)

    return ctx.reply(
      `📌 *This group is now the main group.*\n\n` +
        `• Title: ${record.title || '_unnamed_'}\n` +
        `• Id: \`${record.chatId}\`\n` +
        `• Cards will spawn here too.\n\n` +
        `_Check anytime with_ *${pr}main status*_._`,
    )
  },
}
