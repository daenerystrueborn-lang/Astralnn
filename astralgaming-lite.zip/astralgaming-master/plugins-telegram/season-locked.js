/**
 * season-locked.js — `.season` on Telegram: the game stays, the money page goes.
 *
 * `.season offer` is the naira package list (plugins/season.js handleOffer), so
 * it is refused here. Levels, the Season Shop (paid in Season Points, not
 * money), status and the guide are gameplay and delegate unchanged.
 *
 * Separate file from payments-locked.js because the loader registers exactly
 * one plugin per file (the default export).
 */
import seasonPlugin from '../plugins/season.js'

export default {
  name: 'season-locked',
  aliases: ['season'],
  category: 'utility',
  platforms: ['telegram'],
  description: 'Season status on Telegram (money offers closed)',

  async run(ctx) {
    const sub = (ctx.args[0] ?? '').toLowerCase()
    if (sub === 'offer' || sub === 'offers') {
      return ctx.reply(
        `💳 *Season offers are bought on WhatsApp, not here.*\n\n` +
          `Telegram has no payment rail tied to this bot yet, so no packages or ` +
          `prices are shown.\n\n` +
          `Season *gameplay* — levels, points and the Season Shop — works normally ` +
          `right here.`,
      )
    }
    return seasonPlugin.run(ctx)
  },
}
