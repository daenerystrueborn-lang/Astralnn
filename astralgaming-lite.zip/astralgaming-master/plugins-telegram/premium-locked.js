/**
 * premium-locked.js — `.premium` on Telegram: status yes, purchase no.
 *
 * Buying Premium ends in a naira transfer plus an owner screenshot review, so
 * `buy` / `confirm` / `reject` are refused here. Everything else (current
 * subscription, plan list, on/off toggles) is read-only and delegates to the
 * real plugin — a Telegram account linked to a player who bought Premium on
 * WhatsApp must still be able to see what they own.
 *
 * Separate file from payments-locked.js because the loader registers exactly
 * one plugin per file (the default export).
 */
import { config } from '../config.js'
import premiumPlugin from '../plugins/premium.js'

const pr = config.telegramPrefix

export default {
  name: 'premium-locked',
  // Deliberately registers the plain name: last-registered-wins resolves here
  // before plugins/premium.js for Telegram (lib/plugin-manager.js:60).
  aliases: ['premium'],
  category: 'utility',
  platforms: ['telegram'],
  requiresPlayer: false,
  description: 'Premium status on Telegram (purchases closed)',

  async run(ctx) {
    const sub = (ctx.args[0] ?? '').toLowerCase()
    if (sub === 'buy' || sub === 'confirm' || sub === 'reject') {
      return ctx.reply(
        `💳 *Premium is bought on WhatsApp, not here.*\n\n` +
          `Telegram does not collect Premium payments. You can still read the ` +
          `plans and your status here.\n\n` +
          `Buy it on WhatsApp with \`${config.prefix}premium buy <plan>\`. ` +
          `If this account is linked to the same character, the perks appear ` +
          `here as soon as it is active.\n\n` +
          `_Check what you already have with_ *${pr}premium status*._`,
      )
    }
    return premiumPlugin.run(ctx)
  },
}
