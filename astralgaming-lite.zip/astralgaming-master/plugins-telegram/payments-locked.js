/**
 * payments-locked.js — Telegram cannot take money yet, and must look like it.
 *
 * The owner's requirement: no Telegram player may buy anything, and the bank
 * account details that plugins/topup.js prints must never be reachable from a
 * platform whose audience is unknown.
 *
 * Three layers guard that, and this file is the middle one:
 *
 *   1. PLATFORMS.telegram.payments is false (lib/platform/capabilities.js), so
 *      prices are not supposed to be rendered at all — formatPrice() exists so
 *      the day a rail arrives this is one flag, not fifty strings.
 *   2. THIS FILE — every money command is re-registered for Telegram and
 *      answers with a clear refusal. Without it the player gets "unknown
 *      command", which reads as a broken bot rather than a closed shop.
 *   3. The purchase flows themselves live in plugins that are WhatsApp-shaped
 *      (bank transfer, screenshot confirmation). They are unreachable because
 *      their command names resolve here first: plugin-manager resolves
 *      candidate lists LAST-registered-wins, and ./plugins-telegram is loaded
 *      after ./plugins (lib/plugin-manager.js:60).
 *
 * Commands that are only *partly* about money (`premium`, `season`) live in
 * their own files (premium-locked.js, season-locked.js) because this loader
 * registers exactly ONE plugin per file — the default export.
 */
import { config } from '../config.js'

const pr = config.telegramPrefix

const CLOSED_TEXT =
  `💳 *Payments aren't open on Telegram yet.*\n\n` +
  `Nothing here can be bought, and no prices are shown — Telegram has no ` +
  `payment rail connected to this bot.\n\n` +
  `Everything you already own works normally: play, fight, spawn cards.\n` +
  `To top up or buy, use *WhatsApp* or the website.\n\n` +
  `_Your Telegram account is still linked to the same character, so anything ` +
  `you buy there shows up here._`

function refuse(ctx) {
  return ctx.reply(CLOSED_TEXT)
}

export default {
  // One plugin, many names: these are the money commands that must not exist
  // on Telegram at all.
  name: 'topup',
  aliases: [
    'buysolars', 'buygems', 'gems', 'astralpay', 'pay', 'preorder', 'pre-order',
    'promo', 'promos', 'promogems', 'mond', 'monds', 'buymonds', 'mondshop',
    'gm', 'gameshop', 'vip', 'vipbuy',
  ],
  category: 'utility',
  platforms: ['telegram'],
  description: 'Top-up and purchases (closed on Telegram)',

  async run(ctx) {
    return refuse(ctx)
  },
}
