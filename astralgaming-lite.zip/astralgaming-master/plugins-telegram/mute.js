/**
 * /mute  /unmute  /mutelist — keep a member in the group but stop them talking.
 *
 * Two layers, on purpose:
 *
 *   1. Telegram's own restriction (`restrictChatMember` with every send-right
 *      removed). They physically cannot post, and Telegram tells them so.
 *   2. A record in lib/moderation-state.js. lib/telegram-guard.js deletes
 *      anything they get out anyway (pre-restriction messages, a media caption
 *      that slipped past, or the whole thing when the bot has `can_delete`
 *      but not `can_restrict`).
 *
 * Unlike WhatsApp's `.mute`, this one is visible: the person sees "you can't
 * send messages", which is friendlier than silently eating their messages.
 *
 * Durations accept 30s / 10m / 2h / 1d; blank means forever.
 */
import { setMute, clearMute, listMutes, clearExpiredMutes } from '../lib/moderation-state.js'
import { isPlatformOwner } from '../lib/platform/permissions.js'
import { isMod } from '../lib/mod-repo.js'
import { canModerate, resolveTarget, botRights, restrictMember, unrestrictMember,
  MOD_GROUP_ONLY, MOD_NOT_ALLOWED, mention } from '../lib/telegram-moderation.js'
import { humanDuration } from '../plugins/afk.js'

const UNITS = { s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000 }
const MAX_MS = 30 * 86_400_000 // 30d ceiling so a typo cannot mute for a decade

/** "10m" -> 600000. Bare digits are minutes. null when unparseable. */
function parseDuration(input) {
  const raw = String(input ?? '').trim().toLowerCase()
  if (!raw) return null
  const m = raw.match(/^(\d+)\s*([smhd])?$/)
  if (!m) return null
  const n = parseInt(m[1], 10)
  if (!n) return null
  const ms = n * (UNITS[m[2] ?? 'm'] ?? 60_000)
  return ms > MAX_MS ? null : ms
}

/** The duration argument, ignoring the target's numeric id. */
function durationArg(args = [], target = null) {
  return args.find(a => /^\d+\s*[smhd]$/i.test(String(a ?? '')))
    ?? (target ? null : args.find(a => /^\d+$/.test(String(a ?? ''))))
}

export default {
  name: 'mute',
  aliases: ['unmute', 'mutelist', 'muted'],
  category: 'utility',
  platforms: ['telegram'],
  requiresPlayer: false,
  modTool: true,
  description: 'Stop a member from talking, without removing them (mute @user [10m])',
  subcommands: [
    { cmd: '@user [duration]', desc: 'mute — 30s / 10m / 2h / 1d, blank = forever' },
    { cmd: 'unmute @user', desc: 'lift a mute' },
    { cmd: 'mutelist', desc: 'everyone currently muted here' },
  ],

  async run(ctx) {
    const pr = ctx.prefix ?? '/'
    const chatKey = ctx.sender

    if (!ctx.isGroup) return ctx.reply(MOD_GROUP_ONLY)

    // ── /mutelist ────────────────────────────────────────────────────────
    if (ctx.cmd === 'mutelist' || ctx.cmd === 'muted') {
      if (!(await canModerate(ctx))) return ctx.reply(MOD_NOT_ALLOWED)
      await clearExpiredMutes()
      const list = await listMutes(chatKey)
      if (!list.length) return ctx.reply(`🔇 *MUTE LIST*\n\n_Nobody is muted here._`)
      const lines = list.map(([id, rec]) => {
        const native = String(id).replace(/^tg:/, '')
        return (
          `• ${mention(native)} — ` +
          (rec.until == null ? 'indefinite' : `${humanDuration(rec.until - Date.now())} left`)
        )
      })
      return ctx.reply(
        `🔇 *MUTE LIST*\n─────────────────────\n${lines.join('\n')}\n\n_${pr}unmute @user to lift one._`,
      )
    }

    if (!(await canModerate(ctx))) return ctx.reply(MOD_NOT_ALLOWED)

    const target = resolveTarget(ctx.message, ctx.args)
    if (!target) {
      return ctx.reply(
        `❌ Who should I ${ctx.cmd === 'unmute' ? 'unmute' : 'mute'}?\n\n` +
        `*Usage:* reply to their message, or \`${pr}${ctx.cmd} @username${ctx.cmd === 'unmute' ? '' : ' 10m'}\`.`,
      )
    }

    const targetPlayerId = target.playerId ?? `tg:${target.id}`

    // ── /unmute ──────────────────────────────────────────────────────────
    if (ctx.cmd === 'unmute') {
      const existed = await clearMute(chatKey, targetPlayerId)
      const res = await unrestrictMember(ctx.bot.api, ctx.chat.id, target.id)
      if (!res.ok && !existed) {
        return ctx.reply(`❌ Could not unmute ${target.name} — ${res.error}`)
      }
      return ctx.reply(
        res.ok
          ? `🔊 ${mention(target.id, target.name)} can talk again.`
          : `🔊 Removed ${target.name}'s mute record, but Telegram refused the permission reset — ${res.error}`,
      )
    }

    // ── /mute ────────────────────────────────────────────────────────────
    if (String(target.id) === String(ctx.message?.from?.id)) {
      return ctx.reply(`❌ You cannot mute yourself.`)
    }
    if (isPlatformOwner(targetPlayerId)) {
      return ctx.reply(`❌ I cannot mute the bot owner.`)
    }
    const callerIsOwner = isPlatformOwner(ctx.platformId) || isPlatformOwner(ctx.from)
    if (!callerIsOwner && isMod(ctx.db, targetPlayerId)) {
      return ctx.reply(`❌ Cannot mute a bot mod — only the bot owner can do that.`)
    }

    const rights = await botRights(ctx.bot.api, ctx.chat.id, ctx.bot.botInfo?.id, { force: true })
    if (!rights.isAdmin) {
      return ctx.reply(
        `⚠️ I am not an admin in this group, so Telegram will not let me restrict anyone.\n` +
        `_Make me an admin with "Restrict members" (Ban users covers it too). The mute is still ` +
        `recorded, and I will delete what they post if I have "Delete messages"._`,
      )
    }

    const durArg = durationArg(ctx.args, target)
    let until = null
    if (durArg) {
      const ms = parseDuration(durArg)
      if (ms == null) return ctx.reply(`❌ Bad duration. Use *30s*, *10m*, *2h* or *1d* (max 30d).`)
      until = Date.now() + ms
    }

    const res = await restrictMember(ctx.bot.api, ctx.chat.id, target.id, { untilDate: until })
    await setMute(chatKey, targetPlayerId, { until, by: ctx.platformId ?? ctx.from })

    const when = until ? `for *${humanDuration(until - Date.now())}*` : `*indefinitely*`
    return ctx.reply(
      res.ok
        ? `🔇 ${mention(target.id, target.name)} is muted ${when}.\n` +
          `_They stay in the group. Lift it with_ \`${pr}unmute @user\`.`
        : `⚠️ ${target.name} is recorded as muted ${when}, but Telegram refused the ` +
          `restriction — ${res.error}\n_I will still delete their messages while I am an admin with ` +
          `"Delete messages"._`,
    )
  },
}

export { parseDuration }
