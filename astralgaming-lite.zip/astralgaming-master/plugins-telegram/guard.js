/**
 * /guard — the group's moderation console, plus the switches for the automatic
 * rules that lib/telegram-guard.js enforces on every message.
 *
 *   /guard                     what is on, what is being caught, what is missing
 *   /antilink on|off           delete links (and remove the poster at 3 strikes)
 *   /antispam on|off [n] [s]   delete floods/duplicates; /antispam kick on|off
 *   /grouplock on|off          only admins may talk
 *
 * All three toggles write the SAME settings WhatsApp's `.antilink`/`.antispam`
 * write (lib/group-settings.js), keyed by this chat's `tg:-100…` id, so
 * `.gcsettings` on Telegram reports them and a settings backup restored
 * elsewhere keeps working.
 *
 * `/guard` exists because the honest failure mode of a Telegram moderation bot
 * is silence: with privacy mode ON, or with the bot not an admin, the rules
 * simply never see anything or cannot act. The status screen says which of
 * those it is, in the group, where the person who can fix it will read it.
 */
import { getGroupSettings, saveGroupSettings, saveFailedMessage, parseOnOff } from '../lib/group-settings.js'
import { describeGuardState, ANTILINK_STRIKES, ANTISPAM_STRIKES } from '../lib/telegram-guard.js'
import { canModerate, botMediaRights, setupHint, MOD_GROUP_ONLY, MOD_NOT_ALLOWED } from '../lib/telegram-moderation.js'
import { toPlayerId } from '../lib/platform/identity.js'

const MIN_COUNT = 3, MAX_COUNT = 30
const MIN_WINDOW = 3, MAX_WINDOW = 120

function onOff(value) {
  return value ? 'ON' : 'OFF'
}

/**
 * One line for "may I post pictures in this chat?", given botMediaRights().
 *
 * Separated from the screen so the wording can be tested without a live group:
 * this is the only place the group-only photo failure is ever explained to the
 * person who can fix it.
 */
export function mediaPermissionLine(media) {
  if (!media?.known) return '❔ Media: could not check'
  if (media.canSendPhotos) return '✅ Media: photos and files'
  const tail = media.canSendDocuments
    ? ' — /menu arrives as a file instead of a picture'
    : ' — and files are off too, so /menu can only be text'
  return `⚠️ *Photos OFF here*${tail}\n   _Fix: Group → Edit → Permissions → Send Photos, or make me an admin._`
}

/** The status screen. Exported so the plugin and any future DMs share one copy. */
export async function guardStatus(ctx) {
  const chatKey = ctx.sender
  const botId = ctx.bot.botInfo?.id
  const { settings, rights } = await describeGuardState({
    api: ctx.bot.api,
    chatId: ctx.chat.id,
    botId,
    chatKey,
    userKey: toPlayerId('telegram', ctx.message?.from?.id ?? ''),
  })

  const adminLine = rights.isAdmin
    ? `✅ Admin here${rights.canDelete ? ' · can delete' : ' · ⚠️ *no* Delete messages'}${rights.canRestrict ? ' · can ban/restrict' : ' · ⚠️ *no* Ban users'}`
    : (rights.status === 'member'
      ? '❌ *Not an admin* — I cannot delete or remove anyone'
      : `❌ Status: ${rights.status}`)

  // ── Can I post pictures here? ─────────────────────────────────────────
  // The one permission that is invisible until it bites: a group can deliver
  // this bot's text and refuse its photos, so /menu arrives with the caption
  // and no banner (or, since the media fallback, as a file bubble). Telegram
  // reports it as `not enough rights to send photos to the chat`, never in the
  // chat itself — so the status screen says it in the place the person who can
  // fix it will read it.
  const media = botId
    ? await botMediaRights(ctx.bot.api, ctx.chat.id, botId, { force: true }).catch(() => ({ known: false }))
    : { known: false }
  const mediaLine = mediaPermissionLine(media)

  const rules = [
    `🔗 Antilink: *${onOff(settings.antilink)}*  _(${ANTILINK_STRIKES} strikes → removed)_`,
    `🚨 Antispam: *${onOff(settings.antispam)}*  _(${settings.antispamCount} msgs / ${settings.antispamWindow}s` +
      `${settings.antispamKick ? `, kick at ${ANTISPAM_STRIKES} strikes` : ', delete only'})_`,
    `🔒 Group lock: *${onOff(settings.grouplock)}*  _(only admins may talk)_`,
  ]

  const anyRule = settings.antilink || settings.antispam || settings.grouplock
  const tuning = anyRule && !rights.isAdmin
    ? '\n⚠️ Rules are on but I am not an admin, so nothing will actually be deleted.'
    : ''

  return (
    `🛡️ *GUARD* — ${ctx.chatTitle ? ctx.chatTitle : 'this group'}\n` +
    `─────────────────────\n` +
    `Permissions: ${adminLine}\n` +
    `${mediaLine}\n\n` +
    `*RULES*\n${rules.join('\n')}${tuning}\n\n` +
    `*SWITCHES*\n` +
    `• \`${ctx.prefix}antilink on|off\`\n` +
    `• \`${ctx.prefix}antispam on|off [count] [secs]\` · \`${ctx.prefix}antispam kick on|off\`\n` +
    `• \`${ctx.prefix}grouplock on|off\`\n` +
    `• \`${ctx.prefix}kick\` · \`${ctx.prefix}ban\` · \`${ctx.prefix}mute\` · \`${ctx.prefix}del\`\n\n` +
    setupHint()
  )
}

export default {
  name: 'guard',
  // The three toggles ride on this plugin as aliases: one implementation, one
  // settings writer, and a Telegram admin types the same word they typed on
  // WhatsApp. dispatch() passes the alias back as ctx.cmd.
  aliases: ['antilink', 'antispam', 'grouplock', 'modcheck', 'modstatus', 'guardstatus'],
  category: 'utility',
  platforms: ['telegram'],
  requiresPlayer: false,
  modTool: true,
  description: 'Moderation status for this group, plus the antilink / antispam / grouplock switches',
  subcommands: [
    { cmd: '', desc: 'what is on, and what I am missing' },
    { cmd: 'antilink on|off', desc: 'delete links, remove the poster at 3 strikes' },
    { cmd: 'antispam on|off [count] [secs]', desc: 'delete floods and duplicates' },
    { cmd: 'antispam kick on|off', desc: 'also remove repeat offenders' },
    { cmd: 'grouplock on|off', desc: 'only admins may talk' },
  ],

  async run(ctx) {
    const pr = ctx.prefix ?? '/'
    if (!ctx.isGroup) return ctx.reply(MOD_GROUP_ONLY)
    if (!(await canModerate(ctx))) return ctx.reply(MOD_NOT_ALLOWED)

    const cmd = ctx.cmd

    // ── /grouplock on|off ────────────────────────────────────────────────
    if (cmd === 'grouplock') {
      const want = parseOnOff(ctx.args?.[0])
      if (want === null) return ctx.reply(`❌ *Usage:* \`${pr}grouplock on|off\``)
      const res = await saveGroupSettings(ctx.sender, s => { s.grouplock = want; return s })
      if (!res.ok) return ctx.reply(saveFailedMessage('grouplock', res.error))
      return ctx.reply(
        want
          ? `🔒 *Group lock is ON.* Only admins can talk here — every other message is deleted on sight.\n` +
            `_Switch it off with_ \`${pr}grouplock off\`.`
          : `🔓 *Group lock is OFF.* Everyone can talk again.`,
      )
    }

    // ── /antilink on|off ─────────────────────────────────────────────────
    if (cmd === 'antilink') {
      const want = parseOnOff(ctx.args?.[0])
      if (want === null) return ctx.reply(`❌ *Usage:* \`${pr}antilink on|off\``)
      const res = await saveGroupSettings(ctx.sender, s => { s.antilink = want; return s })
      if (!res.ok) return ctx.reply(saveFailedMessage('antilink', res.error))
      return ctx.reply(
        want
          ? `🔗 *Antilink is ON.*\n` +
            `_Any link is deleted, the poster gets a strike, and ${ANTILINK_STRIKES} strikes removes them. ` +
            `Covers invites, shorteners, bare domains, "foo (dot) com", hidden links and captions. Admins and ` +
            `the bot owner are exempt._`
          : `🔗 *Antilink is OFF.*`,
      )
    }

    // ── /antispam … ──────────────────────────────────────────────────────
    if (cmd === 'antispam') {
      const sub = ctx.args?.[0]?.toLowerCase()

      if (sub === 'kick') {
        const k = parseOnOff(ctx.args?.[1])
        if (k === null) return ctx.reply(`❌ *Usage:* \`${pr}antispam kick on|off\``)
        const res = await saveGroupSettings(ctx.sender, s => { s.antispamKick = k; return s })
        if (!res.ok) return ctx.reply(saveFailedMessage('antispam kick', res.error))
        return ctx.reply(
          k
            ? `🚨 Antispam will now *remove* anyone who trips it ${ANTISPAM_STRIKES} times.`
            : `🚨 Antispam will now only *delete* — nobody gets removed.`,
        )
      }

      const want = parseOnOff(sub)
      if (want === null || !sub) {
        const s = await getGroupSettings(ctx.sender)
        return ctx.reply(
          `🚨 *ANTISPAM*\n─────────────────────\n` +
          `Status: *${onOff(s.antispam)}*\n` +
          `Flood trigger: *${s.antispamCount}* messages in *${s.antispamWindow}s*\n` +
          `Kick repeat offenders: *${onOff(s.antispamKick)}*\n\n` +
          `_${pr}antispam on 5 10_ — 5 messages per 10 seconds\n` +
          `_${pr}antispam kick on_ — remove at ${ANTISPAM_STRIKES} strikes`,
        )
      }

      let count = null, windowSec = null
      if (ctx.args[1] != null) {
        count = parseInt(ctx.args[1], 10)
        if (!Number.isFinite(count) || count < MIN_COUNT || count > MAX_COUNT) {
          return ctx.reply(`❌ Message count must be between *${MIN_COUNT}* and *${MAX_COUNT}*.`)
        }
      }
      if (ctx.args[2] != null) {
        windowSec = parseInt(ctx.args[2], 10)
        if (!Number.isFinite(windowSec) || windowSec < MIN_WINDOW || windowSec > MAX_WINDOW) {
          return ctx.reply(`❌ Window must be between *${MIN_WINDOW}* and *${MAX_WINDOW}* seconds.`)
        }
      }

      const res = await saveGroupSettings(ctx.sender, s => {
        s.antispam = want
        if (count != null) s.antispamCount = count
        if (windowSec != null) s.antispamWindow = windowSec
        return s
      })
      if (!res.ok) return ctx.reply(saveFailedMessage('antispam', res.error))
      const saved = res.settings

      return ctx.reply(
        saved.antispam
          ? `🚨 *Antispam is ON* — *${saved.antispamCount}* messages in *${saved.antispamWindow}s* trips it.\n` +
            `_Offending messages are deleted. Admins and the bot owner are exempt._`
          : `🚨 *Antispam is OFF.*`,
      )
    }

    // ── /guard (and modcheck/modstatus) ──────────────────────────────────
    return ctx.reply(await guardStatus(ctx))
  },
}
