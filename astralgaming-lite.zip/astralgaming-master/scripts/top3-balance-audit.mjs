/**
 * top3-balance-audit.mjs — how do the three strongest fully-geared accounts on
 * the live server actually trade with the endgame pools, and what numbers would
 * put a wall in front of them?
 *
 * WHY. The complaint is "monsters weak asf, bosses die in three hits". That is a
 * claim about two numbers per fight, and both are computable from the shipped
 * code paths rather than estimated by hand:
 *
 *   turns to clear   how many of THIS player's landed hits one monster costs
 *   turns to die     how many monster hits THIS player can absorb
 *
 * 2026-10-07: the Dreamlands sections now apply the realm's whale band
 * (DREAMLAND_WHALE_BAND) to monsters and champions, exactly as the live spawn
 * paths do, so these tables describe the realm as it is now rather than as it
 * was before the retune. The Caged Dimension is unchanged and never banded.
 *
 * The three accounts are the ones the owner pasted (2026-10-06) and their stats
 * are read straight off `.profile` — i.e. INCLUDING gear, pets, titles and mods,
 * which is exactly what `player.stats` holds at fight time. On top of that this
 * script models the two combat items the profile dump proves they carry, because
 * leaving them out makes the fight read wrong in both directions:
 *
 *   Core Sword   (Jester, void reaper)  x1.75 damage, ignores 30% of DEF
 *   Blade of the Dragons (Yochan)       x1.30 damage
 *   Dark Monarch pack (Yochan, Jester)  20% off every incoming hit
 *   Robe of the Dragons (Yochan, Jester) no single hit exceeds 35% of max HP
 *
 * Every monster number comes from the shipped functions (monsterStatsAtFloor,
 * scaleEnemyToPlayer, applyVeteranScaling, applyDefense), so the readout cannot
 * drift from what the bot does when one of these players types `.enter`.
 *
 *   node scripts/top3-balance-audit.mjs
 *
 * Read only. Prints tables; never fails a build.
 */
import { regularByLoc } from '../lib/game-data.js'
import {
  monsterStatsAtFloor, applyDefense, enemyPowerRatio, scaleEnemyToPlayer,
  applyVeteranScaling, calcPlayerHitChance, calcMonsterHitChance, scaleBossToPlayer,
} from '../lib/combat-engine.js'
import {
  DREAMLAND_DIFFICULTY, DREAMLAND_TOTAL_FLOORS, cumulativeFloor,
  dreamlandsRealmRatio, dreamlandsBandMultipliers, DREAMLAND_WHALE_BAND,
} from '../lib/dreamlands-core.js'
import { getBossById } from '../bosses/index.js'
import { initBossFight } from '../lib/boss-engine.js'

// ── the three accounts, verbatim from the profile dump ──────────────────────
const PLAYERS = {
  Yochan: {
    label: 'Yochan', classId: 'samurai', level: 200,
    stats: { str: 2431, agi: 690, int: 505, def: 1252, lck: 455, maxHp: 4503, maxMp: 1383 },
    hp: 4503, maxHp: 4503,
    skill: { name: 'The Thousand Cuts V', mult: 3.13 },
    // The kit, from the equipment block of the dump.
    weaponMult: 1.30, defIgnore: 0,          // Blade of the Dragons (+30%)
    incomingCut: 0.20, lifesteal: 0.15,        // Dark Monarch — Dread Sovereign
    hitCapPct: 0.35,                          // Robe of the Dragons
    modDamage: 1.05,                          // Heavy Hand
  },
  'Absolute Jester_MH': {
    label: 'Absolute Jester_MH', classId: 'mage', level: 200,
    stats: { str: 556, agi: 441, int: 2428, def: 1576, lck: 186, maxHp: 5202, maxMp: 1333 },
    hp: 5202, maxHp: 5202,
    skill: { name: 'Arcane Collapse', mult: 2.05 },
    weaponMult: 1.75, defIgnore: 0.30,        // Core Sword
    incomingCut: 0.20, lifesteal: 0.15, hitCapPct: 0.35,  // Dark Monarch + Robe of the Dragons
    modDamage: 1.05,
  },
  'void reaper': {
    label: 'void reaper', classId: 'rogue', level: 173,
    stats: { str: 2069, agi: 976, int: 347, def: 1423, lck: 234, maxHp: 6924, maxMp: 920 },
    hp: 6924, maxHp: 6924,
    skill: { name: 'Echoing Void II', mult: 3.30 },
    weaponMult: 1.75, defIgnore: 0.30,        // Core Sword
    incomingCut: 0, hitCapPct: 1,             // no pack, Core Chestplate
    modDamage: 1.05, critBoost: 0.05,         // Lucky Edge
  },
}

const PRIMARY = { samurai: 'str', mage: 'int', rogue: 'agi' }
const SKILL_TABLE = []
for (const [name, p] of Object.entries(PLAYERS)) {
  const id = `audit_${name.replace(/\W+/g, '_')}`
  p.equippedSkills = [id]
  SKILL_TABLE.push({ id, effects: [{ type: 'attack', stat: PRIMARY[p.classId], multiplier: p.skill.mult }] })
}
for (const p of Object.values(PLAYERS)) {
  p.primary = p.stats[PRIMARY[p.classId]]
  p.critChance = Math.min(0.95, 0.05 + p.stats.lck * 0.002 + (p.critBoost ?? 0))
  p.critFactor = 1 + p.critChance * 0.5      // a crit is x1.5 (calcPlayerDamage)
  p.playerDefMitigation = Math.min(0.97, p.stats.def / (p.stats.def + 500))
}

/** Outgoing raw before the monster's armour, at the hit's expectation. */
const rawFor = (p, mult, { kit = true } = {}) => Math.round(
  p.primary * mult * p.critFactor * (kit ? p.weaponMult * p.modDamage : 1))
/** Landed damage, through applyDefense (Core Sword's DEF-ignore included). */
const landedFor = (p, def, mult, { kit = true } = {}) =>
  applyDefense(rawFor(p, mult, { kit }), (def ?? 0) * (kit ? 1 - p.defIgnore : 1))
/** Final damage a monster's hit deals after DEF, Dread and the Robe cap. */
function takenFor(p, atk, { kit = true } = {}) {
  const mitig = Math.min(0.97, p.playerDefMitigation)
  let dmg = atk * (1 - mitig)
  if (kit) dmg *= 1 - p.incomingCut
  return Math.max(1, Math.min(dmg, p.maxHp * (kit ? p.hitCapPct : 1)))
}

const median = (xs) => { const s = [...xs].sort((a, b) => a - b); return s[Math.floor(s.length / 2)] }

function exchange(p, enemy, opts = {}) {
  const hp = enemy.maxHp ?? enemy.hp
  const basic = landedFor(p, enemy.def, 1, opts)
  const skill = landedFor(p, enemy.def, p.skill.mult, opts)
  const taken = takenFor(p, enemy.atk ?? 0, opts)
  const hitChance = calcPlayerHitChance(p, enemy)
  const monsterHit = calcMonsterHitChance(enemy, p)
  return {
    hp, def: enemy.def ?? 0, atk: enemy.atk ?? 0,
    clearBasic: hp / basic / hitChance,
    clearSkill: hp / skill / hitChance,
    taken, pctHp: taken / p.maxHp,
    die: p.maxHp / taken / monsterHit,
    mitigation: (enemy.def ?? 0) / ((enemy.def ?? 0) + 500),
  }
}

/** Every regular monster a floor can roll, instantiated exactly as spawnEnemy does. */
/**
 * The band the realm applies to this player, through the shipped functions
 * (dreamlandsRealmRatio + dreamlandsBandMultipliers). Exported to the readout
 * so a table can say how much of a fight the band is responsible for.
 */
function realmBand(p) {
  const ratio = dreamlandsRealmRatio(p, SKILL_TABLE, (p.weaponMult ?? 1) * (p.modDamage ?? 1))
  return { ratio, mult: dreamlandsBandMultipliers(ratio) }
}

function floorEnemies(locId, floor, player, { dreamlands = false } = {}) {
  const pool = (regularByLoc[locId] ?? []).filter(
    m => floor >= m.floorRange[0] && floor <= m.floorRange[1] && m.tier !== 'boss')
  const band = dreamlands && player ? realmBand(player).mult : { hp: 1, atk: 1, def: 1 }
  return pool.map((m) => {
    let e = { ...m, ...monsterStatsAtFloor(m, floor) }
    if (dreamlands) {
      // The realm's own band, applied to the stats the curve just produced —
      // exactly what pickDreamlandsMonster does at spawn time.
      e.maxHp = Math.max(1, Math.round(e.hp * band.hp))
      e.hp = e.maxHp
      e.atk = Math.max(1, Math.round(e.atk * band.atk))
      e.def = Math.max(0, Math.round(e.def * band.def))
      return e
    }
    if (!player) return e
    const ratio = enemyPowerRatio(player, locId, floor)
    if (ratio > 1) e = scaleEnemyToPlayer(e, ratio, { hpExp: 0.85, atkExp: 0.4, defExp: 0.2 })
    applyVeteranScaling(e, player)
    return e
  })
}

function poolRow(p, locId, floor, opts = {}) {
  const rows = floorEnemies(locId, floor, p, opts).map(e => ({ e, x: exchange(p, e, opts) }))
  if (!rows.length) return null
  const med = (pick) => median(rows.map(pick))
  return {
    hp: Math.round(med(r => r.x.hp)), def: Math.round(med(r => r.x.def)), atk: Math.round(med(r => r.x.atk)),
    clearBasic: med(r => r.x.clearBasic), clearSkill: med(r => r.x.clearSkill),
    taken: Math.round(med(r => r.x.taken)), pctHp: med(r => r.x.pctHp),
    die: med(r => r.x.die), mitigation: med(r => r.x.mitigation),
  }
}

const f = (x, n = 1) => Number(x).toFixed(n)
const pct = (x) => `${(x * 100).toFixed(0)}%`
const pad = (s, n) => String(s).padStart(n)

console.log('══ 1. the three accounts, as the engine sees them ═══════════════════════')
for (const p of Object.values(PLAYERS)) {
  console.log(
    `${p.label.padEnd(18)} L${p.level} ${p.classId.padEnd(8)} ` +
    `primary ${pad(p.primary, 4)}  crit ${pct(p.critChance)}  HP ${p.maxHp}  ` +
    `DEF ${pad(p.stats.def, 4)} (cuts ${pct(p.playerDefMitigation)} of a hit)  ` +
    `weapon x${p.weaponMult.toFixed(2)}${p.defIgnore ? ` (ignores ${pct(p.defIgnore)} DEF)` : ''}  ` +
    `best skill ${p.skill.name} x${p.skill.mult}`)
}
console.log('   incoming, after everything they carry: ' +
  Object.values(PLAYERS).map(p => `${p.label} ${pct(1 - p.playerDefMitigation)} through DEF` +
    (p.incomingCut ? `, -${pct(p.incomingCut)} Dread` : '') +
    (p.hitCapPct < 1 ? `, no hit above ${pct(p.hitCapPct)} HP` : '')).join(' | '))

// ── the realm's own reference, for scale ───────────────────────────────────
// The Dreamlands' §6 acceptance benchmarks are written against "Aragon" (the
// owner's reference fight: level 200 mage, INT 2133, LCK 374, HP 2815, DEF 750)
// and they measure his BASIC ATTACK. That detail matters more than any other
// number in this file, because every mage in the game fights with skills, and
// one skill is worth two to three of those blows.
const ARAGON = {
  label: 'Aragon', classId: 'mage', level: 200,
  stats: { str: 1000, agi: 569, int: 2133, def: 750, lck: 374, maxHp: 2815, maxMp: 1375 },
  hp: 2815, maxHp: 2815,
  skill: { name: 'Grand Torrent III (best mage skill)', mult: 3.19 },
  weaponMult: 1, defIgnore: 0, incomingCut: 0, hitCapPct: 1, modDamage: 1,
}
ARAGON.primary = ARAGON.stats.int
ARAGON.critChance = Math.min(0.95, 0.05 + ARAGON.stats.lck * 0.002)
ARAGON.critFactor = 1 + ARAGON.critChance * 0.5
ARAGON.playerDefMitigation = Math.min(0.97, ARAGON.stats.def / (ARAGON.stats.def + 500))

console.log('\n══ 1b. the realm\'s own reference vs the top three — turns to clear ═════')
const BANDS = [['cum 1', 'lantern_fields', 1], ['cum 125', 'lantern_fields', 125],
  ['cum 250', 'sleepwood', 125], ['cum 375', 'drowned_chapel', 125], ['cum 500', 'distorted_court', 125]]
for (const [label, place, floor] of BANDS) {
  const row = poolRow(ARAGON, place, floor, { dreamlands: true })
  const cells = [ARAGON, ...Object.values(PLAYERS)].map((p) => {
    const kit = p.weaponMult !== 1 || p.modDamage !== 1
    const basic = landedFor(p, row.def, 1, { kit })
    const skill = landedFor(p, row.def, p.skill.mult, { kit })
    return `${p.label.split(' ')[0].padEnd(14)} ${pad(f(row.hp / basic), 6)} / ${pad(f(row.hp / skill), 6)}`
  })
  console.log(`  ${label.padEnd(8)} HP ${pad(row.hp, 6)} DEF ${pad(row.def, 5)}  |  ${cells.join(' | ')}`)
}
console.log('  (columns are turns to clear with a basic attack / with that account\'s best equipped skill)')

console.log('\n══ 2a. THE CAGED DIMENSION — the endless farm two of the three live in ══')
console.log('    1v1 path: monsterStatsAtFloor → scaleEnemyToPlayer(ratio, caged playerScale) → applyVeteranScaling')
for (const p of Object.values(PLAYERS)) {
  console.log(`\n── ${p.label} (L${p.level}, primary ${p.primary}, power ratio ${f(enemyPowerRatio(p, 'caged_dimension', 1), 1)}x)`)
  console.log('  floor  monsterHP  itsDEF  armour  clear(basic)  clear(skill)    its hit  %ofHP  you die in')
  for (const floor of [1, 124, 319, 1000, 2500, 5000, 9999]) {
    const x = poolRow(p, 'caged_dimension', floor)
    if (!x) continue
    console.log(
      `  ${pad(floor, 5)}  ${pad(x.hp, 9)}  ${pad(x.def, 6)}  ${pad(pct(x.mitigation), 6)}  ` +
      `${pad(f(x.clearBasic), 12)}  ${pad(f(x.clearSkill), 12)}  ${pad(Math.round(x.taken), 8)}  ` +
      `${pad(pct(x.pctHp), 5)}  ${pad(f(x.die), 10)}`)
  }
}

console.log('\n══ 2b. THE DREAMLANDs — the absolute curve, no whale scaling ═══════════')
console.log(`    floor1 ${JSON.stringify(DREAMLAND_DIFFICULTY.floor1)} → floor${DREAMLAND_TOTAL_FLOORS} ${JSON.stringify(DREAMLAND_DIFFICULTY.floor500)}`)
for (const p of Object.values(PLAYERS)) {
  console.log(`\n── ${p.label} (L${p.level}, primary ${p.primary})`)
  console.log('  place/floor      cumul  monsterHP  itsDEF  armour  clear(basic)  clear(skill)    its hit  %ofHP  you die in')
  for (const [place, floors] of [
    ['lantern_fields', [1, 60, 125]],
    ['sleepwood', [60, 125]],
    ['drowned_chapel', [60, 125]],
    ['distorted_court', [60, 125]],
  ]) {
    for (const floor of floors) {
      const x = poolRow(p, place, floor, { dreamlands: true })
      if (!x) continue
      console.log(
        `  ${`${place}/${floor}`.padEnd(16)} ${pad(cumulativeFloor(place, floor), 4)}  ${pad(x.hp, 9)}  ` +
        `${pad(x.def, 6)}  ${pad(pct(x.mitigation), 6)}  ${pad(f(x.clearBasic), 12)}  ` +
        `${pad(f(x.clearSkill), 12)}  ${pad(Math.round(x.taken), 8)}  ${pad(pct(x.pctHp), 5)}  ${pad(f(x.die), 10)}`)
    }
  }
}

// ── the bosses ─────────────────────────────────────────────────────────────
console.log('\n══ 3. BOSSES ════════════════════════════════════════════════════════════')
const BOSS_SLOTS = [
  ['lantern_child', 'lantern_fields', 125],
  ['sleepwood_mother', 'sleepwood', 125],
  ['drowned_choir', 'drowned_chapel', 125],
  ['the_distorted_one', 'distorted_court', 125],
  ['esteria', 'eternal_dungeon', 100],
  ['the_end', 'the_end', 1],
]
const DREAMLAND_PLACES = new Set(['lantern_fields', 'sleepwood', 'drowned_chapel', 'distorted_court'])
for (const [id, locId, floor] of BOSS_SLOTS) {
  const def = getBossById(id)
  const init = initBossFight({ id: 'seed', level: 200, classId: 'mage', stats: {}, activeEffects: [], battleState: {} }, id, floor)
  const base = init.ok ? init.enemy : def
  const baseHp = base.maxHp ?? base.hp
  console.log(`\n${base.name}  [${base.grade ?? def.grade}]  ${locId} floor ${floor} — authored HP ${baseHp} ATK ${base.atk} DEF ${base.def}`)
  for (const p of Object.values(PLAYERS)) {
    const e = { ...base, hp: baseHp, maxHp: baseHp }
    if (DREAMLAND_PLACES.has(locId)) {
      // Champions take the realm's own band (plugins/dungeon.js spawnBoss), not
      // the global player-power scaling.
      const { mult } = realmBand(p)
      e.maxHp = Math.round(e.maxHp * mult.hp)
      e.hp = e.maxHp
      e.atk = Math.max(1, Math.round(e.atk * mult.atk))
      e.def = Math.max(0, Math.round(e.def * mult.def))
    } else {
      const ratio = enemyPowerRatio(p, locId, floor)
      scaleBossToPlayer(e, p, ratio, { baseHits: 12, hitsRatioExp: 0.16, maxHits: 20, defExp: 0.14, atkExp: 0.2, atkCapMult: 1.75 })
      applyVeteranScaling(e, p)
    }
    const x = exchange(p, e)
    console.log(
      `    ${p.label.padEnd(18)} → HP ${pad(Math.round(e.maxHp), 7)} DEF ${pad(Math.round(e.def), 6)} ATK ${pad(Math.round(e.atk), 6)} ` +
      `| dies in ${pad(f(x.clearSkill), 7)} skill turns (${pad(f(x.clearBasic), 7)} basics) | its hit ${pad(Math.round(x.taken), 5)} ` +
      `(${pct(x.pctHp)} HP), you die in ${f(x.die)}`)
  }
}

// ── the solve ──────────────────────────────────────────────────────────────
// What the numbers would have to BE for the strongest account in the game to
// meet a fight instead of a formality. Targets, per pool:
//
//   regular nightmare   ~12 of their skill turns to kill, ~30% of max HP a hit
//   champion / boss     ~25 of their skill turns to kill, ~45% of max HP a hit
//
// DEF is solved through applyDefense's own curve, so the 0.97 ceiling (3% of
// every hit ALWAYS lands) shows up as "impossible" instead of a fantasy number.
// ATK is solved through the player's own mitigation AND the Dark Monarch cut
// AND the Robe of the Dragons' 35%-of-max-HP hit cap, which is the finding that
// matters most: past a point, more ATK changes nothing at all for its wearers.
console.log('\n══ 4. WHAT IT WOULD TAKE — the strongest account, per pool ═════════════')
function solve(p, { hp, def, atk }, { turns = 12, share = 0.30 } = {}) {
  const mitig = Math.min(0.97, p.playerDefMitigation)
  const raw = rawFor(p, p.skill.mult)
  const landed = landedFor(p, def, p.skill.mult)
  const hitChance = 0.99
  const nowTurns = hp / landed / hitChance
  const need = hp / turns / hitChance
  const left = Math.max(0.03, need / raw)
  const defNeed = Math.round(500 * (1 - left) / left)
  const hpNeed = Math.round(landed * turns * hitChance)
  const atkNeed = Math.round(share * p.maxHp / (1 - mitig) / (1 - p.incomingCut))
  const capPoint = Math.round(p.hitCapPct * p.maxHp / (1 - mitig) / (1 - p.incomingCut))
  return { nowTurns, defNeed, hpNeed, atkNeed, capPoint, capped: atk >= capPoint }
}

const POOLS = [
  ['Caged Dimension — every floor above 1 (it is one flat fight)', 'caged_dimension', 319, false],
  ['Dreamlands — Lantern Fields floor 1 (cumulative 1)', 'lantern_fields', 1, true],
  ['Dreamlands — Lantern Fields floor 125 (cumulative 125)', 'lantern_fields', 125, true],
  ['Dreamlands — Distorted Court floor 125 (cumulative 500)', 'distorted_court', 125, true],
]
for (const [label, locId, floor, dreamlands] of POOLS) {
  console.log(`\n${label}`)
  for (const p of Object.values(PLAYERS)) {
    const x = poolRow(p, locId, floor, { dreamlands })
    const r = solve(p, x, { turns: 12, share: 0.30 })
    console.log(
      `  ${p.label.padEnd(18)} today HP ${pad(x.hp, 6)} DEF ${pad(x.def, 5)} ATK ${pad(x.atk, 6)} ` +
      `→ ${pad(f(r.nowTurns), 5)} skill turns, hit = ${pct(x.pctHp)} of HP` +
      `\n     for 12 turns: DEF ${pad(r.defNeed, 6)} (x${f(r.defNeed / Math.max(1, x.def), 2)}) ` +
      `or HP ${pad(r.hpNeed, 7)} (x${f(r.hpNeed / Math.max(1, x.hp), 2)})` +
      `\n     for a 30% hit: ATK ${pad(r.atkNeed, 6)} (x${f(r.atkNeed / Math.max(1, x.atk), 2)}); ` +
      `its Robe caps at ATK ${r.capPoint}${r.capped ? ' — today is ALREADY past it, so every extra ATK is invisible' : ''}`)
  }
}

// ── the recommendation ─────────────────────────────────────────────────────
// The shape the owner asked for: "how strong do you need to buff them in DEF
// and ATK". Everything above says a flat buff cannot fix the Dreamlands' early
// band without walling out the level-100 players it is priced for, so the
// numbers below are stated per band, at the strength the strongest account
// demands, and it is the owner's call how much of that to spend.
//
// Rule used here: hold the pool's HP where it is (or double it where the fight
// is simply too short to be a fight), then solve the DEF that lands the fight
// on `turns`, and the ATK that lands a hit on `share` of the target's max HP,
// respecting the Robe cap that makes anything above it dead weight.
console.log('\n══ 5. HOW FAR TODAY\'S NUMBERS ARE FROM THE TARGET (solved on Yochan) ══')
console.log('   A live readout: the Dreamlands rows below already include the 2026-10-07')
console.log('   retune and its band, the Caged Dimension is untouched. The historical')
console.log('   solve, against the pre-retune numbers, is in docs/top3-balance-report.md.')
const y = PLAYERS.Yochan
function recommend({ hp, def, atk }, { hpMult = 1, turns = 12, share = 0.30 } = {}) {
  const targetHp = Math.round(hp * hpMult)
  const raw = rawFor(y, y.skill.mult)
  const need = targetHp / turns / 0.99
  const left = Math.max(0.03, need / raw)
  const defNeed = Math.round(500 * (1 - left) / left)
  const mitig = Math.min(0.97, y.playerDefMitigation)
  const atkNeed = Math.round(share * y.maxHp / (1 - mitig) / (1 - y.incomingCut))
  const cap = Math.round(y.hitCapPct * y.maxHp / (1 - mitig) / (1 - y.incomingCut))
  return { hp: targetHp, def: defNeed, atk: atkNeed, cap, dead: atk >= cap }
}
console.log('\n  regular nightmares (target 12 of Yochan\'s Thousand Cuts V turns, a 30%-of-HP hit)')
for (const [label, locId, floor, dreamlands] of [
  ['Caged Dimension   (today, floor 319)', 'caged_dimension', 319, false],
  ['Caged Dimension   floor 1000', 'caged_dimension', 1000, false],
  ['Dreamlands cum 1', 'lantern_fields', 1, true],
  ['Dreamlands cum 125', 'lantern_fields', 125, true],
  ['Dreamlands cum 250', 'sleepwood', 125, true],
  ['Dreamlands cum 375', 'drowned_chapel', 125, true],
  ['Dreamlands cum 500', 'distorted_court', 125, true],
]) {
  const x = poolRow(y, locId, floor, { dreamlands })
  const r = recommend(x, { hpMult: 1, turns: 12, share: 0.30 })
  console.log(`    ${label.padEnd(34)} today HP ${pad(x.hp, 6)} DEF ${pad(x.def, 5)} ATK ${pad(x.atk, 6)}` +
    ` →  keep HP, DEF ${pad(r.def, 6)} (x${f(r.def / Math.max(1, x.def), 2)})` +
    ` + ATK ${pad(r.atk, 6)} (x${f(r.atk / Math.max(1, x.atk), 2)})${r.dead ? '  [ATK beyond this is wasted on the Robe]' : ''}`)
}

console.log('\n  champions (target: the number the fight should cost, a hit at the Robe cap)')
const CHAMPS = [
  ['lantern_child', 'Lantern Child', 12, 1.6],
  ['sleepwood_mother', 'Sleepwood Mother', 16, 1.8],
  ['drowned_choir', 'Drowned Choir', 20, 2.0],
  ['the_distorted_one', 'The Distorted One', 26, 2.2],
]
for (const [id, name, turns, hpMult] of CHAMPS) {
  const def = getBossById(id)
  const init = initBossFight({ id: 'seed', level: 200, classId: 'mage', stats: {}, activeEffects: [], battleState: {} }, id, 125)
  const base = init.ok ? init.enemy : def
  const hp = base.maxHp ?? base.hp
  const r = recommend({ hp, def: base.def, atk: base.atk }, { hpMult, turns, share: 0.35 })
  console.log(`    ${name.padEnd(18)} today HP ${pad(hp, 6)} DEF ${pad(base.def, 5)} ATK ${pad(base.atk, 5)}` +
    ` →  HP ${pad(r.hp, 6)} (x${hpMult})  DEF ${pad(r.def, 5)}  ATK ${pad(Math.max(base.atk, r.atk), 5)}` +
    `  [${turns} turns, ~35% of Yochan's HP a hit]`)
}

// ── the sustain check ──────────────────────────────────────────────────────
// Turns-to-die is the wrong number for the two accounts wearing the Dark
// Monarch pack: Dread Sovereign heals them 15% of every hit they LAND, so the
// question is not "how many hits can they take" but "does the monster drain
// them faster than the lifesteal refills them". That is the difference between
// a monster that is dangerous on paper and one that actually kills anybody.
console.log('\n══ 6. SUSTAIN — does the monster actually drain them? ═══════════════════')
for (const [label, locId, floor, dreamlands] of [
  ['Caged Dimension floor 319', 'caged_dimension', 319, false],
  ['Dreamlands cumulative 500', 'distorted_court', 125, true],
  ['Dreamlands cumulative 125', 'lantern_fields', 125, true],
]) {
  console.log(`\n${label}`)
  for (const p of Object.values(PLAYERS)) {
    const rows = floorEnemies(locId, floor, p, { dreamlands }).map(e => exchange(p, e))
    const med = (k) => median(rows.map(r => r[k]))
    const monsterHit = 0.92 - Math.min(0.30, p.stats.agi * 0.001)
    const takenPerTurn = med('taken') * monsterHit
    const dealtPerTurn = (med('hp') / med('clearSkill')) * (p.lifesteal ?? 0)
    const net = takenPerTurn - dealtPerTurn
    const turnsToDie = net > 0 ? p.maxHp / net : Infinity
    console.log(
      `  ${p.label.padEnd(18)} takes ${pad(f(takenPerTurn), 6)}/turn, drinks ${pad(f(dealtPerTurn), 6)}/turn ` +
      `→ net ${pad(f(net), 6)} (${net > 0 ? 'losing' : 'gaining'}) | dies in ${f(turnsToDie)} turns, kills in ${f(med('clearSkill'))}`)
  }
}
