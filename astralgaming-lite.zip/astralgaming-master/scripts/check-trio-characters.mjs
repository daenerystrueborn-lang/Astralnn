import assert from 'node:assert/strict'
import { existsSync, rmSync } from 'node:fs'
import { characterMap } from '../lib/game-data.js'
import { isMondBuyable, mondPriceFor } from '../lib/monds.js'
import { getSpinBanner } from '../lib/spin-banners.js'
import { chanceForExclusiveSpin, releaseExclusiveSpinLock } from '../lib/season-engine.js'
import {
  setCharacterPreorderReleaseAt,
  ONE_DAY_MS,
} from '../lib/character-preorders.js'
import characterPlugin from '../plugins/character.js'
import preorderPlugin from '../plugins/preorder.js'
import remiSpinPlugin from '../plugins/remi-spin.js'
import attackPlugin from '../plugins/attack.js'
import windupPlugin from '../plugins/windup.js'
import trickPlugin from '../plugins/trick.js'
import heartlockPlugin from '../plugins/heartlock.js'
import pvpPlugin from '../plugins/pvp.js'
import profilePlugin from '../plugins/profile.js'
import mePlugin from '../plugins/me.js'
import storePlugin from '../plugins/store.js'
import shopPlugin from '../plugins/shop.js'
import pickEffectPlugin from '../plugins/pickeffect.js'
import { equippedProfileEffect, equippedProfileFrame } from '../lib/profile-cosmetics.js'
import { applyIncomingDamage } from '../lib/character-abilities.js'
import { addStatusEffect } from '../lib/effects.js'
import { saveGroupSettings } from '../lib/group-settings.js'

const EXPECTED_PNGS = {
  cardia: 'https://i.postimg.cc/gk6ZwSLw/Cardia-solars-2026-11-23-18-52-32-075094.png',
  aimiya: 'https://i.postimg.cc/BZzFn9bj/Aimiya-gems-2026-11-23-18-52-32-663099.png',
  remi: 'https://i.postimg.cc/pXnF9G50/Remi-Gems-2026-11-23-18-52-33-206083.png',
}

// ── 1. Verify Exclusive Flags, PostImg PNGs & Minimal Period-Free Copy ────
assert(!existsSync('./lib/assets/characters'), 'Old lib/assets/characters .jpg folder must be gone')
assert(!existsSync('./images/characters'), 'Old images/characters .jpg folder must be gone')

for (const id of ['cardia', 'aimiya', 'remi']) {
  const c = characterMap[id]
  assert(c, `Missing ${id} in characterMap`)
  assert.equal(c.exclusive, true, `${id} must be exclusive: true`)
  assert.equal(c.image, EXPECTED_PNGS[id], `Expected exact PostImg PNG URL for ${id}`)
  assert(!c.description.includes('.'), `${id} description must have no full stops`)
  assert(!c.quote.includes('.'), `${id} quote must have no full stops`)
  assert(!c.ability.name.includes('.'), `${id} ability.name must have no full stops`)
  assert(!c.ability.flavor.includes('.'), `${id} ability.flavor must have no full stops`)
  for (const line of c.quotes ?? []) assert(!line.includes('.'), `${id} quotes entry has period: ${line}`)
  for (const line of c.ability.quote ?? []) assert(!line.includes('.'), `${id} ability.quote entry has period: ${line}`)
  for (const line of c.ability.howItWorks ?? []) assert(!line.includes('.'), `${id} howItWorks entry has period: ${line}`)
  const combined = JSON.stringify({ d: c.description, q: c.quote, qs: c.quotes, p: c.personality, a: c.ability })
  assert(!/tick-tock|shh|ta-da|oops|poof|—/i.test(combined), `${id} contains forbidden sound/em-dash`)
}
assert.equal(characterMap.amiya.name, 'Amiya, the God of Stars', 'Existing amiya must remain untouched')
assert.equal(characterMap.aimiya.name, 'Aimiya', 'New aimiya must be distinct')
console.log('✅ 1. All 3 exclusive flags, PostImg PNG URLs, and minimal period-free/sound-free copy verified!')

// ── 2. Verify Mond Restrictions, 1-of-1 Exclusive Pre-Order Lock & 24h Unlock
assert.equal(isMondBuyable(characterMap.cardia), false)
assert.equal(mondPriceFor(characterMap.cardia), null)
assert.equal(isMondBuyable(characterMap.aimiya), false)
assert.equal(mondPriceFor(characterMap.aimiya), null)
assert.equal(isMondBuyable(characterMap.remi), true)
assert.equal(mondPriceFor(characterMap.remi), 5)

const db = {
  data: {
    users: {},
    guilds: {
      ember: { id: 'ember', name: 'EMBER', emoji: '🔥', members: [] },
    },
    exclusiveSpinWinners: {},
  },
  write: async () => {},
}

function makePlayer(jid, name, extra = {}) {
  const p = {
    id: jid,
    name,
    raceId: 'human',
    classId: 'warrior',
    level: 100,
    exp: 0,
    hp: 2500,
    maxHp: 2500,
    mp: 800,
    maxMp: 800,
    stats: { str: 240, agi: 220, int: 250, def: 160, lck: 140 },
    wallet: { solars: 100_000_000, gems: 2000, monds: 20 },
    stamina: { current: 100, max: 100, updatedAt: Date.now() },
    jobLevel: 2,
    dungeonProgress: { goblin_cave: { highestFloor: 15 } },
    survivalProgress: { questsClaimed: 2 },
    ownedCharacters: [],
    equippedCharacter: null,
    skills: ['fireball'],
    equippedSkills: ['fireball'],
    inventory: [],
    equipment: {},
    activeEffects: [],
    currentLocation: 'goblin_cave',
    ...extra,
  }
  db.data.users[jid] = p
  return p
}

function makeCtx(jid, cmd, args = [], extra = {}) {
  const logs = []
  const mediaPayloads = []
  const ctx = {
    db,
    from: jid,
    sender: 'test_arena@g.us',
    jid,
    cmd,
    args,
    platform: 'whatsapp',
    isGroup: true,
    get player() { return db.data.users[jid] },
    logs,
    mediaPayloads,
    reply: async (text) => { logs.push(String(text)); return {} },
    replyImage: async (img, cap) => { mediaPayloads.push({ type: 'image', img, cap }); logs.push(String(cap ?? '')); return {} },
    sock: {
      sendMessage: async (_to, payload) => {
        mediaPayloads.push(payload)
        logs.push(String(payload?.caption ?? payload?.text ?? ''))
        return {}
      },
    },
    ...extra,
  }
  return ctx
}

const baseNow = Date.now()
setCharacterPreorderReleaseAt('cardia', baseNow + ONE_DAY_MS)
setCharacterPreorderReleaseAt('aimiya', baseNow + ONE_DAY_MS)

const buyer = makePlayer('buyer@s.whatsapp.net', 'Kael')
const secondBuyer = makePlayer('second@s.whatsapp.net', 'Nyx', {
  wallet: { solars: 100_000_000, gems: 3000, monds: 30 },
})

{
  const c1 = makeCtx(buyer.id, 'character', ['buy', 'cardia', 'monds'])
  await characterPlugin.run(c1)
  assert(c1.logs.join('\n').includes('cannot be bought with Monds'), 'Cardia must refuse Monds')
  assert.equal(buyer.wallet.monds, 20)

  const c2 = makeCtx(buyer.id, 'preorder', ['aimiya', 'monds'])
  await preorderPlugin.run(c2)
  assert(c2.logs.join('\n').includes('cannot be bought with Monds'), 'Aimiya must refuse Monds')
  assert.equal(buyer.wallet.monds, 20)
}

{
  const cCardia = makeCtx(buyer.id, 'preorder', ['cardia'])
  await preorderPlugin.run(cCardia)
  assert(cCardia.logs.join('\n').includes('PRE-ORDER LOCKED'), 'Cardia pre-order receipt expected')
  assert.equal(buyer.wallet.solars, 30_000_000, '70M Solars deducted')
  assert(!buyer.ownedCharacters.includes('cardia'), 'Not yet in ownedCharacters before 24h expiry')

  // Second player tries to pre-order exclusive Cardia -> MUST BE REFUSED with 0 Solars deducted!
  const cCardiaSecond = makeCtx(secondBuyer.id, 'preorder', ['cardia'])
  await preorderPlugin.run(cCardiaSecond)
  assert(cCardiaSecond.logs.join('\n').includes('one-of-one exclusive'), 'Second buyer must be blocked on exclusive Cardia')
  assert.equal(secondBuyer.wallet.solars, 100_000_000, 'Second buyer must spend 0 Solars')

  const cEqEarly = makeCtx(buyer.id, 'character', ['equip', 'cardia'])
  await characterPlugin.run(cEqEarly)
  assert(cEqEarly.logs.join('\n').includes('is on Pre-Order'), 'Equip before release must show countdown')

  const cAimiya = makeCtx(buyer.id, 'character', ['buy', 'aimiya'])
  await characterPlugin.run(cAimiya)
  assert(cAimiya.logs.join('\n').includes('PRE-ORDER LOCKED'), 'Aimiya pre-order receipt expected')
  assert.equal(buyer.wallet.gems, 1100, '900 Gems deducted')

  // Second player tries to pre-order exclusive Aimiya -> MUST BE REFUSED with 0 Gems deducted!
  const cAimiyaSecond = makeCtx(secondBuyer.id, 'character', ['buy', 'aimiya'])
  await characterPlugin.run(cAimiyaSecond)
  assert(cAimiyaSecond.logs.join('\n').includes('one-of-one exclusive'), 'Second buyer must be blocked on exclusive Aimiya')
  assert.equal(secondBuyer.wallet.gems, 3000, 'Second buyer must spend 0 Gems')

  setCharacterPreorderReleaseAt('cardia', Date.now() - 1000)
  setCharacterPreorderReleaseAt('aimiya', Date.now() - 1000)

  const cEqCardia = makeCtx(buyer.id, 'character', ['equip', 'cardia'])
  await characterPlugin.run(cEqCardia)
  assert(buyer.ownedCharacters.includes('cardia'), 'Cardia auto-delivered after 24h')
  assert(buyer.ownedCharacters.includes('aimiya'), 'Aimiya auto-delivered after 24h')
  assert.equal(buyer.equippedCharacter, 'cardia', 'Cardia equipped cleanly')
}
console.log('✅ 2. 1-of-1 exclusive pre-order locks, 70M Solars / 900 Gems pricing, Mond blocks, and 24h auto-unlock verified!')

// ── 3. Verify Remi Spin (2 Gems, 1-234 deadzone, 300 cap) & 5-Mond Buy ────
{
  const remiBanner = getSpinBanner('remi')
  assert.equal(remiBanner.costPerSpin, 2)
  assert.equal(remiBanner.deadZoneUntil, 234)
  assert.equal(remiBanner.maxSpinsPerPlayer, 300)
  assert.equal(remiBanner.pityAt, 300)

  for (let s = 1; s <= 234; s++) {
    const ch = chanceForExclusiveSpin(s, remiBanner)
    assert.equal(ch, 0, `Spin ${s} must have 0 chance inside deadzone 1-234`)
  }
  assert(chanceForExclusiveSpin(235, remiBanner) > 0, 'Spin 235 must be live')

  const spinner = makePlayer('spinner@s.whatsapp.net', 'Lyra', { wallet: { solars: 0, gems: 1000, monds: 10 } })
  while ((spinner.remiSpins ?? 0) < 234) {
    const step = Math.min(10, 234 - (spinner.remiSpins ?? 0))
    const cSpin = makeCtx(spinner.id, 'remi-spin', [String(step)])
    await remiSpinPlugin.run(cSpin)
  }
  assert.equal(spinner.remiSpins, 234)
  assert(!spinner.ownedCharacters.includes('remi'), 'Remi cannot be won in spins 1-234')
  assert.equal(spinner.wallet.gems, 1000 - 234 * 2, '2 Gems per spin charged accurately')

  while (!spinner.ownedCharacters.includes('remi') && (spinner.remiSpins ?? 0) < 300) {
    const cSpin = makeCtx(spinner.id, 'remi-spin', ['10'])
    await remiSpinPlugin.run(cSpin)
  }
  assert(spinner.ownedCharacters.includes('remi'), 'Remi guaranteed by spin 300')
  assert(spinner.remiSpins >= 235 && spinner.remiSpins <= 300)

  releaseExclusiveSpinLock(db, 'remi')
  delete db.data.users[spinner.id]
  const mondBuyer = makePlayer('mondbuyer@s.whatsapp.net', 'Vex', { wallet: { solars: 0, gems: 0, monds: 8 } })
  const cMond = makeCtx(mondBuyer.id, 'character', ['buy', 'remi'])
  await characterPlugin.run(cMond)
  assert(mondBuyer.ownedCharacters.includes('remi'), 'Remi bought for 5 Monds')
  assert.equal(mondBuyer.wallet.monds, 3, '5 Monds deducted')
}
console.log('✅ 3. Remi spin banner (2 Gems, 1-234 deadzone, 300 pity) & 5-Mond exclusive buy verified!')

// ── 4. Verify .profile Fix, .me Circular PFP + GIF Effects & Cosmetics Store
{
  const nieves = makePlayer('nieves@s.whatsapp.net', 'Nieves', {
    guildId: 'ember',
    classId: 'mage',
    pvpRating: 1000,
    pvpWins: 5,
    pvpLosses: 2,
    wallet: { solars: 500_000, gems: 300, monds: 0 },
  })
  db.data.guilds.ember.members.push(nieves.id)

  // 4a. Test .profile (previously crashed with ReferenceError: formatAffinityBadgeLine is not defined)
  const cProf = makeCtx(nieves.id, 'profile', [])
  await profilePlugin.run(cProf)
  assert(cProf.logs.join('\n').includes('Nieves'), '.profile must render player profile without crashing')

  // 4b. Test .me static PNG with circular PFP straddling banner
  const cMeStatic = makeCtx(nieves.id, 'me', [])
  await mePlugin.run(cMeStatic)
  assert(cMeStatic.mediaPayloads.length > 0, '.me must emit an image payload')
  const staticBuf = cMeStatic.mediaPayloads[0]?.img ?? cMeStatic.mediaPayloads[0]?.image
  assert(Buffer.isBuffer(staticBuf) && staticBuf.subarray(1, 4).toString('ascii') === 'PNG', '.me static output must be a PNG buffer')

  // 4c. Test .shop cosmetics -> routes to Cosmetics & GIF Store shelf PNG
  const cShopCos = makeCtx(nieves.id, 'shop', ['cosmetics'])
  await shopPlugin.run(cShopCos)
  assert(cShopCos.logs.join('\n').includes('COSMETICS & GIF EFFECTS STORE'), '.shop cosmetics must render open store shelf')

  // 4d. Buy & equip an Animated GIF Effect (fx_astral_butterflies) and verify .me outputs animated GIF!
  const cBuyFx = makeCtx(nieves.id, 'store', ['buy', 'fx_astral_butterflies'])
  await storePlugin.run(cBuyFx)
  assert((nieves.profileCosmetics?.effects ?? []).includes('fx_astral_butterflies'), 'fx_astral_butterflies must be added to profileCosmetics.effects')

  const cEqFx = makeCtx(nieves.id, 'store', ['equip', 'fx_astral_butterflies'])
  await storePlugin.run(cEqFx)
  assert.equal(nieves.profileEffectId, 'fx_astral_butterflies')
  assert.equal(equippedProfileEffect(nieves)?.style, 'butterflies')

  // Test .pickeffect list & equip as well
  const cPickFx = makeCtx(nieves.id, 'pickeffect', [])
  await pickEffectPlugin.run(cPickFx)
  assert(cPickFx.logs.join('\n').toLowerCase().includes('effect'), '.pickeffect list must render')

  // Run .me now -> must emit animated GIF (converted to MP4/GIF via sendGif; let's verify caption & GIF payload)
  const cMeAnim = makeCtx(nieves.id, 'me', [])
  await mePlugin.run(cMeAnim)
  assert(cMeAnim.mediaPayloads.length > 0, 'Animated .me with GIF effect must emit media')

  // Also buy & equip a Fluid Frame via .shop buy frame_sakura_bloom
  const cShopBuyFrame = makeCtx(nieves.id, 'shop', ['buy', 'frame_sakura_bloom'])
  await shopPlugin.run(cShopBuyFrame)
  assert((nieves.profileCosmetics?.frames ?? []).includes('frame_sakura_bloom'), '.shop buy frame_sakura_bloom must delegate to cosmetic store')
}
console.log('✅ 4. .profile fix, .me circular PFP + clean guild tag, GIF effects, and Cosmetics Store verified!')

// ── 5. Verify DUNGEON Battle Mechanics & Visible Character Text ───────────
for (const charId of ['cardia', 'aimiya', 'remi']) {
  const dPlayer = makePlayer(`d_${charId}@s.whatsapp.net`, `Hero_${charId}`, {
    ownedCharacters: [charId],
    equippedCharacter: charId,
  })
  dPlayer.inBattle = true
  dPlayer.inDungeon = true
  dPlayer.dungeonFloor = 10
  dPlayer.battleState = {
    type: 'dungeon',
    turn: 1,
    enemy: {
      id: 'shadow_drake',
      name: 'Shadow Drake',
      emoji: '🐉',
      hp: 16000,
      maxHp: 16000,
      atk: 380,
      def: 120,
      agi: 90,
      exp: 100,
      gold: 100,
      activeEffects: [{ type: 'strengthen', value: 25, remaining: 2 }],
    },
  }
  if (charId === 'aimiya') {
    addStatusEffect(dPlayer, { type: 'burn', amount: 80, duration: 3, sourceId: 'test_burn' })
  }

  const activePlugin = charId === 'cardia' ? windupPlugin : charId === 'aimiya' ? trickPlugin : heartlockPlugin
  const cAct = makeCtx(dPlayer.id, activePlugin.name, [])
  await activePlugin.run(cAct)
  const actOut = cAct.logs.join('\n')

  if (charId === 'cardia') {
    assert(actOut.includes('CARDIA · GRAND ESCAPEMENT'), 'Cardia active header missing in Dungeon')
    assert(actOut.includes('turn locked'), 'Enemy turn must be held on Cardia .windup in Dungeon')
    assert(actOut.includes('(Cardia)'), 'Cardia live HUD missing in Dungeon')

    dPlayer.battleState.enemy.hp = 19000
    dPlayer.battleState.enemy.maxHp = 19000
    const cAtk1 = makeCtx(dPlayer.id, 'attack', [])
    await attackPlugin.run(cAtk1)
    assert(cAtk1.logs.join('\n').includes('Grand Escapement'), 'Turn 1 after .windup must hold enemy')

    dPlayer.battleState.enemy.hp = 19000
    const cAtk2 = makeCtx(dPlayer.id, 'attack', [])
    await attackPlugin.run(cAtk2)
    assert(cAtk2.logs.join('\n').includes('Grand Escapement'), 'Turn 2 after .windup must hold enemy')
  }

  if (charId === 'aimiya') {
    assert(actOut.includes('AIMIYA · CARNIVAL INVERSION'), 'Aimiya active header missing in Dungeon')
    assert(actOut.includes('Curses Returned'), 'Aimiya active curse flip missing in Dungeon')
    assert(actOut.includes('(Aimiya)'), 'Aimiya live HUD missing in Dungeon')

    addStatusEffect(dPlayer, { type: 'poison', amount: 75, duration: 3, sourceId: 'test_poison' })
    dPlayer.battleState.enemy.hp = 19000
    dPlayer.battleState.enemy.maxHp = 19000
    const cAtkAim = makeCtx(dPlayer.id, 'attack', [])
    await attackPlugin.run(cAtkAim)
    assert(cAtkAim.logs.join('\n').includes('Affliction Flip'), 'Aimiya passive affliction flip missing in Dungeon')

    dPlayer.battleState.aimiya.jesterHexActive = false
    const intercept = applyIncomingDamage(dPlayer, 1500, dPlayer.battleState, true)
    assert.equal(intercept.damage, 0, 'Confetti Hat-Trick must swallow heavy blow for 0 dmg')
    assert(intercept.message.includes('Confetti Hat-Trick'), 'Confetti Hat-Trick text missing')
  }

  if (charId === 'remi') {
    assert(actOut.includes('REMI · KEY OF THE FIFTH HEART'), 'Remi active header missing in Dungeon')
    assert(actOut.includes('Black Rose'), 'Remi Black Rose text missing in Dungeon')
    assert(actOut.includes('(Remi)'), 'Remi live HUD missing in Dungeon')

    const fatal = applyIncomingDamage(dPlayer, 99999, dPlayer.battleState, true)
    assert(dPlayer.hp > 0, 'Remi Scarlet Padlock must prevent lethal death!')
    assert(fatal.message.includes('Scarlet Padlock Shattered'), 'Remi Padlock save text missing')
    assert(fatal.message.includes('4/5 Locks'), 'Remi padlock counter 4/5 missing')
  }
}
console.log('✅ 5. Dungeon combat abilities, passives, saves, and clean battle text verified for all 3 characters!')

// ── 6. Verify PVP Duel Mechanics & Visible Character Text ─────────────────
{
  await saveGroupSettings('test_arena@g.us', (s) => { s.pvpEnabled = true })

  const pCardia = makePlayer('pvp_cardia@s.whatsapp.net', 'Chronos', {
    ownedCharacters: ['cardia'],
    equippedCharacter: 'cardia',
    hp: 6000, maxHp: 6000,
  })
  const pRemi = makePlayer('pvp_remi@s.whatsapp.net', 'Scarlet', {
    ownedCharacters: ['remi'],
    equippedCharacter: 'remi',
    hp: 6000, maxHp: 6000,
  })

  pRemi.pvpChallenge = { fromJid: pCardia.id, expiresAt: Date.now() + 60_000 }
  const cAccept = makeCtx(pRemi.id, 'pvp', ['accept'])
  await pvpPlugin.run(cAccept)
  const acceptText = cAccept.logs.join('\n')
  assert(acceptText.includes('Cardia · Grand Escapement Ready'), 'Cardia opening line missing in PvP accept')
  assert(acceptText.includes('Remi · Five Scarlet Padlocks Sealed'), 'Remi opening line missing in PvP accept')

  const cWind = makeCtx(pCardia.id, 'windup', [])
  await windupPlugin.run(cWind)
  const windPvpText = cWind.logs.join('\n')
  assert(windPvpText.includes('GRAND ESCAPEMENT'), 'Cardia Grand Escapement text missing in PvP')
  assert(windPvpText.includes('(Cardia)'), 'Cardia HUD missing in PvP status footer')
  assert(windPvpText.includes('(Remi)'), 'Remi HUD missing in PvP status footer')
  assert.equal(pCardia.battleState.myTurn, true, 'Cardia must keep turn #1 after .windup in PvP')
  assert.equal(pRemi.battleState.myTurn, false)

  pRemi.hp = 6000
  const cConsec1 = makeCtx(pCardia.id, 'pvp', ['attack'])
  await pvpPlugin.run(cConsec1)
  assert.equal(pCardia.battleState.myTurn, true, 'Cardia must keep turn #2 after first follow-up in PvP')

  pRemi.hp = 6000
  const cConsec2 = makeCtx(pCardia.id, 'pvp', ['attack'])
  await pvpPlugin.run(cConsec2)
  assert.equal(pCardia.battleState.myTurn, false, 'Turn passes after 2 consecutive follow-up turns')
  assert.equal(pRemi.battleState.myTurn, true, 'Remi now holds the turn')

  pCardia.hp = 6000
  const cHeart = makeCtx(pRemi.id, 'heartlock', [])
  await heartlockPlugin.run(cHeart)
  const heartPvpText = cHeart.logs.join('\n')
  assert(heartPvpText.includes('KEY OF THE FIFTH HEART'), 'Remi Key of the Fifth Heart text missing in PvP')
  assert(heartPvpText.includes('Fifth-Heart Seal'), 'Remi Fifth-Heart Seal text missing in PvP')
  assert(pCardia.battleState.remiSealedUntilTurn > pCardia.battleState.turn, 'Opponent must be sealed by Remi')

  const pAimiya = makePlayer('pvp_aimiya@s.whatsapp.net', 'Jester', {
    ownedCharacters: ['aimiya'],
    equippedCharacter: 'aimiya',
    hp: 2000, maxHp: 6000,
  })
  const pFoe = makePlayer('pvp_foe@s.whatsapp.net', 'Rival', {
    ownedCharacters: [],
    equippedCharacter: null,
    hp: 6000, maxHp: 6000,
  })
  pFoe.pvpChallenge = { fromJid: pAimiya.id, expiresAt: Date.now() + 60_000 }
  const cAcc2 = makeCtx(pFoe.id, 'pvp', ['accept'])
  await pvpPlugin.run(cAcc2)
  assert(cAcc2.logs.join('\n').includes('Aimiya · Carnival Inversion Active'), 'Aimiya opening line missing in PvP')

  const cTrick = makeCtx(pAimiya.id, 'trick', [])
  await trickPlugin.run(cTrick)
  const trickPvpText = cTrick.logs.join('\n')
  assert(trickPvpText.includes('CARNIVAL INVERSION'), 'Aimiya .trick text missing in PvP')
  assert(trickPvpText.includes('Reversed Fortunes'), 'Aimiya HP lead reversal missing in PvP')
  assert(trickPvpText.includes('(Aimiya)'), 'Aimiya HUD missing in PvP status footer')

  await saveGroupSettings('test_arena@g.us', (s) => { delete s.pvpEnabled })
}

rmSync('./data/character-preorder-releases.json', { force: true })
console.log('✅ 6. PvP duel opening, passives, actives, turn-stealing, seals, and clean battle text verified!')
console.log('\n🎉 ALL INTEGRATION & COMBAT TESTS PASSED 100%!')
