#!/usr/bin/env node
// Original, deterministic default artwork. Run when changing the design and
// commit both PNGs: deployed renderers must not generate/write assets at boot.
import { createCanvas } from '@napi-rs/canvas'
import { mkdir, writeFile } from 'node:fs/promises'

const dir = new URL('../lib/assets/profile/', import.meta.url)
await mkdir(dir, { recursive: true })

const avatar = createCanvas(256, 256)
const a = avatar.getContext('2d')
const avatarBg = a.createLinearGradient(0, 0, 256, 256)
avatarBg.addColorStop(0, '#192e54')
avatarBg.addColorStop(1, '#356591')
a.fillStyle = avatarBg
a.fillRect(0, 0, 256, 256)
a.strokeStyle = '#ebc27a'
a.lineWidth = 3
a.beginPath()
a.arc(128, 128, 107, 0, Math.PI * 2)
a.stroke()
a.fillStyle = '#f7e7c5'
a.beginPath()
a.arc(128, 94, 35, 0, Math.PI * 2)
a.fill()
a.beginPath()
a.ellipse(128, 195, 69, 55, 0, Math.PI, Math.PI * 2)
a.fill()
await writeFile(new URL('default-pfp.png', dir), avatar.toBuffer('image/png'))

const banner = createCanvas(1024, 512)
const b = banner.getContext('2d')
const bannerBg = b.createLinearGradient(0, 512, 1024, 0)
bannerBg.addColorStop(0, '#182943')
bannerBg.addColorStop(0.6, '#305c80')
bannerBg.addColorStop(1, '#69899c')
b.fillStyle = bannerBg
b.fillRect(0, 0, 1024, 512)
let seed = 73
const random = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 2 ** 32 }
for (let i = 0; i < 160; i++) {
  const x = random() * 1024
  const y = random() * 512
  const radius = 0.6 + random() * 1.8
  b.fillStyle = `rgba(247,231,197,${0.25 + random() * 0.55})`
  b.beginPath()
  b.arc(x, y, radius, 0, Math.PI * 2)
  b.fill()
}
const glow = b.createRadialGradient(780, 160, 1, 780, 160, 170)
glow.addColorStop(0, 'rgba(247,213,146,0.25)')
glow.addColorStop(1, 'rgba(247,213,146,0)')
b.fillStyle = glow
b.fillRect(610, 0, 340, 330)
b.strokeStyle = '#ebc27a'
b.lineWidth = 2
b.beginPath()
b.arc(780, 160, 62, 0, Math.PI * 2)
b.stroke()
for (let i = 0; i < 8; i++) {
  const angle = i * Math.PI / 4
  b.beginPath()
  b.moveTo(780 + Math.cos(angle) * 75, 160 + Math.sin(angle) * 75)
  b.lineTo(780 + Math.cos(angle) * 87, 160 + Math.sin(angle) * 87)
  b.stroke()
}
await writeFile(new URL('default-banner.png', dir), banner.toBuffer('image/png'))
console.log('Wrote lib/assets/profile/default-{pfp,banner}.png')
