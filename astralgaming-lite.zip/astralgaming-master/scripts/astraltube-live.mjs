#!/usr/bin/env node
/**
 * astraltube-live.mjs — the ASTRALTUBE front page, in a terminal.
 *
 * Same idea as scripts/astratok-live.mjs: drive the SAME engine the bot drives
 * and draw it, so the pacing can be looked at without a phone. What you are
 * checking here is not the art, it is the SHAPE: does a video look dead for
 * three hours and then explode, or does it climb smoothly? Both are legitimate
 * answers and only a timeline makes it obvious which one the numbers produce.
 *
 * HOW TO RUN IT
 *   node scripts/astraltube-live.mjs                     demo set, straight away
 *   node scripts/astraltube-live.mjs --followers 42000   a bigger channel
 *   node scripts/astraltube-live.mjs --seed 7            replay an exact run
 *   node scripts/astraltube-live.mjs --frame             one still, then exit
 *   node scripts/astraltube-live.mjs --style board|grid|stats
 *   node scripts/astraltube-live.mjs --no-color          plain text
 *
 * STYLES
 *   grid   the homepage: a shelf of video cards. The default.
 *   board  the leaderboard: one row per video, ranked by views.
 *   stats  one video, followed over time. This is the pacing view.
 */

import { createVideo, videoSnapshot, rankVideos } from '../lib/astraltube/video.js'
import { count, LUCK_TIERS, viewPayout, viewsAt } from '../lib/astraltube/economy.js'

/* ──────────────────────────────── args ──────────────────────────────────── */

const argv = process.argv.slice(2)
const flag = (name, fallback = null) => {
  const i = argv.indexOf(`--${name}`)
  if (i < 0) return fallback
  const next = argv[i + 1]
  return next && !next.startsWith('--') ? next : true
}
const num = (name, fallback) => {
  const v = flag(name)
  return v == null || v === true ? fallback : Number(v)
}

export const STYLES = ['grid', 'board', 'stats']

export const OPTIONS = {
  followers: num('followers', 12_400),
  seed: num('seed', 7),
  style: String(flag('style', 'grid')),
  color: flag('no-color', false) !== true,
  frame: flag('frame', false) === true,
  frames: num('frames', 0),
  hours: num('hours', 24),
}

/* ─────────────────────────────── colour ─────────────────────────────────── */

const COLORS = {
  reset: '\x1b[0m', bold: '\x1b[1m', dim: '\x1b[2m',
  red: '\x1b[31m', green: '\x1b[32m', yellow: '\x1b[33m',
  magenta: '\x1b[35m', cyan: '\x1b[36m', white: '\x1b[37m',
  brightRed: '\x1b[91m', brightGreen: '\x1b[92m', brightYellow: '\x1b[93m',
  brightMagenta: '\x1b[95m', brightCyan: '\x1b[96m',
}

let USE_COLOR = false
export function setColor(on) { USE_COLOR = !!on }
const c = (name, text) => (USE_COLOR && COLORS[name] ? `${COLORS[name]}${text}${COLORS.reset}` : String(text))

/* ──────────────────────────────── width ─────────────────────────────────── */

const strip = (s) => String(s).replace(/\x1b\[[0-9;]*m/g, '')

function cellWidth(ch) {
  const code = ch.codePointAt(0)
  if (code === 0xfe0f || code === 0x200d) return 0
  if (code >= 0x1f300 && code <= 0x1faff) return 2
  if (code >= 0x2600 && code <= 0x27bf) return 2
  return 1
}

export function displayWidth(s) {
  let w = 0
  for (const ch of strip(s)) w += cellWidth(ch)
  return w
}

const pad = (s, width) => s + ' '.repeat(Math.max(0, width - displayWidth(s)))
const padStart = (s, width) => ' '.repeat(Math.max(0, width - displayWidth(s))) + s

export function clip(s, width) {
  if (displayWidth(s) <= width) return s
  let out = ''
  let w = 0
  for (const ch of strip(s)) {
    const cw = cellWidth(ch)
    if (w + cw > width - 1) break
    out += ch
    w += cw
  }
  return out + '…'
}

/* ──────────────────────────────── the mark ──────────────────────────────── */

/** The ASTRALTUBE wordmark: a play triangle and a star, in ASCII. */
export const WORDMARK = '▶✦ ASTRALTUBE ✦'

/* ─────────────────────────────── the data ───────────────────────────────── */

/** A demo library, so the renderer has something to draw. */
export function demoVideos({ followers = 12_400, seed = 7, keepFresh = false } = {}) {
  let s = Math.abs(seed) % 2147483647 || 1
  const rng = () => { s = (s * 16807) % 2147483647; return s / 2147483647 }

  const titles = [
    'floor 40 solo, no heals',
    'the boss that would not die',
    'a quiet stream at 3am',
    'my worst run ever (still won)',
    'speedrun attempt number nine',
    'chat carried me, honestly',
    'one hp for eleven minutes',
  ]

  return titles.map((title, i) => {
    const unlock = {
      id: `demo_${i}`,
      playerId: `demo_${i}`,
      playerName: ['Dawnblade', 'Ashfall', 'Noctis', 'Wren'][i % 4],
      followers: Math.round(followers * (0.4 + rng() * 1.6)),
      streamMinutes: 20,
      streamPeak: Math.round(200 + rng() * 3000),
      earnedAt: Date.now() - (i + 1) * 3_600_000,
    }
    const v = createVideo({ unlock, title, rng })
    // The first video stays at the moment of publishing when asked, so the
    // stats view has a whole life to draw rather than a finished one.
    if (keepFresh && i === 0) return v
    // Advance each video to a plausible point in its life.
    v.publishedAt = Date.now() - Math.round(rng() * 30 * 3_600_000)
    v.lastTickAt = v.publishedAt
    const mins = (Date.now() - v.publishedAt) / 60_000
    const { tickVideo } = { tickVideo: null }
    // Roll forward by hand: same maths as the engine, no store involved.
    const frac = 1 - Math.pow(2, -mins / (90 * (v.multiplier >= 40 ? 1.8 : 1)))
    v.views = Math.round(v.targetViews * Math.min(1, frac))
    v.earned = viewPayout(v.views)
    v.likes = Math.round(v.views / 22)
    v.peakConcurrent = Math.max(1, Math.round(v.views / 400))
    return v
  })
}

/* ─────────────────────────────── renderers ──────────────────────────────── */

/**
 * grid — the homepage.
 *
 * Each card is three lines: the title, the numbers, and the channel. No boxes,
 * because a shelf of boxes reads as a table and a shelf of rows reads as a feed.
 */
export function gridLines(videos, width) {
  const sorted = rankVideos(videos.map(v => videoSnapshot(v)), { by: 'trending' })
  const out = []
  out.push(c('brightMagenta', WORDMARK) + '   ' + c('dim', 'the realm is watching'))
  out.push(c('dim', '─'.repeat(width)))
  out.push('')
  out.push(c('bold', '🔥 TRENDING NOW'))
  out.push('')
  for (const v of sorted.slice(0, 7)) {
    out.push('  ' + c('brightRed', '▶') + ' ' + c('white', clip(v.title, width - 6)))
    out.push(
      '     ' + c('dim', clip(v.playerName, 14)) + '  ' +
      c('brightCyan', '👁 ' + padStart(v.viewsLabel, 6)) + '  ' +
      c('brightYellow', '☀ ' + padStart(count(v.earned), 6)) + '  ' +
      c('dim', v.lengthLabel) + '  ' + v.luckEmoji,
    )
  }
  return out
}

/** board — the leaderboard. One row per video, ranked. */
export function boardLines(videos, width) {
  const sorted = rankVideos(videos.map(v => videoSnapshot(v)), { by: 'views' })
  const out = [
    c('brightMagenta', WORDMARK) + '   ' + c('dim', 'top of the realm'),
    c('dim', '─'.repeat(width)),
    '',
  ]
  sorted.forEach((v, i) => {
    const medal = ['🥇', '🥈', '🥉'][i] ?? c('dim', String(i + 1).padStart(2))
    const title = clip(v.title, Math.max(10, width - 46))
    out.push(`  ${medal} ${pad(c('white', title), Math.max(10, width - 46))} ` +
      c('brightCyan', padStart(v.viewsLabel, 7)) + ' ' +
      c('dim', padStart(v.luckEmoji, 2)) + ' ' +
      c('brightYellow', padStart(count(v.earned), 8) + ' ☀'))
  })
  out.push('')
  out.push(c('dim', `${sorted.length} videos · ${count(sorted.reduce((n, v) => n + v.views, 0))} views`))
  return out
}

/**
 * stats — one video's life, drawn as a curve.
 *
 * This is the view that answers "does a video feel alive", and it is the reason
 * the script exists: the other two styles show a snapshot, this shows pacing.
 */
export function statsLines(video, { width = 90, hours = 24 } = {}) {
  const out = []
  const v = videoSnapshot(video)
  out.push(c('brightMagenta', WORDMARK) + '   ' + c('dim', 'one video, over time'))
  out.push(c('dim', '─'.repeat(width)))
  out.push('')
  out.push('  ' + c('bold', clip(v.title, width - 4)))
  out.push('  ' + c('dim', `${v.playerName} · ${v.lengthLabel} · ${v.luckEmoji} ${v.luckLabel}`))
  out.push('')

  // The curve: one column per checkpoint, height from the fraction reached.
  const steps = 24
  const rows = 7
  const published = video.publishedAt
  const grid = Array.from({ length: rows }, () => Array(steps).fill(' '))
  // PROJECTED, not read back. A video's `views` field is stored state that a
  // tick advances; it is not a function of the clock. So plotting a future
  // timeline has to project through the same growth curve the tick uses, or
  // every column reads zero (which is what the first version of this did).
  const tier = { multiplier: video.multiplier }
  for (let i = 0; i < steps; i++) {
    const minutes = (hours * 60 * (i + 1)) / steps
    const projected = viewsAt(video.targetViews, minutes, { tier })
    const frac = video.targetViews > 0 ? projected / video.targetViews : 0
    const height = Math.round(frac * rows)
    for (let h = 0; h < height; h++) grid[rows - 1 - h][i] = '█'
  }
  for (const row of grid) out.push('  ' + c('brightCyan', row.join('')) + '  ')
  out.push('  ' + c('dim', `0h${' '.repeat(Math.max(1, steps - 6))}${hours}h`))

  // The summary is the END of the run, not "now": this view is a projection, so
  // quoting the stored counter (which is 0 for a video just published) would
  // contradict the curve directly above it.
  const atHours = viewsAt(video.targetViews, hours * 60, { tier })
  const reachedPct = video.targetViews > 0 ? Math.round((atHours / video.targetViews) * 100) : 0
  const peakConcurrent = Math.max(
    ...Array.from({ length: steps }, (_, i) => {
      const minutes = (hours * 60 * (i + 1)) / steps
      const rate = viewsAt(video.targetViews, minutes, { tier }) -
        viewsAt(video.targetViews, Math.max(0, minutes - 60), { tier })
      return Math.round(rate / 12)
    }),
  )
  out.push('')
  out.push('  ' + c('brightCyan', '👁 ' + padStart(count(video.targetViews), 8)) + ' views once it is done')
  out.push('  ' + c('brightYellow', '☀ ' + padStart(count(viewPayout(video.targetViews)), 8)) + ' earned')
  out.push('  ' + c('dim', `🧑‍🤝‍🧑 peak ${count(peakConcurrent)} watching · 📈 ${reachedPct}% by ${hours}h`))
  return out
}

/** Compose a frame in one style. */
export function renderFrame(videos, { width = 90, style = 'grid', hours = 24 } = {}) {
  const w = Math.max(48, Math.min(width, 140))
  if (style === 'board') return boardLines(videos, w).join('\n')
  if (style === 'stats') {
    // The stats view is a video AS IT WAS PUBLISHED, plotted forward. Handing it
    // a video that already lived half its life draws a wall, not a curve, so the
    // caller passes a fresh one (see the CLI below).
    const first = Array.isArray(videos) ? videos[0] : videos
    return statsLines(first, { width: w, hours }).join('\n')
  }
  return gridLines(videos, w).join('\n')
}

/* ───────────────────────────────── cli ──────────────────────────────────── */

const isMain = process.argv[1] && import.meta.url.endsWith(process.argv[1].replace(/\\/g, '/'))

if (isMain) {
  if (!STYLES.includes(OPTIONS.style)) {
    console.error(`unknown --style "${OPTIONS.style}" (use one of: ${STYLES.join(', ')})`)
    process.exit(2)
  }
  setColor(OPTIONS.color && process.stdout.isTTY === true)

  const videos = demoVideos({
    followers: OPTIONS.followers,
    seed: OPTIONS.seed,
    keepFresh: OPTIONS.style === 'stats',
  })
  const width = process.stdout.columns || 90

  if (OPTIONS.frame) {
    process.stdout.write(renderFrame(videos, { width, style: OPTIONS.style, hours: OPTIONS.hours }) + '\n')
    process.exit(0)
  }

  // Live-ish: redraw on a timer so the counts move the way they will in play.
  let frame = 0
  const draw = () => {
    // Advance the demo set a little so the numbers are not frozen. NOT in the
    // stats style: that view plots a video's whole life across a fake timeline,
    // so pinning it to real "now" would freeze the curve at zero.
    if (OPTIONS.style !== 'stats') {
      for (const v of videos) {
        const snap = videoSnapshot(v, { now: Date.now() })
        v.views = Math.min(v.targetViews, snap.views)
        v.earned = viewPayout(v.views)
      }
    }
    if (process.stdout.isTTY) process.stdout.write('\x1b[2J\x1b[H')
    process.stdout.write(renderFrame(videos, { width, style: OPTIONS.style, hours: OPTIONS.hours }) + '\n')
    frame += 1
    if (OPTIONS.frames && frame >= OPTIONS.frames) process.exit(0)
  }
  draw()
  const timer = setInterval(draw, 2000)
  timer.unref?.()
  process.on('SIGINT', () => { clearInterval(timer); process.exit(0) })
}
