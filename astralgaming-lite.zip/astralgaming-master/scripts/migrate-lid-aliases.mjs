/**
 * migrate-lid-aliases.mjs — backfill the identity alias table for an existing
 * database.
 *
 * ── Why ───────────────────────────────────────────────────────────────────
 *
 * lib/identity-resolver.js resolves "the JID this message arrived on" to "the
 * key the player record actually lives under". New accounts get that link
 * written the moment they are created or first seen, but a database that
 * predates the fix has no `db.data.identity` at all, so the very first message
 * from every existing player has to fall back to the scan index. That works
 * whenever the record carries a `phone` or `lid` field — and it does not for
 * LID-keyed accounts that were never stamped (see scripts/check-web-login.mjs,
 * which exists because of exactly that gap).
 *
 * This script closes it offline: it walks every record, collects every address
 * that record is known by (its key, its `phone`, its `lid`), and writes the
 * equivalence links into `db.data.identity.aliases`. After it runs, a
 * LID-addressed group message and a phone-jid DM from the same person resolve
 * to one record on the first hop.
 *
 * ── Usage ─────────────────────────────────────────────────────────────────
 *
 *   node scripts/migrate-lid-aliases.mjs                # report only (safe)
 *   node scripts/migrate-lid-aliases.mjs --write        # write db.json
 *   DB_PATH=./db-pull-123.json node scripts/migrate-lid-aliases.mjs --write
 *
 * Read-only by default. Stop the bot before --write: this rewrites the whole
 * db.json, and the bot is the single writer of that file.
 */
import { readFileSync, writeFileSync, existsSync, copyFileSync } from 'node:fs'
import {
  normalizeJid,
  identityVariants,
  jidDigits,
  jidServer,
  isWhatsAppUserJid,
} from '../lib/identity-resolver.js'

const DB_PATH = process.env.DB_PATH ?? './db.json'
const WRITE = process.argv.includes('--write')

if (!existsSync(DB_PATH)) {
  console.error(`❌ No database at ${DB_PATH} (set DB_PATH to point at one)`)
  process.exit(1)
}

let raw
try {
  raw = JSON.parse(readFileSync(DB_PATH, 'utf8'))
} catch (err) {
  console.error(`❌ Could not parse ${DB_PATH}: ${err.message}`)
  process.exit(1)
}

const users = raw.users ?? {}
const keys = Object.keys(users)
if (!raw.identity) raw.identity = {}
if (!raw.identity.aliases) raw.identity.aliases = {}
const aliases = raw.identity.aliases

/* ── what is already linked ─────────────────────────────────────────────── */

const lidKeyed = keys.filter(k => jidServer(k) === 'lid')
const phoneKeyed = keys.filter(k => jidServer(k) === 's.whatsapp.net')
const otherKeyed = keys.filter(k => !isWhatsAppUserJid(k))
const withPhone = keys.filter(k => users[k]?.phone)
const withLid = keys.filter(k => users[k]?.lid)
const existingLinks = Object.keys(aliases).length

console.log(`\n📊 ${DB_PATH} — ${keys.length} player record(s)`)
console.log(`  keyed by @lid              ${lidKeyed.length}`)
console.log(`  keyed by @s.whatsapp.net   ${phoneKeyed.length}`)
console.log(`  keyed by something else    ${otherKeyed.length}   (Discord/Telegram/League — untouched)`)
console.log(`  carry a .phone stamp       ${withPhone.length}`)
console.log(`  carry a .lid stamp         ${withLid.length}`)
console.log(`  alias links already stored ${existingLinks}`)

/* ── collect the links ──────────────────────────────────────────────────── */

// Per record: every address it is known by. A link between two of them means
// "same person", which is all the resolver needs.
let added = 0
const problems = []

for (const key of keys) {
  const player = users[key] ?? {}
  const addresses = new Set()

  const addAddress = value => {
    const norm = normalizeJid(value)
    if (norm && isWhatsAppUserJid(norm)) addresses.add(norm)
  }
  addAddress(key)
  addAddress(player.phone)
  addAddress(player.lid)
  // A stamped phone number is bare digits; normalise it to a full jid so it
  // matches the form a DM arrives with.
  if (player.phone) {
    const digits = jidDigits(player.phone)
    if (digits.length >= 8) addresses.add(`${digits}@s.whatsapp.net`)
  }

  if (addresses.size < 2) continue

  // The record's own key is the canonical end of every link it takes part in.
  for (const address of addresses) {
    if (address === normalizeJid(key)) continue
    if (aliases[address]) {
      // Already linked to something. Fine when it is this record; a conflict
      // means two records claim the same address, which needs a human.
      if (aliases[address] !== normalizeJid(key)) {
        problems.push({ address, existing: aliases[address], key })
      }
      continue
    }
    aliases[address] = normalizeJid(key)
    added++
  }
}

// Collisions are also possible between two records' OWN keys (the duplicate
// accounts this bug created): two keys with the same digits are one person.
const byDigits = new Map()
for (const key of keys) {
  if (!isWhatsAppUserJid(key)) continue
  const digits = jidDigits(key)
  if (!digits) continue
  const seen = byDigits.get(digits)
  if (seen && seen !== key) problems.push({ address: key, existing: seen, key, duplicateKey: true })
  else byDigits.set(digits, key)
}

/* ── report ─────────────────────────────────────────────────────────────── */

console.log(`\n🔗 Links that would be added: ${added}`)

if (problems.length) {
  console.log(`\n⚠️  ${problems.length} conflict(s) — left alone, each needs a human decision:`)
  for (const p of problems.slice(0, 20)) {
    console.log(`   ${p.address}  already → ${p.existing}  (record ${p.key} also claims it)`)
  }
  if (problems.length > 20) console.log(`   … and ${problems.length - 20} more`)
  console.log('\n   Two records claiming one address usually means a player registered twice,')
  console.log('   once from a DM and once from a group. Merge them by hand before linking.')
}

// A quick "would this have fixed the report" check: how many records can now
// be reached from BOTH spellings of their address.
const reachable = keys.filter(key => {
  const variants = identityVariants(key)
  return variants.some(v => aliases[v] === normalizeJid(key) || users[v])
}).length
console.log(`\n✅ Records reachable from both a phone jid and a LID after this pass: ${reachable}/${keys.length}`)

if (!WRITE) {
  console.log('\n(dry run — pass --write to save. Stop the bot first: this rewrites db.json whole.)')
  process.exit(0)
}

if (added === 0 && existingLinks > 0) {
  console.log('\nNothing to add — db.json left untouched.')
  process.exit(0)
}

try {
  copyFileSync(DB_PATH, `${DB_PATH}.bak`)
  writeFileSync(DB_PATH, JSON.stringify(raw, null, 2))
} catch (err) {
  console.error(`❌ Write failed: ${err.message}`)
  process.exit(1)
}
console.log(`\n💾 Wrote ${DB_PATH} (backup at ${DB_PATH}.bak)`)
