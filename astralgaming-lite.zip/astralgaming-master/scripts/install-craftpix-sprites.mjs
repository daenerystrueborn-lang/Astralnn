/**
 * install-craftpix-sprites.mjs — adds six more fighter bodies to lib/assets/battle/.
 *
 * Sources (CraftPix free packs, see lib/assets/battle/CREDITS-craftpix-extra.txt):
 *   Free Samurai Pixel Art Sprite Sheets  → Samurai, Samurai_Commander, Samurai_Archer  (128px frames)
 *   Free Ninja Sprite Sheets Pixel Art    → Kunoichi (128px), Ninja_Monk, Ninja_Peasant (96px frames)
 *
 * Run:  node scripts/install-craftpix-sprites.mjs [--staging tmp/craftpix-src] [--force]
 *
 * Output: char_<base>_<pose>.png, the exact naming lib/battle-sprites.mjs and
 * lib/battle-frame-render.mjs already look up. Every output is a horizontal
 * strip of 128x128 frames, so the renderer needs no changes to play them: it
 * derives the frame count from the file width.
 *
 * The 96px sheets (Monk, Peasant) are padded to 128: each frame is centred
 * horizontally and bottom-aligned, so the feet stay on the last row like every
 * other body. Nothing is resampled.
 *
 * These packs do not ship the seven poses the renderer wants, so POSE_SOURCES
 * says which sheet stands in for which pose. `defend` is the awkward one: only
 * the two samurai have a guard animation. The rest borrow a short hunched or
 * raised-arms clip (first two frames), which reads as bracing on a still frame.
 */
import sharp from 'sharp'
import { existsSync, mkdirSync, writeFileSync } from 'fs'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..')
const args = process.argv.slice(2)
const argOf = (flag, dflt) => {
  const i = args.indexOf(flag)
  return i >= 0 && args[i + 1] ? args[i + 1] : dflt
}
const STAGING = join(ROOT, argOf('--staging', 'tmp/craftpix-src'))
const OUT     = join(ROOT, 'lib', 'assets', 'battle')
const FORCE   = args.includes('--force')
const FRAME   = 128   // must match CHAR_FRAME_W / CHAR_FRAME_H in battle-frame-render.mjs

/**
 * base      → the `<base>` in char_<base>_<pose>.png
 * dir       → folder inside the staging dir
 * fw        → source frame size (square)
 * poses     → pose → source sheet name, or { sheet, frames } to keep only the first N frames
 */
const BODIES = {
  bushi: {
    dir: 'Samurai', fw: 128,
    poses: { default: 'Idle', attack: 'Attack_1', skill: 'Attack_2', ultimate: 'Attack_3', hurt: 'Hurt', dead: 'Dead', defend: 'Protection' },
  },
  commander: {
    dir: 'Samurai_Commander', fw: 128,
    poses: { default: 'Idle', attack: 'Attack_1', skill: 'Attack_2', ultimate: 'Attack_3', hurt: 'Hurt', dead: 'Dead', defend: 'Protect' },
  },
  archer: {
    dir: 'Samurai_Archer', fw: 128,
    poses: { default: 'Idle', attack: 'Attack_1', skill: 'Attack_2', ultimate: 'Attack_3', hurt: 'Hurt', dead: 'Dead', defend: { sheet: 'Attack_2', frames: 2 } },
  },
  kunoichi: {
    dir: 'Kunoichi', fw: 128,
    poses: { default: 'Idle', attack: 'Attack_1', skill: 'Cast', ultimate: 'Attack_2', hurt: 'Hurt', dead: 'Dead', defend: { sheet: 'Cast', frames: 2 } },
  },
  monk: {
    dir: 'Ninja_Monk', fw: 96,
    poses: { default: 'Idle', attack: 'Attack_1', skill: 'Attack_2', ultimate: 'Blade', hurt: 'Hurt', dead: 'Dead', defend: { sheet: 'Cast', frames: 2 } },
  },
  peasant: {
    dir: 'Ninja_Peasant', fw: 96,
    poses: { default: 'Idle', attack: 'Attack_1', skill: 'Attack_2', ultimate: 'Shot', hurt: 'Hurt', dead: 'Dead', defend: 'Disguise' },
  },
}

const CLEAR = { r: 0, g: 0, b: 0, alpha: 0 }
let wrote = 0, skipped = 0
const fail = (m) => { console.error(`✗ ${m}`); process.exitCode = 1 }

if (!existsSync(STAGING)) {
  console.error(`Staging folder not found: ${STAGING}`)
  console.error('Extract the three CraftPix zips so it contains Samurai/, Samurai_Commander/, Samurai_Archer/, Kunoichi/, Ninja_Monk/, Ninja_Peasant/.')
  process.exit(1)
}
mkdirSync(OUT, { recursive: true })

/** Build one 128px-frame strip from a source sheet. */
async function buildStrip(src, fw, keepFrames) {
  const meta = await sharp(src).metadata()
  if (meta.height !== fw || meta.width % fw !== 0) {
    throw new Error(`is ${meta.width}x${meta.height}, expected height ${fw} and a width that is a multiple of ${fw}`)
  }
  const total = meta.width / fw
  const n = Math.min(total, keepFrames ?? total)

  // Already 128px frames: crop (or copy whole) without touching a pixel.
  if (fw === FRAME) {
    return sharp(src).extract({ left: 0, top: 0, width: n * FRAME, height: FRAME }).png({ compressionLevel: 9 }).toBuffer()
  }

  // Smaller frames: centre each one horizontally, bottom-align, pad with transparency.
  const padX = Math.floor((FRAME - fw) / 2)
  const padTop = FRAME - fw
  const parts = []
  for (let i = 0; i < n; i++) {
    const buf = await sharp(src)
      .extract({ left: i * fw, top: 0, width: fw, height: fw })
      .extend({ top: padTop, bottom: 0, left: padX, right: FRAME - fw - padX, background: CLEAR })
      .png().toBuffer()
    parts.push({ input: buf, left: i * FRAME, top: 0 })
  }
  return sharp({ create: { width: n * FRAME, height: FRAME, channels: 4, background: CLEAR } })
    .composite(parts).png({ compressionLevel: 9 }).toBuffer()
}

for (const [base, def] of Object.entries(BODIES)) {
  for (const [pose, spec] of Object.entries(def.poses)) {
    const sheet = typeof spec === 'string' ? spec : spec.sheet
    const keep  = typeof spec === 'string' ? null : spec.frames
    const src = join(STAGING, def.dir, `${sheet}.png`)
    const dest = join(OUT, `char_${base}_${pose}.png`)
    if (!existsSync(src)) { fail(`${def.dir}/${sheet}.png missing from staging`); continue }
    if (existsSync(dest) && !FORCE) { skipped++; continue }
    try {
      writeFileSync(dest, await buildStrip(src, def.fw, keep))
      wrote++
    } catch (err) {
      fail(`${def.dir}/${sheet}.png ${err.message}`)
    }
  }
}

writeFileSync(join(OUT, 'CREDITS-craftpix-extra.txt'), [
  'Extra battle bodies — provenance and licensing',
  '',
  'char_bushi_*, char_commander_*, char_archer_*',
  '  "Free Samurai Pixel Art Sprite Sheets" by CraftPix.net (pack 123681).',
  'char_kunoichi_*, char_monk_*, char_peasant_*',
  '  "Free Ninja Sprite Sheets Pixel Art" by CraftPix.net (pack 407836).',
  '  License: https://craftpix.net/file-licenses/',
  '',
  'Frames are 128x128. Ninja_Monk and Ninja_Peasant are natively 96x96 and are',
  'centred and bottom-aligned inside a 128 frame (no resampling).',
  'Pose map: see BODIES in scripts/install-craftpix-sprites.mjs (BODIES).',
  '',
  'Regenerate with: node scripts/install-craftpix-sprites.mjs --force',
].join('\n'))

console.log(`lib/assets/battle: ${wrote} written, ${skipped} kept${skipped && !FORCE ? ' (use --force to overwrite)' : ''}`)
