/** Database-free check of styled & compact battle captions + image fallback reliability. */
import assert from 'node:assert/strict'
import {
  compactBattleCaption,
  styleBattleCaption,
  BATTLE_SYMBOL_THEMES,
} from '../lib/battle-caption.mjs'

const sample = `⬆️ Strengthen (str): +3 for 989 more turn(s).
⬆️ Strengthen (agi): +3 for 989 more turn(s).
⬆️ Strengthen (int): +3 for 989 more turn(s).
⬆️ Strengthen (def): +3 for 989 more turn(s).
⬆️ Strengthen (lck): +3 for 989 more turn(s).

⚔️ *COMBO: Double Strike!*
   +50% damage on second hit
   Damage: 2401 → *3602*
🏅 *Golden Knight* guards *269* damage. _(-1 beast HP; 13077/13080 left)_
🛡️ *Guild ward* hardens — _-28% damage taken_
⚡ Critical.
*Jasyne* attacks 👉 *52 DMG* to *Kukoshibo*. The probability breaks.
🛡️✨ *SHIELD ABSORBED 15 DMG!*
🖤 The Dark Monarch drinks it in — *+8 HP*.
🃏 Circe spreads her empty hand. Her spent cards do not return when Heart summons her again.
🗣️ *Alenious, god of anomaly*: “I think we can manage without a scene”

🩸 *BATTLE STATUS* 🩸
❤️ *Jasyne*: [██████████] 5437/5437  💧 3550/3550 MP
💙 *Kukoshibo*: [██░░░░░░░░] 1259/5131  💧 1593/1770 MP
🎭 *COMPANIONS* 🎭
❤️ ❤️ *Alenious, god of anomaly*  1 HP  _standing_
💙 ❤️‍🔥 *Kyojuro Rengoku*  1800 HP  _standing_


⏭️ *TURN PASSES TO KUKOSHIBO!* ⏭️`

const caption = compactBattleCaption(sample)
console.log(caption)
const lines = caption.split('\n')
assert.ok(lines.length <= 8, `caption should be at most 8 lines, got ${lines.length}`)
assert.ok(caption.includes('I think we can manage without a scene'), 'a god must be heard in the compact caption')
assert.ok(caption.includes('52 DMG'))
assert.ok(caption.includes('crit'))
assert.ok(caption.includes('Double Strike'))
assert.ok(caption.includes('guard 269'))
assert.ok(caption.includes('5437/5437'))
assert.ok(caption.includes('1259/5131'))
assert.ok(caption.includes('⏭️ KUKOSHIBO'))
assert.ok(caption.includes('.pvp attack'), 'compact PvP caption must include instructions')
assert.ok(!caption.includes('Strengthen'))
assert.ok(!caption.includes('Circe'))
assert.equal(compactBattleCaption(sample, { fullBattleText: true }), sample, 'opt-out must keep the full text')
assert.equal(compactBattleCaption('⚔️ one short line'), '⚔️ one short line')

// ── Live Vanguard Opening 1v1 PvE regression + symbol variations ───────────
assert.ok(BATTLE_SYMBOL_THEMES.length >= 6, 'must define at least 6 distinct symbol themes')
const vanguardRaw = [
  '📖 *Opening:* *Vanguard Opening*',
  '⬆️ Strengthen (str): +3 for 989 more turn(s).',
  '⬆️ Strengthen (def): +3 for 989 more turn(s).',
  '⚔️ *Artemis* drives a clean blow into *Sewer Rat* — *13* damage!',
  '🐀 *Sewer Rat* snaps back at *Artemis* — *7* damage!',
  '',
  '👤 *Artemis*',
  '❤️ [█████████░] 73/80  💧 150/150 MP',
  '🐀 *Sewer Rat*',
  '❤️ [███████░░░] 47/60',
  '',
  '*.attack* · *.skill <name>* · *.defend* · *.flee*',
].join('\n')

const seenCorners = new Set()
for (let i = 0; i < BATTLE_SYMBOL_THEMES.length; i++) {
  const styled = styleBattleCaption(vanguardRaw, {
    player: { name: 'Artemis', hp: 73, maxHp: 80, mp: 150, maxMp: 150 },
    e: { name: 'Sewer Rat', emoji: '🐀', hp: 47, maxHp: 60 },
    hpBeforeTurn: 80,
    eHpBeforeTurn: 60,
    turn: i + 2,
    floor: 1,
    themeIndex: i,
  })
  seenCorners.add(BATTLE_SYMBOL_THEMES[i].corner)
  assert.ok(styled.includes(BATTLE_SYMBOL_THEMES[i].wingL), `theme ${i} wingL present`)
  assert.ok(styled.includes('*Artemis*'), 'player name always shown')
  assert.ok(styled.includes('*Sewer Rat*'), 'enemy name always shown')
  assert.ok(styled.includes('13* damage'), 'player hit preserved')
  assert.ok(styled.includes('7* damage'), 'enemy counter-attack preserved')
  assert.ok(styled.includes('(-7)'), 'player HP delta shown')
  assert.ok(styled.includes('(-13)'), 'enemy HP delta shown')
  assert.ok(styled.includes('*Buffs:* STR/DEF +3'), 'passive Strengthen lines collapsed')
  assert.ok(!styled.includes('989 more turn'), 'raw Strengthen spam removed')
  assert.ok(styled.includes('*.attack*') && styled.includes('*.skill') && styled.includes('*.defend*') && styled.includes('*.flee*'), '1v1 instructions always present')
  assert.ok(styled.split('\n').length <= 11, `styled 1v1 card stays compact (got ${styled.split('\n').length} lines)`)
}
assert.equal(seenCorners.size, BATTLE_SYMBOL_THEMES.length, 'each theme uses a distinct corner ornament')

// ── Regression (Artemis Nova): Swarm & DOT/passive speeches + instructions ──
const { sendBattleTurnReply } = await import('../lib/battle-frame-render.mjs')

const dungeonTurnText = [
  '🔥 Burn deals *340* damage!',
  '🩸 Crimson Hunger: Clane feeds on the foe, taking *420 HP* as her Toll.',
  '⚔️ *Artemis Nova* drives her blade through *Shadow Stalker* for *1,250 DMG*!',
  '👹 *Shadow Stalker* lunges from the dark and rakes you for *1,180*!',
  '🌑 *Shadow Stalker* casts *Soul Rend* — *520* shadow damage!',
  '',
  '⚔️ *FLOOR 14 — SWARM*',
  '🧭 You hold the *center lane* — they close from every side.',
  '◀ *YOUR LEFT*',
  '   🐺 Shadow Stalker _(⚔️ in reach)_  ⚠️ *winding up!*',
  '   [████░░░░░░] 1800/4200  ⚔️ 920  🛡️ 310',
  '👤 *Artemis Nova*  [███░░░░░░░] 1540/4000  💧 180/220',
  '🎯 *Next turn:* Shadow Stalker will strike. Cut them down, .dodge, or move clear.',
].join('\n')

const delivered = []
await sendBattleTurnReply(
  {
    platform: 'whatsapp',
    reply: async (t) => { delivered.push({ type: 'text', text: t }) },
    replyImage: async (img, cap) => {
      assert.ok(Buffer.isBuffer(img) && img.length > 100, 'rendered PNG buffer attached')
      delivered.push({ type: 'image', text: cap })
    },
  },
  {
    player: { name: 'Artemis Nova', classId: 'warrior', hp: 1540, maxHp: 4000, mp: 180, maxMp: 220, level: 45 },
    e: { id: 'shadow_stalker', name: 'Shadow Stalker', emoji: '🐺', hp: 1800, maxHp: 4200 },
    msg: dungeonTurnText,
    hpBeforeTurn: 4000,
    eHpBeforeTurn: 3050,
    isDungeon: true,
  },
)
const combinedOut = delivered.map((d) => d.text).join('\n')
assert.equal(delivered[0]?.type, 'image', 'primary turn message sent with battle image')
assert.ok(combinedOut.includes('Burn deals *340* damage!'), 'burn DOT line preserved')
assert.ok(combinedOut.includes('Crimson Hunger'), 'self-cost passive speech preserved')
assert.ok(combinedOut.includes('rakes you for *1,180*'), 'enemy hit speech preserved')
assert.ok(combinedOut.includes('Soul Rend'), 'monster ability speech preserved')
assert.ok(combinedOut.includes('Next turn:* Shadow Stalker will strike'), 'swarm telegraph & speech preserved')
assert.ok(combinedOut.includes('*.al*') && combinedOut.includes('*.dodge*'), 'swarm instructions always included')

// ── Media upload retry + graceful fallback when WhatsApp CDN hiccups ────────
let imageAttempts = 0
const retried = []
await sendBattleTurnReply(
  {
    platform: 'whatsapp',
    reply: async (t) => { retried.push({ type: 'text', text: t }) },
    replyImage: async (_img, cap) => {
      imageAttempts++
      if (imageAttempts === 1) throw new Error('Transient WhatsApp media upload timeout')
      retried.push({ type: 'image', text: cap })
    },
  },
  {
    player: { name: 'Artemis', classId: 'mage', hp: 73, maxHp: 80, mp: 140, maxMp: 150, level: 8 },
    e: { id: 'goblin', name: 'Goblin', emoji: '👺', hp: 47, maxHp: 60 },
    msg: vanguardRaw,
    hpBeforeTurn: 80,
    eHpBeforeTurn: 60,
    isDungeon: true,
  },
)
assert.equal(imageAttempts, 2, 'transient replyImage failure retries once')
assert.equal(retried[0]?.type, 'image', 'retry recovers battle image instead of dropping it')

const fallbackDelivered = []
await sendBattleTurnReply(
  {
    platform: 'whatsapp',
    reply: async (t) => { fallbackDelivered.push({ type: 'text', text: t }) },
    replyImage: async () => { throw new Error('Persistent media upload outage') },
  },
  {
    player: { name: 'Artemis', classId: 'mage', hp: 73, maxHp: 80, mp: 140, maxMp: 150, level: 8 },
    e: { id: 'goblin', name: 'Goblin', emoji: '👺', hp: 47, maxHp: 60 },
    msg: vanguardRaw,
    hpBeforeTurn: 80,
    eHpBeforeTurn: 60,
    isDungeon: true,
  },
)
assert.equal(fallbackDelivered[0]?.type, 'text', 'persistent media failure falls back to styled text instead of losing turn')
assert.ok(fallbackDelivered[0].text.includes('*.attack*'), 'fallback text still carries styled battle card + instructions')

// ── Long turn text (>1024 chars on WhatsApp) splits cleanly ─────────────────
const longTurnText = `${dungeonTurnText}\n${'📜 Dungeon chronicle speech line with full tactical detail.\n'.repeat(16)}🏁 Final HP & controls intact.`
const splitDelivered = []
await sendBattleTurnReply(
  {
    platform: 'whatsapp',
    reply: async (t) => { splitDelivered.push({ type: 'text', text: t }) },
    replyImage: async (_img, cap) => { splitDelivered.push({ type: 'image', text: cap }) },
  },
  {
    player: { name: 'Artemis Nova', classId: 'warrior', hp: 1540, maxHp: 4000, mp: 180, maxMp: 220, level: 45 },
    e: { id: 'shadow_stalker', name: 'Shadow Stalker', emoji: '🐺', hp: 1800, maxHp: 4200 },
    msg: longTurnText,
    hpBeforeTurn: 4000,
    eHpBeforeTurn: 3050,
    isDungeon: true,
  },
)
const splitCombined = splitDelivered.map((d) => d.text).join('\n')
assert.ok(splitCombined.includes('🏁 Final HP & controls intact.'), 'long battle speech tail never truncated')
if (splitDelivered[0]?.type === 'image') {
  assert.ok(splitDelivered[0].text.length <= 1024, 'WhatsApp media caption stays within 1024 chars')
  assert.ok(splitDelivered.length >= 2, 'overflow speech sent as follow-up reply')
}

console.log(`\nStyled compact caption (${BATTLE_SYMBOL_THEMES.length} symbol themes) + instructions + image retry/fallback + overflow checks passed.`)
