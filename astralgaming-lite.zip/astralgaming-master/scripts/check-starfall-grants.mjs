/**
 * check-starfall-grants.mjs — regression check for the Starfall premium grant
 * path. The early bug reports were "I won the chase character and it never
 * showed up" and "my Starfall prize did nothing". Root cause: the grant
 * switch routed several prize types to nowhere (skins never reached
 * characterSkins, the PFP/banner never reached profileCosmetics, Edo Tensei's
 * skill landed as a loose item). This test locks every premium prize to its
 * real destination so that never silently breaks again.
 *
 * Run: node scripts/check-starfall-grants.mjs
 */
import { grantEntry, POOL } from '../lib/starfall-engine.js'

let pass = 0, fail = 0
const ok = (cond, label) => {
  if (cond) { pass++; console.log('  ✓', label) }
  else { fail++; console.log('  ✗ FAIL:', label) }
}

const PREMIUM_IDS = ['sf_seong_ha', 'sf_burning_cathedral', 'sf_edo_tensei', 'sf_astral_witch', 'sf_starborn_seraph', 'sf_karren', 'sf_ha_neul', 'sf_ghostblade', 'sf_pfp', 'sf_banner']

const player = {
  ownedCharacters: [], inventory: [], skills: [],
  wallet: { gems: 10_000, solars: 1_000_000 },
  characterSkins: { owned: {}, equipped: {} },
  profileCosmetics: null, seasonOwned: undefined,
}

const results = {}
for (const id of PREMIUM_IDS) {
  const entry = POOL.find(e => e.id === id)
  if (!entry) { ok(false, `pool entry ${id} exists`); continue }
  results[id] = grantEntry(player, entry) ?? {}
}

ok(player.ownedCharacters.includes('seong_ha'), 'Seong-ha lands in ownedCharacters')
ok(player.ownedCharacters.includes('karren'), 'Karren lands in ownedCharacters')
ok(player.skills.includes('burning_cathedral'), 'Burning Cathedral lands in skills')
ok(player.skills.includes('edo_tensei_no_jutsu'), 'Edo Tensei no Jutsu lands in skills')
ok(Boolean(player.characterSkins.owned.seong_ha_astral_witch), 'Astral Witch skin lands in characterSkins.owned')
ok(Boolean(player.characterSkins.owned.seong_ha_starborn_seraph), 'Starborn Seraph skin lands in characterSkins.owned')
ok(player.inventory.includes('ha_neul'), 'Ha-neul lands in inventory')
ok(player.inventory.includes('ghostblade'), 'Ghostblade lands in inventory')
ok(player.profileCosmetics?.pfps?.includes('starfall_pfp'), 'Starfall PFP lands in profileCosmetics.pfps')
ok(player.profileCosmetics?.banners?.includes('starfall_banner_cosmetic'), 'Starfall banner lands in profileCosmetics.banners')
ok(!player.inventory.includes('burning_cathedral'), 'skills do not leak into inventory')
ok(!player.inventory.includes('seong_ha_astral_witch'), 'skins do not leak into inventory')

// No premium ever drops twice for the same player: the second grant of every
// prize must report itself as already owned, not grant a duplicate.
const player2 = { ...player, ownedCharacters: [...player.ownedCharacters], inventory: [...player.inventory], skills: [...player.skills], characterSkins: { owned: { ...player.characterSkins.owned }, equipped: {} }, profileCosmetics: JSON.parse(JSON.stringify(player.profileCosmetics)), seasonOwned: undefined }
for (const id of PREMIUM_IDS) {
  const entry = POOL.find(e => e.id === id)
  const r = grantEntry(player2, entry) ?? {}
  ok(r.duplicate === true, `${id} cannot drop twice (duplicate flag)`)
}

console.log(`\n${pass} passed, ${fail} failed`)
process.exit(fail ? 1 : 0)
