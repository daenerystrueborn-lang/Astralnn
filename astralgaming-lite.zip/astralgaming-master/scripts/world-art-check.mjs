/**
 * world-art-check.mjs — does the world art drop actually go out, and with the
 * right picture on the right screen?
 *
 * WHY. Four links (lib/image.js's map) and one cinematic (lib/world-arrival.js)
 * now sit across six reply sites: the world menu, the two world screens, the two
 * roads between the worlds, and the three ways a breakthrough can be won. Every
 * one of them is a message a player reads once and remembers, and a wrong key or
 * a dropped flag is invisible in the code and obvious in the chat, so this walks
 * the real plugins with a fake WhatsApp ctx and prints what went out.
 *
 * WHAT IT PINS:
 *   · each key resolves to the owner's own link;
 *   · `.map` gets the world art, `.map <world>` gets the tear and then that
 *     world's own picture, and a closed world is announced by nobody;
 *   · a world named in any of its spellings ('.map sect') reaches that world,
 *     while a real PLACE ('sect_road_foot', 'caged_dimension') never does;
 *   · the tear fires on the crossing itself (the last answer of either road) and
 *     not on the gatekeeper's conversation;
 *   · the ascent's picture goes out with a breakthrough WON by any of the three
 *     routes, and with nothing that was lost.
 *
 * Run: node scripts/world-art-check.mjs
 */
import travel from '../plugins/travel.js'
import breakthrough from '../plugins/breakthrough.js'
import { resolveImageSource } from '../lib/image.js'
import { sectPicture } from '../lib/sect-images.js'
import { tearingText, worldFullName } from '../lib/world-arrival.js'
import { CROSSING_OUT_SOLARS } from '../lib/sect-crossing.js'

let failures = 0
function check(label, ok, extra = '') {
  console.log(`${ok ? '  ✓' : '  ✗'} ${label}${extra ? `  ${extra}` : ''}`)
  if (!ok) failures++
}

/** A ctx that records everything the bot would have sent. */
function fakeCtx({ player, args = [], cmd = 'map', db = { data: {} } } = {}) {
  const sent = []
  return {
    sent,
    platform: 'whatsapp',
    sender: '2348000000000@s.whatsapp.net',
    from: '2348000000000@s.whatsapp.net',
    msg: { key: { id: 'SMOKE' } },
    isGroup: false,
    player,
    args,
    cmd,
    db,
    sock: {
      async sendMessage(_jid, content) {
        sent.push({
          kind: content.image ? 'image' : content.text ? 'text' : 'other',
          url: content.image?.url ?? null,
          caption: content.caption ?? null,
          text: content.text ?? null,
        })
        return { key: { id: 'SENT' } }
      },
    },
    async reply(text) { sent.push({ kind: 'reply', text: String(text) }); return null },
  }
}

/** Every picture that went out, as resolved URLs. */
const pictures = ctx => ctx.sent.filter(m => m.kind === 'image').map(m => m.url)
const allText = ctx => ctx.sent.map(m => m.caption || m.text || '').join('\n')

console.log('\n── the keys resolve to the owner\'s five links ────────────────')
const expected = {
  'world-map': 'https://i.ibb.co/rK0QZ7y0/astra.webp',
  'world-tearing': 'https://i.ibb.co/bjmCY3kb/astrantearing.webp',
  'astra-kingdom-map': 'https://i.ibb.co/ycM90gWN/download-14.jpg',
  'sect-ascension': 'https://i.ibb.co/fV82MrJx/ascension.webp',
  'dimension-realm-map': 'https://animeastral.qzz.io/assets/world/world_map4.jpg',
}
for (const [key, url] of Object.entries(expected)) {
  check(`${key} -> ${url.split('/').pop()}`, resolveImageSource(key) === url)
}
check('sect map banner is the tear (by key)', resolveImageSource(sectPicture('world')) === expected['world-tearing'])
check('ascension slot is the ascent (by key)', resolveImageSource(sectPicture('ascension')) === expected['sect-ascension'])

const astraPlayer = {
  id: '2348000000000@s.whatsapp.net', name: 'Smoke', location: 'astral_town',
  level: 40, hp: 100, maxHp: 100, mp: 50, maxMp: 50, wallet: { solars: 1000 }, dungeonProgress: {},
}

console.log('\n── .map with nothing after it ────────────────────────────────')
{
  const ctx = fakeCtx({ player: astraPlayer, args: [], cmd: 'map' })
  await travel.run(ctx)
  check('one message', ctx.sent.length === 1, `(${ctx.sent.length} sent)`)
  check('carries the world art', pictures(ctx)[0] === expected['world-map'])
  check('the menu is the caption', /WORLD MAP/.test(allText(ctx)) && /Astra Kingdom/.test(allText(ctx)))
  console.log(`\n${allText(ctx)}\n`)
}

console.log('── .map astra_kingdom: the tear, then the kingdom map ─────────')
{
  const ctx = fakeCtx({ player: astraPlayer, args: ['astra_kingdom'], cmd: 'map' })
  await travel.run(ctx)
  check('the tear picture goes first', pictures(ctx)[0] === expected['world-tearing'])
  check('the kingdom map follows under its own art', pictures(ctx)[1] === expected['astra-kingdom-map'])
  check('the world tore', /THE WORLD TORE/.test(allText(ctx)))
  check('emerging from the shadows', /emerge from the shadows/.test(allText(ctx)))
  check('the world you came to is welcomed', /Welcome to the Astra Kingdom/.test(allText(ctx)))
  check('the map itself still arrives', /ASTRA KINGDOM/.test(allText(ctx)) && /HEARTLAND/.test(allText(ctx)))
  console.log(`\n${ctx.sent[0].caption}\n`)
}

console.log('── .map sect_empire: the tear, then the mountain signpost ─────')
{
  const ctx = fakeCtx({ player: astraPlayer, args: ['sect_empire'], cmd: 'map' })
  await travel.run(ctx)
  check('the tear picture goes first', pictures(ctx)[0] === expected['world-tearing'])
  check('the tear names the world left behind', /the Astra Kingdom still warm at your back/.test(allText(ctx)))
  check('the mountain is welcomed', /Welcome to Zongmen Diguo, the Sect Empire/.test(allText(ctx)) && !/the Zongmen/.test(allText(ctx)))
  check('the signpost follows', /road is open|Shanlu|Cloudpiercer/i.test(allText(ctx)))
  console.log(`\n${ctx.sent[0].caption}\n`)
}

console.log('── .map dimension_realm: no link yet, so words alone ──────────')
{
  const ctx = fakeCtx({ player: astraPlayer, args: ['dimension_realm'], cmd: 'map' })
  await travel.run(ctx)
  check('nothing blank was sent', ctx.sent.every(m => (m.text || m.caption || '').trim().length > 0))
  check('no tear for a list of doors', !pictures(ctx).includes(expected['world-tearing']))
  check('the doors are listed', /DIMENSION REALM/.test(allText(ctx)) && /Dreamlands/.test(allText(ctx)))
}

console.log('── .travel with nothing after it still opens on the kingdom ───')
{
  const ctx = fakeCtx({ player: astraPlayer, args: [], cmd: 'travel' })
  await travel.run(ctx)
  check('no tear on the old front door', !pictures(ctx).includes(expected['world-tearing']))
  check('the kingdom map has its own art', pictures(ctx)[0] === expected['astra-kingdom-map'])
}

console.log('── a closed Sect Empire is not announced at all ───────────────')
{
  const ctx = fakeCtx({
    player: { ...astraPlayer, id: 'stranger@s.whatsapp.net' },
    args: ['sect_empire'], cmd: 'map',
    db: { data: { worldOpen: { sect_empire: false } } },
  })
  await travel.run(ctx)
  check('no picture', pictures(ctx).length === 0)
  check('the answer a made-up word gets', /Unknown location/.test(allText(ctx)))
}

console.log('\n── the tear, said both ways ──────────────────────────────────')
console.log(tearingText('sect_empire', { from: 'astra_kingdom' }))
console.log('')
console.log(tearingText('astra_kingdom', { from: 'sect_empire' }))
check('a world nobody knows still reads', /Welcome to the world you came to/.test(tearingText('nope')))
check('names come off the world record', worldFullName('sect_empire') === 'Zongmen Diguo, the Sect Empire')

console.log('\n── a world named in any of its spellings ─────────────────────')
{
  const { worldIdForWord } = await import('../lib/worlds.js')
  const spellings = {
    astra_kingdom: ['astra_kingdom', 'astra kingdom', 'astra', 'kingdom', 'ASTRA_KINGDOM'],
    sect_empire: ['sect_empire', 'sect', 'sect empire', 'sects', 'zongmen diguo', 'murim', 'sect-empire'],
    dimension_realm: ['dimension_realm', 'dimension', 'dimensions'],
  }
  for (const [id, words] of Object.entries(spellings)) {
    check(`"${words.join('", "')}" -> ${id}`, words.every(w => worldIdForWord(w) === id))
  }
  const places = ['sect_road_foot', 'hollow_moon_sect', 'caged_dimension', 'astral_town', 'cradlehold', 'town']
  check('a real place is never taken for a world', places.every(w => worldIdForWord(w) === null), `(${places.join(', ')})`)

  // `.map sect` from the kingdom's side is the mountain's signpost, with the tear.
  const ctx = fakeCtx({ player: astraPlayer, args: ['sect'], cmd: 'map' })
  await travel.run(ctx)
  check('.map sect arrives through the tear', pictures(ctx)[0] === expected['world-tearing'])
  check('.map sect reads the mountains', /road is open|Cloudpiercer/i.test(allText(ctx)))

  // `.travel sect empire` is the same screen: two words, one world.
  const two = fakeCtx({ player: astraPlayer, args: ['sect', 'empire'], cmd: 'travel' })
  await travel.run(two)
  check('.travel sect empire is the same door', pictures(two)[0] === expected['world-tearing'])

  // `.map dimensions` is the doors with the Dimension Realm map, and no tear.
  const dim = fakeCtx({ player: astraPlayer, args: ['dimensions'], cmd: 'map' })
  await travel.run(dim)
  check('.map dimensions lists the doors', /DIMENSION REALM/.test(allText(dim)) && pictures(dim).length === 1 && pictures(dim)[0] === expected['dimension-realm-map'])

  // A real place still travels: the town is a town, not a world. updatePlayer
  // writes through the db, so this one needs a real record to move, and the walk
  // starts in a kingdom town (Cradlehold is behind the door, in the Dreamlands).
  const JID = '2348000000000@s.whatsapp.net'
  const mover = { ...astraPlayer, id: JID, location: 'hearthglen' }
  const moveDb = { data: { users: { [JID]: mover } }, async write() {} }
  const town = fakeCtx({ player: mover, args: ['astral_town'], cmd: 'travel', db: moveDb })
  await travel.run(town)
  check('.travel astral_town still moves the player', moveDb.data.users[JID].location === 'astral_town' && pictures(town).length === 0, `(${moveDb.data.users[JID].location})`)
}

console.log('\n── .map from INSIDE the Sect Empire: the tear is the banner ───')
{
  const { rollForRoad, buildSectProfile } = await import('../lib/sect-cultivation.js')
  const now = Date.now()
  const cultivator = {
    id: '2348000000000@s.whatsapp.net', name: 'Smoke', level: 200,
    world: 'sect_empire', location: 'sect_road_foot', sect: null,
  }
  cultivator.sect = buildSectProfile(cultivator, rollForRoad(cultivator, { now }), { now })
  const ctx = fakeCtx({ player: cultivator, args: [], cmd: 'map' })
  await travel.run(ctx)
  check('the mountain\'s own map went out', /Shanlu|Cloudpiercer|SECT/i.test(allText(ctx)))
  check('under the tear, not the old banner', pictures(ctx)[0] === expected['world-tearing'])
  check('the old sect-world link is gone from the slot', !/84NbhH9L/.test(JSON.stringify(pictures(ctx))))
}

console.log('\n── .breakthrough won on the roll carries the ascent ───────────')
{
  const JID = '2348000000000@s.whatsapp.net'
  const { progressNeed } = await import('../lib/sect-progress.js')
  const { ensureSectProfile } = await import('../lib/sect-cultivation.js')
  const { addItem } = await import('../lib/sect-items.js')
  const { buildSectProfile } = await import('../lib/sect-cultivation.js')

  // A cultivator at the peak of Qi Condensation (a `roll` realm), bar full, the
  // pill the realm asks for in the bag, and the owner's forced success on the
  // record so the smoke test does not have to win a coin toss.
  const sectPlayer = {
    id: JID, name: 'Smoke', world: 'sect_empire', location: 'sect_road_foot',
    hp: 100, maxHp: 100, mp: 50, maxMp: 50,
    sect: null,
  }
  sectPlayer.sect = buildSectProfile(sectPlayer, { stage: 9, spiritRoot: { roots: ['fire'] }, stats: {} }, { now: Date.now() })
  ensureSectProfile(sectPlayer, { now: Date.now() })
  sectPlayer.sect.stage = 9
  sectPlayer.sect.stageName = 'Qi Condensation, Layer 9'
  sectPlayer.sect.progress = progressNeed(9)
  sectPlayer.sect.ownerRoll = 'success'
  addItem(sectPlayer.sect, 'foundation_pill', 1)

  const db = { data: { users: { [JID]: sectPlayer } }, async write() {} }
  const ctx = fakeCtx({ player: sectPlayer, args: [], cmd: 'breakthrough', db })
  await breakthrough.run(ctx)

  check('the ascent art went out', pictures(ctx).includes(expected['sect-ascension']), `(${pictures(ctx).length} pictures)`)
  check('the breakthrough words are with it', /BREAKTHROUGH/.test(allText(ctx)))
  check('the stage moved', db.data.users[JID].sect.stage === 10, `(stage ${db.data.users[JID].sect.stage})`)
}

console.log('\n── a breakthrough LOST gets no picture ───────────────────────')
{
  const JID = '2348000000000@s.whatsapp.net'
  const { progressNeed } = await import('../lib/sect-progress.js')
  const { ensureSectProfile } = await import('../lib/sect-cultivation.js')
  const { addItem } = await import('../lib/sect-items.js')
  const { buildSectProfile } = await import('../lib/sect-cultivation.js')

  const sectPlayer = { id: JID, name: 'Smoke', world: 'sect_empire', location: 'sect_road_foot', sect: null }
  sectPlayer.sect = buildSectProfile(sectPlayer, { stage: 9, spiritRoot: { roots: ['fire'] }, stats: {} }, { now: Date.now() })
  ensureSectProfile(sectPlayer, { now: Date.now() })
  sectPlayer.sect.stage = 9
  sectPlayer.sect.progress = progressNeed(9)
  sectPlayer.sect.ownerRoll = 'fail'
  addItem(sectPlayer.sect, 'foundation_pill', 1)

  const db = { data: { users: { [JID]: sectPlayer } }, async write() {} }
  const ctx = fakeCtx({ player: sectPlayer, args: [], cmd: 'breakthrough', db })
  await breakthrough.run(ctx)

  check('no picture at all', pictures(ctx).length === 0)
  check('the bar holds, in words', /THE BAR HOLDS|QI DEVIATION/.test(allText(ctx)))
}

console.log('\n── the heart demon beaten: the ascent rides the last blow ─────')
{
  const JID = '2348000000000@s.whatsapp.net'
  await import('../lib/sect-hooks.js')   // the registration IS the import
  const { startHeartDemon, settleHeartDemonHook } = await import('../lib/sect-breakthrough.js')
  const { applyPlayerAction, sectAttack, settlePendingHook } = await import('../lib/sect-fight.js')
  const { rollForRoad, buildSectProfile, rebuildSectStats, stageLabel } = await import('../lib/sect-cultivation.js')
  const { refillPools } = await import('../lib/sect-progress.js')

  // Foundation Establishment, Peak: a `fight` realm, so the wall is a demon and
  // the demon's death IS the breakthrough.
  const makeCultivator = () => {
    const now = Date.now()
    const player = { id: JID, name: 'Smoke', level: 200, world: 'sect_empire', location: 'sect_road_foot', sect: null }
    player.sect = buildSectProfile(player, rollForRoad(player, { now }), { now })
    player.sect.stage = 13
    player.sect.stageName = stageLabel(13)
    rebuildSectStats(player.sect)
    refillPools(player.sect, now)
    return player
  }

  // Rigged so the smoke test reads the SETTLEMENT and not the combat maths. A
  // fight side carries its numbers FLAT (state.b.attack, not state.b.stats), and
  // the demon mirrors the cultivator it was built from, so an unrigged round is
  // a coin toss: here the demon is on its last breath, cannot hit back (attack 0
  // is the minimum of 1 damage a round), has nothing to cast, and the cultivator
  // is the faster of the two so they open.
  const rigLastBreath = (who) => {
    const f = who.sectFight
    f.b.hp = 1
    f.b.maxHp = 1
    f.b.attack = 0
    f.b.defense = 0
    f.b.speed = 0
    f.b.qi = 0
    f.b.techniques = []
    f.a.hp = f.a.maxHp
    f.a.speed = Math.max(Number(f.a.speed) || 0, 999)
    who.sect.hp = f.a.maxHp
    return who
  }

  // ── the engine's own turn: does the win carry the ascent? ──
  const player = makeCultivator()
  const started = startHeartDemon(player, { now: Date.now(), withTribulation: false })
  check('the demon stands up', started.ok === true && !!player.sectFight)
  const before = player.sect.stage

  rigLastBreath(player)

  // A round can be dodged, so the blow is swung until the demon is down.
  let out = null
  for (let i = 0; i < 8 && player.sectFight; i++) {
    out = applyPlayerAction(player, { kind: 'attack' }, { now: Date.now() })
    if (player.sectFight) rigLastBreath(player)
  }
  check('the fight ended in a win', out?.ended === true && out?.outcome === 'win', `(outcome ${out?.outcome})`)
  check('the turn says the realm was taken', /BREAKTHROUGH/.test((out?.lines ?? []).join('\n')))
  check('the turn carries the ascent flag', out?.ascended === true)
  check('the stage moved', player.sect.stage === before + 1, `(${player.sect.stage})`)

  // ── the command that replies: does the picture go out with the blow? ──
  const fighter = makeCultivator()
  startHeartDemon(fighter, { now: Date.now(), withTribulation: false })
  rigLastBreath(fighter)
  const db = { data: { users: { [JID]: fighter } }, async write() {} }
  const turns = []
  for (let i = 0; i < 8 && db.data.users[JID].sectFight; i++) {
    const ctx = fakeCtx({ player: db.data.users[JID], args: [], cmd: 'attack', db })
    await sectAttack(ctx)
    turns.push(ctx)
    if (db.data.users[JID].sectFight) rigLastBreath(db.data.users[JID])
  }
  const lastBlow = turns[turns.length - 1]
  check('the demon went down', turns.length > 0 && !db.data.users[JID].sectFight, `(${turns.length} rounds)`)
  check('the rounds before the last are words alone', turns.slice(0, -1).every(t => pictures(t).length === 0))
  check('the ascent art went out with the last blow', pictures(lastBlow ?? { sent: [] }).includes(expected['sect-ascension']))
  check('the turn still reads', /BREAKTHROUGH/.test(allText(lastBlow ?? { sent: [] })))

  // ── the hook's own contract, both ways ──
  const winNoTrial = settleHeartDemonHook(makeCultivator(), { hook: { withTribulation: false } }, { outcome: 'win' })
  check('a win with no tribulation answers ascended', winNoTrial?.ascended === true && Array.isArray(winNoTrial.lines))
  const winWithTrial = settleHeartDemonHook(makeCultivator(), { hook: { withTribulation: true } }, { outcome: 'win' })
  check('a win that opens the tribulation does not', Array.isArray(winWithTrial) && !winWithTrial.ascended)
  const loss = settleHeartDemonHook(makeCultivator(), { hook: {} }, { outcome: 'loss' })
  check('a loss still answers with plain lines', Array.isArray(loss))

  // The deferred path (a fight that ended while nobody was listening) must hand
  // back lines, not the object, or the words would be dropped on the floor.
  const deferred = makeCultivator()
  deferred.sect.pendingHook = { hook: { kind: 'heart_demon', withTribulation: false }, outcome: 'win', at: Date.now() }
  const pending = settlePendingHook(deferred, { now: Date.now() })
  check('the deferred settlement is lines, not an object', Array.isArray(pending) && pending.length > 0)
}

console.log('\n── the road UP: the tear fires on the crossing, not the talk ──')
{
  const JID = '2348000000000@s.whatsapp.net'
  const road = await import('../plugins/road.js')
  const answer = await import('../plugins/answer.js')

  const walker = {
    id: JID, name: 'Smoke', level: 200, location: 'astral_town', townSpot: null,
    hp: 100, maxHp: 100, mp: 50, maxMp: 50,
    ownedCharacters: ['monica'], wallet: { solars: 100000 }, inventory: [],
  }
  const db = { data: { users: { [JID]: walker }, worldOpen: { sect_empire: true } }, async write() {} }

  // The gatekeeper talks first: a conversation is not an arrival.
  const talk = fakeCtx({ player: walker, args: [], cmd: 'road', db })
  await road.default.run(talk)
  check('the talk sends no picture', pictures(talk).length === 0)
  check('the gatekeeper is talking', /🪨/.test(allText(talk)))

  // Answer every question until the last one, which is the crossing itself.
  let crossed = null
  for (let i = 0; i < 8 && db.data.users[JID].world !== 'sect_empire'; i++) {
    const q = fakeCtx({ player: db.data.users[JID], args: ['1'], cmd: 'answer', db })
    await answer.default.run(q)
    if (pictures(q).includes(expected['world-tearing'])) crossed = q
  }
  check('the last answer crossed them', db.data.users[JID].world === 'sect_empire')
  check('the tear went out on the crossing', !!crossed, `(${crossed ? 'picture sent' : 'no picture'})`)
  check('the tear is the arrival, not the road talk', /THE WORLD TORE/.test(allText(crossed ?? { sent: [] })))
  check('the mountain is welcomed', /Welcome to Zongmen Diguo, the Sect Empire/.test(allText(crossed ?? { sent: [] })))
  check('the road\'s own words still follow', crossed && crossed.sent.length > 1 && /ROAD OPENS|road knows you/.test(crossed.sent.slice(1).map(m => m.text || m.caption || '').join('\n')))
}

console.log('\n── the road DOWN: the same beat, walked back ─────────────────')
{
  const JID = '2348000000000@s.whatsapp.net'
  const road = await import('../plugins/road.js')
  const answer = await import('../plugins/answer.js')
  const { rollForRoad, buildSectProfile } = await import('../lib/sect-cultivation.js')

  const now = Date.now()
  const cultivator = {
    id: JID, name: 'Smoke', level: 200, world: 'sect_empire', location: 'sect_road_foot',
    hp: 100, maxHp: 100, mp: 50, maxMp: 50,
    ownedCharacters: ['monica'], wallet: { solars: CROSSING_OUT_SOLARS }, inventory: [], crossingAt: 0,
    sect: null,
  }
  cultivator.sect = buildSectProfile(cultivator, rollForRoad(cultivator, { now }), { now })
  cultivator.sect.astraReturn = { location: 'astral_town', townSpot: null, at: now }
  const db = { data: { users: { [JID]: cultivator } }, async write() {} }

  const talk = fakeCtx({ player: cultivator, args: [], cmd: 'road', db })
  await road.default.run(talk)
  check('the talk down sends no picture', pictures(talk).length === 0)

  let home = null
  for (let i = 0; i < 6 && db.data.users[JID].world === 'sect_empire'; i++) {
    const q = fakeCtx({ player: db.data.users[JID], args: ['1'], cmd: 'answer', db })
    await answer.default.run(q)
    if (pictures(q).includes(expected['world-tearing'])) home = q
  }
  check('they are back in the kingdom', db.data.users[JID].world === 'astra_kingdom')
  check('the tear went out on the way down', !!home)
  check('the kingdom is welcomed', /Welcome to the Astra Kingdom/.test(allText(home ?? { sent: [] })))
  check('the world left behind is named', /Sect Empire still warm at your back/.test(allText(home ?? { sent: [] })))
}

console.log('\n── heaven\'s last strike survived carries the ascent ─────────')
{
  const JID = '2348000000000@s.whatsapp.net'
  const { sectTribulationCommand } = await import('../lib/sect-fight.js')
  const { startTribulation } = await import('../lib/sect-breakthrough.js')
  const { rollForRoad, buildSectProfile } = await import('../lib/sect-cultivation.js')

  const now = Date.now()
  const cultivator = {
    id: JID, name: 'Smoke', level: 200, world: 'sect_empire', location: 'sect_road_foot',
    hp: 100, maxHp: 100, mp: 50, maxMp: 50, sect: null,
  }
  cultivator.sect = buildSectProfile(cultivator, rollForRoad(cultivator, { now }), { now })
  cultivator.sect.stage = 17   // Core Formation, Peak: fight+tribulation
  const before = cultivator.sect.stage
  startTribulation(cultivator, { now })

  const db = { data: { users: { [JID]: cultivator } }, async write() {} }
  const strikes = []
  for (let i = 0; i < 3 && cultivator.sectTribulation; i++) {
    const ctx = fakeCtx({ player: db.data.users[JID], args: [], cmd: 'defend', db })
    await sectTribulationCommand(ctx, 'defend')
    strikes.push(ctx)
  }
  check('all three strikes landed', strikes.length === 3 && !cultivator.sectTribulation)
  check('the first two are words alone', pictures(strikes[0]).length === 0 && pictures(strikes[1]).length === 0)
  check('the last one carries the ascent', pictures(strikes[2]).includes(expected['sect-ascension']), `(${pictures(strikes[2]).length} pictures)`)
  check('the realm was taken', cultivator.sect.stage === before + 1, `(stage ${cultivator.sect.stage})`)
}

console.log(`\n${failures === 0 ? '✅ all checks passed' : `❌ ${failures} check(s) failed`}\n`)
process.exit(failures === 0 ? 0 : 1)
