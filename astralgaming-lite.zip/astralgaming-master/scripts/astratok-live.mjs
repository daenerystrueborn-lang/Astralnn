#!/usr/bin/env node
/**
 * astratok-live.mjs — the ASTRATOK control room, in a terminal.
 *
 * WHAT THIS IS
 * A live view of a running stream, drawn in ANSI. It drives the SAME engine the
 * bot does (lib/astratok/stream.js), so what you watch here is what the players
 * are watching in chat, down to the comments and the money. Change the engine
 * and both move together; they cannot drift.
 *
 * WHY IT EXISTS
 * Watching a stream from inside the chat is like watching television through a
 * letterbox: every card is a snapshot of one moment, and a twenty minute stream
 * is twenty minutes of scrolling. Here the whole thing is on one screen and it
 * updates in place, which is the only way to SEE whether the pacing works.
 *
 * HOW TO RUN IT
 *   node scripts/astratok-live.mjs                       demo stream, random seed
 *   node scripts/astratok-live.mjs --followers 42000     a famous streamer
 *   node scripts/astratok-live.mjs --dungeon             dungeon bonus on
 *   node scripts/astratok-live.mjs --seed 7              replay an exact stream
 *   node scripts/astratok-live.mjs --speed 4             4x faster than real time
 *   node scripts/astratok-live.mjs --frames 30           render 30 frames then stop
 *   node scripts/astratok-live.mjs --frame                render ONE frame and exit
 *   node scripts/astratok-live.mjs --style rail|board|cinema|ticker   pick a layout
 *   node scripts/astratok-live.mjs --no-color            plain text (CI, logs)
 *
 * `--frames` and `--frame` are what make this testable: a renderer nobody can
 * assert on is a renderer that silently breaks.
 *
 * STYLES
 *   rail    three columns: the stream, the chat, and the money. The default.
 *   board   the phone layout: one narrow column, the way it reads in Telegram.
 *   cinema  the broadcast: a big mark, one headline number, chat underneath as
 *           subtitles. For a wall screen or a second monitor.
 *   ticker  the log: no boxes, no bars, one dense line per event. For a small
 *           window, a tmux pane, or piping to a file.
 *
 * Every style draws the same view model, so they cannot disagree about what
 * happened; only the arrangement changes.
 */

import { openStream, tick, setMoment, closeStream, snapshot, STREAM_LENGTH_MS } from '../lib/astratok/stream.js'
import { topViewers, regularsHere } from '../lib/astratok/crowd.js'
import { hypeLabel, hypeMultiplier } from '../lib/astratok/economy.js'
import { makeViewer, mulberry32 } from '../lib/astratok/voices.js'

/* ────────────────────────────── args ────────────────────────────────────── */

const argv = process.argv.slice(2)
const flag = (name, fallback = null) => {
  const i = argv.indexOf(`--${name}`)
  if (i < 0) return fallback
  const next = argv[i + 1]
  return next && !next.startsWith('--') ? next : true
}
const num = (name, fallback) => {
  const v = flag(name)
  return v == null || v === true ? fallback : Number(v)
}

export const STYLES = ['rail', 'board', 'cinema', 'ticker']

const OPTIONS = {
  followers: num('followers', 12_400),
  seed: num('seed', Math.floor(Math.random() * 1e6)),
  speed: Math.max(0.1, num('speed', 1)),
  frames: num('frames', 0),          // 0 = run until the stream ends
  dungeon: flag('dungeon', false) === true,
  style: String(flag('style', 'rail')),
  color: flag('no-color', false) !== true,
  frame: flag('frame', false) === true,
  name: String(flag('name', 'Astra Wanderer')),
  realtime: flag('realtime', false) === true,
}

/* ────────────────────────────── colour ──────────────────────────────────── */

const COLORS = {
  reset: '\x1b[0m', bold: '\x1b[1m', dim: '\x1b[2m', italic: '\x1b[3m',
  red: '\x1b[31m', green: '\x1b[32m', yellow: '\x1b[33m', blue: '\x1b[34m',
  magenta: '\x1b[35m', cyan: '\x1b[36m', white: '\x1b[37m',
  brightRed: '\x1b[91m', brightGreen: '\x1b[92m', brightYellow: '\x1b[93m',
  brightBlue: '\x1b[94m', brightMagenta: '\x1b[95m', brightCyan: '\x1b[96m',
}

/**
 * Whether to colour. A module-level flag set from argv would be wrong: an
 * importer (a test, or another script) needs to ask for plain text without
 * rewriting process.argv, and a global here would leak between them.
 */
let USE_COLOR = false
export function setColor(on) { USE_COLOR = !!on }
const c = (name, s) => (USE_COLOR ? `${COLORS[name] ?? ''}${s}${COLORS.reset}` : String(s))

/** Visible length, ignoring ANSI escapes and counting wide glyphs as 2. */
const strip = (s) => String(s).replace(/\x1b\[[0-9;]*m/g, '')
const wide = (ch) => {
  const code = ch.codePointAt(0)
  if (!code) return 0
  // Emoji and CJK occupy two terminal cells. This is the usual approximation.
  if (code >= 0x1100 && code <= 0x115F) return 2
  if (code >= 0x2E80 && code <= 0xA4CF) return 2
  if (code >= 0xAC00 && code <= 0xD7A3) return 2
  if (code >= 0xF900 && code <= 0xFAFF) return 2
  if (code >= 0xFE30 && code <= 0xFE6F) return 2
  if (code >= 0xFF00 && code <= 0xFF60) return 2
  if (code >= 0xFFE0 && code <= 0xFFE6) return 2
  if (code >= 0x1F300 && code <= 0x1FAFF) return 2
  if (code >= 0x2600 && code <= 0x27BF) return 2
  if (code === 0xFE0F) return 0
  return 1
}
export function displayWidth(s) {
  let w = 0
  for (const ch of strip(s)) w += wide(ch)
  return w
}

const pad = (s, width) => s + ' '.repeat(Math.max(0, width - displayWidth(s)))
const padStart = (s, width) => ' '.repeat(Math.max(0, width - displayWidth(s))) + s

/** Clip to `width` cells, adding an ellipsis when it does not fit. */
export function clip(s, width) {
  if (displayWidth(s) <= width) return s
  let out = ''
  let w = 0
  for (const ch of strip(s)) {
    const cw = wide(ch)
    if (w + cw > width - 1) break
    out += ch
    w += cw
  }
  return out + '…'
}

/** Wrap to `width` cells. Returns as many lines as it needs. */
export function wrap(s, width) {
  const words = String(s).split(' ')
  const lines = []
  let line = ''
  for (const word of words) {
    const next = line ? `${line} ${word}` : word
    if (displayWidth(next) > width && line) {
      lines.push(line)
      line = word
    } else {
      line = next
    }
  }
  if (line) lines.push(line)
  return lines.length ? lines : ['']
}

/* ─────────────────────────────── glyphs ─────────────────────────────────── */

/*
 * The Astral mark. The game has no logo file, so the wordmark is drawn: a bar
 * chart rising into a star, which is both "streaming" and "the realm". It is
 * kept ASCII so it survives every terminal and every font.
 *
 *   ┌─── A S T R A L ───┐
 *   │   ◇  ASTRATOK  ◇  │
 *   └───────────────────┘
 */
export const MARK = [
  '   ✦   ✧   ✦   ',
  ' ┌─────────────┐',
  ' │  ASTRATOK  │',
  ' └─────────────┘',
]

/** Just the one-line wordmark, for headers and narrow layouts. */
export const WORDMARK = '✦ ASTRATOK ✦'

/* ──────────────────────────────── boxes ─────────────────────────────────── */

export function box(title, lines, width, { border = 'cyan', titleColor = 'brightCyan' } = {}) {
  const inner = Math.max(4, width - 4)
  const label = title ? ` ${title} ` : ''
  const dashes = Math.max(0, width - 4 - displayWidth(label))
  const top = `${c(border, '╭─')}${c(titleColor, label)}${c(border, '─'.repeat(dashes) + '╮')}`
  const body = lines.flatMap(l => wrap(l, inner)).map(l => `${c(border, '│')} ${pad(l, inner)} ${c(border, '│')}`)
  const bottom = c(border, `╰${'─'.repeat(width - 2)}╯`)
  return [top, ...body, bottom]
}

/** Two boxes of unequal height, side by side. */
export function sideBySide(left, right, gap = 1) {
  const h = Math.max(left.length, right.length)
  const lw = Math.max(...left.map(displayWidth), 0)
  const out = []
  for (let i = 0; i < h; i++) {
    out.push(pad(left[i] ?? '', lw) + ' '.repeat(gap) + (right[i] ?? ''))
  }
  return out
}

/** A bar: ██████░░░░ with a label and a value. */
export function bar(value, max, width, { fill = 'brightMagenta', empty = 'dim', left = '█', right = '░' } = {}) {
  const filled = Math.max(0, Math.min(width, Math.round((value / Math.max(1, max)) * width)))
  return c(fill, left.repeat(filled)) + c(empty, right.repeat(width - filled))
}

/** 4,213 · 41.2K · 1.3M */
export function n(value) {
  const v = Math.round(Number(value) || 0)
  if (v < 1_000) return String(v)
  if (v < 1_000_000) {
    const k = v / 1_000
    return (k % 1 === 0 ? k : k.toFixed(1)) + 'K'
  }
  const m = v / 1_000_000
  return (m % 1 === 0 ? m : m.toFixed(1)) + 'M'
}

/** mm:ss from milliseconds. */
export function mmss(ms) {
  const total = Math.max(0, Math.floor(ms / 1000))
  const m = Math.floor(total / 60)
  const s = total % 60
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
}

/* ─────────────────────────── frame composition ──────────────────────────── */

/**
 * Everything the renderer needs about one moment of a stream, and nothing it
 * does not. The renderer takes this shape only, which is what lets `--frame`
 * render a still and a test assert on it without booting the engine.
 */
export function viewModel(stream, { now = Date.now(), chat = null, events = [] } = {}) {
  const s = snapshot(stream, { now })
  const crowd = stream.crowd
  return {
    stream: s,
    chat: chat ?? [],
    events,
    topGifters: topViewers(crowd, { by: 'diamonds', limit: 5 }),
    topChatters: topViewers(crowd, { by: 'messages', limit: 5 }),
    regulars: regularsHere(crowd).map(v => v.handle),
    seated: crowd.seats.length,
    diamonds: stream.diamonds,
    giftSolars: stream.giftSolars,
    settlePreview: null,
  }
}

/**
 * The header: the mark, the title, and the three numbers that matter.
 * Deliberately the top of the screen in every style — when something goes wrong
 * in a stream, this is the row you look at.
 */
export function headerLines(vm, width, { totalMs = STREAM_LENGTH_MS } = {}) {
  const s = vm.stream
  const live = s.live ? c('brightRed', '● LIVE') : c('dim', '○ ENDED')
  const left = `${c('brightMagenta', WORDMARK)}  ${live}`
  const right = c('dim', mmss(s.uptimeMs) + ' / ' + mmss(totalMs))
  return [
    pad(left, width - displayWidth(right)) + right,
    c('italic', clip(s.title, width)),
    c('dim', `${s.boardEmoji} ${s.boardName}` + (s.dungeon ? `  ·  dungeon bonus +25%` : '  ·  town stream')),
    c('dim', '─'.repeat(width)),
  ]
}

/** The stream panel: viewers, followers, hype. The rail's left column. */
export function streamLines(vm, width) {
  const s = vm.stream
  const inner = width - 4
  const out = []
  out.push(`${c('brightCyan', '👁  VIEWERS')} ${padStart(c('bold', n(s.viewers)), inner - 12)}`)
  out.push(`${c('dim', 'peak ' + n(s.peak))}`)
  out.push(bar(s.viewers, Math.max(1, s.peak), Math.min(inner, 24), { fill: 'brightCyan' }))
  out.push('')
  out.push(`${c('brightYellow', '⭐ FOLLOWERS')} ${padStart(c('bold', n(s.followers)), inner - 14)}`)
  out.push(c('green', `+${n(s.followedThisStream)} this stream`))
  out.push('')
  out.push(`${c('brightMagenta', '⚡ HYPE')} ${c('bold', s.hype + '%')} ${hypeLabel(s.hype)}`)
  out.push(bar(s.hype, 100, Math.min(inner, 24), { fill: 'brightMagenta' }))
  out.push(c('dim', `payout x${hypeMultiplier(s.hype).toFixed(2)}`))
  out.push('')
  out.push(`${c('dim', '💬')} ${n(s.messages)} messages   ${c('dim', '👥')} ${n(vm.seated)} seated`)
  return out
}

/** The money panel. The rail's right column. */
export function moneyLines(vm, width) {
  const s = vm.stream
  const inner = width - 4
  const out = []
  out.push(`${c('brightYellow', '💎 DIAMONDS')} ${padStart(c('bold', n(vm.diamonds)), inner - 14)}`)
  out.push(`${c('brightGreen', '☀  EARNED')} ${padStart(c('bold', n(vm.giftSolars)), inner - 12)}`)
  out.push(`${c('cyan', '🎁 GIFTS')} ${padStart(c('bold', String(s.giftCount)), inner - 11)}`)

  const subs = s.subs ?? {}
  out.push('')
  out.push(c('dim', 'SUBSCRIBERS'))
  const t1 = subs.tier1 ?? 0, t2 = subs.tier2 ?? 0, t3 = subs.tier3 ?? 0
  out.push(`  ⭐ T1 ${padStart(String(t1), 4)}   ⭐⭐ T2 ${padStart(String(t2), 4)}   ⭐⭐⭐ T3 ${padStart(String(t3), 3)}`)

  out.push('')
  if (vm.topGifters.length) {
    out.push(c('dim', 'TOP GIFTERS'))
    vm.topGifters.forEach((v, i) => {
      const rank = ['🥇', '🥈', '🥉'][i] ?? `${i + 1}.`
      out.push(`  ${rank} ${clip(v.handle, inner - 10)} ${c('yellow', n(v.diamondsSent) + '💎')}`)
    })
  } else {
    out.push(c('dim', 'no gifts yet'))
  }
  return out
}

/**
 * The chat panel: the actual comments, newest last, with the badge a client
 * would show (a medal for a named regular, a star for a subscriber).
 */
export function chatLines(vm, width) {
  const inner = width - 4
  return vm.chat.slice(-14).map((l) => {
    const badge = l.regular ? '🏅' : l.sub ? '⭐' : ' '
    const handle = c(l.regular ? 'brightYellow' : l.sub ? 'brightCyan' : 'cyan', clip(l.handle, 14))
    const name = pad(handle, 15)
    return `${badge} ${name}${clip(l.text, Math.max(6, inner - 17))}`
  })
}

/** The event ticker: what happened this minute, in the order it happened. */
export function eventLines(vm, width) {
  const inner = width - 4
  if (!vm.events.length) return [c('dim', 'waiting for the room to move…')]
  return vm.events.slice(-6).map(e => clip(e, inner))
}

/**
 * Compose one full frame.
 *
 * `style` is the layout: 'rail' is three columns for a wide terminal, 'board' is
 * the narrow single column that matches the phone. Width is respected down to
 * about 60 cells; below that 'board' is the only sane choice and the caller
 * should pick it.
 */
export function renderFrame(vm, { width = 100, style = 'rail', color = null } = {}) {
  const previous = USE_COLOR
  if (color != null) USE_COLOR = !!color
  try {
    return renderFrameInner(vm, { width, style })
  } finally {
    USE_COLOR = previous
  }
}

/**
 * cinema — the broadcast layout.
 *
 * One big number, because that is what a stream is: a live audience. The
 * followers and the money sit under it at half the weight, and the chat runs
 * along the bottom like subtitles. It is deliberately NOT a dashboard: a
 * dashboard is for the streamer, and this is for someone glancing at a screen.
 */
export function cinemaLines(vm, width) {
  const s = vm.stream
  const out = []
  const live = s.live ? c('brightRed', '● LIVE') : c('dim', '○ ENDED')
  out.push(c('brightMagenta', MARK[0]))
  out.push(c('brightMagenta', MARK[1]))
  out.push(c('brightMagenta', MARK[2]) + '   ' + live + '  ' + c('dim', mmss(s.uptimeMs)))
  out.push(c('brightMagenta', MARK[3]))
  out.push('')
  out.push(c('bold', clip(s.playerName + '  ·  ' + s.title, width)))
  out.push(c('dim', clip(`${s.boardEmoji} ${s.boardName}${s.dungeon ? '  ·  dungeon +25%' : ''}`, width)))
  out.push('')
  const big = n(s.viewers)
  out.push(c('brightCyan', '👁  ' + big) + '  ' + c('dim', 'watching      peak ' + n(s.peak)))
  out.push(bar(s.viewers, Math.max(1, s.peak), Math.max(10, Math.min(width - 2, 46)), { fill: 'brightCyan' }))
  out.push('')
  out.push(c('brightYellow', '⭐ ' + n(s.followers)) + c('dim', ' followers  ') +
    c('green', '+' + n(s.followedThisStream)) + '   ' +
    c('brightGreen', '☀ ' + n(vm.giftSolars)) + c('dim', ' earned') + '   ' +
    c('brightMagenta', s.hype + '% hype'))
  out.push('')
  out.push(c('dim', '─'.repeat(width)))
  // The chat as subtitles: the last lines, with the newest brightest.
  const lines = vm.chat.slice(-5)
  lines.forEach((l, i) => {
    const newest = i === lines.length - 1
    const badge = l.regular ? '🏅' : l.sub ? '⭐' : '·'
    const body = clip(`${badge} ${l.handle}: ${l.text}`, width)
    out.push(newest ? c('white', body) : c('dim', body))
  })
  if (!lines.length) out.push(c('dim', 'waiting for chat…'))
  return out
}

/**
 * ticker — the log layout.
 *
 * No boxes, no bars: one line per thing that happened, oldest first, with the
 * minute it happened on. It is the honest view when the terminal is 80 columns
 * in a tmux pane, and it is the one you can pipe into a file and read later
 * without a terminal emulator stripping the art.
 */
export function tickerLines(vm, width) {
  const s = vm.stream
  const out = []
  const stamp = mmss(s.uptimeMs)
  const live = s.live ? 'LIVE ' : 'ENDED'
  out.push(c('brightMagenta', `${WORDMARK} `) + c('brightRed', live) + c('dim', ` ${stamp}  ${n(s.viewers)} viewers  ${n(s.followers)} followers  ${s.hype}% hype`))
  out.push(c('dim', '─'.repeat(width)))
  const rows = []
  for (const l of vm.chat) {
    const badge = l.regular ? '🏅' : l.sub ? '⭐' : ' '
    rows.push(`${c('dim', stamp)} ${badge}${c('cyan', pad(clip(l.handle, 14), 15))}${clip(l.text, Math.max(8, width - 26))}`)
  }
  for (const e of vm.events) rows.push(`${c('dim', stamp)} ${c('yellow', '◆')} ${clip(e, Math.max(8, width - 20))}`)
  out.push(...rows.slice(-Math.max(6, vm.rows ?? 18)))
  if (!rows.length) out.push(c('dim', 'the room is quiet'))
  return out
}

function renderFrameInner(vm, { width = 100, style = 'rail' } = {}) {
  const w = Math.max(56, Math.min(width, 140))
  const header = headerLines(vm, w)

  // cinema draws its own mark and header: it does not want the rail's strip.
  if (style === 'cinema') return cinemaLines(vm, w).join('\n')
  if (style === 'ticker') return tickerLines(vm, w).join('\n')

  if (style === 'board' || w < 86) {
    const board = [
      ...header,
      '',
      ...box('THE STREAM', streamLines(vm, w), w),
      ...box('CHAT', chatLines(vm, w), w, { border: 'magenta', titleColor: 'brightMagenta' }),
      ...box('MONEY', moneyLines(vm, w), w, { border: 'yellow', titleColor: 'brightYellow' }),
      ...box('EVENTS', eventLines(vm, w), w, { border: 'dim', titleColor: 'dim' }),
    ]
    return board.join('\n')
  }

  // rail: left column is the stream, middle is chat, right is money.
  const leftW = 28
  const rightW = 30
  const midW = w - leftW - rightW - 2

  const left = box('STREAM', streamLines(vm, leftW), leftW)
  const mid = box('CHAT', chatLines(vm, midW), midW, { border: 'magenta', titleColor: 'brightMagenta' })
  const right = box('MONEY', moneyLines(vm, rightW), rightW, { border: 'yellow', titleColor: 'brightYellow' })

  const body = sideBySide(sideBySide(left, mid), right)
  const ticker = box('EVENTS', eventLines(vm, w), w, { border: 'dim', titleColor: 'dim' })
  return [...header, ...body, ...ticker].join('\n')
}

/* ─────────────────────────────── driver ─────────────────────────────────── */

/**
 * Run a stream and render frames.
 *
 * `onFrame` is called with each rendered string, so the same function serves the
 * terminal (which writes to stdout) and the tests (which capture the strings).
 * This is the one entry point the CLI below and the dashboard test share.
 */
export async function runStream({
  playerName = 'Astra Wanderer',
  followers = 12_400,
  seed = 1234,
  dungeon = false,
  style = 'rail',
  width = 100,
  speed = 1,
  frames = 0,
  lengthMs = STREAM_LENGTH_MS,
  onFrame = null,
  onTick = null,
  now = () => Date.now(),
} = {}) {
  const rng = mulberry32(seed)
  const stream = openStream({
    playerId: 'dashboard',
    playerName,
    followers,
    dungeon,
    dungeonLabel: dungeon ? 'Cloudpiercer Hollow' : null,
    seed,
    lengthMs,
  })
  // The seed above is used by openStream's own rng; point the stream at the same
  // sequence the driver holds so a replayed run is byte identical.
  stream.rng = rng

  const chat = []
  let rendered = 0
  let t = 0
  const minutes = Math.ceil(lengthMs / 60_000)

  for (let minute = 1; minute <= minutes; minute++) {
    // What the streamer is doing. The demo alternates deliberately so both the
    // quiet and the loud path are visible in a short run.
    if (dungeon || minute % 3 === 0) {
      setMoment(stream, minute % 5 === 0 ? 'boss' : 'combat', {
        boss: 'Sky Dragon', floor: 8 + minute, action: 'fighting on the floor',
        target: 'Sky Dragon', hp: Math.max(10, 100 - minute * 4),
      })
    } else if (minute % 4 === 1) {
      setMoment(stream, 'chat')
    }

    t += 60_000
    const bag = tick(stream, { now: stream.startedAt + t })
    if (!bag) break

    for (const l of bag.lines) chat.push(l)
    while (chat.length > 200) chat.shift()

    const events = []
    if (bag.spike) events.push(`${bag.spike.kind === 'boss' ? '🐉' : bag.spike.kind === 'clip' ? '📎' : '🎁'} ${bag.spike.kind} spike · +${bag.spike.arrivals.length} viewers`)
    for (const g of bag.gifts) events.push(`🎁 ${g.from} sent ${g.gift.emoji} ${g.gift.name} (${n(g.gift.diamonds)}💎)`)
    for (const f of bag.follows.slice(0, 2)) events.push(`➕ ${f.handle} followed`)
    for (const sub of bag.subs) events.push(`⭐ ${sub.viewer.handle} subscribed T${sub.tier}`)
    for (const d of bag.departures.slice(0, 2)) events.push(`↘ ${d.handle} left`)

    const vm = viewModel(stream, { now: stream.startedAt + t, chat, events })
    const frame = renderFrame(vm, { width, style })
    rendered++
    if (onFrame) await onFrame(frame, { minute, stream, bag, vm })
    if (onTick) await onTick({ minute, stream, bag })

    if (frames && rendered >= frames) break
    if (bag.ended) break
    if (speed && onFrame) await new Promise(r => setTimeout(r, Math.max(0, 900 / speed)))
  }

  const closed = closeStream(stream, { now: stream.startedAt + t, reason: 'The stream ran its full length.' })
  return { stream, closed, frames: rendered }
}

/* ───────────────────────────────── cli ──────────────────────────────────── */

const isMain = process.argv[1] && import.meta.url.endsWith(process.argv[1].replace(/\\/g, '/'))

if (isMain) {
  // A typo must be loud. Silently falling back to rail is how a renderer gets
  // shipped that nobody ever actually looked at.
  if (!STYLES.includes(OPTIONS.style)) {
    console.error(`unknown --style "${OPTIONS.style}" (use one of: ${STYLES.join(', ')})`)
    process.exit(2)
  }
  setColor(OPTIONS.color && process.stdout.isTTY === true)

  if (OPTIONS.frame) {
    // One frame, for tests and for pasting into an issue.
    const rng = mulberry32(OPTIONS.seed)
    const stream = openStream({
      playerId: 'dashboard', playerName: OPTIONS.name, followers: OPTIONS.followers,
      dungeon: OPTIONS.dungeon, dungeonLabel: OPTIONS.dungeon ? 'Cloudpiercer Hollow' : null,
      seed: OPTIONS.seed,
    })
    stream.rng = rng
    const chat = []
    let events = []
    for (let i = 1; i <= 8; i++) {
      setMoment(stream, i % 3 === 0 ? 'boss' : 'combat', { boss: 'Sky Dragon', floor: 8 + i, action: 'fighting on the floor' })
      const bag = tick(stream, { now: stream.startedAt + i * 60_000 })
      chat.push(...bag.lines)
      events = bag.gifts.map(g => `🎁 ${g.from} sent ${g.gift.name}`)
    }
    const vm = viewModel(stream, { now: stream.startedAt + 8 * 60_000, chat, events })
    process.stdout.write(renderFrame(vm, { width: process.stdout.columns || 100, style: OPTIONS.style }) + '\n')
    process.exit(0)
  }

  const width = process.stdout.columns || 100
  const clear = () => (process.stdout.isTTY ? process.stdout.write('\x1b[2J\x1b[H') : null)

  const result = await runStream({
    playerName: OPTIONS.name,
    followers: OPTIONS.followers,
    seed: OPTIONS.seed,
    dungeon: OPTIONS.dungeon,
    style: OPTIONS.style,
    width,
    speed: OPTIONS.speed,
    frames: OPTIONS.frames,
    onFrame: (frame, { minute }) => {
      clear()
      process.stdout.write(frame + '\n')
      process.stdout.write(c('dim', `\n  minute ${minute}   ·   ctrl+c to quit   ·   seed ${OPTIONS.seed}`) + '\n')
    },
  })

  // The money, at the end. This is the one number the whole engine exists for.
  const k = result.closed
  if (k) {
    process.stdout.write('\n' + c('brightGreen', '═══ SETTLEMENT ═══') + '\n')
    process.stdout.write(`  audience  ${c('brightGreen', n(k.followerSolars))}   subs  ${c('brightGreen', n(k.subscriberSolars))}   gifts  ${c('brightGreen', n(k.giftSolars))}\n`)
    process.stdout.write(`  ${c('bold', 'TOTAL ' + n(k.total) + ' ☀️')}${k.gems ? c('cyan', ' + ' + k.gems + ' 💎') : ''}\n`)
    process.stdout.write(c('dim', `  peak ${n(k.peak)} viewers · +${n(k.newFollowers)} followers · ${n(k.messages)} messages\n`))
  }
}
