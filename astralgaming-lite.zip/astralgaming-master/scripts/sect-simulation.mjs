/**
 * sect-simulation.mjs — 90 simulated days in the Sect Empire (Prompt 8).
 *
 * Plays three kinds of player through the same daily routine the prompt
 * names — one cave session, hunts up to the day's cap, tasks up to the
 * day's cap, one secret realm run, and the trades — using the REAL
 * constants and helpers (progress needs, cave rates, the hunt cap, task
 * rewards, shop prices, the conversion rate), and checks the four balance
 * targets:
 *
 *   1. cave-only pacing (Awakening 3 days, Qi Condensation ~8 weeks,
 *      Foundation Establishment ~10 weeks, 1.5x per realm after), with
 *      fighting 2 to 3 times faster;
 *   2. a breakthrough pill costs about 3 to 5 days of normal income, and
 *      a normal player can afford it by the bottleneck;
 *   3. no single way of earning dominates: value per hour within a factor
 *      of 2, fighting best for progress, tasks best for Spirit Stones;
 *   4. the Spirit Stone -> Solars conversion cannot flood Astra Kingdom:
 *      even a hard-core player's whole day of stones, converted, is small
 *      next to the daily cap, and the cap itself is the wall.
 *
 *   node scripts/sect-simulation.mjs
 *
 * Read only. Prints tables; exits non-zero when a target misses, so the
 * test suite can hold the tuning where this script put it.
 */
import { CAVES, awakeningNeed, progressNeed, sessionRate } from '../lib/sect-progress.js'
import { REALMS, stageByIndex } from '../lib/sect-cultivation.js'
import { huntCfg, dailyCapPoints, huntRate } from '../lib/sect-hunt.js'
import { boardFor, canTakeRank, rewardFor, dailyLimit } from '../lib/sect-tasks.js'
import { SECTS, rankCapOf, rankIndex } from '../lib/sect-sects.js'
import { conversion } from '../lib/sect-items.js'
import { SOLARS_PER_STONE, DAILY_SOLARS_CAP } from '../lib/sect-wayback.js'
import { CROSSING_OUT_SOLARS } from '../lib/sect-crossing.js'

let failures = 0
const check = (label, ok, detail = '') => {
  console.log(`  ${ok ? 'OK  ' : 'OFF '} ${label}${detail ? `  ${detail}` : ''}`)
  if (!ok) failures++
}

// ── the three players ───────────────────────────────────────────────────────
// hours = a real day of play; cave is one session, the rest is the routine.
const PLAYERS = {
  casual:   { caveHours: 2, huntShare: 0.25, tasks: 2, ruinsRuns: 0, craftHours: 0, days: 90 },
  normal:   { caveHours: 8, huntShare: 0.6,  tasks: 5, ruinsRuns: 1, craftHours: 1, days: 90 },
  hardcore: { caveHours: 8, huntShare: 1,    tasks: 5, ruinsRuns: 1, craftHours: 2, days: 90 },
}
const reference = { spiritRoot: { speedMultiplier: 1 }, stage: 10 }

// ── 1. pacing ───────────────────────────────────────────────────────────────
console.log('SECT SIMULATION — 90 days, three players\n')
console.log('1. PACING (cave-only against the targets, fighting against the cave)')
const cave = CAVES[0]
const caveRate = sessionRate(reference, cave) // progress per hour, root x1
const caveDay = caveRate * 8
const realmNeed = (realm) => realm.stages.reduce((sum, s) => sum + progressNeed(s.index), 0)
const qcDays = realmNeed(REALMS.find(r => r.id === 'qi_condensation')) / caveDay
const feDays = realmNeed(REALMS.find(r => r.id === 'foundation_establishment')) / caveDay
const cfDays = realmNeed(REALMS.find(r => r.id === 'core_formation')) / caveDay
const nsDays = realmNeed(REALMS.find(r => r.id === 'nascent_soul')) / caveDay
check('the Awakening takes 3 days of 8h cave days', Math.abs(awakeningNeed() / 8 - 3) <= 0.2, `${(awakeningNeed() / 8).toFixed(1)}d`)
check('Qi Condensation takes about 8 weeks cave-only', Math.abs(qcDays / 7 - 8) / 8 <= 0.15, `${(qcDays / 7).toFixed(1)}w`)
check('Foundation Establishment takes about 10 weeks cave-only', Math.abs(feDays / 7 - 10) / 10 <= 0.15, `${(feDays / 7).toFixed(1)}w`)
check('each realm after takes 1.5x the one before', Math.abs(cfDays / feDays - 1.5) <= 0.08 && Math.abs(nsDays / cfDays - 1.5) <= 0.08,
  `CF x${(cfDays / feDays).toFixed(2)}, NS x${(nsDays / cfDays).toFixed(2)}`)
const huntDay = dailyCapPoints(reference)
const fightPace = (huntRate(reference) * Number(huntCfg.progress?.dailyCapCaveHours ?? 24)) / caveDay
check('hard fighting runs 2 to 3 times the cave pace, never more', fightPace >= 2 && fightPace <= 3.01,
  `a full hunting day is worth ${fightPace.toFixed(2)} full cave days, and the daily cap is the wall`)

// ── daily routine, per player ───────────────────────────────────────────────
// What the Mission Hall pays is read off REAL boards (boardFor), one rank at a
// time. The board is each mountain's own and each rank's: an Elder's work is
// not on a servant's board nor a servant's on an Elder's, so "the average of
// every template in the file" is nobody's day. A task here is one the player
// of that rank can take, paid at that rank (rewardFor folds the multiplier in).
const BOARD_DAYS = 200
const BOARD_T0 = Date.UTC(2026, 0, 5, 12)
function boardPay(rank) {
  const sum = { contribution: 0, stones: 0, hours: 0, n: 0 }
  for (const sect of SECTS) {
    const cap = rankCapOf(sect)
    if (cap && rankIndex(rank) > rankIndex(cap)) continue
    const profile = { sectId: sect.id, sectRank: rank }
    for (let day = 0; day < BOARD_DAYS; day++) {
      for (const task of boardFor(profile, `sim-${day % 7}`, { now: BOARD_T0 + day * 86_400_000 })) {
        if (!canTakeRank(profile, task)) continue
        const pay = rewardFor(profile, task)
        sum.contribution += pay.contribution
        sum.stones += pay.stones
        sum.hours += Number(task.target?.hours) || 0.25 // a chore's hours; anything else is a quarter hour's walk
        sum.n++
      }
    }
  }
  const n = Math.max(1, sum.n)
  return { contribution: sum.contribution / n, stones: sum.stones / n, hours: sum.hours / n }
}
const BOARD = Object.fromEntries(['servant', 'outer_disciple', 'inner_disciple'].map(rank => [rank, boardPay(rank)]))
const WHOSE = { servant: "a servant's", outer_disciple: "an Outer Disciple's", inner_disciple: "an Inner Disciple's" }
// The three players are at the reference stage (10): Outer Disciples.
const avgTask = BOARD.outer_disciple
const contributionPerStone = Math.max(1, Number(conversion.items?.shop?.contributionPerStone ?? 2))

// Hunting stones: the tier table's mean, with a beast's material share and a
// demonic cultivator's purse averaged the way the areas deal them.
const stoneTable = huntCfg.drops?.stonesByTier ?? conversion.monsters?.drops?.stonesByTier ?? {}
const tierStones = (tier) => {
  const [lo, hi] = stoneTable[String(tier)] ?? [0, 0]
  return ((Number(lo) + Number(hi)) / 2) * 0.55 // not every kill carries coin
}
const KILLS_PER_DAY_AT_CAP = Math.ceil(dailyCapPoints(reference) / huntRate(reference) * 1) // kills to fill the cap, roughly

function simulate(kind) {
  const p = PLAYERS[kind]
  const progressPerDay = caveRate * p.caveHours + huntDay * p.huntShare
  const stonesTasks = avgTask.stones * p.tasks
  const kills = Math.round((dailyCapPoints(reference) * p.huntShare) / Math.max(1, huntRate(reference)))
  const stonesHunt = kills * tierStones(2)
  const stonesRuins = p.ruinsRuns * 45 // a run's kept stones, averaged over its rooms
  const contribution = avgTask.contribution * p.tasks
  return {
    kind, progressPerDay,
    stonesPerDay: stonesTasks + stonesHunt + stonesRuins,
    stonesTasks, stonesHunt, stonesRuins, contribution,
    kills,
  }
}

console.log('\n2. INCOME AND THE BREAKTHROUGH PILL')
const sims = Object.keys(PLAYERS).map(simulate)
for (const s of sims) {
  console.log(`  ${s.kind.padEnd(9)} progress/day ${Math.round(s.progressPerDay)}  stones/day ${Math.round(s.stonesPerDay)} ` +
    `(tasks ${Math.round(s.stonesTasks)}, hunts ${Math.round(s.stonesHunt)}, realms ${Math.round(s.stonesRuins)})  contribution/day ${Math.round(s.contribution)}`)
}
const normal = sims.find(s => s.kind === 'normal')
const priceTable = conversion.items?.shop?.priceByGrade ?? []
for (const [rank, pay] of Object.entries(BOARD)) {
  console.log(`  ${WHOSE[rank]} board: ${Math.round(pay.contribution)} contribution and ${Math.round(pay.stones)} stones a task, ${pay.hours.toFixed(2)}h each`)
}
// THE PRICE HERE IS THE BY-GRADE TABLE (items.shop.priceByGrade): what a pill
// costs wherever no shelf posts a price of its own. The sects' counters DO post
// their own for the breakthrough pills (data/sects.json shop.stock `price`,
// with a restock clock), and those are paid mostly out of secret realm clears,
// which this simulation does not model. Read these three lines as "the table
// and the board still agree", not as what the counter charges.
for (const [pill, grade, label, rank] of [['Foundation', 2, 'Qi Condensation -> Foundation', 'servant'], ['Golden Core', 3, 'Foundation -> Core', 'outer_disciple'], ['Nascent Soul', 4, 'Core -> Nascent', 'inner_disciple']]) {
  // The income that pays for a pill is the income of ITS stage: the board of
  // the rank a player holds while they are saving for it.
  const contributionCost = Number(priceTable[grade] ?? 0) * contributionPerStone
  const days = contributionCost / Math.max(1, BOARD[rank].contribution * PLAYERS.normal.tasks)
  check(`the ${pill} Pill costs 3 to 5 days of normal income`, days >= 2.5 && days <= 5.5,
    `${contributionCost} contribution = ${days.toFixed(1)} days of ${WHOSE[rank]} board (${label})`)
}
const qcTotalDays = qcDays // a normal player's contribution is banked the whole climb
const servantDay = BOARD.servant.contribution * PLAYERS.normal.tasks
check('a normal player affords the Foundation Pill long before the bottleneck',
  servantDay * (qcTotalDays / 2) >= Number(priceTable[2] ?? 0) * contributionPerStone,
  `half the climb banks ${Math.round(servantDay * qcTotalDays / 2)} contribution at a servant's pay`)

// ── 3. no single way dominates ──────────────────────────────────────────────
console.log('\n3. VALUE PER HOUR (fighting best for progress, tasks best for stones)')
// Nominal hours: a hunt cap takes about two hours of real fighting, the
// board about two hours of errands and chores, a realm run about an hour,
// a bench hour is an hour. Progress is counted in progress points, stones
// in Spirit Stones; each column must sit within a factor of 2 of its best.
const avgTaskHours = avgTask.hours
const perHour = {
  cave:   { progress: caveRate, stones: 0 },
  hunt:   { progress: huntDay / 3.5, stones: normal.stonesHunt / 3.5 },
  tasks:  { progress: 0, stones: normal.stonesTasks / Math.max(0.25, avgTaskHours * PLAYERS.normal.tasks) },
  ruins:  { progress: 0, stones: normal.stonesRuins / 1.5 },
  craft:  { progress: 0, stones: Number(priceTable[1] ?? 30) / 1 }, // a brewed dose is a bought dose unspent
}
for (const [name, v] of Object.entries(perHour)) {
  console.log(`  ${name.padEnd(7)} progress/h ${v.progress.toFixed(1).padStart(7)}  stones/h ${v.stones.toFixed(1).padStart(7)}`)
}
check('fighting is the best progress per hour', perHour.hunt.progress >= perHour.cave.progress)
check('the cave is never made pointless: a day of both beats a day of either, capped at 3x', fightPace <= 3.01 && caveRate > 0,
  `hunting is capped at ${fightPace.toFixed(2)} cave days a day, and the session still pays on top`)
check('tasks are the best Spirit Stones per hour', perHour.tasks.stones >= perHour.hunt.stones && perHour.tasks.stones >= perHour.ruins.stones && perHour.tasks.stones >= perHour.craft.stones)
const stoneRates = [perHour.hunt.stones, perHour.ruins.stones, perHour.craft.stones].filter(v => v > 0)
check('hunt, realm and craft stones per hour sit within a factor of 2 of the board',
  stoneRates.every(v => perHour.tasks.stones / Math.max(1, v) <= 2.1),
  stoneRates.map(v => `x${(perHour.tasks.stones / Math.max(1, v)).toFixed(1)}`).join(', '))

// ── 4. the conversion cannot flood Astra Kingdom ────────────────────────────
console.log('\n4. THE CONVERSION')
const hardcore = sims.find(s => s.kind === 'hardcore')
const convertible = Math.floor(hardcore.stonesPerDay) * SOLARS_PER_STONE
check('a hard-core day of stones converts far under the daily cap', convertible <= DAILY_SOLARS_CAP / 10,
  `${convertible} Solars against a cap of ${DAILY_SOLARS_CAP}`)
// The walk down is paid in Solars now (crossing.outSolars); the old Spirit
// Stone fee is gone.
check('the walk down to Astra costs real money', CROSSING_OUT_SOLARS > 0, `${CROSSING_OUT_SOLARS.toLocaleString('en-US')} Solars to walk down`)

// ── the 90 days ─────────────────────────────────────────────────────────────
console.log('\nTHE 90 DAYS')
for (const s of sims) {
  const totalProgress = s.progressPerDay * 90
  console.log(`  ${s.kind.padEnd(9)} ${Math.round(totalProgress)} progress and ${Math.round(s.stonesPerDay * 90)} stones over 90 days ` +
    `(${(totalProgress / Math.max(1, realmNeed(REALMS[1]))).toFixed(2)} of Qi Condensation by progress alone)`)
}

console.log(failures ? `\n${failures} target(s) OFF` : '\nall targets hold')
process.exitCode = failures ? 1 : 0
