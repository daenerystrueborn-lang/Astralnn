#!/usr/bin/env node
/**
 * migrate-json-to-mongo.mjs — one-off upload of the local JSON world into
 * MongoDB, for flipping a bot over to DB_MODE=mongo-only.
 *
 * It moves BOTH halves of the bot's storage:
 *
 *   db.json        → the `users` collection (one doc per player) plus the
 *                    `meta` collection (one doc per other top-level db.data
 *                    key) — the exact document shape lib/mongo-adapter.js and
 *                    lib/mongo-only-adapter.js read, built with the same
 *                    buildOps/fingerprint code so the shape can't drift.
 *   data/*.json    → the `stores` collection (lib/state-store.js): group
 *                    settings, moderation, mod-GC, submissions, night mode,
 *                    spin locks, the three spawn lists, premium groups, the
 *                    Telegram registry, and pre-order listings. This list is
 *                    driven by STATE_STORE_IDS, so each new store must be
 *                    registered there to be migrated.
 *
 * Safety rails, in order of how much they save you:
 *
 *   • NOTHING is deleted, ever. Mongo docs that don't exist locally (players
 *     from another node, a key this file predates) stay exactly as they are —
 *     unlike `db-mongo.mjs push`, which makes Mongo match the file.
 *   • Existing Mongo data is never overwritten unless you pass --force.
 *     Without it, only MISSING documents are inserted, so running this against
 *     a live bot (or a half-migrated cluster) is idempotent and harmless.
 *     With --force, local values win for every doc that differs, but
 *     still no deletes.
 *   • --dry-run prints the whole plan and writes nothing. Run it first.
 *   • A count check runs after the upload: every local player/key/store must
 *     be present in Mongo afterwards, or the script exits non-zero and says
 *     which side disagrees. "It finished" is not evidence; a count is.
 *
 * Recommended sequence:
 *
 *   node scripts/db-mongo.mjs status                     # what each side holds
 *   node scripts/migrate-json-to-mongo.mjs --dry-run     # the plan
 *   (stop the bot)
 *   node scripts/migrate-json-to-mongo.mjs               # the upload
 *   # then set DB_MODE=mongo-only and start the bot; it refuses to boot an
 *   # empty world, so if the upload was incomplete the boot tells you.
 */

import { existsSync, readFileSync } from 'fs'
import { resolve } from 'path'
import { config } from '../config.js'
import { FastJSONFile } from '../lib/fast-json-adapter.js'
import {
  USERS_COLLECTION,
  META_COLLECTION,
  WRITER_LOCK_ID,
  BULK_CHUNK,
  fingerprint,
} from '../lib/mongo-adapter.js'
import { STATE_COLLECTION, STATE_STORE_IDS } from '../lib/state-store.js'
import { runtimePath } from '../lib/runtime-paths.js'

const [, ...argv] = process.argv.slice(2)
const has = (flag) => argv.includes(flag)
const val = (flag) => {
  const i = argv.indexOf(flag)
  return i >= 0 ? argv[i + 1] : undefined
}

const DRY_RUN = has('--dry-run')
const FORCE = has('--force')
const ONLY = val('--only') // 'db' | 'state' | undefined
const DB_PATH = resolve(val('--db-path') ?? config.dbPath)

if (ONLY && !['db', 'state'].includes(ONLY)) fail(`--only must be "db" or "state", got "${ONLY}"`)

function die(msg) {
  console.error(`❌ ${msg}`)
  process.exit(1)
}
function fail(msg) {
  die(msg)
}

const safeUri = String(config.mongoUri ?? '').replace(/\/\/[^@/]*@/, '//<credentials>@')
if (!config.mongoUri) die('MONGO_URI is not set in .env — there is no database to migrate INTO.')

const mb = (bytes) => `${(bytes / 1048576).toFixed(2)} MB`
const now = () => new Date().toISOString().slice(11, 19)

// ── 1. Load the local side ──────────────────────────────────────────────────

console.log(`Local database : ${DB_PATH}`)
console.log(`Target         : ${safeUri} / db "${config.mongoDbName}"`)
console.log(`Mode           : ${DRY_RUN ? 'DRY RUN (nothing will be written)' : FORCE ? 'FORCE — local values win, no deletes' : 'INSERT MISSING — existing Mongo data is left alone'}\n`)

let local = null
if (existsSync(DB_PATH)) {
  try {
    local = await new FastJSONFile(DB_PATH).read()
  } catch (err) {
    die(`${DB_PATH} could not be parsed: ${err.message}`)
  }
}
if (!local && ONLY !== 'state') {
  console.log(`⚠️ No local database at ${DB_PATH} — nothing from db.json to upload.`)
}
const localUsers = local?.users ?? {}
const localUserCount = Object.keys(localUsers).length
if (local && localUserCount === 0) {
  die(`${DB_PATH} has no players in it — migrating an empty world is how a backup gets silently wiped. Fix the file (or use --only state) and re-run.`)
}

/** db.data-shaped → the two collections' docs, same $set shape as the adapter. */
function buildDbDocs() {
  const userDocs = []
  for (const id of Object.keys(localUsers)) {
    const json = JSON.stringify(localUsers[id])
    userDocs.push({ _id: id, json, fp: fingerprint(json), updatedAt: new Date() })
  }
  const metaDocs = []
  for (const key of Object.keys(local ?? {})) {
    if (key === 'users') continue
    const json = JSON.stringify(local[key])
    metaDocs.push({ _id: key, json, fp: fingerprint(json), updatedAt: new Date() })
  }
  return { userDocs, metaDocs }
}

/** Side files → store docs. Missing files are skipped, never fabricated. */
function buildStateDocs() {
  const docs = []
  const missing = []
  for (const id of STATE_STORE_IDS) {
    const file = runtimePath(`${id}.json`)
    if (!existsSync(file)) { missing.push(id); continue }
    const raw = readFileSync(file, 'utf8')
    if (!raw.trim()) { missing.push(id); continue }
    let parsed
    try {
      parsed = JSON.parse(raw)
    } catch (err) {
      die(`Side file ${file} is not valid JSON (${err.message}). Fix it or delete it, then re-run.`)
    }
    const json = JSON.stringify(parsed)
    docs.push({ _id: id, json, fp: fingerprint(json), updatedAt: new Date() })
  }
  return { docs, missing }
}

// ── 2. Connect ──────────────────────────────────────────────────────────────

const { MongoClient } = await import('mongodb')
const client = new MongoClient(config.mongoUri, { serverSelectionTimeoutMS: 15_000, maxPoolSize: 4 })
try {
  await client.connect()
  await client.db(config.mongoDbName).command({ ping: 1 })
} catch (err) {
  die(`MongoDB unreachable (${err.message}). Check Atlas Network Access, the password, and MONGO_URI — in DB_MODE=mongo-only the bot will refuse to boot until this connects, too.`)
}
const db = client.db(config.mongoDbName)

async function close(msg, code = 0) {
  try { await client.close() } catch { /* whatever */ }
  if (msg) console.log(msg)
  process.exit(code)
}

// Writer-lock courtesy: a LIVE bot keeps its own state in RAM, so a migrate
// under it is safe for MISSING docs but a --force that fights the live writer
// for the same player will simply be overwritten by its next flush.
const lock = await db.collection(META_COLLECTION).findOne({ _id: WRITER_LOCK_ID }).catch(() => null)
const lockLive = lock?.holder?.heartbeat ? Date.now() - lock.holder.heartbeat < 90_000 : false
if (lockLive) {
  console.log(
    `ℹ️ A live writer holds the lock (pid ${lock.holder.pid} on "${lock.holder.host}"). ` +
    `Missing-doc inserts are safe; ${FORCE ? '--force uploads for keys the live bot also holds will be overwritten by its next save. Stop it first.' : 'they will be picked up by the running bot on its next fingerprint reload (restart, or the boot guard sees them).'}\n`,
  )
}

// ── 3. What already exists on the server ────────────────────────────────────

const [remoteUserIds, remoteMetaIds, remoteStoreIds] = await Promise.all([
  (ONLY === 'state') ? new Set() : new Set((await db.collection(USERS_COLLECTION).find({}, { projection: { _id: 1 } }).toArray()).map(d => String(d._id))),
  (ONLY === 'state') ? new Set() : new Set((await db.collection(META_COLLECTION).find({ _id: { $ne: WRITER_LOCK_ID } }, { projection: { _id: 1 } }).toArray()).map(d => String(d._id))),
  (ONLY === 'db') ? new Set() : new Set((await db.collection(STATE_COLLECTION).find({}, { projection: { _id: 1 } }).toArray()).map(d => String(d._id))),
])

const { userDocs, metaDocs } = ONLY === 'state' ? { userDocs: [], metaDocs: [] } : buildDbDocs()
const { docs: stateDocs, missing: missingState } = ONLY === 'db' ? { docs: [], missing: [] } : buildStateDocs()

const pick = (docs, existing) => FORCE ? docs : docs.filter(d => !existing.has(String(d._id)))
const userPlan = pick(userDocs, remoteUserIds)
const metaPlan = pick(metaDocs, remoteMetaIds)
const storePlan = pick(stateDocs, remoteStoreIds)
const skipped = (docs, plan) => docs.length - plan.length

const dbBytes = userPlan.reduce((n, d) => n + d.json.length, 0) + metaPlan.reduce((n, d) => n + d.json.length, 0)
const stBytes = storePlan.reduce((n, d) => n + d.json.length, 0)

console.log(`Plan — users   : ${userPlan.length} to write (${mb(dbBytes)}) · ${skipped(userDocs, userPlan)} already in Mongo, left alone`)
console.log(`Plan — meta    : ${metaPlan.length} to write · keys: ${metaPlan.map(d => d._id).join(', ') || '(none)'}`)
for (const d of [...userPlan, ...metaPlan]) {
  if (d.json.length > 8 * 1024 * 1024) fail(`doc ${d._id} is ${mb(d.json.length)} — over the 8MB warning line and near Mongo's 16MB cap. Split it before migrating.`)
}
console.log(`Plan — stores  : ${storePlan.length} to write (${mb(stBytes)}) · ${skipped(stateDocs, storePlan)} already in Mongo, left alone`)
if (storePlan.length) console.log(`               ${storePlan.map(d => d._id).join(', ')}`)
if (missingState.length) console.log(`               skipped (no local file): ${missingState.join(', ')}`)
const mongoOnlyPlayers = [...remoteUserIds].filter(id => !localUsers[id]).length
if (mongoOnlyPlayers) console.log(`ℹ️ ${mongoOnlyPlayers} player(s) exist in Mongo but not in the local file — kept as they are (this script never deletes).`)

if (DRY_RUN) {
  console.log(`\n🔎 Dry run — nothing written. Re-run without --dry-run to upload${FORCE ? '' : ' the missing documents'}.\n`)
  await close(null)
}

if (!userPlan.length && !metaPlan.length && !storePlan.length) {
  await close('\n✅ Nothing to do — every local document already exists in MongoDB.\n')
}

// ── 4. Upload ───────────────────────────────────────────────────────────────

async function upload(collection, docs, label) {
  if (!docs.length) return 0
  const col = db.collection(collection)
  let done = 0
  const t0 = Date.now()
  for (let i = 0; i < docs.length; i += BULK_CHUNK) {
    const chunk = docs.slice(i, i + BULK_CHUNK)
    // replaceOne-upsert keeps the doc EXACTLY as built (no $set merging with a
    // doc that a --force override shouldn't inherit fields from).
    await col.bulkWrite(
      chunk.map(d => ({ replaceOne: { filter: { _id: d._id }, replacement: d, upsert: true } })),
      { ordered: false },
    )
    done += chunk.length
    console.log(`[${now()}] ${label}: ${done}/${docs.length} written`)
  }
  console.log(`✅ ${label}: ${done} document(s) in ${(Date.now() - t0) / 1000}s`)
  return done
}

try {
  await upload(USERS_COLLECTION, userPlan, 'users')
  await upload(META_COLLECTION, metaPlan, 'meta')
  await upload(STATE_COLLECTION, storePlan, 'stores')
} catch (err) {
  await close(`\n❌ Upload failed mid-way (${err?.message ?? err}). Re-run to finish: existing docs are skipped without --force, so this is safe to repeat.`, 1)
}

// ── 5. Count check — the part that makes "done" mean something ──────────────

console.log('\n🧮 Verifying…')
const [finalUsers, finalMeta, finalStores] = await Promise.all([
  (ONLY === 'state') ? null : new Set((await db.collection(USERS_COLLECTION).find({}, { projection: { _id: 1 } }).toArray()).map(d => String(d._id))),
  (ONLY === 'state') ? null : new Set((await db.collection(META_COLLECTION).find({ _id: { $ne: WRITER_LOCK_ID } }, { projection: { _id: 1 } }).toArray()).map(d => String(d._id))),
  (ONLY === 'db') ? null : new Set((await db.collection(STATE_COLLECTION).find({}, { projection: { _id: 1 } }).toArray()).map(d => String(d._id))),
])

const problems = []
if (finalUsers) {
  const gone = Object.keys(localUsers).filter(id => !finalUsers.has(id))
  if (gone.length) problems.push(`users: ${gone.length} missing after upload (e.g. ${gone.slice(0, 3).join(', ')})`)
  console.log(`  users   : ${finalUsers.size} in Mongo ≥ ${localUserCount} in db.json ${gone.length ? '❌' : '✅'}`)
}
if (finalMeta) {
  const localMetaKeys = Object.keys(local ?? {}).filter(k => k !== 'users')
  const gone = localMetaKeys.filter(k => !finalMeta.has(k))
  if (gone.length) problems.push(`meta: missing ${gone.join(', ')}`)
  console.log(`  meta    : ${localMetaKeys.length - gone.length}/${localMetaKeys.length} keys present ${gone.length ? '❌' : '✅'}`)
}
if (finalStores) {
  const present = stateDocs.filter(d => finalStores.has(String(d._id)))
  const gone = stateDocs.filter(d => !finalStores.has(String(d._id)))
  if (gone.length) problems.push(`stores: missing ${gone.map(d => d._id).join(', ')}`)
  // byte-for-byte check while we're here: the stored json must equal what we uploaded
  const mismatch = []
  for (const doc of present) {
    const stored = await db.collection(STATE_COLLECTION).findOne({ _id: doc._id }, { projection: { fp: 1 } })
    if (stored?.fp && stored.fp !== doc.fp) mismatch.push(String(doc._id))
  }
  if (mismatch.length) problems.push(`stores: fingerprint mismatch on ${mismatch.join(', ')}`)
  console.log(`  stores  : ${present.length}/${stateDocs.length} files present${mismatch.length ? `, fingerprint drift: ${mismatch.join(', ')}` : ' ✅'}`)
}

if (problems.length) {
  await close(`\n❌ Count check FAILED:\n  ${problems.join('\n  ')}\n  The local files are untouched — fix the cluster and re-run; skipping existing docs makes this safe to repeat.`, 1)
}

await close(
  `\n✅ Migration verified — every local document is now in MongoDB "${config.mongoDbName}".\n` +
  `   Next: set DB_MODE=mongo-only (+ the same MONGO_URI) and start the bot. It reads the\n` +
  `   world from Mongo at boot, refuses to start on an unreachable one, and never touches\n` +
  `   db.json again. Keep the old files until you're happy — the bot will not delete them.\n`,
)
