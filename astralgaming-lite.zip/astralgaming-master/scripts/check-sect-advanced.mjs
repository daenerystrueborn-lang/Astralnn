/**
 * check-sect-advanced.mjs — a fast, database-free check of the four later
 * Sect Empire systems: bloodlines, beasts, bonds and the cultivation clock,
 * plus the post-Nascent-Soul profession work.
 *
 * Run with: node scripts/check-sect-advanced.mjs
 * Every assertion is a rule a player would notice. No network, no db, no RNG
 * (the one capture roll is injected), so the same seed and clock give the same
 * answer every time.
 */
import assert from 'node:assert/strict'
import { timeProblems, phaseAt, cycleMultiplier } from '../lib/sect-time.js'
import { bloodProblems, bloodlineById, grantMemory, awaken, echoFromMaster, caveMultiplier as bloodCave, fightEffects as bloodFx } from '../lib/sect-bloodlines.js'
import { beastProblems, beastById, resolveTame, feed, activeBeast, caveMultiplier as beastCave, fightEffects as beastFx, tameChance } from '../lib/sect-beasts.js'
import { requestFriend, acceptFriend, declareRival, caveMultiplier as bondCave, combatMods as bondMods, contributionMultiplier } from '../lib/sect-bonds.js'
import { makePlayerSide, makeSide, newFightState, checkOutcome } from '../lib/sect-combat.js'
import { addItem } from '../lib/sect-items.js'
import { advancedSectCommand } from '../lib/sect-advanced.js'
import { CONTENT_MAX_LEVEL, LEVELS, MAX_LEVEL } from '../lib/sect-professions.js'
import { alchemyRecipes, RECIPES, recipeProblems, furnaceName, craftRefusal, improveRefusal, benchOf, beginCraft, cancelBench, matchRecipe, craftWords } from '../lib/sect-craft.js'
import sectCraftPlugin from '../plugins/sectcraft.js'
import { artifactsData, artifactProblems } from '../lib/sect-artifacts.js'
import { materialProblems } from '../lib/sect-materials.js'
import { pillProblems } from '../lib/sect-pills.js'

let checks = 0
const ok = (what) => { checks++; console.log(`  ok  ${what}`) }

const makePlayer = (id, { sectId = 'cloudpiercer_pavilion', stage = 10 } = {}) => ({
  id, name: id.toUpperCase(), location: sectId,
  sect: { sectId, stage, stageName: 'Core Formation, Early', contribution: 500, stats: { hp: 100, qi: 100, attack: 100, defense: 100, speed: 100, soul: 100, fortune: 10 } },
})

console.log('DATA')
assert.deepEqual(timeProblems, [], 'time data')
assert.deepEqual(bloodProblems, [], 'bloodline data')
assert.deepEqual(beastProblems, [], 'beast data')
assert.deepEqual(artifactProblems, [], 'artifact data')
assert.deepEqual(materialProblems, [], 'material data')
assert.deepEqual(pillProblems, [], 'pill data')
assert.deepEqual(recipeProblems, [], 'recipe data')
ok('every new data file validates cleanly')

console.log('COMMAND SURFACE')
const screenCtx = (player, word) => ({ player, args: [word], reply: (text) => text })
assert.ok(String(await advancedSectCommand(screenCtx(makePlayer('reader'), 'time'), 'time')).includes('MOUNTAIN HOURS'))
assert.ok(String(await advancedSectCommand(screenCtx(makePlayer('reader'), 'bloodline'), 'bloodline')).includes('BLOODLINES'))
assert.ok(String(await advancedSectCommand(screenCtx(makePlayer('reader'), 'beast'), 'beast')).includes('BEASTS'))
assert.ok(String(await advancedSectCommand(screenCtx(makePlayer('reader'), 'bonds'), 'bonds')).includes('SECT BONDS'))
assert.equal(await advancedSectCommand(screenCtx(makePlayer('reader'), 'unknown'), 'unknown'), null)
ok('all four words open a screen; other words stay with the old dispatcher')

console.log('TIME CYCLES')
const at = (iso) => Date.parse(iso)
assert.equal(phaseAt(at('2026-01-01T04:00:00Z'))?.id, 'morning')
assert.equal(phaseAt(at('2026-01-01T11:00:00Z'))?.id, 'day')
assert.equal(phaseAt(at('2026-01-01T17:00:00Z'))?.id, 'dusk')
assert.equal(phaseAt(at('2026-01-01T22:00:00Z'))?.id, 'night')
const yang = makePlayer('yang', { sectId: 'cloudpiercer_pavilion' })
const yin = makePlayer('yin', { sectId: 'hollow_moon_sect' })
const neutral = makePlayer('neutral', { sectId: 'wayfarers_academy' })
assert.ok(cycleMultiplier(yang, at('2026-01-01T06:00:00Z')) > cycleMultiplier(yin, at('2026-01-01T06:00:00Z')))
assert.ok(cycleMultiplier(yin, at('2026-01-01T22:00:00Z')) > cycleMultiplier(yang, at('2026-01-01T22:00:00Z')))
assert.ok(cycleMultiplier(neutral, at('2026-01-01T06:00:00Z')) === cycleMultiplier(neutral, at('2026-01-01T22:00:00Z')))
ok('morning favours yang, night favours yin, the Academy stays even')

console.log('BLOODLINES')
const heir = makePlayer('heir', { stage: 10 })
const master = makePlayer('master', { stage: 10 })
const dragon = bloodlineById('azure_dragon')
for (const m of dragon.materials) addItem(heir.sect, m.id, m.count)
grantMemory(heir.sect, dragon.id, dragon.memoryNeeded)
const woke = awaken(heir, dragon)
assert.equal(woke.ok, true, JSON.stringify(woke.lines))
assert.equal(bloodCave(heir.sect), 1 + dragon.cave)
assert.equal(bloodFx(heir.sect)[0]?.trigger, dragon.effect.trigger)
const echo = echoFromMaster(master.sect, heir.sect)
assert.equal(echo.ok, true)
assert.equal(echo.line.id, dragon.id)
ok('memory + materials wake a line, and a sensei passes it to a student')

console.log('BEASTS')
const hunter = makePlayer('hunter', { stage: 10 })
const boar = beastById('mossback_boar')
addItem(hunter.sect, boar.bait, 2)
const chance = tameChance(hunter.sect, boar)
assert.ok(chance > 0 && chance <= 0.95)
const missed = resolveTame(hunter, boar, { rand: () => 1 })
const caught = resolveTame(hunter, boar, { rand: () => 0 })
assert.equal(missed.made, false)
assert.equal(caught.made, true)
assert.equal(activeBeast(hunter.sect)?.id, boar.id)
assert.ok(beastCave(hunter.sect) > 1)
assert.equal(beastFx(hunter.sect)[0]?.trigger, boar.effect.trigger)
addItem(hunter.sect, 'whisperleaf', 2)
const fed = feed(hunter, boar)
assert.equal(fed.ok, true, JSON.stringify(fed.lines))
assert.ok(fed.gain > 0)
ok('bait is spent, a beast is caught, and feeding raises the bond')

console.log('BONDS')
const one = makePlayer('one', { stage: 10 })
const two = makePlayer('two', { stage: 10 })
assert.equal(requestFriend(one, two).ok, true)
assert.equal(two.sect.bonds.pending.length, 1)
assert.equal(acceptFriend(two, one).ok, true)
assert.equal(one.sect.bonds.friends.length, 1)
assert.equal(two.sect.bonds.friends.length, 1)
const rivaled = declareRival(one, two)
assert.equal(rivaled.ok, true)
assert.equal(one.sect.bonds.rivals.length, 1)
assert.equal(two.sect.bonds.rivals.length, 1)
assert.ok(contributionMultiplier(one.sect) > 1)
assert.ok(bondCave(one.sect) < 1.1 && bondCave(one.sect) > 1)
assert.ok((bondMods(one.sect).critBonus ?? 0) > 0)
ok('friend requests, rivalries and their numbers are mirrored on both records')

console.log('COMBAT INTEGRATION')
const side = makePlayerSide({ ...heir.sect, beasts: hunter.sect.beasts, bonds: one.sect.bonds }, { name: 'heir' })
assert.ok(side.maxHp > heir.sect.stats.hp, 'bloodline share should reach the fight')
assert.ok(side.artifactEffects.some(f => f.bloodline))
assert.ok(side.artifactEffects.some(f => f.beast))
assert.ok(Object.values(side.classMods).some(v => typeof v === 'number'))
ok('inheritance, companion and bonds reach makePlayerSide')

// A divine blade's ON_DEATH is checked before the outcome is written.
const divineSide = makeSide({ key: 'a', stats: { hp: 100, qi: 20, attack: 10, defense: 5, speed: 5, soul: 5 } })
divineSide.fired = {}
divineSide.artifactEffects = [{
  key: 'divine:test', trigger: 'ON_DEATH', chance: 100, cooldown: 0, once: true,
  actions: [{ kind: 'revive', hpFraction: 0.4 }], set: false,
}]
const state = newFightState({ a: divineSide, b: makeSide({ key: 'b', stats: { hp: 100, qi: 20 } }), seed: 7 })
const events = []
state.a.hp = 0
checkOutcome(state, events)
assert.equal(state.over, false)
assert.ok(state.a.hp >= 40)
assert.ok(events.some(e => e.kind === 'revive'))
checkOutcome(state, events)
assert.equal(state.a.hp >= 40, true, 'a once-only death trigger cannot fire again')
ok('a divine ON_DEATH trigger revives once and then stays spent')

console.log('PROFESSIONS PAST NASCENT SOUL')
assert.equal(CONTENT_MAX_LEVEL, 9)
assert.ok(MAX_LEVEL >= 12 && LEVELS.length >= 13)
assert.ok(alchemyRecipes().some(r => r.id === 'brew_spirit_transformation_pill_5'))
assert.ok(alchemyRecipes().some(r => r.grade === 9))
assert.ok(RECIPES.some(r => r.level === 9 && r.profession === 'forging'))
assert.ok(RECIPES.some(r => r.level === 9 && r.profession === 'formations'))
assert.ok(RECIPES.some(r => r.level === 9 && r.profession === 'talismans'))
const divine = artifactsData.artifacts.find(a => a.grade === 'divine')
assert.ok(divine?.effect, 'a divine artifact needs a real effect')
assert.equal(divine.effect.trigger, 'ON_DEATH')
const high = makePlayer('high', { stage: 35 })
assert.equal(furnaceName(9), 'a tribulation furnace')
const { furnaceTierAt } = await import('../lib/sect-craft.js')
assert.equal(furnaceTierAt({ ...high, location: 'wayfarers_academy', sect: { ...high.sect, spot: 'library' } }, 'alchemy'), 9)
assert.ok(furnaceTierAt({ ...hunter, location: 'wayfarers_academy', sect: { ...hunter.sect, spot: 'library' } }, 'alchemy') < 9)
ok('nine grades of work, master benches, and a divine artifact with a death trigger')

console.log('CROSS-SYSTEM CONNECTIONS & STOCKED CONTENT')
const { MANUALS, manualProblems } = await import('../lib/sect-manuals.js')
const { ENEMIES, enemyProblems } = await import('../lib/sect-enemies.js')
const { HEAVENS, heavenProblems } = await import('../lib/sect-heavens.js')
const { SECRETS, secretEvent } = await import('../lib/sect-world-secrets.js')
const { pillById, usePill } = await import('../lib/sect-pills.js')
const {
  donateToMountainArray, activeMountainArray, resetMountainsMemory, mountainScreenLines,
} = await import('../lib/sect-mountain-state.js')
const { caveFate } = await import('../lib/sect-fate.js')
const { runPointers } = await import('../lib/sect-spar.js')
const { learnTechnique, equipTechnique } = await import('../lib/sect-techniques.js')

assert.deepEqual(manualProblems, [], 'manual data')
assert.deepEqual(enemyProblems, [], 'enemy data')
assert.deepEqual(heavenProblems, [], 'heaven data')
assert.ok(ENEMIES.length >= 8, 'named bosses and rivals populated')
assert.ok(HEAVENS.length >= 5, 'endgame hidden heavens populated')
assert.ok(SECRETS.length >= 5, '5 multi-fragment world secrets populated')
assert.equal(MANUALS.find(m => m.id === 'cloudpiercer_sword_manual')?.forms?.realm?.length, 9)

// Alchemy -> Beast Taming, Ruins Trap Veil, and Bloodline Memory pills
const alch = makePlayer('alch', { stage: 14 })
alch.sect.toxin = 30
addItem(alch.sect, 'spirit_lure_pill', 1, { grade: 3 })
addItem(alch.sect, 'breath_concealing_pill', 1, { grade: 2 })
addItem(alch.sect, 'ancestral_marrow_pill', 1, { grade: 3 })
const baseTame = tameChance(alch.sect, boar)
assert.equal(usePill(alch, pillById('spirit_lure_pill')).ok, true)
assert.ok(tameChance(alch.sect, boar) > baseTame, 'beast lure pill raises tame chance')
assert.equal(usePill(alch, pillById('breath_concealing_pill')).ok, true)
assert.ok(alch.sect.breathVeil >= 1, 'breath-concealing pill grants trap veil charges')
assert.equal(usePill(alch, pillById('ancestral_marrow_pill')).ok, true)
assert.ok(Object.values(alch.sect.bloodMemory ?? {}).some(v => v > 0), 'ancestral marrow pill stirs bloodline memory')
ok('alchemy utility pills connect directly to beast taming, ruins veils, and bloodlines')

// Shared Mountain Spirit Array -> caveFate & Chronicle
resetMountainsMemory()
const mockDb = { data: {} }
const donor = makePlayer('donor', { sectId: 'cloudpiercer_pavilion', stage: 14 })
donor.sect.spiritStones = 3000
const donated = donateToMountainArray(mockDb, donor, 2600, { now: 1_000_000 })
assert.equal(donated.ok, true)
assert.equal(activeMountainArray('cloudpiercer_pavilion', 1_000_000, mockDb)?.tier, 2)
const mtnFate = caveFate(donor.sect, { from: 1_000_000, to: 4_600_000 })
assert.ok(mtnFate.mountain > 1, 'lit mountain array boosts cave cultivation fate')
assert.ok(mountainScreenLines(donor, { db: mockDb, now: 1_000_000 }).join('\n').includes('Nine-Peak Convergence Array'))
resetMountainsMemory()
ok('shared mountain Spirit-Gathering Array buffs sectmates and writes db.data.sectMountains')

// Bonded friend / rival .spar synergy
learnTechnique(one.sect, 'cloud_parting_thrust')
equipTechnique(one.sect, 'cloud_parting_thrust')
learnTechnique(two.sect, 'cloud_parting_thrust')
equipTechnique(two.sect, 'cloud_parting_thrust')
const bout = runPointers(one.sect, two.sect, { now: 2_000_000, seed: 42, name: 'ONE', rivalName: 'TWO', rivalId: 'two' })
assert.ok(Array.isArray(bout.bondLines), 'bonded pointers returns bondLines')
ok('bonded friend and rival spars connect to mastery and sect contribution')

// World secret completion bridges title into player.stigma
const seeker = makePlayer('seeker', { stage: 20 })
for (const [kind, id] of [
  ['arrive', 'wayfarers_academy'],
  ['arrive', 'cloudpiercer_pavilion'],
  ['arrive', 'ironbone_fist_hall'],
  ['cave', 'mid_peak_cave'],
  ['rank', 'outer_disciple'],
  ['hunt', 'deepwood'],
]) {
  secretEvent(seeker, kind, id, { now: 3_000_000 })
}
assert.ok(seeker.sect.titles?.includes('Heir of the Unsplit Ridge'))
assert.ok(seeker.stigma?.includes('Heir of the Unsplit Ridge'))
ok('completing a 6-fragment World Secret bridges its title to Astra stigma')

console.log('CRAFT BENCH & NON-BENCH BUSY REFUSALS')
const crafter = makePlayer('crafter', { sectId: 'wayfarers_academy', stage: 10 })
crafter.world = 'sect_empire'
crafter.hp = 100; crafter.maxHp = 100; crafter.mp = 50; crafter.maxMp = 50
crafter.sect.professions = { alchemy: { level: 2, points: 0 }, forging: { level: 2, points: 0 } }
const healRecipe = matchRecipe('healing pill 1')
assert.equal(healRecipe?.id, 'brew_healing_pill_1', 'natural pill query resolves')
assert.equal(matchRecipe('qingfeng iron sword')?.id, 'forge_qingfeng_iron_sword', 'natural forge query resolves')

// 1. Gather running or ready never falsely says "Finish what is on the bench first."
crafter.sect.gather = { areaId: 'greenwillow_woods', startedAt: 1000, dueAt: 500_000 }
const gatherBusyMsg = craftRefusal(crafter, healRecipe, { now: 100_000 })
assert.ok(gatherBusyMsg.includes('gather collect') && !gatherBusyMsg.includes('on the bench first'))
const gatherReadyMsg = craftRefusal(crafter, healRecipe, { now: 600_000 })
assert.ok(gatherReadyMsg.includes('gather collect') && !gatherReadyMsg.includes('on the bench first'))
crafter.sect.gather = null

// 2. Mission Hall chore & fight never falsely say "Finish what is on the bench first."
crafter.sect.sectTask = { kind: 'chore', name: 'Sweep the stair', dueAt: 500_000 }
const choreMsg = craftRefusal(crafter, healRecipe, { now: 100_000 })
assert.ok(choreMsg.includes('Sweep the stair') && !choreMsg.includes('on the bench first'))
crafter.sect.sectTask = null

crafter.sectFight = { id: 'mock' }
const fightMsg = improveRefusal(crafter, null, { now: 100_000 })
assert.ok(fightMsg.includes('mid fight') && !fightMsg.includes('on the bench first'))
crafter.sectFight = null

// 3. Malformed gather={} and orphaned bench recipeId self-heal instead of wedging
crafter.sect.gather = {}
crafter.sect.bench = { recipeId: 'nonexistent_legacy_recipe', startedAt: 1000, dueAt: 999_999_999 }
assert.equal(benchOf(crafter.sect), null)
assert.equal(crafter.sect.bench, null)
const afterSelfHeal = craftRefusal(crafter, healRecipe, { now: 100_000 })
assert.ok(!afterSelfHeal?.includes('on the bench first'), 'self-healed empty gather & orphaned bench no longer block')

// 4. `.craft collect` on an empty bench says emptyBench (NOT craftWords.busy!), and `.craft cancel` clears a bench
const craftDb = { data: { users: { 'crafter@s.whatsapp.net': crafter } }, write: async () => {} }
const replies = []
await sectCraftPlugin.run({
  from: 'crafter@s.whatsapp.net',
  db: craftDb,
  player: crafter,
  args: ['collect'],
  reply: async (msg) => { replies.push(msg) },
})
assert.ok(replies[0]?.includes('Nothing is on the bench') && replies[0] !== craftWords.busy)

for (const row of healRecipe.materials) addItem(crafter.sect, row.id, row.count)
const startedBench = beginCraft(crafter, healRecipe, { now: 100_000 })
assert.equal(startedBench.ok, true)
assert.ok(benchOf(crafter.sect))
const cancelledBench = cancelBench(crafter)
assert.equal(cancelledBench.ok, true)
assert.equal(benchOf(crafter.sect), null)
ok('empty bench collect, non-bench blockers, orphaned benches, cancel, and natural recipe names all behave cleanly')

// ── 15. Regression (Ryuzen): "Not yet" on Mountain Road exits cleanly ────────
console.log('MOUNTAIN ROAD CROSSING CANCEL')
const { wayBackOpen, wayBackAnswer, isOnWayBack } = await import('../lib/sect-wayback.js')
const { roadOpen: openRoadUp, roadAnswer: answerRoadUp, isOnRoad, SECT_ENTRY_PLACE_ID } = await import('../lib/sect-road.js')

const ryuzen = {
  ...makePlayer('ryuzen', { sectId: SECT_ENTRY_PLACE_ID, stage: 4 }),
  world: 'sect_empire',
  location: SECT_ENTRY_PLACE_ID,
  ownedCharacters: ['monica'],
  wallet: { solars: 10_000_000, gems: 0 },
}

const openedDown = wayBackOpen(ryuzen, { now: 1_000_000 })
assert.equal(openedDown.ok, true)
assert.equal(isOnWayBack(ryuzen), true)

const declinedDown = wayBackAnswer(ryuzen, '2', { now: 1_001_000 })
assert.equal(declinedDown.ok, true)
assert.equal(declinedDown.kind, 'waited')
assert.equal(isOnWayBack(ryuzen), false, 'choosing option 2 ("Not yet") clears sectWayBack instead of looping')
assert.ok(!declinedDown.lines.join('\n').includes('1. *Walk down.*'), 'does not immediately re-ask the crossing prompt')
assert.equal(ryuzen.world, 'sect_empire', 'player remains safely in Sect Empire with zero toll spent')
assert.equal(ryuzen.wallet.solars, 10_000_000, 'no Solars toll deducted on "Not yet"')

// Road UP ("Not yet" on step 3) also exits cleanly without locking ROAD_ALLOWED_COMMANDS
const newcomer = {
  id: 'newcomer',
  name: 'Newcomer',
  world: 'astra_kingdom',
  location: 'astral_town',
  ownedCharacters: ['monica'],
  wallet: { solars: 1_000_000, gems: 0 },
  level: 10,
  sect: null,
}
openRoadUp(newcomer, { now: 2_000_000 })
answerRoadUp(newcomer, '1', { now: 2_001_000 })
answerRoadUp(newcomer, '1', { now: 2_002_000 })
const declinedUp = answerRoadUp(newcomer, '2', { now: 2_003_000 })
assert.equal(declinedUp.kind, 'waited')
assert.equal(isOnRoad(newcomer), false, 'choosing "Not yet" on road up clears sectRoad lock')
ok('choosing "Not yet" on the Mountain Road (both directions) exits cleanly without looping')

// ── 16. Pill Toxin Realm Scaling & Cure-Pill Exemption ───────────────────────
console.log('PILL TOXIN REALM SCALING & CURE EXEMPTION')
const { toxinDecayPerHour, toxinOf, toxinForPill } = await import('../lib/sect-items.js')
assert.equal(toxinDecayPerHour({ stage: 1 }), 2, 'Qi Condensation clears 2 toxin/hr')
assert.equal(toxinDecayPerHour({ stage: 10 }), 3, 'Foundation Establishment clears 3 toxin/hr')
assert.equal(toxinDecayPerHour({ stage: 14 }), 4, 'Core Formation clears 4 toxin/hr')
assert.equal(toxinDecayPerHour({ stage: 22 }), 6, 'Realm 5 clears 6 toxin/hr')
assert.equal(toxinDecayPerHour({ stage: 38 }), 10, 'Realm 9 clears 10 toxin/hr')

const highRealm = makePlayer('high_realm', { stage: 22 })
highRealm.sect.toxin = 30
highRealm.sect.toxinAt = 1_000_000
assert.equal(toxinOf(highRealm.sect, 1_000_000 + 2 * 3_600_000), 18, '2 hours at Realm 5 clears 12 toxin (6/hr)')

assert.equal(toxinForPill(pillById('bone_mending_pill'), 5), 0, 'cure pills add 0 toxin')
assert.equal(toxinForPill(pillById('ancestral_marrow_pill'), 8), 0, 'marrow detox pill adds 0 toxin')
highRealm.sect.toxin = 40
highRealm.sect.toxinAt = 5_000_000
addItem(highRealm.sect, 'ancestral_marrow_pill', 1, { grade: 5 })
const marrowRes = usePill(highRealm, pillById('ancestral_marrow_pill'), { now: 5_000_000 })
assert.equal(marrowRes.ok, true)
assert.equal(highRealm.sect.toxin, 15, 'Ancestral Marrow Pill purges full 25 toxin without adding new toxin back')
ok('hourly pill-toxin decay scales cleanly with realm (2 -> 10/hr) and cure pills add zero toxin')

console.log(`\n${checks} checks passed.`)
