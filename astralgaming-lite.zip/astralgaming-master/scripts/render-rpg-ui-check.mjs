/**
 * scripts/render-rpg-ui-check.mjs — visual check for lib/rpg-ui-render.mjs.
 *
 * Builds a believable player out of the real data/items.json (best-rarity piece
 * in every gear slot, a bag with stacked consumables) and renders:
 *
 *   rpg-ui-check-inventory.png    page 1 of the 5x4 inventory
 *   rpg-ui-check-inventory-2.png  page 2 (checks pagination and a short page)
 *   rpg-ui-check-equipment.png    paper-doll + 4x4 bag grid
 *
 *   node scripts/render-rpg-ui-check.mjs [outDir]
 */
import { readFileSync, writeFileSync, mkdirSync } from 'fs'
import { join, dirname } from 'path'
import { fileURLToPath } from 'url'
import { renderInventoryPanel, renderEquipmentPanel, stackInventory } from '../lib/rpg-ui-render.mjs'

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..')
const outDir = process.argv[2] ?? ROOT
mkdirSync(outDir, { recursive: true })

const items = JSON.parse(readFileSync(join(ROOT, 'data', 'items.json'), 'utf8'))
const byId = Object.fromEntries(items.map((i) => [i.id, i]))
const RANK = { common: 0, uncommon: 1, rare: 2, epic: 3, legendary: 4 }
const best = (pred) => items.filter(pred).sort((a, b) => RANK[b.rarity] - RANK[a.rarity])[0]

const equipped = {
  helmet:     best((i) => i.slot === 'helmet'),
  chestplate: best((i) => i.slot === 'chestplate'),
  boots:      best((i) => i.slot === 'boots'),
  offhand:    best((i) => i.type === 'armor' && i.slot === 'offhand'),
  weapon:     best((i) => i.slot === 'weapon' || i.type === 'weapon'),
  accessory:  best((i) => i.slot === 'accessory' || i.type === 'accessory'),
}

// player.inventory is a flat id list with repeats; stackInventory turns it into stacks.
// Every 3rd item, so the bag mixes armor, relics and consumables instead of 14 chestplates in a row.
const bag = items.filter((i) => !Object.values(equipped).includes(i)).filter((_, n) => n % 3 === 0).slice(0, 26)
const ids = bag.flatMap((i, n) => Array(i.type === 'consumable' ? 1 + ((n * 7) % 14) : 1).fill(i.id))
const stacks = stackInventory(ids, byId)

const write = (name, buf) => {
  writeFileSync(join(outDir, name), buf)
  console.log(`${name}  ${(buf.length / 1024).toFixed(0)} KiB`)
}

write('rpg-ui-check-inventory.png',   await renderInventoryPanel({ items: stacks, page: 0, coins: 48210, gems: 135, caption: 'HIRO' }))
write('rpg-ui-check-inventory-2.png', await renderInventoryPanel({ items: stacks, page: 1, coins: 48210, gems: 135, caption: 'HIRO' }))
write('rpg-ui-check-equipment.png',   await renderEquipmentPanel({
  equipped,
  items: stacks,
  durability: { helmet: 0.9, chestplate: 0.55, boots: 0.15, weapon: 1, offhand: 0.7 },
  caption: 'HIRO',
  summary: 'DEF 24 HP 120',
}))
