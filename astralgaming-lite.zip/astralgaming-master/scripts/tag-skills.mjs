/**
 * tag-skills.mjs — bake an element tag into every skill in data/skills.json.
 *
 * Run: node scripts/tag-skills.mjs          (writes the file)
 *      node scripts/tag-skills.mjs --check  (verifies, exits 1 if anything
 *                                            is untagged or mis-tagged)
 *
 * The classifier itself lives in lib/skill-element.js so combat code and this
 * script can never drift apart. Explicit `element` fields already on a record
 * are preserved. Re-running is idempotent: a second run produces no diff.
 */
import { readFileSync, writeFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'
import { elementOfSkill, affinityOfSkill, ELEMENTS, AFFINITY_SLOTS } from '../lib/skill-element.js'

const here = dirname(fileURLToPath(import.meta.url))
const dataPath = join(here, '..', 'data', 'skills.json')
const checkOnly = process.argv.includes('--check')

const skills = JSON.parse(readFileSync(dataPath, 'utf8'))

/** Rebuild one record with `element` and `affinity` sitting right after its `type` field. */
function withElement(skill) {
  const element = skill.element && ELEMENTS.includes(skill.element)
    ? skill.element
    : elementOfSkill(skill)
  const affinity = skill.affinity && AFFINITY_SLOTS.includes(skill.affinity)
    ? skill.affinity
    : affinityOfSkill({ ...skill, element })
  const out = {}
  for (const [key, value] of Object.entries(skill)) {
    if (key === 'element' || key === 'affinity') continue
    out[key] = value
    if (key === 'type') {
      out.element = element
      out.affinity = affinity
    }
  }
  if (!('element' in out)) out.element = element // records with no type field
  if (!('affinity' in out)) out.affinity = affinity
  return out
}

const tagged = skills.map(withElement)

// Distribution for the run log.
const dist = {}
const affDist = {}
for (const s of tagged) {
  dist[s.element] = (dist[s.element] ?? 0) + 1
  affDist[s.affinity] = (affDist[s.affinity] ?? 0) + 1
}

if (checkOnly) {
  const raw = JSON.parse(readFileSync(dataPath, 'utf8'))
  const stale = raw.filter((s, i) => !s.element || s.element !== tagged[i].element || !s.affinity || s.affinity !== tagged[i].affinity)
  if (stale.length) {
    console.error(`❌ ${stale.length} skill(s) need tagging — run node scripts/tag-skills.mjs`)
    process.exit(1)
  }
  console.log(`✅ all ${raw.length} skills carry current element + affinity slots`)
  process.exit(0)
}

writeFileSync(dataPath, JSON.stringify(tagged, null, 2) + '\n')
console.log(`Tagged ${tagged.length} skills in data/skills.json`)
console.log('Elements:', Object.entries(dist).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k}=${v}`).join(' '))
console.log('Affinities:', Object.entries(affDist).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k}=${v}`).join(' '))
