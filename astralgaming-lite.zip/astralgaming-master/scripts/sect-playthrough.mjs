/**
 * sect-playthrough.mjs — Full live character creation & playthrough of the
 * enhanced Sect Empire, from a Level 1 Astra Kingdom adventurer walking the
 * Mountain Road to conquering Cloudpiercer Pavilion's throne and returning home.
 *
 * Uses an in-memory DB only — touches zero persistent workspace files.
 */
import { buildNewPlayer } from '../lib/player-factory.js'
import { roadOpen, roadAnswer, SECT_ENTRY_PLACE_ID } from '../lib/sect-road.js'
import { startSession, collectSession, addSectProgress, progressNeed } from '../lib/sect-progress.js'
import { rebuildSectStats, MAX_STAGE_INDEX } from '../lib/sect-cultivation.js'
import { commitClass } from '../lib/sect-class.js'
import { heavenById, enter as enterHeaven } from '../lib/sect-heavens.js'
import { findRecord } from '../lib/sect-artifacts.js'
import { attemptBreakthrough } from '../lib/sect-breakthrough.js'
import { sectById, joinSect, completeJoin, applyPromotion } from '../lib/sect-sects.js'
import { hydrateMountains, donateToMountainArray, mountainScreenLines, resetMountainsMemory } from '../lib/sect-mountain-state.js'
import { setSkyDecree, turnWheel } from '../lib/sect-phenomena.js'
import '../lib/sect-hooks.js'
import { manualById, beginStudy, collectStudy } from '../lib/sect-manuals.js'
import { equipTechnique, knownTechniques } from '../lib/sect-techniques.js'
import { beginLesson, finishLesson } from '../lib/sect-professions.js'
import { beginCraft, collectBench, alchemyRecipes } from '../lib/sect-craft.js'
import { addItem, addStones } from '../lib/sect-items.js'
import { pillById, usePill } from '../lib/sect-pills.js'
import { beastById, resolveTame, feed } from '../lib/sect-beasts.js'
import { bloodlineById, awaken as awakenBloodline, performRite } from '../lib/sect-bloodlines.js'
import { requestFriend, acceptFriend, declareRival } from '../lib/sect-bonds.js'
import { runPointers } from '../lib/sect-spar.js'
import { realmById, startRun, openRoom, retreat } from '../lib/sect-ruins.js'
import { secretEvent, secretProgress } from '../lib/sect-world-secrets.js'
import { beginLegendFight, settleLegendHook } from '../lib/sect-legends.js'
import { takeoverChallenge, settleTakeoverHook } from '../lib/sect-takeover.js'
import { generateEnemy } from '../lib/sect-enemies.js'
import { startSectFight, applyPlayerAction } from '../lib/sect-fight.js'
import { sectCultivatorCard } from '../lib/sect-profile.js'
import { wayBackOpen, wayBackAnswer } from '../lib/sect-wayback.js'
import { CROSSING_OUT_SOLARS } from '../lib/sect-crossing.js'

// Auto-drive any active player.sectFight using real applyPlayerAction turns!
function playOutFight(player, clockRef) {
  const opening = []
  let closing = []
  let safety = 0
  while (player.sectFight && safety++ < 60) {
    const f = player.sectFight
    const eq = f.a?.techniques ?? []
    const usable = eq.find(t => (f.a.cooldowns?.[t.id] ?? 0) <= 0 && f.a.qi >= 20)
    const step = usable
      ? applyPlayerAction(player, { kind: 'technique', id: usable.id }, { now: clockRef.now })
      : applyPlayerAction(player, { kind: 'attack' }, { now: clockRef.now })
    clockRef.now += 2000
    if (safety <= 2) opening.push(...(step.lines ?? []).slice(0, 3))
    if (step.ended || !player.sectFight) closing = step.lines ?? []
  }
  return { rounds: safety, opening, closing }
}

const banner = (act, title) => {
  console.log(`\n══════════════════════════════════════════════════════════════════`)
  console.log(`  ACT ${act} — ${title}`)
  console.log(`══════════════════════════════════════════════════════════════════`)
}

resetMountainsMemory()
const db = {
  data: {
    players: {},
    worldSwitches: { sect_empire: true },
    sectMountains: {},
    sectSky: {},
  },
}
hydrateMountains(db)
turnWheel(true)

const clock = { now: Date.parse('2026-11-18T06:00:00Z') } // Dawn on the mountain (Yang hour!)
const HOUR = 3_600_000
const DAY = 24 * HOUR

// ── ACT 1: CHARACTER CREATION & THE MOUNTAIN ROAD ───────────────────────────
banner(1, 'BIRTH OF HAN YE & WALKING THE MOUNTAIN ROAD')
const hanYe = buildNewPlayer({
  id: 'hanye@s.whatsapp.net',
  name: 'Han Ye',
  classId: 'samurai',
  raceId: 'human',
})
hanYe.location = 'astral_town'
hanYe.ownedCharacters = ['monica']
hanYe.wallet.solars = Math.max(10_000_000, CROSSING_OUT_SOLARS + 1_000_000)
// Specialize STR & LCK in Astra before climbing so our Sect lean favors Attack & Spirit Roots!
hanYe.stats.str += 22
hanYe.stats.lck += 15

// Create a sect friend (Lin Wan) and a sect rival (Zhao Feng) on the mountain too
const linWan = buildNewPlayer({ id: 'linwan@s.whatsapp.net', name: 'Lin Wan', classId: 'mage', raceId: 'elf' })
const zhaoFeng = buildNewPlayer({ id: 'zhaofeng@s.whatsapp.net', name: 'Zhao Feng', classId: 'assassin', raceId: 'human' })
db.data.players[hanYe.id] = hanYe
db.data.players[linWan.id] = linWan
db.data.players[zhaoFeng.id] = zhaoFeng

// Set a dramatic Nine Suns Convergence decree overhead!
setSkyDecree(db, 'nine_suns_convergence', { now: clock.now, days: 3 })

const opened = roadOpen(hanYe, { now: clock.now })
console.log(opened.lines.slice(0, 5).join('\n'))
// Answer 1: "The blade" (inclination), Answer 2: "To see the peak", Answer 3: "Walk through"
const ans1 = roadAnswer(hanYe, '1', { now: clock.now, db, isOwner: true })
const ans2 = roadAnswer(hanYe, '1', { now: clock.now, db, isOwner: true })
console.log('\n[Gatekeeper weighs Han Ye]:')
console.log(ans2.lines.slice(0, 8).join('\n'))
const ans3 = roadAnswer(hanYe, '1', { now: clock.now, db, isOwner: true })
console.log('\n[Stepping into the Sect Empire]:')
console.log(ans3.lines.slice(0, 6).join('\n'))

// ── ACT 2: AWAKENING IN WHITE CLOUD CAVE, GOLDFINGER & CULTIVATION PATH ────
banner(2, 'THE 24-HOUR AWAKENING, FATE BOON & SWORD PATH')
hanYe.location = 'low_peak_cave'
for (let sessionNum = 1; sessionNum <= 2; sessionNum++) {
  startSession(hanYe, 'low_peak_cave', { now: clock.now })
  clock.now += 13 * HOUR
  const out = collectSession(hanYe, { now: clock.now })
  console.log(`\n[Cave Session ${sessionNum}]:`)
  console.log(out.lines.join('\n'))
}
const pathChosen = commitClass(hanYe.sect, 'sword_saint')
console.log(`\n[Chosen Path]: ${pathChosen.cls?.name ?? 'Sword Saint'} — ${pathChosen.cls?.description ?? ''}`)

// ── ACT 3: JOINING CLOUDPIERCER PAVILION & LIGHTING THE MOUNTAIN ARRAY ─────
banner(3, 'JOINING CLOUDPIERCER PAVILION & SPIRIT VEIN OFFERING')
// Advance to Qi Condensation Layer 3 and join Cloudpiercer Pavilion
for (let i = 0; i < 3; i++) addSectProgress(hanYe, progressNeed(hanYe.sect.stage), { source: 'cave', now: clock.now })
const cloudpiercer = sectById('cloudpiercer_pavilion')
hanYe.location = 'cloudpiercer_pavilion'
completeJoin(hanYe, cloudpiercer, { now: clock.now })
applyPromotion(hanYe, cloudpiercer, 'outer_disciple', { now: clock.now, db })
addStones(hanYe.sect, 3500)

const arrayOffered = donateToMountainArray(db, hanYe, 2600, { now: clock.now })
console.log(arrayOffered.lines.join('\n'))

// Collect a cave session under BOTH Nine Suns Convergence AND Nine-Peak Convergence Array!
hanYe.location = 'mid_peak_cave'
startSession(hanYe, 'mid_peak_cave', { now: clock.now })
clock.now += 8 * HOUR
const boostedCave = collectSession(hanYe, { now: clock.now })
console.log('\n[Cave Session with Sky + Goldfinger + Mountain Array stacked]:')
console.log(boostedCave.lines.join('\n'))

// ── ACT 4: STUDYING MANUALS & FIGHTING RIVAL SHEN RUI (NAMED ENEMY!) ───────
banner(4, 'CLOUDPIERCER SWORD MANUAL & RIVAL DUEL VS SHEN RUI')
hanYe.location = 'cloudpiercer_pavilion'
hanYe.sect.spot = 'library'
const swordManual = manualById('cloudpiercer_sword_manual')
beginStudy(hanYe, swordManual, { now: clock.now })
clock.now += 2 * HOUR
const learnedForm1 = collectStudy(hanYe, { now: clock.now })
console.log(`📖 Studied *${learnedForm1.manual?.name}* → mastered Form 1 (techniques: ${(learnedForm1.taught ?? []).map(t => t.name ?? t).join(', ')})`)
equipTechnique(hanYe.sect, 'cloud_parting_thrust')

hanYe.sect.spot = 'mission_hall'
// Train up to Layer 5 before challenging Shen Rui so it's a fierce, winnable clash!
while (hanYe.sect.stage < 5) {
  addSectProgress(hanYe, progressNeed(hanYe.sect.stage), { source: 'cave', now: clock.now })
}
const shenDuel = beginLegendFight(hanYe, 'rival', null, { now: clock.now })
console.log('\n[Shen Rui steps onto the arena]:')
console.log(shenDuel.lines.slice(0, 5).join('\n'))
const fightLog = playOutFight(hanYe, clock)
console.log(`[Duel resolved in ${fightLog.rounds} turns]:`)
console.log([...fightLog.opening.slice(0, 3), ...fightLog.closing.slice(-6)].join('\n'))

// ── ACT 5: ALCHEMY -> BEAST TAMING, BLOODLINE MEMORY & RUINS TRAP VEIL ─────
banner(5, 'ALCHEMY BRIDGES: BEAST-CALLER PILL, MARROW ECHO & RUINS VEIL')
hanYe.sect.injury = null
hanYe.sect.deviation = null
// Climb to Core Formation Early (stage 14) to unlock Alchemy, Beasts, Bloodlines & Ruins!
for (let guard = 0; guard < 30 && hanYe.sect.stage < 14; guard++) {
  const cur = hanYe.sect.stage
  addSectProgress(hanYe, progressNeed(cur) * 2, { source: 'cave', now: clock.now })
  if (hanYe.sect.stage === cur) {
    addItem(hanYe.sect, 'foundation_pill', 1, { grade: 2 })
    addItem(hanYe.sect, 'golden_core_pill', 1, { grade: 3 })
    const bt = attemptBreakthrough(hanYe, { now: clock.now, forced: 'success' })
    console.log(bt.lines.slice(0, 3).join('\n'))
    clock.now += HOUR
  }
}
applyPromotion(hanYe, cloudpiercer, 'inner_disciple', { now: clock.now, db })

// Learn Alchemy at Wayfarers Academy & brew our new Beast-Caller Incense Pill!
hanYe.location = 'wayfarers_academy'
hanYe.sect.spot = 'library'
beginLesson(hanYe, 'alchemy', { now: clock.now })
clock.now += 3 * HOUR
finishLesson(hanYe, { now: clock.now }) // settles learning
for (const mat of ['whisperleaf', 'dewcap_moss', 'bark_paper']) addItem(hanYe.sect, mat, 6)
const lureRecipe = alchemyRecipes().find(r => r.id === 'brew_spirit_lure_pill_1')
beginCraft(hanYe, lureRecipe, { now: clock.now })
clock.now += 4 * HOUR
const brewedLure = collectBench(hanYe, { now: clock.now })
console.log('\n[Alchemy Bench — Brewing Beast-Caller Incense Pill]:')
console.log(`⚗️ Brewed *${brewedLure.recipe?.name}* — success: ${brewedLure.success}, quality: *${brewedLure.quality ?? 'standard'}*`)
if (!brewedLure.success) addItem(hanYe.sect, 'spirit_lure_pill', 1, { grade: 1 })

// Swallow Beast-Caller Incense Pill, then tame Ember Crane!
console.log('\n[Using Beast-Caller Incense Pill -> Taming Ember Crane]:')
console.log(usePill(hanYe, pillById('spirit_lure_pill'), { now: clock.now }).lines.join('\n'))
addItem(hanYe.sect, 'cinder_lotus', 2)
const crane = beastById('ember_crane')
const tamed = resolveTame(hanYe, crane, { now: clock.now, rand: () => 0.25 })
console.log(tamed.lines.join('\n'))
addItem(hanYe.sect, 'moon_petal', 3)
console.log(feed(hanYe, crane, { now: clock.now }).lines.join('\n'))

// Swallow Ancestral Marrow Pill + perform rite to wake White Tiger Bloodline!
hanYe.sect.toxin = 22
addItem(hanYe.sect, 'ancestral_marrow_pill', 1, { grade: 3 })
console.log('\n[Using Ancestral Marrow Pill -> Awakening White Tiger Bloodline]:')
console.log(usePill(hanYe, pillById('ancestral_marrow_pill'), { now: clock.now }).lines.join('\n'))
const tiger = bloodlineById('white_tiger')
hanYe.sect.contribution += 2000
performRite(hanYe, tiger, { now: clock.now })
hanYe.sect.bloodMemory[tiger.id] = tiger.memoryNeeded
for (const m of tiger.materials) addItem(hanYe.sect, m.id, m.count)
console.log(awakenBloodline(hanYe, tiger, { now: clock.now }).lines.join('\n'))

// Swallow Breath-Concealing Pill & enter Hollow Pine Temple ruins!
addItem(hanYe.sect, 'breath_concealing_pill', 1, { grade: 2 })
console.log('\n[Using Breath-Concealing Pill -> Entering Secret Realm]:')
console.log(usePill(hanYe, pillById('breath_concealing_pill'), { now: clock.now }).lines.join('\n'))
const pineRuins = realmById('hollow_pine_ruins')
startRun(hanYe, pineRuins, { now: clock.now })
// Walk rooms until we trigger a trap or clear rooms, demonstrating Breath Veil!
for (let step = 0; step < 5 && hanYe.sect.ruins; step++) {
  const rm = openRoom(hanYe, { now: clock.now })
  console.log(`  Room ${step + 1} (${rm.kind}): ${(rm.lines ?? [])[0] ?? ''}`)
  if (playerInFight(hanYe)) playOutFight(hanYe, clock, 'Ruins')
}
function playerInFight(p) { return Boolean(p.sectFight) }

// ── ACT 6: BONDS, RIVAL SPAR & COMPLETING A 6-FRAGMENT WORLD SECRET ────────
banner(6, 'SECT BONDS, RIVAL POINTERS & WORLD SECRET COMPLETION')
linWan.world = 'sect_empire'
zhaoFeng.world = 'sect_empire'
linWan.sect = structuredClone(hanYe.sect)
zhaoFeng.sect = structuredClone(hanYe.sect)
linWan.sect.bonds = { friends: [], rivals: [], pending: [] }
zhaoFeng.sect.bonds = { friends: [], rivals: [], pending: [] }

requestFriend(hanYe, linWan, { now: clock.now })
acceptFriend(linWan, hanYe, { now: clock.now })
declareRival(hanYe, zhaoFeng, { now: clock.now })

clock.now += 2 * MINUTE()
const friendBout = runPointers(hanYe.sect, linWan.sect, {
  now: clock.now, seed: 7, name: 'Han Ye', rivalName: 'Lin Wan', rivalId: linWan.id,
})
console.log('[Sparring Sworn Friend Lin Wan]:')
console.log([...friendBout.reel, ...(friendBout.bondLines ?? [])].join('\n'))

clock.now += 2 * MINUTE()
// Give Han Ye a decisive edge over rival Zhao Feng so we watch Rival Bested trigger!
hanYe.sect.stats.attack += 250
const rivalBout = runPointers(hanYe.sect, zhaoFeng.sect, {
  now: clock.now, seed: 11, name: 'Han Ye', rivalName: 'Zhao Feng', rivalId: zhaoFeng.id,
})
console.log('\n[Sparring Declared Rival Zhao Feng]:')
console.log([`Outcome: ${rivalBout.outcome.toUpperCase()}`, ...rivalBout.reel, ...(rivalBout.bondLines ?? [])].join('\n'))
function MINUTE() { return 60_000 }

// Complete all 6 fragments of "Four Mountains, One Root"
console.log('\n[Piecing together the 6 fragments of "Four Mountains, One Root"]:')
for (const [kind, place] of [
  ['arrive', 'wayfarers_academy'],
  ['arrive', 'cloudpiercer_pavilion'],
  ['arrive', 'ironbone_fist_hall'],
  ['cave', 'mid_peak_cave'],
  ['rank', 'outer_disciple'],
  ['hunt', 'deepwood'],
]) {
  const msg = secretEvent(hanYe, kind, place, { now: clock.now })
  if (msg.length) console.log(msg.slice(-4).join('\n'))
}

// ── ACT 7: FIRST DEFEAT, WAR-GOD HEAVEN, DIVINE GEAR & THRONE REMATCH! ────
banner(7, 'THE WAR-GOD HIDDEN HEAVEN, DIVINE RELICS & CONQUERING JIAN WUCHEN')
hanYe.sect.stage = MAX_STAGE_INDEX
hanYe.sect.stageName = 'Tribulation Transcendence, Peak'
applyPromotion(hanYe, cloudpiercer, 'elder', { now: clock.now, db })
hanYe.sect.contribution += 250_000

// Study Forms 2..8 as Elder so we carry Form 8 ("Nine Heavens Return to One")!
hanYe.location = 'cloudpiercer_pavilion'
hanYe.sect.spot = 'library'
for (let i = 0; i < 7; i++) {
  beginStudy(hanYe, swordManual, { now: clock.now })
  clock.now += 25 * HOUR
  collectStudy(hanYe, { now: clock.now })
}

// Equip Divine & Heaven artifacts (Heaven-Seal Blade, Moonriver Robe, Stillwater Mirror, Worldtree Crown)!
for (const [slot, artId] of [
  ['weapon', 'heaven_seal_blade'],
  ['robe', 'moonriver_robe'],
  ['accessory', 'stillwater_mirror'],
  ['artifact', 'worldtree_crown'],
]) {
  addItem(hanYe.sect, artId, 1)
  const rec = findRecord(hanYe, artId)?.record
  if (rec) hanYe.sect.items.equipped[slot] = rec.uid
}
rebuildSectStats(hanYe.sect)
hanYe.sect.hp = hanYe.sect.stats.hp
hanYe.sect.qi = hanYe.sect.stats.qi
equipTechnique(hanYe.sect, 'heaven_splitting_dawn')
equipTechnique(hanYe.sect, 'sword_remembers_sky')
equipTechnique(hanYe.sect, 'nine_heavens_return')

// Step into our new endgame Hidden Heaven: Ruined War-God Court!
const warHeaven = heavenById('broken_war_palace')
hanYe.sect.heavens = { open: { heavenId: warHeaven.id, foundAt: clock.now, openUntil: clock.now + 6 * HOUR, spent: false }, walked: {} }
const enteredHeaven = enterHeaven(hanYe, { now: clock.now })
console.log(`[Entering New Endgame Hidden Heaven — ${enteredHeaven.heaven?.name} (+${enteredHeaven.qi} Spiritual Qi)]:`)
console.log((enteredHeaven.state?.log ?? enteredHeaven.lines ?? []).slice(0, 5).join('\n'))
const heavenFight = playOutFight(hanYe, clock)
console.log(`[Guardian Duel vs Heaven-Gnawing Wolf (${heavenFight.rounds} turns)]:`)
console.log(heavenFight.closing.slice(-6).join('\n'))
equipTechnique(hanYe.sect, 'heaven_sundering_strike')

// Recover full HP/Qi, re-light the Grand Heaven-Vein Array (Tier 3!), and challenge Sect Master Jian Wuchen!
hanYe.sect.injury = null
hanYe.sect.hp = hanYe.sect.stats.hp
hanYe.sect.qi = hanYe.sect.stats.qi
addStones(hanYe.sect, 10_000)
donateToMountainArray(db, hanYe, 8000, { now: clock.now })

hanYe.location = 'cloudpiercer_pavilion'
hanYe.sect.spot = 'main_hall'
const challenge = takeoverChallenge(hanYe)
console.log(`\n[Challenging ${challenge.foeName} — Element: ${challenge.element}, Signature Moves: ${challenge.techniques.join(', ')}]`)
const patriarchEnemy = generateEnemy({
  stage: challenge.stage,
  role: challenge.role,
  name: challenge.foeName,
  element: challenge.element,
  techniques: challenge.techniques,
  now: clock.now,
})
patriarchEnemy.ai = challenge.ai
startSectFight(hanYe, patriarchEnemy, {
  now: clock.now, real: true, canFlee: true, source: 'sect-trial', trial: true, hook: challenge.hook,
})
const throneFight = playOutFight(hanYe, clock)
console.log(`[Throne Duel finished in ${throneFight.rounds} turns]:`)
console.log([...throneFight.opening.slice(0, 3), ...throneFight.closing.slice(-7)].join('\n'))

// Now as Reigning Sect Master, unlock & study Form 9 ("The Pavilion's Last Light")!
hanYe.sect.spot = 'library'
beginStudy(hanYe, swordManual, { now: clock.now })
clock.now += 25 * HOUR
const learnedForm9 = collectStudy(hanYe, { now: clock.now })
console.log('\n[Studying Form 9 as Reigning Sect Master]:')
console.log(`📖 Studied *${learnedForm9.manual?.name}* → mastered Form 9 (technique: ${(learnedForm9.taught ?? []).map(t => t.name ?? t).join(', ')})`)

console.log('\n[Shared Mountain Peak Tablet — .sect mountain]:')
console.log(mountainScreenLines(hanYe, { db, now: clock.now }).join('\n'))

console.log('\n[Han Ye Cultivator Profile Card — .profile]:')
console.log(sectCultivatorCard(hanYe, { now: clock.now }))

// ── ACT 8: WALKING THE ROAD HOME TO ASTRA KINGDOM ──────────────────────────
banner(8, 'WALKING THE MOUNTAIN ROAD BACK TO ASTRA KINGDOM')
clock.now += 2 * DAY
hanYe.location = SECT_ENTRY_PLACE_ID
hanYe.sect.session = null
hanYe.sect.ruins = null
const roadHome = wayBackOpen(hanYe, { now: clock.now })
console.log(roadHome.lines.join('\n'))

const crossedHome = wayBackAnswer(hanYe, '1', { now: clock.now })
console.log('\n[Arrival in Astra Kingdom]:')
console.log(crossedHome.lines.join('\n'))
console.log(`\nFinal Astra Summary => Name: ${hanYe.name} | World: ${hanYe.world} | Astra Level: ${hanYe.level} | Stigma Titles: [${(hanYe.stigma ?? []).join(' · ')}] | Known Sect Techniques: ${knownTechniques(hanYe.sect).length}`)
