#!/usr/bin/env node
// Validate the final image before booting. Only a disposable SQLite database
// is opened: no WhatsApp connection, phone number or persistent auth is needed.
import { spawnSync } from 'node:child_process'
import { mkdtemp, rm, readFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { loadImage } from '@napi-rs/canvas'
import { fontStatus } from '../lib/fonts.js'
import { Bridge } from '../lib/wa/bridge.js'

let failed = false
const fail = (err) => { failed = true; console.error(`[runtime] ❌ ${err.message ?? err}`) }

const ffmpeg = spawnSync(process.execPath, [fileURLToPath(new URL('./check-ffmpeg.mjs', import.meta.url))], { stdio: 'inherit' })
if (ffmpeg.error || ffmpeg.status !== 0) fail(ffmpeg.error || new Error('ffmpeg runtime check failed'))

for (const file of ['default-pfp.png', 'default-banner.png']) {
  try {
    const image = await loadImage(await readFile(new URL(`../lib/assets/profile/${file}`, import.meta.url)))
    if (!image.width || !image.height) throw new Error(`${file} is empty`)
    console.log(`[runtime] ✅ profile/${file}: ${image.width}×${image.height}`)
  } catch (err) { fail(err) }
}
const fonts = fontStatus()
if (!fonts.ok) fail(new Error('bundled canvas fonts could not be registered'))
else console.log(`[runtime] ✅ fonts: ${fonts.files} files registered`)

/**
 * Telegram's menu card is a PHOTO, and Telegram refuses JPEG shapes its image
 * pipeline cannot decode — above all progressive scans, which answer
 * `400 IMAGE_PROCESS_FAILED` only after the upload has already succeeded. The
 * adapter normalises at send time and falls back to a document, but the art
 * that ships should be sendable as-is, with no native module involved: that is
 * exactly what this check proves, on the FINAL image, at build time.
 */
try {
  const { jpegInfo, photoRejectionReason } = await import('../adapters/telegram/photo.js')
  const art = await readFile(new URL('../lib/assets/ui/telegram-menu.jpg', import.meta.url))
  const info = jpegInfo(art)
  const reason = info && photoRejectionReason(
    { format: 'jpeg', width: info.width, height: info.height, isProgressive: info.isProgressive },
    art.length,
  )
  if (!info) throw new Error('telegram-menu.jpg is not a JPEG')
  if (reason) throw new Error(`telegram-menu.jpg would be refused by Telegram: ${reason}`)
  console.log(`[runtime] ✅ telegram menu art: baseline JPEG ${info.width}×${info.height}, ${Math.round(art.length / 1024)} KB`)
} catch (err) { fail(err) }

const dir = await mkdtemp(join(tmpdir(), 'astral-bridge-check-'))
const bridge = new Bridge({ authDir: dir })
try {
  await bridge.ready
  const result = await bridge.call('ping', {}, 5000)
  if (!result?.pong) throw new Error('WhatsApp bridge did not answer ping')
  console.log('[runtime] ✅ WhatsApp bridge: SQLite ready, protocol ping OK')
} catch (err) { fail(err) }
finally {
  const stopped = bridge.exited ? Promise.resolve() : new Promise(resolve => bridge.once('exit', resolve))
  bridge.kill()
  await stopped
  await rm(dir, { recursive: true, force: true })
}

if (failed) process.exitCode = 1
else console.log('[runtime] ✅ Deployment prerequisites OK')
