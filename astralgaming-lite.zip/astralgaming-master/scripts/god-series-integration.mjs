#!/usr/bin/env node
/**
 * scripts/god-series-integration.mjs — full-format integration check for the
 * god series. Exercises the REAL combat hooks, in-process and against fake
 * players/enemies, on every advertised battle format. No database, socket,
 * wallet or spin is touched: all writes land on synthetic combatants.
 *
 * Run: node scripts/god-series-integration.mjs
 */
import { GOD_BATTLE_MODES, GOD_IDS } from '../lib/god-series/catalog.js'
import { characters } from '../lib/game-data.js'
import { godSummonRegistry, godSummonCoverage, getGodSummonAdapter } from '../lib/god-series/summon-registry.js'
import { newGodEncounter, ownerState, cannotDie, touchConcept, playClub } from '../lib/god-series/engine.js'
import { godDeathRefusal, godLethalHit, godRewriteHit, godMortalDown } from '../lib/god-series/battle.js'
import { planGodSummonTurn, godHeartGuard } from '../lib/god-series/pve.js'
import { planSpade } from '../lib/god-series/spade.js'
import { applyGodTargetEffects } from '../lib/god-series/action-effects.js'
import { queueHeartReaction, applyQueuedHeartReactions, acknowledgeHeartReactions } from '../lib/god-series/pvp-reaction.js'
import { WORLD_CONCEPTS, validateGodWorld } from '../lib/god-series/world-policy.js'
import { newGodWorld } from '../lib/god-series/engine.js'

let pass = 0, fail = 0
const t = (name, ok, extra = '') => {
  if (ok) { pass++; console.log('  PASS  ' + name) }
  else { fail++; console.log('  FAIL  ' + name + (extra ? '  <- ' + extra : '')) }
}
const section = name => console.log(`\n=== ${name} ===`)
const nonGods = characters.filter(c => c.series !== 'god series')

const makeOwner = (id = 'alenious', mode = 'dungeon') => {
  const owner = {
    id: `owner:${id}:${mode}`, name: 'Test Owner', level: 100,
    ownedCharacters: [id], equippedCharacter: id, classId: 'mage',
    hp: 800, maxHp: 1000, mp: 100, maxMp: 100,
    stats: { str: 500, int: 500, def: 400, agi: 500 },
    activeEffects: [], battleState: { turn: 1, type: mode },
  }
  // Real boss fights always carry the live boss clock; the native summon
  // boundary routes HP writes through it, so the fake host must supply one.
  if (mode === 'boss') owner.battleState.bossState = { _defId: 'training_dummy', turn: 1 }
  return owner
}
const makeEnemy = (mode = 'dungeon') => ({
  id: `enemy:${mode}`, name: 'Test Enemy', animeBossId: 'training_dummy',
  hp: 5000, maxHp: 5000, mp: 100, maxMp: 100,
  stats: { atk: 400, int: 200, def: 300, agi: 300 }, activeEffects: [],
  battleState: { turn: 1, type: mode },
})

section('Adapter coverage')
{
  const coverage = godSummonCoverage()
  t('every god-series format is advertised', GOD_BATTLE_MODES.length === 11)
  t('both gods are in the catalog', GOD_IDS.length === 2 && GOD_IDS.includes('alenious') && GOD_IDS.includes('namidrek'))
  t('every non-god has an adapter in every format', coverage.missingCharacters.length === 0,
    JSON.stringify(coverage.missingCharacters.slice(0, 5)))
  t('every format has a registered battle adapter', coverage.missingModes.length === 0,
    coverage.missingModes.join(', '))
  t('registry reports full coverage', coverage.ready === true)
  for (const mode of GOD_BATTLE_MODES) {
    const missing = nonGods.filter(c => !getGodSummonAdapter(c.id)?.modes.includes(mode)).map(c => c.id)
    t(`${mode}: ${nonGods.length} visitor adapters`, missing.length === 0, missing.slice(0, 5).join(', '))
    const modeAdapter = godSummonRegistry().getMode(mode)
    const snap = modeAdapter?.snapshot(makeEnemy(mode))
    t(`${mode}: mode adapter snapshots combat only`, snap && typeof snap.hp === 'number' && !('wallet' in snap))
  }
}

section('Alenious — Heart / Diamond / Club / Spade in every format')
for (const mode of GOD_BATTLE_MODES) {
  const owner = makeOwner('alenious', mode), enemy = makeEnemy(mode)
  let plan = null, err = null
  try { plan = planGodSummonTurn({ player: owner, enemy, turnId: 1, mode }) } catch (e) { err = e }
  t(`${mode}: Heart plan`, !err && plan?.effects && Array.isArray(plan.lines) && !!plan.characterId,
    err?.message ?? String(plan))
  if (plan) {
    const adapter = getGodSummonAdapter(plan.characterId)
    t(`${mode}: Heart visitor integrated`, adapter?.modes.includes(mode) === true, plan.characterId)
    let applied = null, applyErr = null
    try { applied = applyGodTargetEffects(enemy, plan, { pvp: ['pvp', 'wager', 'league', 'guild-war'].includes(mode) }) } catch (e) { applyErr = e }
    t(`${mode}: Heart effects commit`, !applyErr && Number.isFinite(enemy.hp) && enemy.hp >= 0,
      applyErr?.message ?? `hp ${enemy.hp}`)
    t(`${mode}: Heart plan has narration`, plan.lines.length > 0)
  }

  const holder = makeOwner('alenious', mode), target = makeEnemy(mode)
  const encounter = newGodEncounter(`test:diamond:${mode}`, mode, [holder.id, target.id])
  const before = target.hp
  const rewrite = godRewriteHit({ player: holder, attacker: target, damage: 900,
    applyTargetDamage: (victim, amount) => { victim.hp = Math.max(0, victim.hp - amount); return { message: 'redirected' } } })
  t(`${mode}: Diamond redirects the lethal hit`, rewrite?.damage === 0 && rewrite.redirected === true && target.hp < before)
  t(`${mode}: Diamond does not rebound into Alenious twice`, !rewrite?.message?.includes('origin: god-diamond'))

  const clubOwner = makeOwner('alenious', mode)
  const clubEncounter = newGodEncounter(`test:club:${mode}`, mode, [clubOwner.id, target.id])
  playClub({ encounter: clubEncounter, owner: clubOwner, turn: 3, godId: 'namidrek' })
  t(`${mode}: Club borrows Death Touch for its turn`, cannotDie(clubOwner, clubEncounter, 3) === true)
  t(`${mode}: Club expires next turn`, cannotDie(clubOwner, clubEncounter, 4) === false)

  const guardOwner = makeOwner('alenious', mode)
  const guard = godHeartGuard(guardOwner, 100, 1)
  t(`${mode}: Heart guard safe with no active visitor`, guard === null)

  const finaleOwner = makeOwner('alenious', mode), finaleTarget = makeEnemy(mode)
  const scene = newGodEncounter(`test:spade:${mode}`, mode, [finaleOwner.id, finaleTarget.id])
  let finale = null, spadeErr = null
  try { finale = planSpade({ player: finaleOwner, enemy: finaleTarget, encounter: scene, turn: 1 }) } catch (e) { spadeErr = e }
  t(`${mode}: Spade plans its full procession`, !spadeErr && finale?.spade === true && finale.beats?.length === nonGods.length,
    spadeErr?.message ?? `${finale?.beats?.length ?? 0}/${nonGods.length} beats`)
  if (finale) t(`${mode}: Spade settles once with no rewards`, finale.id?.includes(':spade:final') && finale.effects.length === 1)
}

section('Duel formats — Heart reaction outbox (attacker writer)')
for (const mode of ['pvp', 'wager', 'league', 'guild-war']) {
  const defender = makeOwner('alenious', mode), attacker = makeEnemy(mode)
  attacker.id = `attacker:${mode}`
  attacker.battleState.opponentJid = defender.id
  const encounter = newGodEncounter(`test:reaction:${mode}`, mode, [defender.id, attacker.id])
  const adapter = getGodSummonAdapter('urahara')
  const state = ownerState(encounter, defender.id)
  state.heart = 'urahara'
  state.summonMemory.urahara = adapter.createState({ owner: defender, encounterId: encounter.id })
  defender.battleState.godEncounter = encounter

  let reaction = null, err = null
  try { reaction = queueHeartReaction(defender, attacker, 200) } catch (e) { err = e }
  const pending = defender.battleState.godReactionOutbox ?? []
  t(`${mode}: incoming hit is intercepted by the visitor`, !err && reaction?.blocked === true && pending.length === 1,
    err?.message ?? `blocked=${reaction?.blocked}, outbox=${pending.length}`)
  const ack = applyQueuedHeartReactions(attacker, defender.id, pending)
  t(`${mode}: queued combat change commits once`, ack.length === 1 && attacker.battleState.godReactionReceipts?.[ack[0]] === true)
  acknowledgeHeartReactions(defender, ack)
  t(`${mode}: outbox is acknowledged`, (defender.battleState.godReactionOutbox?.length ?? 0) === 0)
}

section('Namidrek — mortality / Death Touch in every format')
for (const mode of GOD_BATTLE_MODES) {
  const owner = makeOwner('namidrek', mode), enemy = makeEnemy(mode)
  owner.hp = 40
  const refusal = godLethalHit(owner, 500)
  t(`${mode}: lethal damage is refused`, refusal !== null && owner.hp === 1 && !godMortalDown(owner))
  const downed = { ...owner, hp: 0 }
  const note = godDeathRefusal(downed, downed.battleState, { deathAttempt: true })
  t(`${mode}: death attempt is rejected`, note?.includes('refuses') === true && downed.hp > 0)

  const world = newGodWorld()
  const encounter = newGodEncounter(`test:touch:${mode}`, mode, [owner.id, enemy.id])
  let result = null, err = null
  try {
    result = touchConcept({ world, encounter, owner, turn: 1,
      target: { kind: 'boss', id: 'esteria' }, receipt: `test:touch:${mode}:1`,
      catalog: (kind, id) => WORLD_CONCEPTS[`${kind}:${id}`],
      ownerHasConcept: () => false })
  } catch (e) { err = e }
  t(`${mode}: Death Touch records an approved concept`, !err && result?.changed === true, err?.message)
  let ledger = null, ledgerErr = null
  try { ledger = validateGodWorld(world) } catch (e) { ledgerErr = e }
  t(`${mode}: world ledger validates after erasure`, !ledgerErr && !!ledger?.erasures['boss:esteria'], ledgerErr?.message)
}

section('Release gate')
{
  const { GOD_SERIES_RELEASED, godAcquisitionBlocked } = await import('../lib/god-series/catalog.js')
  t('god series is released', GOD_SERIES_RELEASED === true)
  t('both gods can now be acquired', !godAcquisitionBlocked('namidrek') && !godAcquisitionBlocked('alenious'))
  console.log(`  INFO  GOD_SERIES_RELEASED=${GOD_SERIES_RELEASED}`)
}

console.log(`\n${pass} passed, ${fail} failed`)
process.exitCode = fail ? 1 : 0
