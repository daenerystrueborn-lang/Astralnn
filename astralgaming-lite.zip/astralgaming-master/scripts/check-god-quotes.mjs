/** The god series must speak stored, interchangeable words in battle. */
import assert from 'node:assert/strict'
import { characterQuote, characterQuotes, godQuoteLine } from '../lib/god-series/quotes.js'
import { newGodEncounter, refuseDeath } from '../lib/god-series/engine.js'
import { personalityFor } from '../lib/god-series/mind-planner.js'

const signature = 'The steppe keeps no graves'
assert.equal(characterQuote('namidrek'), signature, 'the card signature stays the first line')
assert.equal(characterQuote('alenious'), 'I think we can manage without a scene')

const bank = characterQuotes('namidrek')
assert.ok(bank.length >= 8, `Namidrek needs a real line bank, got ${bank.length}`)
assert.equal(bank[0], signature)
assert.equal(new Set(bank).size, bank.length, 'no interchangeable line may be duplicated')

const encounter = newGodEncounter('encounter:quote-check', 'dungeon', ['p1'])
const heard = []
for (let i = 0; i < bank.length; i++) {
  const line = godQuoteLine('namidrek', { encounter })
  assert.ok(line, `line ${i + 1} should be spoken`)
  heard.push(line)
}
assert.equal(new Set(heard).size, bank.length, 'a god rotates through every line before repeating')
assert.equal(godQuoteLine('namidrek', { encounter }), null, 'a spent bank falls quiet instead of repeating')
assert.deepEqual(encounter.godQuotes.namidrek.used, bank, 'the fight remembers exactly what was said')

const looseEncounter = newGodEncounter('encounter:quote-loop', 'dungeon', ['p1'])
for (let i = 0; i < bank.length; i++) godQuoteLine('namidrek', { encounter: looseEncounter, once: false })
assert.ok(godQuoteLine('namidrek', { encounter: looseEncounter, once: false })?.includes(signature), 'an explicit opt-out may loop the bank')

const aleniousEncounter = newGodEncounter('encounter:alenious-quote', 'dungeon', ['p1'])
assert.ok(godQuoteLine('alenious', { encounter: aleniousEncounter })?.includes('I think we can manage without a scene'))
assert.equal(godQuoteLine('alenious', { encounter: aleniousEncounter }), null, 'a one-line card still speaks once')

const owner = {
  id: 'p1', hp: 0, maxHp: 100, ownedCharacters: ['namidrek'], equippedCharacter: 'namidrek', battleState: {},
}
const deathEncounter = newGodEncounter('encounter:death-quote', 'dungeon', ['p1'])
const firstRefusal = refuseDeath(owner, deathEncounter, 1)
assert.ok(bank.some(line => firstRefusal?.includes(line)), 'a refusal includes one of her stored lines')
owner.hp = 0
const secondRefusal = refuseDeath(owner, deathEncounter, 2)
assert.ok(bank.some(line => secondRefusal?.includes(line)))
assert.notEqual(firstRefusal, secondRefusal, 'consecutive refusals use different lines')

const forecasts = { uncertainty: 10, ownerPressure: 10, hope: 10, fatigue: 10, predictability: 20 }
const hypotheses = [{ id: 'ordinary-resolution', confidence: 30 }]
const firstVoice = personalityFor(forecasts, hypotheses, { variant: 1 })
const secondVoice = personalityFor(forecasts, hypotheses, { variant: 2 })
assert.equal(firstVoice.disposition, 'curious')
assert.notEqual(firstVoice.voice, secondVoice.voice, 'the same disposition rotates its voice')
assert.ok(firstVoice.voiceLines.length >= 3, 'each disposition has an interchangeable line bank')
assert.ok(firstVoice.note?.length > 20, 'the disposition explains why she speaks that way')
assert.equal(firstVoice.ownerSafetyIsConstraint, true)

console.log('God battle quotes: Namidrek rotates a detailed line bank, never repeating within a fight.')
