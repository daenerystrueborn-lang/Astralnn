#!/usr/bin/env node
/**
 * One-off manual trigger for the Starfall rollback. Normal deploys do not need
 * this: main.js and lib/platform/boot.js already call runStarfallWipe() on the
 * first restart after the update. This exists for an operator who wants to run
 * the same idempotent migration by hand.
 */
import { initDb } from '../lib/platform/boot.js'
import { runStarfallWipe } from '../lib/starfall-wipe.js'

const db = await initDb()
const result = await runStarfallWipe(db)
if (!result.ran) console.log('Starfall wipe already done; nothing to remove.')
else console.log(`Starfall locked; prizes removed from ${result.players} player(s).`)
