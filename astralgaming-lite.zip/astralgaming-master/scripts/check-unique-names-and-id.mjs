/**
 * scripts/check-unique-names-and-id.mjs
 * Verifies:
 *   1. Pre-existing duplicate @usernames and character names get `1` appended
 *      to the newer holder (or `2`, `3` if `Name1` is already owned).
 *   2. `.username add`, `renamePlayer`, `.register`, and `createPlayer` block
 *      duplicate usernames/names (case-insensitive) while allowing players to
 *      re-case their own name/username.
 *   3. Guided `.register` pushName auto-fill disambiguates duplicates (`Alex` -> `Alex1`).
 *   4. `.id` card renderer resolves equipped Store/Pass PFPs, platform avatars,
 *      custom PFPs, and clean default PFP inside a clipped rounded frame.
 */
import assert from 'node:assert/strict'
import { loadImage, createCanvas } from '@napi-rs/canvas'
import {
  deduplicateUsersInPlace,
  runUniqueNameDeduplication,
} from '../lib/unique-names.js'
import { renamePlayer } from '../lib/rename-rules.js'
import { createPlayer } from '../lib/player-repo.js'
import { renderPlayerIdCard } from '../lib/player-id-render.mjs'
import usernamePlugin from '../plugins/username.js'
import registerPlugin from '../plugins/register.js'
import idPlugin from '../plugins/id.js'

// ── 1. Duplicate +1 deduplication ──────────────────────────────────────────
{
  const users = {
    '111@s.whatsapp.net': { id: '111@s.whatsapp.net', name: 'Shadow', username: 'shadow', registeredAt: 1000, level: 20 },
    '222@s.whatsapp.net': { id: '222@s.whatsapp.net', name: 'shadow', username: 'Shadow', registeredAt: 2000, level: 50 },
    '333@s.whatsapp.net': { id: '333@s.whatsapp.net', name: 'Shadow', username: 'shadow', registeredAt: 3000, level: 10 },
  }
  const changes = deduplicateUsersInPlace(users)
  assert.equal(changes.length, 4)
  assert.equal(users['111@s.whatsapp.net'].name, 'Shadow')
  assert.equal(users['111@s.whatsapp.net'].username, 'shadow')
  assert.equal(users['222@s.whatsapp.net'].name, 'shadow1')
  assert.equal(users['222@s.whatsapp.net'].username, 'Shadow1')
  assert.equal(users['333@s.whatsapp.net'].name, 'Shadow2')
  assert.equal(users['333@s.whatsapp.net'].username, 'shadow2')
}

// ── 2. Collision when `Kira1` already exists before deduplicating two `Kira`s
{
  const db = {
    data: {
      users: {
        'a@s.whatsapp.net': { id: 'a@s.whatsapp.net', name: 'Kira', username: 'kira', registeredAt: 1000, hp: 100, maxHp: 100, mp: 50, maxMp: 50 },
        'b@s.whatsapp.net': { id: 'b@s.whatsapp.net', name: 'Kira', username: 'kira', registeredAt: 2000, hp: 100, maxHp: 100, mp: 50, maxMp: 50 },
        'c@s.whatsapp.net': { id: 'c@s.whatsapp.net', name: 'Kira1', username: 'kira1', registeredAt: 1500, hp: 100, maxHp: 100, mp: 50, maxMp: 50 },
      },
    },
    write: async () => {},
    read: async () => {},
  }
  const applied = await runUniqueNameDeduplication(db)
  assert.equal(applied.length, 2)
  assert.equal(db.data.users['a@s.whatsapp.net'].username, 'kira')
  assert.equal(db.data.users['c@s.whatsapp.net'].username, 'kira1')
  assert.equal(db.data.users['b@s.whatsapp.net'].username, 'kira2')
  assert.equal(db.data.users['b@s.whatsapp.net'].name, 'Kira2')
}

// ── 3. `.username add`, `renamePlayer`, `createPlayer`, and `.register` ────
{
  const db = {
    data: {
      users: {
        'p1@s.whatsapp.net': { id: 'p1@s.whatsapp.net', name: 'Ace', username: 'ace', level: 10, hp: 100, maxHp: 100, mp: 50, maxMp: 50 },
        'p2@s.whatsapp.net': { id: 'p2@s.whatsapp.net', name: 'Luffy', username: null, level: 10, hp: 100, maxHp: 100, mp: 50, maxMp: 50 },
      },
    },
    write: async () => {},
    read: async () => {},
  }

  let lastReply = ''
  await usernamePlugin.run({
    from: 'p2@s.whatsapp.net',
    args: ['add', 'ACE'],
    player: db.data.users['p2@s.whatsapp.net'],
    db,
    reply: async (msg) => { lastReply = msg },
  })
  assert.match(lastReply, /already taken/i)
  assert.equal(db.data.users['p2@s.whatsapp.net'].username, null)

  // Self re-casing allowed (`ace` -> `Ace`)
  await usernamePlugin.run({
    from: 'p1@s.whatsapp.net',
    args: ['add', 'Ace'],
    player: db.data.users['p1@s.whatsapp.net'],
    db,
    reply: async (msg) => { lastReply = msg },
  })
  assert.equal(db.data.users['p1@s.whatsapp.net'].username, 'Ace')

  // Rename to taken name blocked with suggestion `Ace1`
  const renBlocked = await renamePlayer(db, 'p2@s.whatsapp.net', 'ace')
  assert.equal(renBlocked.ok, false)
  assert.equal(renBlocked.reason, 'taken')
  assert.equal(renBlocked.suggestion, 'ace1')

  // Self re-casing name allowed (`Ace` -> `ACE`)
  const renCase = await renamePlayer(db, 'p1@s.whatsapp.net', 'ACE')
  assert.equal(renCase.ok, true)
  assert.equal(db.data.users['p1@s.whatsapp.net'].name, 'ACE')

  // Explicit `.register` with taken name rejected
  await registerPlugin.run({
    from: 'p3@s.whatsapp.net',
    sender: 'p3@s.whatsapp.net',
    args: ['kingdom', 'Luffy', 'warrior', 'human'],
    db,
    reply: async (msg) => { lastReply = msg },
  })
  assert.match(lastReply, /already taken/i)
  assert.equal(db.data.users['p3@s.whatsapp.net'], undefined)

  // Guided `.register` with colliding pushName auto-appends `1` (`Luffy1`)
  await registerPlugin.run({
    from: 'p3@s.whatsapp.net',
    sender: 'p3@s.whatsapp.net',
    pushName: 'Luffy',
    args: ['kingdom', 'warrior', 'human'],
    db,
    reply: async (msg) => { lastReply = msg },
  })
  assert.equal(db.data.users['p3@s.whatsapp.net']?.name, 'Luffy1')

  // Direct createPlayer rejects duplicate name
  await assert.rejects(
    () => createPlayer(db, 'p4@s.whatsapp.net', { id: 'p4@s.whatsapp.net', name: 'luffy', level: 1, hp: 100, maxHp: 100, mp: 50, maxMp: 50 }),
    (err) => err?.code === 'NAME_TAKEN',
  )
}

// ── 4. `.id` card rendering & PFP resolution ───────────────────────────────
{
  // Create a bright solid green 120x120 test avatar PNG buffer
  const avatarCanvas = createCanvas(120, 120)
  const avatarCtx = avatarCanvas.getContext('2d')
  avatarCtx.fillStyle = '#10B981'
  avatarCtx.fillRect(0, 0, 120, 120)
  const greenAvatarBuf = avatarCanvas.toBuffer('image/png')

  // Render with platformAvatar buffer -> centre of PFP box (116, 116) must be bright green (#10B981), NOT muddy sepia!
  const cardBuf = await renderPlayerIdCard(
    { name: 'Kaelen', username: 'kaelen', level: 35, pokemon: [{}], battleRecord: { wins: 9 } },
    { title: 'Hunter' },
    { platformAvatar: greenAvatarBuf },
  )
  const cardImg = await loadImage(cardBuf)
  assert.equal(cardImg.width, 700)
  assert.equal(cardImg.height, 290)

  const probe = createCanvas(700, 290)
  const pctx = probe.getContext('2d')
  pctx.drawImage(cardImg, 0, 0)
  const px = pctx.getImageData(116, 116, 1, 1).data
  assert.ok(px[1] > 160 && px[0] < 40, `Expected crisp green PFP pixel without brown tint, got rgb(${px[0]},${px[1]},${px[2]})`)

  // Verify top edge above PFP box (x=105, y=8) is clean card white (no grey silhouette head bleeding out of box!)
  const fallbackBuf = await renderPlayerIdCard(
    { name: 'Solo', level: 5, pokemon: [], battleRecord: { wins: 0 } },
    { title: 'Rookie' },
  )
  const fallbackImg = await loadImage(fallbackBuf)
  pctx.clearRect(0, 0, 700, 290)
  pctx.drawImage(fallbackImg, 0, 0)
  const topStrip = pctx.getImageData(105, 8, 1, 1).data
  assert.ok(
    topStrip[0] > 245 && topStrip[1] > 245 && topStrip[2] > 245,
    `Expected clean white margin above PFP box, got rgb(${topStrip[0]},${topStrip[1]},${topStrip[2]})`,
  )

  // Verify plugins/id.js runs end-to-end and passes image buffer
  const db = {
    data: {
      users: {
        'u1@s.whatsapp.net': {
          id: 'u1@s.whatsapp.net',
          name: 'Satoru',
          username: 'sixeyes',
          profilePfpId: 'pfp_satoru_suit',
          level: 88,
          pokemon: [{}, {}],
          battleRecord: { wins: 54 },
        },
      },
    },
    write: async () => {},
    read: async () => {},
  }
  let sentBuf = null
  await idPlugin.run({
    from: 'u1@s.whatsapp.net',
    args: [],
    player: db.data.users['u1@s.whatsapp.net'],
    db,
    reply: async () => {},
    replyImage: async (buf) => { sentBuf = buf },
  })
  assert.ok(Buffer.isBuffer(sentBuf) && sentBuf.length > 5000)
}

console.log('✅ All unique username/name + Astral ID card checks passed!')
