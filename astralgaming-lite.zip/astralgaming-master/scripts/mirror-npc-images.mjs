#!/usr/bin/env node
/**
 * scripts/mirror-npc-images.mjs
 *
 * Downloads every NPC portrait listed in the roster JSON, uploads it to ImgBB
 * with the bot's own helper (lib/imgbb.js -> uploadToImgbb), and writes the
 * permanent URL back into the roster as image.mirroredUrl.
 *
 * Why: the roster's image.source links are Pinterest hotlinks. They can die or
 * start refusing requests, and this repo has already lost item art to a dead
 * host. An ImgBB display_url is the same kind of link players' pfps use.
 *
 * Usage (run from the bot repo root, on a machine with open internet):
 *   node scripts/mirror-npc-images.mjs data/astral-npc-roster.json
 *   node scripts/mirror-npc-images.mjs data/astral-npc-roster.json --dry-run
 *   node scripts/mirror-npc-images.mjs data/astral-npc-roster.json --force
 *
 * Needs IMGBB_API_KEY in the environment (config.js also has a committed
 * default; set your own key and rotate that one).
 *
 * Safe to re-run: NPCs that already have a mirroredUrl are skipped unless
 * --force is given. The roster file is rewritten after EVERY successful
 * upload, so a crash halfway keeps the progress made.
 */
import { readFileSync, writeFileSync, renameSync } from 'fs'
import path from 'path'
import { uploadToImgbb } from '../lib/imgbb.js'

const MAX_BYTES = 30 * 1024 * 1024 // ImgBB's limit is 32 MB
const RETRIES = 3
const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'

const args = process.argv.slice(2)
const rosterPath = args.find(a => !a.startsWith('--'))
const dryRun = args.includes('--dry-run')
const force = args.includes('--force')

if (!rosterPath) {
  console.error('usage: node scripts/mirror-npc-images.mjs <roster.json> [--dry-run] [--force]')
  process.exit(2)
}

const sleep = ms => new Promise(r => setTimeout(r, ms))

function saveAtomic(file, data) {
  const tmp = `${file}.tmp`
  writeFileSync(tmp, JSON.stringify(data, null, 2) + '\n')
  renameSync(tmp, file)
}

async function download(url) {
  const res = await fetch(url, {
    headers: { 'User-Agent': UA, Referer: 'https://www.pinterest.com/', Accept: 'image/*' },
    redirect: 'follow',
  })
  if (!res.ok) throw new Error(`download HTTP ${res.status}`)
  const type = res.headers.get('content-type') ?? ''
  if (!type.startsWith('image/')) throw new Error(`not an image (content-type "${type}")`)
  const buf = Buffer.from(await res.arrayBuffer())
  if (buf.length === 0) throw new Error('empty download')
  if (buf.length > MAX_BYTES) throw new Error(`image too large (${buf.length} bytes)`)
  return buf
}

async function withRetries(label, fn) {
  let lastErr
  for (let attempt = 1; attempt <= RETRIES; attempt++) {
    try {
      return await fn()
    } catch (err) {
      lastErr = err
      if (attempt < RETRIES) {
        console.warn(`   ${label}: ${err.message} (attempt ${attempt}/${RETRIES}), retrying`)
        await sleep(1500 * attempt)
      }
    }
  }
  throw lastErr
}

const file = path.resolve(rosterPath)
const roster = JSON.parse(readFileSync(file, 'utf8'))
const results = { done: [], skipped: [], failed: [] }

for (const npc of roster.npcs ?? []) {
  const img = npc.image
  if (!img?.source) {
    console.warn(`- ${npc.id}: no image.source, skipping`)
    results.failed.push(npc.id)
    continue
  }
  if (img.mirroredUrl && !force) {
    console.log(`- ${npc.id}: already mirrored, skipping`)
    results.skipped.push(npc.id)
    continue
  }
  if (dryRun) {
    console.log(`- ${npc.id}: would download ${img.source}`)
    continue
  }

  try {
    const buf = await withRetries(`${npc.id} download`, () => download(img.source))
    const url = await withRetries(`${npc.id} upload`, () => uploadToImgbb(buf, `astral-npc-${npc.id}`))
    img.mirroredUrl = url
    saveAtomic(file, roster)
    console.log(`+ ${npc.id}: ${url} (${(buf.length / 1024).toFixed(0)} KB)`)
    results.done.push(npc.id)
  } catch (err) {
    console.error(`x ${npc.id}: ${err.message}`)
    results.failed.push(npc.id)
  }
}

console.log(
  `\nDone: ${results.done.length}, skipped: ${results.skipped.length}, failed: ${results.failed.length}` +
    (results.failed.length ? ` (${results.failed.join(', ')})` : ''),
)
process.exit(results.failed.length ? 1 : 0)
