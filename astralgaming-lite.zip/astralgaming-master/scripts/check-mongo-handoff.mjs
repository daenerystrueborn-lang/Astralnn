/**
 * scripts/check-mongo-handoff.mjs
 * Verifies server-migration handoff for ReplicatedJSONFile and MongoOnlyJSONFile:
 *   1. Missing /data/db.json + expiring old-server lock -> creates db.json, downloads
 *      players from MongoDB immediately, waits for stale lock handoff, and boots synced.
 *   2. Missing /data/db.json + actively beating old server -> still creates db.json
 *      and downloads players from MongoDB so boot succeeds without crash-looping.
 *   3. MONGO_TAKEOVER / forceTakeover -> claims __writer_lock immediately.
 *   4. MongoOnlyJSONFile -> waits cleanly for old lock to clear and loads players.
 */
import assert from 'node:assert/strict'
import { mkdtempSync, existsSync, readFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import {
  ReplicatedJSONFile,
  USERS_COLLECTION,
  META_COLLECTION,
  WRITER_LOCK_ID,
  fingerprint,
} from '../lib/mongo-adapter.js'
import { MongoOnlyJSONFile } from '../lib/mongo-only-adapter.js'

function createFakeMongoDb({ users = {}, meta = {}, lockHolder = null } = {}) {
  const userDocs = new Map()
  for (const [id, obj] of Object.entries(users)) {
    const json = JSON.stringify(obj)
    userDocs.set(id, { _id: id, json, fp: fingerprint(json), updatedAt: new Date() })
  }
  const metaDocs = new Map()
  for (const [id, obj] of Object.entries(meta)) {
    const json = JSON.stringify(obj)
    metaDocs.set(id, { _id: id, json, fp: fingerprint(json), updatedAt: new Date() })
  }
  if (lockHolder) {
    metaDocs.set(WRITER_LOCK_ID, { _id: WRITER_LOCK_ID, holder: { ...lockHolder } })
  }

  function matchesLockFilter(doc, filter) {
    if (!doc) return false
    if (!filter.$or) return true
    return filter.$or.some(cond => {
      if ('holder' in cond && cond.holder?.$exists === false) return !('holder' in doc)
      if ('holder' in cond && cond.holder === null) return doc.holder == null
      if ('holder.pid' in cond) {
        return doc.holder?.pid === cond['holder.pid'] && doc.holder?.host === cond['holder.host']
      }
      if ('holder.heartbeat' in cond && cond['holder.heartbeat']?.$lt != null) {
        return Number(doc.holder?.heartbeat) < cond['holder.heartbeat'].$lt
      }
      return false
    })
  }

  const collections = {
    [USERS_COLLECTION]: {
      find: () => ({ toArray: async () => [...userDocs.values()] }),
      countDocuments: async () => userDocs.size,
      bulkWrite: async () => {},
    },
    [META_COLLECTION]: {
      find: (q = {}) => ({
        toArray: async () => [...metaDocs.values()].filter(d => q?._id?.$ne ? d._id !== q._id.$ne : true),
      }),
      findOne: async (q = {}) => metaDocs.get(q._id) ?? null,
      updateOne: async (filter, update, opts = {}) => {
        if (filter._id === WRITER_LOCK_ID) {
          const existing = metaDocs.get(WRITER_LOCK_ID)
          if (filter['holder.pid'] != null) {
            if (existing?.holder?.pid === filter['holder.pid'] && existing?.holder?.host === filter['holder.host']) {
              if (update.$set?.['holder.heartbeat']) existing.holder.heartbeat = update.$set['holder.heartbeat']
              if (update.$unset?.holder !== undefined) delete existing.holder
              return { matchedCount: 1, upsertedCount: 0 }
            }
            return { matchedCount: 0, upsertedCount: 0 }
          }
          if (!existing) {
            if (opts.upsert) {
              metaDocs.set(WRITER_LOCK_ID, { _id: WRITER_LOCK_ID, ...(update.$set ?? {}) })
              return { matchedCount: 0, upsertedCount: 1 }
            }
            return { matchedCount: 0, upsertedCount: 0 }
          }
          if (matchesLockFilter(existing, filter)) {
            metaDocs.set(WRITER_LOCK_ID, { ...existing, ...(update.$set ?? {}) })
            return { matchedCount: 1, upsertedCount: 0 }
          }
          const dup = new Error('E11000 duplicate key error')
          dup.code = 11000
          throw dup
        }
        return { matchedCount: 1, upsertedCount: 0 }
      },
      bulkWrite: async () => {},
    },
  }

  return {
    userDocs,
    metaDocs,
    db: {
      command: async () => ({ ok: 1 }),
      collection: (name) => collections[name],
    },
  }
}

const tmpRoot = mkdtempSync(join(tmpdir(), 'astral-handoff-'))

try {
  // ── 1. Dead old server lock expires -> creates db.json & claims lock cleanly
  {
    const dbPath = join(tmpRoot, 'server1', 'db.json')
    const staleMs = 120
    const fake = createFakeMongoDb({
      users: {
        'u1@s.whatsapp.net': { id: 'u1@s.whatsapp.net', name: 'Kaelen', level: 55 },
        'u2@s.whatsapp.net': { id: 'u2@s.whatsapp.net', name: 'Satoru', level: 99 },
      },
      meta: { guilds: { g1: { name: 'Sun' } } },
      lockHolder: { pid: 54, host: '7a132089e29f', heartbeat: Date.now() - 50 },
    })

    const logs = []
    const adapter = new ReplicatedJSONFile({
      uri: 'mongodb+srv://user:secret@cluster.example.net/',
      dbName: 'astral',
      localPath: dbPath,
      staleMs,
      handoffPollMs: 25,
      handoffWaitMs: 600,
      clientFactory: async () => ({ db: () => fake.db, close: async () => {} }),
      log: (...a) => logs.push(a.join(' ')),
      warn: (...a) => logs.push(a.join(' ')),
    })

    const data = await adapter.read()
    assert.equal(existsSync(dbPath), true, 'db.json was created on disk')
    const diskJson = JSON.parse(readFileSync(dbPath, 'utf-8'))
    assert.equal(Object.keys(diskJson.users).length, 2, 'downloaded both players into db.json')
    assert.equal(data.users['u1@s.whatsapp.net'].name, 'Kaelen')
    assert.equal(data.guilds.g1.name, 'Sun')
    assert.equal(adapter.syncState.synced, true, 'claimed writer lock once old lock expired')
    assert.ok(logs.some(l => l.includes('Server switch detected')), 'logged clear server-switch message')
    await adapter.close()
  }

  // ── 2. Actively beating old server -> STILL creates db.json & boots cleanly
  {
    const dbPath = join(tmpRoot, 'server2', 'db.json')
    const fake = createFakeMongoDb({
      users: { 'u1@s.whatsapp.net': { id: 'u1@s.whatsapp.net', name: 'LiveCopy', level: 77 } },
      lockHolder: { pid: 54, host: '7a132089e29f', heartbeat: Date.now() },
    })
    // Simulate old server refreshing its heartbeat
    const beatTimer = setInterval(() => {
      const doc = fake.metaDocs.get(WRITER_LOCK_ID)
      if (doc?.holder) doc.holder.heartbeat = Date.now()
    }, 15)

    try {
      const adapter = new ReplicatedJSONFile({
        uri: 'mongodb+srv://user:secret@cluster.example.net/',
        dbName: 'astral',
        localPath: dbPath,
        staleMs: 5000,
        handoffPollMs: 25,
        handoffWaitMs: 300,
        clientFactory: async () => ({ db: () => fake.db, close: async () => {} }),
        log: () => {},
        warn: () => {},
      })

      const data = await adapter.read()
      assert.equal(existsSync(dbPath), true, 'created db.json even while old server was still live')
      assert.equal(data.users['u1@s.whatsapp.net'].name, 'LiveCopy')
      assert.equal(adapter.syncState.synced, false, 'does not overwrite active old server until it stops')
      await adapter.close()
    } finally {
      clearInterval(beatTimer)
    }
  }

  // ── 3. forceTakeover (MONGO_TAKEOVER=1) claims lock immediately
  {
    const dbPath = join(tmpRoot, 'server3', 'db.json')
    const fake = createFakeMongoDb({
      users: { 'u1@s.whatsapp.net': { id: 'u1@s.whatsapp.net', name: 'TakeoverHero', level: 88 } },
      lockHolder: { pid: 99, host: 'old-box', heartbeat: Date.now() },
    })

    const adapter = new ReplicatedJSONFile({
      uri: 'mongodb+srv://user:secret@cluster.example.net/',
      dbName: 'astral',
      localPath: dbPath,
      forceTakeover: true,
      clientFactory: async () => ({ db: () => fake.db, close: async () => {} }),
      log: () => {},
      warn: () => {},
    })

    const data = await adapter.read()
    assert.equal(data.users['u1@s.whatsapp.net'].name, 'TakeoverHero')
    assert.equal(adapter.syncState.synced, true)
    assert.equal(fake.metaDocs.get(WRITER_LOCK_ID)?.holder?.pid, process.pid)
    await adapter.close()
  }

  // ── 4. MongoOnlyJSONFile waits for expiring lock and boots cleanly
  {
    const fake = createFakeMongoDb({
      users: { 'u1@s.whatsapp.net': { id: 'u1@s.whatsapp.net', name: 'MongoOnlyHero', level: 120 } },
      lockHolder: { pid: 54, host: '7a132089e29f', heartbeat: Date.now() - 60 },
    })

    const adapter = new MongoOnlyJSONFile({
      uri: 'mongodb+srv://user:secret@cluster.example.net/',
      dbName: 'astral',
      staleMs: 110,
      handoffPollMs: 25,
      handoffWaitMs: 600,
      clientFactory: async () => ({ db: () => fake.db, close: async () => {} }),
      log: () => {},
      warn: () => {},
    })

    const data = await adapter.read()
    assert.equal(data.users['u1@s.whatsapp.net'].name, 'MongoOnlyHero')
    assert.equal(adapter.syncState.synced, true)
    await adapter.close()
  }

  console.log('✅ All MongoDB server-switch & auto-db.json download checks passed!')
} finally {
  rmSync(tmpRoot, { recursive: true, force: true })
}
