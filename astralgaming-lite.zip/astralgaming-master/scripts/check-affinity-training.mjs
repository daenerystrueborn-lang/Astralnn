#!/usr/bin/env node
/**
 * scripts/check-affinity-training.mjs — Regression suite verifying:
 *   1. `normalizePlayerAffinity` mutates element entries in place (never detaching `entry` refs).
 *   2. `.affinity train` requires 3 Stamina, launches an interactive Chakra Drill (`kind: 'train'`),
 *      never hands out instant 0-effort XP, and enforces the 6h cooldown after sealing.
 *   3. Spamming `.affinity train` 25x back-to-back yields 0 extra XP.
 *   4. After the 6h cooldown expires, Session #2+ requires real live combat practice (casts or kills).
 *   5. Failing or `.affinity abandon`-ing a Temple Drill awards 0 XP and locks a 2h backlash cooldown.
 *   6. Mastery Scrolls cannot be bought in `.shop` and enforce a 1,500 XP/day absorption cap.
 *   7. `lib/version.js` top changelog entry contains zero dashes.
 */

import assert from 'node:assert/strict'
import os from 'node:os'
import path from 'node:path'
import fs from 'node:fs'

const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'astral-aff-test-'))
process.env.RUNTIME_DATA_DIR = tmpDir

const {
  normalizePlayerAffinity,
  getCurrentMaster,
  getUnlockedMasters,
  grantMasteryXp,
  noteAffinityKill,
  templePracticeProgress,
  canAbsorbMasteryScroll,
  TEMPLE_TRAIN_COOLDOWN_MS,
  TEMPLE_TRAIN_BACKLASH_MS,
  TEMPLE_TRAIN_STAMINA_COST,
  DAILY_SCROLL_XP_CAP,
} = await import('../lib/affinity-engine.js')
const { shopItems } = await import('../lib/shop-catalog.js')
const { CHANGELOG } = await import('../lib/version.js')
const affinityPlugin = (await import('../plugins/affinity.js')).default

let passed = 0
function check(name, fn) {
  return Promise.resolve()
    .then(fn)
    .then(() => {
      passed++
      console.log(`  ✅ ${name}`)
    })
}

function makeTestHarness() {
  const jid = 'test_bender@s.whatsapp.net'
  const player = {
    name: 'ZukoTest',
    level: 65,
    hp: 1000,
    maxHp: 1000,
    mp: 500,
    maxMp: 500,
    location: 'fire_nation',
    inBattle: false,
    stamina: { current: 30, max: 30, resetAt: Date.now() + 86_400_000 },
    wallet: { solars: 100_000, monds: 0 },
    inventory: [],
    learnedSkills: [],
    equippedSkills: [],
    affinity: {
      vesselTier: 'single',
      vesselNumber: 7,
      primary: 'fire',
      elements: {
        fire: {
          level: 1,
          xp: 0,
          totalXp: 0,
          subBending: null,
          subBendings: [],
          masterId: null,
          clearedGates: [],
          lastTrainAt: 0,
          skillCasts: 0,
          templeSessions: 0,
        },
      },
    },
  }
  const db = {
    data: { users: { [jid]: player }, world: {} },
    write: async () => {},
  }
  const replies = []
  const runCmd = async (args) => {
    replies.length = 0
    const ctx = {
      from: jid,
      player: db.data.users[jid],
      db,
      args,
      sock: null,
      msg: null,
      chat: jid,
      reply: async (text) => {
        replies.push(typeof text === 'string' ? text : text?.caption ?? JSON.stringify(text))
      },
    }
    await affinityPlugin.run(ctx)
    return replies.join('\n')
  }
  return { player, db, runCmd }
}

await check('1. normalizePlayerAffinity mutates element entries in place (never detaches references)', () => {
  const { player } = makeTestHarness()
  const aff = normalizePlayerAffinity(player)
  const entry = aff.elements.fire
  getCurrentMaster(player, 'fire')
  getUnlockedMasters(player, 'fire')
  entry.lastTrainAt = 123456789
  entry.templeSessions = 3
  grantMasteryXp(player, 25, { elementId: 'fire', source: 'temple' })
  assert.strictEqual(entry, player.affinity.elements.fire, 'element entry reference must stay identical')
  assert.strictEqual(player.affinity.elements.fire.lastTrainAt, 123456789)
  assert.strictEqual(player.affinity.elements.fire.templeSessions, 3)
  assert.strictEqual(player.affinity.elements.fire.xp, 25)
})

await check('2. .affinity train deducts 3 Stamina and starts a Chakra Drill instead of handing out free XP', async () => {
  const { player, runCmd } = makeTestHarness()
  const out = await runCmd(['train'])
  assert.match(out, /TEMPLE CHAKRA DRILL/i)
  assert.strictEqual(player.affinity.elements.fire.xp, 0, 'XP must still be 0 until Chakra Drill is sealed')
  assert.strictEqual(player.stamina.current, 30 - TEMPLE_TRAIN_STAMINA_COST, 'must spend 3 Stamina')
  assert.strictEqual(player.affinityTrial?.kind, 'train')

  // Calling .affinity train while drill is active shows the drill without charging more Stamina or granting XP
  await runCmd(['train'])
  assert.strictEqual(player.stamina.current, 30 - TEMPLE_TRAIN_STAMINA_COST)
  assert.strictEqual(player.affinity.elements.fire.xp, 0)
})

await check('3. Sealing the Temple Drill grants XP once and locks the 6h cooldown against 25x spam', async () => {
  const { player, runCmd } = makeTestHarness()
  await runCmd(['train'])

  // Drive the Chakra Forge intelligently until sealed
  for (let step = 0; step < 6 && player.affinityTrial; step++) {
    const f = player.affinityTrial.forge
    let move = 'harmonize'
    if (f.instability >= 60 && !f.lotusUsed) move = 'lotus'
    else if (f.instability >= 68) move = 'ground'
    else if (f.resonance <= 60 && f.instability <= 45) move = 'surge'
    await runCmd(['forge', move])
  }

  assert.strictEqual(player.affinityTrial, null, 'Temple drill should seal cleanly')
  const xpAfterSeal = player.affinity.elements.fire.xp
  assert.ok(xpAfterSeal > 0, `Expected positive XP after sealing drill, got ${xpAfterSeal}`)
  assert.strictEqual(player.affinity.elements.fire.templeSessions, 1)
  assert.ok(player.affinity.elements.fire.lastTrainAt > 0, 'lastTrainAt must be persisted on live entry')

  // Attempt to spam .affinity train 25 times back-to-back!
  for (let i = 0; i < 25; i++) {
    const spamOut = await runCmd(['train'])
    assert.match(spamOut, /meridians are resting/i)
  }
  assert.strictEqual(player.affinity.elements.fire.xp, xpAfterSeal, '25x back-to-back spam must yield 0 extra XP')
  assert.strictEqual(player.affinity.elements.fire.templeSessions, 1)
})

await check('4. Session #2+ blocks AFK town-camping until live combat practice (casts or kills) is earned', async () => {
  const { player, runCmd } = makeTestHarness()
  await runCmd(['train'])
  player.affinityTrial.forge.resonance = 85
  player.affinityTrial.forge.instability = 10
  await runCmd(['forge', 'harmonize'])
  assert.strictEqual(player.affinity.elements.fire.templeSessions, 1)

  // Fast-forward 6h + 1min with ZERO combat
  player.affinity.elements.fire.lastTrainAt -= (TEMPLE_TRAIN_COOLDOWN_MS + 60_000)
  assert.strictEqual(templePracticeProgress(player, 'fire').ready, false)

  const blocked = await runCmd(['train'])
  assert.match(blocked, /Field Practice Required/i)
  assert.strictEqual(player.affinityTrial, null, 'must reject AFK training with no combat')

  // Slay 3 dungeon bosses (3 * 3 = 9 kill points >= 7 required at Lv.1)
  noteAffinityKill(player, { isBoss: true })
  noteAffinityKill(player, { isBoss: true })
  noteAffinityKill(player, { isBoss: true })
  assert.strictEqual(templePracticeProgress(player, 'fire').ready, true)

  const unlocked = await runCmd(['train'])
  assert.match(unlocked, /TEMPLE CHAKRA DRILL/i)
  assert.strictEqual(player.affinityTrial?.kind, 'train')
})

await check('5. Shattering OR abandoning a Temple Drill grants 0 XP and enforces a 2h backlash cooldown', async () => {
  const { player, runCmd } = makeTestHarness()
  await runCmd(['train'])
  // Force instability near 100 and surge to shatter
  player.affinityTrial.forge.instability = 90
  const failOut = await runCmd(['forge', 'surge'])
  assert.match(failOut, /Chi Backlash|0 Mastery XP/i)
  assert.strictEqual(player.affinity.elements.fire.xp, 0)
  const cdAfterShatter = player.affinity.elements.fire.lastTrainAt + TEMPLE_TRAIN_COOLDOWN_MS - Date.now()
  assert.ok(cdAfterShatter > TEMPLE_TRAIN_BACKLASH_MS - 5000 && cdAfterShatter <= TEMPLE_TRAIN_BACKLASH_MS + 1000)

  // Retry immediately must be blocked by backlash cooldown
  const retryBlocked = await runCmd(['train'])
  assert.match(retryBlocked, /meridians are resting/i)

  // Clear cooldown and test .affinity abandon mid-drill
  player.affinity.elements.fire.lastTrainAt = 0
  await runCmd(['train'])
  assert.strictEqual(player.affinityTrial?.kind, 'train')
  const abandonOut = await runCmd(['abandon'])
  assert.match(abandonOut, /2h/i)
  const retryAfterAbandon = await runCmd(['train'])
  assert.match(retryAfterAbandon, /meridians are resting/i)
})

await check('6. Mastery Scrolls are removed from General Shop and enforce 1,500 XP/day cap', () => {
  const shopIds = new Set(shopItems.map((i) => i.id))
  assert.strictEqual(shopIds.has('scroll_bending_insight'), false, 'scroll_bending_insight must not be shop-buyable')
  assert.strictEqual(shopIds.has('scroll_white_lotus'), false, 'scroll_white_lotus must not be shop-buyable')

  const { player } = makeTestHarness()
  const r1 = grantMasteryXp(player, 1500, { elementId: 'fire', source: 'scroll' })
  assert.strictEqual(r1.gained, 1500)
  assert.strictEqual(canAbsorbMasteryScroll(player).ok, false)
  const r2 = grantMasteryXp(player, 450, { elementId: 'fire', source: 'scroll' })
  assert.strictEqual(r2.gained, 0)
  assert.strictEqual(r2.scrollCapped, true)
  assert.strictEqual(DAILY_SCROLL_XP_CAP, 1500)
})

await check('7. lib/version.js top entry obeys strict no-dash rule', () => {
  const top = CHANGELOG[0]
  assert.ok(top && top.version, 'top changelog entry must exist')
  for (const line of top.notes) {
    assert.ok(!/[-–—]/.test(line), `Dash found in changelog note: ${line}`)
  }
})

fs.rmSync(tmpDir, { recursive: true, force: true })
console.log(`\n🎉 All ${passed}/7 affinity training & anti-spam checks passed!`)
