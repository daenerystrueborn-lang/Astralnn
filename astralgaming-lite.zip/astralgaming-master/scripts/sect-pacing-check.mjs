/**
 * sect-pacing-check.mjs — does the Sect Empire's climb take the time it is
 * supposed to take?
 *
 * WHY. Every number in data/sect-conversion.json's `cultivation` block is a
 * claim about TIME, and a claim about time is only checkable against the player
 * who will actually be doing it: one who sits in a cave for a full eight hour
 * session every day, fights nothing, and collects every time. This prints what
 * that player's climb costs, stage by stage, and compares it with the targets
 * the design set:
 *
 *   the Awakening                3 days          (24 hours of meditation)
 *   all of Qi Condensation       8 weeks
 *   Foundation Establishment    10 weeks
 *   every realm after that      1.5x the one before
 *
 *   node scripts/sect-pacing-check.mjs
 *
 * Read only. Prints tables; never fails a build. Read it before changing
 * progress.base, progress.growth or progress.realmPeakMultiplier.
 */
import { CAVES, awakeningNeed, progressNeed, sessionRate } from '../lib/sect-progress.js'
import { REALMS, STAGES, stageLabel, stageByIndex } from '../lib/sect-cultivation.js'
import { growth } from '../lib/sect-progress.js'
import { huntCfg, huntWorth, dailyCapPoints, huntRate, perKillHours } from '../lib/sect-hunt.js'

const cfg = growth.progress ?? {}
const sessionCfg = growth.session ?? {}

// ── the reference player ────────────────────────────────────────────────────
const HOURS_A_DAY = 8
const REFERENCE_CAVE = CAVES[0] ?? { id: 'low_peak_cave', name: 'Low Peak Cave', richness: 1 }
const REFERENCE_ROOT = 1.0
const referenceRate = Number(sessionCfg.baseRatePerHour) * Number(REFERENCE_CAVE.richness) * REFERENCE_ROOT
const perDay = referenceRate * HOURS_A_DAY

const days = (progress) => progress / perDay

// ── the ladder, in order, with what each realm costs ────────────────────────
console.log('SECT PACING CHECK')
console.log(`reference player: ${HOURS_A_DAY}h a day in the ${REFERENCE_CAVE.name} (richness ${REFERENCE_CAVE.richness}),`
  + ` root multiplier ${REFERENCE_ROOT.toFixed(2)}, no fighting.`)
console.log(`rate: ${referenceRate.toFixed(3)} progress an hour, ${perDay.toFixed(2)} a day`
  + `  ·  base ${cfg.base}, growth ${cfg.growth}, realm peak x${cfg.realmPeakMultiplier}`
  + ` (${Object.entries(cfg.realmPeakMultiplierOverrides ?? {}).map(([k, v]) => `${k} x${v}`).join(', ')})\n`)

const rows = []
for (const stage of STAGES) {
  if (!stage.index) continue
  const need = progressNeed(stage.index)
  rows.push({ stage, need, d: days(need) })
}

let cumulative = 0
const realmDays = []
console.log('per stage')
from: for (const realm of REALMS) {
  if (!realm.stages.length) continue
  let realmTotal = 0
  for (const s of realm.stages) {
    const row = rows.find(r => r.stage.index === s.index)
    if (!row) continue
    cumulative += row.d
    realmTotal += row.d
    console.log(`  ${stageLabel(s.index).padEnd(38)} bar ${String(row.need).padStart(7)}  ${row.d.toFixed(1).padStart(7)}d   cum ${cumulative.toFixed(1).padStart(8)}d (${(cumulative / 7).toFixed(1)}w)`)
  }
  realmDays.push({ realm, days: realmTotal })
  continue from
}

// ── the targets ─────────────────────────────────────────────────────────────
const awakeningDays = awakeningNeed() / HOURS_A_DAY
const qc = realmDays.find(r => r.realm.id === 'qi_condensation')
const fe = realmDays.find(r => r.realm.id === 'foundation_establishment')
const afterFe = realmDays.filter(r => r.realm.index >= 3)

console.log('\nrealms')
for (const [i, entry] of realmDays.entries()) {
  const ratio = i === 0 ? '' : `  x${(entry.days / realmDays[i - 1].days).toFixed(2)} the one before`
  console.log(`  ${entry.realm.name.padEnd(26)} ${(entry.days / 7).toFixed(1).padStart(7)}w${ratio}`)
}

console.log('\ntargets')
const check = (label, actual, target, tolerance = 0.15) => {
  const ok = Math.abs(actual - target) / target <= tolerance
  console.log(`  ${ok ? 'OK  ' : 'OFF '} ${label.padEnd(34)} ${actual.toFixed(1).padStart(7)}w   target ${target.toFixed(1)}w`)
}
check('the Awakening (hours / 8h days)', awakeningDays / 7, 3 / 7)
check('all of Qi Condensation', qc.days / 7, 8)
check('Foundation Establishment', fe.days / 7, 10)
for (const [i, entry] of afterFe.entries()) {
  const before = i === 0 ? fe : afterFe[i - 1]
  console.log(`  ${Math.abs(entry.days / before.days - 1.5) <= 0.05 ? 'OK  ' : 'OFF '} ${entry.realm.name.padEnd(34)} ${(entry.days / before.days).toFixed(2).padStart(7)}x  target 1.50x`)
}

// ── what a better cave and a better root buy ────────────────────────────────
const qcUnits = rows.filter(r => stageByIndex(r.stage.index).realmId === 'qi_condensation').reduce((sum, r) => sum + r.need, 0)
console.log('\nQi Condensation, by cave and root (days, 8h a day)')
console.log('  cave                      x1.5      x1.25     x1.0      x0.8      x0.65   (root multiplier)')
for (const cave of CAVES) {
  const cells = [1.5, 1.25, 1.0, 0.8, 0.65].map(root => {
    const day = sessionRate({ spiritRoot: { speedMultiplier: root } }, cave) * HOURS_A_DAY
    return (qcUnits / day).toFixed(0).padStart(6) + 'd'
  })
  console.log(`  ${cave.name.padEnd(24)} ${cells.join('  ')}`)
}
// ── the hunt against the cave (Prompt 7) ────────────────────────────────
// The claim: hard fighting runs two to three times the pace of caves, and
// never more. The daily cap is what makes that a fact instead of a hope: a
// kill at your own stage pays one cave hour, and the day stops paying at
// dailyCapCaveHours of them, which is three eight hour sessions.
console.log('\nHUNTING AGAINST THE CAVE')
const hunter = { spiritRoot: { speedMultiplier: 1 }, stage: 10 }
const atStage = (gap) => huntWorth({ stageMin: 10 + gap, stageMax: 10 + gap }, { stage: 10, profile: hunter })
console.log(`reference hunter at stage 10: one cave hour is ${huntRate(hunter).toFixed(3)} progress here`)
console.log(`  a kill at your own stage   ${atStage(0).caveHours.toFixed(2)} cave hours  (${atStage(0).amount} progress)`)
console.log(`  one stage above you        ${atStage(1).caveHours.toFixed(2)} cave hours`)
console.log(`  two stages above you       ${atStage(2).caveHours.toFixed(2)} cave hours`)
console.log(`  eight stages above you     ${atStage(8).caveHours.toFixed(2)} cave hours  (the stage bonus stops at +${huntCfg.progress.maxStageBonus}, so x${1 + huntCfg.progress.maxStageBonus} in all)`)
console.log(`  one stage below you        ${atStage(-1).caveHours.toFixed(2)} cave hours`)
console.log(`  two stages below you       ${atStage(-2).ok ? atStage(-2).caveHours.toFixed(2) : 'nothing at all'}`)
const caveDay = referenceRate * HOURS_A_DAY
const huntDay = dailyCapPoints(hunter)
const pace = (huntRate(hunter) * Number(huntCfg.progress.dailyCapCaveHours)) / caveDay
console.log(`  a full cave day pays ${caveDay.toFixed(1)}; a full hunting day is capped at ${huntDay}`)
console.log(`  ${pace >= 2 && pace <= 3 ? 'OK  ' : 'OFF '} hard fighting against caves   ${pace.toFixed(2)}x   target 2.00-3.00x`)
console.log(`  the cap takes ${Math.ceil(huntDay / Math.max(1, atStage(0).amount))} kills at your own stage,`
  + ` and the ${huntCfg.cooldownSeconds}s between hunts is the only clock on them,`
  + ` so the cap, not the clock, is the wall. per-kill: ${perKillHours(hunter)} cave hour.`)

const lowRate = sessionRate({ spiritRoot: { speedMultiplier: 1 } }, CAVES[0])
console.log('\n  the best cave against the first, at one root:')
for (const cave of CAVES) {
  const factor = sessionRate({ spiritRoot: { speedMultiplier: 1 } }, cave) / lowRate
  const cap = Number(cave.richness) / Number(CAVES[0].richness)
  console.log(`    ${cave.name.padEnd(24)} x${factor.toFixed(2)}   (richness x${cap.toFixed(2)}: ${factor <= cap + 1e-9 ? 'never more than the cave is worth' : 'OVER THE CAP'})`)
}
console.log('\n  one session is capped at ' + (Number(sessionCfg.maxHours) || 12) + 'h, and the Awakening wants '
  + awakeningNeed() + 'h of meditation, which is ' + awakeningDays.toFixed(1) + ' reference days.')
