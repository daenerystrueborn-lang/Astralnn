#!/usr/bin/env node
/**
 * scripts/mirror-balance.mjs — balance harness for The World That Never Ends.
 *
 *   node scripts/mirror-balance.mjs stage  [--n 1000] [--builds a,b] [--opps random,greedy,depth3] [--depths 1,2,3,4,5,6] [--no-lapse]
 *   node scripts/mirror-balance.mjs final  [--n 1000] [--builds …] [--opps …] [--final-first player,reflection,player | coin,coin,coin]
 *   node scripts/mirror-balance.mjs run    [--runs 200] [--mood bored] [--builds …] [--opps …] [--stage-heal 0.25] [--stage-first coin|player|reflection|0.9] [--lapse-scale 0.5]
 *   node scripts/mirror-balance.mjs all    (all three, defaults)
 *
 * STAGE  one isolated stage at full HP: the reflection at depth d (with the
 *        production lapse unless --no-lapse) against a player stand-in.
 *        Conditions are drawn the way a run draws them (a legal trial pair,
 *        stage 1 / 2 / 3 rotating), first mover a seeded coin.
 * FINAL  the best-of-three final: depth 6, full HP each round, the round
 *        conditions and first movers the run uses.
 * RUN    a whole run through lib/inverted-run.js itself (whims, HP carry,
 *        heals between trials, the final), mood fixed.
 *
 * Player stand-ins: random (uniform legal move), greedy (the brain's one-ply
 * heuristic), depth3 (the brain itself at depth 3, no lapse): "average",
 * "decent" and "strong" play. Fights use the pure simulator
 * (lib/inverted-sim.js), which test/inverted-dimension-equivalence.test.mjs
 * proves identical to the live engine; RUN mode uses the live engine.
 * Everything is seeded, so two runs of this script print the same table.
 * The brain runs on a deterministic node budget instead of the 400 ms clock.
 *
 * Targets (spec): depth 1 ≈ 95% player wins, depth 3 ≈ 75%, depth 6 ≈ 50%,
 * final 40–50%, a full Bored run 20–30% for strong play and under 5% for
 * average play. See docs/inverted-dimension-build-report.md for the numbers
 * and for which targets the mirror format can and cannot meet.
 */

import { pathToFileURL } from 'node:url'
import { INVERTED, trialConditions, stageConditions, finalRoundConditions } from '../lib/inverted-core.js'
import { snapshotPlayer, fighterFor } from '../lib/inverted-kit.js'
import { newFight, resolveTurn, rngChance, legalMoves } from '../lib/inverted-sim.js'
import { chooseMove, greedyMove } from '../lib/inverted-brain.js'
import { createRun, readyRun, playerMove, getRun, setBrainLogger, setBrainOptions, setRunOverrides, finalFirstMover } from '../lib/inverted-run.js'
import { seeded } from '../lib/seeded-rng.js'
import { BUILDS, playerFromBuild } from './inverted-builds.mjs'

export const NODE_BUDGET = 60_000

export function standIn(kind, seedText) {
  const rr = seeded(`standin:${seedText}`)
  return (s) => {
    if (kind === 'random') { const l = legalMoves(s, 'p'); return l[Math.floor(rr() * l.length)] }
    if (kind === 'greedy') return greedyMove(s, 'p')
    return chooseMove(s, { who: 'p', depth: 3, seed: `${seedText}:${s.turn}`, budgetMs: 0, nodeBudget: NODE_BUDGET, lapse: false }).move
  }
}

function reflectionMove(s, depth, seedText, lapse) {
  return chooseMove(s, {
    who: 'r', depth, seed: `${seedText}:${s.turn}`, budgetMs: 0, nodeBudget: NODE_BUDGET,
    ...(lapse ? {} : { lapseOverride: 0 }),
  }).move
}

/** One fight to the end with the pure simulator. → 'p' | 'r' */
export function playFight({ snap, conds, cap, first, depth, opp, seedText, lapse = true }) {
  const P = fighterFor(snap, conds, snap.name)
  const R = fighterFor(snap, conds, 'Reflection')
  let s = newFight({ P, R, conds, cap, first, hp: snap.maxHp, mp: snap.maxMp })
  const pick = standIn(opp, seedText)
  while (!s.over) {
    const mr = reflectionMove(s, depth, `r:${seedText}`, lapse)
    const mp = pick(s)
    s = resolveTurn(s, mp, mr, rngChance(seeded(`dice:${seedText}:${s.turn}`)))
  }
  return { winner: s.over.winner, turns: s.turn }
}

export function stageRate({ build, opp, depth, n, lapse = true, stageFirst = INVERTED.run.stageFirstMover }) {
  const snap = snapshotPlayer(playerFromBuild(build))
  let wins = 0
  let turns = 0
  for (let i = 0; i < n; i++) {
    const trial = trialConditions(`bal:${build}:${i}`)
    const conds = stageConditions(trial, i % 3)
    const first = finalFirstMover(stageFirst, `bal:first:${build}:${i}`)
    const r = playFight({ snap, conds, cap: INVERTED.run.stageTurnCap, first, depth, opp, seedText: `st:${build}:${opp}:${depth}:${i}`, lapse })
    if (r.winner === 'p') wins++
    turns += r.turns
  }
  return { rate: wins / n, avgTurns: turns / n }
}

export function finalRate({ build, opp, n, firstMovers = INVERTED.final.roundFirstMover }) {
  const snap = snapshotPlayer(playerFromBuild(build))
  let wins = 0
  for (let i = 0; i < n; i++) {
    const rounds = finalRoundConditions(`bal:final:${build}:${i}`)
    const tally = { p: 0, r: 0 }
    for (let r = 0; r < INVERTED.final.maxRounds && tally.p < INVERTED.final.roundsToWin && tally.r < INVERTED.final.roundsToWin; r++) {
      const first = finalFirstMover(firstMovers[r], `bal:final:first:${build}:${i}:${r}`)
      const res = playFight({ snap, conds: rounds[r], cap: INVERTED.final.roundTurnCap, first, depth: INVERTED.final.depth, opp, seedText: `fi:${build}:${opp}:${i}:${r}` })
      tally[res.winner]++
    }
    if (tally.p >= INVERTED.final.roundsToWin) wins++
  }
  return { rate: wins / n }
}

/** A whole run through the real run module. */
export function runRate({ build, opp, runs, mood = 'bored', stageHeal = null, stageFirst = null, lapseScale = 1, finalFirst = null }) {
  setBrainLogger(() => {})
  setBrainOptions({ budgetMs: 0, nodeBudget: NODE_BUDGET, lapseScale })
  setRunOverrides({ ...(stageHeal == null ? {} : { healBetweenStagesPct: stageHeal }), ...(stageFirst != null ? { stageFirstMover: stageFirst } : {}), ...(finalFirst ? { roundFirstMover: finalFirst } : {}) })
  let wins = 0
  let distance = 0
  let finals = 0
  for (let i = 0; i < runs; i++) {
    const pl = playerFromBuild(build, { id: `bal_${build}_${i}@s`, location: 'astral_town', wallet: { solars: 0, gems: 0 } })
    const t0 = 1_800_000_000_000 + i * 1000
    createRun(pl, { now: t0, mood, seasonId: 'balance' })
    const pick = standIn(opp, `run:${build}:${opp}:${i}`)
    let now = t0
    let guard = 0
    let reachedFinal = false
    while (guard++ < 5000) {
      const run = getRun(pl)
      if (!run) break
      now += 1000
      if (!run.fight || run.fight.over) { readyRun(pl, now); continue }
      if (run.phase === 'final') reachedFinal = true
      playerMove(pl, pick(run.fight), now, null)
    }
    const last = pl.inverted.run
    if (last?.result === 'won') wins++
    if (reachedFinal) finals++
    distance += last?.distance ?? 0
  }
  setBrainOptions({})
  setRunOverrides({})
  return { rate: wins / runs, finalReach: finals / runs, avgDistance: distance / runs }
}

function parseArgs(argv) {
  const out = { mode: argv[0] && !argv[0].startsWith('--') ? argv[0] : 'all' }
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]
    if (!a.startsWith('--')) continue
    const k = a.slice(2)
    if (k === 'no-lapse') { out.noLapse = true; continue }
    out[k] = argv[i + 1]
    i++
  }
  return out
}

const pct = (x) => `${(x * 100).toFixed(1)}%`

async function main() {
  const a = parseArgs(process.argv.slice(2))
  const builds = (a.builds ?? Object.keys(BUILDS).join(',')).split(',')
  const opps = (a.opps ?? 'random,greedy,depth3').split(',')
  const depths = (a.depths ?? '1,2,3,4,5,6').split(',').map(Number)
  const n = Number(a.n ?? 1000)
  const t0 = Date.now()

  if (a.mode === 'stage' || a.mode === 'all') {
    console.log(`\n## Stage win rate (player), n=${n} per cell${a.noLapse ? ', lapse OFF' : ', production lapse'}\n`)
    console.log(`| build | player | ${depths.map(d => `d${d}`).join(' | ')} |`)
    console.log(`|---|---|${depths.map(() => '---').join('|')}|`)
    for (const b of builds) for (const o of opps) {
      const cells = depths.map(d => pct(stageRate({ build: b, opp: o, depth: d, n, lapse: !a.noLapse, stageFirst: a['stage-first'] == null ? INVERTED.run.stageFirstMover : (isNaN(Number(a['stage-first'])) ? a['stage-first'] : Number(a['stage-first'])) }).rate))
      console.log(`| ${b} | ${o} | ${cells.join(' | ')} |`)
    }
  }
  if (a.mode === 'final' || a.mode === 'all') {
    const firstMovers = a['final-first'] ? a['final-first'].split(',') : INVERTED.final.roundFirstMover
    console.log(`\n## Final (best of three, depth ${INVERTED.final.depth}, first movers ${firstMovers.join('/')}), n=${n}\n`)
    console.log(`| build | ${opps.join(' | ')} |`)
    console.log(`|---|${opps.map(() => '---').join('|')}|`)
    for (const b of builds) console.log(`| ${b} | ${opps.map(o => pct(finalRate({ build: b, opp: o, n, firstMovers }).rate)).join(' | ')} |`)
  }
  if (a.mode === 'run' || a.mode === 'all') {
    const runs = Number(a.runs ?? 200)
    const mood = a.mood ?? 'bored'
    const stageHeal = a['stage-heal'] != null ? Number(a['stage-heal']) : null
    const stageFirst = a['stage-first'] == null ? null : (isNaN(Number(a['stage-first'])) ? a['stage-first'] : Number(a['stage-first']))
    const lapseScale = a['lapse-scale'] != null ? Number(a['lapse-scale']) : 1
    const finalFirst = a['final-first'] ? a['final-first'].split(',') : null
    console.log(`\n## Full ${mood} run, ${runs} runs per cell${stageHeal != null ? `, stage heal ${stageHeal * 100}%` : ''}${stageFirst ? `, stage first mover ${stageFirst}` : ''}${lapseScale !== 1 ? `, lapse ×${lapseScale}` : ''}${finalFirst ? `, final ${finalFirst.join('/')}` : ''} (win % · reached final % · avg Distance)\n`)
    console.log(`| build | ${opps.join(' | ')} |`)
    console.log(`|---|${opps.map(() => '---').join('|')}|`)
    for (const b of builds) {
      console.log(`| ${b} | ${opps.map(o => { const r = runRate({ build: b, opp: o, runs, mood, stageHeal, stageFirst, lapseScale, finalFirst }); return `${pct(r.rate)} · ${pct(r.finalReach)} · ${r.avgDistance.toFixed(1)}` }).join(' | ')} |`)
    }
  }
  console.log(`\n_${((Date.now() - t0) / 1000).toFixed(0)} s_`)
}

if (import.meta.url === pathToFileURL(process.argv[1] ?? '').href) await main()
