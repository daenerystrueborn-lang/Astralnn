/** Every material a post-Nascent recipe asks for must be obtainable. */
import assert from 'node:assert/strict'
import { MATERIALS } from '../lib/sect-materials.js'
import { AREAS, areaProblems, gatherRows } from '../lib/sect-areas.js'
import { monsterProblems } from '../lib/sect-monsters.js'
import { realmProblems } from '../lib/sect-ruins.js'
import { recipeProblems, RECIPES } from '../lib/sect-craft.js'

assert.deepEqual(areaProblems, [], 'area data')
assert.deepEqual(monsterProblems, [], 'monster data')
assert.deepEqual(realmProblems, [], 'ruins data')
assert.deepEqual(recipeProblems, [], 'recipe data')

const materials = new Map(MATERIALS.map(m => [m.id, m]))
const gathered = new Set(AREAS.flatMap(a => (a.gather ?? []).map(r => r.id)))
const dropped = new Set()
const rare = new Set()
const { createRequire } = await import('node:module')
const require = createRequire(import.meta.url)
for (const m of require('../data/sect-monsters.json').monsters ?? []) {
  for (const row of m.drops ?? []) if (row.kind === 'material') dropped.add(row.id)
}
for (const r of require('../data/sect-ruins.json').realms ?? []) {
  for (const row of r.rare ?? []) rare.add(row.id)
}

const missing = []
for (const [id, material] of materials) {
  if (Number(material.tier) < 5) continue
  // Rares are deliberately the secret realms' own loot; ordinary materials
  // must be both gathered in the wild and dropped by a beast of that tier.
  const ok = material.kind === 'rare'
    ? rare.has(id)
    : gathered.has(id) && dropped.has(id)
  if (!ok) missing.push(id)
}
assert.deepEqual(missing, [], `tier 5+ materials need an obtainable source; missing: ${missing.join(', ')}`)

const recipeIds = new Set(RECIPES.flatMap(r => (r.materials ?? []).map(m => m.id)))
const unsourced = [...recipeIds].filter(id => !(gathered.has(id) || dropped.has(id) || rare.has(id)))
assert.deepEqual(unsourced, [], `recipe materials with no source: ${unsourced.join(', ')}`)

// A young cultivator cannot pick a tier-9 herb out of a tier-1/9 area just
// because both rows are written on the same table.
const high = AREAS.find(a => a.id === 'ashen_valley')
const early = gatherRows(high, { stage: 10 }).map(r => r.id)
const late = gatherRows(high, { stage: 35 }).map(r => r.id)
assert.ok(late.length > early.length, 'stage must open higher gather rows')
assert.ok(late.some(id => Number(materials.get(id)?.tier) >= 9))
assert.ok(!early.some(id => Number(materials.get(id)?.tier) >= 9))

console.log(`${MATERIALS.length} materials checked; every tier 5+ material has gather, hunt and ruin sources.`)
