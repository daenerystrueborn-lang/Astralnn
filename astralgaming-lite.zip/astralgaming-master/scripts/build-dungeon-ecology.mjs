#!/usr/bin/env node
/**
 * Builds data/dungeon-ecology.json. The committed JSON is the runtime catalog.
 * The simulation itself lives in lib/dungeon-ecology.js; this file only authors
 * the world content: regions, species, food webs, events and intervention verbs.
 */
import { writeFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')

const species = [
  // Entry Tower
  { id:'tower_rat', region:'entry_tower', name:'Rift Rat', emoji:'🐀', tags:['beast','swarm'], diet:'omnivore', prey:[], predators:['tower_hawk','tower_wolf'], population:140, growth:0.22, aggression:0.18, carrying:220, keywords:['rat','gargoyle','crawler'] },
  { id:'tower_hawk', region:'entry_tower', name:'Rift Hawk', emoji:'🦅', tags:['beast','evasion'], diet:'carnivore', prey:['tower_rat'], predators:['tower_wolf'], population:45, growth:0.12, aggression:0.32, carrying:90, keywords:['hawk','harpy','bat'] },
  { id:'tower_wolf', region:'entry_tower', name:'Stone Wolf', emoji:'🐺', tags:['beast','burst'], diet:'carnivore', prey:['tower_rat','tower_hawk'], predators:[], population:24, growth:0.08, aggression:0.45, carrying:55, keywords:['wolf','hound','lizard'] },
  { id:'tower_moss', region:'entry_tower', name:'Living Moss', emoji:'🌿', tags:['construct','healer'], diet:'photosynthetic', prey:[], predators:['tower_rat'], population:180, growth:0.18, aggression:0.05, carrying:260, keywords:['moss','slime','vine'] },

  // Gloomhollow
  { id:'gloom_bat', region:'gloomhollow_caverns', name:'Gloom Bat', emoji:'🦇', tags:['beast','evasion'], diet:'insectivore', prey:['gloom_moth'], predators:['gloom_spider'], population:160, growth:0.2, aggression:0.22, carrying:240, keywords:['bat','shade'] },
  { id:'gloom_moth', region:'gloomhollow_caverns', name:'Lantern Moth', emoji:'🦋', tags:['swarm','mana'], diet:'nectar', prey:[], predators:['gloom_bat','gloom_spider'], population:220, growth:0.26, aggression:0.04, carrying:320, keywords:['moth','wisp'] },
  { id:'gloom_spider', region:'gloomhollow_caverns', name:'Hollow Spider', emoji:'🕷️', tags:['poison','control'], diet:'carnivore', prey:['gloom_bat','gloom_moth'], predators:['gloom_stalker'], population:55, growth:0.12, aggression:0.42, carrying:100, keywords:['spider','crawler'] },
  { id:'gloom_stalker', region:'gloomhollow_caverns', name:'Hollow Stalker', emoji:'🌑', tags:['undead','execute'], diet:'carnivore', prey:['gloom_spider'], predators:[], population:18, growth:0.06, aggression:0.6, carrying:40, keywords:['stalker','wraith','shade'] },

  // Gambit's Dungeon
  { id:'gambit_mirror', region:'gambits_dungeon', name:'Mirror Imp', emoji:'🪞', tags:['construct','evasion'], diet:'mana', prey:['gambit_wisp'], predators:['gambit_knight'], population:120, growth:0.16, aggression:0.28, carrying:180, keywords:['imp','mirror','phantom'] },
  { id:'gambit_wisp', region:'gambits_dungeon', name:"Fool's Wisp", emoji:'✨', tags:['mana','swarm'], diet:'mana', prey:[], predators:['gambit_mirror'], population:180, growth:0.22, aggression:0.08, carrying:260, keywords:['wisp','spirit'] },
  { id:'gambit_knight', region:'gambits_dungeon', name:'Card Knight', emoji:'🃏', tags:['construct','shield'], diet:'mana', prey:['gambit_mirror'], predators:['gambit_trickster'], population:40, growth:0.09, aggression:0.38, carrying:80, keywords:['knight','guard','card'] },
  { id:'gambit_trickster', region:'gambits_dungeon', name:'Gambit Trickster', emoji:'🎭', tags:['control','burst'], diet:'mana', prey:['gambit_knight'], predators:[], population:16, growth:0.05, aggression:0.55, carrying:36, keywords:['trickster','jester','gambit'] },

  // Centurion
  { id:'centurion_legion', region:'centurions_dungeon', name:'Lost Legionnaire', emoji:'🛡️', tags:['undead','shield'], diet:'none', prey:[], predators:['centurion_warlord'], population:150, growth:0.1, aggression:0.35, carrying:220, keywords:['legion','centurion','soldier'] },
  { id:'centurion_hound', region:'centurions_dungeon', name:'War Hound', emoji:'🐕', tags:['beast','pursuit'], diet:'carnivore', prey:['centurion_scout'], predators:['centurion_warlord'], population:60, growth:0.14, aggression:0.44, carrying:100, keywords:['hound','wolf','beast'] },
  { id:'centurion_scout', region:'centurions_dungeon', name:'Broken Scout', emoji:'🏹', tags:['undead','ranged'], diet:'none', prey:[], predators:['centurion_hound'], population:90, growth:0.12, aggression:0.24, carrying:150, keywords:['scout','archer','bow'] },
  { id:'centurion_warlord', region:'centurions_dungeon', name:'Iron Warlord', emoji:'⚔️', tags:['construct','command'], diet:'none', prey:['centurion_legion','centurion_hound'], predators:[], population:12, growth:0.04, aggression:0.65, carrying:30, keywords:['warlord','captain','iron'] },

  // Stormpeak
  { id:'storm_gryphon', region:'stormpeak', name:'Storm Gryphon', emoji:'🦅', tags:['beast','evasion'], diet:'carnivore', prey:['storm_goat'], predators:['storm_drake'], population:40, growth:0.1, aggression:0.4, carrying:80, keywords:['gryphon','harpy','roc'] },
  { id:'storm_goat', region:'stormpeak', name:'Crag Goat', emoji:'🐐', tags:['beast','guard'], diet:'herbivore', prey:[], predators:['storm_gryphon','storm_wolf'], population:160, growth:0.2, aggression:0.12, carrying:240, keywords:['goat','ram','beast'] },
  { id:'storm_wolf', region:'stormpeak', name:'Thunder Wolf', emoji:'🐺', tags:['beast','burst'], diet:'carnivore', prey:['storm_goat'], predators:['storm_drake'], population:55, growth:0.13, aggression:0.46, carrying:95, keywords:['wolf','thunder'] },
  { id:'storm_drake', region:'stormpeak', name:'Peak Drake', emoji:'🐉', tags:['dragon','burst'], diet:'carnivore', prey:['storm_gryphon','storm_wolf'], predators:[], population:10, growth:0.04, aggression:0.7, carrying:24, keywords:['drake','dragon','wyvern'] },

  // Crystaldeep
  { id:'crystal_golem', region:'crystaldeep_caverns', name:'Crystal Golem', emoji:'💎', tags:['construct','shield'], diet:'mineral', prey:[], predators:['crystal_wurm'], population:70, growth:0.08, aggression:0.2, carrying:120, keywords:['golem','crystal','construct'] },
  { id:'crystal_wisp', region:'crystaldeep_caverns', name:'Prism Wisp', emoji:'🔮', tags:['mana','swarm'], diet:'mana', prey:[], predators:['crystal_golem'], population:180, growth:0.2, aggression:0.06, carrying:260, keywords:['wisp','prism','spirit'] },
  { id:'crystal_wurm', region:'crystaldeep_caverns', name:'Gem Wurm', emoji:'🪱', tags:['beast','armor_break'], diet:'mineral', prey:['crystal_golem'], predators:['crystal_queen'], population:30, growth:0.09, aggression:0.42, carrying:65, keywords:['wurm','worm','burrow'] },
  { id:'crystal_queen', region:'crystaldeep_caverns', name:'Shard Queen', emoji:'👑', tags:['construct','command'], diet:'mana', prey:['crystal_wurm'], predators:[], population:8, growth:0.03, aggression:0.6, carrying:20, keywords:['queen','shard','monarch'] },

  // Astral Tower
  { id:'astral_sentinel', region:'astral_tower', name:'Astral Sentinel', emoji:'🛡️', tags:['construct','shield'], diet:'mana', prey:[], predators:['astral_reaver'], population:110, growth:0.09, aggression:0.3, carrying:170, keywords:['sentinel','guard','astral'] },
  { id:'astral_mote', region:'astral_tower', name:'Star Mote', emoji:'✨', tags:['mana','swarm'], diet:'mana', prey:[], predators:['astral_sentinel'], population:240, growth:0.24, aggression:0.05, carrying:340, keywords:['mote','star','wisp'] },
  { id:'astral_reaver', region:'astral_tower', name:'Void Reaver', emoji:'🌌', tags:['dark','execute'], diet:'mana', prey:['astral_sentinel','astral_mote'], predators:['astral_archon'], population:35, growth:0.08, aggression:0.52, carrying:75, keywords:['reaver','void','knight'] },
  { id:'astral_archon', region:'astral_tower', name:'Fallen Archon', emoji:'👼', tags:['command','burst'], diet:'mana', prey:['astral_reaver'], predators:[], population:9, growth:0.03, aggression:0.68, carrying:22, keywords:['archon','angel','fallen'] },

  // Eternal Dungeon
  { id:'eternal_wraith', region:'eternal_dungeon', name:'Eternal Wraith', emoji:'👻', tags:['undead','evasion'], diet:'souls', prey:['eternal_shade'], predators:['eternal_lich'], population:130, growth:0.11, aggression:0.4, carrying:200, keywords:['wraith','ghost','spirit'] },
  { id:'eternal_shade', region:'eternal_dungeon', name:'Memory Shade', emoji:'🌫️', tags:['undead','swarm'], diet:'souls', prey:[], predators:['eternal_wraith'], population:210, growth:0.18, aggression:0.16, carrying:300, keywords:['shade','memory','phantom'] },
  { id:'eternal_lich', region:'eternal_dungeon', name:'Bone Lich', emoji:'💀', tags:['undead','caster'], diet:'souls', prey:['eternal_wraith'], predators:['eternal_deathlord'], population:24, growth:0.06, aggression:0.58, carrying:55, keywords:['lich','bone','necro'] },
  { id:'eternal_deathlord', region:'eternal_dungeon', name:'Deathlord', emoji:'☠️', tags:['undead','command'], diet:'souls', prey:['eternal_lich'], predators:[], population:6, growth:0.02, aggression:0.75, carrying:16, keywords:['deathlord','death','lord'] },

  // Caged Dimension
  { id:'caged_horror', region:'caged_dimension', name:'Caged Horror', emoji:'🧟', tags:['aberration','burst'], diet:'mana', prey:['caged_spawn'], predators:['caged_warden'], population:90, growth:0.14, aggression:0.55, carrying:150, keywords:['horror','flesh','aberration'] },
  { id:'caged_spawn', region:'caged_dimension', name:'Rift Spawn', emoji:'🥚', tags:['aberration','swarm'], diet:'mana', prey:[], predators:['caged_horror'], population:260, growth:0.28, aggression:0.1, carrying:360, keywords:['spawn','larva','rift'] },
  { id:'caged_warden', region:'caged_dimension', name:'Chain Warden', emoji:'⛓️', tags:['construct','control'], diet:'none', prey:['caged_horror'], predators:['caged_jailer'], population:28, growth:0.06, aggression:0.48, carrying:60, keywords:['warden','chain','jailer'] },
  { id:'caged_jailer', region:'caged_dimension', name:'The Jailer', emoji:'🗝️', tags:['command','control'], diet:'none', prey:['caged_warden'], predators:[], population:5, growth:0.02, aggression:0.8, carrying:14, keywords:['jailer','key','lock'] },

  // Quiet Mile
  { id:'quiet_stray', region:'the_quiet_mile', name:'Quiet Stray', emoji:'🐈', tags:['beast','evasion'], diet:'omnivore', prey:['quiet_mouse'], predators:['quiet_hound'], population:120, growth:0.18, aggression:0.14, carrying:190, keywords:['stray','cat','beast'] },
  { id:'quiet_mouse', region:'the_quiet_mile', name:'Hush Mouse', emoji:'🐁', tags:['beast','swarm'], diet:'omnivore', prey:[], predators:['quiet_stray','quiet_hound'], population:260, growth:0.26, aggression:0.03, carrying:360, keywords:['mouse','rat','rodent'] },
  { id:'quiet_hound', region:'the_quiet_mile', name:'Silent Hound', emoji:'🐕', tags:['undead','pursuit'], diet:'carnivore', prey:['quiet_stray','quiet_mouse'], predators:['quiet_bellkeeper'], population:45, growth:0.1, aggression:0.44, carrying:85, keywords:['hound','dog','silent'] },
  { id:'quiet_bellkeeper', region:'the_quiet_mile', name:'Bellkeeper', emoji:'🔔', tags:['undead','command'], diet:'souls', prey:['quiet_hound'], predators:[], population:10, growth:0.03, aggression:0.62, carrying:24, keywords:['bell','keeper','ringer'] },
]

const regions = [
  { id:'entry_tower', name:'Entry Tower', biome:'ruined tower', climate:'stable', species:['tower_rat','tower_hawk','tower_wolf','tower_moss'], unrest:0.1, corruption:0.05 },
  { id:'gloomhollow_caverns', name:'Gloomhollow Caverns', biome:'lightless cavern', climate:'humid', species:['gloom_bat','gloom_moth','gloom_spider','gloom_stalker'], unrest:0.18, corruption:0.12 },
  { id:'gambits_dungeon', name:"Gambit's Dungeon", biome:'shifting labyrinth', climate:'unstable', species:['gambit_mirror','gambit_wisp','gambit_knight','gambit_trickster'], unrest:0.22, corruption:0.16 },
  { id:'centurions_dungeon', name:"Centurion's Dungeon", biome:'buried warcamp', climate:'dry', species:['centurion_legion','centurion_hound','centurion_scout','centurion_warlord'], unrest:0.26, corruption:0.1 },
  { id:'stormpeak', name:'Stormpeak', biome:'alpine spire', climate:'storm', species:['storm_gryphon','storm_goat','storm_wolf','storm_drake'], unrest:0.2, corruption:0.08 },
  { id:'crystaldeep_caverns', name:'Crystaldeep Caverns', biome:'crystal geode', climate:'resonant', species:['crystal_golem','crystal_wisp','crystal_wurm','crystal_queen'], unrest:0.14, corruption:0.14 },
  { id:'astral_tower', name:'Astral Tower', biome:'starlit citadel', climate:'astral', species:['astral_sentinel','astral_mote','astral_reaver','astral_archon'], unrest:0.24, corruption:0.2 },
  { id:'eternal_dungeon', name:'Eternal Dungeon', biome:'necropolis', climate:'deathly', species:['eternal_wraith','eternal_shade','eternal_lich','eternal_deathlord'], unrest:0.3, corruption:0.3 },
  { id:'caged_dimension', name:'Caged Dimension', biome:'prison plane', climate:'rift-bound', species:['caged_horror','caged_spawn','caged_warden','caged_jailer'], unrest:0.34, corruption:0.36 },
  { id:'the_quiet_mile', name:'The Quiet Mile', biome:'silent road', climate:'hushed', species:['quiet_stray','quiet_mouse','quiet_hound','quiet_bellkeeper'], unrest:0.16, corruption:0.18 },
]

const events = [
  { id:'prey_bloom', name:'Prey Bloom', emoji:'🌿', trigger:{ preyOverpop:true }, effects:{ preyGrowth:0.15, predatorGrowth:0.08, spawnWeight:0.1 }, text:'Prey species overflow the lower halls.' },
  { id:'predator_surge', name:'Predator Surge', emoji:'🐺', trigger:{ predatorOverpop:true }, effects:{ aggression:0.1, atkMult:1.06, spawnWeight:0.12 }, text:'Predators grow bold and hunt in packs.' },
  { id:'famine', name:'Famine', emoji:'🥀', trigger:{ preyCollapse:true }, effects:{ aggression:0.18, populationGrowth:-0.1, hpMult:0.94 }, text:'Food webs collapse; everything is desperate.' },
  { id:'migration', name:'Migration', emoji:'🧭', trigger:{ weekParity:0 }, effects:{ spawnWeight:0.08, unrest:-0.04 }, text:'New herds move through the dungeon.' },
  { id:'warband', name:'Warband', emoji:'⚔️', trigger:{ unrestHigh:true }, effects:{ atkMult:1.08, defMult:1.04, extraPackChance:0.15 }, text:'Scattered monsters organize into a warband.' },
  { id:'sanctuary', name:'Sanctuary', emoji:'🕊️', trigger:{ unrestLow:true }, effects:{ aggression:-0.1, hpMult:1.03, unrest:-0.05 }, text:'A quiet pocket forms; creatures are calmer but hardier.' },
  { id:'corruption_bloom', name:'Corruption Bloom', emoji:'🌑', trigger:{ corruptionHigh:true }, effects:{ corruption:0.08, atkMult:1.05, tags:['undead'] }, text:'Corruption seeps into the food web.' },
  { id:'mana_spring', name:'Mana Spring', emoji:'🔮', trigger:{ manaOverpop:true }, effects:{ mpRestore:0.03, spawnWeight:0.08, tags:['mana'] }, text:'Mana-rich creatures swarm the springs.' },
  { id:'crystal_resonance', name:'Crystal Resonance', emoji:'💎', trigger:{ biome:'crystal geode' }, effects:{ defMult:1.06, staggerResist:0.1 }, text:'The walls sing; armored creatures resonate.' },
  { id:'storm_front', name:'Storm Front', emoji:'🌩️', trigger:{ climate:'storm' }, effects:{ atkMult:1.05, evasion:0.04 }, text:'Storm pressure makes every strike sharper.' },
  { id:'deathly_hush', name:'Deathly Hush', emoji:'💀', trigger:{ biome:'necropolis' }, effects:{ antiHeal:0.1, tags:['undead'] }, text:'The dead do not rest; healing feels thin.' },
  { id:'rift_leak', name:'Rift Leak', emoji:'🌀', trigger:{ biome:'prison plane' }, effects:{ corruption:0.06, extraPackChance:0.12, tags:['aberration'] }, text:'Something leaks through the cage.' },
  { id:'overhunt', name:'Overhunt', emoji:'🏹', trigger:{ pressureHigh:true }, effects:{ preyGrowth:-0.12, unrest:0.08, spawnWeight:-0.08 }, text:'Players have hunted the region too hard.' },
  { id:'recovery', name:'Recovery', emoji:'🌱', trigger:{ pressureLow:true }, effects:{ populationGrowth:0.1, unrest:-0.06 }, text:'The region recovers from recent pressure.' },
  { id:'alpha_ascends', name:'Alpha Ascends', emoji:'👑', trigger:{ apexOverpop:true }, effects:{ bossBias:'armored', atkMult:1.04 }, text:'An apex creature claims the deeper floors.' },
  { id:'scavenger_feast', name:'Scavenger Feast', emoji:'🦴', trigger:{ recentKillsHigh:true }, effects:{ scavengerGrowth:0.15, spawnWeight:0.1 }, text:'Scavengers gather where battles were fought.' },
  { id:'silent_road', name:'Silent Road', emoji:'🔕', trigger:{ biome:'silent road' }, effects:{ evasion:0.05, unrest:-0.03 }, text:'The Mile grows quieter; footsteps vanish.' },
  { id:'lantern_swarm', name:'Lantern Swarm', emoji:'🏮', trigger:{ species:'gloom_moth' }, effects:{ spawnWeight:0.15, tags:['swarm'] }, text:'Lantern moths fill the dark.' },
  { id:'iron_mutiny', name:'Iron Mutiny', emoji:'🛡️', trigger:{ species:'centurion_legion' }, effects:{ defMult:1.05, unrest:0.06 }, text:'The lost legion drills for war.' },
  { id:'starfall', name:'Starfall', emoji:'🌠', trigger:{ biome:'starlit citadel' }, effects:{ manaOverpop:true, spawnWeight:0.1, tags:['mana'] }, text:'Falling stars feed the tower.' },
]

const interventions = {
  scout: { stamina:1, solars:0, insight:1, durationMs:86400000, text:'You map tracks, nests and feeding grounds.' },
  cull: { stamina:2, solars:0, populationDelta:-0.12, pressure:0.08, unrest:0.03, text:'You thin a population before it becomes a plague.' },
  feed: { stamina:1, solars:500, populationDelta:0.1, aggression:-0.06, unrest:-0.04, text:'You leave bait and salt to steady a food web.' },
  sabotage: { stamina:2, solars:1500, unrest:0.12, corruption:0.04, bossWeaken:0.03, text:'You break banners, salt nests and turn predators against each other.' },
  sanctuary: { stamina:2, solars:1000, unrest:-0.12, corruption:-0.06, aggression:-0.08, text:'You consecrate a quiet pocket where the dungeon can breathe.' },
}

const out = {
  version: 1,
  generatedBy: 'scripts/build-dungeon-ecology.mjs',
  design: {
    weekMs: 604800000,
    minPopulation: 4,
    maxPopulationMultiplier: 1.6,
    pressureDecay: 0.82,
    unrestDecay: 0.92,
    corruptionDecay: 0.97,
    killPopulationDelta: -0.015,
    killPressure: 0.012,
    killUnrest: 0.004,
    overpopThreshold: 0.85,
    collapseThreshold: 0.25,
    highPressureThreshold: 0.55,
    lowPressureThreshold: 0.15,
    highUnrestThreshold: 0.55,
    lowUnrestThreshold: 0.2,
    highCorruptionThreshold: 0.5,
    insightDamageBonus: 0.05,
    insightGuardBonus: 0.03,
    maxHistory: 60,
  },
  regions,
  species,
  events,
  interventions,
}

writeFileSync(join(root, 'data/dungeon-ecology.json'), JSON.stringify(out, null, 2) + '\n')
console.log(`Wrote ${regions.length} regions, ${species.length} species, ${events.length} events.`)
