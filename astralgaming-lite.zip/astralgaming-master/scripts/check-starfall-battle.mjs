#!/usr/bin/env node
/**
 * check-starfall-battle.mjs — the Starfall champion package, fought through
 * the REAL turn funnels, not called in isolation.
 *
 * Every PvE command in this game runs through processStatusTurn() at the top
 * of the turn and applyIncomingDamage() on every struck blow; boss fights also
 * route through applyBossSpecial(EVENT.ENEMY_TAKE_DAMAGE, ...); duels run the
 * same tick against a throwaway snapshot of the opponent. This harness drives
 * exactly those functions with synthetic combatants, the same way
 * scripts/god-series-integration.mjs does it for the gods. What it proves:
 * the package actually fires inside a battle, in order, and settles — it does
 * not prove the chat rendering (that needs a live client).
 *
 * Run: node scripts/check-starfall-battle.mjs
 */
process.env.NODE_ENV = 'test'
import { readFileSync } from 'node:fs'
const {
  processStatusTurn, resolvePlayerHpZero,
} = await import('../lib/combat-handlers.js')
const { applyIncomingDamage } = await import('../lib/character-abilities.js')
const { applyBossSpecial, EVENT } = await import('../lib/boss-engine.js')
const { hasEffect, getEffectiveStat } = await import('../lib/effects.js')
const {
  armCathedral, armEdoTensei, castCage, haNeulReleaseDamage,
  starfallTurnTick, cathedralUp, heavensOrrery, astralWitchActive,
  CAGE_TURNS, WITCH_CAGE_TURNS,
} = await import('../lib/starfall-champion.js')
const { karrenPartyPulse } = await import('../plugins/party.js')

let pass = 0, fail = 0
const ok = (cond, label) => { if (cond) { pass++; console.log('  ✓', label) } else { fail++; console.log('  ✗ FAIL:', label) } }
const section = name => console.log(`\n=== ${name} ===`)

function mkPlayer(overrides = {}) {
  return {
    id: 'p1', name: 'Seong-ha', equippedCharacter: 'seong_ha',
    hp: 1000, maxHp: 1000, mp: 100, maxMp: 100, xp: 0, level: 60,
    stats: { str: 200, int: 200, def: 150, agi: 150, lck: 10 },
    inventory: ['ha_neul'], skills: ['burning_cathedral', 'edo_tensei_no_jutsu'],
    equipped: { weapon: 'ghostblade' },
    ownedCharacters: ['seong_ha'],
    characterSkins: { owned: {}, equipped: {} },
    summonedBeasts: [], pets: [],
    activeEffects: [],
    battleState: null,
    locationId: 'dungeon_ashfall',
    ...overrides,
  }
}
function mkEnemy(overrides = {}) {
  return {
    name: 'Test Fiend', emoji: '👹', hp: 900, maxHp: 900, attack: 250,
    stats: { str: 100, int: 100, def: 100, agi: 100 },
    activeEffects: [], ...overrides,
  }
}
const seat = (p, enemy, overrides = {}) => {
  p.battleState = { turn: 1, type: 'dungeon', enemy, combatStats: { damageTaken: 0, minHpFrac: 1 }, ...overrides }
  return p.battleState
}
const strike = (p, dmg) => applyIncomingDamage(p, dmg, null, true, {})
const fightTurn = (p, enemy, swing = 120) => {
  const before = enemy.hp
  const tick = processStatusTurn(p)
  const ledgerBite = Math.max(0, before - enemy.hp)
  if (enemy.hp > 1) enemy.hp = Math.max(1, enemy.hp - swing)
  const hit = strike(p, 600)
  return { tick, hit, ledgerBite, hpAfter: p.hp }
}

// ── A. Burning Cathedral end-to-end inside a dungeon fight ─────────────────
section('Burning Cathedral — six turns of a real fight')
{
  const p = mkPlayer()
  const enemy = mkEnemy()
  const bs = seat(p, enemy)
  armCathedral(p, bs)
  ok(cathedralUp(p), 'cathedral stands after the cast')

  // Real timeline, verified turn by turn: the nave stands turns 1-4 (its 4
  // ticks land on turns 1-4), Sanctuary saves her on turn 3, the Hymn fires
  // on turn 4 once the nave falls, and the second lethal is real.
  const turns = []
  for (let t = 1; t <= 6; t++) {
    bs.turn = t
    turns.push({ t, ...fightTurn(p, enemy, 120) })
  }
  const strike = t => turns.find(x => x.t === t).hit
  ok(hasEffect(p, 'cathedral') === false, 'the domain wears off on schedule (4 ticks, turns 1-4)')
  ok(/Sanctuary/.test(strike(3).message), 'Sanctuary clamped the fight-ending blow on turn 3')
  ok(/Ha-neul/.test(strike(1).message), 'every absorb is narrated — the tether is never silent')
  ok(turns.filter(t => t.t <= 3).every(t => t.hpAfter >= 1), 'the holder never fell while the nave stood (turns 1-3)')
  ok(turns.find(t => t.t === 3).hpAfter === 77, 'deterministic arc: 1000 → 610 → 220 → 77 under the domain')
  ok(bs.cathedral.dealtByEnemy > 0, `ledger tallied the struck blows (${bs.cathedral.dealtByEnemy} written)`)
  ok(turns.some(t => t.ledgerBite > 0), `ledger burned the foe on a later turn (${turns.map(t => t.ledgerBite).join('/')})`)
  ok(enemy.hp <= 1, 'ledger of flame floors the foe at 1 HP and can never land the kill')
  ok(/Hymn/.test(strike(4).message) && turns.find(t => t.t === 4).hpAfter === 1, 'once the domain falls, a lethal blow wakes the Hymn')
  ok(!/Hymn/.test(strike(5).message) && turns.find(t => t.t === 5).hpAfter === 0, 'a second lethal after the Hymn is spent is real')
}

// ── B. Sealed Doors — the cathedral closes the exit ────────────────────────
section('Sealed Doors — flee is refused while the nave stands')
{
  const p = mkPlayer()
  const enemy = mkEnemy()
  const bs = seat(p, enemy)
  armCathedral(p, bs)
  // plugins/flee.js and plugins/party.js both refuse on exactly this gate.
  ok(hasEffect(p, 'cathedral'), 'gate reads closed while the cathedral stands')
  bs.turn = 99
  processStatusTurn(p) // burn the remaining durations
  processStatusTurn(p)
  processStatusTurn(p)
  processStatusTurn(p)
  ok(!hasEffect(p, 'cathedral'), 'gate reads open once the domain expires')
}

// ── C. Cage of the World, called six moves into a fight ────────────────────
section('Cage of the World — castable any turn, including five moves in')
{
  const p = mkPlayer()
  const enemy = mkEnemy({ hp: 4000, maxHp: 4000 })
  const bs = seat(p, enemy)
  // Five ordinary turns first — the scenario the owner asked about. A weak
  // enemy keeps the fight alive to turn six, the way a real grind works.
  const gentleStrike = (pl) => applyIncomingDamage(pl, 100, null, true, {})
  for (let t = 1; t <= 5; t++) {
    bs.turn = t
    processStatusTurn(p)
    if (enemy.hp > 1) enemy.hp = Math.max(1, enemy.hp - 100)
    gentleStrike(p)
  }
  const hpAtCage = enemy.hp
  ok(hpAtCage < 4000 && p.hp > 0, `five moves in, the battle is still live (foe ${hpAtCage}, you ${p.hp})`)
  // The sixth move: the cage, not a blow.
  bs.turn = 6
  bs.cageUsed = true // the plugins/cage.js once-per-battle flag
  const cage = castCage(p, enemy)
  ok(hasEffect(enemy, 'cage'), 'the cage lands on turn six — there is no early-fight gate')
  ok(cage.lines.some(l => l.includes('6 turns')), 'base form locks for 6 turns')
  ok(cage.lines.every(l => !l.includes('Written Stars')), 'base form calls no Written Stars')
  ok(enemy.activeEffects.some(e => e.type === 'weaken'), 'prisoner DEF weakened 25%')
  // The prisoner cannot act: processStatusTurn must flag the hard control,
  // which is what every combat plugin reads to skip the enemy turn.
  const cagedTick = processStatusTurn(enemy)
  ok(cagedTick.incapacitated === true, 'prisoner is unable to act while caged')
  const second = mkEnemy({ hp: 500, maxHp: 4000, activeEffects: [] })
  castCage(p, second) // a fresh lock purely to count its full duration
  let cagedTurns = 0
  for (let i = 0; i < CAGE_TURNS + 1; i++) { if (hasEffect(second, 'cage')) { cagedTurns++; processStatusTurn(second) } }
  ok(cagedTurns === CAGE_TURNS, `the fresh cage held for exactly ${CAGE_TURNS} swings, then broke`)
  ok(!hasEffect(second, 'cage'), 'prisoner walks free when the last turn fades')
  ok(bs.cageUsed === true, 'the once-per-battle flag is set (plugins/cage.js enforces it)')
}

// ── D. Astral Witch & the Orrery — the cage calls Written Stars ────────────
section('Cage of the World — witch form and Heaven’s Orrery')
{
  const witch = mkPlayer({ characterSkins: { owned: { seong_ha_astral_witch: { level: 1 } }, equipped: { seong_ha: 'seong_ha_astral_witch' } } })
  const witchEnemy = mkEnemy({ hp: 30, maxHp: 900, activeEffects: [] })
  ok(astralWitchActive(witch), 'witch form reads active from the equipped skin')
  const witchCage = castCage(witch, witchEnemy)
  ok(witchCage.lines.some(l => l.includes(`${WITCH_CAGE_TURNS} turns`)), 'witch form locks for 10 turns')
  ok(witchCage.lines.some(l => l.includes('Written Stars')), 'writes Written Stars down alongside the cage')
  ok(witchEnemy.hp >= 1, `Written Stars floor the prisoner at 1 HP (hp=${witchEnemy.hp})`)
  ok(witchEnemy.activeEffects.some(e => e.type === 'weaken' && e.meta?.sourceId === 'constellation' || e.type === 'weaken'), 'a constellation is branded on the prisoner')

  const seraph = mkPlayer({ characterSkins: {
    owned: { seong_ha_astral_witch: { level: 1 }, seong_ha_starborn_seraph: { level: 1 } },
    equipped: { seong_ha: 'seong_ha_starborn_seraph' },
  } })
  ok(heavensOrrery(seraph), 'owning both forms lights the Orrery')
  const orreryEnemy = mkEnemy({ hp: 800, maxHp: 900, activeEffects: [] })
  const orreryCage = castCage(seraph, orreryEnemy)
  ok(orreryCage.lines.some(l => l.includes('Written Stars')), 'the Orrery calls Written Stars even in the Seraph’s face')
}

// ── E. Seong-ha’s Hymn and Edo Tensei — the fall that does not land ─────────
section('Hymn of the Shield & Edo Tensei — inside the damage funnel')
{
  const p = mkPlayer({ hp: 40, battleState: null })
  const bs = seat(p, mkEnemy(), { combatStats: { damageTaken: 0, minHpFrac: 1 } })
  bs.lastHitDamage = 500
  const hit = strike(p, 500)
  ok(/Hymn/.test(hit.message), 'the Hymn fires inside the real damage funnel')
  ok(p.hp === 1, `the blow leaves her at 1 HP (hp=${p.hp})`)
  ok(bs.seonghaHymn?.debt === 500, 'the full 500 is written down as Debt')

  const p2 = mkPlayer({ hp: 100, battleState: null })
  const bs2 = seat(p2, mkEnemy({ hp: 400 }), { combatStats: { damageTaken: 0, minHpFrac: 1 } })
  bs2.seonghaHymnUsed = true // spent earlier in the fight
  armEdoTensei(p2, bs2)
  bs2.lastHitDamage = 500
  const hit2 = strike(p2, 500)
  ok(/Edo Tensei/.test(hit2.message), 'Edo Tensei fires after the Hymn is spent')
  ok(p2.hp === 300, `the fallen are called back at 30% (hp=${p2.hp})`)
}

// ── F. resolvePlayerHpZero — the floor under every fight, incl. DoT deaths ──
section('Sanctuary & Edo Tensei rescue a 0-HP record (DoT backstop)')
{
  const fakeCtx = { reply: async () => {} }

  const sanctuaried = mkPlayer({ hp: 0 })
  const bsS = seat(sanctuaried, mkEnemy())
  armCathedral(sanctuaried, bsS)
  const r1 = await resolvePlayerHpZero(sanctuaried, fakeCtx, '', { boss: false })
  ok(r1.fallThrough === true && sanctuaried.hp === 1, 'Sanctuary catches the death and returns her to 1 HP')

  const edo = mkPlayer({ hp: 0 })
  const bsE = seat(edo, mkEnemy())
  armEdoTensei(edo, bsE)
  bsE.seonghaHymnUsed = true
  const r2 = await resolvePlayerHpZero(edo, fakeCtx, '', { boss: false })
  ok(r2.fallThrough === true && edo.hp === 300, 'Edo Tensei catches the death and returns her at 30%')
}

// ── G. Ha-neul — the tether, all six chains, in a real fight ───────────────
section('Ha-neul — absorb, chains, cleanse, head of light, expiry')
{
  const p = mkPlayer({ hp: 10000, maxHp: 10000 })
  p.battleState = { turn: 1, type: 'dungeon', enemy: mkEnemy({ hp: 100000, maxHp: 100000 }), combatStats: { damageTaken: 0, minHpFrac: 1 } }
  // Two struck blows through the real funnel: absorb accrues, the tether's
  // clock stays at zero (the enemy's turn never moves it).
  strike(p, 1000)
  strike(p, 1000)
  const hnFunnel = p.battleState.haneul
  ok(hnFunnel.absorbed === 700 && hnFunnel.weight === 700, `the funnel feeds the tether (${hnFunnel.absorbed} absorbed)`)
  ok(hnFunnel.turn === 0, 'the tether’s clock only runs on her turn, not the enemy’s')
  // A burn lands on the wielder — the fourth chain washes it away.
  const { addStatusEffect } = await import('../lib/effects.js')
  addStatusEffect(p, { type: 'burn', duration: 3, value: 50 })
  const { haNeulAbsorb } = await import('../lib/starfall-champion.js')
  haNeulAbsorb(p, 24000, p.battleState) // a mythic-sized soak, same code path the funnel calls
  const hn = p.battleState.haneul
  ok(hn.broken === 6, `all six chains broke (absorbed=${hn.absorbed}, broken=${hn.broken})`)
  ok((p.activeEffects ?? []).some(e => e.sourceId === 'haneul_chain_2' && e.type === 'shield'), 'the second chain wraps her in a vow-shield')
  ok(!(p.activeEffects ?? []).some(e => e.type === 'burn'), 'the fourth chain washed the burn off her')
  ok((p.activeEffects ?? []).some(e => e.sourceId === 'haneul_head_of_light' && e.type === 'damage_boost'), 'the sixth chain lit the head of light')
  ok((p.activeEffects ?? []).some(e => e.sourceId === 'haneul_head_of_light' && e.type === 'damage_reduction'), 'the head of light also wards her')
  processStatusTurn(p)
  ok(p.battleState.haneul.ended === true, 'the sixth chain ending the tether lands on her turn')
}

// ── H. .haneul release — the one kill the Starfall package may land ────────
section('Ha-neul release — 200%, and the only Starfall kill')
{
  const p = mkPlayer({ hp: 1000, maxHp: 1000 })
  const bs = seat(p, mkEnemy({ hp: 100 }))
  for (let i = 0; i < 3; i++) strike(p, 200)
  const rel = haNeulReleaseDamage(p, bs)
  ok(!!rel && rel.damage > 0, `release pays 200% of the stored weight (${rel?.damage})`)
  ok(p.battleState.haneul.ended === true, 'the tether is spent')
  ok(haNeulReleaseDamage(p, bs) === null, 'nothing is left to release')
}

// ── I. Duel path — the tick settles exactly once, never twice ───────────────
section('Duel tick — computed against a snapshot, applied once')
{
  const opponent = {
    name: 'Rival', hp: 800, maxHp: 1000,
    stats: { str: 200, int: 200, def: 100, agi: 400 },
    activeEffects: [{ type: 'strengthen', remaining: 3, value: 250, meta: null }],
  }
  const actorBs = {
    turn: 3, type: 'pvp', enemy: opponent,
    combatStats: { damageTaken: 0, minHpFrac: 1 },
  }
  const actor = mkPlayer({
    battleState: actorBs,
    characterSkins: { owned: { seong_ha_starborn_seraph: { level: 1 } }, equipped: { seong_ha: 'seong_ha_starborn_seraph' } },
  })
  armCathedral(actor, actorBs)
  actorBs.cathedral.dealtByEnemy = 300 // the ledger the reference fight tallied
  const before = JSON.stringify(opponent)
  const tick = starfallTurnTick(actor, actor.battleState, opponent, { applyToFoe: false })
  ok(tick.foeDamage === 300, `the clock reads exactly the ledger it was owed (got ${tick.foeDamage})`)
  ok(JSON.stringify(opponent) === before, 'the duel snapshot is never written through')
  ok(tick.foeEffects.some(e => e.sourceId === 'six_laws_weight'), 'the Seraph’s Weight is queued, not applied, in a duel')
  ok(tick.foeEffects.some(e => e.type === 'strip_buff'), 'the Bell strips nothing until the opponent’s write lands')
  // plugins/pvp.js — writeOpponent applies it as a single subtraction:
  const settled = Math.max(0, opponent.hp - tick.foeDamage)
  ok(settled === 500, 'the opponent pays 300 once (not twice)')
}

// ── J. Boss with Infinity — the spear does not ask for permission ──────────
section('Boss ENEMY_TAKE_DAMAGE — Infinity nullifies, soul-strike does not')
{
  const carrier = mkPlayer()
  const bossEnemy = { name: 'Gojo Satoru', hp: 50000, maxHp: 50000, stats: { def: 400, agi: 400 }, activeEffects: [] }
  carrier.battleState = { turn: 1, type: 'boss', enemy: bossEnemy, bossState: { _defId: 'gojo_satoru', infinityActive: true, turn: 1 }, combatStats: { damageTaken: 0, minHpFrac: 1 } }
  const pierced = applyBossSpecial(carrier, EVENT.ENEMY_TAKE_DAMAGE, { damage: 500, element: 'physical' })
  ok(pierced.damage === 500, `ghostblade restores the thrown blow through Infinity (got ${pierced.damage})`)

  const unarmed = mkPlayer({ equipped: { weapon: null } })
  unarmed.battleState = { turn: 1, type: 'boss', enemy: { ...bossEnemy, activeEffects: [] }, bossState: { _defId: 'gojo_satoru', infinityActive: true, turn: 1 }, combatStats: { damageTaken: 0, minHpFrac: 1 } }
  const refused = applyBossSpecial(unarmed, EVENT.ENEMY_TAKE_DAMAGE, { damage: 500, element: 'physical' })
  ok(refused.damage === 0, 'without the spear, Infinity keeps the blow')
}

// ── K. Karren’s party pulse — heals the most-wounded living member ─────────
section('Karren — the Archivist corrects the record (party)')
{
  const users = {
    'karren@x': { id: 'karren@x', name: 'Karren', equippedCharacter: 'karren', hp: 1000, maxHp: 1000, inBattle: true, stats: {}, activeEffects: [], skills: [], inventory: [], ownedCharacters: ['karren'] },
    'ally@x':   { id: 'ally@x',   name: 'Ally',    equippedCharacter: 'seong_ha', hp: 100, maxHp: 1000, inBattle: true, stats: {}, activeEffects: [], skills: [], inventory: [], ownedCharacters: ['seong_ha'] },
    'dead@x':   { id: 'dead@x',   name: 'Fallen',  equippedCharacter: 'karren',   hp: 0,   maxHp: 1000, inBattle: true, stats: {}, activeEffects: [], skills: [], inventory: [], ownedCharacters: ['karren'] },
  }
  const db = { data: { users } }
  const replies = []
  const ctx = { db, from: 'karren@x', reply: async m => { replies.push(m) } }
  const party = { members: ['karren@x', 'ally@x', 'dead@x'], battle: { enemy: { name: 'Test Fiend', hp: 500, maxHp: 900 }, charState: {} } }
  const healed = await karrenPartyPulse(ctx, party)
  ok(healed === true, 'the pulse fires on her turn')
  ok(users['ally@x'].hp === 220, `the most-wounded living member was corrected by 12% of her max HP (hp=${users['ally@x'].hp})`)
  ok(users['dead@x'].hp === 0, 'the dead are not patched back together')
  ok(replies.length === 1 && replies[0].includes('120'), 'the mend is narrated with the amount')
  // Everyone full: no mend, no message.
  users['ally@x'].hp = 1000
  users['karren@x'].hp = 1000
  const quiet = await karrenPartyPulse(ctx, party)
  ok(quiet === false && replies.length === 1, 'a full house is left in peace')
}

// ── L. Wiring — the places only a battle can prove ─────────────────────────
section('Wiring — the hooks the chat plugins rely on')
{
  const src = (f) => readFileSync(new URL(`../${f}`, import.meta.url), 'utf8')
  ok(/noteGhostbladeKill/.test(src('lib/combat-handlers.js')), 'handleVictory writes the Requiem Roster on every kill')
  ok(/cathedral/.test(src('plugins/flee.js')), 'plugins/flee.js refuses the door while the cathedral stands')
  ok(/cathedral/.test(src('plugins/party.js')), 'the party flee twin refuses the door too')
  ok(/cageUsed/.test(src('plugins/cage.js')), 'plugins/cage.js enforces the once-per-battle flag')
  ok(/karrenPartyPulse\(ctx, party\)/.test(src('plugins/party.js')), 'party victory paths call the Archivist’s pulse')
  ok(/from '\.\.\/lib\/starfall-champion\.js'/.test(src('plugins/cage.js')) && /from '\.\.\/lib\/starfall-champion\.js'/.test(src('plugins/haneul.js')), 'the .cage and .haneul commands load the champion package')
}

console.log(`\n${pass} passed, ${fail} failed`)
process.exit(fail ? 1 : 0)
