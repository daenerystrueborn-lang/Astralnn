/**
 * dreamlands-balance-check.mjs — does the realm hold up at every rank, not just
 * at the top?
 *
 * WHY. The 2026-10-07 retune (docs/top3-balance-report.md) raised the realm's
 * two anchors, added a bounded whale band (DREAMLAND_WHALE_BAND) and put the
 * four champions on it. Every one of those is a claim about a FIGHT, and a
 * claim about a fight is only checkable against the players who will actually
 * stand in it: the level-100 the realm is priced at, a level-130 climber, the
 * realm's own reference fight (Aragon, §6), and the three strongest accounts on
 * the server.
 *
 * For each of them this prints turns-to-clear and the share of max HP a hit
 * costs, through the shipped functions only. Read it before changing a number
 * in DREAMLAND_DIFFICULTY or DREAMLAND_WHALE_BAND.
 *
 *   node scripts/dreamlands-balance-check.mjs
 *
 * Read only. Prints tables; never fails a build.
 */
import { regularByLoc, getTotalStats, allItems } from '../lib/game-data.js'
import {
  pickDreamlandsMonster, dreamlandsRealmRatio, dreamlandsBandMultipliers,
  DREAMLAND_DIFFICULTY, DREAMLAND_WHALE_BAND, cumulativeFloor,
} from '../lib/dreamlands-core.js'
import { applyDefense, calcPlayerHitChance, calcMonsterHitChance, calcMonsterDamage } from '../lib/combat-engine.js'
import { getBossById } from '../bosses/index.js'
import { initBossFight } from '../lib/boss-engine.js'

// ── the ladder ─────────────────────────────────────────────────────────────
const CLASS_OF = { warrior: 'str', mage: 'int', rogue: 'agi' }

/** The best world gear a level can hold, as scripts/check-monster-power.mjs reads it. */
function bestWorldGear(level) {
  const wearable = allItems.filter(i => i.statBonuses && !i.starterPackExclusive
    && ['weapon', 'armor', 'accessory', 'offhand'].includes(i.type))
  const t = { str: 0, def: 0, maxHp: 0, int: 0, agi: 0 }
  for (const slot of ['weapon', 'armor', 'accessory', 'offhand']) {
    const avail = wearable.filter(i => i.type === slot && (i.levelRequirement ?? 1) <= level)
    if (!avail.length) continue
    const best = avail.reduce((a, b) =>
      ((b.statBonuses.str ?? 0) + (b.statBonuses.def ?? 0) + (b.statBonuses.maxHp ?? 0)) >
      ((a.statBonuses.str ?? 0) + (a.statBonuses.def ?? 0) + (a.statBonuses.maxHp ?? 0)) ? b : a)
    for (const k of Object.keys(t)) t[k] += best.statBonuses[k] ?? 0
  }
  return t
}

function climber({ label, level, classId = 'warrior', skillMult, lck = 150, stats: given = null }) {
  const base = getTotalStats(classId, 'human', level)
  const gear = given ? { str: 0, agi: 0, int: 0, def: 0, maxHp: 0 } : bestWorldGear(level)
  const stats = given
    ? { str: 0, agi: 0, lck, ...given }
    : { str: base.str + gear.str, agi: base.agi + gear.agi, int: base.int + gear.int,
        def: base.def + gear.def, lck }
  const key = CLASS_OF[classId]
  const crit = Math.min(0.95, 0.05 + lck * 0.002)
  const hp = given ? given.maxHp : base.maxHp + gear.maxHp
  return {
    label, level, classId, stats,
    hp, maxHp: hp,
    primary: stats[key],
    skillMult,
    rawHit: stats[key] * skillMult * (1 + crit * 0.5),
    defMitigation: Math.min(0.97, stats.def / (stats.def + 500)),
    equippedSkills: ['synthetic_best_skill'],
    hitCapPct: 1, incomingCut: 0, weaponMult: 1, modDamage: 1,
  }
}

const LADDER = [
  // The realm's own level-100 benchmark (test/dreamlands.test.mjs's BENCH_100:
  // a fresh unwarded entrant, 1,500 HP / DEF 300 / INT 900) given the skill a
  // real level 100 carries.
  climber({ label: 'L100 fresh', level: 100, classId: 'mage', skillMult: 2.6, lck: 150, stats: { int: 900, def: 300, maxHp: 1500 } }),
  // Halfway between the benchmark and the reference: the player the second and
  // third places actually ask for.
  climber({ label: 'L130 climber', level: 130, classId: 'mage', skillMult: 2.9, lck: 180, stats: { int: 1350, def: 420, maxHp: 2300 } }),
  // The §6 reference fight itself, hand authored in the test file.
  climber({ label: 'Aragon (ref)', level: 200, classId: 'mage', skillMult: 3.19, lck: 374,
    stats: { int: 2133, def: 750, maxHp: 2815 } }),
  // The three strongest accounts on the server, verbatim from the 2026-10-06
  // profile dump, with the two combat items the dump proves they carry.
  {
    label: 'Yochan', level: 200, classId: 'samurai',
    stats: { str: 2431, agi: 690, int: 505, def: 1252, lck: 455, maxHp: 4503, maxMp: 1383 },
    hp: 4503, maxHp: 4503, primary: 2431, skillMult: 3.13,
    defMitigation: 1252 / (1252 + 500), hitCapPct: 0.35, incomingCut: 0.20, lifesteal: 0.15,
    weaponMult: 1.30, modDamage: 1.05, equippedSkills: ['synthetic_best_skill'],
  },
  {
    label: 'Jester', level: 200, classId: 'mage',
    stats: { str: 556, agi: 441, int: 2428, def: 1576, lck: 186, maxHp: 5202, maxMp: 1333 },
    hp: 5202, maxHp: 5202, primary: 2428, skillMult: 2.05,
    defMitigation: 1576 / (1576 + 500), hitCapPct: 0.35, incomingCut: 0.20, lifesteal: 0.15,
    weaponMult: 1.75, modDamage: 1.05, defIgnore: 0.30, equippedSkills: ['synthetic_best_skill'],
  },
  {
    label: 'void reaper', level: 173, classId: 'rogue',
    stats: { str: 2069, agi: 976, int: 347, def: 1423, lck: 234, maxHp: 6924, maxMp: 920 },
    hp: 6924, maxHp: 6924, primary: 976, skillMult: 3.30,
    defMitigation: 1423 / (1423 + 500), hitCapPct: 1, incomingCut: 0,
    weaponMult: 1.75, modDamage: 1.05, defIgnore: 0.30, equippedSkills: ['synthetic_best_skill'],
  },
]

for (const p of LADDER) {
  p.crit = Math.min(0.95, 0.05 + (p.stats.lck ?? 0) * 0.002)
  if (p.rawHit == null) {
    p.rawHit = p.primary * p.skillMult * (1 + p.crit * 0.5)
  }
}

const SKILL_TABLE = [{ id: 'synthetic_best_skill', effects: [{ type: 'attack', stat: 'str', multiplier: 3 }] }]
/** The band for this player, with no synthetic skill table poisoning the ratio. */
function bandRatio(p) {
  const fake = { ...p, equippedSkills: [`__${p.label}`] }
  const table = [{ id: `__${p.label}`, effects: [{ type: 'attack', stat: CLASS_OF[p.classId], multiplier: p.skillMult }] }]
  return dreamlandsRealmRatio(fake, table, (p.weaponMult ?? 1) * (p.modDamage ?? 1))
}

function vsEnemy(p, enemy) {
  const hp = enemy.maxHp ?? enemy.hp
  const def = (enemy.def ?? 0) * (1 - (p.defIgnore ?? 0))
  const raw = p.rawHit * (p.weaponMult ?? 1) * (p.modDamage ?? 1)
  const landed = applyDefense(Math.round(raw), def)
  const hitChance = calcPlayerHitChance(p, enemy)
  const monsterHit = calcMonsterHitChance(enemy, p)
  // calcMonsterDamage is the shipped player-side curve (variance 0.8-1.2),
  // then the kit: Dread's cut, then the Robe's per-hit cap.
  const base = calcMonsterDamage(enemy.atk ?? 0, p.stats.def, false)
  let taken = base * (1 - (p.incomingCut ?? 0))
  taken = Math.max(1, Math.min(taken, p.maxHp * (p.hitCapPct ?? 1)))
  const dealtPerTurn = landed
  const heal = (p.lifesteal ?? 0) * dealtPerTurn
  const net = taken * monsterHit - heal
  return {
    hp, def: enemy.def, atk: enemy.atk,
    turns: hp / landed / hitChance,
    taken, share: taken / p.maxHp,
    net,
    dieNet: net > 0 ? p.maxHp / net : Infinity,
  }
}

const f = (x, n = 1) => (Number.isFinite(x) ? Number(x).toFixed(n) : 'never')
const pct = (x) => `${(x * 100).toFixed(0)}%`
const pad = (s, n) => String(s).padStart(n)

console.log('══ the ladder ══════════════════════════════════════════════════════════')
for (const p of LADDER) {
  const r = bandRatio(p)
  const b = dreamlandsBandMultipliers(r)
  console.log(`  ${p.label.padEnd(13)} L${String(p.level).padEnd(4)} primary ${pad(p.primary, 5)}  its own DEF cuts ${pad(pct(p.defMitigation), 4)}` +
    `  best-skill raw hit ${pad(Math.round(p.rawHit * (p.weaponMult ?? 1) * (p.modDamage ?? 1)), 6)}` +
    `  band ratio ${pad(f(r, 2), 5)} → HP x${f(b.hp, 2)} ATK x${f(b.atk, 2)} DEF x${f(b.def, 2)}`)
}
console.log(`  reference hit (Aragon, best mage skill, crit folded) = ${Math.round(9519)}  ` +
  `band caps: HP x${DREAMLAND_WHALE_BAND.maxHpMult} ATK x${DREAMLAND_WHALE_BAND.maxAtkMult} DEF x${DREAMLAND_WHALE_BAND.maxDefMult}`)

console.log('\n══ regular nightmares (median of the place\'s pool at that floor) ══════')
const PLACES = [
  ['lantern_fields', 1], ['lantern_fields', 125],
  ['sleepwood', 125], ['drowned_chapel', 125], ['distorted_court', 125],
]
function medianPool(place, floor, p) {
  const enemies = []
  for (let i = 0; i < 200; i++) {
    const e = pickDreamlandsMonster(place, floor, p, regularByLoc, {
      skills: [], ratio: bandRatio(p),
    })
    if (e && e.tier === 'regular') enemies.push(e)
  }
  if (!enemies.length) return null
  const med = (k) => { const s = enemies.map(e => e[k]).sort((a, b) => a - b); return s[Math.floor(s.length / 2)] }
  return { hp: med('hp'), def: med('def'), atk: med('atk') }
}
for (const [place, floor] of PLACES) {
  const cells = LADDER.map(p => {
    const e = medianPool(place, floor, p)
    if (!e) return `${p.label}: n/a`
    const x = vsEnemy(p, e)
    return `${p.label.split(' ')[0]} ${f(x.turns)}t/${pct(x.share)}`
  })
  console.log(`  ${`${place}/${floor}`.padEnd(22)} cum ${pad(cumulativeFloor(place, floor), 3)}  ${cells.join('  |  ')}`)
}
console.log('  (turns to clear / share of max HP one of its hits costs)')

console.log('\n══ the four champions ══════════════════════════════════════════════════')
for (const [id, name] of [['lantern_child', 'Lantern Child'], ['sleepwood_mother', 'Sleepwood Mother'],
  ['drowned_choir', 'Drowned Choir'], ['the_distorted_one', 'The Distorted One']]) {
  const def = getBossById(id)
  const init = initBossFight({ id: 'seed', level: 200, classId: 'mage', stats: {}, activeEffects: [], battleState: {} }, id, 125)
  const base = init.ok ? init.enemy : def
  const seedHp = base.maxHp ?? base.hp
  console.log(`  ${name}  authored HP ${seedHp} DEF ${base.def} ATK ${base.atk}`)
  for (const p of LADDER) {
    const b = dreamlandsBandMultipliers(bandRatio(p))
    const e = {
      ...base, hp: Math.round(seedHp * b.hp), maxHp: Math.round(seedHp * b.hp),
      def: Math.round(base.def * b.def), atk: Math.round(base.atk * b.atk),
    }
    const x = vsEnemy(p, e)
    console.log(`    ${p.label.padEnd(13)} HP ${pad(Math.round(e.maxHp), 7)} DEF ${pad(e.def, 5)} ATK ${pad(e.atk, 5)}` +
      ` → ${pad(f(x.turns), 6)} turns, hit ${pad(Math.round(x.taken), 5)} (${pad(pct(x.share), 4)} of HP)` +
      (x.net > 0 ? `, net -${Math.round(x.net)}/turn → dies in ${f(x.dieNet)}` : `, net +${Math.round(-x.net)}/turn`))
  }
}

console.log('\n══ the guardian wall (fifty in a row, no healing between) ══════════════')
const { buildBodyGuardian } = await import('../lib/dreamlands-core.js')
for (const p of LADDER) {
  const rows = Array.from({ length: 40 }, () => buildBodyGuardian()).map(e => vsEnemy(p, e))
  const med = (k) => { const s = rows.map(r => r[k]).sort((a, b) => a - b); return s[Math.floor(s.length / 2)] }
  console.log(`  ${p.label.padEnd(13)} guardian HP ${pad(Math.round(med('hp')), 6)} DEF ${pad(Math.round(med('def')), 5)}` +
    ` ATK ${pad(Math.round(med('atk')), 5)} → ${f(med('turns'))} turns each, hit ${Math.round(med('taken'))}` +
    ` (${pct(med('share'))} of HP), all fifty cost ${Math.round(med('taken') * 50)} HP of ${p.maxHp}`)
}
