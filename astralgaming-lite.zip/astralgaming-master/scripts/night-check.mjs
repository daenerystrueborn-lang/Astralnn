/**
 * Night mode checks: the switch, its durability, the notice throttle, and that
 * the gate is actually wired into the handler chokepoint and all three sweeps.
 * Run: node scripts/night-check.mjs
 */
import { readFileSync, existsSync, writeFileSync, mkdtempSync, rmSync } from 'fs'
import { execFileSync } from 'child_process'
import { tmpdir } from 'os'
import { join } from 'path'

// Never remove or rewrite the bot's real state. Each run gets a private store,
// and fresh processes below use that same directory to simulate a real restart.
const stateDir = mkdtempSync(join(tmpdir(), 'astral-night-check-'))
process.env.RUNTIME_DATA_DIR = stateDir
const STATE = join(stateDir, 'night-mode.json')
const HANDLER = readFileSync(new URL('../handler.js', import.meta.url), 'utf8')
// The battle gate was lifted out of handler.js into the platform layer in the
// pipeline refactor; the set itself lives here now.
const GATES = readFileSync(new URL('../lib/platform/gates.js', import.meta.url), 'utf8')
const MAIN = readFileSync(new URL('../main.js', import.meta.url), 'utf8')
const SWEEPS = readFileSync(new URL('../lib/background-sweeps.js', import.meta.url), 'utf8')
const JOBS = readFileSync(new URL('../lib/background-jobs.js', import.meta.url), 'utf8')
const TG_SPAWNS = readFileSync(new URL('../lib/telegram-spawns.js', import.meta.url), 'utf8')

const {
  isNightMode, getNightState, setNightMode, shouldNotifyNight, nightNotice,
  isNightModeAllowed, LOCKOUT_EXEMPT_COMMANDS, SPAWN_CLAIM_COMMANDS,
} = await import('../lib/night-mode.js')
const { isNightCommandAllowed } = await import('../lib/sect-access.js')

function freshNightMode() {
  const url = new URL('../lib/night-mode.js', import.meta.url).href
  const script = `const m = await import(${JSON.stringify(url)}); process.stdout.write(String(m.isNightMode()))`
  return execFileSync(process.execPath, ['--input-type=module', '-e', script], {
    env: process.env, encoding: 'utf8',
  }).trim() === 'true'
}

let pass = 0, fail = 0
const t = (name, cond, extra = '') => {
  if (cond) { pass++; console.log('  PASS  ' + name) }
  else { fail++; console.log('  FAIL  ' + name + (extra ? '  <- ' + extra : '')) }
}

console.log('\n=== 1. Toggle ===')
t('defaults to OFF (fails open)', isNightMode() === false)
{
  const r = setNightMode(true, 'owner@s.whatsapp.net')
  t('turning on reports changed', r.changed === true)
  t('isNightMode true', isNightMode() === true)
  t('records who turned it on', getNightState().by === 'owner@s.whatsapp.net')
  t('records when', typeof getNightState().since === 'number')

  const again = setNightMode(true, 'owner@s.whatsapp.net')
  t('turning on twice reports NOT changed', again.changed === false)

  const off = setNightMode(false, 'owner@s.whatsapp.net')
  t('turning off reports changed', off.changed === true)
  t('isNightMode false', isNightMode() === false)
  t('since cleared on off', getNightState().since === null)
  t('turning off twice reports NOT changed', setNightMode(false).changed === false)
}

console.log('\n=== 2. Durability across a restart ===')
{
  setNightMode(true, 'mod@s.whatsapp.net')
  t('state file written', existsSync(STATE))
  const onDisk = JSON.parse(readFileSync(STATE, 'utf8'))
  t('file says on', onDisk.on === true)

  // A fresh process gets a fresh state-store registry, as on a real restart.
  t('survives a restart as ON', freshNightMode() === true)

  setNightMode(false)
  t('survives a restart as OFF', freshNightMode() === false)
}

console.log('\n=== 3. Corrupt state file fails OPEN (never bricks the bot) ===')
{
  writeFileSync(STATE, '{ this is not json', 'utf8')
  t('corrupt file -> night mode OFF', freshNightMode() === false)
  t('no throw on import', true)
  // Restore a valid store; state is already off so setNightMode(false) alone
  // would not write over the deliberately corrupted file.
  writeFileSync(STATE, JSON.stringify({ on: false, since: null, by: null }), 'utf8')
}

console.log('\n=== 4. Notice throttle ===')
{
  const jid = 'player1@s.whatsapp.net'
  const now = 1_700_000_000_000
  t('first blocked command notifies', shouldNotifyNight(jid, now) === true)
  t('immediate repeat is silent', shouldNotifyNight(jid, now + 1000) === false)
  t('still silent 29 min later', shouldNotifyNight(jid, now + 29 * 60000) === false)
  t('notifies again after 30 min', shouldNotifyNight(jid, now + 31 * 60000) === true)
  t('a different player is notified independently',
    shouldNotifyNight('player2@s.whatsapp.net', now + 1000) === true)

  // Toggling clears the throttle so the first person after a change is told.
  shouldNotifyNight('player3@s.whatsapp.net', now)
  setNightMode(true, 'owner@s.whatsapp.net')
  t('toggle resets the throttle', shouldNotifyNight('player3@s.whatsapp.net', now + 1000) === true)
  setNightMode(false)
}

console.log('\n=== 5. The notice text ===')
{
  const n = nightNotice('.')
  t('says it is night', /night/i.test(n))
  t('tells them to sleep/rest', /sleep|rest/i.test(n))
  t('says back tomorrow', /tomorrow/i.test(n))
  t('reassures nothing is lost', /saved/i.test(n))
  t('leaves no unreplaced placeholder', !/\{prefix\}/.test(n))
}

console.log('\n=== 6. Wired into handler.js ===')
t('imports the gate', /import \{[^}]*isNightMode[^}]*\} from '\.\/lib\/night-mode\.js'/.test(HANDLER))
t('imports isMod', /import \{ isMod \} from '\.\/lib\/mod-repo\.js'/.test(HANDLER))
t('gate checks night mode', /if \(isNightMode\(\)\)/.test(HANDLER))
t('owner is recognized as staff', /isOwnerJid\(from\) \|\| isMod\(db, from\)/.test(HANDLER))
t('staff controls are exempt', isNightCommandAllowed({ cmd: 'night', staff: true }))
t('gate returns (blocks the command)', /shouldNotifyNight\(from\)[\s\S]{0,300}?return/.test(HANDLER))
t('gate sits before the ban lockout',
  HANDLER.indexOf('isNightMode()') < HANDLER.indexOf('const ban = getBan(db, from)'))
t('gate sits after the command is parsed',
  HANDLER.indexOf('const cmd = rawCmd.toLowerCase()') < HANDLER.indexOf('isNightMode()'))

// Ban appeals must survive the night, same as they survive the ban/jail
// lockouts — otherwise someone banned at 2am has no route out until morning.
// So must spawn claims: night mode pauses the spawn SWEEPS but never clears a
// spawn that is already live, so without this a card or series that appeared
// just before `.night on` sits there with its code posted and nobody able to
// spend it until morning. See SPAWN_CLAIM_COMMANDS in lib/night-mode.js.
{
  const gate = HANDLER.slice(HANDLER.indexOf('if (isNightMode())'), HANDLER.indexOf('── Ban lockout'))
  t('the night gate routes exemptions through the shared policy',
    /isNightCommandAllowed\(/.test(gate))
  t('isNightModeAllowed keeps ban appeals reachable',
    ['unban', 'unban-me', 'unbanme', 'appeal'].every(isNightModeAllowed))
  t('isNightModeAllowed keeps spawn claims reachable',
    ['claim', 'collect', 'grab'].every(cmd => SPAWN_CLAIM_COMMANDS.has(cmd) && isNightModeAllowed(cmd)))
  t('exemption is checked BEFORE the notice is sent',
    gate.indexOf('isNightCommandAllowed') < gate.indexOf('shouldNotifyNight'))
  // Widening the night gate must not widen the ban/jail lockouts with it.
  const banGate = HANDLER.slice(HANDLER.indexOf('── Ban lockout'), HANDLER.indexOf('── Jail lockout'))
  t("'claim' was NOT added to the every-lockout exemption set",
    !LOCKOUT_EXEMPT_COMMANDS.has('claim') && !/isNightModeAllowed/.test(banGate))
}

console.log('\n=== 6b. In-battle commands are reachable mid-battle ===')
{
  const block = GATES.match(/BATTLE_ALLOWED_COMMANDS = new Set\(\[([\s\S]*?)\n\]\)/)[1]
  const allowed = new Set([...block.matchAll(/^\s*'.*$/gm)]
    .flatMap(l => [...l[0].matchAll(/'([^']+)'/g)].map(m => m[1])))
  // Every command whose plugin hard-requires being in battle must clear the
  // gate, or it is unreachable in the only state it works in.
  for (const id of [
    'attack', 'skill', 'defend', 'flee',            // core
    'use', 'consume', 'drink',                      // potions / consumables in dungeon & boss fights
    'inventory', 'inv', 'bag',                      // checking bag / inventory mid-battle
    'cinderverdict', 'wildcard', 'circe',           // Wither, Circe
    'ultimate',                                     // Nisha's dragon
    'domain-expansion', 'domain', 'chimera',        // Megumi
    'mahoraga',                                     // Megumi (status card)
    'finalform', 'ff', 'transform',                // Mei
    'greed', 'tithe', 'wisdom',                     // Echidna
    'willow', 'advise', 'advisor',                  // Willow
    'pvp', 'duel', 'dparty', 'pattack',             // PvP + party
    'cb', 'unstuck',                                // escape hatch
  ]) t("'" + id + "' clears the battle gate", allowed.has(id))
}

console.log('\n=== 7. Wired into all three background spawn sweeps ===')
for (const fn of ['runCardSpawnSweep', 'runSeriesSpawnSweep', 'runPokemonSpawnSweep']) {
  const start = SWEEPS.indexOf('export async function ' + fn)
  const body = SWEEPS.slice(start, start + 900)
  t(fn + ' gated', start !== -1 && /if \(isNightMode\(\)\) return/.test(body))
  t(fn + ' gated BEFORE it picks a socket',
    body.indexOf('isNightMode()') < body.indexOf('instances.map'))
}
t('background-sweeps.js imports the gate',
  /import \{ isNightMode \} from '\.\/night-mode\.js'/.test(SWEEPS))
t('exactly 3 sweeps gated', (SWEEPS.match(/if \(isNightMode\(\)\) return/g) ?? []).length === 3)
t('background-jobs.js owns the night-mode wake listener', /onNightModeOff\(/.test(JOBS))

console.log('\n=== 7b. The Telegram card sweep honours night mode too (it lives in its own file) ===')
t('telegram sweep gated', /if \(isNightMode\(\)\) return/.test(TG_SPAWNS))
t('telegram sweep gated before any send',
  TG_SPAWNS.indexOf('isNightMode()') < TG_SPAWNS.indexOf('await deliver('))
t('telegram sweep is the 4th gateway, not a 4th gated sweep in background-sweeps.js',
  (SWEEPS.match(/if \(isNightMode\(\)\) return/g) ?? []).length === 3)
t('main.js delegates recurring jobs', /startBackgroundJobs\(db, instances/.test(MAIN))

// Remove only this run's private state, never the bot's persisted setting.
rmSync(stateDir, { recursive: true, force: true })

console.log('\n' + '='.repeat(52))
console.log('  ' + pass + ' passed, ' + fail + ' failed')
console.log('='.repeat(52))
process.exit(fail ? 1 : 0)
