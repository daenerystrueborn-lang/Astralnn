#!/usr/bin/env node
/**
 * Builds data/combat-doctrines.json from the live character/weapon catalogs.
 *
 * The output is committed so runtime never regenerates balance data. Run this
 * only when the catalogs change or when tuning the doctrine tables below.
 * Every character and every weapon receives an explicit profile; the audit in
 * test/combat-doctrines.test.mjs fails if a new catalog entry is left behind.
 */
import { readFileSync, writeFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')
const read = p => JSON.parse(readFileSync(join(root, p), 'utf8'))
const characters = read('data/characters.json')
const weapons = [
  ...read('data/weapons.json'),
  ...read('data/named-weapons.json'),
  ...read('data/boss-gear.json'),
]

const ROLES = {
  vanguard: {
    label: 'Vanguard', emoji: '🛡️',
    tags: ['frontline', 'shield', 'guard'],
    outgoing: { dungeon: 1.03, boss: 1.04, swarm: 1.03, pvp: 1.015, party: 1.03, league: 1.01 },
    incoming: { dungeon: 0.97, boss: 0.97, swarm: 0.97, pvp: 0.985, party: 0.97, league: 0.99 },
    meter: { attack: 12, skill: 13, defend: 16, move: 9, dodge: 11, taken: 7, ability: 18 },
    form: { outgoing: 1.16, incoming: 0.88, pvpOutgoing: 1.08, pvpIncoming: 0.94, duration: 3, guardPct: 0.10 },
    strongAgainst: ['burst', 'swarm', 'beast'], weakAgainst: ['mana_burn', 'anti_heal'],
  },
  striker: {
    label: 'Striker', emoji: '⚔️',
    tags: ['burst', 'physical', 'duelist'],
    outgoing: { dungeon: 1.05, boss: 1.04, swarm: 1.04, pvp: 1.025, party: 1.04, league: 1.015 },
    incoming: { dungeon: 0.99, boss: 0.99, swarm: 0.99, pvp: 0.995, party: 0.99, league: 1 },
    meter: { attack: 15, skill: 14, defend: 8, move: 12, dodge: 12, taken: 5, ability: 18 },
    form: { outgoing: 1.22, incoming: 0.93, pvpOutgoing: 1.11, pvpIncoming: 0.97, duration: 3, critBonus: 0.08 },
    strongAgainst: ['evasion', 'healer', 'caster'], weakAgainst: ['armored', 'reflect'],
  },
  arcanist: {
    label: 'Arcanist', emoji: '🔮',
    tags: ['caster', 'mana', 'elemental'],
    outgoing: { dungeon: 1.05, boss: 1.05, swarm: 1.06, pvp: 1.025, party: 1.05, league: 1.015 },
    incoming: { dungeon: 0.98, boss: 0.98, swarm: 0.97, pvp: 0.99, party: 0.98, league: 0.995 },
    meter: { attack: 9, skill: 18, defend: 12, move: 8, dodge: 9, taken: 5, ability: 20 },
    form: { outgoing: 1.20, incoming: 0.92, pvpOutgoing: 1.10, pvpIncoming: 0.96, duration: 3, mpRestorePct: 0.12 },
    strongAgainst: ['armored', 'construct', 'swarm'], weakAgainst: ['mana_burn', 'silence'],
  },
  guardian: {
    label: 'Guardian', emoji: '🏰',
    tags: ['shield', 'healer', 'guard'],
    outgoing: { dungeon: 1.02, boss: 1.03, swarm: 1.02, pvp: 1.01, party: 1.04, league: 1.005 },
    incoming: { dungeon: 0.95, boss: 0.96, swarm: 0.95, pvp: 0.975, party: 0.95, league: 0.985 },
    meter: { attack: 10, skill: 12, defend: 18, move: 8, dodge: 10, taken: 8, ability: 16 },
    form: { outgoing: 1.12, incoming: 0.84, pvpOutgoing: 1.06, pvpIncoming: 0.92, duration: 4, healPct: 0.10 },
    strongAgainst: ['burst', 'poison', 'undead'], weakAgainst: ['anti_heal', 'mana_burn'],
  },
  trickster: {
    label: 'Trickster', emoji: '🎭',
    tags: ['evasion', 'control', 'tempo'],
    outgoing: { dungeon: 1.04, boss: 1.03, swarm: 1.05, pvp: 1.02, party: 1.03, league: 1.01 },
    incoming: { dungeon: 0.97, boss: 0.98, swarm: 0.96, pvp: 0.985, party: 0.98, league: 0.99 },
    meter: { attack: 12, skill: 14, defend: 10, move: 16, dodge: 16, taken: 5, ability: 18 },
    form: { outgoing: 1.17, incoming: 0.90, pvpOutgoing: 1.09, pvpIncoming: 0.95, duration: 3, dodgeBonus: 0.08 },
    strongAgainst: ['burst', 'armored', 'boss'], weakAgainst: ['pursuit', 'silence'],
  },
  sovereign: {
    label: 'Sovereign', emoji: '👑',
    tags: ['command', 'burst', 'control'],
    outgoing: { dungeon: 1.045, boss: 1.05, swarm: 1.045, pvp: 1.022, party: 1.05, league: 1.012 },
    incoming: { dungeon: 0.975, boss: 0.975, swarm: 0.975, pvp: 0.988, party: 0.975, league: 0.992 },
    meter: { attack: 13, skill: 15, defend: 12, move: 10, dodge: 11, taken: 6, ability: 20 },
    form: { outgoing: 1.19, incoming: 0.89, pvpOutgoing: 1.10, pvpIncoming: 0.95, duration: 3, meterRefund: 20 },
    strongAgainst: ['swarm', 'healer', 'construct'], weakAgainst: ['anti_heal', 'reflect'],
  },
  reaper: {
    label: 'Reaper', emoji: '☠️',
    tags: ['execute', 'bleed', 'dark'],
    outgoing: { dungeon: 1.055, boss: 1.045, swarm: 1.05, pvp: 1.025, party: 1.045, league: 1.012 },
    incoming: { dungeon: 0.99, boss: 0.99, swarm: 0.99, pvp: 0.995, party: 0.99, league: 1 },
    meter: { attack: 15, skill: 15, defend: 7, move: 11, dodge: 11, taken: 6, ability: 19 },
    form: { outgoing: 1.23, incoming: 0.94, pvpOutgoing: 1.11, pvpIncoming: 0.975, duration: 3, executeBonus: 0.10 },
    strongAgainst: ['healer', 'undead', 'low_hp'], weakAgainst: ['shield', 'reflect'],
  },
  support: {
    label: 'Support', emoji: '✨',
    tags: ['healer', 'cleanse', 'tempo'],
    outgoing: { dungeon: 1.025, boss: 1.03, swarm: 1.03, pvp: 1.012, party: 1.05, league: 1.006 },
    incoming: { dungeon: 0.965, boss: 0.97, swarm: 0.965, pvp: 0.982, party: 0.96, league: 0.99 },
    meter: { attack: 9, skill: 14, defend: 16, move: 10, dodge: 12, taken: 7, ability: 17 },
    form: { outgoing: 1.13, incoming: 0.87, pvpOutgoing: 1.07, pvpIncoming: 0.94, duration: 4, healPct: 0.12 },
    strongAgainst: ['poison', 'undead', 'swarm'], weakAgainst: ['anti_heal', 'silence'],
  },
  phantom: {
    label: 'Phantom', emoji: '🌫️',
    tags: ['evasion', 'shadow', 'tempo'],
    outgoing: { dungeon: 1.045, boss: 1.035, swarm: 1.055, pvp: 1.022, party: 1.035, league: 1.011 },
    incoming: { dungeon: 0.965, boss: 0.975, swarm: 0.955, pvp: 0.984, party: 0.975, league: 0.991 },
    meter: { attack: 13, skill: 14, defend: 9, move: 17, dodge: 17, taken: 5, ability: 18 },
    form: { outgoing: 1.18, incoming: 0.89, pvpOutgoing: 1.09, pvpIncoming: 0.95, duration: 3, dodgeBonus: 0.10 },
    strongAgainst: ['burst', 'caster', 'boss'], weakAgainst: ['pursuit', 'mana_burn'],
  },
  berserker: {
    label: 'Berserker', emoji: '🔥',
    tags: ['burst', 'rage', 'physical'],
    outgoing: { dungeon: 1.065, boss: 1.055, swarm: 1.055, pvp: 1.03, party: 1.05, league: 1.015 },
    incoming: { dungeon: 1.015, boss: 1.01, swarm: 1.015, pvp: 1.008, party: 1.01, league: 1.004 },
    meter: { attack: 17, skill: 15, defend: 6, move: 10, dodge: 9, taken: 9, ability: 19 },
    form: { outgoing: 1.26, incoming: 0.96, pvpOutgoing: 1.13, pvpIncoming: 0.985, duration: 3, rageBonus: 0.12 },
    strongAgainst: ['shield', 'construct', 'low_hp'], weakAgainst: ['reflect', 'anti_heal'],
  },
}

// Explicit role / movement / form identity for every current character. The
// unique ability in character-abilities.js remains authoritative; doctrine is
// the cross-mode chassis that makes the whole roster participate.
const CHARACTER_OVERRIDES = {
  mei:              { role: 'vanguard', movement: 'bulwark', formName: 'Prayer of the Last Wall', tags: ['guard', 'healer'] },
  urahara:          { role: 'trickster', movement: 'feint', formName: 'Reshape the Battlefield', tags: ['bleed', 'control'] },
  wither:           { role: 'reaper', movement: 'executioner', formName: 'Cinder Sovereignty', tags: ['execute', 'fire'] },
  willow:           { role: 'support', movement: 'advisor', formName: 'Perfect Counsel', tags: ['insight', 'tempo'] },
  miyashi:          { role: 'arcanist', movement: 'frostlock', formName: 'Absolute Zero Domain', tags: ['freeze', 'control'] },
  nisha:            { role: 'phantom', movement: 'serpent', formName: 'Absolute One Ascension', tags: ['drain', 'evasion'] },
  yoriichi:         { role: 'striker', movement: 'sunstep', formName: 'Dance of the Fire God', tags: ['burst', 'cat_form'] },
  monica:           { role: 'support', movement: 'pathfinder', formName: 'Beyond the Astral Gate', tags: ['travel', 'insight'] },
  tyla_alya:        { role: 'guardian', movement: 'twinshift', formName: 'Twin Bond Convergence', tags: ['shield', 'debuff'] },
  anastasia:        { role: 'trickster', movement: 'rewind', formName: 'Demon Lord Rewind', tags: ['time', 'control'] },
  circe:            { role: 'trickster', movement: 'wildcard', formName: 'Court of Wild Cards', tags: ['random', 'burst'] },
  megumi:           { role: 'arcanist', movement: 'shadow', formName: 'Chimera Shadow Garden', tags: ['shadow', 'summon'] },
  xiao:             { role: 'phantom', movement: 'thief', formName: 'Stolen Heaven', tags: ['copy', 'evasion'] },
  minna:            { role: 'trickster', movement: 'exchange', formName: 'Hollow Exchange Ascendant', tags: ['swap', 'control'] },
  shunya:           { role: 'guardian', movement: 'void', formName: 'Empty Vessel Perfected', tags: ['cleanse', 'immune'] },
  ariel:            { role: 'striker', movement: 'transcendent', formName: 'Second Transcendance', tags: ['double_strike', 'burst'] },
  yato:             { role: 'sovereign', movement: 'stream', formName: 'Live Blast Coronation', tags: ['crowd', 'burst'] },
  gojo:             { role: 'arcanist', movement: 'limitless', formName: 'Six Eyes Unbound', tags: ['shield', 'space'] },
  alexa:            { role: 'support', movement: 'charm', formName: 'Lovestruck Dominion', tags: ['control', 'healer'] },
  witch_of_envy:    { role: 'reaper', movement: 'envy', formName: 'Wonders of Envy', tags: ['execute', 'dark'] },
  echidna:          { role: 'trickster', movement: 'greed', formName: 'Book of Wisdom Opened', tags: ['steal', 'control'] },
  gogeta:           { role: 'striker', movement: 'instant', formName: 'Fusion of Equals Perfected', tags: ['burst', 'evasion'] },
  red_rose:         { role: 'trickster', movement: 'puppet', formName: 'Puppet Strings Unbound', tags: ['control', 'reflect'] },
  naruto:           { role: 'berserker', movement: 'kurama', formName: 'Baryon Mode Limit', tags: ['rage', 'burst'] },
  reverie:          { role: 'arcanist', movement: 'timestop', formName: 'Time Stop Sovereignty', tags: ['time', 'control'] },
  montana:          { role: 'striker', movement: 'speedster', formName: 'Faster Than Time', tags: ['counter', 'speed'] },
  aizen:            { role: 'trickster', movement: 'hypnosis', formName: 'Kyōka Suigetsu Complete', tags: ['illusion', 'control'] },
  orihime:          { role: 'support', movement: 'reject', formName: 'Shun Shun Rikka Rejection', tags: ['healer', 'cleanse'] },
  scarlett:         { role: 'guardian', movement: 'desire', formName: 'My Desire Reflected', tags: ['reflect', 'guard'] },
  ronova:           { role: 'reaper', movement: 'countdown', formName: 'End of the World', tags: ['execute', 'beam'] },
  sword_maiden:     { role: 'striker', movement: 'charge', formName: 'Absolute Sword Unsealed', tags: ['charge', 'burst'] },
  alpha:            { role: 'sovereign', movement: 'garden', formName: 'Garden Call Ascendant', tags: ['summon', 'command'] },
  delta:            { role: 'berserker', movement: 'grudge', formName: "Beast's Grudge Unleashed", tags: ['counter', 'rage'] },
  yelan:            { role: 'reaper', movement: 'killer', formName: 'Character Killer Throne', tags: ['execute', 'anti_character'] },
  avessa:           { role: 'trickster', movement: 'mirror', formName: 'Perfect Mirror Complete', tags: ['copy', 'control'] },
  beth:             { role: 'support', movement: 'mend', formName: 'Mend & Reinforce Eternal', tags: ['healer', 'repair'] },
  yu_miaoyi:        { role: 'phantom', movement: 'lucid', formName: 'Lucid Embrace Deep', tags: ['auto', 'evasion'] },
  texas:            { role: 'striker', movement: 'followup', formName: 'Nigh Omni Cascade', tags: ['followup', 'burst'] },
  liorei:           { role: 'support', movement: 'snapshot', formName: 'Snapshot Eternity', tags: ['time', 'healer'] },
  queen_esta:       { role: 'sovereign', movement: 'constellation', formName: 'Mother of Constellations', tags: ['beam', 'command'] },
  king_yato:        { role: 'sovereign', movement: 'grace', formName: 'Grace of the Crown', tags: ['guard', 'command'] },
  queen_king:       { role: 'sovereign', movement: 'crown', formName: 'Crown Reunited', tags: ['beam', 'guard'] },
  cid:              { role: 'arcanist', movement: 'atomic', formName: 'I Am Atomic', tags: ['burst', 'mana'] },
  saber:            { role: 'striker', movement: 'excalibur', formName: 'Sword of Promised Victory', tags: ['beam', 'burst'] },
  audrey_hall:      { role: 'guardian', movement: 'justice', formName: 'Justice of the Mind', tags: ['reflect', 'insight'] },
  victoria_minayoko:{ role: 'guardian', movement: 'sanctum', formName: 'Sanctum Victoriae', tags: ['immune', 'guard'] },
  queen_of_fairies: { role: 'sovereign', movement: 'encore', formName: 'Court of the Dark Elf Queen', tags: ['control', 'command'] },
  clane:            { role: 'berserker', movement: 'hunger', formName: 'Crimson Hunger Crown', tags: ['drain', 'rage'] },
  the_end:          { role: 'sovereign', movement: 'countdown', formName: 'The Last Dominion', tags: ['summon', 'execute', 'dimension'] },
  surtr:            { role: 'berserker', movement: 'colossus', formName: 'Twilight of the Molten Colossus', tags: ['fire', 'burst', 'transform'] },
  // Season 2 cast, Minato and Rengoku. Their profiles were authored straight into
  // data/combat-doctrines.json and this table — the generator's only source of
  // character identity — was never brought back in step, so a run of the script
  // threw on kim_dokja before it read a single weapon. Restored below from those
  // committed profiles, so the builder is a working tool again and a new
  // character (Surtr above) can be added the documented way.
  kim_dokja:        { role: 'arcanist', movement: 'constellation', formName: 'The Fourth Wall', tags: ['reflect', 'shield', 'reader'] },
  yoo_joonghyuk:    { role: 'striker', movement: 'executioner', formName: 'Splitting the Sky', tags: ['frontline', 'execute', 'regressor'] },
  han_sooyoung:     { role: 'arcanist', movement: 'reject', formName: 'Final Draft', tags: ['dispel', 'control', 'author'] },
  klein_moretti:    { role: 'trickster', movement: 'puppet', formName: 'Astral Projection', tags: ['caster', 'dodge', 'seer'] },
  rimuru:           { role: 'sovereign', movement: 'hunger', formName: 'Megiddo', tags: ['bruiser', 'regen', 'absorb', 'slime'] },
  evelyn_ling:      { role: 'support', movement: 'encore', formName: 'Pressing', tags: ['support', 'dodge'] },
  minato:           { role: 'striker', movement: 'instant', formName: 'Yellow Flash', tags: ['evasion', 'speed'] },
  rengoku:          { role: 'striker', movement: 'followup', formName: 'Flame Hashira Ascendant', tags: ['followup', 'fire'] },
}

const MOVEMENTS = {
  bulwark:      { moveGuard: 0.08, dodgeGuard: 0.04, flankBonus: 0.02, meterBonus: 2 },
  feint:        { moveGuard: 0.03, dodgeGuard: 0.06, flankBonus: 0.07, meterBonus: 4 },
  executioner:  { moveGuard: 0.02, dodgeGuard: 0.03, flankBonus: 0.08, meterBonus: 3 },
  advisor:      { moveGuard: 0.04, dodgeGuard: 0.05, flankBonus: 0.04, meterBonus: 5 },
  frostlock:    { moveGuard: 0.05, dodgeGuard: 0.05, flankBonus: 0.03, meterBonus: 3 },
  serpent:      { moveGuard: 0.03, dodgeGuard: 0.09, flankBonus: 0.06, meterBonus: 4 },
  sunstep:      { moveGuard: 0.02, dodgeGuard: 0.07, flankBonus: 0.09, meterBonus: 4 },
  pathfinder:   { moveGuard: 0.04, dodgeGuard: 0.06, flankBonus: 0.05, meterBonus: 6 },
  twinshift:    { moveGuard: 0.07, dodgeGuard: 0.05, flankBonus: 0.03, meterBonus: 3 },
  rewind:       { moveGuard: 0.04, dodgeGuard: 0.07, flankBonus: 0.04, meterBonus: 5 },
  wildcard:     { moveGuard: 0.03, dodgeGuard: 0.08, flankBonus: 0.06, meterBonus: 5 },
  shadow:       { moveGuard: 0.04, dodgeGuard: 0.08, flankBonus: 0.07, meterBonus: 4 },
  thief:        { moveGuard: 0.03, dodgeGuard: 0.08, flankBonus: 0.08, meterBonus: 5 },
  exchange:     { moveGuard: 0.05, dodgeGuard: 0.06, flankBonus: 0.05, meterBonus: 4 },
  void:         { moveGuard: 0.08, dodgeGuard: 0.05, flankBonus: 0.02, meterBonus: 3 },
  transcendent: { moveGuard: 0.02, dodgeGuard: 0.07, flankBonus: 0.09, meterBonus: 4 },
  stream:       { moveGuard: 0.03, dodgeGuard: 0.05, flankBonus: 0.06, meterBonus: 5 },
  limitless:    { moveGuard: 0.07, dodgeGuard: 0.08, flankBonus: 0.03, meterBonus: 3 },
  charm:        { moveGuard: 0.05, dodgeGuard: 0.05, flankBonus: 0.03, meterBonus: 4 },
  envy:         { moveGuard: 0.03, dodgeGuard: 0.05, flankBonus: 0.08, meterBonus: 4 },
  greed:        { moveGuard: 0.04, dodgeGuard: 0.06, flankBonus: 0.05, meterBonus: 5 },
  instant:      { moveGuard: 0.02, dodgeGuard: 0.10, flankBonus: 0.08, meterBonus: 4 },
  puppet:       { moveGuard: 0.04, dodgeGuard: 0.06, flankBonus: 0.05, meterBonus: 4 },
  kurama:       { moveGuard: 0.02, dodgeGuard: 0.04, flankBonus: 0.09, meterBonus: 3 },
  timestop:     { moveGuard: 0.05, dodgeGuard: 0.07, flankBonus: 0.04, meterBonus: 5 },
  speedster:    { moveGuard: 0.02, dodgeGuard: 0.10, flankBonus: 0.09, meterBonus: 5 },
  hypnosis:     { moveGuard: 0.04, dodgeGuard: 0.09, flankBonus: 0.05, meterBonus: 4 },
  reject:       { moveGuard: 0.06, dodgeGuard: 0.05, flankBonus: 0.02, meterBonus: 4 },
  desire:       { moveGuard: 0.07, dodgeGuard: 0.04, flankBonus: 0.03, meterBonus: 3 },
  countdown:    { moveGuard: 0.04, dodgeGuard: 0.05, flankBonus: 0.06, meterBonus: 4 },
  charge:       { moveGuard: 0.04, dodgeGuard: 0.04, flankBonus: 0.07, meterBonus: 4 },
  garden:       { moveGuard: 0.05, dodgeGuard: 0.05, flankBonus: 0.04, meterBonus: 5 },
  grudge:       { moveGuard: 0.05, dodgeGuard: 0.03, flankBonus: 0.07, meterBonus: 4 },
  killer:       { moveGuard: 0.03, dodgeGuard: 0.06, flankBonus: 0.09, meterBonus: 4 },
  mirror:       { moveGuard: 0.04, dodgeGuard: 0.07, flankBonus: 0.05, meterBonus: 5 },
  mend:         { moveGuard: 0.06, dodgeGuard: 0.05, flankBonus: 0.02, meterBonus: 4 },
  lucid:        { moveGuard: 0.04, dodgeGuard: 0.10, flankBonus: 0.06, meterBonus: 5 },
  followup:     { moveGuard: 0.03, dodgeGuard: 0.06, flankBonus: 0.08, meterBonus: 4 },
  snapshot:     { moveGuard: 0.05, dodgeGuard: 0.06, flankBonus: 0.04, meterBonus: 5 },
  constellation:{ moveGuard: 0.05, dodgeGuard: 0.05, flankBonus: 0.05, meterBonus: 5 },
  grace:        { moveGuard: 0.08, dodgeGuard: 0.05, flankBonus: 0.03, meterBonus: 4 },
  crown:        { moveGuard: 0.08, dodgeGuard: 0.06, flankBonus: 0.04, meterBonus: 5 },
  atomic:       { moveGuard: 0.03, dodgeGuard: 0.05, flankBonus: 0.06, meterBonus: 4 },
  excalibur:    { moveGuard: 0.04, dodgeGuard: 0.05, flankBonus: 0.08, meterBonus: 4 },
  justice:      { moveGuard: 0.07, dodgeGuard: 0.05, flankBonus: 0.03, meterBonus: 4 },
  sanctum:      { moveGuard: 0.09, dodgeGuard: 0.05, flankBonus: 0.02, meterBonus: 4 },
  encore:       { moveGuard: 0.05, dodgeGuard: 0.07, flankBonus: 0.05, meterBonus: 5 },
  hunger:       { moveGuard: 0.03, dodgeGuard: 0.04, flankBonus: 0.09, meterBonus: 4 },
  // 🌋 Surtr — she does not step, she arrives. The lowest dodge in the roster
  // and the highest flank bonus: a colossus is not hard to hit, it is hard to be
  // in front of.
  colossus:     { moveGuard: 0.06, dodgeGuard: 0.02, flankBonus: 0.09, meterBonus: 4 },
}

const FAMILIES = {
  blade:   { label: 'Blade', emoji: '🗡️', tags: ['physical', 'momentum'], effect: 'momentum', pierce: 0.02, critBonus: 0.02, outgoing: 1.03, defendGuard: 0.03, moveMeter: 3, description: 'Builds momentum each turn; steady damage and reliable guard.' },
  shadow:  { label: 'Shadow', emoji: '🌑', tags: ['evasion', 'bleed'], effect: 'first_blood', pierce: 0.04, critBonus: 0.05, outgoing: 1.025, defendGuard: 0.02, moveMeter: 5, description: 'Rewards flanks and opening strikes; high crit and movement charge.' },
  arcane:  { label: 'Arcane', emoji: '🔮', tags: ['mana', 'elemental'], effect: 'mana_echo', pierce: 0.03, critBonus: 0.01, outgoing: 1.035, defendGuard: 0.04, moveMeter: 2, mpRestorePct: 0.03, description: 'Skills hit harder and defending restores a little MP.' },
  ranger:  { label: 'Ranger', emoji: '🏹', tags: ['ranged', 'tempo'], effect: 'opening_shot', pierce: 0.03, critBonus: 0.04, outgoing: 1.03, defendGuard: 0.02, moveMeter: 5, description: 'Opening strikes and dodges are rewarded; keeps distance.' },
  breaker: { label: 'Breaker', emoji: '🪓', tags: ['armor_break', 'burst'], effect: 'armor_break', pierce: 0.08, critBonus: 0.02, outgoing: 1.04, defendGuard: 0.03, moveMeter: 2, description: 'Cuts through armor and punishes shielded targets.' },
  crush:   { label: 'Crush', emoji: '🔨', tags: ['stagger', 'construct'], effect: 'stagger', pierce: 0.05, critBonus: 0.01, outgoing: 1.035, defendGuard: 0.05, moveMeter: 2, description: 'Heavy impacts build stagger and guard stability.' },
  reach:   { label: 'Reach', emoji: '🔱', tags: ['swarm', 'reach'], effect: 'reach', pierce: 0.04, critBonus: 0.02, outgoing: 1.03, defendGuard: 0.03, moveMeter: 6, description: 'Lane movement primes the next strike; strong against packs.' },
  brawler: { label: 'Brawler', emoji: '🥊', tags: ['combo', 'physical'], effect: 'combo', pierce: 0.03, critBonus: 0.03, outgoing: 1.035, defendGuard: 0.04, moveMeter: 4, description: 'Consecutive hits build combo pressure; counters after guard.' },
  codex:   { label: 'Codex', emoji: '📖', tags: ['mana', 'insight'], effect: 'insight', pierce: 0.03, critBonus: 0.01, outgoing: 1.03, defendGuard: 0.04, moveMeter: 3, meterBonus: 4, description: 'Charges character form faster and rewards skill variety.' },
}

function familyFor(w) {
  const id = String(w.id || '').toLowerCase()
  const name = String(w.name || '').toLowerCase()
  const s = `${id} ${name}`
  if (/grimoire|tome|codex|book/.test(s)) return 'codex'
  if (/fist|gauntlet|knuckle|glove|bracer/.test(s)) return 'brawler'
  if (/spear|lance|glaive|bisento|trident/.test(s)) return 'reach'
  if (/mace|club|hammer|maul|drum/.test(s)) return 'crush'
  if (/axe|scythe|pick|warpick|rhitta/.test(s)) return 'breaker'
  if (/bow|crossbow|arrow/.test(s)) return 'ranger'
  if (/staff|wand|scepter|rod|cane|dial|core|headset|crown|diadem|veil|pin|ring|aureole/.test(s)) return 'arcane'
  if (/dagger|knife|fang|shiv|stiletto|reaper|edge/.test(s)) return 'shadow'
  return 'blade'
}

const RARITY_SCALE = {
  common: 0.75, uncommon: 0.85, rare: 0.95, epic: 1.05, legendary: 1.15, mythic: 1.25,
}

const characterProfiles = characters.map(c => {
  const o = CHARACTER_OVERRIDES[c.id]
  if (!o) throw new Error(`Missing character doctrine override: ${c.id}`)
  const role = ROLES[o.role]
  if (!role) throw new Error(`Unknown role ${o.role} for ${c.id}`)
  const movement = MOVEMENTS[o.movement]
  if (!movement) throw new Error(`Unknown movement ${o.movement} for ${c.id}`)
  return {
    id: c.id,
    name: c.name,
    role: o.role,
    roleLabel: role.label,
    emoji: role.emoji,
    movement: o.movement,
    movementProfile: movement,
    tags: [...new Set([...(role.tags || []), ...(o.tags || [])])],
    outgoing: role.outgoing,
    incoming: role.incoming,
    meter: role.meter,
    form: {
      ...role.form,
      name: o.formName,
      meterCost: 100,
      oncePerBattle: true,
      description: `${o.formName}: a ${role.label.toLowerCase()} ascension that amplifies ${c.name}'s existing kit without replacing it.`,
    },
    strongAgainst: role.strongAgainst,
    weakAgainst: role.weakAgainst,
    existingAbility: c.ability?.name ?? null,
  }
})

const weaponProfiles = weapons.map(w => {
  const familyId = familyFor(w)
  const fam = FAMILIES[familyId]
  const scale = RARITY_SCALE[String(w.rarity || 'common').toLowerCase()] ?? 1
  const named = Boolean(w.named || w.passiveId || w.effect)
  // Named/passive gear keeps its authored passive as the star. Doctrine adds a
  // half-strength chassis so it still participates in movement/form/counterplay.
  const weight = named ? 0.5 : 1
  const s = n => Number((n * scale * weight).toFixed(4))
  return {
    id: w.id,
    name: w.name,
    family: familyId,
    familyLabel: fam.label,
    emoji: fam.emoji,
    rarity: w.rarity ?? 'common',
    named,
    existingPassive: w.passiveId ?? w.effect?.type ?? null,
    tags: fam.tags,
    effect: fam.effect,
    description: fam.description,
    outgoing: Number((1 + (fam.outgoing - 1) * scale * weight).toFixed(4)),
    pierce: s(fam.pierce),
    critBonus: s(fam.critBonus),
    defendGuard: s(fam.defendGuard),
    moveMeter: Math.max(1, Math.round(fam.moveMeter * weight)),
    mpRestorePct: s(fam.mpRestorePct ?? 0),
    meterBonus: Math.max(0, Math.round((fam.meterBonus ?? 0) * weight)),
    strongAgainst: familyId === 'breaker' ? ['shield', 'armored', 'construct']
      : familyId === 'crush' ? ['armored', 'construct', 'stagger']
      : familyId === 'reach' ? ['swarm', 'beast']
      : familyId === 'shadow' ? ['low_hp', 'caster', 'evasion']
      : familyId === 'arcane' || familyId === 'codex' ? ['armored', 'undead', 'mana']
      : familyId === 'ranger' ? ['evasion', 'beast', 'swarm']
      : ['burst', 'duelist'],
  }
})

const out = {
  version: 1,
  generatedBy: 'scripts/build-combat-doctrines.mjs',
  design: {
    meterMax: 100,
    formDurationDefault: 3,
    pvpMeterScale: 0.75,
    leagueMeterScale: 0.6,
    partyMeterScale: 0.9,
    matchupStrongBonus: 0.05,
    matchupWeakPenalty: 0.03,
    pvpMatchupScale: 0.6,
    momentumMaxStacks: 5,
    momentumPerStack: 0.02,
    comboMaxStacks: 4,
    comboPerStack: 0.02,
  },
  roles: ROLES,
  movements: MOVEMENTS,
  families: FAMILIES,
  characters: characterProfiles,
  weapons: weaponProfiles,
}

writeFileSync(join(root, 'data/combat-doctrines.json'), JSON.stringify(out, null, 2) + '\n')
console.log(`Wrote ${characterProfiles.length} character doctrines and ${weaponProfiles.length} weapon doctrines.`)
