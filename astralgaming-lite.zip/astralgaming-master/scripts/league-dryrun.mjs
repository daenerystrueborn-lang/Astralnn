#!/usr/bin/env node
/**
 * scripts/league-dryrun.mjs — a whole League season with a fake clock.
 *
 * Seats seven fake players next to the thirteen real Adventurers, draws the
 * schedule, then walks a fake clock through all 21 days (19 rounds plus the two
 * catch up days) and prints every post the scheduler would make, in order.
 *
 * It touches no real database and no socket: the db is a plain object whose
 * write() is a no-op, and the sends are collected instead of delivered. That is
 * the point. It is how you read a season before an owner ever sees one.
 *
 * Usage (from the repo root):
 *   node scripts/league-dryrun.mjs              full season, every post
 *   node scripts/league-dryrun.mjs --day 3      only day 3
 *   node scripts/league-dryrun.mjs --quiet      counts and markers only
 *   node scripts/league-dryrun.mjs --seed 7     a different draw
 *   node scripts/league-dryrun.mjs --restart    simulate a boot in the middle
 */
import { flushPendingWrites } from '../lib/player-repo.js'
import {
  emptyLeague,
  seatAdventurers,
  seatPlayers,
  drawSeason,
  leagueDayOf,
  matchesDueOn,
  applyMatchResult,
  resultShapes,
} from '../lib/league/league-repo.js'
import { listAdventurers } from '../lib/league/adventurer-repo.js'
import { planLeagueTick, runLeagueTick } from '../lib/league/league-scheduler.js'
import { buildTable } from '../lib/league/league-table.js'
import {
  LEAGUE_ROUNDS,
  LEAGUE_CATCHUP_DAYS,
  LEAGUE_TICK_MS,
  dayKeyWAT,
  dateLabelWAT,
  wallClockWAT,
} from '../lib/league/league-rules.js'

const args = process.argv.slice(2)
const quiet = args.includes('--quiet')
const restart = args.includes('--restart')
const onlyDay = args.includes('--day') ? parseInt(args[args.indexOf('--day') + 1], 10) : null
const seed = args.includes('--seed') ? parseInt(args[args.indexOf('--seed') + 1], 10) : 1234

// ── A fake db. updateWorldState only needs db.data and db.write(). ──────────
const db = {
  data: {},
  async write() { this.writes = (this.writes ?? 0) + 1 },
}
db.data.league = emptyLeague()
db.data.league.featureOn = true
db.data.league.construction = false
process.env.ASTRAL_PROS_ENABLED = '1'

// ── Seat the table: 13 real Adventurers, 7 fake players. ────────────────────
const FAKE_PLAYERS = ['Ada', 'Bram', 'Cleo', 'Dax', 'Elif', 'Fen', 'Gus']
seatAdventurers(db.data.league, listAdventurers())
const jids = FAKE_PLAYERS.map((name, i) => `90000000${i}@s.whatsapp.net`)
const seated = seatPlayers(db.data.league, jids, jid => FAKE_PLAYERS[Number(jid.slice(-2, -13) || 0)] ?? null)
// The name resolver above is fussy about the fake JID shape, so name them here.
db.data.league.seats.filter(s => s.kind === 'player')
  .forEach((s, i) => { s.name = FAKE_PLAYERS[i] })

const startMs = Date.UTC(2026, 9, 1, 0, 0, 0) - 60 * 60 * 1000 // 1 Oct 2026, 00:00 WAT
const drawn = drawSeason(db.data.league, { seed, now: startMs })
if (!drawn.ok) {
  console.error('draw failed:', drawn.problems)
  process.exit(1)
}
db.data.league.season.startDay = dayKeyWAT(startMs)
db.data.league.season.status = 'running'

const league = db.data.league
console.log(`🎲 Seed ${seed} drew ${Object.keys(league.matches).length} matches over ${league.fixtures.length} days`)
console.log(`🪑 Seated ${league.seats.length} seats: ${league.seats.filter(s => s.kind === 'adventurer').length} Adventurers, ${league.seats.filter(s => s.kind === 'player').length} players`)
if (seated.problems.length) console.error('seating problems:', seated.problems)

// ── Fake sends. The scheduler hands them to a socket; we collect them. ──────
const collected = []
const fakeInstances = [{ activeSock: { async sendMessage(jid, payload) { collected.push({ jid, text: payload.text }) } } }]

// ── Walk the clock. One tick every 30 minutes of fake time is plenty: the real
//    tick is 30 seconds, and the markers make the cadence irrelevant. ─────────
const STEP_MS = 30 * 60 * 1000
const totalDays = LEAGUE_ROUNDS + LEAGUE_CATCHUP_DAYS
const endMs = startMs + totalDays * 86_400_000

let ticks = 0
let lastDay = null
for (let now = startMs; now < endMs; now += STEP_MS) {
  const day = leagueDayOf(league, now)
  if (day !== lastDay) {
    lastDay = day
    if (!quiet && (onlyDay === null || onlyDay === day)) {
      console.log(`\n${'═'.repeat(72)}`)
      console.log(`📅 DAY ${day}  ·  ${dateLabelWAT(now)}  ·  ${matchesDueOn(league, day).length} matches due`)
      console.log('═'.repeat(72))
    }
  }

  // Simulate a restart partway through day 5: the markers are in db.data, so a
  // fresh tick must not repost what already went out.
  if (restart && day === 5 && now === startMs + 4 * 86_400_000 + 12 * 3_600_000) {
    console.log('\n🔁 Simulated restart here. Markers survive, so nothing should repeat.')
  }

  // Settle the day's Adventurer matches at 18:30 so the table moves and the
  // end of day post has something to say. In the real bot Phase 3 does this.
  // It has to run BEFORE the tick's early exit: 18:30 is never a tick where a
  // scheduled task is due, so putting it after the `continue` meant it never ran.
  let settledNow = 0
  if (wallClockWAT(now).hhmm === '18:30') {
    for (const m of matchesDueOn(league, day).filter(x => x.type === 'AvA' && !x.result?.applied)) {
      // A deterministic pick: the lower seat wins, so the run is reproducible.
      applyMatchResult(league, m.id, resultShapes.fought(m.seatA, m.seatB, now))
      settledNow++
    }
  }

  collected.length = 0
  const result = await runLeagueTick(db, fakeInstances, now, { log: null, sendGapMs: 0 })
  ticks++
  if (settledNow && !quiet && (onlyDay === null || onlyDay === day)) {
    console.log(`\n   ⚔️ ${settledNow} Adventurer matches settled for day ${day}`)
  }
  if (!result.due.length) continue

  if (!quiet && (onlyDay === null || onlyDay === day)) {
    const clock = wallClockWAT(now)
    console.log(`\n⏰ ${clock.hhmm}  due: ${result.due.join(', ')}  (${result.sent} sends)`)
    for (const send of collected) {
      const who = send.jid.includes('@g.us') ? 'GROUP' : `DM ${send.jid.split('@')[0]}`
      console.log(`\n── to ${who} ${'─'.repeat(50)}`)
      console.log(send.text)
    }
  } else {
    console.log(`day ${day} ${wallClockWAT(now).hhmm}: ${result.due.join(', ')} (${result.sent} sends)`)
  }

}

// ── The closing table. ──────────────────────────────────────────────────────
console.log(`\n${'═'.repeat(72)}`)
console.log(`🏁 After ${totalDays} days and ${ticks} ticks`)
console.log('═'.repeat(72))
const rows = buildTable(league)
for (const row of rows) {
  console.log(`${String(row.rank).padStart(2)}. ${row.kind === 'adventurer' ? '🌟' : '🎮'} ${row.name.padEnd(20)} ${String(row.points).padStart(4)} pts  ${row.wins}W ${row.losses}L  played ${row.played}`)
}
console.log(`\n📝 Results applied: ${league.results.length}`)
console.log('🔁 Rollover markers:', JSON.stringify(league.rollover))
await flushPendingWrites(db)
console.log(`💾 Whole file writes: ${db.writes ?? 0} for ${ticks} ticks (coalesced, never one per seat)`)
process.exit(0)
