/**
 * check-starfall-mechanics.mjs — unit checks for the Starfall champion package
 * (lib/starfall-champion.js). Runs without a database: every kit rule is
 * exercised against synthetic player/enemy records. What it does NOT cover:
 * turn-by-turn integration through plugins/skill.js, plugins/pvp.js and
 * plugins/party.js (those need a live harness), and the web preview surfaces.
 *
 * Run: node scripts/check-starfall-mechanics.mjs
 */
process.env.NODE_ENV = 'test'
const {
  starfallTurnTick, armCathedral, armEdoTensei, edoTenseiSave, seongHaHymnSave,
  castCage, haNeulAbsorb, haNeulReleaseDamage, noteGhostbladeKill, cathedralUp,
  haNeulState,
} = await import('../lib/starfall-champion.js')

let pass = 0, fail = 0
const ok = (cond, label) => { if (cond) { pass++; console.log('  ✓', label) } else { fail++; console.log('  ✗ FAIL:', label) } }

function mkPlayer(overrides = {}) {
  return {
    id: 'p1', name: 'Tester', equippedCharacter: 'seong_ha',
    hp: 1000, maxHp: 1000, mp: 100,
    stats: { str: 100, int: 100, def: 100, agi: 100, lck: 10 },
    inventory: ['ha_neul'], skills: ['burning_cathedral', 'edo_tensei_no_jutsu'],
    equipped: { weapon: 'ghostblade' },
    characterSkins: { owned: {}, equipped: {} },
    activeEffects: [],
    battleState: null,
    ...overrides,
  }
}

function mkBStruck() {
  return {
    turn: 3, enemy: { id: 'e1', name: 'Gojo', hp: 900, maxHp: 900, stats: { def: 120, agi: 200 }, activeEffects: [] },
    combatStats: { damageTaken: 400, minHpFrac: 0.9 },
  }
}

console.log('— Sanctuary: armed cathedral keeps the holder at 1 HP —')
{
  const p = mkPlayer()
  const bs = mkBStruck(); bs.turn = 1
  p.battleState = bs
  const armed = armCathedral(p, bs)
  ok(armed.applied, 'cathedral armed')
  ok(cathedralUp(p), 'cathedral effect present')
  ok(bs.cathedral.dealtByEnemy === 400, 'ledger opened with combatStats.damageTaken, got ' + bs.cathedral.dealtByEnemy)
}

console.log('— Ledger collects on the owner’s turn —')
{
  const p = mkPlayer()
  const bs = mkBStruck()
  p.battleState = bs
  armCathedral(p, bs)
  bs.cathedral.dealtByEnemy = 300
  const tick = starfallTurnTick(p, bs)
  ok(bs.enemy.hp === 600, 'foe took 300 ledger damage, got ' + bs.enemy.hp)
  ok(tick.lines.some(l => l.includes('ledger')), 'ledger line narrated')
}

console.log('— Bell tolls the strongest buff off the foe, pays a shield —')
{
  const p = mkPlayer()
  const bs = mkBStruck()
  p.battleState = bs
  armCathedral(p, bs)
  bs.enemy.activeEffects.push(
    { type: 'strengthen', remaining: 3, value: 200, meta: null },
    { type: 'shield', remaining: 2, value: 80, meta: null },
  )
  const tick = starfallTurnTick(p, bs)
  ok(!bs.enemy.activeEffects.some(e => e.type === 'strengthen'), 'strongest buff stripped')
  ok(bs.enemy.activeEffects.some(e => e.type === 'shield'), 'weaker buff kept')
  ok((p.activeEffects ?? []).some(e => e.type === 'shield'), 'caster got the payout shield')
}

console.log('— Edo Tensei: cast arms it, death consumes it once —')
{
  const p = mkPlayer()
  const bs = mkBStruck()
  p.battleState = bs
  const a = armEdoTensei(p, bs)
  ok(a.ok && bs.edoPrepared, 'rite armed')
  const again = armEdoTensei(p, bs)
  ok(!again.ok, 'double-arm refused')
  p.hp = 0
  const save = edoTenseiSave(p, bs)
  ok(!!save && p.hp === 300, 'revived at 30%, got ' + p.hp)
  const save2 = edoTenseiSave(p, bs)
  ok(save2 === null, 'second death is real')
}

console.log('— Seong-ha Hymn: lethal blow leaves 1 HP and writes Debt —')
{
  const p = mkPlayer()
  const bs = mkBStruck(); bs.turn = 4
  p.battleState = bs
  bs.lastHitDamage = 850
  const line = seongHaHymnSave(p, bs)
  ok(!!line && p.hp === 1, 'hymn leaves 1 HP')
  ok(bs.seonghaHymn?.debt === 850 && bs.seonghaHymn?.dueTurn === 6, 'debt armed for turn 6, got ' + JSON.stringify(bs.seonghaHymn))
  const again = seongHaHymnSave(p, bs)
  ok(again === null, 'hymn spent, second lethal blow is real')
}

console.log('— Hymn debt fires on the due turn, floored at 1 —')
{
  const p = mkPlayer()
  const bs = mkBStruck(); bs.turn = 6
  p.battleState = bs
  bs.seonghaHymn = { debt: 5000, dueTurn: 6 }
  const tick = starfallTurnTick(p, bs)
  ok(bs.enemy.hp === 1, 'debt cannot kill through the tick, foe at 1, got ' + bs.enemy.hp)
  ok(bs.seonghaHymn === null, 'debt settled')
}

console.log('— Cage of the World: 25% DEF weaken, no kill from stars —')
{
  const p = mkPlayer()
  const enemy = { name: 'Gojo', hp: 500, maxHp: 900, stats: { def: 400, agi: 100 }, activeEffects: [] }
  const out = castCage(p, enemy)
  ok(enemy.activeEffects.some(e => e.type === 'cage'), 'cage effect landed')
  ok(enemy.activeEffects.some(e => e.type === 'weaken' && e.meta?.stat === 'def'), 'def weakened')
}

console.log('— Ha-neul: absorb builds chains, release pays everything —')
{
  const p = mkPlayer()
  const bs = mkBStruck()
  p.battleState = bs
  const a = haNeulAbsorb(p, 1000, bs)
  ok(a.absorbed === 350, 'absorbed 35%, got ' + a.absorbed)
  const hn = haNeulState(bs)
  ok(hn.weight === 350, 'weight stored, got ' + hn.weight)
  const rel = haNeulReleaseDamage(p, bs)
  ok(rel.damage === 700, 'release pays 200% (rounded), got ' + rel.damage)
  ok(haNeulState(bs).ended, 'tether ended after release')
  const rel2 = haNeulReleaseDamage(p, bs)
  ok(rel2 === null, 'nothing left to release')
}

console.log('— Ghostblade: the Requiem Roster collects names —')
{
  const p = mkPlayer()
  p.battleState = mkBStruck()
  const line = noteGhostbladeKill(p, { name: 'Gojo Satoru' })
  ok(line && p.ghostbladeRoster?.[0] === 'Gojo Satoru', 'name written')
  noteGhostbladeKill(p, { name: 'Gojo Satoru' })
  ok(p.ghostbladeRoster.length === 1, 'no duplicates')
}

console.log(`\n${pass} passed, ${fail} failed`)
process.exit(fail ? 1 : 0)
