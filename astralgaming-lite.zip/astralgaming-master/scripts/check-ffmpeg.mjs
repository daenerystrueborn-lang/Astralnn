#!/usr/bin/env node
/**
 * check-ffmpeg.mjs — "why did `.sticker` fail?" answered from the shell.
 *
 *   node scripts/check-ffmpeg.mjs
 *
 * Prints the exact binary every conversion command will use — stickers
 * (`.sticker`, `.stickerpack`), gif → video, the music converters — and where
 * it came from. That resolution lives in lib/ffmpeg-bin.js and is the same one
 * the bot uses at runtime, so this is not an approximation of the bot's
 * behaviour: it is the bot's behaviour, run once and printed.
 *
 * Written after a player's `.sticker` came back as
 *
 *   ❌ Sticker conversion failed: … /bin/sh: 1: ffmpeg: not found
 *
 * because lib/sticker.js shelled out to a bare `ffmpeg` even though
 * ffmpeg-static was a declared dependency. Run this after a deploy that used
 * --ignore-scripts, or after `npm rebuild ffmpeg-static`, to see which binary
 * the bot actually got.
 *
 * Exit code: 0 when a binary was found, 1 when none was (so a deploy script
 * can gate on it).
 */
import { spawnSync } from 'node:child_process'
import { existsSync } from 'node:fs'
import { createRequire } from 'node:module'
import { resolveFfmpeg, ffmpegInstallHint } from '../lib/ffmpeg-bin.js'

const { bin, source, notes } = resolveFfmpeg()

for (const note of notes) console.log(`⚠️  ${note}`)

if (!bin) {
  console.log('🎞️  ffmpeg: NOT FOUND — stickers, gif → video and music conversion will fail')
  console.log(`    ${ffmpegInstallHint()}`)
  process.exit(1)
}

console.log(`🎞️  ffmpeg: ${bin}`)
console.log(`    resolved from: ${source}` +
  (source === 'FFMPEG_PATH' ? ' (an explicit setting)' :
   source === 'ffmpeg-static' ? ' (the binary bundled in node_modules)' :
   ' (a system install found on PATH)'))

// Prove it runs, and that it can do the one thing the sticker command needs.
// A present-but-broken binary (wrong architecture, truncated download) is a
// different failure from a missing one and looks identical in the chat reply.
const version = spawnSync(bin, ['-hide_banner', '-version'], { encoding: 'utf8' })
if (version.error || version.status !== 0) {
  console.log(`❌ it could not be executed: ${version.error?.message ?? `exit code ${version.status}`}`)
  console.log('    A binary that exists but cannot run usually means the wrong architecture')
  console.log('    (an amd64 binary on an arm64 host), or a download that was cut short.')
  console.log('    `npm rebuild ffmpeg-static` re-downloads it for this platform.')
  process.exit(1)
}
console.log(`    ${(version.stdout ?? '').split('\n')[0].trim()}`)

const encoders = spawnSync(bin, ['-hide_banner', '-encoders'], { encoding: 'utf8' })
const hasWebp = /libwebp/.test(encoders.stdout ?? '')
console.log(`    libwebp encoder: ${hasWebp ? '✅' : '❌ — stickers cannot be encoded by this build'}`)
if (!hasWebp) {
  console.log('    Install a full ffmpeg build (https://johnvansickle.com/ffmpeg/ static builds include it),')
  console.log('    or run `npm rebuild ffmpeg-static` to get the bundled one back.')
}

// ffmpeg-static keeps its download next to the package; saying so makes
// "ffmpeg-static is installed but has no binary" (the --ignore-scripts shape)
// obvious at a glance.
if (source !== 'ffmpeg-static') {
  let point = null
  try {
    point = createRequire(import.meta.url)('ffmpeg-static')
  } catch { /* not installed at all */ }
  if (point && !existsSync(point)) {
    console.log('')
    console.log(`ℹ️  the ffmpeg-static package is installed, but its downloaded binary is missing`)
    console.log(`    (expected at ${point}). The resolved ffmpeg above is used instead;`)
    console.log('    no bundled download is needed when a working system ffmpeg is available.')
  }
}

process.exit(hasWebp ? 0 : 1)
