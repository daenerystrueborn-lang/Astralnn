/** Starfall character spin: pricing, one-time premiums, rates and payouts. */
import assert from 'node:assert/strict'
import { existsSync, readFileSync } from 'node:fs'
import {
  PREMIUM, BOXES, SOLARS, COST_PER_SPIN, COST_PER_SPIN_SOLARS, ITEMS_PER_SPIN,
  STARFALL_BOX_IDS, openStarfallBoxes, starfallBoxCount, totalStarfallBoxes,
  validateStarfallCatalog, ensureStarfallState, premiumRateFor, spinBandRates,
  costFor, rollStarfall, grantEntry,
} from '../lib/starfall-engine.js'
import { characters } from '../lib/game-data.js'
import {
  wipePlayer, runStarfallWipe, runStarfallReopen, runStarfallRecovery,
  STARFALL_CHARACTERS, STARFALL_SKILLS, STARFALL_ITEMS,
} from '../lib/starfall-wipe.js'
import { allItems } from '../lib/game-data.js'
import skills from '../data/skills.json' with { type: 'json' }
import { BATTLE_ALLOWED_COMMANDS } from '../lib/platform/gates.js'
import haneulPlugin from '../plugins/haneul.js'
import starfallPlugin from '../plugins/starfall.js'

assert.deepEqual(validateStarfallCatalog(), [], 'catalog must pass its own economy checks')
assert.equal(PREMIUM.length, 10)
assert.equal(BOXES.length, 8)
assert.equal(SOLARS.length, 3)
assert.equal(ITEMS_PER_SPIN, 5)
assert.equal(COST_PER_SPIN, 3)
assert.equal(COST_PER_SPIN_SOLARS, 80000)
assert.equal(costFor(7, 'gems'), 21)
assert.equal(costFor(7, 'solars'), 560000)

assert.equal(premiumRateFor('seong_ha', 0, 'gems'), 0)
assert.equal(premiumRateFor('seong_ha', 349, 'gems'), 0)
assert.ok(premiumRateFor('seong_ha', 350, 'gems') > 0, 'the 351st gem spin can pay premium')
assert.equal(premiumRateFor('seong_ha', 399, 'solars'), 0)
assert.ok(premiumRateFor('seong_ha', 400, 'solars') > 0, 'the 401st solar spin can pay premium')
assert.ok(premiumRateFor('seong_ha', 500, 'gems') > premiumRateFor('seong_ha', 350, 'gems'))
assert.ok(premiumRateFor('seong_ha', 700, 'gems') > premiumRateFor('seong_ha', 500, 'gems'))
assert.ok(premiumRateFor('other', 350, 'gems') > 0)
const freshGems = spinBandRates({ premiumsWon: [], gemsSpins: 0 }, undefined, 'gems')
assert.equal(freshGems.premium, 0, 'gems dead zone pays no premium at spin 1')
const freshSolars = spinBandRates({ premiumsWon: [], solarsSpins: 0 }, undefined, 'solars')
assert.equal(freshSolars.premium, 0, 'solars dead zone pays no premium at spin 1')
const pastDeadZone = spinBandRates({ premiumsWon: [], gemsSpins: 350 }, undefined, 'gems')
assert.ok(pastDeadZone.premium > 0)

const deadZoneState = ensureStarfallState({ starfall: { spins: 0, gemsSpins: 351, solarsSpins: 401 } })
assert.equal(deadZoneState.gemsSpins, 351, 'wallet spin ledgers survive migration')
assert.equal(deadZoneState.solarsSpins, 401)

const state = ensureStarfallState({ starfall: { spins: 42, headlinesWon: ['sf_saber'], gemsSpent: 90 } })
assert.equal(state.spins, 42, 'old lifetime spins survive migration')
assert.deepEqual(state.headlinesWon, ['sf_saber'], 'old headline wins are not wiped')
assert.deepEqual(state.premiumsWon, [])

const alwaysPremium = () => 0.001
const batch = rollStarfall(20, 0, alwaysPremium, { ...state, gemsSpins: 350 }, 'gems')
const wonThisBatch = batch.flatMap(spin => spin.slots.filter(s => s.band === 'premium').map(s => s.id))
assert.ok(wonThisBatch.length >= 1)
assert.equal(new Set(wonThisBatch).size, wonThisBatch.length, 'no duplicate premium inside one command')
const later = rollStarfall(20, 20, alwaysPremium, { ...state, premiumsWon: wonThisBatch, gemsSpins: 350 }, 'gems')
const laterWon = later.flatMap(spin => spin.slots.filter(s => s.band === 'premium').map(s => s.id))
assert.equal(laterWon.filter(id => wonThisBatch.includes(id)).length, 0, 'owned premiums never drop again')
assert.equal(rollStarfall(1, 0, alwaysPremium, { ...state, premiumsWon: PREMIUM.map(e => e.id), gemsSpins: 350 }, 'gems')[0].band, 'box', 'spent pool falls back to boxes')
const deadBatch = rollStarfall(10, 0, alwaysPremium, { ...state, gemsSpins: 0, solarsSpins: 0 }, 'solars')
assert.ok(deadBatch.every(spin => spin.band !== 'premium'), 'inside the dead zone no premium can land')

const player = { ownedCharacters: [], inventory: [], skills: [], wallet: {} }
const grant = grantEntry(player, PREMIUM.find(e => e.id === 'sf_seong_ha'))
assert.equal(grant.duplicate, false)
assert.ok(player.ownedCharacters.includes('seong_ha'))
const repeat = grantEntry(player, PREMIUM.find(e => e.id === 'sf_seong_ha'))
assert.equal(repeat.duplicate, true, 'premium duplicates never pay out')

const ids = new Set([...characters.map(c => c.id), ...allItems.map(i => i.id), ...skills.map(s => s.id)])
for (const entry of PREMIUM) assert.ok(ids.has(entry.itemId), `${entry.itemId} must exist in a real catalog`)
for (const entry of [...PREMIUM, ...BOXES, ...SOLARS]) {
  if (entry.image) assert.ok(existsSync(`images/${entry.image}`), `${entry.image} is missing`)
}

const plugin = readFileSync(new URL('../plugins/starfall.js', import.meta.url), 'utf8')
assert.ok(!plugin.includes('Premium chance:'), 'player-facing banner must not print odds')
assert.ok(!plugin.includes('1 in 300'), 'player-facing info must not print the rate schedule')
assert.ok(!plugin.includes('premiumRateFor('), 'odds helpers must stay out of the plugin')
assert.ok(plugin.includes('if (parsed.info) return sendImage(ctx, BANNER_ART, helpText(pr))'), 'info must show the banner')
assert.ok(plugin.includes('ctx.db?.data?.starfallLocked'), 'Starfall must be locked while wiped')

const dirty = {
  starfall: { spins: 12, premiumsWon: ['sf_seong_ha'] },
  ownedCharacters: ['seong_ha', 'karren', 'saber'],
  equippedCharacter: 'seong_ha',
  skills: ['edo_tensei_no_jutsu', 'fireball'],
  inventory: ['ghostblade', 'ghostblade', 'iron_box', 'potion_box'],
  seasonOwned: { characters: ['seong_ha'], items: ['starfall_pfp'], weapons: ['ghostblade'] },
}
assert.equal(wipePlayer(dirty), true)
assert.equal(dirty.starfall, undefined)
assert.deepEqual(dirty.ownedCharacters, ['saber'])
assert.equal(dirty.equippedCharacter, null)
assert.deepEqual(dirty.skills, ['fireball'])
assert.deepEqual(dirty.inventory, ['iron_box'])
assert.deepEqual(dirty.seasonOwned, { characters: [], items: [], weapons: [] })
assert.equal(wipePlayer(dirty), false, 'the wipe is idempotent')
assert.equal(STARFALL_CHARACTERS.length, 2)
assert.equal(STARFALL_SKILLS.length, 2)
assert.ok(STARFALL_ITEMS.includes('ghostblade'))

// Verify startup reopen flips starfallLocked -> false once after wipe, while
// respecting any subsequent manual owner close across later restarts.
const fakeDb = {
  data: { users: {}, starfallWipeDone: true, starfallLocked: true },
  write: async () => {},
}
const reopen1 = await runStarfallReopen(fakeDb)
assert.equal(reopen1.reopened, true, 'first boot after wipe reopens Starfall')
assert.equal(fakeDb.data.starfallLocked, false, 'Starfall lock cleared on reopen')
assert.equal(fakeDb.data.starfallReopened, true, 'reopen marker recorded')

fakeDb.data.starfallLocked = true // simulate owner running .starfall close later
const reopen2 = await runStarfallReopen(fakeDb)
assert.equal(reopen2.reopened, false, 'second boot never overrides manual owner lock')
assert.equal(fakeDb.data.starfallLocked, true, 'manual owner lock persists across restarts')

const freshDb = { data: { users: {} }, write: async () => {} }
await runStarfallWipe(freshDb)
await runStarfallReopen(freshDb)
assert.equal(freshDb.data.starfallLocked, false, 'fresh DB boots with Starfall open')

// Regression: Ghostblade & Ha-neul MUST land even when inventory is 30/30 full,
// Starfall boxes go to weightless stash, all 5 boxes open cleanly, and boot
// recovery restores Jasyne's lost Ghostblade + frees clogged bag boxes.
{
  const fullBagPlayer = {
    name: 'FullBag',
    inventory: Array.from({ length: 30 }, () => 'health_potion'),
    ownedCharacters: [],
    skills: [],
    wallet: { solars: 0, gems: 0 },
  }
  const gbRes = grantEntry(fullBagPlayer, PREMIUM.find((e) => e.id === 'sf_ghostblade'))
  assert.equal(gbRes.duplicate, false)
  assert.ok(fullBagPlayer.inventory.includes('ghostblade'), 'Ghostblade lands even when bag is 30/30 full')
  assert.ok(fullBagPlayer.seasonOwned?.weapons?.includes('ghostblade'), 'Ghostblade recorded in seasonOwned.weapons')

  const hnRes = grantEntry(fullBagPlayer, PREMIUM.find((e) => e.id === 'sf_ha_neul'))
  assert.equal(hnRes.duplicate, false)
  assert.ok(fullBagPlayer.inventory.includes('ha_neul'), 'Ha-neul lands even when bag is full')
  assert.ok(fullBagPlayer.seasonOwned?.items?.includes('ha_neul'), 'Ha-neul recorded in seasonOwned.items')

  // Granting Starfall boxes goes to weightless stash, never filling inventory
  const boxTester = { inventory: [], wallet: { solars: 0, gems: 0 } }
  for (const boxId of STARFALL_BOX_IDS) {
    grantEntry(boxTester, BOXES.find((e) => e.itemId === boxId))
    assert.equal(starfallBoxCount(boxTester, boxId), 1, `${boxId} credited to Starfall box stash`)
  }
  assert.equal(boxTester.inventory.length, 0, 'Starfall boxes do not consume inventory slots')
  assert.equal(totalStarfallBoxes(boxTester), 5)

  for (const boxId of STARFALL_BOX_IDS) {
    const opened = openStarfallBoxes(boxTester, boxId, 1)
    assert.equal(opened.reason, 'ok', `${boxId} opens cleanly`)
    assert.equal(opened.opened, 1, `${boxId} consumes 1 box`)
    assert.equal(starfallBoxCount(boxTester, boxId), 0)
  }

  // Opening a bag-stored box at 30/30 frees its own slot first so 1-item gear rolls succeed
  const cloggedPlayer = {
    inventory: ['silver_box', ...Array.from({ length: 29 }, () => 'health_potion')],
    wallet: { solars: 0, gems: 0 },
  }
  const silverOpen = openStarfallBoxes(cloggedPlayer, 'silver_box', 1)
  assert.equal(silverOpen.reason, 'ok', 'bag-stored Silver Box opens even at 30/30 inventory')
  assert.equal(cloggedPlayer.inventory.length, 30)
  assert.ok(!cloggedPlayer.inventory.includes('silver_box'))

  // Boot recovery restores Jasyne's lost Ghostblade and moves Starfall boxes out of inventory,
  // while NOT double-granting to someone who already received & sold Ghostblade.
  const recoveryDb = {
    data: {
      users: {
        u_jasyne: {
          name: 'Jasyne',
          inventory: ['gold_box', 'silver_box', 'potion_box', 'iron_box'],
          starfall: { spins: 410, solarsSpins: 410, premiumsWon: ['sf_ghostblade'] },
          seasonOwned: { weapons: [], items: [], characters: [] },
        },
        u_already_sold: {
          name: 'Seller',
          inventory: [],
          starfall: { spins: 420, solarsSpins: 420, premiumsWon: ['sf_ghostblade'] },
          seasonOwned: { weapons: ['ghostblade'], items: [], characters: [] },
        },
      },
    },
    write: async () => {},
  }
  const rec = await runStarfallRecovery(recoveryDb)
  assert.equal(rec.ran, true)
  assert.ok(recoveryDb.data.users.u_jasyne.inventory.includes('ghostblade'), 'Jasyne receives her lost Ghostblade on boot')
  assert.deepEqual(recoveryDb.data.users.u_jasyne.starfall.boxes, {
    iron_box: 0,
    gold_box: 1,
    silver_box: 1,
    diamond_box: 0,
    potion_box: 1,
  }, 'clogged Starfall boxes moved from bag to stash')
  assert.ok(!recoveryDb.data.users.u_already_sold.inventory.includes('ghostblade'), 'player who already received & sold Ghostblade is not double-granted')

  // Regression (Glitch): `ensureStarfallState` must mutate `player.starfall` in place
  // so `grantEntry` box credits never orphan `current` and freeze lifetime/solar spins at 250.
  const glitchDb = {
    data: {
      starfallLocked: false,
      users: {
        'glitch@s.whatsapp.net': {
          name: 'Glitch',
          hp: 100,
          maxHp: 100,
          mp: 50,
          maxMp: 50,
          inventory: [],
          ownedCharacters: [],
          skills: [],
          wallet: { solars: 60_000_000, gems: 0 },
          starfall: { spins: 250, solarsSpins: 250, solarsSpent: 20_000_000 },
        },
      },
    },
    write: async () => {},
  }
  for (let batchIdx = 0; batchIdx < 5; batchIdx++) {
    await starfallPlugin.run({
      from: 'glitch@s.whatsapp.net',
      sender: 'glitch@s.whatsapp.net',
      db: glitchDb,
      player: glitchDb.data.users['glitch@s.whatsapp.net'],
      args: ['50', 'solar'],
      reply: async () => {},
      sock: { sendMessage: async () => {} },
    })
  }
  const glitchAfter = glitchDb.data.users['glitch@s.whatsapp.net']
  assert.equal(glitchAfter.starfall.spins, 500, 'lifetime spins advances cleanly from 250 to 500 across 5x50 solar batches')
  assert.equal(glitchAfter.starfall.solarsSpins, 500, 'solarsSpins advances cleanly past the 400-spin dead zone to 500')
  assert.equal(glitchAfter.starfall.solarsSpent, 40_000_000, 'solarsSpent persists across box-granting batches (500 * 80k = 40M)')

  // V2 boot recovery: frozen spin ledger reconciles upward from unopened Starfall box stash
  const frozenSpinDb = {
    data: {
      starfallRecoveryV1Done: true,
      users: {
        u_frozen: {
          name: 'FrozenSpinner',
          inventory: [],
          starfall: {
            spins: 250,
            solarsSpins: 250,
            solarsSpent: 20_000_000,
            boxes: { iron_box: 1200, gold_box: 500, silver_box: 300, diamond_box: 50, potion_box: 50 },
          },
        },
      },
    },
    write: async () => {},
  }
  const recV2 = await runStarfallRecovery(frozenSpinDb)
  assert.equal(recV2.ran, true)
  assert.equal(frozenSpinDb.data.users.u_frozen.starfall.spins, 420, '2,100 stashed boxes recover 420 minimum spins')
  assert.equal(frozenSpinDb.data.users.u_frozen.starfall.solarsSpins, 420, 'solarsSpins reconciled past 400 dead zone')

  // Regression (Jasyne): `.haneul` and `.cage` + all aliases clear BATTLE_ALLOWED_COMMANDS,
  // and `.haneul` works outside battle AND on Turn 1 mid-battle before taking damage.
  for (const token of ['haneul', 'ha-neul', 'chainedangel', 'angel', 'cage', 'cageoftheworld', 'cage-world', 'worldcage', 'imprison']) {
    assert.ok(BATTLE_ALLOWED_COMMANDS.has(token), `${token} must be in BATTLE_ALLOWED_COMMANDS`)
  }
  const haneulOwner = {
    name: 'Jasyne',
    inventory: ['ha_neul'],
    inBattle: false,
    battleState: null,
  }
  const outReplies = []
  await haneulPlugin.run({
    from: 'jasyne@s.whatsapp.net',
    db: { data: { users: { 'jasyne@s.whatsapp.net': haneulOwner } }, write: async () => {} },
    player: haneulOwner,
    args: [],
    reply: async (m) => { outReplies.push(m) },
  })
  assert.ok(outReplies[0]?.includes('Bound & Ready') && outReplies[0]?.includes('35%'), 'out-of-battle .haneul shows full bound status card')

  haneulOwner.inBattle = true
  haneulOwner.battleState = { turn: 1, enemy: { name: 'Shadow Fiend', hp: 500, maxHp: 500 } }
  const inBattleReplies = []
  await haneulPlugin.run({
    from: 'jasyne@s.whatsapp.net',
    db: { data: { users: { 'jasyne@s.whatsapp.net': haneulOwner } }, write: async () => {} },
    player: haneulOwner,
    args: [],
    reply: async (m) => { inBattleReplies.push(m) },
  })
  assert.ok(inBattleReplies[0]?.includes('Chains: *6/6*') && inBattleReplies[0]?.includes('Turns left: *6*'), 'Turn-1 mid-battle .haneul shows live 6/6 chains')
}

console.log('Starfall: hidden odds, dual currency, one-time premiums, boxes, recovery, wipe, reopen and Solars economy checked.')
