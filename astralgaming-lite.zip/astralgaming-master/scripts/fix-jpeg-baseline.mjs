#!/usr/bin/env node
/**
 * fix-jpeg-baseline — re-encode shipped artwork to the JPEG shape Telegram
 * will actually accept.
 *
 * Telegram decodes every photo it receives to build its own sizes, and it
 * refuses a handful of perfectly valid JPEG variants on the way: progressive
 * scans above all. The Bot API answers `400 IMAGE_PROCESS_FAILED` AFTER the
 * upload succeeded, which the bot can only degrade into "no picture", so the
 * art itself has to be baseline.
 *
 * adapters/telegram/photo.js normalises photos at send time, but doing that
 * work once here is better: no per-send CPU, no dependency on a native module
 * being present on the host, and the failure is visible in review instead of
 * in a 400 nobody reads.
 *
 *   node scripts/fix-jpeg-baseline.mjs --check        # report, change nothing
 *   node scripts/fix-jpeg-baseline.mjs --all          # fix every shipped JPEG
 *   node scripts/fix-jpeg-baseline.mjs path/a.jpg …   # fix named files
 *
 * Exit code 1 under --check when something needs fixing, so CI can use it.
 */
import { readdirSync, readFileSync, writeFileSync } from 'node:fs'
import { join, relative } from 'node:path'
import { fileURLToPath } from 'node:url'

import { jpegInfo, photoRejectionReason } from '../adapters/telegram/photo.js'

const ROOT = fileURLToPath(new URL('..', import.meta.url))
const SCAN_ROOTS = ['lib/assets', 'images', 'assets']
const JPEG_RE = /\.jpe?g$/i

const args = process.argv.slice(2)
const checkOnly = args.includes('--check')
const all = args.includes('--all')
const named = args.filter((a) => !a.startsWith('--'))

/** Every JPEG under the shipped-asset roots. */
function shippedJpegs() {
  const found = []
  const walk = (dir) => {
    let entries
    try { entries = readdirSync(dir, { withFileTypes: true }) } catch { return }
    for (const entry of entries) {
      const path = join(dir, entry.name)
      if (entry.isDirectory()) {
        if (entry.name !== 'node_modules') walk(path)
      } else if (JPEG_RE.test(entry.name)) {
        found.push(path)
      }
    }
  }
  for (const root of SCAN_ROOTS) walk(join(ROOT, root))
  return found
}

function reasonFor(path) {
  const bytes = readFileSync(path)
  const info = jpegInfo(bytes)
  if (!info) return null // not a JPEG this preflight understands: leave it
  return photoRejectionReason(
    { format: 'jpeg', width: info.width, height: info.height, isProgressive: info.isProgressive },
    bytes.length,
  )
}

async function rewrite(path) {
  const sharp = (await import('sharp')).default
  const before = readFileSync(path)
  const out = await sharp(before)
    .rotate()
    // Telegram rejects width + height over 10,000; 2,560 a side is plenty for
    // anything this bot displays and keeps the sum far under the limit.
    .resize({ width: 2560, height: 2560, fit: 'inside', withoutEnlargement: true })
    .jpeg({ quality: 90, progressive: false, chromaSubsampling: '4:2:0' })
    .toBuffer()
  writeFileSync(path, out)
  return { before: before.length, after: out.length }
}

// --check with no file list means "check everything", which is how CI and
// check-runtime.mjs call it.
const targets = all || (checkOnly && !named.length) ? shippedJpegs() : named.map((p) => join(ROOT, p))
if (!targets.length) {
  console.error('Nothing to do: pass --all or one or more JPEG paths.')
  process.exitCode = 2
} else {
  let broken = 0
  for (const path of targets) {
    const reason = reasonFor(path)
    const label = relative(ROOT, path)
    if (!reason) {
      if (!all) console.log(`[jpeg] ✅ ${label}`)
      continue
    }
    broken += 1
    if (checkOnly) {
      console.log(`[jpeg] ❌ ${label}: ${reason}`)
      continue
    }
    const { before, after } = await rewrite(path)
    console.log(`[jpeg] 🔧 ${label}: ${reason} → baseline (${Math.round(before / 1024)} KB → ${Math.round(after / 1024)} KB)`)
  }
  if (checkOnly) {
    console.log(
      broken
        ? `[jpeg] ${broken} file(s) would be refused by Telegram. Run: node scripts/fix-jpeg-baseline.mjs --all`
        : `[jpeg] ✅ all ${targets.length} shipped JPEGs are baseline`,
    )
    if (broken) process.exitCode = 1
  } else if (broken) {
    console.log(`[jpeg] rewrote ${broken} file(s)`)
  }
}
