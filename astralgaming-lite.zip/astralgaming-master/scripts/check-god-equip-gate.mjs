/** Alenious's four cards must follow the equipped character, not ownership. */
import assert from 'node:assert/strict'
import { ownsGod, battleGodReady } from '../lib/god-series/catalog.js'
import { planGodSummonTurn } from '../lib/god-series/pve.js'

const player = {
  id: 'p1', hp: 100, maxHp: 100, mp: 50, maxMp: 50,
  ownedCharacters: ['alenious'], equippedCharacter: 'someone_else',
  battleState: { turn: 2, enemy: null },
}
const enemy = { id: 'e1', hp: 500, maxHp: 500 }

assert.equal(ownsGod(player, 'alenious'), true, 'ownership stays intact for the shop')
assert.equal(battleGodReady(player, 'alenious'), false, 'an unequipped god is not in the fight')
assert.equal(planGodSummonTurn({ player, enemy, turnId: 2 }), null)

player.equippedCharacter = 'alenious'
assert.equal(battleGodReady(player, 'alenious'), true)
const plan = planGodSummonTurn({ player, enemy, turnId: 2 })
assert.ok(plan, 'the equipped god answers')
assert.ok(plan.lines.some(l => l.includes('I think we can manage without a scene')), 'Alenious speaks when Heart is played')

console.log('Alenious equip gate: ownership kept, battle ability gated, checked.')
