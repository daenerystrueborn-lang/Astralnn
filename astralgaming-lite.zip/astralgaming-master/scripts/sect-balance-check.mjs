/**
 * sect-balance-check.mjs — is a Sect Empire fight as fair as the design says
 * it should be, at every rung of the ladder?
 *
 * WHY. The three balance claims of Part 1 are about WIN RATES, and a win rate
 * is only checkable by playing the fight out. Every number in
 * data/sect-conversion.json `combat` — the damage scale, the damage roll, the
 * crit, the dodge, the initiative margin — exists to make three numbers true:
 *
 *   same stage                         about 50/50
 *   one stage higher inside a realm    about 65%
 *   one full realm higher              95% or more
 *
 * so this script plays them out with basic attacks (the fight of a cultivator
 * who has learned nothing yet), and says what it got.
 *
 *   node scripts/sect-balance-check.mjs        # the pinned check
 *
 * It exits non-zero when a target is missed, which is what makes it a check.
 * The seeds are fixed, so the numbers it prints do not move between runs: if
 * they change, a constant changed. Read it before touching combat.damage,
 * combat.crit, combat.dodge or combat.initiative.
 */
import { REALMS, STAGES, stageBaseStats, stageLabel } from '../lib/sect-cultivation.js'
import {
  applyFightAction, combat, initiativeCfg, makeSide, newFightState,
} from '../lib/sect-combat.js'

/** The targets, and the room a sample this size is allowed. */
export const BALANCE_TARGETS = [
  { id: 'equal', label: 'same stage is about a coin toss', target: 0.50, low: 0.45, high: 0.55 },
  { id: 'stage', label: 'one stage up inside a realm', target: 0.65, low: 0.58, high: 0.72 },
  { id: 'realm', label: 'one full realm up', target: 0.95, low: 0.95, high: 1.01 },
]

/** A fighter of a stage, on basic attacks, with whatever luck the seed brings. */
const fighter = (key, stage, over = {}) => makeSide({
  key,
  name: key === 'a' ? 'player' : 'enemy',
  stage,
  stats: { ...stageBaseStats(stage), ...over },
  techniques: [],
  roots: [],
})

/**
 * How often the side built by `makeA` beats the side built by `makeB`.
 * Both factories are called for EVERY sample: a side is mutated by the fight
 * it is in, and a shared one would carry one fight's damage into the next.
 */
export function winRate(makeA, makeB, { samples = 300, seedBase = 11 } = {}) {
  let wins = 0
  for (let i = 0; i < samples; i++) {
    const state = newFightState({
      a: makeA(), b: makeB(), canFlee: false, real: false, seed: seedBase + i * 7919, now: 1,
    })
    // Both sides on basic attacks: the baseline these numbers were tuned on.
    state.aiWeights = { basic: 100, technique: 0, defend: 0 }
    let guard = 0
    while (!state.over && guard++ < 400) applyFightAction(state, { action: { kind: 'attack' } })
    if (state.outcome === 'win') wins++
  }
  return wins / samples
}

/**
 * The average over every step of the ladder, played BOTH ways round so that
 * the seat a fighter happens to be sitting in cannot flatter a measurement.
 * `edge(lo, hi)` is "how often the higher stage beats the lower one".
 */
export function ladderEdge({ samples = 300 } = {}) {
  const inside = []
  for (const realm of REALMS) {
    const indexes = realm.stages.map(s => s.index)
    for (let i = 0; i + 1 < indexes.length; i++) inside.push([indexes[i], indexes[i + 1]])
  }
  const boundaries = []
  for (let i = 0; i + 1 < REALMS.length; i++) {
    const lower = REALMS[i].stages.map(s => s.index)
    const upper = REALMS[i + 1].stages.map(s => s.index)
    if (!lower.length || !upper.length) continue
    boundaries.push([lower[0], upper[0]])
    boundaries.push([lower[lower.length - 1], upper[upper.length - 1]])
  }

  const average = (pairs) => pairs.reduce((sum, [lo, hi]) => sum
    + (winRate(() => fighter('a', hi), () => fighter('b', lo), { samples, seedBase: 11 })
      + (1 - winRate(() => fighter('a', lo), () => fighter('b', hi), { samples, seedBase: 991 }))) / 2, 0) / pairs.length

  return {
    inside,
    boundaries,
    stage: average(inside),
    realm: average(boundaries),
  }
}

/** How long a fight of one stage against itself runs, in rounds. */
export function fightLength(stage, { samples = 200 } = {}) {
  let rounds = 0
  for (let i = 0; i < samples; i++) {
    const state = newFightState({
      a: fighter('a', stage), b: fighter('b', stage), canFlee: false, real: false, seed: 31 + i * 13, now: 1,
    })
    state.aiWeights = { basic: 100, technique: 0, defend: 0 }
    let guard = 0
    while (!state.over && guard++ < 400) applyFightAction(state, { action: { kind: 'attack' } })
    rounds += state.round
  }
  return rounds / samples
}

/** Play every measurement and score it against the targets. */
export function balanceCheck({ samples = 300, equalSamples = 1500 } = {}) {
  const rungs = [1, 5, 10, 20, 30, 41].filter(s => STAGES.some(x => x.index === s))
  const equal = rungs.reduce((sum, stage) => sum
    + winRate(() => fighter('a', stage), () => fighter('b', stage), { samples: equalSamples, seedBase: 5 }), 0) / rungs.length
  const { stage, realm, inside, boundaries } = ladderEdge({ samples })

  const measured = { equal, stage, realm }
  const results = BALANCE_TARGETS.map(row => {
    const actual = measured[row.id]
    return { ...row, actual, ok: actual >= row.low && actual <= row.high }
  })
  return { results, ok: results.every(r => r.ok), rungs, inside: inside.length, boundaries: boundaries.length }
}

const pct = (v) => `${(v * 100).toFixed(1)}%`.padStart(6)

export function printReport(check, { samples = 300, equalSamples = 1500 } = {}) {
  console.log('SECT COMBAT BALANCE CHECK')
  console.log(`damage: attack x${combat.damage.attackScale}  defense x${combat.damage.defenseScale}`
    + `  roll ${combat.damage.rollMin}-${combat.damage.rollMax}  min ${combat.damage.minDamage}`)
  console.log(`crit: ${combat.crit.base} + ${combat.crit.perFortune}/fortune, capped at ${combat.crit.max}, x${combat.crit.multiplier}`)
  console.log(`dodge: ${combat.dodge.base} + ${combat.dodge.perSpeed}/speed, capped at ${combat.dodge.max}`)
  console.log(`initiative: faster side first; within ${initiativeCfg.tieMargin} of each other counts as tied,`
    + ' and a tie alternates, the player taking the opening round\n')
  console.log('basic attacks only, both sides, no techniques:')
  for (const row of check.results) {
    console.log(`  ${row.ok ? 'OK  ' : 'OFF '} ${row.label.padEnd(32)} ${pct(row.actual)}   target ${(row.target * 100).toFixed(0)}%`
      + `  (${(row.low * 100).toFixed(0)}-${(row.high * 100).toFixed(0)}%)`)
  }
  console.log(`\n  measured over ${check.inside} stage steps and ${check.boundaries} realm steps, both ways round,`
    + ` ${samples} fights each (${equalSamples} for the coin toss).`)
  console.log('  rounds per same-stage fight:', check.rungs.map(s => `${s}:${fightLength(s).toFixed(2)}`).join('  '))
  console.log('  rungs:', check.rungs.map(s => `${s} ${stageLabel(s)}`).join(' · '))
}

if (process.argv[1] && import.meta.url === `file://${process.argv[1]}`) {
  const samples = Math.max(20, Number(process.env.N) || 300)
  const equalSamples = Math.max(50, Number(process.env.EQ) || 1500)
  const check = balanceCheck({ samples, equalSamples })
  printReport(check, { samples, equalSamples })
  console.log(check.ok
    ? '\n  every target is met.'
    : '\n  ⚠️ a target is off: the constants in data/sect-conversion.json combat no longer agree with this run.')
  process.exit(check.ok ? 0 : 1)
}
