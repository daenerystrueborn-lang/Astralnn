#!/usr/bin/env node
/**
 * scripts/check-dungeon-difficulty.mjs — Verifies hardened dungeon monster tuning:
 *   1. Regular & Elite monsters carry stronger HP, ATK, and depth-scaled DEF across both
 *      Swarm and Solo 1v1 dungeons.
 *   2. Newcomer's Hollow tutorial band (Lv. 1–10) stays protected by `applyBeginnerBudget`.
 *   3. Caged Dimension retains its godly `LOCATION_DIFFICULTY` profile.
 *   4. Over-leveled / Veteran (Lv. 100–200) scaling + raised `DUNGEON_HP_LIMITS` scale past
 *      the old 30k/45k/75k caps cleanly.
 *   5. Swarm Floor-10 Apprentice mini-bosses and Veteran packs carry hardened multipliers.
 *   6. Monster tracking accuracy, active ability triggers, and tactical cleaves function cleanly.
 *   7. `lib/version.js` top entry (`3.16.3`) has zero dashes.
 */

import assert from 'node:assert/strict'
import os from 'node:os'
import path from 'node:path'
import fs from 'node:fs'

const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'astral-dungeon-diff-'))
process.env.RUNTIME_DATA_DIR = tmpDir

const { regularByLoc } = await import('../lib/game-data.js')
const {
  pickMonsterForFloor,
  monsterStatsAtFloor,
  applyDefense,
  enemyPowerRatio,
  scaleEnemyToPlayer,
  scaleBossToPlayer,
  applyVeteranScaling,
  veteranTier,
  calcMonsterHitChance,
} = await import('../lib/combat-engine.js')
const { expectedLevelAtFloor } = await import('../lib/xp-regulator.js')
const { getTotalStats } = await import('../lib/game-data.js')
const { DUNGEON_HP_LIMITS, limitDungeonHp } = await import('../lib/dungeon-hp-budget.js')
const { applyBeginnerBudget } = await import('../lib/beginner-combat.js')
const { buildSwarmFloor } = await import('../lib/swarm-combat.js')
const { applyMonsterAbilityTurn } = await import('../lib/monster-abilities.js')
const { armEndlessSurvival, advanceEndlessSurvival } = await import('../lib/endless-survival.js')
const { CHANGELOG } = await import('../lib/version.js')

let passed = 0
function check(name, fn) {
  fn()
  passed++
  console.log(`  ✅ ${name}`)
}

check('1. Solo 1v1 and Swarm dungeon monsters carry substantially higher HP, ATK, and deep-floor DEF', () => {
  const boilPool = regularByLoc.boiling_rock.filter((m) => m.tier === 'regular' && 99 >= m.floorRange[0] && 99 <= m.floorRange[1])
  const boil99 = monsterStatsAtFloor(boilPool[0], 99)
  assert.ok(boil99.hp >= 4000, `Expected Boiling Rock F99 regular HP >= 4000, got ${boil99.hp}`)
  assert.ok(boil99.atk >= 500, `Expected Boiling Rock F99 regular ATK >= 500, got ${boil99.atk}`)

  const boil1 = monsterStatsAtFloor(regularByLoc.boiling_rock.find((m) => m.tier === 'regular'), 1)
  assert.ok(boil99.def > boil1.def, `Expected deep-floor DEF (${boil99.def}) > shallow DEF (${boil1.def})`)

  const centPool = regularByLoc.centurions_dungeon.filter((m) => m.tier === 'regular' && 99 >= m.floorRange[0] && 99 <= m.floorRange[1])
  const cent99 = monsterStatsAtFloor(centPool[0], 99)
  assert.ok(cent99.hp >= 2600, `Expected Centurion F99 swarm member HP >= 2600, got ${cent99.hp}`)

  const eliteDef = regularByLoc.boiling_rock.find((m) => m.tier === 'elite')
  if (eliteDef) {
    const eliteStats = monsterStatsAtFloor(eliteDef, eliteDef.floorRange[1])
    const regStats = monsterStatsAtFloor(boilPool[0], eliteDef.floorRange[1])
    assert.ok(eliteStats.hp > regStats.hp * 1.6, 'Elite HP must strongly exceed regular HP')
    assert.ok(eliteStats.atk > regStats.atk * 1.15, 'Elite ATK must exceed regular ATK')
  }
})

check('2. Newcomer Hollow tutorial floors (Lv. 1–10) stay protected by applyBeginnerBudget', () => {
  const m = pickMonsterForFloor('newbie_hollow', 1, regularByLoc)
  applyBeginnerBudget(m, 'newbie_hollow', 1)
  assert.ok(m.hp <= 75, `Expected tutorial F1 monster HP <= 75, got ${m.hp}`)
  assert.ok(m.atk <= 15, `Expected tutorial F1 monster ATK <= 15, got ${m.atk}`)
})

check('3. Caged Dimension keeps its godly difficulty overrides (~20+ hits to clear, ~2 hits to die)', () => {
  const cagedReg = regularByLoc.caged_dimension.find((m) => m.tier === 'regular')
  const st = monsterStatsAtFloor(cagedReg, 50)
  const lv = expectedLevelAtFloor('caged_dimension', 50)
  const naked = getTotalStats('warrior', 'human', lv)
  const clearHits = Math.ceil(st.hp / Math.max(1, applyDefense(naked.str + 230, st.def)))
  assert.ok(clearHits >= 15, `Expected Caged Dimension regular to take >= 15 geared hits, got ${clearHits}`)
  assert.ok(st.def >= 180, `Expected Caged Dimension 6x DEF floor >= 180, got ${st.def}`)
})

check('4. Geared + Veteran (Lv. 200) scaling and DUNGEON_HP_LIMITS allow tough endgame encounters', () => {
  assert.strictEqual(DUNGEON_HP_LIMITS.regular, 85_000)
  assert.strictEqual(DUNGEON_HP_LIMITS.elite, 135_000)
  assert.strictEqual(DUNGEON_HP_LIMITS.boss, 250_000)

  const whale = {
    level: 200,
    classId: 'warrior',
    stats: { str: 2400, agi: 600, int: 300, def: 1200, lck: 200 },
    activeEffects: [],
  }
  const tier = veteranTier(whale)
  assert.strictEqual(tier.hpMult, 3.4)
  assert.strictEqual(tier.atkMult, 2.2)
  assert.strictEqual(tier.defMult, 1.8)

  const mob = pickMonsterForFloor('boiling_rock', 95, regularByLoc)
  const ratio = enemyPowerRatio(whale, 'boiling_rock', 95)
  scaleEnemyToPlayer(mob, ratio, { hpExp: 0.95, atkExp: 0.68, defExp: 0.42 })
  applyVeteranScaling(mob, whale)
  limitDungeonHp(mob)
  assert.ok(mob.hp > 35_000, `Expected Lv.200 scaled monster HP > old 30k cap, got ${mob.hp}`)

  const boss = { name: 'Warden', isBoss: true, hp: 32_000, maxHp: 32_000, atk: 1200, def: 400, baseAtk: 1200, baseDef: 400 }
  scaleBossToPlayer(boss, whale, ratio)
  applyVeteranScaling(boss, whale)
  limitDungeonHp(boss, { boss: true })
  assert.ok(boss.hp > 85_000, `Expected Lv.200 scaled boss HP > old 75k cap, got ${boss.hp}`)
})

check('5. Swarm Floor-10 Apprentice checkpoints spawn hardened mini-boss packs', () => {
  const whale = {
    level: 160,
    classId: 'warrior',
    stats: { str: 1600, agi: 400, int: 200, def: 800, lck: 120 },
    activeEffects: [],
  }
  const built = buildSwarmFloor('centurions_dungeon', 40, whale)
  assert.ok(built && built.isApprentice && built.monsters.length >= 2)
  const app = built.monsters.find((m) => m.apprentice)
  assert.ok(app && app.hp > 12_000, `Expected Apprentice mini-boss HP > 12000, got ${app?.hp}`)
})

check('6. Monster accuracy, active abilities, and unguarded survival cleaves hit reliably', () => {
  const agilePlayer = {
    hp: 4000,
    maxHp: 4000,
    stats: { str: 400, agi: 900, int: 200, def: 300, lck: 100 },
    activeEffects: [],
  }
  const eliteEnemy = {
    id: 'test_elite',
    name: 'Iron Fang',
    tier: 'elite',
    hp: 6000,
    maxHp: 6000,
    atk: 700,
    def: 350,
    abilities: [
      { id: 'rend', name: 'Crimson Rend', chance: 0.35, cooldown: 2, effect: { type: 'strike', multiplier: 1.5 } },
    ],
  }
  const hitChance = calcMonsterHitChance(eliteEnemy, agilePlayer)
  assert.ok(hitChance >= 0.72, `Expected Elite hit chance vs max-dodge player >= 0.72, got ${hitChance}`)

  const lines = []
  const abRes = applyMonsterAbilityTurn({
    player: agilePlayer,
    enemy: eliteEnemy,
    state: { turn: 2 },
    lines,
    baseDamage: 400,
    rng: () => 0.40, // 0.35 * 1.45 = 0.5075 > 0.40, so ability fires!
  })
  assert.strictEqual(abRes.fired, true, 'Elite ability should fire at rng=0.40 under boosted trigger rate')
  assert.ok(abRes.bonusDamage > 0)

  armEndlessSurvival(eliteEnemy)
  // Step 1: probe -> cleave
  advanceEndlessSurvival({ enemy: eliteEnemy, turn: 1, defending: false, playerDef: 300, action: 'attack' })
  // Step 2: unguarded cleave lands heavy bonus damage
  const cleaveUnguarded = advanceEndlessSurvival({ enemy: eliteEnemy, turn: 2, defending: false, playerDef: 300, action: 'attack' })
  assert.ok(cleaveUnguarded.extraDamage > 350, `Expected heavy unguarded cleave > 350, got ${cleaveUnguarded.extraDamage}`)
})

check('7. lib/version.js top entry obeys strict no-dash rule', () => {
  const top = CHANGELOG[0]
  assert.ok(top && top.version, 'top changelog entry must exist')
  for (const line of top.notes) {
    assert.ok(!/[-–—]/.test(line), `Dash found in changelog note: ${line}`)
  }
})

fs.rmSync(tmpDir, { recursive: true, force: true })
console.log(`\n🎉 All ${passed}/7 dungeon monster difficulty checks passed!`)
