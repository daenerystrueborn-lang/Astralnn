/**
 * validate-named-recipes.js
 *
 * Sanity-checks the named-weapon forging system:
 *   1. Every material itemId in named-category recipes exists in boss-trophies.json
 *   2. Every recipe output id in named-category recipes exists in named-weapons.json
 *
 * Run from the project root:
 *   node scripts/validate-named-recipes.js
 */

import { createRequire } from 'module'
import { allItems } from '../lib/game-data.js'
const require = createRequire(import.meta.url)

const recipes      = require('../data/recipes.json')
const bossTrophies = require('../data/boss-trophies.json')
const namedWeapons = require('../data/named-weapons.json')
const bossGear     = require('../data/boss-gear.json')

const trophyById   = new Map(bossTrophies.map(t => [t.id, t]))
const materialIds  = new Set(allItems.map(i => i.id))
const namedItemIds = new Set([
  ...namedWeapons.map(w => w.id),
  ...bossGear.map(g => g.id),
])
const namedRecipes = recipes.filter(r => r.category === 'named')

let errors = 0

console.log(`\n🔍 Validating ${namedRecipes.length} named-weapon / boss-gear recipes...\n`)

for (const recipe of namedRecipes) {
  // Check output id
  if (!namedItemIds.has(recipe.output)) {
    console.error(`❌ [${recipe.id}] output "${recipe.output}" NOT FOUND in named-weapons.json or boss-gear.json`)
    errors++
  } else {
    console.log(`✅ [${recipe.id}] output "${recipe.output}" — OK`)
  }

  // Check each material
  for (const { itemId, qty } of recipe.materials) {
    if (!materialIds.has(itemId)) {
      console.error(`   ❌ material "${itemId}" (qty ${qty}) NOT FOUND in boss-trophies.json / materials.json / items.json`)
      errors++
    } else if (trophyById.has(itemId)) {
      const trophy = trophyById.get(itemId)
      console.log(`   ✅ material "${itemId}" (boss: ${trophy.sourceBoss}, rarity: ${trophy.rarity})`)
    } else {
      console.log(`   ✅ material "${itemId}" (qty ${qty})`)
    }
  }
}

console.log('\n' + '─'.repeat(60))
if (errors === 0) {
  console.log(`✅  All ${namedRecipes.length} recipes passed validation — no mismatches found.\n`)
} else {
  console.error(`❌  ${errors} mismatch(es) found — fix the ids above before shipping.\n`)
  process.exit(1)
}
