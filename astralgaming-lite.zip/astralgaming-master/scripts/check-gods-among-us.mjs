#!/usr/bin/env node
/**
 * check-gods-among-us.mjs — end-to-end verification for Book 2 (*Gods Among Us*),
 * its 50-gem unlock gate, the remembered-light tally + `iflight` branching,
 * self-hosted original artwork, Chains of Resurrection, and Amiya's combat
 * passive (*The Star That Remembers*) fought through the real damage funnels.
 *
 * Run: node scripts/check-gods-among-us.mjs
 */
process.env.NODE_ENV = 'test'
import { readFileSync, existsSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = dirname(fileURLToPath(import.meta.url))
const ROOT = join(__dirname, '..')

const { storyVolumes, characters, allItems } = await import('../lib/game-data.js')
const {
  getVolume,
  findVolumeByName,
  ensureStoryProgress,
  getChapter,
  getResolvedBeats,
  choiceKeyFor,
  recordChoice,
  advanceBeat,
  resolveBattle,
  resolvePlea,
  completeChapter,
  isVolumePurchased,
  purchaseVolume,
  openStoryBattle,
  applyStoryBattleMove,
  checkDetourLock,
  clearDetourLock,
} = await import('../lib/story-engine.js')
const {
  isInteractiveStoryBattle,
  initStoryBattle,
  stepStoryBattle,
  currentEnemyIntent,
  resolveStoryBattleInput,
  renderStoryBattleCard,
} = await import('../lib/story-battle.js')
const { hasPendingStoryChoice } = await import('../plugins/story.js')
const { applyIncomingDamage } = await import('../lib/character-abilities.js')
const { calcPlayerDamage } = await import('../lib/combat-engine.js')
const { localPathForAssetUrl } = await import('../lib/self-hosted-asset.js')
const { jpegInfo, photoRejectionReason } = await import('../adapters/telegram/photo.js')
const { BOT_VERSION, VERSION_CODENAME, VERSION_DATE, CHANGELOG } = await import('../lib/version.js')

let pass = 0, fail = 0
const ok = (cond, label) => {
  if (cond) { pass++; console.log('  ✓', label) }
  else { fail++; console.error('  ✗ FAIL:', label) }
}
const section = name => console.log(`\n=== ${name} ===`)

// ── 1. Volume registration & schema invariants ──────────────────────────────
section('1. Story volumes & Book 2 structure')
{
  const book1 = getVolume('beyond-the-astral')
  const book2 = getVolume('gods-among-us')
  ok(Boolean(book1) && book1.chapters.length === 20, 'Book 1 (Beyond the Astral) still loads cleanly with 20 chapters')
  ok(Boolean(book2) && book2.chapters.length === 20, 'Book 2 (Gods Among Us) loads with 20 chapters')
  ok(storyVolumes.length >= 2, `storyVolumes exports both volumes (${storyVolumes.map(v => v.id).join(', ')})`)
  ok(findVolumeByName('gods among us')?.id === 'gods-among-us', 'findVolumeByName resolves "gods among us"')
  ok(book2.unlock?.gems === 50, 'Book 2 unlock price is 50 gems')
  ok(Array.isArray(book2.introLines) && book2.introLines.length === 2, 'Book 2 carries its own intro epigraph lines')

  // Verify mirror light sum in Chapter 6 and iflight placement in Ch17/19/20 only
  const ch6 = getChapter(book2, 6)
  let maxLight = 0, mirrorChoices = 0
  for (const b of ch6.beats) {
    if (b.type === 'choice') {
      mirrorChoices++
      maxLight += Math.max(0, ...(b.options ?? []).map(o => Number(o.light ?? 0)))
    }
  }
  ok(mirrorChoices === 7, `Chapter 6 (City of Glass) has 7 mirror choices (got ${mirrorChoices})`)
  ok(maxLight === 8, `Chapter 6 maximum light tally is 8 (six +1s and one +2; got ${maxLight})`)

  const iflightChapters = []
  let duplicateLongBeats = 0
  let totalVolumeBeats = 0
  let minChapterBeats = Infinity
  const interactiveBattles = []
  const walkRaw = (beats, visit) => {
    for (const b of beats ?? []) {
      visit(b)
      for (const o of b.options ?? []) walkRaw(o.beats, visit)
      if (b.type === 'iflight') { walkRaw(b.beats, visit); walkRaw(b.elseBeats, visit) }
    }
  }
  for (const ch of book2.chapters) {
    let hasIflight = false
    let chBeats = 0
    const seen = new Map()
    walkRaw(ch.beats, b => {
      if (b.type !== 'iflight') chBeats++
      if (b.type === 'iflight') hasIflight = true
      if (b.type === 'battle') interactiveBattles.push({ ch: ch.num, beat: b })
      if (typeof b.text === 'string') {
        const t = b.text.trim()
        if (t.length > 25 && t !== '---') {
          seen.set(t, (seen.get(t) ?? 0) + 1)
        }
      }
    })
    minChapterBeats = Math.min(minChapterBeats, chBeats)
    totalVolumeBeats += chBeats
    for (const [, count] of seen) if (count > 1) duplicateLongBeats++
    if (hasIflight) iflightChapters.push(ch.num)
  }
  ok(totalVolumeBeats >= 2750, `expanded volume carries >= 2,750 beats across 20 chapters (got ${totalVolumeBeats})`)
  ok(minChapterBeats >= 125, `every chapter in Book 2 carries >= 125 beats (min chapter has ${minChapterBeats})`)
  ok(interactiveBattles.length === 12 && interactiveBattles.every(x => isInteractiveStoryBattle(x.beat)), `all 12 Book 2 battles are interactive fixed-loadout Story Battles`)
  ok(JSON.stringify(iflightChapters) === JSON.stringify([17, 19, 20]), `iflight appears exclusively in Ch17, Ch19, Ch20 (got ${iflightChapters.join(',')})`)
  ok(duplicateLongBeats === 0, `zero duplicate long prose beats inside any chapter (got ${duplicateLongBeats})`)

  const ch20 = getChapter(book2, 20)
  ok(
    ch20.onComplete?.grantsCharacter === 'amiya' &&
    JSON.stringify(ch20.onComplete?.items) === JSON.stringify(['chains-of-resurrection']),
    'Chapter 20 onComplete grants Amiya and Chains of Resurrection',
  )
}

// ── 2. Paid volume purchase flow ────────────────────────────────────────────
section('2. One-time 50-gem unlock gate')
{
  const book1 = getVolume('beyond-the-astral')
  const book2 = getVolume('gods-among-us')
  const p = { wallet: { gems: 30 }, storyProgress: { volumes: {} } }

  ok(isVolumePurchased(p, book1) === true, 'Book 1 remains free and unconditionally purchased')
  ok(isVolumePurchased(p, book2) === false, 'Book 2 starts locked before purchase')

  const short = purchaseVolume(p, book2)
  ok(short.ok === false && short.shortfall === 20 && p.wallet.gems === 30, 'insufficient gems refused cleanly with zero deduction')
  ok(isVolumePurchased(p, book2) === false, 'failed purchase leaves volume locked')

  p.wallet.gems = 80
  const bought = purchaseVolume(p, book2)
  ok(bought.ok === true && bought.gems === 50 && p.wallet.gems === 30, 'buying Book 2 deducts 50 gems once (80 -> 30)')
  ok(isVolumePurchased(p, book2) === true, 'Book 2 reports purchased after payment')

  const again = purchaseVolume(p, book2)
  ok(again.ok === true && again.already === true && p.wallet.gems === 30, 'repeat purchase call is idempotent and never charges twice')
}

// ── 3. Full 20-chapter playthroughs (Quiet light=0 vs Bright light=8) ───────
section('3. Full 20-chapter walkthroughs & ending split')
{
  const book2 = getVolume('gods-among-us')

  function playWholeVolume(pickBrightMirrors) {
    const p = {
      xp: 0, level: 10,
      stats: { str: 20, agi: 20, int: 20, def: 20, lck: 5 },
      wallet: { gems: 100 },
      ownedCharacters: [],
      inventory: [],
      storyFlags: [],
      storyProgress: { volumes: {} },
    }
    purchaseVolume(p, book2)
    const prog = ensureStoryProgress(p, 'gods-among-us')
    prog.seenIntro = true
    p.storyProgress.activeVolume = 'gods-among-us'

    const chapterTranscripts = {}
    let leakedIflight = 0

    for (let chNum = 1; chNum <= 20; chNum++) {
      const ch = getChapter(book2, chNum)
      ok(prog.currentChapter === chNum, `[${pickBrightMirrors ? 'bright' : 'quiet'}] enters ch${chNum}`)
      const lines = []
      while (true) {
        const beats = getResolvedBeats(book2, p, 'gods-among-us', ch)
        if (beats.some(b => b.type === 'iflight')) leakedIflight++
        const idx = prog.currentBeat
        if (idx >= beats.length) break
        const beat = beats[idx]
        lines.push(beat.text)
        if (beat.type === 'choice') {
          const opts = beat.options ?? []
          const chosen = pickBrightMirrors
            ? [...opts].sort((a, b) => Number(b.light ?? 0) - Number(a.light ?? 0))[0]
            : [...opts].sort((a, b) => Number(a.light ?? 0) - Number(b.light ?? 0))[0]
          recordChoice(p, 'gods-among-us', ch.id, chosen.id, choiceKeyFor(beat, ch.id), chosen.light ?? 0)
          advanceBeat(p, 'gods-among-us')
          continue
        }
        if (beat.type === 'battle' && isInteractiveStoryBattle(beat)) {
          openStoryBattle(p, 'gods-among-us', beat, ch.num, idx)
          let safety = 0
          while (prog.activeBattle && safety++ < 30) {
            const st = prog.activeBattle
            const intent = currentEnemyIntent(st)
            const disruptMove = st.moves.find(m => m.kind === 'disrupt' && (st.usesLeft[m.id] ?? 1) > 0)
            const guardMove = st.moves.find(m => m.kind === 'guard')
            const healMove = st.moves.find(m => m.kind === 'heal' && (st.usesLeft[m.id] ?? 1) > 0)
            const atkMove = st.moves.find(m => m.kind === 'attack') ?? st.moves[0]
            let pick = atkMove.id
            if (intent.heavy) pick = (disruptMove ?? guardMove ?? atkMove).id
            else if (st.hp <= st.maxHp * 0.45 && healMove && !st.counterPrimed && !st.enemyExposed) pick = healMove.id
            const step = applyStoryBattleMove(p, 'gods-among-us', pick, () => 0.25, beat.encounter?.resumeLine)
            if (step.outcome === 'win') lines.push(beat.encounter.onWin)
            else if (step.outcome === 'lose') throw new Error(`Unexpected tactical loss in ch${ch.num} vs ${beat.encounter.enemyName}`)
          }
        } else if (beat.type === 'battle') {
          const res = resolveBattle(beat)
          if (res.text) lines.push(res.text)
        } else if (beat.type === 'plea') {
          const res = resolvePlea(beat)
          if (res.text) lines.push(res.text)
        }
        if (idx >= beats.length - 1) break
        advanceBeat(p, 'gods-among-us')
      }
      chapterTranscripts[chNum] = lines.join('\n')
      const summary = completeChapter(p, book2, 'gods-among-us', ch, { gemsPerChapter: 5, xpPerChapter: 0 })
      if (chNum === 20) {
        ok(summary.isFinalChapter === true, `[${pickBrightMirrors ? 'bright' : 'quiet'}] ch20 triggers final-chapter completion`)
      }
    }
    return { player: p, progress: prog, transcripts: chapterTranscripts, leakedIflight }
  }

  const quietRun = playWholeVolume(false)
  const brightRun = playWholeVolume(true)

  ok(quietRun.leakedIflight === 0 && brightRun.leakedIflight === 0, 'iflight markers are always expanded and never emitted as raw beats')
  ok(quietRun.progress.light === 0, `quiet playthrough ends with light === 0 (got ${quietRun.progress.light})`)
  ok(brightRun.progress.light === 8, `bright playthrough ends with light === 8 (got ${brightRun.progress.light})`)
  ok(quietRun.progress.completed && brightRun.progress.completed, 'both playthroughs mark gods-among-us completed')
  ok(
    brightRun.player.ownedCharacters.includes('amiya') &&
    brightRun.player.inventory.includes('chains-of-resurrection'),
    'completion unlocks Amiya and grants Chains of Resurrection',
  )
  ok(quietRun.transcripts[17] !== brightRun.transcripts[17], 'Ch17 (The Fourth Wall) varies between quiet and bright light tallies')
  ok(quietRun.transcripts[19] !== brightRun.transcripts[19], 'Ch19 (Why Would You Do That) varies between quiet and bright light tallies')
  ok(quietRun.transcripts[20] !== brightRun.transcripts[20], 'Ch20 (All the Colors) varies between quiet and bright light tallies')
  ok(
    quietRun.transcripts[20].endsWith('It was never all white. It just needed someone to look.') &&
    brightRun.transcripts[20].endsWith('It was never all white. It just needed someone to look.'),
    'both endings close on the canonical final line',
  )
}

// ── 3B. Interactive Story Battle Mode (loadout isolation & real consequences) ─
section('3B. Interactive Story Battle Mode — fixed kit, telegraphs & defeat penalty')
{
  const book2 = getVolume('gods-among-us')
  const allBattles = []
  for (const ch of book2.chapters) {
    ch.beats.forEach((b, idx) => {
      if (b.type === 'battle') allBattles.push({ ch, idx, beat: b })
    })
  }
  ok(allBattles.length === 12, `collected all 12 Story Battles across Book 2 (${allBattles.map(x => `Ch${x.ch.num}:${x.beat.encounter.enemyName}`).join(', ')})`)

  // Verify EVERY battle: (a) blind basic-attack mashing loses even on lucky rolls,
  // and (b) reading telegraphs wins even on worst rolls!
  let mashLosses = 0
  let smartWins = 0
  for (const { ch, idx, beat } of allBattles) {
    let stMash = initStoryBattle(beat, ch.num, idx)
    let mOut = null
    const atkId = stMash.moves.find(m => m.kind === 'attack').id
    for (let t = 0; t < 25; t++) {
      mOut = stepStoryBattle(stMash, atkId, () => 0.99)
      if (mOut.outcome !== 'ongoing') break
      stMash = mOut.state
    }
    if (mOut?.outcome === 'lose') mashLosses++

    let stSmart = initStoryBattle(beat, ch.num, idx)
    let sOut = null
    for (let t = 0; t < 25; t++) {
      const intent = currentEnemyIntent(stSmart)
      const dis = stSmart.moves.find(m => m.kind === 'disrupt' && (stSmart.usesLeft[m.id] ?? 1) > 0)
      const grd = stSmart.moves.find(m => m.kind === 'guard')
      const hl = stSmart.moves.find(m => m.kind === 'heal' && (stSmart.usesLeft[m.id] ?? 1) > 0)
      const atk = stSmart.moves.find(m => m.kind === 'attack')
      let moveId = atk.id
      if (intent.heavy) moveId = (dis ?? grd).id
      else if (stSmart.hp <= stSmart.maxHp * 0.45 && hl && !stSmart.counterPrimed && !stSmart.enemyExposed) moveId = hl.id
      sOut = stepStoryBattle(stSmart, moveId, () => 0.0)
      if (sOut.outcome !== 'ongoing') break
      stSmart = sOut.state
    }
    if (sOut?.outcome === 'win') smartWins++
  }
  ok(mashLosses === 12, `blindly mashing attack loses all 12/12 Story Battles (got ${mashLosses}/12)`)
  ok(smartWins === 12, `reading telegraphs wins all 12/12 Story Battles even on 0.0 rolls (got ${smartWins}/12)`)

  // Verify RPG-stat isolation + DM pending gate + real defeat consequence on Ch1
  const ch1 = getChapter(book2, 1)
  const overleveledPlayer = {
    level: 100,
    hp: 999999,
    maxHp: 999999,
    stats: { str: 99999, int: 99999, def: 99999, agi: 99999, lck: 99999 },
    equippedCharacter: 'gojo',
    ownedCharacters: ['gojo', 'kurama'],
    inventory: ['excalibur', 'potion'],
    wallet: { gems: 100 },
    storyProgress: { activeVolume: 'gods-among-us', volumes: {} },
  }
  purchaseVolume(overleveledPlayer, book2)
  const prog = ensureStoryProgress(overleveledPlayer, 'gods-among-us')
  prog.seenIntro = true
  const ch1Beats = getResolvedBeats(book2, overleveledPlayer, 'gods-among-us', ch1)
  const battleIdx = ch1Beats.findIndex(b => b.type === 'battle')
  prog.currentBeat = battleIdx
  const ch1BattleBeat = ch1Beats[battleIdx]

  const opened = openStoryBattle(overleveledPlayer, 'gods-among-us', ch1BattleBeat, 1, battleIdx)
  ok(
    opened.battle.hp === 88 && opened.battle.atk === 18 && opened.battle.fighter === 'Ren',
    'level-100 account with 99,999 stats still enters Ch1 battle with Ren fixed 88 HP / 18 ATK scavenged kit',
  )
  ok(hasPendingStoryChoice(overleveledPlayer) === true, 'hasPendingStoryChoice intercepts plain-text DM moves while Story Battle is active')
  ok(/Dull Penknife & Masonry Brick/.test(renderStoryBattleCard(opened.battle)), 'battle card renders Ren exact scavenged kit and enemy telegraph')
  ok(resolveStoryBattleInput(opened.battle, 'summon kurama').error === 'outside_kit', 'trying to summon outside RPG gear/beasts is rejected with outside_kit')
  ok(resolveStoryBattleInput(opened.battle, 'flee').error === 'outside_kit', 'trying to flee a story battle is rejected with outside_kit')

  // Intentionally lose by mashing basic attack 1 -> verify lock + chapter gem penalty!
  let lossStep = null
  for (let t = 0; t < 10; t++) {
    lossStep = applyStoryBattleMove(overleveledPlayer, 'gods-among-us', 'slash', () => 0.5, ch1BattleBeat.encounter.resumeLine)
    if (lossStep.outcome !== 'ongoing') break
  }
  ok(lossStep?.outcome === 'lose', 'reckless mashing knocks Ren out in Ch1 Story Battle')
  ok(prog.currentBeat === battleIdx && prog.activeBattle === null, 'defeat leaves currentBeat on the unbeaten battle (cannot skip past a loss)')
  ok(prog.lostInCurrentChapter === true && prog.battleLosses === 1, 'defeat records lostInCurrentChapter and increments battleLosses')
  const lock = checkDetourLock(overleveledPlayer, 'gods-among-us')
  ok(lock.locked === true && lock.retryAt > Date.now() + 14 * 60 * 1000, 'defeat imposes 15-minute wound recovery lock before retrying')

  const resumeText = clearDetourLock(overleveledPlayer, 'gods-among-us')
  ok(Boolean(resumeText), 'clearing recovery lock emits Ren recovery narrative line')

  // When chapter eventually completes after a defeat, gems drop 5 -> 2
  const preGems = overleveledPlayer.wallet.gems
  const penalizedSummary = completeChapter(overleveledPlayer, book2, 'gods-among-us', ch1, { gemsPerChapter: 5, xpPerChapter: 0 })
  ok(
    penalizedSummary.battlePenaltyApplied === true &&
    penalizedSummary.gemsAward === 2 &&
    overleveledPlayer.wallet.gems === preGems + 2,
    'chapter clear after a Story Battle defeat reduces gem reward from 5💎 to 2💎 (-3💎 wound penalty)',
  )
}

// ── 4. Multi-volume pending-choice coexistence ──────────────────────────────
section('4. Multi-volume activeVolume coexistence')
{
  const book1 = getVolume('beyond-the-astral')
  const book2 = getVolume('gods-among-us')
  const p = { wallet: { gems: 100 }, storyProgress: { volumes: {} } }
  purchaseVolume(p, book2)
  const prog1 = ensureStoryProgress(p, 'beyond-the-astral')
  prog1.seenIntro = true
  const b1Beats = getResolvedBeats(book1, p, 'beyond-the-astral', getChapter(book1, 1))
  prog1.currentBeat = b1Beats.findIndex(b => b.type === 'choice')

  const prog2 = ensureStoryProgress(p, 'gods-among-us')
  prog2.seenIntro = true
  const b2Beats = getResolvedBeats(book2, p, 'gods-among-us', getChapter(book2, 1))
  prog2.currentBeat = b2Beats.findIndex(b => b.type === 'choice')
  p.storyProgress.activeVolume = 'gods-among-us'

  ok(prog1.currentBeat >= 0 && prog2.currentBeat >= 0, 'both volumes have a pending choice in Ch1')
  ok(hasPendingStoryChoice(p) === true, 'hasPendingStoryChoice detects pending choice with two active volumes')
}

// ── 5. Catalog entries & self-hosted baseline JPEGs ─────────────────────────
const { isMondBuyable, mondPriceFor } = await import('../lib/monds.js')
section('5. Amiya 5★ Ascendant character, non-Mond gate, Chains relic & artwork')
{
  const amiya = characters.find(c => c.id === 'amiya')
  ok(Boolean(amiya), 'Amiya exists in data/characters.json')
  ok(
    amiya?.stars === 5 && amiya?.rarity === 'ascendant' &&
    amiya?.mondBuyable === false && amiya?.exclusive === false &&
    amiya?.storyVolume === 'GODS AMONG US' &&
    amiya?.image === 'https://i.postimg.cc/sD4KfTdN/Hahiwara-Sakutaro.jpg' &&
    amiya?.combat?.atkType === 'int' && amiya?.combat?.atk === 5700 &&
    amiya?.combat?.def === 5400 && amiya?.combat?.agi === 5200 &&
    amiya?.statBonuses?.int === 68 && amiya?.statBonuses?.maxHp === 320,
    'Amiya matches 5★ Ascendant INT 5700 / DEF 5400 / AGI 5200 Story Mode exclusive spec & portrait URL',
  )
  ok(
    isMondBuyable(amiya) === false && mondPriceFor(amiya) === null,
    'Amiya is NOT buyable with Monds (isMondBuyable === false, mondPriceFor === null)',
  )

  const chains = allItems.find(i => i.id === 'chains-of-resurrection')
  ok(Boolean(chains), 'Chains of Resurrection exists in data/items.json')
  ok(
    chains?.slot === 'offhand' && chains?.exclusive === true &&
    chains?.statBonuses?.int === 25 && chains?.statBonuses?.def === 25 && chains?.statBonuses?.maxHp === 100,
    'Chains of Resurrection matches offhand +25 INT / +25 DEF / +100 MaxHP exclusive spec',
  )

  const gauVol = getVolume('gods-among-us')
  ok(
    gauVol?.coverImage === 'https://i.postimg.cc/hvD8xkNZ/gods-among-us.jpg',
    'Gods Among Us coverImage points to official https://i.postimg.cc/hvD8xkNZ/gods-among-us.jpg URL',
  )

  for (const file of ['chains-of-resurrection.jpg']) {
    const relUrl = `/assets/gods-among-us/${file}`
    const resolved = localPathForAssetUrl(relUrl)
    ok(Boolean(resolved) && existsSync(resolved), `self-hosted mount resolves ${relUrl} to disk`)
    const buf = readFileSync(join(ROOT, 'lib', 'assets', 'gods-among-us', file))
    const info = jpegInfo(buf)
    const reject = info && photoRejectionReason(
      { format: 'jpeg', width: info.width, height: info.height, isProgressive: info.isProgressive },
      buf.length,
    )
    ok(Boolean(info) && !info.isProgressive && !reject, `${file} is a valid baseline JPEG (${info?.width}×${info?.height}, ${Math.round(buf.length / 1024)} KB)`)
  }
}

// ── 6. Amiya combat kit through real battle funnels ─────────────────────────
section('6. Amiya — Choice-Attuned Starlight Resonance, Celestial Rebirth & Starfall Reckoning')
{
  const mkAmiyaPlayer = (light = 0) => ({
    id: 'u_amiya',
    name: 'Ren',
    equippedCharacter: 'amiya',
    ownedCharacters: ['amiya'],
    hp: 1200,
    maxHp: 1200,
    mp: 200,
    maxMp: 200,
    level: 50,
    stats: { str: 100, int: 350, def: 200, agi: 200, lck: 0 },
    inventory: ['chains-of-resurrection'],
    skills: [],
    equipped: { offhand: 'chains-of-resurrection' },
    characterSkins: { owned: {}, equipped: {} },
    summonedBeasts: [],
    pets: [],
    activeEffects: [],
    storyProgress: { volumes: { 'gods-among-us': { completed: true, light } } },
    battleState: {
      turn: 1,
      type: 'dungeon',
      playerEffects: [{ type: 'burn', turns: 3, dmg: 80 }],
      enemy: { name: 'Hollow Carrier', hp: 5000, maxHp: 5000, attack: 800, stats: { def: 50 }, activeEffects: [] },
      combatStats: { damageTaken: 0, minHpFrac: 1 },
    },
  })

  // Quiet Choices (Light 0 -> Veil of the Unspoken: 1.20x ATK, 24% DR, 35% Rebirth, 2.25x Reckoning)
  // vs Bright Choices (Light 8 -> Crown of Remembered Light: 1.32x ATK, 18% DR, 45% Rebirth, 2.50x Reckoning)
  const quietP = mkAmiyaPlayer(0)
  const p = mkAmiyaPlayer(8)
  const bs = p.battleState

  const quietSwing = calcPlayerDamage(quietP, null, 1, -1, { consumeBuffs: true, battleState: quietP.battleState })
  const baseSwing = calcPlayerDamage(p, null, 1, -1, { consumeBuffs: true, battleState: bs })
  ok(
    quietSwing.amiyaAuraMult === 1.2 && baseSwing.amiyaAuraMult === 1.32 && baseSwing.rawDmg > quietSwing.rawDmg,
    `Story choices scale passive Starlight Resonance: Quiet Light 0 (${quietSwing.amiyaAuraMult}× -> ${quietSwing.rawDmg}) < Crown Light 8 (${baseSwing.amiyaAuraMult}× -> ${baseSwing.rawDmg})`,
  )

  // 1) Non-lethal strike is mitigated by Starlight Resonance (18% at Light 8 -> 300 becomes 246) without spending save
  const chip = applyIncomingDamage(p, 300, null, true, {})
  ok(p.hp === 954 && !bs.amiyaStarUsed && !bs.amiyaBlessing, `non-lethal blow (300) mitigated by 18% to 246 -> HP ${p.hp} without spending save`)
  const quietChip = applyIncomingDamage(quietP, 300, null, true, {})
  ok(quietP.hp === 972, `Quiet Light 0 Veil mitigates 24% (300 -> 228, HP ${quietP.hp} > ${p.hp})`)

  // 2) First lethal strike triggers Celestial Rebirth -> restores 45% MaxHP (540 HP at Light 8), cleanses burn, arms 2.5x Reckoning
  const lethal1 = applyIncomingDamage(p, 9999, null, true, {})
  ok(p.hp === 540, `Celestial Rebirth at Light 8 restores 45% Max HP (got ${p.hp}/1200)`)
  ok(bs.playerEffects.length === 0, 'Celestial Rebirth cleanses active burn DoT')
  ok(bs.amiyaStarUsed === true && bs.amiyaBlessing === true, 'lethal save marks amiyaStarUsed and arms amiyaBlessing')
  ok(/Celestial Rebirth/.test(lethal1.message), 'lethal save narrates Celestial Rebirth')

  // 3) Preview calcPlayerDamage(consumeBuffs: false) must NOT spend Starfall Reckoning
  const preview = calcPlayerDamage(p, null, 1, -1, { consumeBuffs: false, battleState: bs })
  ok(preview.amiyaBlessingMult === 1 && bs.amiyaBlessing === true, 'damage preview (consumeBuffs: false) never consumes amiyaBlessing')

  // 4) Next committed attack consumes Starfall Reckoning (2.5x at Light 8!)
  const blessedSwing = calcPlayerDamage(p, null, 1, -1, { consumeBuffs: true, battleState: bs })
  ok(
    blessedSwing.amiyaBlessingMult === 2.5 &&
    blessedSwing.rawDmg > baseSwing.rawDmg * 2 &&
    bs.amiyaBlessing === false,
    `committed attack cashes 2.5× Starfall Reckoning (${baseSwing.rawDmg} -> ${blessedSwing.rawDmg}) and clears amiyaBlessing`,
  )

  // 5) Following attack returns to her passive 1.32x Starlight Resonance
  const afterSwing = calcPlayerDamage(p, null, 1, -1, { consumeBuffs: true, battleState: bs })
  ok(afterSwing.amiyaBlessingMult === 1 && afterSwing.rawDmg === baseSwing.rawDmg, 'subsequent attack returns to passive Starlight Resonance')

  // 6) Second lethal blow in the same battle is fatal (once per battle)
  const lethal2 = applyIncomingDamage(p, 5000, null, true, {})
  ok(p.hp === 0 && !/Celestial Rebirth/.test(lethal2.message), 'second lethal blow in the same fight drops HP to 0')
}

// ── 7. Version stamp & changelog copy hygiene ───────────────────────────────
section('7. Version stamp, bookshelf render & AI style guide')
{
  const gauEntry = CHANGELOG.find(e => e.version === '3.16.0')
  ok(Boolean(gauEntry) && gauEntry.codename === 'Gods Among Us' && gauEntry.date === '2026-11-21', `changelog carries 3.16.0 (Gods Among Us) dated 2026-11-21`)
  const hasDashCurrent = CHANGELOG[0].notes.some(n => /[-–—]/.test(n))
  const hasDashGau = (gauEntry?.notes ?? []).some(n => /[-–—]/.test(n))
  ok(!hasDashCurrent && !hasDashGau, `player-facing changelog notes obey the no-dash rule (${BOT_VERSION} & 3.16.0)`)

  const b1Resolved = localPathForAssetUrl('/assets/beyond-the-astral/cover.jpg')
  ok(Boolean(b1Resolved) && existsSync(b1Resolved), 'self-hosted mount resolves /assets/beyond-the-astral/cover.jpg to disk')
  const b1Buf = readFileSync(b1Resolved)
  const b1Info = jpegInfo(b1Buf)
  ok(Boolean(b1Info) && !b1Info.isProgressive, `Book 1 cover.jpg is a valid baseline JPEG (${b1Info?.width}×${b1Info?.height})`)

  const { renderStoryShelf } = await import('../lib/story-shelf-render.mjs')
  const shelfBuf = await renderStoryShelf(storyVolumes, {
    'beyond-the-astral': { locked: false, completed: false },
    'gods-among-us': { locked: true, completed: false },
  })
  const shelfInfo = jpegInfo(shelfBuf)
  const shelfReject = shelfInfo && photoRejectionReason(
    { format: 'jpeg', width: shelfInfo.width, height: shelfInfo.height, isProgressive: shelfInfo.isProgressive },
    shelfBuf.length,
  )
  const sharpMod = (await import('sharp')).default
  const shelfMeta = await sharpMod(shelfBuf).metadata()
  ok(
    Boolean(shelfInfo) && !shelfInfo.isProgressive && !shelfReject &&
    shelfInfo.width === shelfInfo.height && shelfMeta.space === 'srgb' && shelfMeta.channels === 3,
    `renderStoryShelf produces a square 1:1 full-color sRGB baseline JPEG (${shelfInfo?.width}×${shelfInfo?.height}, ${Math.round(shelfBuf.length / 1024)} KB)`,
  )

  const storyMod = (await import('../plugins/story.js')).default
  const sentPayloads = []
  const fakeDb = { data: { users: { u_shelf: { id: 'u_shelf', wallet: { gems: 10 }, storyProgress: { volumes: {} } } } } }
  await storyMod.run({
    isGroup: false,
    from: 'u_shelf',
    sender: 'u_shelf',
    args: [],
    db: fakeDb,
    sock: { sendMessage: async (_to, payload) => sentPayloads.push(payload) },
    reply: async (text) => sentPayloads.push({ text }),
  })
  ok(
    sentPayloads.length === 1 && Buffer.isBuffer(sentPayloads[0].image) &&
    /Books/.test(sentPayloads[0].caption) && !/Volumes/.test(sentPayloads[0].caption) &&
    /\.story info/.test(sentPayloads[0].caption) && /\.story exit/.test(sentPayloads[0].caption) &&
    sentPayloads[0].caption.length < 760,
    `.story sends rendered full-color bookshelf image + concise Books caption (${sentPayloads[0]?.caption?.length} chars, includes .story info & .story exit)`,
  )

  // Verify `.story info "title of story"` with quotes & short synopsis
  const infoPayloads = []
  await storyMod.run({
    isGroup: false,
    from: 'u_shelf',
    sender: 'u_shelf',
    args: ['info', '"The Boy Who Glided the Skies"'],
    db: fakeDb,
    sock: { sendMessage: async (_to, payload) => infoPayloads.push(payload) },
    reply: async (text) => infoPayloads.push({ text }),
  })
  ok(
    infoPayloads.length === 1 &&
    Boolean(infoPayloads[0].image) &&
    /Beyond the Astral/.test(infoPayloads[0].caption ?? '') &&
    /Synopsis/.test(infoPayloads[0].caption ?? '') &&
    /Oliver Wright/.test(infoPayloads[0].caption ?? ''),
    `.story info "The Boy Who Glided the Skies" sends Book 1 cover image & short synopsis`,
  )

  ok(existsSync(join(ROOT, 'AGENTS.md')) && existsSync(join(ROOT, 'CLAUDE.md')), 'AGENTS.md and CLAUDE.md mandatory AI copy style guides exist at repo root')

  // 8) .story exit gate: blocked before Ch1 reward, mid-chapter, mid-battle, and during detour; allowed ONLY after chapter reward paid
  const { canExitStoryBook, exitStoryBook, markChapterStarted } = await import('../lib/story-engine.js')
  const exitBook = getVolume('beyond-the-astral')
  const exitUser = {
    id: 'u_exit',
    level: 1,
    classId: 'warrior',
    raceId: 'human',
    stats: { str: 10, agi: 10, int: 10, def: 10, lck: 10 },
    wallet: { gems: 10 },
    xp: 0,
    storyProgress: { volumes: {} },
  }
  const exitDb = { data: { users: { u_exit: exitUser } }, write: async () => {} }
  const exitReplies = []
  const runStoryCmd = (args) => storyMod.run({
    isGroup: false,
    from: 'u_exit',
    sender: 'u_exit',
    args,
    db: exitDb,
    sock: { sendMessage: async (_to, payload) => exitReplies.push(payload.text ?? payload.caption ?? '') },
    reply: async (text) => exitReplies.push(text),
  })

  ensureStoryProgress(exitUser, 'beyond-the-astral')
  exitUser.storyProgress.volumes['beyond-the-astral'].seenIntro = true
  exitUser.storyProgress.activeVolume = 'beyond-the-astral'

  // Before Chapter 1 finishes & pays reward -> refused
  ok(canExitStoryBook(exitUser, 'beyond-the-astral').allowed === false, '.story exit blocked before Chapter 1 reward is paid')
  await runStoryCmd(['exit'])
  ok(/Cannot exit yet/i.test(exitReplies.at(-1)) && exitUser.storyProgress.activeVolume === 'beyond-the-astral', '.story exit command refuses before chapter reward is paid')

  // Mid-chapter (currentBeat > 0) -> refused
  advanceBeat(exitUser, 'beyond-the-astral')
  ok(canExitStoryBook(exitUser, 'beyond-the-astral').reason === 'mid_chapter', '.story exit blocked mid-chapter')
  await runStoryCmd(['exit'])
  ok(/Cannot exit mid-chapter/i.test(exitReplies.at(-1)), '.story exit command refuses mid-chapter')

  // Complete Chapter 1 & pay out reward -> NOW allowed!
  const ch1 = getChapter(exitBook, 1)
  const ch1Summary = completeChapter(exitUser, exitBook, 'beyond-the-astral', ch1, { gemsPerChapter: 5, xpPerChapter: 200 })
  ok(ch1Summary.gemsAward === 5 && exitUser.wallet.gems === 15, 'Chapter 1 completion paid +5💎 reward')
  ok(canExitStoryBook(exitUser, 'beyond-the-astral').allowed === true, '.story exit unlocked right after Chapter 1 reward is paid')

  // If Chapter 2 begins playing out (markChapterStarted), .story exit locks immediately again
  markChapterStarted(exitUser, 'beyond-the-astral')
  ok(canExitStoryBook(exitUser, 'beyond-the-astral').allowed === false, '.story exit re-locks as soon as next chapter begins playing out')

  // Restore end-of-chapter paid state and execute `.story exit`
  exitUser.storyProgress.volumes['beyond-the-astral'].atPaidChapterEnd = true
  await runStoryCmd(['exit'])
  ok(
    /BOOK CLOSED/.test(exitReplies.at(-1)) &&
    exitUser.storyProgress.activeVolume === null &&
    exitUser.storyProgress.volumes['beyond-the-astral'].exited === true &&
    exitUser.storyProgress.volumes['beyond-the-astral'].currentChapter === 2,
    '.story exit closes book cleanly at paid chapter end while keeping Chapter 2 progress saved',
  )

  // 9) Gods Among Us sparse full-stop style check (no AI-tell full-stop spam)
  {
    const book2 = getVolume('gods-among-us')
    let texts = 0, trailingPeriods = 0, staccato = 0
    const walkTexts = (beats) => {
      for (const b of beats ?? []) {
        if (typeof b.text === 'string') {
          texts++
          const pCount = (b.text.match(/\./g) || []).length
          if (/\.[""\u201d\x27\u2019)]?$/.test(b.text.trim())) trailingPeriods++
          if (pCount >= 3) staccato++
        }
        for (const o of b.options ?? []) walkTexts(o.beats)
        if (b.type === 'iflight') { walkTexts(b.beats); walkTexts(b.elseBeats) }
      }
    }
    for (const ch of book2.chapters) walkTexts(ch.beats)
    ok(
      staccato === 0 && trailingPeriods / texts < 0.03,
      `Gods Among Us hardly uses full stops (${trailingPeriods}/${texts} trailing periods, ${staccato} staccato beats)`,
    )
  }

  // 10) .salvage & .shop sell regression check
  {
    const salvagePlugin = (await import('../plugins/salvage.js')).default
    const shopPlugin = (await import('../plugins/shop.js')).default
    const sDb = {
      data: {
        users: {
          u_salv: {
            id: 'u_salv',
            name: 'Artemis Nova',
            level: 30,
            hp: 100,
            maxHp: 100,
            mp: 50,
            maxMp: 50,
            equipped: { weapon: 'iron_sword' },
            enchants: { shadow_blade: { sharpness: 1 } },
            inventory: ['iron_sword', 'iron_sword', 't_sword_1', 'shadow_blade', 'bar_tab_receipt', 'ghostblade', 'echo_blade'],
            wallet: { solars: 0, gems: 0 },
          },
        },
      },
      write: async () => {},
    }
    const sReplies = []
    const runSalv = (args) => salvagePlugin.run({
      cmd: 'salvage', args, from: 'u_salv', sender: 'u_salv', db: sDb, player: sDb.data.users.u_salv,
      reply: async (t) => sReplies.push(t),
    })
    await runSalv(['all']) // scraps bar_tab_receipt
    await runSalv(['common']) // scraps spare iron_sword + t_sword_1 while keeping equipped iron_sword
    await runSalv(['ghostblade']) // refuses mythic
    ok(
      !sDb.data.users.u_salv.inventory.includes('bar_tab_receipt') &&
      !sDb.data.users.u_salv.inventory.includes('t_sword_1') &&
      sDb.data.users.u_salv.inventory.filter(x => x === 'iron_sword').length === 1 &&
      sDb.data.users.u_salv.inventory.includes('shadow_blade') &&
      sDb.data.users.u_salv.inventory.includes('ghostblade') &&
      sDb.data.users.u_salv.wallet.solars > 0,
      '.salvage scraps junk & unequipped gear while protecting equipped, enchanted & mythic items',
    )

    const sellReplies = []
    await shopPlugin.run({
      cmd: 'shop', args: ['sell', 'echo', 'blade'], from: 'u_salv', sender: 'u_salv', db: sDb, player: sDb.data.users.u_salv,
      reply: async (t) => sellReplies.push(t),
    })
    ok(
      /Sold!/.test(sellReplies.at(-1) ?? '') && !sDb.data.users.u_salv.inventory.includes('echo_blade'),
      '.shop sell handles non-buyable / season items with sellPrice > 0',
    )
  }
}

console.log(`\n${pass} passed, ${fail} failed`)
if (fail > 0) process.exit(1)
