/**
 * scripts/inverted-builds.mjs — the player builds The World That Never Ends
 * is balanced and tested against. Shared by scripts/mirror-balance.mjs and
 * test/inverted-dimension*.test.mjs.
 *
 * "top" builds are the three strongest accounts from
 * scripts/top3-balance-audit.mjs (their stats, their reborn relics), with
 * real skills from data/skills.json. "typical" builds are ordinary mid-level
 * accounts with shield, regen and heal kits, so the stall-prone side of the
 * game is covered too.
 */

export const BUILDS = {
  top_samurai: {
    tier: 'top', name: 'Yochan', classId: 'samurai', level: 200,
    stats: { str: 2431, agi: 690, int: 505, def: 1252, lck: 455 }, maxHp: 4503, maxMp: 1383,
    skills: ['samurai_muramasas_echo_3', 'samurai_the_thousand_cuts_5', 'samurai_the_last_draw_3', 'samurai_honour_cleave_4'],
    equipped: { weapon: 'blade_of_the_dragons', chestplate: 'robe_of_the_dragons' },
  },
  top_mage: {
    tier: 'top', name: 'Absolute Jester_MH', classId: 'mage', level: 200,
    stats: { str: 556, agi: 441, int: 2428, def: 1576, lck: 186 }, maxHp: 5202, maxMp: 1333,
    skills: ['mage_grand_torrent_3', 'mage_infernal_cascade_2', 'mage_the_unravelling_2', 'mage_oblivion_ray_3'],
    equipped: { chestplate: 'robe_of_the_dragons' },
  },
  top_rogue: {
    tier: 'top', name: 'void reaper', classId: 'rogue', level: 173,
    stats: { str: 2069, agi: 976, int: 347, def: 1423, lck: 234 }, maxHp: 6924, maxMp: 920,
    skills: ['rogue_echoing_void_2', 'rogue_venom_shroud_3', 'rogue_blade_of_silence_3', 'rogue_dark_execution_3'],
    equipped: {},
  },
  typical_knight: {
    tier: 'typical', name: 'Typical Knight', classId: 'knight', level: 120,
    stats: { str: 600, agi: 200, int: 50, def: 500, lck: 80 }, maxHp: 2200, maxMp: 500,
    skills: ['knight_fortress_charge_3', 'knight_radiant_bulwark_4', 'knight_unbreakable_wall', 'knight_stalwart_recovery'],
    equipped: {},
  },
  typical_cleric: {
    tier: 'typical', name: 'Typical Cleric', classId: 'cleric', level: 110,
    stats: { str: 80, agi: 150, int: 700, def: 400, lck: 100 }, maxHp: 1900, maxMp: 700,
    skills: ['cleric_light_eternal_2', 'cleric_radiant_miracle_2', 'cleric_astral_grace_2', 'cleric_the_last_prayer_2'],
    equipped: {},
  },
}

/** A minimal player record for a build (what snapshotPlayer reads). */
export function playerFromBuild(key, extra = {}) {
  const b = BUILDS[key]
  return {
    id: `build_${key}@s.whatsapp.net`,
    name: b.name,
    classId: b.classId,
    level: b.level,
    stats: { ...b.stats },
    hp: b.maxHp, maxHp: b.maxHp, mp: b.maxMp, maxMp: b.maxMp,
    skills: [...b.skills],
    equippedSkills: [...b.skills],
    equipped: { ...b.equipped },
    equippedAbilities: [],
    ...extra,
  }
}
