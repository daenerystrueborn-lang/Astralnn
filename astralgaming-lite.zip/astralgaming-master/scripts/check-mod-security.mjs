/**
 * scripts/check-mod-security.mjs
 *
 * Regression suite verifying all moderator security boundaries:
 *   1. Owner-only commands remain strictly unreachable by mods (.mod, .unmod,
 *      .modgc, .leave, .unstick, .cb all, .sectgive, .sectgoldfinger, .givegold).
 *   2. Loophole #1 (.cb @player): Mods cannot self-clear (directly or via @lid
 *      alias), cannot clear their own PvP duel opponent, cannot clear live Boss
 *      fights, and cannot clear active/wagered PvP duels — while orphan/stale
 *      battle rescue and full Owner override continue working.
 *   3. Loophole #2 (Night Mode): Mods cannot farm Astra or Sect RPG commands
 *      during .night on, while pure moderation/control tools (.ban, .mute,
 *      .night off, .card off, .cb) remain reachable and Owner keeps full non-Sect access.
 *   4. Loophole #3 (Sect Empire & Seclusion/Fight/Tribulation locks): Mods inside
 *      the Sect Empire, Seclusion, Sect Fight, Tribulation, or Way Back cannot
 *      bypass world/cultivation locks for gameplay, while moderation tools still
 *      work from anywhere and Owner retains full bypass.
 *   5. Loophole #4 (Restricted Group Gates — .noob on / .pro on / .sect on / .prem on):
 *      Mods cannot bypass level/world/premium group locks for gameplay, while
 *      moderation & group toggle commands (.ban, .noob off, .sect off) still work.
 *   6. Loophole #5 (Cross-Mod Ban, Owner-only .leave, Cross-Platform .unmod):
 *      Mods cannot ban other mods (WhatsApp or Telegram, including via alias),
 *      mods cannot make the bot leave groups via .leave, and cross-platform
 *      owners can revoke mods via .unmod.
 */

import assert from 'node:assert/strict'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

// Isolate runtime stores in a temporary directory so workspace data is never dirtied.
const stateDir = mkdtempSync(join(tmpdir(), 'astral-mod-sec-'))
process.env.RUNTIME_DATA_DIR = stateDir

const { config } = await import('../config.js')
const { addMod, isMod } = await import('../lib/mod-repo.js')
const { isNightCommandAllowed } = await import('../lib/sect-access.js')
const {
  sectGate,
  seclusionGate,
  sectFightGate,
  sectTribulationGate,
  sectWayBackGate,
} = await import('../lib/sect-lock.js')
const { runCommand } = await import('../lib/platform/pipeline.js')
const { getRegistry } = await import('../lib/plugin-manager.js')
const { updateGroupSettings } = await import('../lib/group-settings.js')

const { default: cbPlugin } = await import('../plugins/cb.js')
const { default: banPlugin } = await import('../plugins/ban.js')
const { default: tgBanPlugin } = await import('../plugins-telegram/ban.js')
const { default: modPlugin } = await import('../plugins/mod.js')
const { default: unmodPlugin } = await import('../plugins/unmod.js')
const { default: leavePlugin } = await import('../plugins/leave.js')
const { handleModGc } = await import('../plugins/submit.js')
const { default: unstickPlugin } = await import('../plugins/unstick.js')
const { default: sectGivePlugin } = await import('../plugins/sectgive.js')
const { default: sectGoldfingerPlugin } = await import('../plugins/sectgoldfinger.js')
const { default: adminPlugin } = await import('../plugins/admin.js')

// Deterministic test identities
const OWNER_WA = '2349990000001@s.whatsapp.net'
const OWNER_TG_RAW = '9990001'
const OWNER_TG = `tg:${OWNER_TG_RAW}`
const MOD_A = '2348001111111@s.whatsapp.net'
const MOD_A_LID = '55511111111111@lid'
const MOD_B = '2348002222222@s.whatsapp.net'
const MOD_B_LID = '55522222222222@lid'
const MOD_TG_A = 'tg:8001111'
const MOD_TG_B = 'tg:8002222'
const PLAYER_1 = '2348003333333@s.whatsapp.net'
const PLAYER_2 = '2348004444444@s.whatsapp.net'
const GROUP_ID = '120363000000000001@g.us'

config.ownerNumbers = ['2349990000001']
config.telegramOwnerIds = [OWNER_TG_RAW]

let passed = 0
function check(label, cond) {
  assert.ok(cond, label)
  passed++
  console.log(`  PASS  ${label}`)
}

function makePlayer(name, overrides = {}) {
  return {
    name,
    raceId: 'human',
    classId: 'warrior',
    level: 40,
    xp: 0,
    hp: 500,
    maxHp: 500,
    mp: 200,
    maxMp: 200,
    stamina: 100,
    maxStamina: 100,
    hunger: { current: 100, max: 100 },
    wallet: 5000,
    bank: 0,
    location: 'astral_town',
    inBattle: false,
    battleState: null,
    inventory: [],
    activeEffects: [],
    ...overrides,
  }
}

function makeDb() {
  return {
    data: {
      users: {
        [OWNER_WA]: makePlayer('SupremeOwner', { level: 100 }),
        [MOD_A]: makePlayer('ModAlpha', { level: 60 }),
        [MOD_B]: makePlayer('ModBravo', { level: 55 }),
        [MOD_TG_A]: makePlayer('TgModAlpha', { level: 120 }),
        [MOD_TG_B]: makePlayer('TgModBravo', { level: 45 }),
        [PLAYER_1]: makePlayer('DiscipleOne', { level: 20 }),
        [PLAYER_2]: makePlayer('DiscipleTwo', { level: 22 }),
      },
      identity: {
        aliases: {
          [MOD_A_LID]: MOD_A,
          [MOD_B_LID]: MOD_B,
        },
      },
      mods: [],
      bans: {},
      groups: {},
      parties: {},
      sectSky: null,
      sectMountains: {},
    },
    async write() {},
  }
}

function makeWaCtx(db, from, {
  args = [],
  targetJid = null,
  isGroup = true,
  sender = GROUP_ID,
} = {}) {
  const replies = []
  const sentMessages = []
  let leftGroup = null
  const msg = targetJid
    ? {
        message: {
          extendedTextMessage: {
            contextInfo: { mentionedJid: [targetJid] },
          },
        },
      }
    : { message: { conversation: '' } }

  return {
    platform: 'whatsapp',
    platformId: from,
    db,
    from,
    sender: isGroup ? sender : from,
    isGroup,
    args,
    text: args.join(' '),
    msg,
    player: db.data.users[from] ?? db.data.users[db.data.identity?.aliases?.[from]] ?? null,
    replies,
    sentMessages,
    get leftGroup() { return leftGroup },
    async reply(text) {
      replies.push(String(text))
      return { key: { id: 'mock' } }
    },
    sock: {
      async sendMessage(to, payload) {
        sentMessages.push({ to, ...payload })
        replies.push(String(payload?.text ?? ''))
      },
      async groupLeave(jid) {
        leftGroup = jid
      },
      async groupMetadata() {
        return { id: GROUP_ID, participants: [] }
      },
    },
  }
}

try {
  // ── 1. Owner-Only Command Isolation ────────────────────────────────────────
  console.log('\n=== 1. Owner-Only Command Isolation ===')
  {
    const db = makeDb()
    await addMod(db, MOD_A, OWNER_WA)

    // .mod rejected for mod
    const modTryPromote = makeWaCtx(db, MOD_A, { targetJid: PLAYER_1 })
    await modPlugin.run(modTryPromote)
    check('mod cannot run .mod to promote another user', !isMod(db, PLAYER_1) && modTryPromote.replies.some(r => r.includes('Only')))

    // .unmod rejected for mod
    await addMod(db, MOD_B, OWNER_WA)
    const modTryDemote = makeWaCtx(db, MOD_A, { targetJid: MOD_B })
    await unmodPlugin.run(modTryDemote)
    check('mod cannot run .unmod to demote another mod', isMod(db, MOD_B))

    // .modgc rejected for mod
    const modTryModGc = makeWaCtx(db, MOD_A)
    await handleModGc(modTryModGc)
    check('mod cannot hijack .modgc', modTryModGc.replies.some(r => r.includes('Owner only')))

    // .unstick rejected for mod
    const modTryUnstick = makeWaCtx(db, MOD_A, { targetJid: PLAYER_1 })
    await unstickPlugin.run(modTryUnstick)
    check('mod cannot run owner-only .unstick', modTryUnstick.replies.some(r => r.includes('owner')))

    // .cb all rejected for mod
    db.data.users[PLAYER_1].inBattle = true
    db.data.users[PLAYER_1].battleState = { type: 'mob', monsterName: 'Slime' }
    const modTryCbAll = makeWaCtx(db, MOD_A, { args: ['all'] })
    await cbPlugin.run(modTryCbAll)
    check('mod cannot run .cb all global reset', db.data.users[PLAYER_1].inBattle === true)

    // .sectgive / .sectgoldfinger / .givegold rejected for mod
    const modTrySectGive = makeWaCtx(db, MOD_A, { args: ['stones', '99999'] })
    await sectGivePlugin.run(modTrySectGive)
    check('mod cannot run .sectgive', modTrySectGive.replies.some(r => /owner|decree|only/i.test(r)))

    db.data.users[MOD_A].world = 'sect_empire'
    const modTryGoldfinger = makeWaCtx(db, MOD_A, { args: ['reroll'] })
    await sectGoldfingerPlugin.run(modTryGoldfinger)
    db.data.users[MOD_A].world = 'astral_kingdom'
    check('mod cannot run .goldfinger reroll', modTryGoldfinger.replies.some(r => /keeper|sealed|owner/i.test(r)))

    const goldBefore = db.data.users[MOD_A].wallet
    const modTryGiveGold = makeWaCtx(db, MOD_A, { args: ['999999'], targetJid: MOD_A })
    modTryGiveGold.cmd = 'givegold'
    await adminPlugin.run(modTryGiveGold)
    check('mod cannot run .givegold', db.data.users[MOD_A].wallet === goldBefore)
  }

  // ── 2. Loophole #1: .cb @player Combat / PvP / Boss Escape Hardening ───────
  console.log('\n=== 2. Loophole #1 — .cb @player Combat / PvP / Boss Hardening ===')
  {
    const db = makeDb()
    await addMod(db, MOD_A, OWNER_WA)
    await addMod(db, MOD_B, OWNER_WA)

    // 2a. Direct self-clear blocked
    db.data.users[MOD_A].inBattle = true
    db.data.users[MOD_A].battleState = { type: 'mob', monsterName: 'Goblin' }
    const selfDirect = makeWaCtx(db, MOD_A, { targetJid: MOD_A })
    await cbPlugin.run(selfDirect)
    check('mod cannot .cb themselves directly', db.data.users[MOD_A].inBattle === true)

    // 2b. Self-clear via @lid alias blocked
    const selfViaAlias = makeWaCtx(db, MOD_A_LID, { targetJid: MOD_A })
    await cbPlugin.run(selfViaAlias)
    check('mod cannot .cb themselves via @lid vs phone-JID alias mismatch', db.data.users[MOD_A].inBattle === true)

    // 2c. Mod in PvP duel running .cb @opponent to escape loss is blocked
    const now = Date.now()
    db.data.users[MOD_A].inBattle = true
    db.data.users[MOD_A].battleState = { type: 'pvp', opponentJid: PLAYER_1, wager: 10000, startedAt: now }
    db.data.users[PLAYER_1].inBattle = true
    db.data.users[PLAYER_1].battleState = { type: 'pvp', opponentJid: MOD_A, wager: 10000, startedAt: now }
    const modPvpEscape = makeWaCtx(db, MOD_A, { targetJid: PLAYER_1 })
    await cbPlugin.run(modPvpEscape)
    check(
      'mod in a PvP duel cannot .cb @opponent to escape their own duel/wager',
      db.data.users[MOD_A].inBattle === true && db.data.users[PLAYER_1].inBattle === true,
    )

    // 2d. Mod running .cb @friend on a live Boss fight is blocked
    db.data.users[PLAYER_1].inBattle = true
    db.data.users[PLAYER_1].battleState = {
      enemy: { isBoss: true, name: 'Calamity Sovereign', hp: 5000 },
      bossState: { turn: 1 },
    }
    const modBossRescue = makeWaCtx(db, MOD_B, { targetJid: PLAYER_1 })
    await cbPlugin.run(modBossRescue)
    check('mod cannot .cb a player out of a live Boss fight', db.data.users[PLAYER_1].inBattle === true)

    // 2e. Mod running .cb on an active / wagered third-party PvP duel is blocked
    db.data.users[PLAYER_1].inBattle = true
    db.data.users[PLAYER_1].battleState = { type: 'pvp', opponentJid: PLAYER_2, wager: 5000, startedAt: Date.now() }
    db.data.users[PLAYER_2].inBattle = true
    db.data.users[PLAYER_2].battleState = { type: 'pvp', opponentJid: PLAYER_1, wager: 5000, startedAt: Date.now() }
    const modThirdPartyPvp = makeWaCtx(db, MOD_B, { targetJid: PLAYER_1 })
    await cbPlugin.run(modThirdPartyPvp)
    check('mod cannot .cb an active wagered PvP duel between two players', db.data.users[PLAYER_1].inBattle === true)

    // 2f. Legitimate rescue: Mod clearing a genuinely wedged/orphaned battle SUCCEEDS
    db.data.users[PLAYER_1].inBattle = true
    db.data.users[PLAYER_1].battleState = { type: 'mob', monsterName: 'Glitched Wolf' }
    const modLegitRescue = makeWaCtx(db, MOD_B, { targetJid: PLAYER_1 })
    await cbPlugin.run(modLegitRescue)
    check('mod CAN still .cb a genuinely wedged PvE battle on another player', db.data.users[PLAYER_1].inBattle === false)

    // 2g. Legitimate rescue: Orphaned one-sided PvP (no wager, opponent no longer paired) SUCCEEDS
    db.data.users[PLAYER_1].inBattle = true
    db.data.users[PLAYER_1].battleState = { type: 'pvp', opponentJid: PLAYER_2, wager: 0 }
    db.data.users[PLAYER_2].inBattle = false
    db.data.users[PLAYER_2].battleState = null
    const modOrphanPvp = makeWaCtx(db, MOD_B, { targetJid: PLAYER_1 })
    await cbPlugin.run(modOrphanPvp)
    check('mod CAN .cb an orphaned one-sided PvP lock with no wager', db.data.users[PLAYER_1].inBattle === false)

    // 2h. Owner override: Owner CAN clear an active wagered PvP duel or live Boss fight
    db.data.users[PLAYER_1].inBattle = true
    db.data.users[PLAYER_1].battleState = {
      enemy: { isBoss: true, name: 'Calamity Sovereign', hp: 5000 },
      bossState: { turn: 1 },
    }
    const ownerOverride = makeWaCtx(db, OWNER_WA, { targetJid: PLAYER_1 })
    await cbPlugin.run(ownerOverride)
    check('owner retains full .cb @player override even on live Boss fights', db.data.users[PLAYER_1].inBattle === false)
  }

  // ── 3. Loophole #2: Night Mode Astra RPG Farming Lockdown ──────────────────
  console.log('\n=== 3. Loophole #2 — Night Mode Astra RPG Farming Lockdown ===')
  {
    const astraMod = makePlayer('ModAlpha')
    const sectOwner = makePlayer('OwnerCultivator', { world: 'sect_empire', location: 'sect_outer_court', sect: { realm: 1 } })

    for (const gameplayCmd of ['rob', 'dungeon', 'auction', 'raid', 'war', 'mine', 'fish', 'pvp', 'daily', 'spin', 'sect', 'hunt']) {
      check(
        `night mode blocks non-owner mod from running .${gameplayCmd}`,
        isNightCommandAllowed({ cmd: gameplayCmd, args: [], player: astraMod, staff: true, isOwner: false }) === false,
      )
    }

    // Dual-purpose plugin commands (.card, .pokemon) blocked without on/off, allowed WITH on/off
    check(
      'night mode blocks mod running .card without on/off',
      isNightCommandAllowed({ cmd: 'card', args: ['collection'], player: astraMod, staff: true, isOwner: false }) === false,
    )
    check(
      'night mode allows mod running .card off',
      isNightCommandAllowed({ cmd: 'card', args: ['off'], player: astraMod, staff: true, isOwner: false }) === true,
    )

    for (const modCmd of ['ban', 'tban', 'unban', 'mute', 'unmute', 'kick', 'del', 'guard', 'night', 'cb', 'gclist', 'gcqueue']) {
      check(
        `night mode allows mod running pure moderation command .${modCmd}`,
        isNightCommandAllowed({ cmd: modCmd, args: [], player: astraMod, staff: true, isOwner: false }) === true,
      )
    }

    check(
      'night mode still allows Bot Owner to run non-Sect Astra commands (.dungeon)',
      isNightCommandAllowed({ cmd: 'dungeon', args: [], player: astraMod, staff: true, isOwner: true }) === true,
    )
    check(
      'night mode still blocks even Bot Owner from Sect gameplay (.hunt in Sect)',
      isNightCommandAllowed({ cmd: 'hunt', args: [], player: sectOwner, staff: true, isOwner: true }) === false,
    )
  }

  // ── 4. Loophole #3: Sect Empire & Seclusion / Fight / Tribulation Locks ────
  console.log('\n=== 4. Loophole #3 — Sect Empire & Cultivation Locks ===')
  {
    const db = makeDb()
    await addMod(db, MOD_A, OWNER_WA)

    // Put MOD_A inside the Sect Empire + Seclusion + Fight + Tribulation + WayBack
    db.data.users[MOD_A].world = 'sect_empire'
    db.data.users[MOD_A].sect = {
      id: 'azure_cloud',
      realm: 2,
      inSectWorld: true,
      session: { type: 'seclusion', startedAt: Date.now() },
    }
    db.data.users[MOD_A].location = 'sect_outer_court'

    // 4a. sectGate blocks Astra RPG commands for Mod in Sect Empire, allows .ban & Owner
    const modSectRob = makeWaCtx(db, MOD_A)
    check('sectGate BLOCKS mod in Sect Empire from running Astra .rob', (await sectGate(modSectRob, 'rob', 'rob', { known: true, category: 'economy' })) === true)

    const modSectBan = makeWaCtx(db, MOD_A)
    check('sectGate ALLOWS mod in Sect Empire to run .ban', (await sectGate(modSectBan, 'ban', 'ban', { known: true, category: 'group' })) === false)

    const modSectCardOff = makeWaCtx(db, MOD_A, { args: ['off'] })
    check('sectGate ALLOWS mod in Sect Empire to run .card off', (await sectGate(modSectCardOff, 'card', 'card', { known: true, category: 'cards' })) === false)

    db.data.users[OWNER_WA].world = 'sect_empire'
    db.data.users[OWNER_WA].sect = { id: 'azure_cloud', realm: 2, inSectWorld: true }
    const ownerSectRob = makeWaCtx(db, OWNER_WA)
    check('sectGate ALLOWS Bot Owner to bypass world lock', (await sectGate(ownerSectRob, 'rob', 'rob', { known: true, category: 'economy' })) === false)

    // 4b. seclusionGate blocks .hunt / .gather / .spar for Mod in seclusion, allows .ban / .mute
    const modSeclHunt = makeWaCtx(db, MOD_A)
    check('seclusionGate BLOCKS mod in closed-door seclusion from farming .hunt', (await seclusionGate(modSeclHunt, 'hunt', 'sect-hunt')) === true)

    const modSeclMute = makeWaCtx(db, MOD_A)
    check('seclusionGate ALLOWS mod in closed-door seclusion to run .mute', (await seclusionGate(modSeclMute, 'mute', 'mute')) === false)

    // 4c. sectFightGate blocks .shop / .tasks for Mod mid-fight, allows .ban
    db.data.users[MOD_A].sectFight = { enemy: 'Rogue Cultivator', hp: 100 }
    const modFightTasks = makeWaCtx(db, MOD_A)
    check('sectFightGate BLOCKS mod mid-fight from running .tasks', (await sectFightGate(modFightTasks, 'tasks', 'sect-tasks')) === true)

    const modFightBan = makeWaCtx(db, MOD_A)
    check('sectFightGate ALLOWS mod mid-fight to run .ban', (await sectFightGate(modFightBan, 'ban', 'ban')) === false)

    // 4d. sectTribulationGate & sectWayBackGate block gameplay for Mod, allow .ban
    db.data.users[MOD_A].sectTribulation = { wave: 1 }
    const modTribHunt = makeWaCtx(db, MOD_A)
    check('sectTribulationGate BLOCKS mod mid-tribulation from running .hunt', (await sectTribulationGate(modTribHunt, 'hunt', 'sect-hunt')) === true)
    const modTribBan = makeWaCtx(db, MOD_A)
    check('sectTribulationGate ALLOWS mod mid-tribulation to run .ban', (await sectTribulationGate(modTribBan, 'ban', 'ban')) === false)

    db.data.users[MOD_A].sectWayBack = { active: true, step: 1 }
    const modWayBackHunt = makeWaCtx(db, MOD_A)
    check('sectWayBackGate BLOCKS mod on Mountain Road from running .hunt', (await sectWayBackGate(modWayBackHunt, 'hunt', 'sect-hunt')) === true)
    const modWayBackBan = makeWaCtx(db, MOD_A)
    check('sectWayBackGate ALLOWS mod on Mountain Road to run .ban', (await sectWayBackGate(modWayBackBan, 'ban', 'ban')) === false)
  }

  // ── 5. Loophole #4: .noob on / .pro on / .sect on Group Gate Enforcement ───
  console.log('\n=== 5. Loophole #4 — .noob on / .pro on / .sect on Group Gates ===')
  {
    const db = makeDb()
    await addMod(db, MOD_TG_A, OWNER_WA)

    const reg = getRegistry('telegram')
    let gameplayExecuted = false
    let modControlExecuted = false
    reg.set('__test_farm', {
      name: '__test_farm',
      aliases: [],
      category: 'rpg',
      requiresPlayer: true,
      async run() { gameplayExecuted = true },
    })
    reg.set('gclist', {
      name: 'gclist',
      aliases: [],
      category: 'group',
      requiresPlayer: false,
      modTool: true,
      async run() { modControlExecuted = true },
    })

    const tgGroup = 'tg:group:-100555'
    await updateGroupSettings(tgGroup, s => Object.assign(s, { noobOnly: true, sectOnly: false, proOnly: false }))

    const makeTgCmdCtx = (from, cmd, args = []) => {
      const replies = []
      return {
        platform: 'telegram',
        platformId: from,
        from,
        sender: tgGroup,
        isGroup: true,
        db,
        cmd,
        args,
        text: args.join(' '),
        replies,
        async isChatAdmin() { return false },
        async reply(t) { replies.push(String(t)) },
      }
    }

    // MOD_TG_A is level 45 (> NOOB_MAX_LEVEL)
    gameplayExecuted = false
    const noobBlockedCtx = makeTgCmdCtx(MOD_TG_A, '__test_farm')
    await runCommand(noobBlockedCtx)
    check(
      'high-level mod is BLOCKED from gameplay inside a .noob on group',
      gameplayExecuted === false && noobBlockedCtx.replies.some(r => /Noob|level/i.test(r)),
    )

    modControlExecuted = false
    const noobModAllowedCtx = makeTgCmdCtx(MOD_TG_A, 'gclist')
    await runCommand(noobModAllowedCtx)
    check(
      'high-level mod CAN still run staff control commands inside a .noob on group',
      modControlExecuted === true,
    )

    // .pro on group blocks low-level mod (MOD_TG_B, level 45) from gameplay, allows staff control
    await addMod(db, MOD_TG_B, OWNER_WA)
    await updateGroupSettings(tgGroup, s => Object.assign(s, { noobOnly: false, sectOnly: false, proOnly: true }))
    gameplayExecuted = false
    const proBlockedCtx = makeTgCmdCtx(MOD_TG_B, '__test_farm')
    await runCommand(proBlockedCtx)
    check(
      'low-level mod is BLOCKED from gameplay inside a .pro on group',
      gameplayExecuted === false && proBlockedCtx.replies.some(r => /Pro-only/i.test(r)),
    )

    // .sect on group blocks Astra gameplay for Mod, allows staff control + Owner
    await updateGroupSettings(tgGroup, s => Object.assign(s, { noobOnly: false, sectOnly: true, proOnly: false }))
    gameplayExecuted = false
    const sectGroupBlockedCtx = makeTgCmdCtx(MOD_TG_A, '__test_farm')
    await runCommand(sectGroupBlockedCtx)
    check(
      'mod is BLOCKED from Astra gameplay inside a .sect on group',
      gameplayExecuted === false && sectGroupBlockedCtx.replies.some(r => /Sect Hall/i.test(r)),
    )

    modControlExecuted = false
    const sectGroupModAllowedCtx = makeTgCmdCtx(MOD_TG_A, 'gclist')
    await runCommand(sectGroupModAllowedCtx)
    check(
      'mod CAN run staff control commands inside a .sect on group',
      modControlExecuted === true,
    )

    // Owner bypasses both .noob on and .sect on
    db.data.users[OWNER_TG] = makePlayer('TgOwner', { level: 99 })
    gameplayExecuted = false
    const ownerSectAllowedCtx = makeTgCmdCtx(OWNER_TG, '__test_farm')
    await runCommand(ownerSectAllowedCtx)
    check('Bot Owner retains full bypass inside .sect on groups', gameplayExecuted === true)

    reg.delete('__test_farm')
  }

  // ── 6. Loophole #5: Cross-Mod Ban, Owner-Only .leave, Cross-Platform .unmod ─
  console.log('\n=== 6. Loophole #5 — Cross-Mod Ban, .leave, & Cross-Platform .unmod ===')
  {
    const db = makeDb()
    await addMod(db, MOD_A, OWNER_WA)
    await addMod(db, MOD_B, OWNER_WA)
    await addMod(db, MOD_TG_A, OWNER_WA)
    await addMod(db, MOD_TG_B, OWNER_WA)

    // 6a. WhatsApp Mod A cannot ban Mod B (directly or via Mod B's @lid alias)
    const modBanModDirect = makeWaCtx(db, MOD_A, { targetJid: MOD_B, args: ['rogue'] })
    await banPlugin.run(modBanModDirect)
    check(
      'WhatsApp mod cannot .ban another mod directly',
      !db.data.bans[MOD_B] && modBanModDirect.replies.some(r => /Mods cannot ban another mod/i.test(r)),
    )

    const modBanModAlias = makeWaCtx(db, MOD_A, { targetJid: MOD_B_LID, args: ['rogue'] })
    await banPlugin.run(modBanModAlias)
    check(
      'WhatsApp mod cannot .ban another mod via @lid alias',
      !db.data.bans[MOD_B_LID] && !db.data.bans[MOD_B] && modBanModAlias.replies.some(r => /Mods cannot ban another mod/i.test(r)),
    )

    // Legitimate mod ban on normal player still works
    const modBanPlayer = makeWaCtx(db, MOD_A, { targetJid: PLAYER_1, args: ['spamming'] })
    await banPlugin.run(modBanPlayer)
    check('WhatsApp mod CAN still .ban a regular rule-breaking player', Boolean(db.data.bans[PLAYER_1]))

    // Bot Owner CAN ban a rogue mod
    const ownerBanMod = makeWaCtx(db, OWNER_WA, { targetJid: MOD_B, args: ['compromised'] })
    await banPlugin.run(ownerBanMod)
    check('Bot Owner CAN .ban a mod when needed', Boolean(db.data.bans[MOD_B]))

    // 6b. Telegram Mod A cannot ban Telegram Mod B
    const tgReplies = []
    const tgCtx = {
      platform: 'telegram',
      platformId: MOD_TG_A,
      from: MOD_TG_A,
      sender: 'tg:group:-100777',
      isGroup: true,
      cmd: 'ban',
      args: ['rogue'],
      db,
      chat: { id: -100777 },
      message: {
        from: { id: 8001111, is_bot: false, first_name: 'TgModAlpha' },
        reply_to_message: {
          from: { id: 8002222, is_bot: false, first_name: 'TgModBravo' },
        },
      },
      bot: {
        botInfo: { id: 1 },
        api: {
          async getChatMember() { return { status: 'member' } },
          async banChatMember() { throw new Error('should not be called') },
        },
      },
      async isChatAdmin() { return true },
      async reply(t) { tgReplies.push(String(t)) },
    }
    await tgBanPlugin.run(tgCtx)
    check(
      'Telegram mod cannot .ban another bot mod',
      !db.data.bans[MOD_TG_B] && tgReplies.some(r => /Mods cannot ban another bot mod/i.test(r)),
    )

    // 6c. .leave is strictly Owner-only (Mod blocked, Owner succeeds)
    const modLeave = makeWaCtx(db, MOD_A)
    await leavePlugin.run(modLeave)
    check('Mod cannot force bot out of a group with .leave', modLeave.leftGroup === null && modLeave.replies.some(r => /Owner only/i.test(r)))

    const ownerLeave = makeWaCtx(db, OWNER_WA)
    await leavePlugin.run(ownerLeave)
    check('Bot Owner CAN make bot leave a group with .leave', ownerLeave.leftGroup === GROUP_ID)

    // 6d. Cross-platform Owner (Telegram) can revoke a mod via .unmod
    const tgOwnerUnmodReplies = []
    const tgOwnerUnmodCtx = {
      platform: 'telegram',
      platformId: OWNER_TG,
      from: OWNER_TG,
      sender: 'tg:group:-100777',
      isGroup: true,
      db,
      args: [],
      message: {
        reply_to_message: {
          from: { id: 8001111, is_bot: false },
        },
      },
      async reply(t) { tgOwnerUnmodReplies.push(String(t)) },
    }
    await unmodPlugin.run(tgOwnerUnmodCtx)
    check('Telegram Owner CAN revoke a mod via .unmod', !isMod(db, MOD_TG_A))

    // 6e. Owner revoking a WhatsApp mod via @lid alias cleans up their phone-JID mod status too
    const ownerUnmodViaLid = makeWaCtx(db, OWNER_WA, { targetJid: MOD_A_LID })
    await unmodPlugin.run(ownerUnmodViaLid)
    check('WhatsApp Owner revoking a mod via @lid alias removes canonical mod status', !isMod(db, MOD_A) && !isMod(db, MOD_A_LID))
  }

  console.log(`\n====================================================`)
  console.log(`  Mod Security Check: ${passed} passed, 0 failed`)
  console.log(`====================================================\n`)
} finally {
  try { rmSync(stateDir, { recursive: true, force: true }) } catch {}
}
