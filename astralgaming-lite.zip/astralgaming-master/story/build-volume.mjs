/**
 * build-volume.mjs — assembles data/story-beyond-the-astral.json out of the
 * per-chapter fragments in story/chapters-json/.
 *
 *   node story/build-volume.mjs                  (Book 1, chapters-json/)
 *   node story/build-volume.mjs gods-among-us-json   (Book 2)
 *
 * WHY THIS EXISTS
 * The volume is one JSON document at runtime (lib/game-data.js loads exactly
 * one file per volume — see story/json-schema-spec.md), but 20 chapters of
 * branching prose in one file is unreviewable: a single chapter's diff is
 * buried in a 300KB blob and a stray comma breaks all twenty. So the prose is
 * authored one chapter per file and stitched here.
 *
 * story/chapters-json/_volume.json  — everything above "chapters"
 * story/chapters-json/chNN.json     — one chapter object each, NN = 01..20
 *
 * data/story-beyond-the-astral.json is GENERATED. Edit the fragments, then
 * re-run this. Editing the generated file directly works until the next
 * build silently reverts it.
 *
 * The validation pass below is the real point of the script. It catches the
 * three mistakes that are invisible in JSON but break at play time:
 *   - a duplicate choice key, which makes two different choices share one
 *     recorded pick (lib/story-engine.js's choiceKeyFor / choiceKeys)
 *   - a choice beat with no key while carrying per-option beats, which falls
 *     back to an option-id-derived key and can collide
 *   - a 4th option, which lib/interactive-buttons.js's sendButtons silently
 *     drops from the button row (it slices to 3) while it stays pickable by
 *     typing — i.e. an option some players can never see
 */
import { readFileSync, writeFileSync, readdirSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import path from 'node:path'

const here = path.dirname(fileURLToPath(import.meta.url))
// One fragment directory per volume. Default keeps `node story/build-volume.mjs`
// Book-1-shaped; any other directory name builds that volume, with the output
// filename derived from the volume id in its _volume.json.
const fragName = process.argv[2] ?? 'chapters-json'
const fragDir = path.join(here, fragName)
const read = f => JSON.parse(readFileSync(path.join(fragDir, f), 'utf8'))
const outId = JSON.parse(readFileSync(path.join(fragDir, '_volume.json'), 'utf8')).id
if (!outId) throw new Error(`${fragName}/_volume.json carries no id`)
const outFile = path.join(here, '..', 'data', `story-${outId}.json`)

const volume = read('_volume.json')
const chapterFiles = readdirSync(fragDir).filter(f => /^ch\d\d\.json$/.test(f)).sort()
if (!chapterFiles.length) throw new Error('no chNN.json fragments found in ' + fragDir)

volume.chapters = chapterFiles.map(read)

// ------------------------------------------------------------------ validate
const problems = []
const stats = []

/** Walks a beat list plus every per-option / conditional payload nested inside it. */
function walk(beats, visit, depth = 0) {
  for (const beat of beats ?? []) {
    visit(beat, depth)
    for (const option of beat.options ?? []) {
      if (option.beats?.length) walk(option.beats, visit, depth + 1)
    }
    if (beat.type === 'iflight') {
      walk(beat.beats, visit, depth + 1)
      walk(beat.elseBeats, visit, depth + 1)
    }
  }
}

function allBeatLists(chapter) {
  const lists = [chapter.beats ?? []]
  if (chapter.branch) {
    for (const c of Object.values(chapter.branch.cases ?? {})) lists.push(c)
    lists.push(chapter.branch.default ?? [], chapter.branch.resumeBeats ?? [])
  }
  return lists
}

const VALID_TYPES = new Set(['line', 'dialogue', 'choice', 'plea', 'battle', 'iflight'])

volume.chapters.forEach((chapter, i) => {
  const where = `ch${String(chapter.num).padStart(2, '0')} (${chapter.id})`
  if (chapter.num !== i + 1) problems.push(`${where}: num is ${chapter.num}, expected ${i + 1}`)
  const prev = volume.chapters[i - 1]
  const expectedRequires = prev ? prev.id : null
  if ((chapter.requires ?? null) !== expectedRequires) {
    problems.push(`${where}: requires is ${JSON.stringify(chapter.requires ?? null)}, expected ${JSON.stringify(expectedRequires)}`)
  }

  const keys = new Set()
  let total = 0, choices = 0, branchBeats = 0, pleas = 0, battles = 0

  for (const list of allBeatLists(chapter)) {
    walk(list, (beat, depth) => {
      total++
      if (depth > 0) branchBeats++
      if (!VALID_TYPES.has(beat.type)) problems.push(`${where}: unknown beat type ${JSON.stringify(beat.type)}`)
      if (beat.type === 'iflight') {
        if (typeof beat.min !== 'number' || Number.isNaN(beat.min)) {
          problems.push(`${where}: iflight beat has no numeric min (the light threshold)`)
        }
        const payloads = [beat.beats, beat.elseBeats].filter(b => b !== undefined)
        if (!payloads.length) problems.push(`${where}: iflight beat carries neither beats nor elseBeats`)
        for (const p of payloads) if (!Array.isArray(p) || !p.length) problems.push(`${where}: iflight beat has an empty payload list`)
        if (beat.options) problems.push(`${where}: an iflight beat has options`)
        return
      }
      if (typeof beat.text !== 'string' || !beat.text.trim()) problems.push(`${where}: a ${beat.type} beat has no text`)

      if (beat.type === 'plea') {
        if (!beat.stakes) problems.push(`${where}: plea beat has no stakes block`)
        else if (!beat.stakes.scripted && typeof beat.stakes.chance !== 'number') {
          problems.push(`${where}: unscripted plea has no numeric chance`)
        }
      }
      if (beat.type === 'battle') {
        if (!beat.encounter) problems.push(`${where}: battle beat has no encounter block`)
        else {
          if (!beat.encounter.onWin) problems.push(`${where}: battle beat has no onWin text`)
          if (beat.encounter.loadout) {
            const lo = beat.encounter.loadout
            if (!lo.fighter) problems.push(`${where}: interactive battle loadout missing fighter`)
            if (!lo.weapon) problems.push(`${where}: interactive battle loadout missing weapon`)
            if (!Number.isFinite(Number(lo.hp)) || Number(lo.hp) <= 0) problems.push(`${where}: interactive battle loadout needs hp > 0`)
            if (!Number.isFinite(Number(lo.atk)) || Number(lo.atk) <= 0) problems.push(`${where}: interactive battle loadout needs atk > 0`)
            if (!Number.isFinite(Number(beat.encounter.enemyHp)) || Number(beat.encounter.enemyHp) <= 0) problems.push(`${where}: interactive battle needs enemyHp > 0`)
            if (!Number.isFinite(Number(beat.encounter.enemyAtk)) || Number(beat.encounter.enemyAtk) <= 0) problems.push(`${where}: interactive battle needs enemyAtk > 0`)
            if (!beat.encounter.onLose) problems.push(`${where}: interactive battle must have onLose text for defeat consequence`)
            const moves = lo.moves ?? []
            if (moves.length < 2 || moves.length > 4) {
              problems.push(`${where}: interactive battle loadout needs 2..4 moves, got ${moves.length}`)
            }
            const mIds = new Set()
            for (const m of moves) {
              if (!m.id || !m.label) problems.push(`${where}: interactive battle move missing id or label`)
              if (mIds.has(m.id)) problems.push(`${where}: interactive battle repeats move id ${m.id}`)
              mIds.add(m.id)
              if (!['attack', 'disrupt', 'guard', 'heal'].includes(m.kind)) {
                problems.push(`${where}: interactive battle move ${m.id} has unknown kind ${m.kind}`)
              }
            }
            const pats = beat.encounter.enemyPatterns ?? []
            if (!pats.length) problems.push(`${where}: interactive battle needs at least one enemyPatterns entry`)
          }
        }
      }

      if (beat.type !== 'choice') {
        if (beat.options) problems.push(`${where}: a ${beat.type} beat has options`)
        return
      }
      // option light weights (Book 2) — honest answers only, 0 to 2 each
      for (const o of beat.options ?? []) {
        if (o.light !== undefined) {
          const n = Number(o.light)
          if (!Number.isFinite(n) || n < 0 || n > 2) {
            problems.push(`${where}: choice ${beat.key ?? '(no key)'} option ${o.id} has light ${JSON.stringify(o.light)} — allowed values are 0, 1 or 2`)
          }
        }
      }
      choices++
      const opts = beat.options ?? []
      if (opts.length < 2) problems.push(`${where}: choice ${beat.key ?? '(no key)'} has ${opts.length} option(s)`)
      if (opts.length > 3) problems.push(`${where}: choice ${beat.key ?? '(no key)'} has ${opts.length} options — sendButtons only renders 3`)

      const ids = new Set()
      for (const o of opts) {
        if (!o.id) problems.push(`${where}: choice ${beat.key ?? '(no key)'} has an option with no id`)
        if (ids.has(o.id)) problems.push(`${where}: choice ${beat.key ?? '(no key)'} repeats option id ${o.id}`)
        ids.add(o.id)
        if (!o.label) problems.push(`${where}: option ${o.id} has no label`)
      }

      const carriesBeats = opts.some(o => o.beats?.length)
      if (!beat.key) {
        if (carriesBeats) problems.push(`${where}: a choice with per-option beats has no key`)
        return
      }
      if (keys.has(beat.key)) problems.push(`${where}: duplicate choice key ${beat.key}`)
      keys.add(beat.key)
    })
  }

  for (const list of allBeatLists(chapter)) {
    walk(list, beat => { if (beat.type === 'plea') pleas++; if (beat.type === 'battle') battles++ })
  }

  stats.push({ ch: chapter.num, title: chapter.title, beats: total, choices, branchBeats, pleas, battles })
})

const globalKeys = new Map()
for (const chapter of volume.chapters) {
  for (const list of allBeatLists(chapter)) {
    walk(list, beat => {
      if (beat.type !== 'choice' || !beat.key) return
      if (globalKeys.has(beat.key)) {
        problems.push(`choice key ${beat.key} used in both ch${globalKeys.get(beat.key)} and ch${chapter.num}`)
      }
      globalKeys.set(beat.key, chapter.num)
    })
  }
}

for (const row of stats) {
  console.log(
    `ch${String(row.ch).padStart(2, '0')}  ${String(row.beats).padStart(4)} beats  ` +
    `${String(row.choices).padStart(2)} choices  ${String(row.branchBeats).padStart(3)} branch  ` +
    `${row.pleas ? row.pleas + ' plea ' : '      '}${row.battles ? row.battles + ' battle' : ''}  ${row.title}`,
  )
}
const totals = stats.reduce((a, r) => ({ beats: a.beats + r.beats, choices: a.choices + r.choices }), { beats: 0, choices: 0 })
console.log(`\n${volume.chapters.length} chapters · ${totals.beats} beats · ${totals.choices} choices`)

if (problems.length) {
  console.error(`\n${problems.length} problem(s):`)
  for (const p of problems) console.error('  - ' + p)
  process.exit(1)
}

writeFileSync(outFile, JSON.stringify(volume, null, 2) + '\n')
console.log(`\nwrote ${path.relative(path.join(here, '..'), outFile)}`)
