//
//   ⚡  ASTRAL RPG — TELEGRAM ENTRY POINT  ⚡
//
//   Boots ONE platform: grammY long-polling against the bot token in .env,
//   plus the shared plugin set and ./plugins-telegram.
//
//   ── Which DB shape is this? ──────────────────────────────────────────────
//   This is boot.js's "Separate worlds" shape: its own process, its own
//   DB_PATH. Point DB_PATH at the SAME file the WhatsApp bot uses and
//   acquireDbLock() will refuse to start — deliberately. Two processes each
//   holding a stale snapshot of one db.json clobber each other (vanished gold,
//   duplicated items, rolled-back levels), which is the failure lib/
//   player-repo.js:267 documents.
//
//   To give Telegram players their existing WhatsApp character, the supported
//   routes are:
//     • this platform's own /link (plugins/connect.js) — links a Telegram
//       account to a WhatsApp character over the shared DB, or
//     • main-all.js — the future single-process, three-platform entry point
//       described in lib/platform/boot.js's header.
//
//   ── Starting it ──────────────────────────────────────────────────────────
//     node main-telegram.js
//   or under PM2 alongside the WhatsApp app (ecosystem.telegram.cjs), with
//   TELEGRAM_TOKEN set and DB_PATH pointed wherever this world should live.
//
import { config } from './config.js'
import { seedRuntimeData, auditStatePaths, runtimePath } from './lib/runtime-paths.js'
import './lib/fonts.js' // bundled fonts, same reason as main.js
import {
  bootPlatform,
  acquireDbLock,
  installShutdownHandlers,
  globalLog,
  globalError,
} from './lib/platform/boot.js'
import { createTelegramBot } from './adapters/telegram/adapter.js'
import { startTelegramCardSpawns } from './lib/telegram-spawns.js'
import { startGateSpawns } from './lib/gate-spawns.js'
import { CARD_SPAWN_INTERVAL_MS, humanInterval } from './lib/spawn-intervals.js'

async function main() {
  if (!config.telegramToken) {
    globalError(
      'Telegram failed to start: TELEGRAM_TOKEN is empty',
      new Error('TELEGRAM_TOKEN is not set'),
      [
        'Message @BotFather → /newbot → copy the token.',
        'Add it to .env as TELEGRAM_TOKEN=123456:AA… (never commit it).',
        'Set TELEGRAM_OWNER_IDS to your numeric id from @userinfobot.',
      ],
    )
    process.exit(1)
  }

  globalLog('⚡ Astral RPG — Telegram platform')
  globalLog(`🔧 Prefix: ${config.telegramPrefix} (${config.prefix} still accepted)`)

  // ── Which database ───────────────────────────────────────────────────────
  // A Telegram-only process gets its OWN file by default (db-telegram.json on
  // the persistent volume). Using config.dbPath's default would mean this
  // process tries to write the exact file the WhatsApp bot is writing, and
  // acquireDbLock() would refuse to start — correctly, but confusingly, for
  // anyone who just ran `node main-telegram.js`.
  //
  // Set DB_PATH explicitly to point somewhere deliberate. To share ONE
  // database — and therefore one character, which is what /link needs — use
  // main-all.js instead of this file: a shared world is one process, one
  // writer, one lock (lib/platform/boot.js:12).
  const dbPath = process.env.DB_PATH?.trim() || runtimePath('db-telegram.json')
  globalLog(`💾 Telegram db: ${dbPath}`)
  if (dbPath === config.dbPath) {
    globalLog('⚠️ DB_PATH points at the same file main.js uses. Two processes on one db is refused; run main-all.js for a shared world.')
  }

  seedRuntimeData(globalLog)
  const audit = auditStatePaths({ dbPath })
  if (audit.problems?.length) audit.problems.forEach(p => globalLog('⚠️ State path:', p))

  // Refuse to share one DB file with another live process. See header.
  const releaseDbLock = acquireDbLock(dbPath)

  const db = await bootPlatform({ platform: 'telegram', dbPath, pluginDir: './plugins-telegram' })
  globalLog('✅ Plugins loaded for telegram')

  let runtime
  try {
    runtime = await createTelegramBot({ db })
  } catch (err) {
    releaseDbLock?.()
    throw err
  }

  // The hourly wild card for Telegram groups. main.js boots the same sweep;
  // this process does not run lib/background-jobs.js at all, so without this a
  // Telegram-only deployment spawned nothing.
  const spawns = startTelegramCardSpawns(() => runtime.sender, { log: globalLog })

  // Gates, same reason: this process does not run lib/background-jobs.js, so the
  // five-a-day gate clock has to be armed here too or a Telegram-only
  // deployment would never see one open.
  const gates = startGateSpawns(() => ({ db, instances: [], getTelegramSender: () => runtime.sender }), { log: globalLog })

  installShutdownHandlers({
    db,
    releaseDbLock,
    onShutdown: async () => {
      spawns.stop()
      gates.stop()
      globalLog('🛑 Stopping Telegram polling…')
      await runtime.stop()
    },
  })

  const me = runtime.bot.botInfo
  globalLog(`🤖 Connected as @${me?.username ?? '?'} (id ${me?.id ?? '?'}) — polling`)
  globalLog(`💳 Payments on Telegram: ${config.telegramPaymentsEnabled ? 'ENABLED' : 'disabled (locked)'}`)
  globalLog(`🃏 Card spawns armed every ${humanInterval(CARD_SPAWN_INTERVAL_MS)}`)
  globalLog('🚪 Gate sweep armed (five gates a day while the gate season runs)')

  // Resolves when polling stops (bot.stop()), which the shutdown handlers call.
  await runtime.start()
  globalLog('Telegram polling stopped.')
}

main().catch(err => {
  globalError('💥 Telegram boot failed', err, [
    'If this says 401 Unauthorized: the token in .env is wrong or was revoked.',
    'If it says getUpdates 409 Conflict: another process is polling this token.',
  ])
  process.exit(1)
})
