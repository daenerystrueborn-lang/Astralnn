import { refreshGodWorld } from './lib/god-series/world.js'
import { startGodWorldWorker, stopGodWorldWorker } from './lib/god-series/world-worker.js'
//
//   ⚔️  RPGBOT — MAIN CONNECTION  ⚔️
//
//   Runs one or more WhatsApp numbers (see config.js's `bots` array) as
//   independent Baileys sockets INSIDE THIS SINGLE PROCESS, all sharing one
//   `db` (config.dbPath). Running them as one process — instead of one PM2
//   process per number — is deliberate: lib/player-repo.js's write queue
//   only serializes db.read()/db.write() cycles within a single process.
//   Two separate processes hammering the same db.json can each read a
//   stale snapshot and clobber each other's writes (lost gold, vanished
//   items — see the warning already written into player-repo.js about this
//   exact failure mode). One process, one in-memory writeQueue, one file =
//   safe. Two numbers are just two sockets sharing that one queue.
//

import { seedRuntimeData, IS_PERSISTENT, auditStatePaths } from './lib/runtime-paths.js'
import { ffmpegStatus } from './lib/ffmpeg-bin.js'
import './lib/fonts.js' // registers bundled fonts before any canvas draw — see lib/fonts.js
import makeWASocket, {
  DisconnectReason,
  makeCacheableSignalKeyStore,
  Browsers,
  PAIRING_WINDOW_MS,
  isBridgeStartupError,
} from '#wa'
import { useAtomicAuthState, checkCredsIntegrity } from './lib/auth-state.js'
import { Boom } from '@hapi/boom'
import { Low } from 'lowdb'
import { createDbAdapter, describeDbTarget, closeDbAdapter } from './lib/db-adapter.js'
import { mkdir } from 'fs/promises'
import { mkdirSync, createWriteStream, existsSync, readFileSync } from 'fs'
import { basename as pathBasename } from 'path'
import { config, bots } from './config.js'
import { wrapSendWithRateLimit } from './lib/send-rate-limiter.js'
import {
  DECRYPT_FAIL_RE,
  captureLibsignalLine,
  createDecryptLedger,
  createReasonStash,
  createSessionResetPolicy,
  extractDecryptContext,
  formatDecryptLog,
  formatDecryptRecovery,
} from './lib/decrypt-forensics.js'
import { attachInboundPulse, createInboundPulse, describeInboundPulse, guardProcessingMutex } from './lib/inbound-guard.js'
import { createLogThrottle, createFailureReporter, throttleText } from './lib/log-throttle.js'
import { createInboundScheduler, inboundMessageKey } from './lib/inbound-scheduler.js'
import { planReconnect, countsTowardFlap } from './lib/reconnect-policy.js'
import { startLoopLagMonitor, getLoopLagSnapshot } from './lib/loop-lag.js'
import { createStallWatchdog, warnOncePer, WATCHDOG_WARN_EVERY_MS } from './lib/stall-watchdog.js'
import { createMemoryGuard, memoryStartupWarning, sampleMemory } from './lib/memory-guard.js'
import { shedMessageCache } from './lib/message-cache.js'
import { shedItemArtCache } from './lib/item-art-cache.mjs'
import { setHealthProvider } from './lib/bot-health.js'
import { loadPlugins } from './lib/plugin-manager.js'
import { makeHandler } from './handler.js'
import { flushPendingWrites, installReadGuard, startPeriodicSnapshot, stopPeriodicSnapshot, updateAllPlayers } from './lib/player-repo.js'
import { loadStateStores } from './lib/state-store.js'
import { scheduleResetBackupExpiry } from './lib/reset-backups.js'
import { runStartupJobs, startBackgroundJobs } from './lib/background-jobs.js'
import { startTelegramCardSpawns } from './lib/telegram-spawns.js'
import { CARD_SPAWN_INTERVAL_MS, humanInterval } from './lib/spawn-intervals.js'
import { runValidation } from './plugins/validate.js'
import { getGroupSettings } from './lib/group-settings.js'
import { sendToOwner } from './lib/pending-purchase.js'
import { migrateAllPlayers } from './lib/stat-progression.js'
import { repairAllCharacterBonuses } from './lib/character-bonus-fix.js'
import { materializeAllUnlockedPreorders } from './lib/character-preorders.js'
import { runUniqueNameDeduplication } from './lib/unique-names.js'
import { runStarfallWipe, runStarfallReopen, runStarfallRecovery } from './lib/starfall-wipe.js'
// NOT a static import. lib/api-server.js pulls in express, cors,
// cookie-parser and jsonwebtoken — if any of those aren't installed yet
// (fresh clone, `npm install` not run, a failed install), a static import
// here would throw MODULE_NOT_FOUND at load time and take the ENTIRE BOT
// down with it. The website is an add-on; the bot has to survive without
// it. Loaded lazily in main() instead, inside a try/catch.
let startApiServer = null

// ── Kill Baileys internal spam ────────────────────────────────────────────
// Baileys' signal-session internals log a lot of low-value noise straight to
// stdout/stderr even with a silent logger passed in. Filter it at the stream
// level so it never reaches the terminal or the log files.
const SPAM_PATTERNS = [
  'Closing session', 'SessionEntry', 'baseKey', 'baseKeyType',
  'pendingPreKey', 'signedKeyId', 'preKeyId', 'remoteIdentityKey',
  'ephemeralKeyPair', 'currentRatchet', 'registrationId', '_chains',
  'chainKey', 'chainType', 'messageKeys', 'rootKey', '<Buffer',
  'pubKey', 'privKey', 'previousCounter', 'indexInfo',
  'Closing open session', 'Decrypted message with closed session',
  'SessionCipher',
  'decryptWithSessions', 'verifyMAC', 'asyncQueueExecutor', 'closed session',
  'Connection Closed',
]
// DELIBERATELY NOT FILTERED (do not add them back without reading the
// inbound-stall notes in lib/stall-watchdog.js): 'Failed to decrypt', 'Bad MAC',
// 'Session error' and 'rate-overlimit' are the ONLY signals that explain the
// "bot ignores everyone but spawns keep coming" outage. Filtering them made
// that outage undiagnosable — the errors were happening, they just never
// reached the logs.
//
// But note what the old claim missed (fixed 2026-09): the token list above is
// matched anywhere in the chunk, and libsignal prints its reason line and its
// stack as ONE console.error() call —
//
//   console.error("Session error:" + e, e.stack)
//
// — whose stack contains 'SessionCipher' / 'verifyMAC' / 'decryptWithSessions'.
// So the generic "Failed to decrypt…" line got through while the line that
// actually said WHY was dropped, every time. libsignal does not use Baileys'
// logger, so makeWaLogger never saw it either. That is why hours of these
// failures produced no usable diagnosis. installSignalConsoleBridge() below
// now lifts the reason out of that chunk before the filter sees it and hands
// it to the per-instance ledger; the cleaned-up line is logged by
// recordSignalFailure() with a timestamp, the bot name and the sender.
function isSpam(str) {
  if (typeof str !== 'string') return false
  return SPAM_PATTERNS.some(p => str.includes(p))
}
// ── Console repeat guard (2026-10: "I don't want to see log spam of any kind")
// Every console line — ours, Baileys', libsignal's, any plugin's console.log —
// passes through one throttle: the first occurrence of a message always
// prints, repeats of the same message (numbers/ids ignored) are hidden and
// counted, and it may print again only after a growing gap (10 min → 30 min
// → 1 h → 3 h) carrying "(+N similar lines hidden)". See lib/log-throttle.js.
// pino output (config.js `logger`) is throttled the same way at the call.
// The per-bot files under logs/<bot>/ are NOT throttled: they stay complete
// for digging.
const _rawStdoutWrite = process.stdout.write.bind(process.stdout)
const _rawStderrWrite = process.stderr.write.bind(process.stderr)
const consoleThrottle = createLogThrottle()
// Pairing codes are different every time and are the whole point of the line.
const LOG_THROTTLE_EXEMPT = /🔑/u
function writeThrottled(rawWrite, chunk, args) {
  if (typeof chunk !== 'string' && !Buffer.isBuffer(chunk)) return rawWrite(chunk, ...args)
  const text = typeof chunk === 'string' ? chunk : chunk.toString('utf8')
  const out = throttleText(consoleThrottle, text, { exempt: LOG_THROTTLE_EXEMPT })
  if (out === null) {
    // Swallowed — but a caller waiting on the write callback must not hang.
    const cb = args.find(a => typeof a === 'function')
    if (cb) process.nextTick(cb)
    return true
  }
  return rawWrite(out, ...args)
}
const _stdoutWrite = (chunk, ...args) => writeThrottled(_rawStdoutWrite, chunk, args)
const _stderrWrite = (chunk, ...args) => writeThrottled(_rawStderrWrite, chunk, args)
process.stdout.write = (chunk, ...args) => {
  if (isSpam(String(chunk))) return true
  return _stdoutWrite(chunk, ...args)
}
process.stderr.write = (chunk, ...args) => {
  if (isSpam(String(chunk))) return true
  return _stderrWrite(chunk, ...args)
}

// ── libsignal's console output → the per-instance ledger ───────────────────
// libsignal (session_cipher.js, decryptWithSessions) prints the ONLY line that
// names the real failure reason with a bare console.error(), which the stream
// filter above and every logger in Baileys both miss. Wrap the console methods
// to lift the reason out (captureLibsignalLine) before SPAM_PATTERNS can eat
// it, and stash it for the very next Baileys logger error — which is the call
// that knows which instance and which sender the failure belongs to. Order is
// guaranteed: libsignal prints, then throws, then Baileys catches and logs.
const signalReasons = createReasonStash({ ttlMs: 5_000, max: 32 })

/**
 * Flattens console/logger args into one string for pattern matching.
 *
 * Object args are JSON-included on purpose: the stream filter this replaces
 * matched the FORMATTED output, so `console.log('Remote', { registrationId,
 * … })` used to be recognised as credential noise and dropped. Matching only
 * `a.message` would let every such object through — i.e. the bridge would
 * quietly remove a filter that exists to keep session material out of the
 * logs. Error fields are lifted out first because a bare Error serializes to
 * `{}` and would hide the reason.
 */
function extractLogText(args) {
  return args
    .map(a => {
      if (typeof a === 'string') return a
      if (a instanceof Error) return `${a.message} ${a.stack ?? ''}`
      if (a && typeof a === 'object') {
        const bits = []
        if (typeof a.message === 'string') bits.push(a.message)
        if (typeof a.err?.message === 'string') bits.push(a.err.message)
        if (typeof a.msg === 'string') bits.push(a.msg)
        try { bits.push(JSON.stringify(a)) } catch { /* circular — the bits above still match */ }
        return bits.join(' ')
      }
      return a == null ? '' : String(a)
    })
    .join(' ')
    .trim()
}

function installSignalConsoleBridge() {
  const originals = { error: console.error.bind(console), warn: console.warn.bind(console), log: console.log.bind(console) }
  for (const level of ['error', 'warn', 'log']) {
    console[level] = (...args) => {
      const captured = captureLibsignalLine(...args)
      if (captured) {
        signalReasons.remember(extractLogText(args), captured.placeholder)
        return // dropped: recordSignalFailure logs it properly, with context
      }
      if (isSpam(extractLogText(args))) return
      originals[level](...args)
    }
  }
}
installSignalConsoleBridge()

// ── Baileys logger: silent, except the one thing we must never miss ────────
// A wedged Signal session fails to DECRYPT incoming messages ("Failed to
// decrypt" / "Bad MAC"). Baileys drops those messages before
// messages.upsert ever fires — the socket looks perfectly healthy, outbound
// keeps working, and inbound just quietly never arrives. That is exactly the
// "the bot ignores everyone but the card/pokémon spawns keep coming" outage
// (see lib/stall-watchdog.js), and with a fully silent logger it is
// undiagnosable: the errors existed, they just went nowhere.
//
// So: everything stays silent, except warn/error messages that look like
// Signal decryption/session failures. Those go through recordSignalFailure,
// which logs WHO could not be decrypted, WHY (merged in from the libsignal
// console line above), and how many times in the window it has happened —
// then feeds the instance's ledger, which is what the watchdog and `.health`
// read. Retry receipts mean one stuck message can log several times, so the
// detailed line is deduped per sender and the aggregate alert only fires on
// real threshold crossings (see lib/decrypt-forensics.js for why the old
// `n % 25 === 0` re-fired the same "#50" line for hours).
// Kept at 10 minutes on purpose (it briefly became 60s while adding the
// forensics, which would have been a silent regression): the reported outage
// ran at roughly 50 failures per 10 minutes, i.e. ~5/minute. Against a 60s
// window that rate never reaches the limit, so the alert — and the forced
// reconnect behind it — would simply stop firing on the exact incident they
// were written for. The per-sender DETAIL is deduped separately (60s budget,
// then one line per sender per 5 min), so a long window costs no extra noise.
const DECRYPT_FAIL_WINDOW_MS = 10 * 60_000
// This many failures in the window (with no successfully-decrypted message
// since) is a wedged session — only a reconnect renegotiates it.
const DECRYPT_FAIL_LIMIT = 10
// The successful-decrypt path must have been dry at least this long for the
// decrypt-failure trigger to act — a session that is still decrypting fine
// moments ago is not the outage, even if it logged a few stale-session errors.
const DECRYPT_STALE_INBOUND_MS = 60_000
// Never force a second reconnect for this long. If the failures survive the
// first reconnect, reconnecting again does not fix it — it is something else
// (usually the number being logged in twice), and a reconnect loop would only
// drop the send queue while you try to find out what.
const DECRYPT_RECONNECT_COOLDOWN_MS = 5 * 60_000

/** New ledger for one instance — see createDecryptLedger in lib/. */
function makeDecryptLedger() {
  return createDecryptLedger({
    windowMs: DECRYPT_FAIL_WINDOW_MS,
    limit: DECRYPT_FAIL_LIMIT,
    logEveryN: 25,
    // A storm prints its 🚨 summary at most twice an hour.
    alertCooldownMs: 30 * 60_000,
    // One sender = ONE line per incident (2026-10). The old settings printed
    // the first 3 failures of every "window", and any other person's message
    // decrypting reset that window — so one broken sender produced a line
    // every few seconds for hours. Now: reported on its 3rd failure (one Bad
    // MAC is often a replayed message that heals itself), reminded at most
    // every 6 hours if it never heals, and a sender quiet for 30 minutes
    // starts a fresh incident.
    reportAfter: 3,
    perSenderDedupeMs: 6 * 60 * 60_000,
    senderIdleMs: 30 * 60_000,
    maxDistinctSenderLogs: 8,
  })
}

/** New Bad-MAC session-reset policy for one instance — see lib/decrypt-forensics.js. */
function makeSessionResetPolicy() {
  return createSessionResetPolicy({
    threshold: 3,
    // Same horizon as the ledger's incidents: a slow drip of Bad MACs from one
    // device is just as broken as a burst.
    windowMs: 30 * 60_000,
    cooldownMs: 60 * 60_000,
    maxPerHour: 10,
  })
}

/**
 * Forget our stored 1:1 Signal session for one sender device (`user.device`).
 * Baileys' key store treats `null` as delete (lib/auth-state.js removes the
 * session file; the cacheable store drops its cached copy). The next message
 * from that device then builds a fresh session instead of failing Bad MAC
 * forever. Fire-and-forget: called from inside Baileys' logger, which must
 * never wait on (or be broken by) disk I/O.
 */
function resetSignalSession(inst, address) {
  const keys = inst.currentSock?.authState?.keys
  if (!address || !keys || typeof keys.set !== 'function') return false
  Promise.resolve()
    .then(() => keys.set({ session: { [address]: null } }))
    .then(() => {
      inst.sessionResets++
      inst.lastSessionResetAt = Date.now()
    })
    .catch(err => inst.logQuiet?.(`⚠️ could not reset the Signal session for ${address}: ${err?.message ?? err}`))
  return true
}

function recordSignalFailure(inst, args) {
  const text = extractLogText(args)
  if (!text || !DECRYPT_FAIL_RE.test(text)) return

  const now = Date.now()
  const pending = signalReasons.take(now)
  const ctx = extractDecryptContext({ args, text, pendingText: pending?.text ?? '' })
  const reasonText = `${text}\n${pending?.text ?? ''}`

  const out = inst.decryptLedger.record({
    text: reasonText,
    jid: ctx.jid,
    device: ctx.device,
    // A group failure means the participant's SENDER KEY is missing, which is
    // a different protocol from a 1:1 Signal session and heals differently —
    // the hint below says which, so it needs to know.
    group: ctx.group,
    now,
    // 440 within the last 30 min = WhatsApp closed this same number's other
    // socket. That makes the advice specific (find the second instance)
    // instead of the generic "stale session".
    sawSessionConflict: Boolean(inst.sessionConflictAt && now - inst.sessionConflictAt < 30 * 60_000),
  })

  // ── Bad MAC on the same device, again and again → reset that session ────
  // Retry receipts cannot fix a session that no longer matches the sender's:
  // the re-sent message hits the same broken session and fails the same way
  // (the endless "could not decrypt … 238105034498180:0" loop). Deleting our
  // copy makes the next exchange build a fresh one. Rate-limited per device
  // and per bot — see createSessionResetPolicy.
  const plan = inst.sessionResetPolicy.noteFailure({ address: ctx.signalAddress, kind: out.kind, now })
  if (plan.reset && resetSignalSession(inst, ctx.signalAddress)) {
    out.sessionReset = true
    if (!out.logForensic) {
      inst.logQuiet?.(`🩹 reset the Signal session for ${ctx.signalAddress} after ${plan.count} Bad MAC failure(s)${plan.repeat ? ' (again)' : ''}`)
    }
  }

  for (const line of formatDecryptLog({ botName: inst.botName, outcome: out, context: ctx, windowMs: DECRYPT_FAIL_WINDOW_MS })) {
    globalErrorLog(line)
  }
}

function makeWaLogger(inst) {
  const noop = () => {}
  const capture = (...args) => {
    try { recordSignalFailure(inst, args) } catch { /* never break whatsmeow over a logger */ }
  }
  return {
    level: 'silent',
    trace: noop, debug: noop, info: noop,
    warn: capture, error: capture, fatal: capture,
    child: () => makeWaLogger(inst),
  }
}

// ── Global (not-instance-specific) log helper ───────────────────────────────
// Normal informational logs still go to stdout (pm2-out.log).
function globalLog(...args) {
  const line = `[${new Date().toISOString()}] ` + args.join(' ') + '\n'
  _stdoutWrite(line)
}

// Startup chatter (schedules, versions, paths) is hidden by default so the
// console shows only pairing codes, connected messages and the MongoDB line.
// Set VERBOSE_STARTUP=1 to bring all of it back. Real warnings and errors are
// never routed through here.
const VERBOSE_STARTUP = process.env.VERBOSE_STARTUP === '1'
function bootLog(...args) {
  if (VERBOSE_STARTUP) globalLog(...args)
}

// Routine status lines (League ticks, rollovers, idle scans…) — written to
// logs/system/out.log only, so they are there when you go looking but never
// scroll past on the console. VERBOSE_STARTUP=1 echoes them to the console.
let _quietLogStream = null
function globalQuietLog(...args) {
  const line = `[${new Date().toISOString()}] ` + args.join(' ') + '\n'
  try {
    if (!_quietLogStream) {
      mkdirSync('./logs/system', { recursive: true })
      _quietLogStream = createWriteStream('./logs/system/out.log', { flags: 'a' })
      _quietLogStream.on('error', () => { _quietLogStream = null })
    }
    _quietLogStream?.write(line)
  } catch { /* a log line must never break its caller */ }
  if (VERBOSE_STARTUP) _stdoutWrite(line)
}

// Lines that need a human (warnings, failures) stay on the console; the rest
// of what a subsystem reports is routine and goes to the quiet file.
// (⚠ without its variation selector, so both spellings of the emoji match.)
const NEEDS_ATTENTION_RE = /^\s*(⚠|❌|🚨|💥|🛑)/u
function routineOrAlert(line) {
  if (NEEDS_ATTENTION_RE.test(String(line))) globalLog(line)
  else globalQuietLog(line)
}
// Plain, un-timestamped line so columns stay aligned and easy to read.
function sayLine(text) {
  _stdoutWrite(text + '\n')
}

/*
 * ── Boot barrier ──────────────────────────────────────────────────────────
 *
 * "Is the bot up, or is it stuck?" has to be answerable from the log alone, and
 * on a first boot the answer used to be genuinely unclear: the pairing code was
 * requested from inside connect(), i.e. from inside main()'s connect loop, so
 * the process's own startup lines and the `❌ paired_number.txt not found`
 * complaint arrived INTERLEAVED — and the website API, which is what a platform
 * like Railway watches to decide the deploy is up, only called listen() after
 * all of it.
 *
 * markBootComplete() is called once at the end of main(), after the database,
 * the plugins, the website's port and every sweep exist. Anything that is
 * *output for the owner* rather than a step of the boot waits on
 * whenBootComplete() so it is printed after that line, never before it.
 * Promise-based, not a polling loop, so a waiter resumes on the very next
 * microtask after main() finishes.
 */
let _bootComplete = false
const _bootWaiters = []
function markBootComplete() {
  if (_bootComplete) return
  _bootComplete = true
  for (const resolve of _bootWaiters.splice(0)) resolve()
}
function whenBootComplete() {
  return _bootComplete ? Promise.resolve() : new Promise(resolve => _bootWaiters.push(resolve))
}

// Crash-level logs go to stderr on purpose, so PM2 puts them in
// pm2-err.log — this is what you should be checking when the bot goes
// quiet / stops responding.
function globalErrorLog(...args) {
  const line = `[${new Date().toISOString()}] ` + args.join(' ') + '\n'
  _stderrWrite(line)
}

const runStallWatchdog = createStallWatchdog({
  errorLog: globalErrorLog,
  getLoopLagSnapshot,
  decryptFailLimit: DECRYPT_FAIL_LIMIT,
  decryptFailWindowMs: DECRYPT_FAIL_WINDOW_MS,
  decryptStaleInboundMs: DECRYPT_STALE_INBOUND_MS,
  decryptReconnectCooldownMs: DECRYPT_RECONNECT_COOLDOWN_MS,
})

// ── Global error guards ────────────────────────────────────────────────────
process.on('uncaughtException', (err) => {
  globalErrorLog('💥 uncaughtException:', err?.message ?? err)
  globalErrorLog('📍 Stack trace:\n' + (err?.stack ?? '(no stack)'))
})
process.on('unhandledRejection', (reason) => {
  const msg = reason?.message || String(reason)
  if (msg === 'Connection Closed' || msg === 'rate-overlimit') return
  globalErrorLog('💥 unhandledRejection:', msg)
  globalErrorLog('📍 Stack trace:\n' + (reason?.stack ?? '(no stack)'))
})

// ── Graceful shutdown (PM2 / VPS signals) ───────────────────────────────────
// Set once main() finishes initDb() — lets shutdown flush any write that's
// still sitting in player-repo.js's debounce window instead of losing up to
// FLUSH_DEBOUNCE_MS worth of the most recent mutations on restart/deploy.
let _dbRef = null
let _instancesRef = null
let _backgroundJobsRef = null
// Telegram, when TELEGRAM_TOKEN is set. See startTelegramIfConfigured().
let _telegramRef = null
/** Hourly Telegram card spawns — see lib/telegram-spawns.js. Null when Telegram is off. */
let _telegramSpawnsRef = null

// Exported so main-all.js can reuse the ONE Low instance main() opens instead
// of calling initDb() again. A second Low instance on the same db.json runs its
// own steno write cycle (write .db.json.tmp → rename onto db.json) with no lock
// shared with this one; two of those overlapping is what produced
// "ENOENT: no such file or directory, rename '.db.json.tmp' -> './db.json'".
// Returns null until main()'s initDb() resolves — callers poll for it.
/**
 * The live bot instances, for background work that outlives a command.
 *
 * A view timer runs for days after the player who started it has gone quiet,
 * so it cannot hold the ctx it was born in: that socket will have been
 * replaced by at least one reconnect. It asks here instead, every time it
 * sends, and always gets whichever socket is current.
 */
export function getBotInstances() {
  return _instancesRef ?? []
}

export function getDb() {
  return _dbRef
}

let _isShuttingDown = false

/**
 * Stop the timers, flush every pending db write and every instance's pending
 * creds, release the auth locks, hand back the remote writer lock. Does NOT
 * exit — the caller decides how and with what status.
 *
 * Split out of gracefulShutdown() so lib/memory-guard.js can run the identical
 * sequence before its deliberate restart. That reuse is the whole point of the
 * guard: a heap-limit abort or a kernel OOM-kill loses whatever was in flight,
 * while this path gets it onto disk first. Idempotent, because a memory
 * restart and a SIGTERM can legitimately race.
 */
async function flushStateBeforeExit(reason) {
  if (_isShuttingDown) return
  _isShuttingDown = true
  globalLog(`🧹 Flushing state before exit (${reason})…`)
  _backgroundJobsRef?.stop()
  _backgroundJobsRef = null

  // Stop Telegram before the database is closed: a long poll that lands after
  // closeDbAdapter() would try to read a closed store.
  // Stop the spawn timer first: a spawn landing after the socket stops is a
  // send that half-completes on the way out.
  _telegramSpawnsRef?.stop()
  _telegramSpawnsRef = null

  if (_telegramRef) {
    try {
      await _telegramRef.stop()
      globalLog('🤖 Telegram polling stopped.')
    } catch (err) {
      globalLog('⚠️ Failed to stop Telegram cleanly:', err?.message ?? err)
    }
    _telegramRef = null
  }

  if (_dbRef) {
    await stopGodWorldWorker(_dbRef)
    stopPeriodicSnapshot()
    try {
      await flushPendingWrites(_dbRef)
      globalLog('💾 Pending database writes flushed.')
    } catch (err) {
      globalLog('⚠️ Failed to flush pending writes on shutdown:', err?.message ?? err)
    }
  }

  // Flush any pending debounced WhatsApp credentials before exit
  if (_instancesRef) {
    for (const inst of _instancesRef) {
      if (typeof inst.flushPendingCreds === 'function') {
        try {
          await inst.flushPendingCreds()
          globalLog(`💾 Pending credentials flushed for ${inst.botName}.`)
        } catch (err) {
          globalLog(`⚠️ Failed to flush pending creds for ${inst.botName}:`, err?.message ?? err)
        }
      }
      try {
        inst.authState?.releaseLock?.()
      } catch {}
    }
  }

  // Hand the remote writer lock back so a redeploy can take over immediately
  // instead of waiting for the heartbeat to go stale. No-op on local files.
  await closeDbAdapter()
}

async function gracefulShutdown(signal) {
  globalLog('🛑', signal, 'received — shutting down gracefully...')
  await flushStateBeforeExit(signal)
  globalLog('✅ Shutdown complete.')
  process.exit(0)
}
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'))
process.on('SIGINT',  () => gracefulShutdown('SIGINT'))

// ── Memory guard ────────────────────────────────────────────────────────────
// Owns "the bot stops working and the log says nothing". lib/memory-guard.js
// holds the logic and the reasoning; this is only the wiring: the two cache
// shedders that exist, the flush-before-exit hook above, and the log file the
// timeline is written to.
//
// The log path is deliberately beside globalQuietLog's logs/system/out.log —
// a separate file because it has to stay readable as a straight line after a
// crash, which is exactly when the console log is full of the restart that
// followed it.
const memoryGuard = config.memoryGuardEnabled
  ? createMemoryGuard({
      highPct: config.memoryHighPct,
      criticalPct: config.memoryCriticalPct,
      rssCriticalPct: config.memoryRssCriticalPct,
      criticalTicks: config.memoryCriticalTicks,
      shedCooldownMs: config.memoryShedCooldownMs,
      // Monitor-only unless explicitly opted in — see config.js.
      shedEnabled: config.memoryShedEnabled,
      restartEnabled: config.memoryRestartEnabled,
      log: globalLog,
      errorLog: globalErrorLog,
      logFile: './logs/system/memory.log',
      // Same sequence PM2's SIGTERM would run — creds and db land on disk
      // before the process goes, which is the entire advantage of restarting
      // on purpose instead of being killed.
      beforeExit: () => flushStateBeforeExit('memory guard restart'),
    })
  : null

if (memoryGuard) {
  // Both of these are pure caches: dropping them costs a re-render or an
  // un-repostable deleted message, never player data.
  memoryGuard.registerShedder('message cache', () => shedMessageCache({ keepNewest: 100 }))
  memoryGuard.registerShedder('item art', () => shedItemArtCache())
}

// ── Database (ONE shared db for every bot instance) ─────────────────────────
async function initDb() {
  // Storage is chosen by lib/db-adapter.js, not hardcoded here. Either way
  // config.dbPath is the live database, written by the same atomic writer as
  // before (lib/fast-json-adapter.js — no pretty-printing, temp file +
  // rename); with MONGO_URI set in .env, each save is additionally copied up
  // to MongoDB right after it lands, so losing this box no longer loses the
  // players. The read()/write() contract is identical in both cases, so the
  // shared write queue in lib/player-repo.js, and every plugin above it, is
  // untouched.
  // Move/keep mutable state on the persistent volume BEFORE anything reads
  // it. On Railway the container is rebuilt from GitHub each deploy, so any
  // state written back into the repo's ./data (group settings, moderation,
  // spawn lists) and ./db.json reverts on the next push unless it lives on a
  // mounted volume. seedRuntimeData() copies the existing files across once,
  // then leaves the volume authoritative forever after. No volume mounted =
  // no-op, identical to the old behaviour. See lib/runtime-paths.js.
  seedRuntimeData(globalLog)
  if (!IS_PERSISTENT) {
    globalLog(
      '⚠️ State is stored inside the deployment (./data, ./db.json). On Railway this ' +
      'resets on every redeploy — mount a volume and set RUNTIME_DATA_DIR=/data to keep it.',
    )
  }

  // Unconditional, on purpose. A volume can be mounted and healthy while
  // AUTH_FOLDER — set before the volume existed, and RAILWAY.md tells people to
  // keep it — still points inside the container. Every other state file then
  // persists and ONLY the pairing is wiped each deploy, which looks exactly
  // like "WhatsApp keeps logging me out" and nothing else in the boot output
  // contradicts it. Naming the paths and the variable to change ends that
  // guess. See auditStatePaths().
  {
    const audit = auditStatePaths({
      authFolders: bots.map(b => b.authFolder),
      dbPath: config.dbPath,
    })
    globalLog(
      `📁 State: ${audit.persistent ? `persistent volume at ${audit.runtimeDir}` : 'NOT persistent (inside the deployment)'}` +
      ` · auth ${bots.map(b => b.authFolder).join(', ')} · db ${config.dbPath}`,
    )
    for (const problem of audit.problems) {
      globalLog(`🚨 ${problem.path}: ${problem.kind}. Fix: ${problem.fix}`)
    }
  }

  const adapter = createDbAdapter(config.dbPath, { log: globalLog, warn: globalErrorLog })
  // Default structure — expand when RPG features are added
  const db = new Low(adapter, { users: {}, sessions: {}, bans: {}, mods: [] })
  // Every plugin ranking/board command calls the raw `await db.read()`, and
  // lowdb's read() replaces db.data wholesale with the FILE. With player
  // writes debounced (lib/player-repo.js's scheduleFlush), the file lags RAM
  // for the length of that window — so a raw read rewound the world and the
  // next flush persisted the rollback. See installReadGuard()'s comment.
  installReadGuard(db)
  await db.read()
  // The side stores (group settings, moderation, night mode, spin locks,
  // spawn lists, mod-GC queue, Telegram registry) hydrate here, in ONE query
  // in DB_MODE=mongo-only, before anything is served. No-op in file mode —
  // see lib/state-store.js. Must run after createDbAdapter (it borrows the
  // adapter's connection) and before the first message handler or sweep.
  await loadStateStores()
  if (config.clusterMode) await refreshGodWorld()
  // Low's default data only applies on first-ever creation of db.json — an
  // existing db.json from before the ban feature won't have `bans` at all,
  // so backfill it here rather than crashing every ban lookup on undefined.
  if (!db.data.bans) db.data.bans = {}
  // Same backfill for `mods` (global mod list — see lib/mod-repo.js),
  // added after ban support.
  if (!db.data.mods) db.data.mods = []
  await db.write()
  scheduleResetBackupExpiry(db)
  bootLog('💾 Database ready (shared by all bot instances):', describeDbTarget(config.dbPath))
  return db
}

// ── Auth-state integrity check ───────────────────────────────────────────
// Implemented and exported from lib/auth-state.js with crash-safe atomic
// writes, .bak backup recovery, and multi-instance conflict guarding.

/**
 * The digits on one 1 based line of a paired_number file, or ''.
 *
 * One file carries every number the process runs, one per line, and each
 * instance reads only its own line. Splitting on the line FIRST and stripping
 * non-digits after is the whole point: doing it the other way round would join
 * two numbers into one long digit string the moment a second line existed, and
 * requestPairingCode() would be handed a number that belongs to nobody.
 *
 * A blank line, a line holding a note-to-self, or a missing file all read as
 * '', which is what the caller already treats as "not filled in yet".
 *
 * @param {string} file path to the paired_number file
 * @param {number} [line] 1 based line number, defaulting to the first
 * @returns {string} digits only, possibly empty
 */
function readPhoneLine(file, line = 1) {
  try {
    const lines = readFileSync(file, 'utf-8').split(/\r?\n/)
    return (lines[Math.max(1, Number(line) || 1) - 1] ?? '').trim().replace(/\D/g, '')
  } catch {
    return ''
  }
}


// HARD LIMIT: the whole pairing flow — requesting the code, retries while the
// socket settles, and the phone entering it — gets ONE 60 s budget, measured
// from the first request. When it runs out the unlinked connection is torn
// down (wa-bridge does it too, as a backstop) and nothing re-requests a code
// until the bot is restarted.
const PAIRING_CODE_REQUEST_WINDOW_MS = PAIRING_WINDOW_MS
const PAIRING_CODE_RETRY_INTERVAL_MS = 3_000

/**
 * Ask WhatsApp for a pairing code for this instance, if it hasn't been linked
 * yet, and print it once the bot is already up.
 *
 * FIRE AND FORGET — never awaited by openConnection(). It used to run inline
 * there, and that one `await` was the whole first-boot problem:
 *
 *   • `await inst.connect(db)` inside main()'s connect loop could not return
 *     until this function had slept 3s and either got a code or exhausted its
 *     retry window — so the *rest of the boot*, the website API's listen()
 *     included, waited on it;
 *   • the pairing complaint about a missing paired_number.txt therefore
 *     appeared BETWEEN boot lines, in the middle of startup, which reads as
 *     "the bot is stuck loading" rather than "the bot is running and this one
 *     number isn't linked yet".
 *
 * Now: connect() returns as soon as the socket exists, boot finishes, listen()
 * is called, and only then (boot barrier + a settle delay) does the code get
 * requested and printed — as the last, unmissable thing in the log.
 *
 * @param {object} inst bot instance (read for phoneFile/phoneLine/botName)
 * @param {object} sock the socket this request was queued for
 * @param {{log: Function, logQuiet: Function}} loggers per-instance writers
 */
async function requestPairingCodeWhenUnlinked(inst, sock, { log, logQuiet }) {
  // Wait for the boot to finish first — see markBootComplete()'s note.
  await whenBootComplete()

  // Give the socket a moment to stabilize before hitting the pairing
  // endpoint — requesting immediately on a still-settling connection is
  // a common cause of an instant 401 right after the code is issued.
  await new Promise(r => setTimeout(r, 3_000))

  // Read the file BEFORE deciding it's usable. An existing-but-blank phone
  // file used to pass the existsSync check, hand '' to requestPairingCode()
  // and fail before explaining the actual problem — which sent people deleting
  // a healthy auth folder when the real problem was a file they hadn't filled
  // in yet. Non-digits are
  // stripped, so a file holding a note-to-self reads as blank here too.
  //
  // ONE file holds every number, one per line, and each instance takes only
  // its own line (config.js's phoneLine, 1 based). Reading the whole file
  // and stripping non-digits would concatenate two numbers into a single
  // unusable string the moment a second line was added, and pair neither.
  const phone = readPhoneLine(inst.phoneFile, inst.phoneLine ?? 1)
  const hasPhoneFile = existsSync(inst.phoneFile) && phone !== ''

  if (!hasPhoneFile) {
    // Says BOTH halves on purpose: what is missing, and that the process itself
    // is fine. On a first boot this line is the difference between "it's waiting
    // for me to add a number" and "it's broken and I don't know why".
    log(
      `❌ ${inst.phoneFile} not found! Create it with your number, e.g. 2348012345678 ` +
      `— the bot itself is running; this number just can't come online until that file exists, then restart it.`,
    )
  } else if (phone.length < 8) {
    // Shorter than a country code + subscriber number: a typo or a
    // placeholder, never a real number.
    log(`❌ ${inst.phoneFile} has no usable number in it (${phone ? `only got "${phone}"` : 'the file is empty'}). Put your number in it, digits only, e.g. 2348012345678`)
  } else {
    // The socket this was queued for can be gone by now: an unstable first
    // handshake (statusCode 428 is the usual one) closes in well under 3s and
    // the reconnect replaces it. Asking the pairing endpoint through a retired
    // socket cannot work. Clear the request flag for this socket so a new one
    // can ask; the socket identity is checked before every retry, including
    // after the 3s gap between attempts.
    let replaced = false
    let code = null
    let attempt = 0
    let lastError = null
    const requestDeadline = Date.now() + PAIRING_CODE_REQUEST_WINDOW_MS
    while (!code && Date.now() < requestDeadline) {
      if (sock.authState?.creds?.registered || inst.currentSock !== sock) {
        replaced = true
        break
      }
      const remainingBudgetMs = requestDeadline - Date.now()
      if (remainingBudgetMs < 1_000) break
      attempt++
      try {
        logQuiet('📱 Requesting pairing code for:', phone)
        // Whatever is left of the shared 60 s budget becomes the code's lifetime.
        code = await sock.requestPairingCode(phone, { windowMs: remainingBudgetMs })
      } catch (err) {
        lastError = err
        // An absent/broken executable is a deployment failure, not a WhatsApp
        // transport hiccup. The close handler explains it once; never retry it.
        if (isBridgeStartupError(err)) {
          logQuiet('Pairing stopped because the WhatsApp bridge could not start:', err.message)
          return
        }
        // Retry transient socket-not-ready errors for up to one minute. The
        // phone-issued code's own expiry is controlled by WhatsApp, not here.
        if (attempt === 1) {
          log(`⚠️ Pairing-code request did not send yet; retrying for up to ${Math.round(PAIRING_CODE_REQUEST_WINDOW_MS / 1000)}s:`, err.message)
        }
        const remainingMs = requestDeadline - Date.now()
        if (remainingMs > 0) {
          await new Promise(r => setTimeout(r, Math.min(PAIRING_CODE_RETRY_INTERVAL_MS, remainingMs)))
        }
      }
    }

    if (!code && replaced) {
      if (inst.pairingRequestSocket === sock) {
        inst.pairingRequested = false
        inst.pairingRequestSocket = null
      }
      logQuiet('↩️ Socket was replaced while the pairing code was being requested — the new socket can request its own code.')
    } else if (!code) {
      if (inst.pairingRequestSocket === sock) {
        inst.pairingRequested = false
        inst.pairingRequestSocket = null
      }
      log(
        `❌ Could not get a pairing code from WhatsApp within ${Math.round(PAIRING_CODE_REQUEST_WINDOW_MS / 1000)}s ` +
        `(${attempt} attempts${lastError ? `; last error: ${lastError.message}` : ''}). Keep the auth folder; check the connection and restart to try again.`,
      )
    } else {
      const shown = /^[A-Z0-9]{8}$/i.test(code) ? `${code.slice(0, 4)}-${code.slice(4)}` : code
      inst.lastPairingCode = shown
      inst.lastPairingCodeIssuedAt = Date.now()
      logQuiet('📱 Pairing code issued:', code)
      const secondsLeft = Math.max(1, Math.round((requestDeadline - Date.now()) / 1000))
      sayLine(`  🔑  ${String(inst.phoneLine ?? 1)}  ${inst.botName.padEnd(20)}  ${phone.padEnd(15)}  ${shown}  ⏱ enter within ${secondsLeft}s`)
    }
  }
}

// ── One WhatsApp connection ─────────────────────────────────────────────────
// `botCfg` is one entry from config.js's `bots` array: { botName, authFolder,
// phoneFile }. `inst` is a small per-instance state bag (log stream, pairing
// flags, activeSock) that this function closes over instead of using
// module-level globals — that's what lets multiple numbers run side by side
// in one process without stepping on each other's state.
function createBotInstance(botCfg) {
  const inst = {
    botName: botCfg.botName,
    authFolder: botCfg.authFolder,
    phoneFile: botCfg.phoneFile,
    // 1 based line of phoneFile this number reads. Without this the second
    // bot fell back to line 1 and tried to pair the FIRST number.
    phoneLine: botCfg.phoneLine ?? 1,
    activeSock: null,
    // Guards a pairing code from being re-requested on every reconnect —
    // without this, Baileys' first unstable handshake (statusCode 428)
    // causes connect() to be called again 5s later, which requests a
    // brand new code before you've had a chance to enter the old one.
    pairingRequested: false,
    pairingRequestSocket: null,
    lastPairingCodeIssuedAt: 0,
    // Tracks whether we've ever reached connection === 'open' this run —
    // used so a fake/soft 401 doesn't wipe a session that was already paired.
    wasEverConnected: false,
    // Ensures the "bot is online" DM to the owner fires once per process
    // start for THIS number, not on every reconnect.
    onlineDmSent: false,
    // Counts consecutive unpaired-session (401) retries — used to stop
    // reconnecting and printing new codes every minute forever if linking
    // keeps failing.
    unpairedRetryCount: 0,

    // ── Liveness bookkeeping (read by runStallWatchdog + plugins/health.js) ──
    // When connection === 'open' last happened, when we last saw ANY inbound
    // upsert at all, and — the number that actually matters — when a message
    // last DECRYPTED successfully.
    //
    // The distinction is the whole 2026-09 bug: Baileys still emits
    // undecryptable messages to messages.upsert as a CIPHERTEXT stub with no
    // `.message`, so stamping lastInboundAt on every upsert made the
    // decrypt-failure watchdog trigger unreachable — the very failures that
    // wedge the session kept the "inbound is alive" clock fresh. The watch
    // therefore runs on lastDecryptOkAt (plaintext arrived), while
    // lastInboundAt/inboundCount stay as raw delivery counters for `.health`.
    openedAt: 0,
    lastInboundAt: 0,
    inboundCount: 0,
    lastDecryptOkAt: 0,
    stubCount: 0,
    lastStubAt: 0,
    lastForcedReconnectAt: 0,
    forcedReconnect: false,

    // ── Inbound-stall evidence (2026-09) ───────────────────────────────────
    // When the inbound scheduler FIRST showed a wedge (work accepted but not
    // draining, or a handler detached as stuck). 0 = healthy so far. The
    // watchdog in lib/stall-watchdog.js only acts after this evidence persists —
    // a busy minute drains in seconds and never sets it.
    inboundStallSince: 0,
    // Sliding-window ledger of Signal decryption failures + plaintext
    // recoveries, filled by recordSignalFailure (Baileys logger) with reasons
    // bridged in from libsignal's console output. A burst here with a dry
    // plaintext path is a wedged session — a reconnect is the only fix.
    decryptLedger: makeDecryptLedger(),
    // When WhatsApp last closed this socket with statusCode 440 (session
    // conflict = the same number connected twice somewhere). Used to sharpen
    // the decryption advice: 440 + Bad MAC is the double-login signature.
    sessionConflictAt: 0,
    // When we last logged "failures survived a reconnect, this is not a stale
    // session" so the message is printed once per cooldown, not every tick.
    decryptPersistLoggedAt: 0,
    // Bad-MAC session resets (2026-10): when one sender device keeps failing,
    // our stored session for it is deleted so the next message builds a fresh
    // one (recordSignalFailure / makeSessionResetPolicy). Survives reconnects:
    // a reconnect does not fix a sender's session.
    sessionResetPolicy: makeSessionResetPolicy(),
    sessionResets: 0,
    lastSessionResetAt: 0,
    // Baileys receive-pipeline guard + raw-stanza pulse for the CURRENT socket
    // (lib/inbound-guard.js, watchdog evidence #3). Replaced on every connect.
    mutexGuard: null,
    inboundPulse: null,
    // The last pairing code printed, so the "not linked yet" line can name it.
    lastPairingCode: null,
    // Whether the creds on disk say this number is linked. Sampled at connect
    // time and used by the boot summary ("is this a first boot or not?"), so
    // the log can say whether a 🔑 code is coming without waiting for one.
    linked: false,
    // Rate-limit memory for the watchdog's repeating diagnostics (warnOncePer).
    warnedAt: {},

    // ── Reconnect hygiene ───────────────────────────────────────────────────
    // connect() used to be callable from several places at once: every
    // 'close' event scheduled its own call, and a retired socket's late
    // 'close' could land after a new socket had already opened. Two overlapping
    // connects on one auth folder is exactly what produces WhatsApp's
    // statusCode 440 (session conflict), which closes both sockets, which
    // schedules two more connects — a loop that gets worse the longer it runs.
    // currentSock + connectInFlight + one reconnectTimer make "at most one
    // socket, at most one pending reconnect" an invariant instead of a hope.
    currentSock: null,
    connectInFlight: false,
    reconnectTimer: null,
    // How many transient closes in a row this instance has taken (reset on
    // 'open'). lib/reconnect-policy.js uses it to escalate from a 3s retry to
    // a cooldown + alert, which is what keeps "come back fast after a blink"
    // from turning into "hammer WhatsApp for an hour during a real outage".
    transientCloseStreak: 0,
    // Bounded inbound work queue for the currently active socket. Retired
    // sockets clear its pending messages during connection.close.
    inboundScheduler: null,
  }

  // Bot log file — appends to logs/<botName>/out.log, still shows in pm2
  // logs. Log folder name is derived from botName but sanitized for the
  // filesystem — spaces and special characters are fine in chat messages
  // but awkward to type/quote when navigating logs over SSH. Each bot
  // instance gets its own folder so the two numbers' logs never interleave
  // in the same file.
  const logDirSlug = inst.botName.replace(/[^a-zA-Z0-9_-]+/g, '-')
  const logDir = `./logs/${logDirSlug}`
  mkdirSync(logDir, { recursive: true })
  const logStream = createWriteStream(`${logDir}/out.log`, { flags: 'a' })

  function log(...args) {
    const line = `[${new Date().toISOString()}] [${inst.botName}] ` + args.join(' ') + '\n'
    _stdoutWrite(line)      // still shows in pm2 logs
    logStream.write(line)   // also written to this bot's own log folder
  }
  inst.log = log
  // File-only unless VERBOSE_STARTUP=1: still in logs/<bot>/out.log for debugging.
  function logQuiet(...args) {
    if (VERBOSE_STARTUP) return log(...args)
    logStream.write(`[${new Date().toISOString()}] [${inst.botName}] ` + args.join(' ') + '\n')
  }
  inst.logQuiet = logQuiet

  // ── creds saves that fail ─────────────────────────────────────────────────
  // A failing save used to print `⚠️ saveCreds error: …` on every attempt.
  // `creds.update` fires every few seconds on a busy connection, so a save that
  // could not succeed — the reported one: ENOENT because /data/auth_info_2 had
  // been deleted under the running bot — produced a line every ~3s for as long
  // as it lasted, in the console AND in logs/<bot>/out.log. Two guards now, in
  // order:
  //   • lib/auth-state.js recreates a missing auth folder, so that particular
  //     failure heals on the next write instead of repeating at all;
  //   • anything else that still fails goes through this reporter — first
  //     failure now, repeats counted and printed only on the throttle's growing
  //     schedule (10m → 30m → 1h → 3h), plus ONE line when it works again. The
  //     per-bot file gets the same reduced lines on purpose: it is deliberately
  //     not stream-throttled, and a line every 3 seconds for days is growth,
  //     not forensics.
  // Deliberately per-INSTANCE, not per-connection: a failing save must not get
  // a fresh report just because a reconnect built a new socket.
  const credsSaveReporter = createFailureReporter({
    label: `${inst.botName} creds save`,
    hint:
      'The session is still in memory; if this keeps up, check that the auth folder\'s volume is mounted ' +
      'and writable (see lib/auth-state.js), then re-pair if WhatsApp rejects the session.',
  })
  const reportCredsSaveFailure = (err, context) => {
    const out = credsSaveReporter.fail(err)
    if (out.print) log(context ? `${out.text} (${context})` : out.text)
  }
  const noteCredsSaveOk = () => {
    const out = credsSaveReporter.ok()
    if (out.print) log(out.text)
  }

  /**
   * The ONLY way a reconnect is scheduled. Collapses duplicate requests (two
   * closes in the same second, a watchdog kill racing a real close) into one
   * pending attempt, and retries by itself if the attempt throws before a
   * socket even exists.
   *
   * That last part matters: connect() awaits mkdir + useMultiFileAuthState
   * before building the socket, and any throw in there used to reject an
   * un-awaited promise. The process stayed alive with NO socket and nothing
   * scheduled to try again — offline until someone noticed and ran
   * `pm2 restart rpg-bot`.
   */
  inst.scheduleReconnect = function scheduleReconnect(db, delayMs, reason, { quiet = false } = {}) {
    if (inst.reconnectTimer) {
      logQuiet(`↩️ Reconnect already scheduled — ignoring duplicate request (${reason}).`)
      return
    }
    // `quiet`: the caller already printed the one line that matters (e.g. the
    // unpaired-number retries below) — this one goes to the bot's log file.
    ;(quiet ? logQuiet : log)(`🔄 Reconnecting in ${Math.round(delayMs / 1000)}s (${reason})…`)
    inst.reconnectTimer = setTimeout(() => {
      inst.reconnectTimer = null
      inst.connect(db).catch(err => {
        log('⚠️ Reconnect attempt failed before a socket was created:', err?.message ?? err)
        inst.scheduleReconnect(db, 30_000, 'previous attempt threw')
      })
    }, delayMs)
  }

  /**
   * The reconnect knobs this instance hands lib/reconnect-policy.js, built once
   * so the forced path and the ordinary close path cannot drift apart (they
   * used to be two hardcoded numbers, 5_000 and 60_000, with the reasoning for
   * each written down only in the other file).
   */
  const reconnectPolicy = {
    fastBaseMs: config.reconnectFastBaseMs,
    fastMaxMs: config.reconnectFastMaxMs,
    fastMaxAttempts: config.reconnectFastMaxAttempts,
    slowMs: config.reconnectSlowMs,
    forcedMs: config.reconnectForcedMs,
  }

  const openConnection = async function connect(db) {
    await mkdir(inst.authFolder, { recursive: true })

    // Check the file on disk BEFORE useAtomicAuthState() touches it — see the
    // header comment in lib/auth-state.js for why Baileys' own loader can't
    // tell a corrupted creds.json from a missing one. Once that call returns,
    // both are indistinguishable (both become a fresh initAuthCreds()), so
    // this is the only point where "was there actually a broken file here"
    // can still be answered.
    const credsCheck = await checkCredsIntegrity(inst.authFolder, { log: globalErrorLog })
    if (credsCheck.status === 'recovered') {
      globalErrorLog(
        `🚨 [${inst.botName}] RECOVERY: creds.json was corrupted, but a valid backup (creds.json.bak) was found! ` +
        `Successfully restored credentials from backup and continuing session.`,
      )
    } else if (credsCheck.status === 'corrupted') {
      globalErrorLog(
        `🚨 [${inst.botName}] CRITICAL: creds.json integrity check failed: ${credsCheck.reason}. ` +
        `This is NOT a normal first pairing! If this instance was previously paired and working, ` +
        `the session files are corrupted or missing without a valid backup.`,
      )
    } else {
      logQuiet(`✅ Auth state check: ${credsCheck.reason}`)
    }

    const authState = await useAtomicAuthState(inst.authFolder, { botName: inst.botName, log })
    inst.authState = authState
    const { state, saveCreds } = authState
    // WhatsApp connectivity runs through the whatsmeow sidecar (wa-bridge/).
    // Session keys live in <authFolder>/whatsmeow.db; creds.json only tracks
    // the `registered` flag. The WhatsApp Web version is handled by whatsmeow.
    const sock = makeWASocket({
      authDir: inst.authFolder,
      auth: { creds: state.creds, keys: state.keys },
      browser: Browsers.ubuntu('Chrome'),
      logger: makeWaLogger(inst),
    })

    // ── Receive-pipeline guard (2026-10) ───────────────────────────────────
    // (1) Baileys' shared receive lock gets a timeout: a task stuck in there
    //     is skipped after config.inboundProcessTimeoutMs and every message
    //     queued behind it is processed, instead of the bot going deaf until
    //     somebody restarts it. (2) The pulse counts raw `message` stanzas off
    //     the websocket so the watchdog can PROVE "messages arriving, none
    //     coming out" (evidence #3 in runStallWatchdog). See lib/inbound-guard.js.
    inst.mutexGuard = guardProcessingMutex(sock, {
      timeoutMs: config.inboundProcessTimeoutMs,
      onTimeout: ({ elapsedMs, timeouts, pending }) => {
        warnOncePer(inst, 'receiveLock', WATCHDOG_WARN_EVERY_MS, Date.now(),
          `⏱️ [${inst.botName}] WhatsApp's receive queue was stuck on one task for ${Math.round(elapsedMs / 1000)}s — ` +
          `skipped it so ${pending ? `the ${pending} message(s) waiting behind it get answered` : 'incoming messages keep flowing'} ` +
          `(${timeouts} skipped on this connection).`,
          globalErrorLog,
        )
      },
    })
    // whatsmeow has no JS-side receive mutex to guard (decryption runs in the
    // Go sidecar), so there is nothing to warn about when mutexGuard is null.
    inst.inboundPulse = createInboundPulse({ stallMs: config.inboundStallMs })
    attachInboundPulse(sock, inst.inboundPulse)

    // Newer / less-trusted numbers get banned fast if plugins burst-send
    // (tournament brackets, leaderboards, mass DMs, etc.). rateLimit is set
    // per-bot in config.js's bots[] entries — bot2 defaults to a tighter
    // cap than bot1 since it has no send history yet. Wrapping here means
    // every sock.sendMessage() call anywhere in the codebase (handler.js,
    // all plugins/*.js, the welcome/goodbye code just below) is throttled
    // without having to touch each call site.
    wrapSendWithRateLimit(sock, {
      botName: inst.botName,
      minGapMs: botCfg.rateLimit?.minGapMs,
      maxPerMinute: botCfg.rateLimit?.maxPerMinute,
      burstMax: botCfg.rateLimit?.burstMax,
      burstGapMs: botCfg.rateLimit?.burstGapMs,
      onAlert: async (alertData) => {
        const text =
          `🚨 *[${alertData.botName}] Outbound Send Backlog Alert*\n` +
          `• Current Queue: *${alertData.depth}* waiting (${alertData.pendingReplies} replies, ${alertData.pendingBulk} bulk)\n` +
          `• Trend Rate: *${alertData.rateFormatted}*\n` +
          `• Growing For: *${Math.round(alertData.growthDurationMs / 1000)}s*\n` +
          `• Oldest Pending: *${Math.round(alertData.oldestPendingMs / 1000)}s*\n` +
          `• Send Ceiling: *${alertData.maxPerMinute}/min* (queue limit: ${alertData.maxQueue})\n\n` +
          `_Outbound queue is growing faster than it drains. Replies are being delayed._`
        await sendToOwner(sock, { text }).catch(err => log('⚠️ Failed to alert owner of send backlog:', err.message))
      },
      log,
    })

    // Claim this socket as the instance's current one immediately — before
    // any listener is attached, so a 'close' from the socket we're replacing
    // can already tell that it has been retired (see the identity check in
    // the close handler). activeSock still waits for 'open': currentSock
    // means "the one we're driving", activeSock means "the one you can send
    // through", and those are genuinely different states.
    inst.currentSock = sock

    // NOT assigned here on purpose. `makeWASocket()` returns immediately, long
    // before the connection is usable — publishing it now meant liveSocket()
    // in lib/api-server.js handed out a still-connecting (or already-dead)
    // socket, sendMessage() threw, and the website told people "We couldn't DM
    // that number. Make sure you've messaged the bot at least once." That
    // message was a lie: the number was fine, the bot just wasn't online yet.
    // activeSock is now set on 'open' and cleared on 'close' below, so it
    // means what its name says.

    // Debounce creds saves — Baileys fires creds.update rapidly during
    // pairing and reconnect. Writing on every single event risks
    // partial/race writes that corrupt the auth files right when the
    // connection is most volatile. Wait 500ms for the burst to settle,
    // then do one clean write. On shutdown, flushPendingCreds ensures
    // the trailing write is never lost to a process termination.
    // Failures here are reported through reportCredsSaveFailure/
    // noteCredsSaveOk, created once per instance — see the block next to
    // logQuiet above for why one line per attempt is not acceptable.
    let saveCredsTimer = null

    const flushPendingCreds = async ({ reason = 'graceful shutdown', quiet = false } = {}) => {
      if (saveCredsTimer) {
        clearTimeout(saveCredsTimer)
        saveCredsTimer = null
        try {
          await saveCreds()
          noteCredsSaveOk()
          ;(quiet ? logQuiet : log)(`💾 Flushed pending creds save on ${reason}.`)
        } catch (err) {
          reportCredsSaveFailure(err, `${reason} flush`)
        }
      }
    }
    inst.flushPendingCreds = flushPendingCreds

    sock.ev.on('creds.update', (update) => {
      if (typeof update?.registered === 'boolean') inst.linked = update.registered
      if (saveCredsTimer) clearTimeout(saveCredsTimer)
      saveCredsTimer = setTimeout(async () => {
        saveCredsTimer = null
        try { await saveCreds(); noteCredsSaveOk() } catch (err) { reportCredsSaveFailure(err) }
      }, 500)
    })
    // Every command from this number goes through the SAME shared `db` and
    // the SAME shared writeQueue in lib/player-repo.js as the other number
    // — that's what makes "one big shared database" safe here. botName is
    // passed through to ctx so replies show the number they came in on.
    //
    // The stamp in front of the handler is what the stall watchdog reads. It
    // has to count EVERY upsert, including ones the handler ignores (its own
    // messages, non-commands, protocol messages): the question the watchdog
    // asks is "is WhatsApp still delivering anything at all to this socket",
    // not "did anyone run a command".
    const handleMessages = makeHandler(sock, db, inst.botName)

    // Do not put every upsert on one global promise chain. A single slow
    // command (media/API work or a reply waiting on the outbound safety
    // limiter) used to prevent later messages from even reaching handler.js;
    // the bot then appeared to "load" and catch up by reacting/replying one
    // message at a time. Run different senders concurrently, while keeping a
    // FIFO lane per sender so two stateful commands from one player cannot
    // overtake each other. The global cap protects the websocket/event loop
    // during a genuine group flood.
    const inboundScheduler = createInboundScheduler({
      concurrency: config.inboundConcurrency,
      maxPending: config.inboundQueueLimit,
      jobTimeoutMs: config.inboundJobTimeoutMs,
      handle: (payload) => handleMessages(payload),
      log: ({ err, pending, active, maxPending, laneKey, elapsedMs }, message) => {
        if (err) {
          log(`⚠️ ${message}:`, err?.message ?? err)
        } else if (laneKey) {
          // A handler timed out and was detached — the exact moment a
          // "bot stops answering" outage can start. pm2-err.log, not the
          // quiet lane log: if a command is hanging, find THIS line first.
          globalErrorLog(
            `⚠️ [${inst.botName}] ${message} lane=${laneKey} after ${Math.round(elapsedMs / 1000)}s ` +
            `(timeout ${config.inboundJobTimeoutMs / 1000}s) — the stream kept working, this command was abandoned.`,
          )
        } else {
          log(`⚠️ ${message} pending=${pending} active=${active} limit=${maxPending}`)
        }
      },
    })

    // Retire the scheduler with this socket. Running handlers are allowed to
    // finish (they may already have mutated player state), but queued work must
    // not wake up later and send through a dead Baileys socket.
    inst.inboundScheduler = inboundScheduler

    sock.ev.on('messages.upsert', (arg) => {
      inst.lastInboundAt = Date.now()
      inst.inboundCount++
      // Baileys produced output: the receive pipeline is moving.
      inst.inboundPulse?.noteUpsert()

      const messages = Array.isArray(arg?.messages) ? arg.messages : []
      if (!messages.length) {
        inboundScheduler.enqueue(arg, `event:${Date.now()}`)
        return
      }

      // ── Delivery vs. decryptability ─────────────────────────────────────
      // A message that reached messages.upsert is NOT proof that this socket
      // can read messages: Baileys emits undecryptable ones as a CIPHERTEXT
      // stub with no `.message` (see decode-wa-message.ts). Only a message
      // that actually carries plaintext proves the inbound path works — that
      // is `lastDecryptOkAt`, and it is the clock the decrypt watchdog reads.
      // Stubs get counted separately for `.health` so "messages are arriving
      // but not decrypting" is visible instead of looking like healthy
      // inbound traffic.
      const decrypted = messages.filter(m => m?.message)
      const stubs = messages.filter(m => !m?.message)
      if (decrypted.length) {
        inst.lastDecryptOkAt = Date.now()
        // A window that was full of failures just proved itself recoverable —
        // either the session renegotiated on its own or the forced reconnect
        // worked. Either way the ledger starts clean, so the next incident is
        // reported with its own counts rather than inheriting yesterday's.
        const recovered = inst.decryptLedger.noteSuccess()
        if (recovered.cleared >= DECRYPT_FAIL_LIMIT) {
          globalErrorLog(
            `✅ [${inst.botName}] inbound decryption recovered after ${recovered.cleared} failure(s) — ` +
            `messages are being read again.`,
          )
        }
        // Per sender: a person whose broken session we reported (and maybe
        // reset) is readable again — close their incident with one ✅ line.
        // Same identity as the failure side (extractDecryptContext reads
        // participant || remoteJid). Our own messages from the phone carry the
        // CHAT in remoteJid, not a sender, so they are skipped.
        for (const m of decrypted) {
          if (m.key?.fromMe) continue
          const sender = m.key?.participant || m.key?.remoteJid
          if (!sender) continue
          inst.sessionResetPolicy.noteSuccessFor(sender)
          const back = inst.decryptLedger.noteSenderSuccess(sender)
          if (back) globalErrorLog(formatDecryptRecovery({ botName: inst.botName, recovered: back }))
        }
      }
      if (stubs.length) {
        inst.stubCount += stubs.length
        inst.lastStubAt = Date.now()
      }

      // Schedule one message at a time instead of handing a whole batch to a
      // serial handler. This is important during history/live bursts: one
      // expensive message must not hold the rest of the batch hostage.
      for (const msg of messages) {
        inboundScheduler.enqueue(
          { ...arg, messages: [msg] },
          inboundMessageKey(msg),
        )
      }
    })

    // ── Welcome / goodbye announcements ───────────────────────────────────
    // Fires whenever WhatsApp reports members joining or leaving a group.
    // Purely config-driven via data/group-settings.json (toggled through
    // .groupguard welcome/goodbye on|off) — no-ops if a group hasn't opted in.
    sock.ev.on('group-participants.update', async (update) => {
      try {
        const { id: groupId, participants, action } = update
        const settings = await getGroupSettings(groupId)

        // ── Join gate: antifake / antiinternational ──────────────────────
        // Runs before the welcome so a number that's about to be removed
        // never gets greeted. Both are sub-settings of .grouplock — see
        // plugins/grouplock.js. Removed members are collected so they're
        // skipped by the welcome loop below.
        const removed = new Set()
        if (action === 'add' && (settings.antiFake || settings.antiInternational)) {
          const allowed = (settings.localPrefixes ?? []).length
            ? settings.localPrefixes
            : (config.ownerNumbers ?? []).map(n => String(n).replace(/\D/g, '').slice(0, 3)).filter(Boolean)

          for (const jid of participants) {
            if (isOwnerJid(jid)) continue
            const num = String(jid).replace(/@.*$/, '').split(':')[0].replace(/\D/g, '')
            if (!num) continue

            // A real WhatsApp MSISDN is 10-15 digits including country code.
            // Anything outside that is a placeholder/spoofed entry.
            const looksFake = settings.antiFake && (num.length < 10 || num.length > 15)
            const isForeign = settings.antiInternational && allowed.length &&
              !allowed.some(pfx => num.startsWith(String(pfx)))

            if (!looksFake && !isForeign) continue

            const why = looksFake ? 'an invalid number' : 'an international number'
            const kicked = await sock.groupParticipantsUpdate(groupId, [jid], 'remove')
              .then(() => true)
              .catch(err => { log('⚠️ join-gate kick failed:', err.message); return false })

            removed.add(jid)
            await sock.sendMessage(groupId, {
              text: kicked
                ? `🚪 Removed @${num} — ${why} isn't allowed here.`
                : `⚠️ @${num} joined with ${why} but I couldn't remove them. Make me a group admin.`,
              mentions: [jid],
            }).catch(() => {})
          }
        }

        if (action === 'add' && settings.welcome) {
          const template = settings.welcomeMessage || 'Welcome {user}! 🎉'
          for (const jid of participants) {
            if (removed.has(jid)) continue
            const text = template.replace(/\{user\}/g, `@${jid.split('@')[0]}`)
            await sock.sendMessage(groupId, { text, mentions: [jid] }).catch(err =>
              log('⚠️ welcome message failed:', err.message))
          }
        }

        if (action === 'remove' && settings.goodbye) {
          const template = settings.goodbyeMessage || 'Goodbye {user}. 👋'
          for (const jid of participants) {
            const text = template.replace(/\{user\}/g, `@${jid.split('@')[0]}`)
            await sock.sendMessage(groupId, { text, mentions: [jid] }).catch(err =>
              log('⚠️ goodbye message failed:', err.message))
          }
        }
      } catch (err) {
        log('⚠️ group-participants.update handler error:', err.message)
      }
    })

    // Whether this number is linked, sampled from the creds we just loaded.
    // Read by the boot summary below so "1 of 1 linked" is a fact it can state
    // rather than a guess, and re-sampled on every reconnect.
    inst.linked = Boolean(sock.authState?.creds?.registered)

    // Pairing code — requested once per process, from this instance's phoneFile.
    //
    // NOT awaited, and the flag is set synchronously so a racing reconnect
    // cannot queue a second request. Pairing output must come after the boot,
    // not in the middle of it — see requestPairingCodeWhenUnlinked()'s header
    // for what the await here used to cost on a first boot.
    if (
      !sock.authState.creds.registered &&
      (!inst.pairingRequested || inst.pairingRequestSocket !== sock)
    ) {
      inst.pairingRequested = true
      inst.pairingRequestSocket = sock
      void requestPairingCodeWhenUnlinked(inst, sock, { log, logQuiet })
        .catch(err => log('⚠️ Pairing code request failed:', err?.message ?? err))
    }

    sock.ev.on('connection.update', async ({ connection, lastDisconnect }) => {
      if (connection === 'connecting') {
        logQuiet('🔌 Connecting to WhatsApp…')
      }

      if (connection === 'open') {
        inst.wasEverConnected = true
        inst.unpairedRetryCount = 0
        // The link is demonstrably fine now, so the next blink earns the fast
        // retry again instead of inheriting an hour-old grudge.
        inst.transientCloseStreak = 0
        inst.openedAt = Date.now()
        // Fresh socket, fresh inbound clock. Without this the watchdog would
        // measure silence from before the reconnect and immediately kill the
        // socket it just built.
        inst.lastInboundAt = Date.now()
        // Same reasoning for the plaintext clock the decrypt watchdog uses —
        // a socket that opened 10s ago has not had time to prove anything.
        inst.lastDecryptOkAt = Date.now()
        inst.stubCount = 0
        inst.forcedReconnect = false
        // Fresh scheduler, fresh sessions — reset the stall evidence so the
        // watchdog measures THIS socket, not the dead one it replaces (a
        // reconnect that was the cure for the old socket's wedge must not
        // immediately re-trigger on the old socket's evidence).
        inst.inboundStallSince = 0
        // And fresh failure evidence, for the same reason: a reconnect that
        // cured a wedge must not be re-triggered by the dead socket's counts.
        inst.decryptLedger.reset()
        // Publish the socket only now that it can actually send. Everything
        // that reaches for a socket (the sweeps above, the website's OTP DM
        // in lib/api-server.js) goes through this field.
        inst.activeSock = sock
        sayLine(`  ✅  ${inst.botName} connected`)
        logQuiet(`✅ ${inst.botName} is online`)

        // Verify authFolder instance lock on connection
        inst.authState?.verifyInstanceLock?.()

        if (!inst.onlineDmSent) {
          inst.onlineDmSent = true
          // LID-based accounts need the @lid suffix — @s.whatsapp.net will
          // silently fail to deliver to them. Try LID first if configured,
          // then fall back to the plain phone-number JID.
          const candidates = []
          if (config.ownerLid) candidates.push(`${config.ownerLid}@lid`)
          const ownerNumber = (config.ownerNumbers ?? [])[0]
          if (ownerNumber) candidates.push(`${ownerNumber.replace(/\D/g, '')}@s.whatsapp.net`)

          if (candidates.length === 0) {
            log('⚠️ No owner LID or number configured — skipping online DM.')
          } else {
            ;(async () => {
              for (const jid of candidates) {
                try {
                  await sock.sendMessage(jid, { text: `✅ ${inst.botName} is online.` })
                  log('✅ Online DM sent to owner:', jid)
                  return
                } catch (err) {
                  log(`⚠️ Online DM failed for ${jid}:`, err.message)
                }
              }
              log('❌ Online DM failed for all configured owner targets.')
            })()
          }
        }
      }

      if (connection === 'close') {
        // Retire this socket so nothing tries to send through it. The identity
        // check matters: reconnects below build a NEW socket, and the old
        // one's 'close' can land after the new one's 'open'. A bare
        // `inst.activeSock = null` would then blank out the live socket and
        // take the bot offline as far as the website is concerned.
        if (inst.activeSock === sock) inst.activeSock = null

        const statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode

        // A close from a socket we've already replaced must not schedule
        // anything. Acting on it is how one instance ends up with two live
        // sockets on one auth folder, which WhatsApp answers with 440s —
        // each of which closes a socket and schedules another connect.
        if (inst.currentSock !== sock) {
          logQuiet('🗑️ Ignoring close from a retired socket. statusCode:', statusCode)
          return
        }

        // Nothing else is listening to this socket now. Baileys' own end()
        // already drops its ws + connection.update listeners; clear the
        // application-level queue too so pending work cannot be replayed
        // against the socket that just died.
        inst.inboundScheduler?.close(`socket closed (${statusCode ?? 'unknown'})`)
        inst.inboundScheduler = null

        // Nothing else is listening to this socket now. Baileys' own end()
        // already drops its ws + connection.update listeners; this releases
        // the rest (messages.upsert, group-participants.update) so a dead
        // socket can't keep a handler — and the db it closes over — alive.
        try { sock.ev.removeAllListeners?.('messages.upsert') } catch { /* not fatal */ }
        try { sock.ev.removeAllListeners?.('group-participants.update') } catch { /* not fatal */ }

        // Write any debounced creds to disk BEFORE a reconnect can read them.
        // creds.update is saved 500ms after the last change, but the 515 that
        // follows a successful pairing reconnects with a 0ms delay: the new
        // connect() read creds.json while it still held the OLD, unpaired
        // creds, so WhatsApp answered the "restarted" session with a 401
        // ("closed the unpaired session") a few seconds after the link
        // had actually succeeded. Flushing here closes that race for every
        // close code, not just 515.
        await flushPendingCreds({ reason: `socket close (${statusCode ?? 'unknown'})`, quiet: true })

        const loggedOut  = statusCode === DisconnectReason.loggedOut
        const conflict   = statusCode === DisconnectReason.conflict
        const restartReq = statusCode === DisconnectReason.restartRequired // 515

        // File only: every branch below prints the ONE console line that says
        // what happened and what happens next (with the status code in it).
        // This used to add a bare "⚠️ Connection closed. statusCode: 401" on
        // top of that line for every single close.
        logQuiet('⚠️ Connection closed. statusCode:', statusCode)

        // The WhatsApp sidecar (wa-bridge) died on its own. Its exit reason rides
        // on the close error; without this line a crash looked like an ordinary
        // 428 and the cause was lost. The reconnect below starts a new sidecar.
        if (String(lastDisconnect?.error?.data?.reason ?? '').startsWith('bridge exited')) {
          globalErrorLog(`❌ [${inst.botName}] ${lastDisconnect.error.message}. Restarting the WhatsApp bridge.`)
        }

        // A missing/non-executable bridge or SQLite startup failure cannot be
        // repaired by reconnecting every 3s. Keep the auth and stop this socket.
        if (lastDisconnect?.error?.data?.reason === 'bridge_start_failed') {
          inst.pairingRequested = false
          inst.pairingRequestSocket = null
          log(`❌ WhatsApp bridge could not start: ${lastDisconnect.error.message}. Pairing stopped — fix the build and redeploy. Keep the auth folder.`)
          return
        }

        // The 60 s pairing window ran out before the phone linked. Stop here:
        // no reconnect, no new code — a fresh code needs a restart.
        if (lastDisconnect?.error?.data?.reason === 'pairing_timeout') {
          inst.pairingRequested = false
          inst.pairingRequestSocket = null
          inst.unpairedRetryCount = 0
          log(`⏱️ Pairing code expired — it was not entered within ${Math.round(PAIRING_WINDOW_MS / 1000)}s. Connection closed. Restart the bot to get a new code.`)
          return
        }

        if (inst.forcedReconnect) {
          // Set by lib/stall-watchdog.js — that watchdog calling it is the
          // whole point of that flag (this comment used to claim nothing set it
          // any more, which was already wrong when the watchdog was re-added;
          // deleting this branch on the strength of it would make every forced
          // reconnect wait the ordinary 60s instead of 5).
          inst.forcedReconnect = false
          inst.scheduleReconnect(
            db,
            planReconnect({ forced: true, policy: reconnectPolicy }).delayMs,
            'watchdog forced reconnect',
          )
          return
        }

        if (restartReq) {
          // 515 is WhatsApp's normal "restart to finish linking" signal
          // right after a successful pairing — not an error. Reconnect
          // immediately; waiting the usual 1 min here let the freshly-
          // paired session expire and produced a 401 on the next attempt.
          log('🔁 Restart required (515) — this is expected right after pairing, reconnecting now…')
          inst.scheduleReconnect(db, 0, 'restart required (515)', { quiet: true })
          return
        }

        if (conflict) {
          // Another process/session is using the same auth (e.g. this auth
          // folder opened twice) — this needs a short retry, not the full
          // 1-min wait used for logout, since it's usually transient.
          //
          // Stamped because it is the fingerprint of the double-login that
          // explains a persistent Bad-MAC storm (recordSignalFailure attaches
          // this to the decryption advice when it happened in the last 30
          // min). A conflict that keeps coming back means the other instance
          // never stopped — the reconnect here is treating a symptom.
          inst.sessionConflictAt = Date.now()
          log('⚠️ Session conflict (code 440) — reconnecting in 10s… (if this repeats, another instance is using this auth folder)')
          inst.scheduleReconnect(db, 10_000, 'session conflict (440)', { quiet: true })
          return
        }

        if (loggedOut && inst.wasEverConnected) {
          // WhatsApp sometimes sends a fake/soft 401 on an already-paired
          // session. A real logout is rare — wiping auth on every 401
          // kills a good session permanently and forces an unnecessary
          // re-pair. Just reconnect instead.
          log('⚠️ Got logout signal (401) on a previously-connected session — reconnecting in 1 min without wiping auth…')
          inst.scheduleReconnect(db, 60_000, 'soft logout (401) on a paired session', { quiet: true })
          return
        }

        if (loggedOut) {
          inst.unpairedRetryCount++

          // Never actually paired yet: WhatsApp closes an unlinked socket with
          // 401 when the pairing attempt does not complete (the code may have
          // expired or been rejected). Give the owner a few fresh codes, then stop.
          //
          // Console noise (2026-10): every retry used to print FOUR lines — the
          // new code, "Connection closed. statusCode: 401", "Logged out before
          // pairing completed… (attempt N/5)" and "Reconnecting in 60s" — for
          // a number nobody was pairing. Now the console gets ONE explanation
          // on the first miss, then only each new 🔑 code (that line is the
          // useful one), then one final line. Everything else is file-only.
          const MAX_UNPAIRED_RETRIES = 5
          const phoneFileName = pathBasename(inst.phoneFile ?? 'paired_number.txt')
          if (inst.unpairedRetryCount > MAX_UNPAIRED_RETRIES) {
            const stopHint = (inst.phoneLine ?? 1) > 1
              ? ` Restart the bot for a new code — or, if you don't want this number running, delete line ${inst.phoneLine} of ${phoneFileName} (or set BOT2_ENABLED=0).`
              : ' Restart the bot for a new code.'
            log(`⏸️ Never linked — stopped asking for pairing codes after ${MAX_UNPAIRED_RETRIES} tries.${stopHint}`)
            return
          }

          if (inst.unpairedRetryCount === 1) {
            const codeAgeSeconds = inst.lastPairingCodeIssuedAt
              ? Math.max(0, Math.round((Date.now() - inst.lastPairingCodeIssuedAt) / 1000))
              : null
            const codeAge = codeAgeSeconds == null ? '' : ` ${codeAgeSeconds}s after the last code was issued`
            log(
              `⚠️ WhatsApp closed the unpaired session (401)${codeAge}. This can mean the code expired or WhatsApp rejected the link; ` +
              `the status alone cannot distinguish them. On the phone: WhatsApp → Linked devices → Link a device → ` +
              `"Link with phone number instead", then enter the newest 🔑 code. If it is rejected immediately, check the number's ` +
              `international format and available linked-device slots. A fresh code is requested after 1 min, up to ${MAX_UNPAIRED_RETRIES} times.`,
            )
          } else {
            logQuiet(`❌ Logged out before pairing completed — waiting 1 min before requesting a new code… (attempt ${inst.unpairedRetryCount}/${MAX_UNPAIRED_RETRIES})`)
          }
          inst.pairingRequested = false
          inst.pairingRequestSocket = null
          inst.scheduleReconnect(db, 60_000, 'logged out before pairing completed', { quiet: true })
          return
        }

        // Everything without a rule above used to wait a flat 60s. That is the
        // right wait for a logout and the wrong one for a hiccup — and the
        // common hiccups here are self-inflicted: Baileys' keepalive calls
        // end(Boom('Connection was lost', 408)) whenever the event loop is too
        // busy to service a frame within keepAliveIntervalMs + 5s (see
        // lib/loop-lag.js for why a busy db.write() can do exactly that). Each
        // such close cost sixty silent seconds, and the scheduler.close() above
        // threw away every command typed during them: "online, ignoring
        // everyone, then fine again" for the rest of the busy minute.
        const plan = planReconnect({
          statusCode,
          consecutiveFast: inst.transientCloseStreak,
          policy: reconnectPolicy,
        })
        if (plan.alert) {
          // Loud on purpose: 403/411/500 and an unrecoverable flap are all
          // cases where retrying is not the answer and a human is.
          globalErrorLog(`🚨 [${inst.botName}] ${plan.label}`)
        }
        if (countsTowardFlap(plan)) inst.transientCloseStreak++
        else inst.transientCloseStreak = 0
        // `?? 60_000` is unreachable today (the only null delay is 401, handled
        // above) and kept so that adding a code to the policy cannot silently
        // schedule a zero-delay reconnect loop.
        inst.scheduleReconnect(db, plan.delayMs ?? 60_000, plan.label)
      }
    })

    return sock
  }

  /**
   * Public entry point for (re)connecting. Refuses to run two connects at
   * once for this instance — see the reconnect-hygiene note on inst above.
   */
  inst.connect = async function connect(db) {
    if (inst.connectInFlight) {
      logQuiet('↩️ connect() called while another connect is already in progress — ignoring.')
      return null
    }
    inst.connectInFlight = true
    try {
      return await openConnection(db)
    } finally {
      inst.connectInFlight = false
    }
  }

  return inst
}

/**
 * Boot the Telegram platform inside THIS process, on THIS process's database.
 *
 * ── Why it lives here now ────────────────────────────────────────────────
 * This block was deleted when the bot went WhatsApp-only, and for a while the
 * only way to run Telegram was main-all.js. That made a deploy fail silently:
 * Railway's start command was still `node main.js`, so nothing polled the bot
 * token and `/start` reached no process at all — while WhatsApp kept working,
 * which reads to the owner as "the bot is half-broken" rather than
 * "Telegram was never started".
 *
 * So: if the token is configured, this process runs it. That is the "shared
 * accounts" shape in lib/platform/boot.js's header — one process, one database,
 * one write queue — and it is what makes /link able to hand a Telegram account
 * its existing WhatsApp character.
 *
 * ── Rules this function keeps ────────────────────────────────────────────
 * • Never awaited by main(): bot.init() is a network call, and a slow Telegram
 *   must not delay the WhatsApp sockets or the port Railway waits for
 *   (/api/health). Same reasoning as the API server block below.
 * • Never fatal: a missing token, a revoked token, or a 409 from another
 *   poller ends in a log line. WhatsApp keeps running.
 * • Never both: do NOT also run main-telegram.js against the same token. Two
 *   pollers get 409 Conflict from Telegram, and two writers on one DB_PATH is
 *   what acquireDbLock() refuses.
 */
async function startTelegramIfConfigured(db) {
  try {
    const { createTelegramBot } = await import('./adapters/telegram/adapter.js')
    // The per-platform plugin dir needs the load-time check pointed at
    // 'telegram': this process booted as 'whatsapp', so a plugin declaring
    // `platforms: ['telegram']` would be skipped silently otherwise.
    await loadPlugins('./plugins-telegram', { platform: 'telegram' })
    const runtime = await createTelegramBot({ db })
    _telegramRef = runtime
    runtime.start().catch(err =>
      globalErrorLog('⚡ Telegram polling stopped:', err?.stack ?? err),
    )
    // The hourly wild card, for Telegram groups. lib/background-sweeps.js is a
    // WhatsApp sweep and skips `tg:` ids on purpose — without this, a Telegram
    // group that turned cards on received nothing, ever, because the list they
    // registered in belongs to a sweep that cannot send to them.
    _telegramSpawnsRef = startTelegramCardSpawns(() => _telegramRef?.sender ?? null, {
      log: globalLog,
    })
    globalLog(`🃏 Telegram card spawns armed every ${humanInterval(CARD_SPAWN_INTERVAL_MS)}`)
    globalLog(`🤖 Telegram connected as @${runtime.bot.botInfo?.username ?? '?'} — same database, one character everywhere`)
    globalLog(`💳 Payments on Telegram: ${config.telegramPaymentsEnabled ? 'ENABLED' : 'disabled (locked)'}`)
  } catch (err) {
    _telegramSpawnsRef?.stop()
    _telegramSpawnsRef = null
    _telegramRef = null
    globalErrorLog('⚡ Telegram failed to start (WhatsApp is unaffected):', err?.stack ?? err)
    globalLog('   → 401: TELEGRAM_TOKEN is wrong or was revoked in @BotFather.')
    globalLog('   → 409: another process is already polling this token (main-telegram.js?).')
    globalLog('   → empty token: set TELEGRAM_TOKEN in .env / Railway Variables.')
  }
}

// ── Boot ───────────────────────────────────────────────────────────────────
async function main() {
  bootLog(`🚀 Starting ${bots.length} bot instance(s), sharing one database…`)
  // Started first, on purpose: "the bot went slow at 03:00" is only answerable
  // afterwards if the loop delay was being sampled the whole time. Diagnostic
  // only — see lib/loop-lag.js for what the number means.
  startLoopLagMonitor({ windowMs: config.loopLagWindowMs, starveMs: config.loopLagStarveMs })
  const { passed, errors } = runValidation()
  if (!passed) {
    errors.forEach(e => globalLog('❌ Data validation failure:', e))
    globalLog('❌ Data validation failed — fix all errors above before starting the bot.')
    process.exit(1)
  }
  bootLog('✅ Data validation passed')

  const db = await initDb()
  _dbRef = db
  // 2026-09: updatePlayer/createPlayer/savePlayer now save each player
  // straight to Mongo when MONGO_URI is set (see lib/player-repo.js), instead
  // of rewriting the whole db.json on every command — that whole-file
  // stringify was blocking the event loop long enough to starve Baileys'
  // keepalive under command spam. This timer is what keeps the local
  // db.json refreshed as a disaster-recovery copy now that saves no longer
  // do it on every command. No-op when MONGO_URI isn't set.
  startPeriodicSnapshot(db)
  await runStartupJobs(db, { quietLog: globalQuietLog })
  const starfallWipe = await runStarfallWipe(db)
  if (starfallWipe.ran) globalLog(`🌠 Locked Starfall and wiped its prizes from ${starfallWipe.players} player(s).`)
  const starfallReopen = await runStarfallReopen(db)
  if (starfallReopen.reopened) globalLog('🌠 Reopened Starfall.')
  const starfallRecovery = await runStarfallRecovery(db)
  if (starfallRecovery.players) {
    globalLog(`🌠 Repaired Starfall boxes/prizes for ${starfallRecovery.players} player(s)${starfallRecovery.restored.length ? `: ${starfallRecovery.restored.join('; ')}` : ''}.`)
  }
  const migrated = await updateAllPlayers(db, (users) => migrateAllPlayers(users))
  if (migrated) globalLog('📊 Migrated player stat pools to the level-100 / 1,500-point progression.')
  // Before any command can unequip: whoever is wearing Beth or Liorei gets the
  // part of her bonus the old equip code dropped (lib/character-bonus-fix.js).
  const repairedBonuses = await updateAllPlayers(db, (users) => repairAllCharacterBonuses(users))
  if (repairedBonuses) globalLog(`🩹 Gave ${repairedBonuses} player(s) the character stat bonus top-up they were missing.`)
  const deliveredPreorders = await updateAllPlayers(db, () => materializeAllUnlockedPreorders(db).length)
  if (deliveredPreorders) globalLog(`🎉 Delivered ${deliveredPreorders} unlocked character pre-order(s) into player rosters.`)
  const dedupedNames = await runUniqueNameDeduplication(db)
  if (dedupedNames.length) {
    globalLog(`🏷️ Deduplicated ${dedupedNames.length} duplicate username(s)/name(s): ${dedupedNames.map(c => `${c.from} → ${c.to}`).join(', ')}`)
  }
  await loadPlugins('./plugins')
  startGodWorldWorker(db, { onError: error => globalLog('⚠️ God world observer:', error.message) })

  // Videos earn for days, which is longer than this process is likely to live.
  // Nothing else re-arms their timers, so a deploy used to freeze every video
  // published before it: the counter stopped while the video still looked live.
  // The fold-in reads the gap from `lastTickAt`, so restarting here loses
  // nothing and credits everything that accrued while we were down.
  try {
    const { resumeVideoTimers } = await import('./plugins/tube.js')
    const live = await resumeVideoTimers()
    if (live) globalLog(`▶ ASTRALTUBE: resuming ${live} video(s) still earning.`)
  } catch (err) {
    globalLog('⚠️ ASTRALTUBE: could not resume video timers:', err?.message ?? err)
  }

  // Guard against misconfiguration — two instances pointed at the same
  // auth folder would fight over the same Baileys session and produce
  // exactly the "instant 401 / conflict" symptoms the reconnect logic
  // above already has to work around for a single number.
  const seenAuthFolders = new Set()
  for (const b of bots) {
    if (seenAuthFolders.has(b.authFolder)) {
      globalLog(`❌ Duplicate authFolder "${b.authFolder}" used by more than one bot in config.js's bots[] — each number needs its own. Refusing to start.`)
      process.exit(1)
    }
    seenAuthFolders.add(b.authFolder)
  }

  const instances = bots.map(createBotInstance)
  _instancesRef = instances

  // ── Website bridge (lib/api-server.js), started BEFORE the sockets ───────
  //
  // This block used to run after the connect loop, and on a first boot that
  // ordering was the bug reported from Railway: nothing was listening until
  // every connect() had finished, and connect() would not finish until the
  // pairing code had been requested (3s settle, then a bounded 60s retry
  // window if the socket cannot send). Railway decides a deploy is up by waiting for the port, so the
  // container sat on "loading" with a `❌ paired_number.txt not found` as the
  // last line anyone could see — read by everyone as "the bot is stuck".
  //
  // Two reasons the old ordering was never buying what it claimed:
  //   • /api/auth/request-otp needs a live socket at CALL time, not at boot
  //     time. Whether listen() happens 20s earlier changes nothing about a
  //     request that arrives minutes later, and the route already answers
  //     "the bot hasn't linked yet" by itself when there is no socket.
  //   • an unlinked number is the NORMAL state on first boot. Waiting for a
  //     socket that cannot open without a pairing code can only ever delay
  //     the listen, which is exactly the state that used to look stuck.
  //
  // Pairing output is now deferred past boot as well (whenBootComplete), so the
  // 🔑 code is printed after this port and after the "Bot is up" line.
  // It runs in THIS process on purpose — see the single-writer note at the top
  // of this file and in lib/player-repo.js.
  // Declines to start (rather than crashing the bot) if JWT_SECRET is unset.
  let apiServer = null
  try {
    ({ startApiServer } = await import('./lib/api-server.js'))
    apiServer = startApiServer(db, instances)
  } catch (err) {
    const missing = err?.code === 'ERR_MODULE_NOT_FOUND'
    globalLog(
      missing
        ? `⛔ Website API not started — a dependency is missing. Run \`npm install\` on the VPS. (${err.message})`
        : `⛔ Website API failed to start: ${err?.stack ?? err}`,
    )
    globalLog('   The bot itself is unaffected and will keep running normally.')
  }

  // ── Telegram (optional) ─────────────────────────────────────────────────
  // Started here, beside the API server and before the socket loop, for the
  // same reason that block is: the deploy should answer on every platform it
  // was configured for, and a slow Telegram must not hold up WhatsApp. Not
  // awaited — see startTelegramIfConfigured().
  if (config.telegramToken) startTelegramIfConfigured(db)
  else globalLog('⚡ Telegram: TELEGRAM_TOKEN not set — running WhatsApp only.')

  for (const inst of instances) {
    // One number failing to even build its socket (unreadable auth folder,
    // full disk, DNS down at boot) must not abort main(). Everything after
    // this loop — the website API and EVERY sweep, including the card and
    // Pokémon spawns — used to be skipped when this threw, leaving a process
    // that was alive with no scheduled work at all.
    try {
      await inst.connect(db)
    } catch (err) {
      globalErrorLog(`❌ [${inst.botName}] initial connect failed: ${err?.stack ?? err}`)
      inst.scheduleReconnect(db, 30_000, 'initial connect failed')
    }
  }

  // Live health readout for plugins/health.js (`.health`). Kept as a getter
  // rather than a snapshot object so it can never go stale.
  setHealthProvider(() => ({
    uptimeSec: Math.floor(process.uptime()),
    loopLag: getLoopLagSnapshot(),
    // Live counters only — no I/O — so this still answers when the process is
    // too busy to do anything else. Null when the guard is disabled.
    memory: memoryGuard ? memoryGuard.getMemorySnapshot() : null,
    instances: instances.map(inst => {
      const sock = inst.activeSock
      const rl = sock?.__rateLimiter ?? null
      return {
        botName: inst.botName,
        online: Boolean(sock),
        openedAt: inst.openedAt,
        lastInboundAt: inst.lastInboundAt,
        inboundCount: inst.inboundCount,
        // Plaintext arrival — the one that proves inbound actually works.
        lastDecryptOkAt: inst.lastDecryptOkAt,
        stubCount: inst.stubCount,
        lastStubAt: inst.lastStubAt,
        decrypt: inst.decryptLedger.snapshot(),
        // Baileys' own receive side (lib/inbound-guard.js): raw stanzas in vs
        // upserts out, and the receive lock's queue / skipped stuck tasks.
        receive: inst.inboundPulse ? {
          summary: describeInboundPulse(inst.inboundPulse.snapshot(), inst.mutexGuard?.stats ?? null),
          pulse: inst.inboundPulse.snapshot(),
          guard: inst.mutexGuard ? { ...inst.mutexGuard.stats, timeoutMs: inst.mutexGuard.timeoutMs } : null,
        } : null,
        sessionResets: inst.sessionResets,
        lastSessionResetAt: inst.lastSessionResetAt,
        sessionConflictAt: inst.sessionConflictAt,
        lastForcedReconnectAt: inst.lastForcedReconnectAt,
        reconnectPending: Boolean(inst.reconnectTimer),
        transientCloseStreak: inst.transientCloseStreak,
        inbound: inst.inboundScheduler ? {
          active: inst.inboundScheduler.active,
          pending: inst.inboundScheduler.pending,
          lanes: inst.inboundScheduler.laneCount,
          limits: inst.inboundScheduler.limits,
          stats: inst.inboundScheduler.stats,
        } : null,
        send: rl ? {
          pending: rl.pending,
          pendingReplies: rl.pendingReplies,
          pendingBulk: rl.pendingBulk,
          pendingReactions: rl.pendingReactions,
          oldestPendingMs: rl.oldestPendingMs,
          sentLastMinute: rl.sentLastMinute,
          draining: rl.draining,
          burstReady: rl.burstReady,
          limits: rl.limits,
          effectiveLimits: rl.effectiveLimits,
          throttledForMs: rl.throttledForMs,
          counters: rl.counters,
          trend: rl.trend,
        } : null,
      }
    }),
  }))

  // Periodic jobs (spawns, League, maintenance and timeout sweeps) are owned
  // by lib/background-jobs.js. main.js keeps only connection/health lifecycle
  // wiring; the job manager shares this process and the one database writer.
  _backgroundJobsRef = await startBackgroundJobs(db, instances, {
    log: globalLog,
    quietLog: globalQuietLog,
    errorLog: globalErrorLog,
    bootLog,
    routineOrAlert,
    runStallWatchdog: () => runStallWatchdog(instances),
    // Null when MEMORY_GUARD_ENABLED=0 — background-jobs then arms no timer.
    runMemoryTick: memoryGuard ? () => memoryGuard.runMemoryTick() : null,
    memoryTickMs: config.memoryTickMs,
    // Gates open on both platforms from one clock. Telegram connects later in
    // boot (or not at all with no token), so the sweep resolves its sender per
    // tick rather than being handed one that may still be null.
    getTelegramSender: () => _telegramRef?.sender ?? null,
  })

  // ── Boot complete ────────────────────────────────────────────────────────
  //
  // Everything a running bot needs now exists: database, plugins, website port,
  // every sweep. Say so in ONE unconditional line, because the alternative is
  // what this looked like from Railway — a log whose last visible line was an
  // error about a missing file, and no way to tell a healthy wait from a hang.
  //
  // Then release the pairing prompt (markBootComplete), which is deliberately
  // the LAST thing to print: the boot lines above are the evidence the process
  // is up, and the 🔑 code / "create paired_number.txt" notice arrives after
  // them rather than interleaved with them.
  const linked = instances.filter(i => i.linked).length
  globalLog(
    `✅ Bot is up — ${instances.length} bot instance(s), ${linked}/${instances.length} linked to WhatsApp, ` +
    `website API ${apiServer ? `listening on 0.0.0.0:${config.apiPort}` : 'NOT started (see above)'}.`,
  )
  if (linked < instances.length) {
    globalLog(
      '📱 Not linked yet: the pairing step runs next, after this line — a 🔑 code is printed below ' +
      '(or a notice telling you which number file to create). Nothing is stuck; the bot and its website are already running.',
    )
  }

  // A host with no ffmpeg boots perfectly — only the media commands fail, one
  // player at a time, with an error that lands in a chat rather than in the
  // boot log. Say it once here, where the owner is already reading, instead of
  // waiting for a `.sticker` failure to surface it. See lib/ffmpeg-bin.js.
  const ffmpeg = ffmpegStatus()
  if (!ffmpeg.ok) {
    globalLog(
      '🎞️ ffmpeg: ❌ not found — .sticker and gif→video conversion will fail. ' +
      'Fix it with `npm rebuild ffmpeg-static` (or set FFMPEG_PATH to a system ffmpeg), then restart. ' +
      '`.health` shows what the bot resolved.',
    )
  }
  // The container/heap mismatch check — see memoryStartupWarning(). Unconditional
  // on purpose: on Railway the process can be SIGKILLed with no error and no
  // stack trace, so this is the only line that will ever say why. It is also the
  // only place the owner learns what limit the container actually reported.
  if (memoryGuard) {
    const memWarn = memoryStartupWarning(sampleMemory())
    if (memWarn) globalLog(memWarn)
  }

  markBootComplete()
}

// A throw anywhere in main() used to surface as an unhandled rejection and
// leave a live process with no sockets, no sweeps and no API server —
// "online" as far as PM2 is concerned, dead to every user. Say so in
// pm2-err.log and exit non-zero instead, so PM2's autorestart gets a chance
// to fix it.
main().catch(err => {
  globalErrorLog('💥 Boot failed:', err?.stack ?? err)
  process.exit(1)
})

// Telegram's boot lives in main() now — see startTelegramIfConfigured() above.
// It runs whenever TELEGRAM_TOKEN is set, so a deploy whose start command is
// still `node main.js` serves Telegram as well as WhatsApp, on one database.
//
// main-all.js still exists as a name and simply imports this file; main-telegram.js
// remains for a Telegram-ONLY world with its own database (db-telegram.json).
// Discord's adapter is still gone — nothing here boots it.
