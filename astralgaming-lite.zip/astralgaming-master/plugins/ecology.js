/**
 * ecology.js — living dungeon food webs and player interventions.
 *
 * Regions are not static spawn tables: populations grow, predators suppress
 * prey, over-hunting raises pressure, and weekly events reshape the next run.
 * Players can scout for insight, cull overpopulated species, feed collapsing
 * ones, sabotage a boss's warband, or sanctuary a region to calm it.
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import {
  ecologyReport, ecologyWorldSummary, ecologyAction, ecologyRegionIds, ECOLOGY_DATA,
} from '../lib/dungeon-ecology.js'

const ACTIONS = new Set(['scout', 'cull', 'feed', 'sabotage', 'sanctuary'])

export default {
  name: 'ecology',
  aliases: ['foodweb', 'dungeonecology'],
  category: 'dungeon',
  requiresPlayer: true,
  description: 'Read and shape living dungeon populations',
  subcommands: [
    { cmd: 'report <region>', desc: 'show populations, events and pressure' },
    { cmd: 'scout <region> [species]', desc: 'gain regional insight' },
    { cmd: 'cull <region> [species]', desc: 'reduce an overpopulated species' },
    { cmd: 'feed <region> [species]', desc: 'support a collapsing species' },
    { cmd: 'sabotage <region>', desc: 'raise unrest and weaken the region boss' },
    { cmd: 'sanctuary <region>', desc: 'calm aggression and corruption' },
    { cmd: 'world', desc: 'summarize every living region' },
    { cmd: 'regions', desc: 'list ecology region ids' },
  ],

  async run(ctx) {
    const prefix = config.prefix
    let reply = ''
    await updatePlayer(ctx.db, ctx.from, player => {
      const args = (ctx.args ?? []).map(a => String(a).toLowerCase())
      const first = args[0] ?? ''
      if (!first || first === 'world' || first === 'summary') {
        reply = ecologyWorldSummary(ctx.db)
        return player
      }
      if (first === 'regions' || first === 'list') {
        reply = `🌍 *Ecology regions:*\n${ecologyRegionIds().map(id => `• ${id}`).join('\n')}\n\n_Use *${prefix}ecology report <region>*._`
        return player
      }
      if (first === 'help' || first === '?') {
        reply = [
          '🌍 *LIVING DUNGEON ECOLOGY*',
          `• *${prefix}ecology world* — every region's pressure/unrest`,
          `• *${prefix}ecology report <region>* — food web + events`,
          `• *${prefix}ecology scout <region>* — insight for the next run`,
          `• *${prefix}ecology cull <region> [species]* — hunt pressure`,
          `• *${prefix}ecology feed <region> [species]* — support prey`,
          `• *${prefix}ecology sabotage <region>* — weaken the boss`,
          `• *${prefix}ecology sanctuary <region>* — calm the region`,
          '',
          `_Regions: ${ecologyRegionIds().join(', ')}_`,
        ].join('\n')
        return player
      }
      // `.ecology <region>` is shorthand for report.
      const action = ACTIONS.has(first) ? first : 'report'
      const regionId = ACTIONS.has(first) ? args[1] : first
      const speciesId = ACTIONS.has(first) ? args[2] ?? null : null
      if (action === 'report') {
        reply = ecologyReport(ctx.db, player, regionId)
        return player
      }
      const result = ecologyAction(ctx.db, player, action, { regionId, speciesId })
      reply = result.message
      return player
    })
    return ctx.reply(reply)
  },
}
