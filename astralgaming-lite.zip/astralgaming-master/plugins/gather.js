/**
 * gather.js — `.gather`: an hour out in a hunting ground with a basket.
 *
 * The trip is a timestamped state (lib/sect-gather.js), so it survives a
 * restart; the goods are the area's own table; three trips a day, and no hunt,
 * cave or walk while the hands are full.
 *
 *   .gather                 pick up the trip you are on (or the screen)
 *   .gather <area>          start an hour out there
 *   .gather collect         come back with the basket
 *   .gather cancel          pack it in (no goods, no trip spent)
 */
import { config } from '../config.js'
import { sectDoorRefusal, missingSectRecordRefusal } from '../lib/world-guards.js'
import { gatherCommand, gatherScreen } from '../lib/sect-gather.js'


export default {
  name: 'gather',
  aliases: ['forage'],
  category: 'event',
  requiresPlayer: true,
  description: `${config.prefix}gather [area|collect|cancel] — an hour of the ground's own goods`,

  async run(ctx) {
    const player = ctx.player
    const wrongWorld = sectDoorRefusal(player, {
      emoji: '🧺', title: '*The gathering grounds belong to the Sect Empire.*',
      here: { cmd: 'mine', label: 'work the Astra mines instead' },
    })
    if (wrongWorld) return ctx.reply(wrongWorld)
    if (!player.sect) return ctx.reply(missingSectRecordRefusal())
    const first = String((ctx.args ?? [])[0] ?? '').toLowerCase()
    if (first === 'areas' || first === 'map' || first === 'where') {
      return ctx.reply(gatherScreen(player, { prefix: config.prefix }).join('\n'))
    }
    return gatherCommand(ctx, { now: Date.now() })
  },
}
