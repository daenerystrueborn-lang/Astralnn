import { claimCreatorBudget, creatorDailyAllowance } from '../lib/creator-budget.js'
import { recordFaucet } from '../lib/economy-ledger.js'
/**
 * stream.js — ASTRATOK, the realm's live streaming platform.
 *
 * USAGE
 *   .stream on | off          GROUP: this group is (or is no longer) an ASTRATOK hall
 *   .stream start [board]     go live (Premium, and only in a hall)
 *   .stream chat              answer the room (this is what pays, see below)
 *   .stream gift [id]         what the room has sent, or send a gift yourself
 *   .stream status            your numbers, live or not
 *   .stream board [page]      who is live right now
 *   .stream end               close the stream and settle up
 *   .stream chatstats         what the chat engine actually contains
 *   .stream halls             which groups may stream (staff)
 *
 * ─────────────────────────── THE ONE RULE ────────────────────────────────
 * STREAMING IS ALLOWED ONLY IN A GROUP WHERE SOMEONE TYPED `.stream on`.
 *
 * That is the owner's rule and it is enforced twice, on purpose:
 *   1. ASTRATOK keeps its own allowlist (lib/astratok/store.js `halls`), so the
 *      list survives a settings repair and can say WHO opened a hall and WHEN;
 *   2. the existing group settings toggle still has to agree, so an admin can
 *      close streaming with the tool they already know.
 * A group that has never run `.stream on` cannot start a stream, whatever else
 * it has enabled.
 *
 * ─────────────────────────── WHAT A STREAM IS ────────────────────────────
 * The engine is lib/astratok/stream.js: a crowd of named viewers who arrive,
 * talk, gift, subscribe and leave, and a settlement at the end. This plugin is
 * the part that talks to chat:
 *
 *   · a LIVE CARD that edits itself (lib/astratok/livecard.js) instead of a
 *     bubble a minute;
 *   · bursts of real chat delivered to the streamer when the room speaks;
 *   · gift call-outs as they land;
 *   · a settlement card that breaks the money down by where it came from.
 *
 * ─────────────────────────── WHY `.stream chat` MATTERS ──────────────────
 * The old stream paid out on a timer, which meant `.stream start` and a walk
 * away was the optimal play. Now:
 *
 *   · hype is the multiplier on everything (lib/astratok/economy.js), and it
 *     only climbs past the forties when the streamer DOES something;
 *   · `.stream chat` is the strongest single action (`ACTIONS.chat`);
 *   · the room itself decays when it is ignored, so an idle stream shrinks.
 *
 * You can absolutely leave a stream running. You will just earn almost nothing,
 * which is the correct outcome.
 *
 * ─────────────────────────── FOLLOWERS ARE FAME ──────────────────────────
 * The owner's call: followers ARE fame, one number read two ways. `.fame` shows
 * the clout a follower count represents and `.followers` shows the audience;
 * both read `player.fame`. That is why a stream's followers join the same stat
 * that comes off dungeon wins, and why plugins/fame.js needed no fork.
 *
 * ─────────────────────────── WHY IT STILL NEEDS DUNGEONS ─────────────────
 * It does not. A stream runs anywhere in the sect world, because a market
 * stream and a boss stream are different shows and both are worth watching. A
 * DUNGEON stream earns a +25% settlement bonus and pulls a bigger crowd, which
 * is the honest reward for the risk: stream from a floor and the room sees you
 * bleed.
 *
 * See lib/astratok/ for the engine, the corpus (2.1M comments), the economy and
 * scripts/astratok-live.mjs for the terminal view of the same stream.
 */
import { config } from '../config.js'
import { updatePlayer, getPlayer } from '../lib/player-repo.js'
import { roundGems } from '../lib/format.js'
import { isPremiumActive } from '../lib/premium.js'
import { getGroupSettings, handleBoolToggle } from '../lib/group-settings.js'
import { getFameTier, getNextFameTier, formatFame } from '../lib/fame-engine.js'
import { whisperToPlayer } from '../lib/player-whisper.js'

import {
  openStream, tick, closeStream, snapshot, setMoment, engage, playerGift,
  addLiveSubs, extendStream, TICK_MS,
} from '../lib/astratok/stream.js'
import { openLiveCard, MIN_EDIT_GAP_MS } from '../lib/astratok/livecard.js'
import {
  CHAT_CARD_MS, CHAT_CARD_MIN_LINES, CHAT_CARD_MAX_LINES, CHAT_CARD_GIFTS,
  GIFT_CALLOUT_MIN_SOLARS, GIFT_CALLOUT_MS,
  STREAM_MAX_MS, EXTENSION_GEMS, EXTENDED_STREAM_MAX_MS,
  minutesLeft, lengthWords, mayPost, notePost,
} from '../lib/astratok/pacing.js'
import {
  shouldAskAI, askChatLines, noteAIUse, buildContext,
  askReplies, fallbackReplies, REPLY_COUNT,
  canAskReplyAI, noteReplyAIUse,
} from '../lib/astratok/ai-chat.js'
import { giftById, giftCatalogue, corpusStats, BOARDS, boardById } from '../lib/astratok/voices.js'
import {
  PCS, canStream, equippedPc, equipPc, ownedPcs, ownsPc, pcById,
  pcLimitLabel, pcPriceLabel, pcRiskLabel, rollBreakdown, rigBusyUntil,
  rigUsedToday, markStreamStarted, breakdownUntil, PC_DAY_MS,
  rigFailed, rigCeilingMs, breakdownMoment, rigLoad, rigLoadLine,
} from '../lib/gaming-pcs.js'
import {
  milestoneAt, nextMilestone, SUB_GIFT_TIERS, SUB_BULK, SUB_BULK_PRICE,
  resolveSubTier, bulkSubPlan, subscriberIncome, hypeLabel,
} from '../lib/astratok/economy.js'
import {
  goLiveCard, liveCard, chatCard, giftCard, settleCard, statusCard, notLiveCard,
  boardCard, followersCard, corpusCard, WORDMARK, n, cash,
  dashboardCard, liveBoardCard, giftedSubCard, subReceiptCard, subsCard, dressingCard,
} from '../lib/astratok/cards.js'
import {
  isHall, setHall, listHalls, getProfile, updateProfile, setLastStream, getLastStream,
  setDressing, clearDressing, addSubscribers, logSubGift, recentSubGifts,
} from '../lib/astratok/store.js'

const MIN_FAME_TO_STREAM = 1_000

/** Active streams, keyed by player id. In-memory by design (see the header). */
const activeStreams = new Map()

/** Rolling chat a streamer has not been shown yet, per stream. */
const chatQueue = new Map()

/* ─────────────────── the public surface combat reads ──────────────────────
 * plugins/liveblast.js sizes its damage off the crowd, and attack/skill/swarm
 * grow the crowd as turns are taken. Those three call sites are the reason these
 * accessors exist and must keep working exactly as before.
 */

/** Viewers watching `playerId`, or 0 if they are not live. */
export function getStreamViewers(playerId) {
  return activeStreams.get(playerId)?.stream?.crowd?.watchers ?? 0
}

/** True while `playerId` has an open stream. */
export function isStreaming(playerId) {
  return activeStreams.has(playerId)
}

/**
 * A combat turn happened. The room reacts: a few arrive, hype lifts, and the
 * stream remembers what the player is doing so the callouts can name it.
 *
 * Returns the new viewer count (0 when not live). Never throws: combat calls
 * this mid-turn and a viewer counter must never be able to break a fight.
 */
export function rampStreamViewers(playerId, context = null) {
  const entry = activeStreams.get(playerId)
  if (!entry) return 0
  try {
    // A turn in a fight is a `fight` moment; naming a boss upgrades it, because
    // the room should react to a boss pull differently from a floor-3 bat.
    // A kill and a death are their own moments and override both: the fight
    // being OVER is the loudest thing that can happen in it.
    const moment = context?.fate ? 'fight' : context?.killed ? 'boss' : context?.boss ? 'boss' : 'fight'
    setMoment(entry.stream, moment, context)
    // A FINISHED fight is not still happening. The context merge keeps old keys
    // on purpose (the boss is still the boss on the next floor), but once a
    // fight is over its live details are a lie: chat was still reading out a
    // health value for a boss that had already died.
    if (context?.killed || context?.fate) {
      for (const key of ['hp', 'target', 'skill']) delete entry.stream.context?.[key]
    }
    return entry.stream.crowd.watchers
  } catch {
    return entry.stream.crowd.watchers ?? 0
  }
}

/**
 * Every live stream, as snapshots — the board.
 *
 * Deliberately NO chat text and no player-identifying detail beyond the name: a
 * public board is browsable by anyone on the website, and the room's chat is
 * only worth showing to someone watching it. The caller that wants a room calls
 * `getStreamRoom()` with an id.
 */
export function listLiveStreams() {
  return [...activeStreams.values()].map(e => {
    const s = snapshot(e.stream)
    return {
      playerId: s.playerId, playerName: s.playerName, title: s.title,
      viewers: s.viewers, peak: s.peak, followers: s.followers, hype: s.hype,
      diamonds: s.diamonds, earned: s.earned, boardName: s.boardName,
      boardEmoji: s.boardEmoji, dungeon: s.dungeon, uptimeMs: s.uptimeMs,
    }
  }).sort((a, b) => b.viewers - a.viewers)
}

/**
 * One live stream WITH its recent chat — for the room page.
 *
 * The chat is served from the per-stream queue the plugin fills every tick, so
 * the page and the streamer's own chat cards show the same conversation.
 */
export function getStreamRoom(playerId) {
  const entry = activeStreams.get(String(playerId))
  if (!entry) return null
  const s = snapshot(entry.stream)
  const chat = (chatQueue.get(String(playerId)) ?? []).slice(-40)
  // The machine is part of the room: it is why the stream can end early, and a
  // surface that draws a stream needs to know what it is running on. The LOAD
  // is computed here, from the same rigLoad the status command prints, so the
  // picture and the caption can never disagree about how hard it is working.
  const pc = entry.rig?.pc ?? null
  const load = pc ? rigLoad(pc, { minutes: (s.uptimeMs ?? 0) / 60_000, viewers: s.viewers }) : null
  return {
    ...s,
    chat,
    rig: pc?.id ?? null,
    rigName: pc?.name ?? null,
    rigBreakdownAt: entry.rig?.breakdownAt ?? 0,
    machine: load ? { ...load, pcName: pc.name } : null,
  }
}

/**
 * Forget every active stream without paying anything.
 *
 * For tests and for a harness that wants a clean slate. A real restart does the
 * same thing by losing the module, which is the documented behaviour.
 */
/**
 * Run one narration tick now, for tests.
 *
 * A stream is driven by an interval, and the interesting rig behaviour — the
 * machine dying mid-stream — only happens on a tick. Without a way to run one,
 * that death was only ever covered as a pure rule (`rigFailed`) and the wiring
 * bug that stopped it firing in the plugin went unseen.
 */
export async function _runTickForTests(ctx, playerId) {
  return runTick(ctx, playerId)
}

export function _resetStreamsForTests() {
  for (const [, entry] of activeStreams) clearInterval(entry.timer)
  activeStreams.clear()
  chatQueue.clear()
}

/** Move a live stream to a dungeon or back to town, without restarting it. */
export function setStreamDungeon(playerId, dungeon, label = null) {
  const entry = activeStreams.get(playerId)
  if (!entry) return false
  entry.stream.dungeon = !!dungeon
  entry.stream.dungeonLabel = dungeon ? (label ?? 'a dungeon') : null
  entry.stream.crowd.dungeon = !!dungeon
  return true
}

/* ─────────────────────────────── helpers ────────────────────────────────── */

const p = () => config.prefix

/** The follower count, which is fame. One number, two names. */
const followersOf = (player) => Math.max(0, Math.floor(player?.fame ?? 0))

/** A player's stored subs, so a stream opens with their real subscriber base. */
async function subsFor(playerId) {
  const profile = await getProfile(playerId).catch(() => null)
  return profile?.subs ?? { tier1: 0, tier2: 0, tier3: 0 }
}

/** Why this player may not start a stream right now, or null. */
async function startRefusal(ctx) {
  const { player, isGroup, sender } = ctx
  if (!isGroup) {
    return `📺 *ASTRATOK only works in a group.* _A stream posts cards into the chat it is watched in. Join a group where an admin ran *${p()}stream on*._`
  }
  if (!(await isHall(sender))) {
    return `📴 *ASTRATOK is not open in this group.*\n\n_A bot mod opens it with *${p()}stream on*. Only a group that has done that can stream._`
  }
  const gs = await getGroupSettings(sender).catch(() => null)
  if (!gs?.streamingEnabled) {
    return `📴 *ASTRATOK is switched off in this group.* _A bot mod can switch it back on with *${p()}stream on*._`
  }
  if (!isPremiumActive(player)) {
    return `👑 *ASTRATOK is a Premium perk.*\n\nGo live, grow a following, and take the creator cut. _Check plans with *${p()}premium*._`
  }
  const fame = followersOf(player)
  if (fame < MIN_FAME_TO_STREAM) {
    return `❌ *You need ${formatFame(MIN_FAME_TO_STREAM)} followers to open a stream.*\n📊 You have *${formatFame(fame)}*.\n\n_Earn followers by fighting, clearing floors and beating bosses. Check *${p()}followers*._`
  }

  // ── the rig ────────────────────────────────────────────────────────────
  //
  // The owner's rule: "u need to buy streaming equipments and gaming pc now,
  // like just in game stuff". A stream needs a machine, so this is a hard gate
  // and not a suggestion — the whole point of the cheap tier is that a player
  // who goes live on a 10k solar box is taking a real risk.
  const rig = canStream(player)
  if (!rig.ok && rig.code === 'none') {
    return [
      `🖥️ *You need a rig to go live.*`,
      '',
      `ASTRATOK is not a phone call: it runs on a machine, and yours has to be bought.`,
      `_Cheap ones cost solars and break. The best one never does._`,
      '',
      `👉 *${p()}store pcs* — the rig store`,
    ].join('\n')
  }
  if (!rig.ok && rig.code === 'broken') {
    const next = ownedPcs(player).filter(x => !x.broken).sort((a, b) => a.price - b.price)[0]
    return [
      `🔧 *${rig.pc?.name ?? 'Your rig'} is in the shop.*`,
      '',
      `It comes back in *${rig.hoursLeft}h*. A breakdown costs ${Math.round((rig.pc?.cooldownHours ?? 72) / 24)} days, every time.`,
      next
        ? `👉 Plug in the *${next.name}* instead: *${p()}stream pc ${next.id}*`
        : `👉 *${p()}store pcs* — a second machine streams while the first is repaired`,
    ].join('\n')
  }
  if (rig.ok && rigUsedToday(player, rig.pc.id)) {
    const until = rigBusyUntil(player, rig.pc.id)
    const hours = Math.max(1, Math.ceil((until - Date.now()) / 3_600_000))
    const spare = ownedPcs(player).filter(x => !x.broken && !rigUsedToday(player, x.id))
    return [
      `📅 *${rig.pc.name} has already streamed today.*`,
      '',
      `One stream a day per machine. It is free again in *${hours}h*.`,
      spare.length
        ? `👉 Use the *${spare[0].name}*: *${p()}stream pc ${spare[0].id}*`
        : `👉 *${p()}store pcs* — a second rig is a second stream`,
    ].join('\n')
  }
  return null
}

/**
 * The player's followers, written once and read everywhere.
 *
 * Followers live on `player.fame` (they ARE fame). A stream adds to it through
 * this function so the write is one place: the fame history entry says it came
 * from streaming, which is what makes `.fame` explain itself.
 */
async function creditFollowers(ctx, playerId, gained, { note = 'stream' } = {}) {
  if (!gained) return null
  let before = 0
  let after = 0
  await updatePlayer(ctx.db, playerId, fresh => {
    before = Math.max(0, Math.floor(fresh.fame ?? 0))
    fresh.fame = before + gained
    after = fresh.fame
    fresh.fameHistory = Array.isArray(fresh.fameHistory) ? fresh.fameHistory : []
    fresh.fameHistory.unshift({
      event: note, value: 1, gained, targetName: null, at: Date.now(),
    })
    fresh.fameHistory = fresh.fameHistory.slice(0, 5)
    return fresh
  }).catch(() => null)
  return { before, after, gained }
}

/** Pay the settlement. Money is written once, at the end, never per tick. */
async function paySettlement(ctx, playerId, settlement) {
  if (!settlement || (!settlement.total && !settlement.gems)) return
  await updatePlayer(ctx.db, playerId, fresh => {
    fresh.wallet = fresh.wallet ?? {}
    const gross = settlement.total
    const budget = claimCreatorBudget(fresh, gross)
    settlement.total = budget.paid
    settlement.budgetWithheld = budget.withheld
    settlement.budgetAllowance = budget.allowance
    // Keep the displayed breakdown consistent with what was actually paid.
    const ratio = gross > 0 ? budget.paid / gross : 0
    settlement.followerSolars = Math.floor((settlement.followerSolars ?? 0) * ratio)
    settlement.subscriberSolars = Math.floor((settlement.subscriberSolars ?? 0) * ratio)
    settlement.giftSolars = Math.max(0, budget.paid - settlement.followerSolars - settlement.subscriberSolars)
    fresh.wallet.solars = (fresh.wallet.solars ?? 0) + budget.paid
    recordFaucet(ctx.db, 'creator_stream', { solars: budget.paid, gems: settlement.gems ?? 0 })
    if (settlement.gems) fresh.wallet.gems = roundGems((fresh.wallet.gems ?? 0) + settlement.gems)
    return fresh
  }).catch(() => null)
}

/* ─────────────────────────── the stream lifecycle ───────────────────────── */

/**
 * Stop a stream: settle, pay, record, and tell the room.
 *
 * Everything that can end a stream goes through here (`.stream end`, the timer,
 * a disconnect), so the settlement is computed exactly once.
 */
async function stopStream(ctx, playerId, { reason = null, announce = true } = {}) {
  const entry = activeStreams.get(playerId)
  if (!entry) return null

  clearInterval(entry.timer)
  activeStreams.delete(playerId)
  chatQueue.delete(playerId)

  const closed = closeStream(entry.stream, { reason })
  if (!closed) return null

  // Followers gained during the stream are part of the same stat as fame, so
  // they are credited here, not per tick, to keep the player write queue quiet.
  const followerCredit = closed.newFollowers
    ? await creditFollowers(ctx, playerId, closed.newFollowers, { note: 'live stream' })
    : null

  await paySettlement(ctx, playerId, closed)
  if (closed.budgetWithheld > 0) await ctx.reply(`☀️ Creator allowance: ${closed.total.toLocaleString()} Solars paid; ${closed.budgetWithheld.toLocaleString()} exceeded today's ${closed.budgetAllowance.toLocaleString()}-Solar budget. Audience progress is unchanged.`).catch(() => null)

  // Career + milestone bookkeeping. A milestone pays ONCE, ever.
  let milestonePaid = null
  await updateProfile(playerId, (profile) => {
    profile.career.streams += 1
    profile.career.totalViewers += closed.peak
    profile.career.bestPeak = Math.max(profile.career.bestPeak, closed.peak)
    profile.career.followersEarned += closed.newFollowers
    profile.career.giftPrice = (profile.career.giftPrice ?? 0) + (closed.giftPrice ?? 0)
    profile.career.earned += closed.total
    profile.career.minutesStreamed += Math.round(closed.durationMs / 60_000)

    if (closed.milestone && !profile.milestones.includes(closed.milestone.at)) {
      profile.milestones.push(closed.milestone.at)
      milestonePaid = { ...closed.milestone }
    }
    // Subscribers accrued in the stream become the player's base.
    const subs = entry.stream.crowd.subs
    profile.subs = {
      tier1: (profile.subs.tier1 ?? 0) + (subs.tier1 ?? 0),
      tier2: (profile.subs.tier2 ?? 0) + (subs.tier2 ?? 0),
      tier3: (profile.subs.tier3 ?? 0) + (subs.tier3 ?? 0),
    }
    profile.lastLive = Date.now()
    return profile
  }).catch(() => null)

  if (milestonePaid) {
    await updatePlayer(ctx.db, playerId, fresh => {
      fresh.wallet = fresh.wallet ?? {}
      milestonePaid.solars = claimCreatorBudget(fresh, milestonePaid.solars).paid
      fresh.wallet.solars = (fresh.wallet.solars ?? 0) + milestonePaid.solars
      recordFaucet(ctx.db, 'creator_milestone', { solars: milestonePaid.solars, gems: milestonePaid.gems ?? 0 })
      if (milestonePaid.gems) fresh.wallet.gems = roundGems((fresh.wallet.gems ?? 0) + milestonePaid.gems)
      return fresh
    }).catch(() => null)
  }

  if (milestonePaid?.solars) {
    await updateProfile(playerId, profile => {
      profile.career.earned += milestonePaid.solars
      return profile
    })
  }

  await setLastStream(playerId, {
    at: Date.now(),
    viewers: closed.peak,
    peak: closed.peak,
    newFollowers: closed.newFollowers,
    earned: closed.total,
    minutes: Math.round(closed.durationMs / 60_000),
  }).catch(() => null)

  // ── the ASTRALTUBE receipt ─────────────────────────────────────────────
  // Finishing a stream is what EARNS a video (plugins/tube.js). It is issued
  // here, at settlement, and not anywhere else: that is the whole licensing
  // model, and putting it anywhere earlier would let someone upload from a
  // stream that then failed.
  let tubeUnlock = null
  try {
    const { grantUnlock } = await import('../lib/astraltube/store.js')
    tubeUnlock = await grantUnlock(playerId, {
      id: `vu_${playerId}_${Date.now()}`,
      playerName: entry.stream.playerName,
      followers: closed.followersAfter,
      streamMinutes: Math.round(closed.durationMs / 60_000),
      streamPeak: closed.peak,
      at: Date.now(),
    })
  } catch {
    // A failed receipt must never cost someone their settlement; they have
    // already been paid above.
    tubeUnlock = null
  }

  // Any chat nobody was shown is simply dropped: a stream that ended is not a
  // backlog to catch up on.
  const card = settleCard(closed, {
    prefix: p(),
    peak: closed.peak,
    durationMs: closed.durationMs,
    newFollowers: closed.newFollowers,
    milestones: milestonePaid ? [milestonePaid] : [],
    reason: closed.reason,
  })

  // Close the live card if there is one, then post the settlement as its own
  // message: the settlement is the record, and it must not be an edit somebody
  // can miss.
  if (entry.card) await entry.card.finish(card).catch(() => false)
  if (announce) await ctx.reply(card).catch(() => null)

  // One line, after the money: your stream bought a video.
  if (announce && tubeUnlock) {
    await ctx.reply([
      `🎬 *ASTRALTUBE unlock earned*`,
      '',
      `That stream is worth one video. It stays good for ${Math.round((tubeUnlock.expiresAt - tubeUnlock.earnedAt) / 3_600_000)} hours.`,
      `👉 *${p()}tube upload*`,
    ].join('\n')).catch(() => null)
  }

  void followerCredit
  return { closed, milestone: milestonePaid }
}

/**
 * Send a card as a PICTURE, falling back to the text it already built.
 *
 * ASTRATOK was text only while every other system in this bot rendered. The
 * owner asked why, and the honest answer was that nobody had written the
 * renderer. This is the wiring half: build the text first (it is the source of
 * truth and the fallback), then try the drawn version.
 *
 * Never throws, never blocks the stream: a picture is a decoration on a
 * message that must go out either way. On a chat with no canvas, or if the
 * render itself faults, the text card lands exactly as before.
 */
async function sendCard(ctx, text, render) {
  try {
    const buf = await render()
    if (buf?.length && typeof ctx.replyImage === 'function') {
      return await ctx.replyImage(buf, text)
    }
  } catch { /* fall through to the text card */ }
  return ctx.reply(text)
}

/** The hype word without its emoji, for drawing. Emoji have no glyph on canvas. */
function bareHype(hype) {
  return String(hypeLabel(hype) ?? '').replace(/[^\p{L}\s]/gu, '').trim()
}

/**
 * One engine tick, then narrate it.
 *
 * The narration is what makes a stream feel like a stream: the live card is
 * redrawn, a burst of chat is sent to the streamer, and any gift is called out
 * the moment it lands.
 */
async function runTick(ctx, playerId) {
  const entry = activeStreams.get(playerId)
  if (!entry) return

  // ── the machine ────────────────────────────────────────────────────────
  //
  // The rig gives out here, mid-stream, exactly as the owner described it: it
  // "can break down during streaming and not work until 3 days later". The
  // failure time was decided when the stream opened, so this is the machine
  // dying rather than a fresh dice roll every minute.
  //
  // The stream is CLOSED rather than paused: a dead machine has no viewers. The
  // settlement still runs — everything earned up to this tick is real — and the
  // reason is on the card, so the player is not left guessing.
  // `entry.rig` is the rig RECORD ({ pc, breakdownAt }); the stream entry above
  // it is a different shape. Passing the wrong one reads `entry.pc`, finds
  // nothing, and reports "the machine is fine" forever.
  if (rigFailed(entry.rig, Date.now())) {
    const pc = entry.rig.pc
    const days = Math.round((pc.cooldownHours ?? 72) / 24)
    await updatePlayer(ctx.db, ctx.from, (fresh) => {
      fresh.pc = fresh.pc ?? { owned: [] }
      const owned = (fresh.pc.owned ?? []).find(e => e?.id === pc.id)
      if (owned) owned.brokenUntil = breakdownUntil(pc)
      return fresh
    }).catch(() => null)
    return stopStream(ctx, playerId, {
      reason: `💥 *${pc.name} died mid-stream.* It is in the shop for ${days} days.`,
      announce: true,
    })
  }

  let bag = null
  try {
    bag = tick(entry.stream)
  } catch {
    // An engine fault must not leave a stream open and paying forever.
    return stopStream(ctx, playerId, { reason: 'The stream dropped.' })
  }
  if (!bag) return

  // ── chat ───────────────────────────────────────────────────────────────
  //
  // THE SPAM FIX. This used to post a fresh bubble carrying EVERY accumulated
  // line as soon as three had piled up, which measured at nineteen bubbles in
  // twenty minutes, one every seventy seconds, on top of a live card redrawing
  // every twelve. Now there are two separate clocks with two separate jobs:
  //
  //   · the LIVE CARD carries the excerpt and redraws on its own throttle. It
  //     is what makes the stream feel alive, and it costs an edit, not a
  //     message.
  //   · a CHAT BUBBLE is a new message. It pings the phone and pushes the card
  //     up the screen, so it only happens every few minutes, only when the
  //     room actually said enough to be worth reading, and it carries at most
  //     a screenful.
  if (bag.lines.length) {
    const queue = chatQueue.get(playerId) ?? []
    queue.push(...bag.lines)
    while (queue.length > 60) queue.shift()
    chatQueue.set(playerId, queue)
  }

  const snap = snapshot(entry.stream)

  // ── gifts worth a call-out ─────────────────────────────────────────────
  // A gift bubble is a celebration, so it gets its own message and is allowed
  // to interrupt the chat clock. It is NOT allowed to arrive every minute.
  const loud = bag.gifts.filter(g => (g.solars ?? 0) >= GIFT_CALLOUT_MIN_SOLARS)
  const lastGiftAt = entry.lastGiftCalloutAt ?? 0
  if (loud.length && Date.now() - lastGiftAt >= GIFT_CALLOUT_MS && mayPost(entry)) {
    entry.lastGiftCalloutAt = Date.now()
    notePost(entry)
    // Only the biggest one; a stack of gift cards is the thing we are fixing.
    const best = loud.sort((a, b) => (b.solars ?? 0) - (a.solars ?? 0))[0]
    await ctx.reply(giftCard(best, { hype: bag.hype })).catch(() => null)
  }

  // ── one chat bubble, on its own clock ──────────────────────────────────
  const queue = chatQueue.get(playerId) ?? []
  const lastChatAt = entry.lastChatCardAt ?? 0
  const due = Date.now() - lastChatAt >= CHAT_CARD_MS && mayPost(entry)
  if (queue.length >= CHAT_CARD_MIN_LINES && due) {
    entry.lastChatCardAt = Date.now()
    notePost(entry)
    const spoken = queue.splice(0, Math.min(queue.length, CHAT_CARD_MAX_LINES))
    chatQueue.set(playerId, queue)
    // Only the biggest gifts ride along. `bag.gifts` is every gift of the last
    // minute, which measured at 3.1 gifts a minute and put nine gift lines at
    // the bottom of a single card. The card is about what was said.
    const rideAlong = [...bag.gifts]
      .sort((a, b) => (b.solars ?? 0) - (a.solars ?? 0))
      .slice(0, CHAT_CARD_GIFTS)
    const chatText = chatCard(snap, {
      lines: spoken,
      gifts: rideAlong,
      prefix: p(),
    })
    await sendCard(ctx, chatText, async () => {
      const { renderChatCard } = await import('../lib/astratok/render.mjs')
      return renderChatCard({
        viewers: snap.viewers,
        hype: snap.hype,
        hypeLabel: bareHype(snap.hype),
        lines: spoken,
        gifts: rideAlong,
        prefix: p(),
        // A media caption is capped on both platforms; the text card is the
        // long version and it still goes out whenever the picture cannot.
        maxLines: CHAT_CARD_MAX_LINES,
        maxGifts: CHAT_CARD_GIFTS,
      })
    }).catch(() => null)
  }

  // ── the live card: the excerpt, on the edit clock ──────────────────────
  await entry.card?.update(liveCard(snap, {
    prefix: p(),
    lines: (chatQueue.get(playerId) ?? []).slice(-5),
    gifts: bag.gifts.slice(-3),
  }), { force: bag.gifts.length > 0 })

  // ── the AI room, off the hot path ──────────────────────────────────────
  // Not awaited. The corpus has already spoken for this tick; these lines land
  // in the NEXT one, a few seconds late, which is exactly how a real chat
  // works. Nothing here can delay or break the stream.
  if (shouldAskAI(entry.stream)) {
    noteAIUse(entry.stream)
    const recent = bag.lines.slice(-6).map(l => l.text)
    askChatLines({
      streamerName: entry.stream.playerName,
      situation: buildContext(entry.stream, snap),
      recent,
      avoid: entry.stream.recentLines ?? null,
    }).then((lines) => {
      if (!lines?.length) return
      const q = chatQueue.get(playerId) ?? []
      // The AI lines wear a real viewer's name, because that is what they are
      // pretending to be; a "🤖" badge would break the room.
      const who = entry.stream.crowd?.watchers ?? []
      for (const text of lines) {
        const viewer = who[Math.floor(Math.random() * Math.max(1, who.length))]
        q.push({
          handle: viewer?.handle ?? 'chat',
          text,
          regular: false,
          persona: 'ai',
          sub: viewer?.subTier || 0,
        })
      }
      while (q.length > 60) q.shift()
      chatQueue.set(playerId, q)
    }).catch(() => null)
  }

  // ── the end ────────────────────────────────────────────────────────────
  if (bag.ended) {
    await stopStream(ctx, playerId, { reason: entry.stream.reason })
  }
}

/* ─────────────────────────────── commands ───────────────────────────────── */

async function cmdStart(ctx, boardArg) {
  const { player, sender, from } = ctx
  const pp = p()

  if (activeStreams.has(player.id)) {
    const s = snapshot(activeStreams.get(player.id).stream)
    return ctx.reply(`🔴 *You are already live.* _${Math.floor(s.uptimeMs / 60000)} minutes in._\nUse *${pp}stream end* to close it out.`)
  }

  const refusal = await startRefusal(ctx)
  if (refusal) return ctx.reply(refusal)
  await ctx.reply(`☀️ Creator payout allowance: ${creatorDailyAllowance(ctx.player).toLocaleString()} Solars per UTC day across streams and milestones. Excess cash earnings are not paid; audience progress continues.`)

  const board = boardArg && BOARDS.some(b => b.id === boardArg) ? boardArg : 'dungeon'
  const subs = await subsFor(player.id)
  const inDungeon = !!player.inDungeon

  // The channel's published videos are part of the audience, not decoration:
  // a shelf of ASTRALTUBE videos brings subscribers who already watch, so a
  // player who posts more gets a bigger stream (crowd.js videoReachBoost).
  let videoCount = 0
  try {
    const { getChannel } = await import('../lib/astraltube/store.js')
    videoCount = (await getChannel(player.id))?.videos ?? 0
  } catch { videoCount = 0 }

  const stream = openStream({
    playerId: player.id,
    playerName: player.name,
    followers: followersOf(player),
    subs,
    dungeon: inDungeon,
    dungeonLabel: inDungeon ? (player.dungeonName ?? player.dungeonId ?? 'a dungeon') : null,
    board,
    videoCount,
  })
  // The stream's own rng comes from a seed, so a player can report a weird
  // stream and it can be reproduced.
  stream.rng = stream.rng ?? null

  // ── the machine ────────────────────────────────────────────────────────
  //
  // The rig that is plugged in is what this stream runs on, and it is marked
  // used for the day HERE rather than at settlement: a player who goes live and
  // closes in ten seconds has still used the machine, or the daily limit is
  // decorative.
  //
  // ONE failure model, not two. The owner said a bad PC "can break down DURING
  // streaming and not work until 3 days later", so:
  //
  //   · the rig has a ceiling on how long it can run (`maxStreamHours`);
  //   · it is rolled ONCE for this stream, and if it is going to fail, the
  //     failure lands at some point before that ceiling — the moment the
  //     machine actually gives out, not a dice roll at the door;
  //   · a failed rig goes into the shop for its cooldown (three days);
  //   · a rig that survives to its ceiling ends the stream normally, with NO
  //     repair clock. It did not break, it just ran out of machine.
  //
  // The roll is seeded from the player and the stream, so a report can be
  // replayed and closing/reopening cannot re-roll a bad machine into a good one.
  const rig = canStream(player).ok ? canStream(player).pc : equippedPc(player)
  let entryRig = null
  if (rig) {
    const seed = [...String(player.id)].reduce((n, ch) => (n * 31 + ch.charCodeAt(0)) % 2147483647, 7)
      ^ (stream.startedAt % 2147483647)
    const willBreak = rollBreakdown(rig, seed)

    // How long this machine can hold this stream. 0 hours means "the machine
    // sets no limit", so the platform's own two hour clock is the ceiling.
    const ceilingMs = rigCeilingMs(rig, stream.lengthMs)
    stream.lengthMs = ceilingMs

    // When it gives out, if it is going to: somewhere in the back 80% of its
    // ceiling, so a player always gets some stream out of a machine before it
    // dies, and two rigs of the same model fail at different moments.
    const breakdownAt = willBreak
      ? breakdownMoment({ now: Date.now(), ceilingMs, seed })
      : 0

    entryRig = { pc: rig, breakdownAt, ceilingMs }
    await updatePlayer(ctx.db, ctx.from, (fresh) => {
      fresh.pc = fresh.pc ?? { owned: [] }
      markStreamStarted(fresh, rig.id, { broken: false })
      return fresh
    }).catch(() => null)
  }

  const card = await openLiveCard(ctx)
  // The HALL a stream belongs to is the chat it was opened in, and the hall
  // allowlist is keyed on ctx.sender (the chat id every group setting uses).
  // Keying this on ctx.from instead is a silent mismatch: `.stream off` would
  // close the hall and leave the stream running in it, paying out into a group
  // that had asked for silence.
  const entry = {
    stream, card, jid: sender ?? from, chatId: sender ?? from,
    startedAt: Date.now(), timer: null,
    // The machine, as ONE record: `rigFailed(entry)` reads `entry.rig.pc` and
    // `entry.rig.breakdownAt`, so storing the pc and the time as two siblings
    // meant the tick could never see a failure. It looked right in review and
    // the mid-stream death silently never fired.
    rig: entryRig ?? null,
  }
  activeStreams.set(entry.stream.playerId, entry)
  entry.stream.playerId = player.id

  // Fire the engine once immediately so the opening card is not an empty room.
  entry.stream.moment = 'idle'
  const opening = tick(entry.stream)
  if (opening?.lines?.length) chatQueue.set(player.id, [...opening.lines])

  const snap = snapshot(entry.stream)
  await card.update(liveCard(snap, { prefix: pp }), { force: true })

  entry.timer = setInterval(() => {
    // Any error here is logged by the caller's interval guard and the stream is
    // closed rather than left running with a dead timer.
    runTick(ctx, player.id).catch(() => stopStream(ctx, player.id, { reason: 'The stream dropped.' }))
  }, TICK_MS)
  // Do not hold the process open just for a stream.
  entry.timer.unref?.()

  const goLive = goLiveCard(snap, { prefix: pp })

  // The machine, on the card that says you are live. A player on a one hour box
  // has to know the stream is a one hour stream BEFORE they plan around it —
  // the same reason a real streamer knows what their capture card can hold.
  const machine = rig
    ? [
      '',
      `🖥️ *Streaming on ${rig.name}* · ${pcLimitLabel(rig)} · ${pcRiskLabel(rig)}`,
      entry.rig?.breakdownAt
        ? `_This one is going to give out at some point in this stream. It happens._`
        : `_A second rig is a second stream: *${p()}store pcs*_`,
    ].join('\n')
    : ''
  return ctx.reply(goLive + machine)
}

async function cmdEnd(ctx) {
  const { player } = ctx
  if (!activeStreams.has(player.id)) {
    return ctx.reply(`⚫ *You are not live.*\n_Use *${p()}stream start* to open a stream._`)
  }
  return stopStream(ctx, player.id, { reason: 'You closed the stream.' })
}

async function cmdStatus(ctx) {
  const { player } = ctx
  const entry = activeStreams.get(player.id)
  if (entry) {
    const snap = snapshot(entry.stream)
    const load = entry.rig?.pc ? rigLoad(entry.rig.pc, { minutes: (snap.uptimeMs ?? 0) / 60_000, viewers: snap.viewers }) : null
    const text = statusCard(snap, { prefix: p() })
      + (load ? `\n\n🖥️ *YOUR PC*\n${rigLoadLine(entry.rig.pc, load)}\n_${load.spec.cpu} · ${load.spec.gpu} · ${load.spec.storage}_` : '')
    return sendCard(ctx, text, async () => {
      const { renderStreamCard } = await import('../lib/astratok/render.mjs')
      const subs = snap.subs ?? {}
      return renderStreamCard({
        playerName: snap.playerName,
        viewers: snap.viewers,
        peak: snap.peak,
        giftPrice: snap.giftPrice ?? 0,
        earned: snap.earned ?? 0,
        giftCount: snap.giftCount ?? 0,
        followers: snap.followers ?? 0,
        followedThisStream: snap.followedThisStream ?? 0,
        subs,
        hype: snap.hype,
        hypeLabel: bareHype(snap.hype),
        minutesLeftMs: snap.endsInMs ?? null,
        topGifters: snap.topGifters ?? [],
        prefix: p(),
        machine: snap.machine ?? null,
      })
    })
  }

  const profile = await getProfile(player.id)
  const last = await getLastStream(player.id)
  return ctx.reply(notLiveCard({
    followers: followersOf(player),
    bestStream: profile.career.bestPeak ? { viewers: profile.career.bestPeak } : null,
    blocked: null,
  }, { prefix: p() }) + (last ? `\n\n📊 _Last stream: peak ${n(last.peak)} viewers · +${n(last.newFollowers)} followers · ${cash(last.earned)} ☀️_` : ''))
}

async function cmdChat(ctx) {
  const { player, args } = ctx
  const entry = activeStreams.get(player.id)
  if (!entry) return ctx.reply(`⚫ *You are not live.*\n_Use *${p()}stream start* to open a stream._`)

  // WHAT THEY ACTUALLY SAID. `.stream chat hey` used to throw the "hey" away and
  // the room answered with seven canned acknowledgements ("he replied", "chat
  // he saw us") no matter what was typed. The room cannot answer a question it
  // never heard.
  const said = args.slice(1).join(' ').trim()
  const result = engage(entry.stream, { said })

  // The acknowledgement lines are a fallback, not the answer. If a model is
  // configured, the room replies TO THE STREAMER, about what they said and
  // what they are doing. Awaited here (unlike a tick) because the player is
  // sitting in a chat waiting for this exact reply and a two second wait reads
  // as "the room is thinking" rather than as a stall.
  if (said) {
    const spoken = await roomRepliesTo(entry.stream, said).catch(() => [])
    if (spoken.length) result.spoke = spoken
  }
  const snap = snapshot(entry.stream)

  const lines = [
    `🎤 *You answer the room.*`,
    `⚡ Hype *${Math.round(result.hype)}%* · 👁️ *${n(snap.viewers)}* watching`,
  ]
  if (result.spoke.length) {
    lines.push('', '💬 *They reply:*')
    for (const l of result.spoke.slice(0, 5)) {
      lines.push(`  ${l.regular ? '🏅' : '⭐'} *${l.handle}*: ${l.text}`)
    }
  }
  if (result.arrivals.length) {
    lines.push('', `👥 *${result.arrivals.length}* more walked in because the room looked alive.`)
  }
  lines.push('', `_Hype is the multiplier on everything. Keep answering: *${p()}stream chat*._`)
  return ctx.reply(lines.join('\n'))
}

async function cmdGift(ctx) {
  const { player, args } = ctx
  const wanted = args[1] ? giftById(String(args[1]).toLowerCase()) : null

  // Gifting SOMEONE ELSE. First arg is a name, second is the gift.
  // This is the thing a viewer actually wants to do: watch a stream, then throw
  // money at it. Before this, `.stream gift` only ever talked about your own.
  const otherToken = args[1] && !wanted ? String(args[1]).toLowerCase() : null
  if (otherToken) {
    const other = findLiveByToken(otherToken)
    if (other) {
      const gift = args[2] ? giftById(String(args[2]).toLowerCase()) : null
      if (!gift) {
        const shelf = giftCatalogue().slice(0, 10)
        return ctx.reply(
          `🎁 *Gift what?*\n\n` +
          shelf.map(g => `  ${g.emoji} *${g.id}* · ${cash(g.diamonds)} ☀️`).join('\n') +
          `\n\n_${p()}stream gift ${other.stream.playerName.split(' ')[0].toLowerCase()} <gift>_`,
        )
      }
      if (other.stream.playerId === player.id) {
        return ctx.reply(`❌ *That is your own stream.* _To prime your own room, use *${p()}stream gift <gift>*._`)
      }
      // The gifter pays the sticker price; the room sees who did it.
      const { runTransferGuards } = await import('../lib/transfer-guards.js')
      if (await runTransferGuards(ctx, player, other.stream.playerId)) return
      // The sticker IS solars now, so the gifter pays exactly what the shelf
      // says and the creator takes a cut of it (lib/astratok/economy.js).
      const price = Math.max(1, Math.round(gift.diamonds ?? 1))
      const balance = await checkAffordable(ctx, price)
      if (balance == null) return
      const after = await chargeBuyer(ctx, price)

      const event = playerGift(other.stream, { from: player.name, gift, isSubscriber: true })
      if (!event) return ctx.reply(`🎁 _That gift could not be sent._`)
      const afterSnap = snapshot(other.stream)
      return ctx.reply([
        giftCard(event, { hype: afterSnap.hype }),
        '',
        `💸 You paid *${cash(price)}* ☀️ · 💰 balance *${cash(after)}* ☀️`,
        `👁️ *${n(afterSnap.viewers)}* watched you do it`,
        `_Standing in the room: *${p()}stream board* · subs pay more: *${p()}stream sub ${other.stream.playerName.split(' ')[0].toLowerCase()}*_`,
      ].join('\n'))
    }
  }

  const entry = activeStreams.get(player.id)

  if (!entry) {
    // Offline: show the shelf, because "what can I send" is a reasonable
    // question before you have ever started a stream.
    const shelf = giftCatalogue()
    const lines = [
      `🎁 *ASTRATOK GIFT SHELF*`,
      '━━━━━━━━━━━━━━━━━━━━',
      ...shelf.slice(0, 12).map(g => `  ${g.emoji} *${g.name}* · ${cash(g.diamonds)} ☀️`),
      '',
      `_${shelf.length} gifts in the catalogue. Bigger gifts are worth more to the streamer and to the room._`,
      '',
      `🔴 *${p()}stream start* to go live and receive them`,
    ]
    return ctx.reply(lines.join('\n'))
  }

  const snap = snapshot(entry.stream)

  // `.stream gift <id>` sends one yourself: a player gifting their own room is
  // the one way a streamer can prime a dead chat, at their own expense.
  if (wanted) {
    // A self gift is a real purchase: the streamer pays the sticker and takes
    // the creator cut back, so priming a dead room costs money. That was always
    // the intent and it never collected.
    const price = Math.max(1, Math.round(wanted.diamonds ?? 1))
    const balance = await checkAffordable(ctx, price)
    if (balance == null) return
    await chargeBuyer(ctx, price)
    const event = playerGift(entry.stream, { from: player.name, gift: wanted, isSubscriber: true })
    if (!event) return ctx.reply(`🎁 _That gift could not be sent._`)
    const after = snapshot(entry.stream)
    return ctx.reply([
      giftCard(event, { hype: after.hype }),
      '',
      `👁️ *${n(after.viewers)}* watching · ⚡ *${Math.round(after.hype)}%*`,
      `_A gift from the streamer stops the room cooling. It is not free._`,
    ].join('\n'))
  }

  const recent = entry.stream.gifts.slice(-5).reverse()
  const lines = [
    `🎁 *GIFTS · ${n(snap.giftCount)} this stream*`,
    '━━━━━━━━━━━━━━━━━━━━',
  ]
  if (recent.length) {
    for (const g of recent) {
      lines.push(`  ${g.gift.emoji} *${g.from}* · *${g.gift.name}* · ${cash(g.gift.diamonds)} ☀️ paid → +${cash(g.solars)} ☀️ to you`)
    }
  } else {
    lines.push('  _Nothing yet. The room gifts when it is excited: answer chat, pull a boss, clip a moment._')
  }
  lines.push('', `🎁 Gifted this stream: *${cash(snap.giftPrice)}* ☀️`)
  lines.push(`☀️ Your cut so far: *${cash(snap.earned)}*`)
  lines.push('', `_Send one yourself: *${p()}stream gift rose*_`)
  lines.push(`_Shelf: ${giftCatalogue().slice(0, 6).map(g => g.id).join(' · ')}_`)
  return ctx.reply(lines.join('\n'))
}

/* ─────────────────────── gifting someone else's stream ──────────────────── */

/** Find a live stream by name or id, however the caller spelled it. */
function findLiveByToken(token) {
  const raw = String(token ?? '').trim().toLowerCase().replace(/^@/, '')
  if (!raw) return null
  for (const [, entry] of activeStreams) {
    const nm = String(entry.stream.playerName ?? '').toLowerCase()
    const id = String(entry.stream.playerId ?? '').toLowerCase()
    if (nm === raw || nm.split(' ')[0] === raw || id === raw || id.endsWith(raw)) return entry
  }
  return null
}

/**
 * Compare a buyer's balance against a price, BEFORE any money moves.
 *
 * Returns the balance, or replies and returns null. Split out because both the
 * single-sub and the bulk path need it, and getting it wrong in one of them is
 * how a bulk purchase half-succeeds.
 */
async function checkAffordable(ctx, cost) {
  const { db, player, from } = ctx
  let balance = 0
  await updatePlayer(db, from, (fresh) => {
    const w = fresh.wallet ?? {}
    balance = Math.max(0, Math.floor(w.solars ?? 0))
    return fresh
  })
  if (balance < cost) {
    await ctx.reply(
      `❌ *Not enough solars.*\n\nYou have *${cash(balance)}* ☀️ and that costs *${cash(cost)}* ☀️.\n` +
      `_Short by ${cash(cost - balance)}._`,
    )
    return null
  }
  return balance
}

/** Move solars out of the buyer's wallet. Returns the new balance. */
async function chargeBuyer(ctx, cost) {
  const { db, from } = ctx
  let after = 0
  await updatePlayer(db, from, (fresh) => {
    const w = fresh.wallet ?? {}
    w.solars = Math.max(0, Math.floor(w.solars ?? 0) - cost)
    after = w.solars
    fresh.lastTransferAt = Date.now()
    return fresh
  })
  return after
}

/**
 * `.stream sub <name> [tier] [count]` — buy subscriptions for a live streamer.
 *
 * THE PRICE IS THE POINT. A sub costs the buyer the real monthly price and pays
 * the streamer every stream afterwards, forever. 100 gold subs is 500,000
 * solars out of one wallet and 60,000 solars into another at every settlement.
 * That is the biggest move a player can make in this game and it is priced to
 * feel like it.
 *
 * The money does not vanish and is not minted: it LEAVES a player's wallet. The
 * only thing that is created is the standing obligation, which is paid by the
 * stream itself, not by the buyer.
 */
/**
 * How the room answers the streamer.
 *
 * The old path gave every message the same seven acknowledgements — "he
 * replied", "chat he saw us", "the streamer noticed me" — whatever was typed.
 * That is not a room reacting, it is a room reporting that it exists.
 *
 * So: the model first, answering the message; and if there is no model, lines
 * chosen by the SHAPE of the message (question, greeting, agreement, argument)
 * rather than a fixed list. The names are still the crowd's own, because a
 * reply card full of strangers reads worse than no card.
 */
async function roomRepliesTo(stream, said) {
  const r = stream.rng ?? Math.random
  const crowd = stream.crowd
  const seats = crowd?.seats ?? []
  if (!seats.length) return []

  const snap = snapshot(stream)
  let texts = []
  if (canAskReplyAI(stream)) {
    noteReplyAIUse(stream)
    texts = await askReplies({
      streamerName: stream.playerName,
      situation: buildContext(stream, snap),
      said,
      recent: [],
    }).catch(() => [])
  }

  // Whatever the model gave, top the list up to a full room from the fallback
  // pools. One model line and three normal viewers reads better than one line
  // and an empty room, and the fallbacks respond to the same message.
  const lines = [...texts]
  if (lines.length < REPLY_COUNT) {
    for (const line of fallbackReplies(said, { rng: r, count: REPLY_COUNT * 2 })) {
      if (lines.length >= REPLY_COUNT) break
      if (!lines.includes(line)) lines.push(line)
    }
  }

  // One viewer each, drawn without repeats, so four answers are four people.
  const used = new Set()
  return lines.map((text) => {
    let viewer = null
    for (let i = 0; i < 8; i++) {
      const candidate = seats[Math.floor(r() * seats.length)]
      if (candidate && !used.has(candidate.handle)) { viewer = candidate; break }
    }
    viewer = viewer ?? seats[Math.floor(r() * seats.length)]
    if (viewer) {
      used.add(viewer.handle)
      viewer.messages = (viewer.messages ?? 0) + 1
    }
    return {
      handle: viewer?.handle ?? 'chat',
      text,
      regular: !!viewer?.regular,
      persona: 'reply',
      sub: viewer?.subTier || 0,
    }
  })
}

/**
 * `.stream extend` — 100 gems for three more hours.
 *
 * The cap is five hours total and it is a HARD cap: a stream that pays for
 * ever is a stream nobody is watching. So this refuses on the cap rather than
 * taking 100 gems and adding nothing, which is the version that produces a
 * support ticket.
 */
/**
 * `.stream pc` / `.stream pc <id>` — the machine ASTRATOK runs on.
 *
 * Two jobs: show what is plugged in and what else is in the cupboard, and switch
 * to one of them. Switching is the answer to a breakdown — a player with a spare
 * rig should not be locked out for three days because the cheap one died.
 */
async function cmdRig(ctx, wanted) {
  const { player, prefix } = ctx
  const owned = ownedPcs(player)
  const equipped = equippedPc(player)

  if (!wanted) {
    if (!owned.length) {
      return ctx.reply([
        '🖥️ *You have no rig.*',
        '',
        '_ASTRATOK runs on a machine, and the machine is bought._',
        '',
        `👉 *${prefix}store pcs* — cheap ones cost solars`,
      ].join('\n'))
    }
    const out = ['🖥️ *YOUR RIGS*', '━━━━━━━━━━━━━━━━━━━━']
    for (const pc of owned) {
      const state = pc.broken
        ? `🔧 *in the shop ${pc.hoursLeft}h*`
        : pc.id === equipped?.id ? '✅ *plugged in*'
          : rigUsedToday(player, pc.id) ? '📅 streamed today'
            : '⚪ idle'
      out.push(`${pc.best ? '👑' : '🖥️'} *${pc.name}* — ${state}`)
      out.push(`   ⏱ ${pcLimitLabel(pc)} · ${pcRiskLabel(pc)} · \`${pc.id}\``)
    }
    const spare = owned.find(pc => !pc.broken && pc.id !== equipped?.id)
    out.push('', `🔌 *${prefix}stream pc <id>* — plug one in`)
    if (spare) out.push(`_Try_ *${prefix}stream pc ${spare.id}*`)
    out.push(`🛒 *${prefix}store pcs* — the rig store`)
    return ctx.reply(out.join('\n'))
  }

  let outcome = null
  await updatePlayer(ctx.db, ctx.from, (fresh) => {
    outcome = equipPc(fresh, wanted)
  }).catch(() => null)

  if (!outcome?.ok) {
    if (outcome?.code === 'not_owned') {
      return ctx.reply([
        `🔒 *You do not own that rig.*`,
        '',
        `👉 *${prefix}store pcs* — the shelf`,
      ].join('\n'))
    }
    if (outcome?.code === 'broken') {
      return ctx.reply([
        `🔧 *${outcome.pc.name} is in the shop* for another *${outcome.hoursLeft}h*.`,
        '',
        `_A broken machine cannot stream. That is what the repair clock is for._`,
        `👉 *${prefix}stream pc* — pick another`,
      ].join('\n'))
    }
    return ctx.reply(`❌ No rig matches *${wanted}*.\n👉 *${prefix}stream pc* to see what you own.`)
  }

  const pc = outcome.pc
  return ctx.reply([
    `🔌 *Plugged in: ${pc.name}*`,
    `⏱ ${pcLimitLabel(pc)} per stream · ${pcRiskLabel(pc)}`,
    '',
    `🔴 *${prefix}stream start* — go live on it`,
  ].join('\n'))
}

async function cmdExtend(ctx) {
  const { player, prefix } = ctx
  const entry = activeStreams.get(player.id)
  if (!entry) {
    return ctx.reply(`⚫ *You are not live.*\n_Only a running stream can be extended._`)
  }
  const snap = snapshot(entry.stream)
  const total = snap.lengthMs ?? STREAM_MAX_MS
  if (total >= EXTENDED_STREAM_MAX_MS) {
    return ctx.reply(
      `⏳ *This stream is already at the five hour cap.*\n\n` +
      `_End it and start again tomorrow: the cap exists so a stream cannot pay ` +
      `forever while nobody is watching._`,
    )
  }

  // Charge the gems, and only then lengthen. A failed charge must not extend.
  let gems = 0
  let charged = false
  await updatePlayer(ctx.db, ctx.from, (fresh) => {
    const w = fresh.wallet ?? {}
    gems = Math.max(0, Math.floor(w.gems ?? 0))
    if (gems < EXTENSION_GEMS) return fresh
    w.gems = gems - EXTENSION_GEMS
    charged = true
    return fresh
  })

  if (!charged) {
    return ctx.reply(
      `👑 *Extending costs ${EXTENSION_GEMS} 💎.*\n\n` +
      `You have *${n(gems)} 💎*.\n` +
      `_Buy gems with *${prefix}gems*._`,
    )
  }

  const added = EXTENDED_STREAM_MAX_MS - total
  extendStream(entry.stream, { ms: 3 * 60 * 60_000, capMs: EXTENDED_STREAM_MAX_MS })
  const after = snapshot(entry.stream)

  return ctx.reply([
    `👑 *STREAM EXTENDED*`,
    '━━━━━━━━━━━━━━━━━━━━',
    `⏳ Now ends in *${lengthWords(after.endsInMs)}*`,
    `💎 Paid: *${EXTENSION_GEMS}* · balance *${n(gems - EXTENSION_GEMS)}* 💎`,
    '',
    `_${lengthWords(Math.min(added, 3 * 60 * 60_000))} bought. The five hour cap is absolute._`,
    `🔴 *${prefix}stream status* · 📊 *${prefix}dm*`,
  ].join('\n'))
}

async function cmdSub(ctx) {
  const { player, args, from, prefix } = ctx
  const pp = p()

  // `.stream sub` alone, or `.stream subs`: what am I owed?
  const target = args[1]

  // No target: show the caller's own subscriber book.
  if (!target) {
    const profile = await getProfile(player.id)
    const income = subscriberIncome(profile.subs)
    const gifted = (await recentSubGifts(50)).filter(r => r.toId === player.id)
    return ctx.reply(subsCard({
      subs: profile.subs,
      perStream: income.solars,
      recent: gifted,
      prefix: pp,
    }))
  }

  const entry = findLiveByToken(target)
  if (!entry) {
    const live = listLiveStreams()
    return ctx.reply(
      `🔍 *Nobody called "${target}" is live right now.*\n\n` +
      (live.length
        ? `Live: ${live.map(s => `*${s.playerName.split(' ')[0]}*`).join(', ')}\n`
        : '_Nobody is live._\n') +
      `\n_Check *${pp}stream board*._`,
    )
  }

  const streamer = entry.stream
  const stream = entry.stream
  if (streamer.playerId === player.id) {
    // Not a moral objection: a player paying themselves is a no-op that still
    // moves hype, which is a free engagement lever.
    return ctx.reply(`❌ *You cannot buy subs for your own stream.* _Someone else has to believe in you._`)
  }

  const tier = resolveSubTier(args[2]) ?? SUB_GIFT_TIERS[1]
  const bulk = /^(bulk|100|x100)$/i.test(String(args[3] ?? '')) || String(args[2] ?? '').toLowerCase() === 'bulk'
  const count = bulk ? SUB_BULK : Math.max(1, Math.min(SUB_BULK, Math.floor(Number(args[3]) || 1)))

  // Buying subs for someone costs solars from a real wallet, so it goes through
  // the same guards a transfer does: level, cooldown, registered target.
  const { runTransferGuards } = await import('../lib/transfer-guards.js')
  if (await runTransferGuards(ctx, player, streamer.playerId)) return

  const plan = bulkSubPlan(tier.tier, count)
  const balance = await checkAffordable(ctx, plan.cost)
  if (balance == null) return

  const after = await chargeBuyer(ctx, plan.cost)

  // 1. Into the LIVE crowd, so it pays at THIS settlement.
  addLiveSubs(stream, { [`tier${tier.tier}`]: count })
  // 2. Into the store, so it pays at every settlement after this one.
  const totals = await addSubscribers(streamer.playerId, { [`tier${tier.tier}`]: count })
  await logSubGift({
    fromId: from ?? player.id, fromName: player.name,
    toId: streamer.playerId, toName: streamer.playerName,
    tier: tier.tier, count, cost: plan.cost,
  })

  // 3. The room reacts, because someone just spent a house on this stream.
  const hypeBoost = Math.min(35, 6 + count * 0.3)
  const snap = snapshot(stream)

  const toStreamer = giftedSubCard({
    fromName: player.name,
    toName: streamer.playerName,
    tier,
    count,
    cost: plan.cost,
    perStream: plan.streamerPerStream,
    totals: (await getProfile(streamer.playerId)).subs,
    hype: hypeBoost,
    prefix: pp,
  })
  const receipt = subReceiptCard({
    toName: streamer.playerName,
    tier,
    count,
    cost: plan.cost,
    balanceAfter: after,
    prefix: pp,
  })

  // The buyer gets the receipt here; the streamer gets the fanfare in their
  // stream, where the rest of the room can see it happen.
  await ctx.reply(receipt)
  if (entry.chatId && entry.chatId !== (from ?? null)) {
    await ctx.reply(toStreamer).catch(() => null)
  }
  return null
}

/** `.stream profile` — the dressing page without changing anything. */
async function cmdProfile(ctx) {
  const { player } = ctx
  const profile = await getProfile(player.id)
  let videos = 0
  try {
    const tube = await import('../lib/astraltube/store.js')
    videos = (await tube.getChannel(player.id)).videos ?? 0
  } catch { videos = 0 }
  return ctx.reply(dressingCard({
    name: player.name,
    handle: profile.handle,
    pfp: profile.pfp,
    banner: profile.banner,
    followers: Math.max(0, Math.floor(player.fame ?? 0)),
    subs: profile.subs,
    videos,
    prefix: p(),
  }))
}

/* ────────────────────────── the private dashboard ───────────────────────── */

/**
 * `.dm` — the whole ASTRATOK picture, in a private chat.
 *
 * In a group, numbers are a performance. In a DM they can be honest, which is
 * why this card is allowed to say "you have not streamed yet" and show the
 * shortfall to the next milestone in plain numbers.
 */
export async function cmdDashboard(ctx) {
  const { player, isGroup, prefix } = ctx
  const pp = p()
  const profile = await getProfile(player.id)
  const last = await getLastStream(player.id)
  const entry = activeStreams.get(player.id)
  const next = nextMilestone(Math.max(0, Math.floor(player.fame ?? 0)))

  let videos = null
  try {
    const tube = await import('../lib/astraltube/store.js')
    const ch = await tube.getChannel(player.id)
    videos = { count: ch.videos ?? 0, views: ch.views ?? 0, earned: ch.earned ?? 0 }
  } catch { videos = null }

  const card = dashboardCard({
    name: player.name,
    handle: profile.handle,
    live: entry ? snapshot(entry.stream) : null,
    career: { ...profile.career, lastStream: last ?? null },
    subs: profile.subs,
    followers: Math.max(0, Math.floor(player.fame ?? 0)),
    earned: profile.career.earned ?? 0,
    videos,
    recent: last ? [{ peak: last.peak, earned: last.earned, at: last.at }] : [],
    nextMilestone: next,
    prefix: pp,
  })

  if (isGroup) {
    // Do not spill someone's numbers into a group: DM them instead.
    const { whisperToPlayer } = await import('../lib/player-whisper.js')
    const sent = await whisperToPlayer(ctx, card).catch(() => false)
    if (sent) return ctx.reply(`📊 _Sent to your DMs. Numbers are between you and the room._`)
    return ctx.reply(`📊 _I could not DM you. Open a private chat with me and send *${pp}dm* there._`)
  }
  return ctx.reply(card)
}

/* ─────────────────────────── channel dressing ───────────────────────────── */

/**
 * `.stream pfp` / `.stream banner` — set or clear your CHANNEL art.
 *
 * Deliberately separate from the game profile. Wanting a channel logo without
 * changing how your fighter looks in a dungeon is the normal case; the two are
 * different identities and this does not touch `.pfp`.
 *
 * Works two ways: reply to a photo and type the command, or send the photo with
 * the command as its caption. Both end up in the same place.
 */
async function cmdDress(ctx, kind, arg) {
  const { player, prefix } = ctx
  const pp = p()

  if (arg === 'off' || arg === 'clear' || arg === 'remove') {
    await clearDressing(player.id, kind)
    const profile = await getProfile(player.id)
    return ctx.reply(dressingCard({
      name: player.name, handle: profile.handle, pfp: profile.pfp, banner: profile.banner,
      followers: Math.max(0, Math.floor(player.fame ?? 0)), subs: profile.subs, prefix: pp,
      justChanged: `🗑 *${kind === 'pfp' ? 'Picture' : 'Banner'} removed.*`,
    }))
  }

  // Any image in the message, including a reply to one.
  let buffer = null
  try {
    const { readProfilePictureBuffer } = await import('../lib/pfp.js')
    buffer = await readProfilePictureBuffer(ctx)
  } catch { buffer = null }

  if (!buffer) {
    const profile = await getProfile(player.id)
    return ctx.reply(
      dressingCard({
        name: player.name, handle: profile.handle, pfp: profile.pfp, banner: profile.banner,
        followers: Math.max(0, Math.floor(player.fame ?? 0)), subs: profile.subs, prefix: pp,
      }) +
      `\n\n📷 _Send the photo with *${pp}stream ${kind}* as the caption, or reply to a photo and type it._`,
    )
  }

  // Host it, because a card needs a URL and a buffer dies with the message.
  let url = null
  let failure = null
  try {
    const { uploadToImgbb } = await import('../lib/imgbb.js')
    url = await uploadToImgbb(buffer, `astratok-${kind}-${player.id}-${Date.now()}`)
  } catch (err) {
    failure = err?.message ?? String(err)
  }
  if (!url) {
    return ctx.reply(
      `❌ *Could not save that picture.*\n_${failure ?? 'the upload failed'}_\n\n` +
      `_Nothing changed. Try again in a moment._`,
    )
  }

  await setDressing(player.id, kind, url)
  const profile = await getProfile(player.id)
  return ctx.reply(dressingCard({
    name: player.name, handle: profile.handle, pfp: profile.pfp, banner: profile.banner,
    followers: Math.max(0, Math.floor(player.fame ?? 0)), subs: profile.subs, prefix: pp,
    justChanged: `✅ *${kind === 'pfp' ? 'Channel picture' : 'Channel banner'} set.*`,
  }))
}

async function cmdBoard(ctx, pageArg) {
  const live = [...activeStreams.values()].map(e => snapshot(e.stream))

  // With nobody live, and nobody asking for a page, lead with the card you can
  // act on: names, viewers, and the exact command to reach each one. The old
  // page-numbered card stays for anyone who explicitly asks for a page.
  if (!pageArg) {
    const mine = live.find(s => s.playerId === ctx.player?.id)
    return ctx.reply(liveBoardCard({
      streams: mine ? [mine, ...live.filter(s => s !== mine)] : live,
      prefix: p(),
      youName: mine ? mine.playerName : null,
    }))
  }
  // Include recently-live players so the board is never empty in a quiet realm.
  const offline = []
  if (live.length < 4) {
    const { boardRows } = await import('../lib/astratok/store.js')
    const rows = await boardRows(8).catch(() => [])
    for (const row of rows) {
      if (live.some(s => s.playerId === row.playerId)) continue
      const player = getPlayer(ctx.db, row.playerId)
      if (!player) continue
      offline.push({
        playerName: player.name, viewers: 0, followers: followersOf(player),
        title: 'last seen on ASTRATOK', live: false, boardName: 'Offline', boardEmoji: '⚫',
      })
    }
  }
  return ctx.reply(boardCard([...live, ...offline], { prefix: p(), page: Number(pageArg) || 1 }))
}

async function cmdHalls(ctx) {
  const halls = await listHalls()
  const lines = [`📺 *ASTRATOK HALLS*`, '━━━━━━━━━━━━━━━━━━━━']
  if (!halls.length) {
    lines.push('_No group has opened ASTRATOK yet._')
    lines.push('', `_An admin opens one with *${p()}stream on*._`)
  } else {
    for (const h of halls) {
      lines.push(`  ✅ \`${h.jid}\` _${h.by ? `opened by ${h.by}` : 'open'}_`)
    }
    lines.push('', `_Only these groups can stream._`)
  }
  return ctx.reply(lines.join('\n'))
}

async function cmdChatStats(ctx) {
  return ctx.reply(corpusCard(corpusStats(), { prefix: p() }))
}

/* ──────────────────────────────── plugin ────────────────────────────────── */

export default {
  name: 'stream',
  aliases: ['live', 'astratok'],
  category: 'social',
  requiresPlayer: true,
  description: 'Go live on ASTRATOK, grow a following, and take the creator cut',
  subcommands: [
    { cmd: 'on | off', desc: 'GROUP: open or close this group as an ASTRATOK hall' },
    { cmd: 'start [board]', desc: 'go live (Premium, a hall, 1,000+ followers, a rig)' },
    { cmd: 'pc [id]', desc: 'your gaming PCs; plug one in' },
    { cmd: 'chat', desc: 'answer the room (this is what pays)' },
    { cmd: 'board', desc: 'who is live right now, and how to reach them' },
    { cmd: 'gift <name> <gift>', desc: "gift someone else's stream" },
    { cmd: 'sub <name> [tier] [count|bulk]', desc: 'buy a streamer subs that pay every stream' },
    { cmd: 'subs', desc: 'your own subscribers, and what they pay' },
    { cmd: 'pfp', desc: 'set your channel picture (reply to a photo)' },
    { cmd: 'banner', desc: 'set your channel banner (reply to a photo)' },
    { cmd: 'profile', desc: 'your channel art and numbers' },
    { cmd: 'extend', desc: '100 gems for 3 more hours (five hour cap)' },
    { cmd: 'status', desc: 'your numbers, live or not' },
    { cmd: 'end', desc: 'close the stream and settle up' },
    { cmd: 'halls', desc: 'which groups may stream (staff)' },
  ],

  async run(ctx) {
    const { args, reply } = ctx
    const pp = p()
    const sub = (args[0] || '').toLowerCase()

    // ── the hall switch, first: it is a group action, not a player one ────
    if (sub === 'on' || sub === 'off') {
      const me = ctx.from ?? ctx.sender
      const on = sub === 'on'
      // The shared toggle does the permission checks (group only, admin or bot
      // mod) and writes groupSettings. ASTRATOK's own allowlist is written only
      // once that has agreed, so the two can never disagree about a refusal.
      // handleBoolToggle writes groupSettings itself (and does the admin/mod
      // check). If it refuses, its own refusal has already been sent and we must
      // not also open a hall behind its back.
      const gs = await getGroupSettings(ctx.sender).catch(() => null)
      const wasOn = gs?.streamingEnabled === true
      const handled = await handleBoolToggle(ctx, 'streamingEnabled', 'ASTRATOK', '📺',
        `_Members can now go live with *${pp}stream start*. Only this group._`)
      if (handled === false) return handled

      // Trust the STORE, not the argument: the toggle is the source of truth for
      // whether the group actually agreed.
      const after = await getGroupSettings(ctx.sender).catch(() => null)
      const actuallyOn = after?.streamingEnabled === true
      if (actuallyOn === wasOn && on !== wasOn) {
        // The write was refused or silently failed. Do not open the hall.
        return handled
      }
      await setHall(ctx.sender, actuallyOn, { by: ctx.player?.name ?? String(me) }).catch(() => null)
      if (!actuallyOn) {
        // Ending the hall ends any stream running in it, rather than leaving one
        // paying out into a group that has asked for silence.
        for (const [, entry] of activeStreams) {
          if (entry.chatId === ctx.sender || entry.chatId === ctx.from || entry.jid === ctx.sender) {
            // The settlement still goes to the chat that watched it, even though
            // this command arrived from the same place. Both are the group.
            await stopStream(ctx, entry.stream.playerId, { reason: 'The group closed ASTRATOK.' })
          }
        }
      }
      return handled
    }

    if (sub === 'start') return cmdStart(ctx, (args[1] || '').toLowerCase())
    if (sub === 'end' || sub === 'stop') return cmdEnd(ctx)
    if (sub === 'chat' || sub === 'talk') return cmdChat(ctx)
    if (sub === 'gift' || sub === 'gifts') return cmdGift(ctx)
    if (sub === 'board' || sub === 'live') return cmdBoard(ctx, args[1])
    if (sub === 'halls' || sub === 'groups') return cmdHalls(ctx)
    if (sub === 'chatstats' || sub === 'voices') return cmdChatStats(ctx)
    if (sub === 'status' || sub === 'stats') return cmdStatus(ctx)
    if (sub === 'sub' || sub === 'subs' || sub === 'subscribe') return cmdSub(ctx)
    if (sub === 'pc' || sub === 'rig' || sub === 'machine') return cmdRig(ctx, args[1])
    if (sub === 'extend' || sub === 'longer') return cmdExtend(ctx)
    if (sub === 'dm' || sub === 'dashboard' || sub === 'me') return cmdDashboard(ctx)
    if (sub === 'pfp' || sub === 'pic' || sub === 'avatar') {
      return cmdDress(ctx, 'pfp', String(args[1] ?? '').toLowerCase())
    }
    if (sub === 'banner' || sub === 'cover') {
      return cmdDress(ctx, 'banner', String(args[1] ?? '').toLowerCase())
    }
    if (sub === 'profile' || sub === 'channel') return cmdProfile(ctx)

    return reply(
      `📺✨ *ASTRATOK* ✨📺\n` +
      '━━━━━━━━━━━━━━━━━━━━\n' +
      `*${pp}stream start* — go live\n` +
      `*${pp}stream chat* — answer the room (this is what pays)\n` +
      `*${pp}stream gift* — the gift shelf and what the room sent\n` +
      `*${pp}stream board* — who is live right now\n` +
      `*${pp}stream status* — your numbers\n` +
      `*${pp}stream end* — close it and settle up\n` +
      `*${pp}stream chatstats* — what the chat engine contains\n\n` +
      `_Admin: *${pp}stream on* opens ASTRATOK in this group. Only a group that has done that can stream._\n` +
      `_Your followers are your fame. Check *${pp}followers*._`
    )
  },
}

/**
 * Boot-time restore: nothing to restore, deliberately. A stream is a live thing;
 * a restart ends it and the settlement it would have paid is lost. That is the
 * correct trade (see lib/astratok/store.js) and it means this plugin has no
 * start-up work.
 */

export { followersCard, getFameTier, getNextFameTier, milestoneAt, nextMilestone, MIN_FAME_TO_STREAM }
