/**
 * take-to.js — `.take-to town <name | @mention | reply>` — the owner's door.
 *
 * THE OWNER'S AMENDMENT (2026-10-06): the 48h timed thaw is gone, and a body
 * stays in the ice until a player fights through the guardian wall and carries
 * them home — or until the owner does THIS. `.take-to town` is the manual
 * release: the named player is taken out of the ice, set down in the Astral
 * Town square, and WOKEN outright (30% HP, the same share four Revival Drinks
 * would leave them with) — not left unconscious waiting on Drinks, because a
 * body nobody can rescue and nobody has Drinks for must not become a second
 * way to be stuck. Everything the Dreamlands death already took stays taken:
 * they still come home with nothing but their Solars, Gems, Monds, characters,
 * beasts, pets, skills, stats and level.
 *
 * It also finishes waking a player who is already home and partway through
 * the Revival Drink stage — the owner's mercy is the same at both doors.
 *
 * Owner-only (same isOwnerJid gate as every admin tool), and it accepts the
 * same three targets the admin commands do: a typed name, an @mention, or a
 * reply. The destination word is part of the command's shape and is required:
 * only `town` exists today, so `.take-to town <name>`.
 */
import { config } from '../config.js'
import { isOwnerJid, extractTarget } from '../lib/group-helpers.js'
import { updatePlayer, getPlayer } from '../lib/player-repo.js'
import { isFrozen, isUnconscious, takeBodyToTown } from '../lib/dreamlands-death.js'

/** Resolve the target player record: mention/reply jid first, then typed name. */
function resolveTarget(db, ctx, name) {
  const users = db?.data?.users ?? {}
  const jid = extractTarget(ctx)
  if (jid && users[jid]) return { player: users[jid], jid, how: 'mention' }
  const q = String(name ?? '').toLowerCase().trim()
  if (!q) return { player: null, jid: null, how: 'none' }
  const byName = Object.values(users).find(u => (u?.name ?? '').toLowerCase() === q)
    ?? Object.values(users).find(u => (u?.name ?? '').toLowerCase().includes(q))
  if (!byName) return { player: null, jid: null, how: 'none' }
  return { player: byName, jid: byName.jid ?? byName.id ?? null, how: 'name' }
}

export default {
  name: 'take-to',
  aliases: ['taketo', 'taketotown', 'take-to-town'],
  category: 'admin',
  requiresPlayer: false,
  description: 'Owner-only: take a frozen player out of the ice and wake them in Astral Town',

  async run(ctx) {
    const p = config.prefix
    if (!ctx.from || !isOwnerJid(ctx.from)) {
      return ctx.reply('❌ This command is restricted to the bot owner.')
    }

    const args = (ctx.args ?? []).map(a => String(a ?? ''))
    const dest = (args[0] ?? '').toLowerCase()
    const nameQuery = args.slice(1).join(' ').trim()

    if (dest !== 'town') {
      return ctx.reply(
        `🗝️ *Usage:* *${p}take-to town <name>*\n` +
        `_Town is the only place to take someone back from. Today it is the only place anyone can be taken to at all._`,
      )
    }

    const { player: target, jid, how } = resolveTarget(ctx.db, ctx, nameQuery)
    if (!target || !jid) {
      return ctx.reply(
        `❓ *Nobody called "${nameQuery || '?'}" is playing.*\n` +
        `_Name them, or reply to / mention them:_ *${p}take-to town <name>*`,
      )
    }

    if (!isFrozen(target) && !isUnconscious(target)) {
      const state = getPlayer(ctx.db, jid)
      if (isFrozen(state) || isUnconscious(state)) {
        return ctx.reply(`🧊 *${state?.name ?? target.name}* is already on their way out.`)
      }
      return ctx.reply(
        `✅ *${target.name}* is not in the ice.\n` +
        `_They are up and about. There is nothing to take back._`,
      )
    }

    // The taker's own record supplies the receipt line; a carried body also
    // releases whoever was carrying it, directly rather than lazily, so the
    // rescuer does not walk the rest of the way home with empty arms.
    let line = null
    let carriedByJid = null
    let carriedByName = null
    await updatePlayer(ctx.db, jid, pl => {
      if (isFrozen(pl) && pl.frozen?.carried) {
        carriedByJid = pl.frozen.rescuerJid ?? null
        carriedByName = pl.frozen.rescuer ?? null
      }
      line = takeBodyToTown(pl, { by: ctx.player?.name ?? 'the owner' })
      return pl
    })
    if (carriedByJid) {
      await updatePlayer(ctx.db, carriedByJid, res => {
        // Release only the arms that were actually holding THIS body.
        if (res?.carryingBody && (res.carryingBody.jid === jid || res.carryingBody.jid == null)) {
          res.carryingBody = null
        }
        return res
      }).catch(() => {})
    }

    if (!line) {
      return ctx.reply(`⚠️ *The ice did not let go.* _Nothing was changed._`)
    }

    const carryNote = carriedByName
      ? `\n🤲 _*${carriedByName}* was carrying them. The weight is off their shoulders now — ` +
        `the walk home is theirs to finish or abandon._`
      : ''
    return ctx.reply(
      `🗝️ ━━━ *TAKEN TO TOWN.* ━━━ 🗝️\n\n` +
      line + carryNote + '\n\n' +
      `_They keep everything the death did not take. The death took plenty._`,
    )
  },
}
