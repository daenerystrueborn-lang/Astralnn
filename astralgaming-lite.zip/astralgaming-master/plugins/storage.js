/**
 * .storage — the Starter Pack chest's storage interface.
 *
 * With a home, pack slots extend the regular home store. Without one, the same
 * command uses the player's standalone Starter Storage and does not create a
 * house. `.home store/take` remains available for homeowners.
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { allItems } from '../lib/game-data.js'
import { getInventoryCap, inventoryFullMessage } from '../lib/inventory-limits.js'
import { hasHome, storageCap, storageItems, storageLabel } from '../lib/housing-engine.js'

const itemMap = Object.fromEntries(allItems.map((item) => [item.id, item]))
const isEmptySlot = (id) => id == null || id === ''
const countItems = (items) => items.filter((id) => !isEmptySlot(id)).length

function findItem(query) {
  const q = String(query ?? '').toLowerCase().trim()
  if (!q) return null
  if (itemMap[q]) return itemMap[q]
  return allItems.find((item) => item.name.toLowerCase().includes(q)) ?? null
}

function parseItemAndQty(args) {
  const last = args.at(-1)
  if (args.length > 1 && /^\d+$/.test(last)) {
    return { query: args.slice(0, -1).join(' '), qty: Math.max(1, Math.min(99, Number(last))) }
  }
  return { query: args.join(' '), qty: 1 }
}

function render(player) {
  const p = config.prefix
  const cap = storageCap(player)
  if (cap <= 0) {
    return `📦 You don't have storage slots yet. Open a Starter Chest from a pack with *${p}use <chest>* first.`
  }
  const store = storageItems(player)
  const label = hasHome(player) ? 'Home Storage' : 'Standalone Starter Storage'
  const counts = new Map()
  for (const id of store) {
    if (isEmptySlot(id)) continue
    counts.set(id, (counts.get(id) ?? 0) + 1)
  }
  const lines = [...counts.entries()].map(([id, count]) => {
    const name = itemMap[id]?.name ?? id
    return `• *${name}*${count > 1 ? ` x${count}` : ''}`
  }).sort((a, b) => a.localeCompare(b))
  const used = countItems(store)
  return `📦 *${label}* _(${used}/${cap})_\n` +
    `${store.length > used ? `▫️ Empty saved positions: ${store.length - used}\n` : ''}\n` +
    (lines.length ? lines.join('\n') : '_Empty._') +
    `\n\n*${p}storage put <item> [qty]* · *${p}storage take <item> [qty]*`
}

async function handlePut(ctx, args) {
  const p = config.prefix
  if (storageCap(ctx.player) <= 0) return ctx.reply(render(ctx.player))
  if (!args.length) return ctx.reply(`❌ *Usage:* *${p}storage put <item name or id> [qty]*`)
  const { query, qty } = parseItemAndQty(args)
  const item = findItem(query)
  if (!item) return ctx.reply(`❌ Item "_${query}_" not recognized.`)

  let outcome = null
  await updatePlayer(ctx.db, ctx.from, (player) => {
    const store = storageItems(player)
    const inventory = Array.isArray(player.inventory) ? player.inventory : []
    const owned = inventory.filter((id) => id === item.id).length
    if (!owned) { outcome = { reason: 'none' }; return player }
    const cap = storageCap(player)
    const room = Math.max(0, cap - countItems(store))
    if (!room) { outcome = { reason: 'full', cap, label: storageLabel(player) }; return player }
    const moved = Math.min(qty, owned, room)
    let removed = 0
    player.inventory = inventory.filter((id) => {
      if (id === item.id && removed < moved) { removed++; return false }
      return true
    })
    for (let index = 0; index < moved; index++) {
      const emptyIndex = store.findIndex(isEmptySlot)
      if (emptyIndex >= 0) store[emptyIndex] = item.id
      else store.push(item.id)
    }
    outcome = { reason: 'ok', moved, held: countItems(store), cap, label: storageLabel(player) }
    return player
  })

  if (outcome.reason === 'none') return ctx.reply(`❌ You don't have any *${item.name}* in your bag.`)
  if (outcome.reason === 'full') return ctx.reply(`📦 *${outcome.label} is full* _(${outcome.cap})._`)
  return ctx.reply(`📦 Stored *${outcome.moved}x ${item.name}* in ${outcome.label}. _${outcome.held}/${outcome.cap}_`)
}

async function handleTake(ctx, args) {
  const p = config.prefix
  if (storageCap(ctx.player) <= 0) return ctx.reply(render(ctx.player))
  if (!args.length) return ctx.reply(`❌ *Usage:* *${p}storage take <item name or id> [qty]*`)
  const { query, qty } = parseItemAndQty(args)
  const item = findItem(query)
  if (!item) return ctx.reply(`❌ Item "_${query}_" not recognized.`)

  let outcome = null
  await updatePlayer(ctx.db, ctx.from, (player) => {
    const store = storageItems(player)
    const stored = store.filter((id) => id === item.id).length
    if (!stored) { outcome = { reason: 'none' }; return player }
    const moved = Math.min(qty, stored)
    const inventory = Array.isArray(player.inventory) ? player.inventory : []
    const room = Math.max(0, getInventoryCap(player) - countItems(inventory))
    if (room < moved) { outcome = { reason: 'invfull', player }; return player }
    let removed = 0
    const remaining = store.filter((id) => {
      if (id === item.id && removed < moved) { removed++; return false }
      return true
    })
    if (hasHome(player)) player.home.storage = remaining
    else player.starterStorage.items = remaining
    player.inventory = inventory
    for (let index = 0; index < moved; index++) {
      const emptyIndex = player.inventory.findIndex(isEmptySlot)
      if (emptyIndex >= 0) player.inventory[emptyIndex] = item.id
      else player.inventory.push(item.id)
    }
    outcome = { reason: 'ok', moved, label: storageLabel(player) }
    return player
  })

  if (outcome.reason === 'none') return ctx.reply(`❌ No *${item.name}* in storage.`)
  if (outcome.reason === 'invfull') return ctx.reply(inventoryFullMessage(outcome.player))
  return ctx.reply(`🎒 Took *${outcome.moved}x ${item.name}* from ${outcome.label}.`)
}

export default {
  name: 'storage',
  // No 'stash' alias: plugins/stash.js has owned .stash since the empire
  // feature, and the loader is last-registered-wins, so claiming it here
  // silently stole the empire stash command (.stash drop/take/invite).
  category: 'housing',
  requiresPlayer: true,
  description: `${config.prefix}storage — use home storage or your standalone Starter Chest`,
  subcommands: [
    { cmd: 'list', desc: 'show stored items and capacity' },
    { cmd: 'put <item> [qty]', desc: 'move items from your bag into storage' },
    { cmd: 'take <item> [qty]', desc: 'move items from storage back to your bag' },
  ],
  async run(ctx) {
    const sub = (ctx.args[0] ?? '').toLowerCase()
    if (sub === 'put' || sub === 'store') return handlePut(ctx, ctx.args.slice(1))
    if (sub === 'take' || sub === 'get') return handleTake(ctx, ctx.args.slice(1))
    return ctx.reply(render(ctx.player))
  },
}
