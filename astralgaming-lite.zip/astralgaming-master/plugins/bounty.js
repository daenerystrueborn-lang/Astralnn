/**
 * bounty — one personal risk-tiered bounty per day (R7).
 * Usage:
 *   .bounty                 — today's target and progress
 *   .bounty pick <tier>     — cautious | bold | reckless (before progress)
 *   .bounty claim           — collect when the goal is met
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { rollBounty, pickTier, claimBounty, formatBounty, TIERS } from '../lib/bounty-board.js'
import { recordFaucet } from '../lib/economy-ledger.js'
import { settlePlayerXp, xpLevelLine } from '../lib/player-xp.js'

export default {
  name: 'bounty',
  aliases: ['contract'],
  category: 'economy',
  requiresPlayer: true,
  description: 'Pick a risk-tiered daily bounty and claim its payout',

  async run(ctx) {
    const p = config.prefix
    const sub = (ctx.args?.[0] ?? '').toLowerCase().trim()
    const now = Date.now()

    if (sub === 'pick') {
      const tier = (ctx.args?.[1] ?? '').toLowerCase().trim()
      let reply
      await updatePlayer(ctx.db, ctx.from, (player) => {
        const r = pickTier(player, tier, now)
        if (!r.ok) {
          reply = r.reason === 'unknown_tier'
            ? `❌ Unknown tier. Pick: ${TIERS.map((t) => t.id).join(', ')}`
            : '❌ Your tier is locked in once kills are counted. Finish or wait for tomorrow.'
          return player
        }
        reply = `${r.tier.emoji} *${r.tier.label} bounty accepted* — hunt *${r.bounty.family}* monsters (${r.tier.goal} kills).`
        return player
      })
      return ctx.reply(reply)
    }

    if (sub === 'claim') {
      let reply
      await updatePlayer(ctx.db, ctx.from, (player) => {
        const r = claimBounty(player, now)
        if (!r.ok) {
          reply = r.reason === 'no_tier' ? `❌ Pick a tier first: \`${p}bounty pick cautious\``
            : r.reason === 'already_claimed' ? '❌ Already claimed today — a new bounty arrives tomorrow.'
            : `❌ Not done yet — ${r.remaining ?? 0} kills to go.`
          return player
        }
        recordFaucet(ctx.db, 'bounty', { solars: r.solars })
        reply = `📜 *Bounty complete!* ☀️ ${r.solars.toLocaleString()} Solars · 📖 ${r.xp} XP (${r.tier.label} tier)${xpLevelLine(settlePlayerXp(player))}`
        return player
      })
      return ctx.reply(reply)
    }

    let text = ''
    await updatePlayer(ctx.db, ctx.from, (player) => {
      rollBounty(player, now)
      text = formatBounty(player, p, now)
      return player
    })
    return ctx.reply(text)
  },
}
