/**
 * form.js — universal character ascension built on combat doctrine.
 *
 * Every character has a form meter charged by attacking, skilling, guarding,
 * moving, dodging and surviving. At 100 meter the player may spend it once per
 * battle. This does not replace authored ultimates (Mei's Final Form, Gojo's
 * Hollow Purple, etc.); it gives the whole roster a cross-mode combat chassis.
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { activateDoctrineForm, doctrineStatus, flushDoctrineLines } from '../lib/combat-doctrine.js'

export default {
  name: 'form',
  aliases: ['battleform', 'ascend'],
  category: 'combat',
  requiresPlayer: true,
  description: 'Spend a full character doctrine meter to ascend for a few turns',
  subcommands: [
    { cmd: 'status', desc: 'show character/weapon doctrine, meter and counterplay' },
  ],

  async run(ctx) {
    const prefix = config.prefix
    const sub = String(ctx.args?.[0] ?? '').toLowerCase()
    let reply = ''
    await updatePlayer(ctx.db, ctx.from, player => {
      if (sub === 'status' || !player.inBattle || !player.battleState) {
        reply = doctrineStatus(player, player.battleState, prefix)
        return player
      }
      const bs = player.battleState
      if (bs.type === 'pvp' && bs.myTurn === false) {
        reply = '⏳ You can only ascend on your own PvP turn.'
        return player
      }
      const result = activateDoctrineForm(player, bs)
      reply = result.message
      const pending = flushDoctrineLines(player.battleState)
      if (pending) reply += `\n${pending}`
      return player
    })
    return ctx.reply(reply)
  },
}
