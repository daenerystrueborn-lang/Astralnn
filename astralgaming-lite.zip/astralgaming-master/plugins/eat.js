/**
 * eat — Eat food from your inventory to refill your hunger bar.
 *
 * The eating twin of plugins/use.js: same race-guarded updatePlayer
 * consume-one-instance pattern, but instead of routing through lib/effects.js
 * it calls feed() in lib/hunger-engine.js — the single owner of player.hunger.
 * The Golden Apple (immunity:true) also switches on permanent hunger immunity
 * until the player's next death.
 *
 * Usable anywhere EXCEPT mid-battle, so you can eat between dungeon fights
 * without eating a turn in the battle economy.
 *
 * Usage: <prefix>eat <food name or id>
 */
import { config } from '../config.js'
import { allItems } from '../lib/game-data.js'
import { updatePlayer } from '../lib/player-repo.js'
import { feed, hungerBar, ensureHunger } from '../lib/hunger-engine.js'
import { noteConsumableUsed } from '../lib/scenario-metrics.js'
import { addStatusEffect } from '../lib/effects.js'
import { perkTotal } from '../lib/housing-engine.js'

const itemMap = Object.fromEntries(allItems.map(i => [i.id, i]))

/** First matching id in inventory — exact id, else partial name. */
function findInInventory(inventory, query) {
  const q = query.toLowerCase()
  if (inventory.includes(q)) return q
  for (const id of inventory) {
    const item = itemMap[id]
    if (item && item.name.toLowerCase().includes(q)) return id
  }
  return null
}

export default {
  name:           'eat',
  aliases:        ['feed'],
  category:       'inventory',
  requiresPlayer: true,
  description:    `${config.prefix}eat <food> — eat food to refill your hunger bar`,

  async run(ctx) {
    const { player, args } = ctx
    const pr = config.prefix

    if (player.inBattle) {
      return ctx.reply(`⚔️ You can't stop to eat mid-battle! Finish the fight first.`)
    }
    if (!args || args.length === 0) {
      return ctx.reply(`Usage: *${pr}eat <food name or id>*\nSee your food with *${pr}inventory*.`)
    }

    const query   = args.join(' ')
    const foundId  = findInInventory(player.inventory ?? [], query)
    if (!foundId) {
      return ctx.reply(
        `❌ *"${query}"* not found in your inventory.\n` +
        `Cook a dish with *${pr}cook* or check *${pr}inventory*.`,
      )
    }

    const item = itemMap[foundId]
    if (!item) return ctx.reply(`❌ Item data for *${foundId}* is missing. Please report this bug.`)

    if (item.type !== 'food') {
      return ctx.reply(
        `❌ *${item.name}* isn't food — you can't eat it.\n` +
        `Try *${pr}use ${foundId}* instead.`,
      )
    }

    let raceAborted = false
    let barAfter    = ''
    let restored    = 0
    const mealNotes = []
    const wasImmune = item.immunity === true

    await updatePlayer(ctx.db, ctx.from, (p) => {
      if (p.inBattle) { raceAborted = true; return }
      const inv = p.inventory ?? []
      const idx = inv.indexOf(foundId)
      if (idx === -1) { raceAborted = true; return } // consumed by a concurrent command

      const hasKitchen = perkTotal(p, 'cook') > 0
      const hungerMult = hasKitchen && !wasImmune ? 1.2 : 1
      const before = ensureHunger(p).current       // hunger before eating
      restored = Math.round(feed(p, Math.round(item.hunger * hungerMult), { immune: wasImmune }) - before)

      // Apply cooked dish HP/MP recovery (percentage-backed so meals stay
      // relevant at high levels too).
      if (item.mealHeal) {
        const healScale = hasKitchen ? 1.25 : 1
        if (item.mealHeal.hp || item.mealHeal.hpPct) {
          const maxHp = p.maxHp ?? 100
          const rawHp = Math.round(((item.mealHeal.hp ?? 0) + maxHp * (item.mealHeal.hpPct ?? 0)) * healScale)
          const beforeHp = p.hp ?? 0
          p.hp = Math.min(maxHp, beforeHp + rawHp)
          const gained = p.hp - beforeHp
          if (gained > 0) mealNotes.push(`❤️ +${gained} HP`)
        }
        if (item.mealHeal.mp || item.mealHeal.mpPct) {
          const maxMp = p.maxMp ?? 50
          const rawMp = Math.round(((item.mealHeal.mp ?? 0) + maxMp * (item.mealHeal.mpPct ?? 0)) * healScale)
          const beforeMp = p.mp ?? 0
          p.mp = Math.min(maxMp, beforeMp + rawMp)
          const gained = p.mp - beforeMp
          if (gained > 0) mealNotes.push(`💧 +${gained} MP`)
        }
      }

      // Apply cooked dish combat buff (Home Kitchen adds +1 turn duration).
      if (item.mealBuff) {
        // One meal preparation at a time: refresh, never stack whole menus.
        p.activeEffects = (p.activeEffects ?? []).filter(e => !itemMap[e.sourceId]?.mealBuff)
        const buffs = Array.isArray(item.mealBuff) ? item.mealBuff : [item.mealBuff]
        for (const b of buffs) {
          const eff = b.duration
            ? { ...b, duration: b.duration + (hasKitchen ? 1 : 0), sourceId: item.id }
            : { ...b, sourceId: item.id }
          addStatusEffect(p, eff)
          if (eff.type === 'damage_boost')     mealNotes.push(`⚔️ +${eff.percent}% DMG (${eff.duration}t)`)
          else if (eff.type === 'damage_reduction') mealNotes.push(`🛡️ -${eff.percent}% DMG taken (${eff.duration}t)`)
          else if (eff.type === 'regen')       mealNotes.push(`💚 +${eff.amount} HP/turn (${eff.duration}t)`)
          else if (eff.type === 'shield')      mealNotes.push(`🛡️ +${eff.amount} Shield (${eff.duration}t)`)
          else if (eff.type === 'strengthen')  mealNotes.push(`✨ +${eff.value} ${String(eff.stat).toUpperCase()} (${eff.duration}t)`)
        }
      }

      inv.splice(idx, 1)
      p.inventory = inv
      // Season 2: eating a ration counts as using a consumable (The Ration).
      noteConsumableUsed(p, { db: ctx.db, food: true })
      if (p.inBattle && p.battleState) p.battleState.usedConsumable = true
      barAfter = hungerBar(p)
    })

    if (raceAborted) {
      return ctx.reply(`❌ *${item.name}* is no longer in your inventory — please try again.`)
    }

    const mealLine = mealNotes.length ? `\n✨ *Meal bonus:* ${mealNotes.join(' · ')}` : ''
    const immuneNote = wasImmune
      ? `\n✨ *The Golden Apple's power fills you* — you will not hunger again until you die.`
      : ''
    return ctx.reply(
      `🍽️ You ate *${item.name}*! _(+${restored} hunger)_\n` +
      `${barAfter}${mealLine}${immuneNote}`,
    )
  },
}
