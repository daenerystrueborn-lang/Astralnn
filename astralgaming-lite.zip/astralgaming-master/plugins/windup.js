import { config } from '../config.js'
import { runTrioSignatureMove } from '../lib/trio-pve-runner.js'

export default {
  name: 'windup',
  aliases: ['cardia', 'escapement'],
  category: 'combat',
  requiresPlayer: true,
  description: `${config.prefix}windup: Cardia Grand Escapement (locks enemy turn for 2 consecutive actions)`,
  async run(ctx) {
    return runTrioSignatureMove(ctx, 'windup')
  },
}
