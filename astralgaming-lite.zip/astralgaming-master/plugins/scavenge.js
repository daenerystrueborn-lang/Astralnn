import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { getActiveSeason, getSeasonRuntime } from '../lib/season-engine.js'
import { mapTheme, placeName } from '../lib/orv-map.js'
import { WAT_OFFSET_MS, season02ScavengeStatus, scavengeSeason02 } from '../lib/season-02-quest-engine.js'

export function formatScavengeResetTime(ms) {
  const date = new Date(ms + WAT_OFFSET_MS)
  return `${String(date.getUTCHours()).padStart(2, '0')}:${String(date.getUTCMinutes()).padStart(2, '0')} WAT`
}

export default {
  name: 'scavenge',
  aliases: ['searchruins'],
  category: 'season',
  requiresPlayer: true,
  description: 'Search a mapped Season 2 location for a small daily supply find',

  async run(ctx) {
    const season = getActiveSeason(ctx.db)
    if (season?.id !== 'season_02') {
      return ctx.reply('🌙 Scavenging is part of Season 2, Life of a Regressor.')
    }
    const runtime = getSeasonRuntime(ctx.db)
    const action = String(ctx.args[0] ?? '').toLowerCase()
    const theme = mapTheme(ctx.db)
    const locationId = ctx.player?.location
    const place = theme?.places?.[locationId]
    if (action === 'status' || action === 'check') {
      let status = null
      await updatePlayer(ctx.db, ctx.from, player => {
        status = season02ScavengeStatus(player, { runNumber: runtime.runNumber })
        return player
      })
      return ctx.reply(
        `「 🔎 SCAVENGE 」\n\n` +
        `Searches remaining today: *${status.remaining}/1*\n` +
        `Next reset: *${formatScavengeResetTime(status.resetAt)}*\n\n` +
        `_One search per WAT day. Finds use existing Season 2 supplies; there is no purchase or survival currency._`,
      )
    }
    if (ctx.player?.inBattle || ctx.player?.inDungeon) {
      return ctx.reply(`⚔️ Finish the encounter and leave the Tower before scavenging. Your climb is saved.`)
    }
    if (!place) {
      return ctx.reply(
        `「 🔎 SCAVENGE 」\n\n` +
        `There is nothing safe to search at this location. Move to a place on the Season 2 System Map first.\n` +
        `⌁ _${config.prefix}map_ · view the six sectors`,
      )
    }

    let result = null
    await updatePlayer(ctx.db, ctx.from, player => {
      result = scavengeSeason02(player, {
        runNumber: runtime.runNumber,
        location: locationId,
      })
      return player
    })
    if (!result?.ok) {
      return ctx.reply(
        `「 🔎 SCAVENGE 」\n\n` +
        `You have used today’s search. The next one opens at *00:00 WAT*.\n` +
        `_No items or Stars were spent._`,
      )
    }
    const found = result.loot.id.replaceAll('_', ' ')
    return ctx.reply(
      `「 🔎 SCAVENGE 」\n\n` +
      `*${placeName(locationId, ctx.db)}*\n` +
      `You search the quiet edges of the route and find *${found}* ×${result.loot.amount}.\n` +
      (result.held ? `_Your bag is full. The find is held until you make room._\n` : '') +
      `_One search is used for today. No filter item, purchase or new currency is involved._`,
    )
  },
}
