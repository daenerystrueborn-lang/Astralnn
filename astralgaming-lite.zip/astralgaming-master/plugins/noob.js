/**
 * noob.js — .noob on|off
 *
 * Turns a group into a newcomers' room: only players below level 100 may run
 * commands there. Veterans are refused with a reply (never a kick), so new
 * players get a room of their own. Group admins, bot mods and the bot owner
 * bypass the gate entirely — they set the mode and can always lift it with
 * `.noob off`.
 *
 * The flag lives in data/group-settings.json (`noobOnly`) and is enforced by
 * the level gate in handler.js (lib/level-gate.js). `.noob` and `.pro` are
 * opposites: turning one on clears the other.
 */
import { config } from '../config.js'
import {
  parseOnOff, saveGroupSettings, saveFailedMessage, settingsStorageLabel, isGroupOrBotOwnerOrMod,
} from '../lib/group-settings.js'
import { NOT_GROUP, NOT_STAFF } from '../lib/group-helpers.js'
import { PRO_MIN_LEVEL } from '../lib/level-gate.js'

export default {
  name:        'noob',
  aliases:     [],
  category:    'group',
  description: `Restrict a group to below-level-${PRO_MIN_LEVEL} players only (.noob on/off)`,

  async run(ctx) {
    const p = config.prefix
    if (!ctx.isGroup) return ctx.reply(NOT_GROUP)
    if (!(await isGroupOrBotOwnerOrMod(ctx))) return ctx.reply(NOT_STAFF)

    const want = parseOnOff(ctx.args[0])
    if (want === null) return ctx.reply(`❌ *Usage:* ${p}noob on|off`)

    const res = await saveGroupSettings(ctx.sender, s => {
      s.noobOnly = want
      if (want) s.proOnly = false
      return s
    })
    if (!res.ok) return ctx.reply(saveFailedMessage('Noob-only mode', res.error))

    const stored = res.settings.noobOnly === true
    return ctx.reply(
      `🐣 *Noob-only mode* is now *${stored ? 'ON' : 'OFF'}*.` +
      (stored ? `\nOnly players below *level ${PRO_MIN_LEVEL}* can use commands here now. Veterans are refused with a reply — admins and mods are exempt, and can lift it with *${p}noob off*.` : '') +
      `\n_Saved to ${settingsStorageLabel()} — verify any time with ${p}gcsettings._`,
    )
  },
}
