import { config } from '../config.js'
import { runTrioSignatureMove } from '../lib/trio-pve-runner.js'

export default {
  name: 'heartlock',
  aliases: ['remi', 'fifthheart', 'padlock'],
  category: 'combat',
  requiresPlayer: true,
  description: `${config.prefix}heartlock: Remi Key of the Fifth Heart (executes mobs, pierces boss DEF, seals PvP abilities and healing)`,
  async run(ctx) {
    return runTrioSignatureMove(ctx, 'heartlock')
  },
}
