/**
 * mod.js — .mod (reply to a member's message, or @mention them)
 *          .mod list
 * Grants a member GLOBAL "mod" status (db.data.mods — see lib/mod-repo.js).
 * Once granted, that JID is a mod in every group the bot is in, not just
 * wherever the command was run. A mod is NOT a WhatsApp group admin and
 * NOT the bot owner; they're a bot-level role that unlocks exactly:
 *   .ban .unban .kick .add .antilink .welcome .setwelcome .goodbye .setgoodbye
 * WhatsApp group admins are refused on all of them. Owner-only commands
 * (.admin, .givegems, .setlevel, .resetplayer, .mod, ...) check isOwnerJid()
 * themselves, so mods can never run them.
 *
 * Permission to GRANT/REVOKE mod status is OWNER-ONLY. WhatsApp group
 * admins cannot make someone a mod — only the bot owner can.
 */
import { extractTarget, isOwnerJid, NOT_ALLOWED } from '../lib/group-helpers.js'
import { isPlatformOwner } from '../lib/platform/permissions.js'
import { addMod, getMods } from '../lib/mod-repo.js'
import { config } from '../config.js'

export default {
  name:        'mod',
  aliases:     [],
  category:    'admin',
  description: 'Grant a member global mod status (owner only, reply to their message or @mention them)',

  async run(ctx) {
    const { reply, msg, from, db, sender, args, sock } = ctx

    // isOwnerJid() only understands WhatsApp numbers: it strips `@…` and cuts
    // at the first colon, so `tg:847362` becomes the literal string `tg` and
    // never matches an owner. That made `.mod` unusable by the bot's own owner
    // on Telegram, which matters because mod status is what unlocks the staff
    // tools there (plugins-telegram/kick.js and friends). Check both ids: the
    // raw platform one and the linked character one.
    if (!isPlatformOwner(ctx.platformId) && !isOwnerJid(from)) return reply(NOT_ALLOWED)

    if (args[0]?.toLowerCase() === 'list') {
      const mods = getMods(db)
      if (mods.length === 0) return reply('📋 No mods set yet.')
      return sock.sendMessage(sender, {
        text: `📋 *Bot mods:*\n\n` + mods.map(id => `• @${id.replace(/@.*$/, '')}`).join('\n'),
        mentions: mods,
      }, { quoted: msg })
    }

    // ctx, not msg: extractTarget() dispatches on the platform when it is given
    // the whole context (lib/group-helpers.js), and a raw grammY message has no
    // WhatsApp contextInfo to read a target from.
    const target = extractTarget(ctx)
    if (!target) {
      return reply(
        `❌ Reply to the member's message (or @mention them).\n\n` +
        `*Usage:*\n` +
        `${config.prefix}mod (reply to user) — grant mod status\n` +
        `${config.prefix}mod list — show current mods`,
      )
    }

    if (target === from) {
      return reply(`❌ You can't mod yourself.`)
    }
    if (isOwnerJid(target) || isPlatformOwner(target)) {
      return reply(`❌ The bot owner doesn't need mod status.`)
    }

    const bareTarget = target.replace(/@.*$/, '')
    const added = await addMod(db, target)

    if (!added) {
      return sock.sendMessage(sender, {
        text: `⚠️ @${bareTarget} is already a mod.`,
        mentions: [target],
      }, { quoted: msg })
    }

    return sock.sendMessage(sender, {
      text:
        `🛡️ @${bareTarget} is now a *mod* (applies in every group).\n` +
        `They can use: ban, unban, kick, add, antilink, welcome, setwelcome, goodbye, setgoodbye.`,
      mentions: [target],
    }, { quoted: msg })
  },
}
