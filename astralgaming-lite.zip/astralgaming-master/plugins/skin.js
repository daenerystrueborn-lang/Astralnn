/**
 * skin.js — view/equip paid character skins.
 *
 * Purchases and upgrades happen at the Game Shop (.gm skins / .gm buy skin /
 * .gm upgrade skin). This command only manages the cosmetic/combat variant a
 * player already owns, and sends the skin art when the form is changed.
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { sendImage } from '../lib/image.js'
import { characterMap } from '../lib/game-data.js'
import {
  CHARACTER_SKINS, findSkin, skinById, skinInfoCard, equipSkin, unequipSkin,
  ownsSkin, skinLevel, equippedSkinId, activeSkin, ensureCharacterSkins,
} from '../lib/character-skins.js'

function ownedSkinList(player, pr) {
  ensureCharacterSkins(player)
  const lines = []
  for (const def of CHARACTER_SKINS) {
    if (!ownsSkin(player, def.id)) continue
    const level = skinLevel(player, def.id)
    const worn = equippedSkinId(player, def.characterId) === def.id ? ' · equipped' : ''
    lines.push(`• ${def.emoji ?? '🎭'} *${def.name}* — Lv${level}/${def.maxLevel}${worn}`)
  }
  return [
    '🎭 *Your Character Skins*',
    '',
    ...(lines.length ? lines : ['_No skins owned yet._']),
    '',
    `Browse: *${pr}gm skins*`,
    `Equip: *${pr}skin equip <skin id>*`,
    `Info: *${pr}skin info <skin id>*`,
    `Unequip: *${pr}skin unequip <character>*`,
  ].join('\n')
}

export default {
  name: 'skin',
  aliases: ['skins', 'characterskin'],
  category: 'account',
  requiresPlayer: true,
  description: `${config.prefix}skin — view/equip character skins bought from the Game Shop`,
  subcommands: [
    { cmd: 'list', desc: 'show owned skins' },
    { cmd: 'info <skin>', desc: 'show skin art, effects and upgrade costs' },
    { cmd: 'equip <skin>', desc: 'wear an owned skin and show its art' },
    { cmd: 'unequip <character>', desc: 'return a character to the original form' },
  ],

  async run(ctx) {
    const pr = config.prefix
    const args = ctx.args ?? []
    const sub = String(args[0] ?? '').toLowerCase()

    if (!sub || sub === 'list' || sub === 'owned') {
      return ctx.reply(ownedSkinList(ctx.player, pr))
    }

    if (sub === 'info') {
      const def = findSkin(args.slice(1).join(' '))
      if (!def) return ctx.reply(`❌ Unknown skin. Browse with *${pr}gm skins*.`)
      const card = skinInfoCard(def, ctx.player, pr)
      const art = def.images?.info ?? def.images?.card
      if (art) return sendImage(ctx, art, card)
      return ctx.reply(card)
    }

    if (sub === 'buy' || sub === 'upgrade') {
      return ctx.reply(
        `🏛️ Skins are bought and upgraded at the *Game Shop* in Crownspire.\n` +
        `Travel there, then use *${pr}gm buy skin <skin id>* or *${pr}gm upgrade skin <skin id>*.`,
      )
    }

    if (sub === 'equip') {
      const query = args.slice(1).join(' ')
      if (!query) return ctx.reply(`❌ *Usage:* *${pr}skin equip <skin id>*`)
      const def = findSkin(query)
      if (!def) return ctx.reply(`❌ Unknown skin *"${query}"*. Browse with *${pr}gm skins*.`)
      let outcome = null
      await updatePlayer(ctx.db, ctx.from, player => {
        outcome = equipSkin(player, def.id)
      })
      if (!outcome?.ok) {
        const baseName = characterMap[def.characterId]?.name ?? def.characterId
        if (outcome?.reason === 'base_character') {
          return ctx.reply(`🔒 You must own *${baseName}* before equipping *${def.name}*.`)
        }
        if (outcome?.reason === 'slain') {
          return ctx.reply(`💀 *${baseName}* is slain. Revive the character before wearing a skin.`)
        }
        if (outcome?.reason === 'not_owned') {
          return ctx.reply(`❌ You do not own *${def.name}*. Buy it with *${pr}gm buy skin ${def.id}*.`)
        }
        if (outcome?.reason === 'in_battle') {
          return ctx.reply(`⚔️ Finish the current battle before changing skins.`)
        }
        return ctx.reply(`❌ That skin could not be equipped.`)
      }
      const caption =
        `🎭 *${def.name}* equipped!\n` +
        `Lv${outcome.level}/${def.maxLevel} · ${def.abilityName ?? 'Variant ability'}\n\n` +
        `_The character's original ability identity remains active._`
      const art = def.images?.equip ?? def.images?.card
      if (art) return sendImage(ctx, art, caption)
      return ctx.reply(caption)
    }

    if (sub === 'unequip' || sub === 'remove') {
      const characterId = String(args[1] ?? ctx.player?.equippedCharacter ?? '').toLowerCase()
      if (!characterId) return ctx.reply(`❌ *Usage:* *${pr}skin unequip <character>*`)
      let outcome = null
      await updatePlayer(ctx.db, ctx.from, player => {
        outcome = unequipSkin(player, characterId)
      })
      if (!outcome?.ok) {
        if (outcome?.reason === 'in_battle') return ctx.reply(`⚔️ Finish the current battle before changing skins.`)
        return ctx.reply(`⚠️ No skin is equipped for that character.`)
      }
      return ctx.reply(`✅ *${characterMap[characterId]?.name ?? characterId}* returned to the original form.`)
    }

    return ctx.reply(`❌ Unknown skin command. Use *${pr}skin list*, *${pr}skin info <skin>*, or *${pr}skin equip <skin>*.`)
  },
}
