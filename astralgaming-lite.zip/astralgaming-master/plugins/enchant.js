/**
 * enchant — the Enchanting Table.
 *
 *   .enchant                      the table: your enchanted gear + what exists
 *   .enchant list                 the six enchantments and every level of them
 *   .enchant <item>               one item's panel: what it has, next prices
 *   .enchant <item> <enchant>     pay the bill and apply the next level
 *   .enchant grind <item>         strip every enchant, reclaim 25% of it
 *
 * The rules live in lib/enchantments.js; this file is the counter you walk up
 * to. Three deliberate calls:
 *
 *   1. Enchantments are bound to an ITEM, not a slot. player.inventory is a
 *      flat array of ids with no per-copy identity, so an item is the finest
 *      grain the game can honestly promise — "your Iron Sword has Sharpness"
 *      is a promise that survives equipping, unequipping, banking and dying.
 *      The one thing it cannot promise is "this sword and not the other two",
 *      so the docs say so out loud instead of pretending otherwise.
 *   2. Nothing is ever charged for a change that did not land. Every purchase
 *      pre-checks for a fast fail, then re-validates the level, the materials
 *      and the wallet inside the updatePlayer() mutator — the same
 *      double-check craft.js does — and setEnchant() refuses an out-of-range
 *      level. A raced command costs nothing.
 *   3. Applying requires you to name the item. `.enchant sharpness` on its own
 *      shows you the panel instead of quietly charging you for the one piece
 *      of gear you happen to own.
 */
import { config } from '../config.js'
import { allItems } from '../lib/game-data.js'
import { kingdomDoorRefusal } from '../lib/world-guards.js'
import { updatePlayer } from '../lib/player-repo.js'
import { rarityStars } from '../lib/rarity.js'
import { hasInventoryRoom, inventoryFullMessage } from '../lib/inventory-limits.js'
import { noServicesRefusal } from '../lib/dreamlands-core.js'
import { durabilityReadout } from '../lib/durability.js'
import { recordSink } from '../lib/economy-ledger.js'
import {
  ENCHANTS, enchantSlots, slotCanHold,
  levelText, levelName, roman, fmtPct,
  enchantsFor, enchantLevel, setEnchant, clearEnchants, enchantBadge, enchantCount,
  isEnchantableItem, nextLevelCost, grindRefund, mendingConfig,
  ENCHANT_BOOK_SOLARS, ENCHANT_SOLARS, hasEnchantingBook,
} from '../lib/enchantments.js'
import { purchaseEnchantingBook } from '../lib/enchanting-book.js'

const itemMap = Object.fromEntries(allItems.map((i) => [i.id, i]))

const DIVIDER = '┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈┈'
const GRIND_PCT = 0.25

const SLOT_LABEL = {
  weapon: 'Weapon', offhand: 'Offhand', helmet: 'Helmet',
  chestplate: 'Chestplate', boots: 'Boots', tool: 'Tool',
}
const SLOT_EMOJI = {
  weapon: '⚔️', offhand: '🛡️', helmet: '🪖', chestplate: '🧥', boots: '👢', tool: '⛏️',
}
const ALL_SLOTS = ['weapon', 'offhand', 'helmet', 'chestplate', 'boots', 'tool']

const LEVEL_WORDS = { i: 1, ii: 2, iii: 3, iv: 4, v: 5 }

function slotList(def) {
  const slots = def.slots ?? []
  if (slots.length === ALL_SLOTS.length) return 'any gear'
  return slots.map((s) => SLOT_LABEL[s] ?? s).join(' / ')
}

function slotText(item) {
  return SLOT_LABEL[item?.slot] ?? (item?.slot ? item.slot : 'Gear')
}

function solars(n) {
  return `☀️${(Number(n) || 0).toLocaleString()}`
}

/* ─────────────────────────── what the player owns ────────────────────────── */

/**
 * Every enchantable item the player has on them — equipped (any slot) or in
 * the bag — as { item, itemId, slot } with the bag entry de-duplicated against
 * an equipped copy. Gear that never wears out is not "enchantable"; that is
 * the same maxDurability test the durability system uses, so the two can
 * never disagree about what can hold an enchant.
 */
function enchantableOwned(player) {
  const eq = player.equipped ?? {}
  const seen = new Map()
  for (const slot of ALL_SLOTS) {
    const id = eq[slot]
    const item = id ? itemMap[id] : null
    if (isEnchantableItem(item)) seen.set(id, { item, itemId: id, slot })
  }
  for (const id of player.inventory ?? []) {
    const item = itemMap[id]
    if (!item || seen.has(id) || !isEnchantableItem(item)) continue
    seen.set(id, { item, itemId: id, slot: item.slot ?? null })
  }
  return [...seen.values()]
}

function isOwned(player, itemId) {
  if (Object.values(player.equipped ?? {}).includes(itemId)) return true
  return (player.inventory ?? []).includes(itemId)
}

/**
 * findOwned(player, query) → { hit } | { error: 'none'|'not-owned'|'ambiguous', ... }
 * Exact id, then exact name, then a unique partial match — the same
 * resolution order craft.js uses for recipes, so "iron sword" and
 * "iron_sword" both land on the same entry.
 */
function findOwned(player, query) {
  const owned = enchantableOwned(player)
  if (!owned.length) return { error: 'none' }

  const q = (query ?? '').trim().toLowerCase()
  if (!q) {
    if (owned.length === 1) return { hit: owned[0] }
    return { error: 'ambiguous', matches: owned }
  }

  let hit = owned.find((e) => e.itemId.toLowerCase() === q)
    ?? owned.find((e) => e.item.name.toLowerCase() === q)
  if (hit) return { hit }

  const matches = owned.filter((e) =>
    e.item.name.toLowerCase().includes(q) || e.itemId.toLowerCase().includes(q))
  if (matches.length === 1) return { hit: matches[0] }
  if (matches.length > 1) return { error: 'ambiguous', matches }
  // Not owned / not enchantable — distinguish the two for a better message.
  const anyItem = allItems.find((i) => i.id.toLowerCase() === q)
    ?? allItems.find((i) => i.name?.toLowerCase() === q)
  if (anyItem && !isEnchantableItem(anyItem)) return { error: 'not-enchantable', item: anyItem }
  return { error: 'not-owned', query: query.trim() }
}

/** Resolve an enchant from an id, name, or an unambiguous prefix ("prot"). */
function findEnchant(word) {
  if (!word) return null
  const w = String(word).toLowerCase()
  const exact = ENCHANTS.find((e) => e.id === w || e.name.toLowerCase() === w)
  if (exact) return exact
  const prefixed = ENCHANTS.filter((e) => e.id.startsWith(w) || e.name.toLowerCase().startsWith(w))
  return prefixed.length === 1 ? prefixed[0] : null
}

/* ─────────────────────────── the Enchanting Book ────────────────────────── */

function lockedView(p) {
  return (
    `🔒 *You need an Enchanting Book.*\n` +
    `${DIVIDER}\n` +
    `The book is the table: without it nothing can be applied — and every\n` +
    `enchant, at every level, costs *${solars(ENCHANT_SOLARS)}* plus its materials.\n\n` +
    `📕 *Enchanting Book* — ${solars(ENCHANT_BOOK_SOLARS)}, once, from the shop:\n` +
    `   *${p}shop buy enchanting book*\n` +
    `   _or_ *${p}enchant buy*\n\n` +
    `_Own it and the whole table opens up, for good._`
  )
}

/**
 * The purchase, exported so `.shop buy enchanting book` runs THIS function
 * rather than a second copy of the price/insufficient-funds/success copy.
 * Two doorways, one message set, one charge (purchaseEnchantingBook()).
 */
export async function buyEnchantingBook(ctx) {
  const p = config.prefix
  const outcome = await purchaseEnchantingBook(ctx.db, ctx.from)

  if (outcome.reason === 'already') {
    return ctx.reply(`❌ You already own an Enchanting Book. Use *${p}enchant* to work the table.`)
  }
  if (outcome.reason === 'solars') {
    return ctx.reply(
      `❌ *Not enough Solars!*\n` +
      `The Enchanting Book costs ☀️ *${ENCHANT_BOOK_SOLARS.toLocaleString()}*. ` +
      `You have ☀️ *${(outcome.have ?? 0).toLocaleString()}*.\n` +
      `_Short by ☀️ ${(ENCHANT_BOOK_SOLARS - (outcome.have ?? 0)).toLocaleString()}._`,
    )
  }
  if (outcome.reason === 'nosave') {
    return ctx.reply(`❌ Couldn't find your save — try *${p}register* first.`)
  }

  return ctx.reply(
    `📕 *ENCHANTING BOOK ACQUIRED!* 🔮\n${DIVIDER}\n` +
    `Paid: ☀️ *${ENCHANT_BOOK_SOLARS.toLocaleString()} Solars*\n` +
    `Remaining: ☀️ *${(outcome.remaining ?? 0).toLocaleString()}*\n\n` +
    `The table is yours for good. Every enchant, at every level, costs\n` +
    `*${solars(ENCHANT_SOLARS)}* plus its materials.\n\n` +
    `Start here: *${p}enchant* — then *${p}enchant <item>* for a piece's prices.`,
  )
}

/* ─────────────────────────────── rendering ──────────────────────────────── */

function costText(cost) {
  const parts = (cost?.items ?? []).map(({ itemId, qty }) =>
    `${qty}× ${itemMap[itemId]?.name ?? itemId}`)
  if (cost?.solars) parts.push(solars(cost.solars))
  return parts.join(', ')
}

/** Per-material shortfall for an item's bill, plus a wallet check. */
function missingFor(player, cost) {
  const inv = player.inventory ?? []
  const missing = []
  for (const { itemId, qty } of cost.items ?? []) {
    const have = inv.filter((id) => id === itemId).length
    if (have < qty) missing.push(`${itemMap[itemId]?.name ?? itemId} ×${qty - have}`)
  }
  const have = player.wallet?.solars ?? 0
  if (cost.solars > have) missing.push(`${(cost.solars - have).toLocaleString()} more Solars`)
  return missing
}

function catalogLines() {
  const lines = [`*✨ THE SIX ENCHANTMENTS*`, DIVIDER]
  for (const def of ENCHANTS) {
    lines.push(`${def.icon} *${def.name}*  _(${slotList(def)} · up to ${roman(def.maxLevel)})_`)
    lines.push(`   ${def.blurb}`)
    for (let lvl = 1; lvl <= def.maxLevel; lvl++) {
      lines.push(`   ${roman(lvl)} · ${levelText(def.id, lvl)}`)
    }
  }
  return lines
}

function ownedGearLines(player) {
  const owned = enchantableOwned(player)
  const enchanted = owned.filter((e) => enchantCount(player, e.itemId) > 0)
  if (!owned.length) {
    return { lines: [`_You are carrying nothing that can hold an enchant — only gear that wears out can._`], enchanted }
  }
  if (!enchanted.length) {
    return { lines: [`_Nothing of yours is enchanted yet._`], enchanted }
  }
  const lines = enchanted.map((e) => {
    const eq = Object.values(player.equipped ?? {}).includes(e.itemId) ? ' ⚡' : ''
    const pool = mendingConfig(player, e.itemId)
    const poolText = pool ? `  _(${pool.used}/${pool.daily} Mending today)_` : ''
    return `  ${SLOT_EMOJI[e.slot] ?? '🔹'} *${e.item.name}*${eq} — ${enchantBadge(player, e.itemId).replace(/^✨ /, '')}${poolText}`
  })
  return { lines, enchanted }
}

function homeView(ctx) {
  const p = config.prefix
  const { lines } = ownedGearLines(ctx.player)
  const bookLine = hasEnchantingBook(ctx.player)
    ? `📕 *Enchanting Book:* owned ✅\n`
    : `📕 *Enchanting Book:* not yet — ${solars(ENCHANT_BOOK_SOLARS)} _(${p}shop buy enchanting book)_\n`
  return (
    `🔮 *THE ENCHANTING TABLE*\n${DIVIDER}\n` +
    `Enchantments are bound to an *item*, not a slot — buy one and that piece\n` +
    `keeps it through equipping, unequipping, banking and dying.\n` +
    `Every enchant, at every level, costs *${solars(ENCHANT_SOLARS)}* plus its materials.\n\n` +
    bookLine + `\n` +
    `*Your enchanted gear*\n${lines.join('\n')}\n\n` +
    `*At the table*\n` +
    `  *${p}enchant <item>* — its enchants and what the next level costs\n` +
    `  *${p}enchant <item> <enchant>* — pay the bill, apply it\n` +
    `  *${p}enchant grind <item>* — strip every enchant, reclaim ${fmtPct(GRIND_PCT)}\n` +
    `  *${p}enchant list* — everything the table can do\n` +
    `  *${p}enchant buy* — the Enchanting Book, ${solars(ENCHANT_BOOK_SOLARS)}\n\n` +
    `_Materials come out of your bag — the Ender Chest doesn't count, pull them\n` +
    `out first with *${p}ender take <item>*._`
  )
}

/** One enchant's full write-up — what every level does and what each costs. */
function enchantDetailView(player, def) {
  const p = config.prefix
  const lines = [
    `${def.icon} *${def.name.toUpperCase()}* · _${slotList(def)} · up to ${roman(def.maxLevel)}_`,
    DIVIDER,
    def.blurb,
    '',
  ]
  for (let lvl = 1; lvl <= def.maxLevel; lvl++) {
    lines.push(`*${roman(lvl)}* — ${levelText(def.id, lvl)}`)
    lines.push(`    Cost: ${costText(nextLevelCost(def.id, lvl))}`)
  }
  lines.push('')
  lines.push(`_Apply it with_ *${p}enchant <item> ${def.id}*`)
  if (def.id === 'mending') {
    lines.push(`_Mending tops a piece up while it sits below its line, spends from a pool` +
      ` that refills at midnight, and can even save a piece from the hit that would break it._`)
  }
  return lines.join('\n')
}

function itemPanelView(player, hit) {
  const p = config.prefix
  const { item, itemId, slot } = hit
  const owned = enchantsFor(player, itemId)
  const has = Object.keys(owned).length > 0

  const equippedHere = (player.equipped ?? {})[slot] === itemId
  const dur = equippedHere ? durabilityReadout(player).find((d) => d.slot === slot) : null

  const lines = [
    `🔮 *ENCHANTING TABLE*`,
    `${rarityStars(item.rarity)} *${item.name}*`,
    `${SLOT_EMOJI[slot] ?? '🔹'} ${slotText(item)}` +
      (dur ? ` · *${dur.current}/${dur.max}* durability` : '') +
      (equippedHere ? ' · ⚡ equipped' : ' · in your bag'),
    DIVIDER,
  ]

  if (has) {
    lines.push(`*On it now*`)
    for (const def of ENCHANTS) {
      const lvl = owned[def.id]
      if (!lvl) continue
      const pool = def.id === 'mending' ? mendingConfig(player, itemId) : null
      lines.push(`  ${def.icon} *${def.name} ${roman(lvl)}* — ${levelText(def.id, lvl)}`)
      if (pool) lines.push(`     🩹 ${pool.used}/${pool.daily} repaired today · refills at midnight`)
    }
  } else {
    lines.push(`_No enchantments on it yet._`)
  }

  lines.push(DIVIDER)
  const options = ENCHANTS.filter((def) => slotCanHold(def.id, slot))
  if (!options.length) {
    lines.push(`_Nothing at the table fits a ${slotText(item).toLowerCase()}._`)
    return lines.join('\n')
  }
  if (!hasEnchantingBook(player)) {
    lines.push(`🔒 *No Enchanting Book yet* — ${solars(ENCHANT_BOOK_SOLARS)} _(${p}shop buy enchanting book)_\n`)
  }

  lines.push(`*Available for this ${slotText(item).toLowerCase()}*`)
  for (const def of options) {
    const lvl = owned[def.id] ?? 0
    if (lvl >= def.maxLevel) {
      lines.push(`  ✅ ${def.icon} *${def.name} ${roman(lvl)}* — maxed`)
      continue
    }
    const next = lvl + 1
    const cost = nextLevelCost(def.id, next)
    const missing = missingFor(player, cost)
    lines.push(`  ${def.icon} *${def.name} ${roman(next)}* — ${levelText(def.id, next)}`)
    lines.push(`     Cost: ${costText(cost)}`)
    lines.push(missing.length
      ? `     ❌ Missing: ${missing.join(', ')}`
      : `     ✅ Ready — *${p}enchant ${item.id} ${def.id}*`)
  }
  return lines.join('\n')
}

/* ───────────────────────────── cost handling ────────────────────────────── */

/**
 * consumeCost(inv, wallet, cost) → true when it was paid. Mutates in place.
 * Materials are pulled from the END of the bag, the same direction craft.js
 * consumes them, so a stack behaves identically no matter which command spends
 * it.
 */
function consumeCost(inv, wallet, cost) {
  for (const { itemId, qty } of cost.items ?? []) {
    let remaining = qty
    for (let i = inv.length - 1; i >= 0 && remaining > 0; i--) {
      if (inv[i] === itemId) { inv.splice(i, 1); remaining-- }
    }
    if (remaining > 0) return false
  }
  wallet.solars = (wallet.solars ?? 0) - cost.solars
  return true
}

/* ──────────────────────────────── handlers ──────────────────────────────── */

async function handleApply(ctx, hit, def, requestedLevel) {
  const p = config.prefix
  const { item, itemId, slot } = hit
  const player = ctx.player

  // The book first: it is the prerequisite for the whole action, so a player
  // without one gets the price and the two ways to buy it rather than a
  // downstream complaint about slots or materials.
  if (!hasEnchantingBook(player)) return ctx.reply(lockedView(p))

  if (!slotCanHold(def.id, slot)) {
    return ctx.reply(
      `❌ *${def.name}* only fits *${slotList(def)}* — not a ${slotText(item).toLowerCase()}.\n` +
      `_Slots it can be applied to: ${enchantSlots(def.id).map((s) => SLOT_LABEL[s] ?? s).join(', ')}._`,
    )
  }

  const current = enchantLevel(player, itemId, def.id)
  if (current >= def.maxLevel) {
    return ctx.reply(`✅ *${item.name}* already carries *${def.name} ${roman(current)}* — that is maxed.`)
  }
  const next = current + 1
  const target = requestedLevel ?? next
  if (target > next) {
    return ctx.reply(
      `❌ Enchantments are applied one level at a time.\n` +
      `*${item.name}* is at *${def.name} ${roman(current)}* — the next step is *${roman(next)}*.\n` +
      `_Try:_ *${p}enchant ${itemId} ${def.id}*`,
    )
  }
  if (target < next) {
    return ctx.reply(
      `❌ *${item.name}* is already at *${def.name} ${roman(current)}* — ` +
      `*${roman(target)}* is behind it.\n_Enchantments only ever go up. Nothing was charged._`,
    )
  }

  const cost = nextLevelCost(def.id, next)
  if (!cost) return ctx.reply(`❌ The table has no price listed for *${def.name} ${roman(next)}*. Tell an admin.`)

  const missing = missingFor(player, cost)
  if (missing.length) {
    return ctx.reply(
      `❌ *Can't afford ${def.name} ${roman(next)}* on *${item.name}* — missing:\n` +
      missing.map((m) => `  • ${m}`).join('\n') +
      `\n\n_Cost: ${costText(cost)}_\n` +
      `_Materials are spent from your bag — pull them out of the Ender Chest with *${p}ender take <item>*._`,
    )
  }

  let raceAborted = null
  let applied = false
  let remainingSolars = null

  await updatePlayer(ctx.db, ctx.from, (fresh) => {
    if (!isOwned(fresh, itemId)) { raceAborted = 'you no longer own that item'; return }
    if (enchantLevel(fresh, itemId, def.id) !== current) { raceAborted = 'its level changed'; return }
    const freshCost = nextLevelCost(def.id, next)
    const freshMissing = missingFor(fresh, freshCost)
    if (freshMissing.length) { raceAborted = `missing ${freshMissing[0]}`; return }
    const inv = fresh.inventory ?? []
    fresh.wallet = fresh.wallet ?? {}
    if (!consumeCost(inv, fresh.wallet, freshCost)) { raceAborted = 'materials changed'; return }
    fresh.inventory = inv
    recordSink(ctx.db, 'enchant', { solars: freshCost.solars ?? 0, gems: freshCost.gems ?? 0 })
    applied = setEnchant(fresh, itemId, def.id, next)
    remainingSolars = fresh.wallet.solars
  })

  if (raceAborted) {
    return ctx.reply(`❌ Enchanting failed — ${raceAborted}. Nothing was charged. Try again.`)
  }
  if (!applied) {
    return ctx.reply(`❌ Enchanting failed — nothing changed. Try again in a moment.`)
  }

  return ctx.reply(
    `🔮 *ENCHANTED!* ✨\n${DIVIDER}\n` +
    `${def.icon} *${item.name}* → *${def.name} ${roman(next)}*\n` +
    `   ${levelText(def.id, next)}\n\n` +
    `_Paid: ${costText(cost)}_\n` +
    `_Wallet: ${solars(remainingSolars ?? (player.wallet?.solars ?? 0))}_\n\n` +
    `${def.id === 'mending'
      ? `🩹 *Mending* lives on the piece from now on — wear it down and it patches itself, up to its daily pool, and it will even catch the hit that would break it.\n`
      : ''}` +
    `_See it any time: *${p}enchant ${itemId}*_`,
  )
}

async function handleGrind(ctx, query) {
  const p = config.prefix
  const player = ctx.player
  const found = findOwned(player, query)

  if (found.error) {
    if (found.error === 'none') return ctx.reply(`❌ You are carrying no gear that can hold an enchant.`)
    if (found.error === 'ambiguous') {
      return ctx.reply(
        `❌ Which item?\n` + found.matches.map((m) => `  • ${m.item.name}`).join('\n') +
        `\n_Try:_ *${p}enchant grind <item>*`,
      )
    }
    return ctx.reply(`❌ You don't have *${found.query ?? query}*.`)
  }

  const { item, itemId } = found.hit
  const owned = enchantsFor(player, itemId)
  if (!Object.keys(owned).length) {
    return ctx.reply(`❌ *${item.name}* has no enchantments to grind off.`)
  }

  const refund = grindRefund(player, itemId, GRIND_PCT)
  const refundTotal = refund.items.reduce((n, i) => n + i.qty, 0)
  if (!hasInventoryRoom(player, refundTotal)) {
    return ctx.reply(
      `❌ Your bag needs ${refundTotal} free slot${refundTotal === 1 ? '' : 's'} for the reclaimed materials ` +
      `before the grindstone can work.\n${inventoryFullMessage(player)}`,
    )
  }

  const stripped = Object.entries(owned)
    .map(([id, lvl]) => levelName(id, lvl)).join(' · ')
  let raceAborted = null

  await updatePlayer(ctx.db, ctx.from, (fresh) => {
    if (!isOwned(fresh, itemId)) { raceAborted = 'you no longer own that item'; return }
    if (!Object.keys(enchantsFor(fresh, itemId)).length) { raceAborted = 'its enchantments are already gone'; return }
    const freshRefund = grindRefund(fresh, itemId, GRIND_PCT)
    const freshTotal = freshRefund.items.reduce((n, i) => n + i.qty, 0)
    if (!hasInventoryRoom(fresh, freshTotal)) { raceAborted = 'your bag is full'; return }
    clearEnchants(fresh, itemId)
    fresh.wallet = fresh.wallet ?? {}
    fresh.wallet.solars = (fresh.wallet.solars ?? 0) + freshRefund.solars
    // A ground item's Mending pool goes with its enchants — otherwise a
    // re-enchanted piece would inherit yesterday's spent budget.
    if (fresh.mending) delete fresh.mending[itemId]
    fresh.inventory = [...(fresh.inventory ?? []), ...freshRefund.items.flatMap(({ itemId: matId, qty }) => Array(qty).fill(matId))]
  })

  if (raceAborted) return ctx.reply(`❌ Grinding failed — ${raceAborted}. Try again.`)

  const refundText = refund.items.length
    ? refund.items.map(({ itemId: matId, qty }) => `${qty}× ${itemMap[matId]?.name ?? matId}`).join(', ')
    : 'nothing usable'
  return ctx.reply(
    `⚙️ *GROUND DOWN* ✨\n${DIVIDER}\n` +
    `*${item.name}* — removed: ${stripped}\n\n` +
    `♻️ Reclaimed ${fmtPct(GRIND_PCT)} of what it took: ${refundText}` +
    (refund.solars ? `, ${solars(refund.solars)}` : '') + `\n` +
    `_The piece is plain steel again — re-enchant it any time._`,
  )
}

/* ───────────────────────────────── parsing ──────────────────────────────── */

/** "2" | "ii" → 2, anything else → null. */
function parseLevel(word) {
  if (!word) return null
  const w = String(word).toLowerCase()
  if (/^\d+$/.test(w)) return parseInt(w, 10)
  if (LEVEL_WORDS[w]) return LEVEL_WORDS[w]
  return null
}

/* ────────────────────────────── plugin export ───────────────────────────── */

export default {
  name:           'enchant',
  aliases:        ['enchanting', 'enchantments', 'ench'],
  category:       'town',
  requiresPlayer: true,
  description:    `${config.prefix}enchant — the Enchanting Table (book ☀️${ENCHANT_BOOK_SOLARS.toLocaleString()}, then ☀️${ENCHANT_SOLARS.toLocaleString()} per enchant)`,

  async run(ctx) {
    const { player, args } = ctx
    const p = config.prefix

    const wrongWorld = kingdomDoorRefusal(player, {
      emoji: '✨', title: '*The enchant table is Astra Kingdom life.*',
      instead: { cmd: 'sectshop', label: 'the mountain quartermaster supplies cultivators' },
    })
    if (wrongWorld) return ctx.reply(wrongWorld)

    if (!args.length) return ctx.reply(homeView(ctx))
    if (['list', 'table', 'all'].includes(args[0].toLowerCase())) {
      return ctx.reply(catalogLines().join('\n'))
    }
    if (['help', '?'].includes(args[0].toLowerCase())) return ctx.reply(homeView(ctx))

    // ── the Enchanting Book (`.enchant buy`, and `.shop buy enchanting book`) ─
    if (['buy', 'unlock', 'purchase', 'book'].includes(args[0].toLowerCase())) {
      return buyEnchantingBook(ctx)
    }

    if (player.inBattle) {
      return ctx.reply(`⚔️ You can't work the table mid-battle!`)
    }
    const noServices = noServicesRefusal(player)
    if (noServices) return ctx.reply(noServices)

    // ── grindstone ─────────────────────────────────────────────────────────
    if (['grind', 'grindstone', 'strip', 'remove', 'disenchant'].includes(args[0].toLowerCase())) {
      return handleGrind(ctx, args.slice(1).join(' '))
    }

    // ── one word that names an enchant → its write-up (never a purchase) ───
    if (args.length === 1 && findEnchant(args[0])) {
      return ctx.reply(enchantDetailView(player, findEnchant(args[0])))
    }

    // ── "<item> <enchant> [level]" ─────────────────────────────────────────
    // An item name can be several words and so can an enchant's aliases, so
    // the enchant is read off the END: peel a trailing level word first
    // ("3", "ii"), then the word before it is the enchant. Everything left is
    // the item query. A trailing level with no enchant after it belongs to the
    // item name instead, so ".enchant iron sword 3" is still a panel request.
    const words = [...args]
    let requestedLevel = parseLevel(words[words.length - 1])
    // A trailing level only counts when there is still an item AND an enchant
    // word in front of it; on its own ("iron sword 3") it is just part of the
    // item query and the panel answers instead.
    const levelIsUsable = requestedLevel != null && words.length >= 3
    const enchantWord = levelIsUsable ? words[words.length - 2] : words[words.length - 1]
    const def = levelIsUsable || (requestedLevel == null && words.length > 1)
      ? findEnchant(enchantWord)
      : null
    const itemQuery = def
      ? (levelIsUsable ? words.slice(0, -2) : words.slice(0, -1)).join(' ')
      : (requestedLevel != null && words.length > 1 ? words.slice(0, -1).join(' ') : words.join(' '))
    if (!def) {
      // ".enchant sharpness 3" — an enchant plus a level, but no item. Show the
      // write-up rather than looking for an item called "sharpness 3".
      const maybeEnchant = requestedLevel != null && words.length === 2 ? findEnchant(words[0]) : null
      if (maybeEnchant) return ctx.reply(enchantDetailView(player, maybeEnchant))
      requestedLevel = null
    }

    const found = findOwned(player, itemQuery)
    if (found.error) {
      if (found.error === 'none') {
        return ctx.reply(
          `❌ You are carrying no gear that can hold an enchant.\n` +
          `_Only things that wear out can be enchanted — buy or craft a weapon, armor or pickaxe first._`,
        )
      }
      if (found.error === 'ambiguous') {
        return ctx.reply(
          `❌ Which item?\n` + found.matches.map((m) => `  • ${m.item.name}`).join('\n') +
          `\n_Try:_ *${p}enchant <item>${def ? ` ${def.id}` : ''}* — or *${p}enchant* to see the table.`,
        )
      }
      if (found.error === 'not-enchantable') {
        return ctx.reply(
          `❌ *${found.item.name}* never wears out — there is nothing for an enchant to hold on to.\n` +
          `_Only weapons, armor and tools wear down enough to carry one._`,
        )
      }
      return ctx.reply(
        `❌ You don't have *${found.query ?? itemQuery}*.\n` +
        `_Buy or craft it first — *${p}shop* / *${p}craft* — then enchant it here._`,
      )
    }

    // No item named → show the panel (never a silent purchase).
    if (!def || !itemQuery.trim()) {
      const body = itemPanelView(player, found.hit)
      if (def && !itemQuery.trim()) {
        return ctx.reply(
          body + `\n\n_To buy it:_ *${p}enchant ${found.hit.itemId} ${def.id}*`,
        )
      }
      return ctx.reply(body)
    }

    return handleApply(ctx, found.hit, def, requestedLevel)
  },
}
