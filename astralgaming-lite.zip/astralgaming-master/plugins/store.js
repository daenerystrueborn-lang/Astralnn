/**
 * store.js — the PFP & Banner Store.
 *
 * Gem-priced profile pictures and banners. Chat front end for
 * lib/cosmetic-store.js, which owns the catalog, the prices and the single
 * purchase mutator; the website's /api/store and the shelf render read the same
 * module, so the three can never disagree about a price or an owned chip.
 *
 *   .store                     — the shelf (page 1)
 *   .store 2 | .store season   — page by number, line id, or label
 *   .store pfps | banners      — one collection
 *   .store info <id>           — full card: art, price, how to equip it
 *   .store buy <id|name>       — spend Gems, unlock it
 *   .store equip <id|name>     — buy-time shortcut to the pick command
 *   .store owned               — everything you own, store or not
 *
 * Equipping is deliberately NOT reimplemented here: buying unlocks, and
 * `.pickpfp` / `.pickbanner` wear it. `store equip` exists only because "I just
 * bought it, wear it" is the thought everyone has next.
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { fmtGems, roundGems } from '../lib/format.js'
import { recordSink } from '../lib/economy-ledger.js'
import { renderCosmeticStorePage, renderCosmeticStoreItem } from '../lib/cosmetic-store-render.mjs'
import {
  buyStoreItem,
  collectionLabel,
  cosmeticStoreEntry,
  describeStoreEntry,
  listStoreItems,
  ownedCollection,
  storeLines,
  storeStatus,
} from '../lib/cosmetic-store.js'
import { hasProfileCosmetic, selectProfileCosmetic } from '../lib/profile-cosmetics.js'
import { renderAnimatedProfileCard } from '../lib/profile-card-render.mjs'
import { runStoreAdmin, isStoreOwner } from '../lib/cosmetic-store-admin.js'
import { readProfilePictureBuffer, findImageMessage } from '../lib/pfp.js'
import { uploadToImgbb } from '../lib/imgbb.js'
import {
  PCS, bestPc, buyPc, canStream, equipPc, equippedPc, ownedPcs, ownsPc,
  pcById, pcLimitLabel, pcPriceLabel, pcRiskLabel, pcsByPrice,
} from '../lib/gaming-pcs.js'
import { renderRigStorePage, renderRigCard } from '../lib/gaming-pc-render.mjs'

const PAGE_SIZE = 5

const RARITY_EMOJI = {
  common: '⚪', uncommon: '🟢', rare: '🔵', epic: '🟣', legendary: '🟡', mythical: '🔴',
}

/** Loose match for a typed name — '.store buy dokkaebi' and the full title both work. */
function findByTypedName(query, items) {
  const q = String(query ?? '').trim().toLowerCase()
  if (!q) return null
  const underscored = q.replace(/\s+/g, '_')
  return items.find((item) => item.id.toLowerCase() === q)
    ?? items.find((item) => item.id.toLowerCase() === underscored)
    ?? items.find((item) => item.id.toLowerCase() === `league_${underscored}`)
    ?? items.find((item) => item.name.toLowerCase() === q)
    ?? items.find((item) => item.name.toLowerCase().includes(q))
    ?? items.find((item) => item.id.toLowerCase().includes(underscored))
    ?? null
}

function collectionEmoji(collection) {
  if (collection === 'banner') return '🌄'
  if (collection === 'frame') return '💠'
  if (collection === 'effect') return '✨'
  return '🖼️'
}

function kindForCollection(collection) {
  if (collection === 'banner') return 'profileBanner'
  if (collection === 'frame') return 'profileFrame'
  if (collection === 'effect') return 'profileEffect'
  return 'profilePfp'
}

/** Which shelf a typed page argument means: '2', 'season', 'league', 'pfps', 'effects', 'frames'. */
function resolveShelf(raw) {
  const q = String(raw ?? '').trim().toLowerCase()
  if (!q) return { page: 1 }
  if (q === 'pfp' || q === 'pfps' || q === 'pictures' || q === 'picture') return { collection: 'pfp' }
  if (q === 'banner' || q === 'banners') return { collection: 'banner' }
  if (q === 'frame' || q === 'frames') return { collection: 'frame' }
  if (q === 'effect' || q === 'effects' || q === 'gif' || q === 'gifs' || q === 'fx') return { collection: 'effect' }
  const lines = storeLines()
  const byLine = lines.find((line) => line.id === q)
    ?? lines.find((line) => line.label.toLowerCase() === q)
    ?? lines.find((line) => q.length > 2 && line.label.toLowerCase().includes(q))
  if (byLine) return { line: byLine.id }
  const asNumber = Number(q)
  if (Number.isFinite(asNumber) && asNumber >= 1) return { page: Math.floor(asNumber) }
  return { page: 1 }
}

function itemsFor({ line = 'all', collection = null, player = null } = {}) {
  return listStoreItems({ line, collection, player })
}

function shelfCaption({ items, page, pageCount, player, line, collection, prefix }) {
  const gems = roundGems(player?.wallet?.gems ?? 0)
  const lines = storeLines()
  const lineObj = lines.find((entry) => entry.id === line)
  const heading = collection
    ? collectionLabel(collection).many
    : line === 'all' ? 'All Collections' : lineObj?.label ?? 'Store'
  const out = [
    `✨ *COSMETICS & GIF EFFECTS STORE*${pageCount > 1 ? ` — page ${page}/${pageCount}` : ''}`,
    `✦ *${heading}* · your balance: 💎 *${fmtGems(gems)}* Gems`,
  ]
  if (!items.length) {
    out.push('', '_Nothing on this shelf yet._')
  }
  for (const item of items) {
    const tag = item.owned ? ' ✅ *OWNED*'
      : item.locked === 'pass' ? ' 🔒 _pass exclusive_'
        : item.affordable ? '' : ' 💤 _can\'t afford_'
    out.push(
      `${RARITY_EMOJI[item.rarity] ?? '⚪'} *${item.name}* — ${collectionEmoji(item.collection)} ${item.collectionLabel}${tag}`,
      `   💎 ${fmtGems(item.price)} · \`${item.id}\``,
    )
    if (item.owned) out.push(`   ⌁ wear it: _${prefix}${item.equipCommand.slice(1)}_`)
  }
  out.push(
    '',
    `🛒 *${prefix}store buy <id>* · 📖 *${prefix}store info <id>*`,
    pageCount > 1 ? `📄 *${prefix}store ${collection ? `${collection}s ` : ''}${page + 1 > pageCount ? 1 : page + 1}* — next shelf` : '',
    collection
      ? `🗂️ *${prefix}store* — all collections`
      : `🗂️ *${prefix}store effects* · *${prefix}store frames* · *${prefix}store pfps* · *${prefix}store banners*`,
    `✅ *${prefix}store owned* — what you already have`,
  )
  return out.filter(Boolean).join('\n')
}

/**
 * The storefront while the owner is still stocking it.
 *
 * Deliberately not an empty shelf: an empty shelf reads as a bug ("the shop is
 * broken"). This says what it is, that nothing is being sold yet, and that
 * nothing a player owns has changed — `.cosmetics` / `.pickpfp` still work, so
 * pass art and box drops stay wearable while the shop is shut.
 */
function comingSoonScreen(ctx) {
  const prefix = config.prefix
  const status = storeStatus()
  const when = status.openAt ? `\n🗓️ _Aiming to open: ${status.openAt}_` : ''
  return ctx.reply([
    '🖼️ *PFP & BANNER STORE*',
    '',
    '🚧 *COMING SOON*',
    '',
    status.note ? `_${status.note}_` : '_The shelves are being stocked. Nothing is for sale yet._',
    when,
    '',
    `✅ Everything you already own still works:`,
    `⌁ *${prefix}cosmetics* — your pass art, frames and badges`,
    `⌁ *${prefix}pickpfp* / *${prefix}pickbanner* — equip what you have`,
    '',
    '_Your Gems are untouched._',
    isStoreOwner(ctx.from) ? `\n👑 Owner: *${prefix}store admin* to stock the shelves, then *${prefix}store admin open*.` : '',
  ].filter(Boolean).join('\n'))
}

async function sendShelf(ctx, { line = 'all', collection = null, page = 1 } = {}) {
  const prefix = config.prefix
  const items = itemsFor({ line, collection, player: ctx.player })
  const pageCount = Math.max(1, Math.ceil(items.length / PAGE_SIZE))
  const pageIndex = Math.min(Math.max(1, page), pageCount)
  const slice = items.slice((pageIndex - 1) * PAGE_SIZE, pageIndex * PAGE_SIZE)
  const caption = shelfCaption({ items: slice, page: pageIndex, pageCount, player: ctx.player, line, collection, prefix })

  try {
    const buf = await renderCosmeticStorePage({
      items: slice,
      page: pageIndex,
      pageCount,
      gems: roundGems(ctx.player?.wallet?.gems ?? 0),
      collection,
      line,
      heading: collection
        ? collectionLabel(collection).many
        : line === 'all' ? 'All Collections' : storeLines().find((entry) => entry.id === line)?.label,
      prefix,
    })
    return ctx.replyImage(buf, caption)
  } catch {
    // Render trouble is cosmetic; the shelf still has to be browsable.
    return ctx.reply(caption)
  }
}

async function showInfo(ctx, query) {
  const prefix = config.prefix
  const entry = findByTypedName(query, itemsFor())
  if (!entry) {
    return ctx.reply(
      `❌ No store item matches *${query}*.\n` +
      `Browse with *${prefix}store* — ids are printed under every name.`,
    )
  }
  const item = describeStoreEntry(entry, ctx.player)
  const label = collectionLabel(item.collection)
  const owned = hasProfileCosmetic(ctx.player, kindForCollection(item.collection), item.id)
  const lines = [
    `${collectionEmoji(item.collection)} *${item.name.toUpperCase()}*`,
    `_${label.one} · ${item.rarity}_`,
    '────────────────────',
    item.note ? `${item.note}` : '',
    item.track ? `🎟️ Season 2 pass track: *${item.track}*${item.tier ? ` · tier ${item.tier}` : ''}` : '',
    `💎 Price: *${fmtGems(item.price)}* Gems${owned ? ' · *already owned*' : ''}`,
    owned
      ? `⌁ Wear it: *${prefix}${item.equipCommand.slice(1)}*`
      : item.purchasable === false
        ? `🔒 ${item.lockedMessage}`
        : `🛒 *${prefix}store buy ${item.id}*`,
    `🆔 \`${item.id}\``,
  ].filter(Boolean)
  const caption = lines.join('\n')

  if ((item.collection === 'frame' || item.collection === 'effect') && item.style && typeof ctx.replyGif === 'function') {
    try {
      const previewGif = await renderAnimatedProfileCard(ctx.player, {
        pvpOnly: true,
        bannerOnly: false,
        frameStyle: item.collection === 'frame' ? item.style : null,
        effectStyle: item.collection === 'effect' ? item.style : null,
      })
      return await ctx.replyGif(previewGif, caption)
    } catch { /* fall through to static preview */ }
  }

  try {
    const buf = await renderCosmeticStoreItem({ item, owned, prefix })
    return ctx.replyImage(buf, caption)
  } catch {
    if (item.image) {
      try { return await ctx.replyImage(item.image, caption) } catch { /* fall through */ }
    }
    return ctx.reply(caption)
  }
}

async function buy(ctx, query) {
  const prefix = config.prefix
  const entry = findByTypedName(query, itemsFor())
  if (!entry) {
    return ctx.reply(
      `❌ No store item matches *${query}*.\n` +
      `Browse with *${prefix}store* first — the id is printed under every name.`,
    )
  }

  let outcome = null
  await updatePlayer(ctx.db, ctx.from, (player) => {
    outcome = buyStoreItem(player, entry.id)
  }, { critical: true })

  if (!outcome?.ok) {
    if (outcome?.code === 'closed') {
      return ctx.reply(
        `🚧 *The Cosmetics & GIF Store is coming soon.*\n` +
        `_Nothing was charged — your Gems are untouched._`,
      )
    }
    if (outcome?.code === 'owned') {
      return ctx.reply(
        `✅ You already own *${entry.name}*.\n` +
        `⌁ Wear it with *${prefix}${collectionLabel(entry.collection).pick.slice(1)} ${entry.id}*.`,
      )
    }
    if (outcome?.code === 'pass') {
      return ctx.reply(`🔒 *${entry.name}* is a Season Pass exclusive — it's earned from the pass, not sold.`)
    }
    if (outcome?.code === 'gems') {
      const short = roundGems(outcome.price - outcome.gems)
      return ctx.reply(
        `❌ *Not enough Gems!*\n` +
        `*${entry.name}* costs 💎 *${fmtGems(outcome.price)}*.\n` +
        `You have 💎 *${fmtGems(outcome.gems)}* — you need 💎 *${fmtGems(short)}* more.\n\n` +
        `_Gems come from season offers (${prefix}season offer) and admin grants._`,
      )
    }
    if (outcome?.code === 'unknown') return ctx.reply(`❌ That item is no longer in the store.`)
    return ctx.reply(`❌ That purchase could not be completed. Nothing was charged.`)
  }

  // Ledger: gems leave the economy here, same as every other gem sink.
  recordSink(ctx.db, 'cosmetic_store', { gems: outcome.price })

  const label = collectionLabel(entry.collection)
  return ctx.reply(
    `✅ *${entry.name}* unlocked!\n` +
    `${collectionEmoji(entry.collection)} ${label.one} · 💎 −${fmtGems(outcome.price)} · balance 💎 *${fmtGems(outcome.gemsLeft)}*\n\n` +
    `⌁ Wear it now: *${prefix}${label.pick.slice(1)} ${entry.id}* (or *${prefix}store equip ${entry.id}*)\n` +
    `_It shows live on_ *${prefix}me* _and on the website once equipped._`,
  )
}

async function equip(ctx, query) {
  const prefix = config.prefix
  const entry = findByTypedName(query, itemsFor())
  if (!entry) return ctx.reply(`❌ No store item matches *${query}*.`)
  const kind = kindForCollection(entry.collection)
  if (!hasProfileCosmetic(ctx.player, kind, entry.id)) {
    const item = describeStoreEntry(entry, ctx.player)
    return ctx.reply(
      `🔒 You don't own *${entry.name}* yet.\n` +
      `💎 It costs *${fmtGems(item.price)}* Gems — *${prefix}store buy ${entry.id}*.`,
    )
  }
  const selectKind = entry.collection === 'banner' ? 'banner'
    : entry.collection === 'frame' ? 'frame'
      : entry.collection === 'effect' ? 'effect'
        : 'pfp'
  let res = null
  await updatePlayer(ctx.db, ctx.from, (player) => {
    res = selectProfileCosmetic(player, selectKind, entry.id)
  })
  const label = collectionLabel(entry.collection)
  if (!res?.ok) return ctx.reply(`❌ Could not equip *${entry.name}*.`)
  return ctx.reply(
    `✅ *${entry.name}* equipped as your *${label.one}*! Check it live with *${prefix}me*.`,
  )
}

/* ────────────────────────────── the RIG STORE ───────────────────────────── */

/**
 * The gaming PCs ASTRATOK needs, appended to the same store.
 *
 * `.store pcs` is its own shelf rather than extra rows on the PFP pages: this is
 * not a cosmetic, it is a machine you need to go live, and burying it behind
 * five profile pictures would mean a player never finds out why `.stream start`
 * refuses them.
 */
const RIG_PAGE_SIZE = 4

/** The catalogue, merged with what this player owns and what is in the shop. */
function rigItems(player) {
  const owned = ownedPcs(player)
  const byId = new Map(owned.map(p => [p.id, p]))
  return pcsByPrice().map(pc => {
    const mine = byId.get(pc.id)
    return {
      ...pc,
      owned: !!mine,
      broken: !!mine?.broken,
      hoursLeft: mine?.hoursLeft ?? 0,
    }
  })
}

function rigCaption({ items, page, pageCount, player, prefix }) {
  const solars = Math.floor(player?.wallet?.solars ?? 0)
  const gems = roundGems(player?.wallet?.gems ?? 0)
  const ready = canStream(player)
  const out = [
    `🖥️ *RIG STORE*${pageCount > 1 ? ` — page ${page}/${pageCount}` : ''}`,
    `✦ Gaming PCs and streaming gear · ☀️ *${fmtSolars(solars)}* · 💎 *${fmtGems(gems)}*`,
  ]

  // The first line a player needs is not "here are the parts", it is "what am
  // I streaming on right now" — that is the sentence that stops the "why can't
  // I start" loop.
  if (!ready.ok && ready.code === 'none') {
    out.push('', '⚠️ *You have no rig.* _ASTRATOK will refuse to start until you own one._')
  } else if (!ready.ok && ready.code === 'broken') {
    out.push('', `🔧 *${ready.pc?.name ?? 'Your rig'} is in the shop* for another *${ready.hoursLeft}h*.`)
    out.push('_Buy a second machine and you can stream on that while this one is repaired._')
  } else if (ready.ok) {
    out.push(`✅ *Streaming on ${ready.pc.name}* · ${pcLimitLabel(ready.pc)} per stream`)
  }

  for (const pc of items) {
    const tag = pc.owned
      ? (pc.broken ? ` 🔧 *IN THE SHOP ${pc.hoursLeft}h*` : ' ✅ *OWNED*')
      : ''
    out.push(
      `${pc.best ? '👑' : '🖥️'} *${pc.name}* — ${pcPriceLabel(pc)}${tag}`,
      `   ⏱ ${pcLimitLabel(pc)} per stream · ${pcRiskLabel(pc)}${pc.cooldownHours ? ` · ${Math.round(pc.cooldownHours / 24)}d repair` : ''}`,
      `   \`${pc.id}\``,
    )
  }
  out.push(
    '',
    `🛒 *${prefix}store buy <id>* · 📖 *${prefix}store info <id>*`,
    pageCount > 1 ? `📄 *${prefix}store pcs ${page + 1 > pageCount ? 1 : page + 1}* — next shelf` : '',
    `🔌 *${prefix}stream pc <id>* — plug one in`,
    `🎨 *${prefix}store* — the PFP & banner shelves`,
  )
  return out.filter(Boolean).join('\n')
}

/** Solars with separators, because a rig price is never abbreviated. */
function fmtSolars(value) {
  return Math.round(Number(value) || 0).toLocaleString('en-US')
}

async function sendRigShelf(ctx, { page = 1 } = {}) {
  const prefix = config.prefix
  const items = rigItems(ctx.player)
  const pageCount = Math.max(1, Math.ceil(items.length / RIG_PAGE_SIZE))
  const pageIndex = Math.min(Math.max(1, page), pageCount)
  const slice = items.slice((pageIndex - 1) * RIG_PAGE_SIZE, pageIndex * RIG_PAGE_SIZE)
  const caption = rigCaption({ items: slice, page: pageIndex, pageCount, player: ctx.player, prefix })

  try {
    const buf = await renderRigStorePage({
      items: slice,
      page: pageIndex,
      pageCount,
      solars: Math.floor(ctx.player?.wallet?.solars ?? 0),
      gems: roundGems(ctx.player?.wallet?.gems ?? 0),
      prefix,
    })
    return ctx.replyImage(buf, caption)
  } catch {
    // Render trouble is cosmetic; the shelf still has to be browsable.
    return ctx.reply(caption)
  }
}

async function showRig(ctx, query) {
  const prefix = config.prefix
  const pc = pcById(query) ?? PCS.find(p => p.name.toLowerCase().includes(String(query ?? '').toLowerCase()))
  if (!pc) {
    return ctx.reply(`❌ No rig matches *${query}*.\nBrowse with *${prefix}store pcs* — ids are printed under every name.`)
  }
  const owned = ownedPcs(ctx.player).find(p => p.id === pc.id)
  const caption = [
    `🖥️ *${pc.name.toUpperCase()}*`,
    `_${pc.currency === 'gems' ? 'Premium gear' : 'Solars gear'} · ${pcLimitLabel(pc)} per stream_`,
    '────────────────────',
    pc.note ?? '',
    `⏱ One stream lasts: *${pcLimitLabel(pc)}*${pc.maxStreamHours ? '' : ' _(the machine sets no limit, the 2h stream clock still does)_'}`,
    `⚠️ Breakdowns: *${pcRiskLabel(pc)}*`,
    `🔧 Repair time: *${pc.cooldownHours ? `${Math.round(pc.cooldownHours / 24)} days` : 'none'}*`,
    '',
    `🧠 *CPU:* ${pc.spec.cpu}`,
    `🧮 *RAM:* ${pc.spec.ram} GB`,
    `🎮 *GPU:* ${pc.spec.gpu}`,
    `💾 *Storage:* ${pc.spec.storage}`,
    '',
    `💵 Price: *${pcPriceLabel(pc)}*`,
    owned
      ? (owned.broken
        ? `🔧 *In the shop* for another *${owned.hoursLeft}h*`
        : `✅ Owned — plug it in with *${prefix}stream pc ${pc.id}*`)
      : `🛒 *${prefix}store buy ${pc.id}*`,
    `🆔 \`${pc.id}\``,
  ].filter(Boolean).join('\n')

  try {
    const buf = await renderRigCard({
      pc,
      owned: !!owned,
      broken: !!owned?.broken,
      hoursLeft: owned?.hoursLeft ?? 0,
      prefix,
    })
    return ctx.replyImage(buf, caption)
  } catch {
    return ctx.reply(caption)
  }
}

/**
 * Buy a rig.
 *
 * The charge happens INSIDE buyPc, on the player object updatePlayer hands us:
 * one writer, one mutation, and if the save fails nothing was bought. The reply
 * is only sent after the write resolves, so "money gone, no rig" cannot happen.
 */
async function buyRig(ctx, query) {
  const prefix = config.prefix
  const pc = pcById(query) ?? PCS.find(p => p.name.toLowerCase().includes(String(query ?? '').toLowerCase()))
  if (!pc) {
    return ctx.reply(`❌ No rig matches *${query}*.\nBrowse with *${prefix}store pcs*.`)
  }

  let outcome = null
  await updatePlayer(ctx.db, ctx.from, (player) => {
    outcome = buyPc(player, pc.id)
  }, { critical: true })

  if (!outcome?.ok) {
    if (outcome?.code === 'owned') {
      return ctx.reply(`✅ You already own the *${pc.name}*.\n_Pretty sure it is in your collection already._`)
    }
    if (outcome?.code === 'gems') {
      const short = Math.max(0, outcome.price - outcome.gems)
      return ctx.reply(
        `❌ *Not enough Gems!*\n` +
        `*${pc.name}* costs 💎 *${fmtGems(outcome.price)}*.\n` +
        `You have 💎 *${fmtGems(outcome.gems)}* — you need 💎 *${fmtGems(short)}* more.\n\n` +
        `_The good rigs are the gem ones. Cheap machines are priced in solars._`,
      )
    }
    if (outcome?.code === 'solars') {
      const short = Math.max(0, outcome.price - outcome.solars)
      return ctx.reply(
        `❌ *Not enough Solars!*\n` +
        `*${pc.name}* costs ☀️ *${fmtSolars(outcome.price)}*.\n` +
        `You have ☀️ *${fmtSolars(outcome.solars)}* — you need ☀️ *${fmtSolars(short)}* more.\n\n` +
        `_Solars come from dungeons, fights and selling. The top rigs are cheaper in_ 💎 *${prefix}store pcs*`,
      )
    }
    return ctx.reply(`❌ That purchase could not be completed. Nothing was charged.`)
  }

  // Ledger: the currency leaves the economy here, same as every other sink.
  recordSink(ctx.db, 'rig_store', outcome.currency === 'gems'
    ? { gems: outcome.price }
    : { solars: outcome.price })

  return ctx.reply([
    `✅ *${pc.name}* is yours!`,
    `💵 Paid: *${pcPriceLabel(pc)}*`,
    '',
    `⏱ One stream lasts *${pcLimitLabel(pc)}*`,
    `⚠️ ${pcRiskLabel(pc)}`,
    '',
    `🔴 *${prefix}stream start* — go live on it`,
    `_Switch machines any time with_ *${prefix}stream pc <id>*`,
  ].join('\n'))
}

function ownedScreen(ctx) {
  const prefix = config.prefix
  const out = ['「 ✦ YOUR COSMETICS & GIF EFFECTS 」', '']
  const fieldFor = {
    pfp: 'profilePfpId',
    banner: 'profileBannerId',
    frame: 'profileFrameId',
    effect: 'profileEffectId',
  }
  for (const collection of ['pfp', 'banner', 'frame', 'effect']) {
    const label = collectionLabel(collection)
    const owned = ownedCollection(ctx.player, collection)
    const equipped = ctx.player?.[fieldFor[collection]]
    out.push(`*${label.many}* (${owned.length})`)
    if (!owned.length) out.push('  _None yet._')
    for (const item of owned) {
      const worn = equipped === item.id ? ' ✅ *equipped*' : ''
      out.push(`  ▫️ *${item.name}*${worn}`)
      out.push(`     ⌁ ${prefix}${label.pick.slice(1)} ${item.id}`)
    }
    out.push('')
  }
  out.push(
    `🛒 *${prefix}store* — buy PFPs, banners, frames & GIF effects`,
    `🎨 *${prefix}cosmetics* — all unlocked cosmetics & badges`,
  )
  return out.join('\n')
}

export default {
  name: 'store',
  aliases: ['pfpstore', 'bannerstore', 'cosmeticstore', 'skinsstore', 'gifstore'],
  category: 'account',
  requiresPlayer: true,
  description: 'Buy profile pictures, banners, Fluid Frames, and animated GIF effects with Gems',

  async run(context) {
    let ctx = context
    const prefix = config.prefix
    const args = ctx.args ?? []
    const sub = String(args[0] ?? '').toLowerCase()

    // ── owner stock management ───────────────────────────────────────────
    // `.store admin add <id> pfp <url>` — or reply to a photo with
    // `.store admin add <id> pfp` as the caption and the photo becomes the
    // stock. That is the whole point: the owner should never have to edit a
    // JSON file or redeploy to put their own art on the shelf.
    //
    // The photo path downloads the attachment and uploads it to ImgBB (the
    // same lib/pfp.js reader .setpfp uses, so it works on WhatsApp, Discord
    // and Telegram), because a WhatsApp media URL is encrypted and expires —
    // storing it would give players a tile that is broken within the hour.
    if (sub === 'admin') {
      const adminArgs = args.slice(1)
      const verb = String(adminArgs[0] ?? '').toLowerCase()
      // Only the verbs that can consume an image, only when the owner did NOT
      // already type a link, and only when a photo is actually attached. An
      // unconditional attempt was a real bug: every `.store admin …` command
      // (including `list` and `price`) tried to download and re-host media,
      // which both burned ImgBB calls and turned a harmless message with no
      // body into a spurious "couldn't re-host that photo" error.
      const takesImage = ['add', 'new', 'set'].includes(verb)
      const typedUrl = adminArgs.some((arg) => /^https?:\/\//i.test(String(arg ?? '')))
      const attached = takesImage && !typedUrl && isStoreOwner(ctx.from)
        && (typeof ctx.getAttachment === 'function' || !!findImageMessage(ctx.msg ?? {}))

      let uploadFailure = null
      if (attached) {
        try {
          const buffer = await readProfilePictureBuffer(ctx)
          if (buffer) {
            ctx = { ...ctx, mediaUrl: await uploadToImgbb(buffer, `store-${Date.now()}`) }
          }
        } catch (err) {
          // A failed upload must not be silent, or the owner thinks their photo
          // landed and gets "I need an image URL" instead.
          uploadFailure = err?.message ?? String(err)
        }
      }
      if (uploadFailure) {
        return ctx.reply(
          `⚠️ I couldn't re-host that photo: _${uploadFailure}_\n\n` +
          `Paste a direct link instead: *${prefix}store admin add <id> <pfp|banner> <url>*`,
        )
      }
      return ctx.reply(runStoreAdmin({ ...ctx, mediaUrl: ctx.mediaUrl }, adminArgs))
    }
    // ── the rig store ────────────────────────────────────────────────────
    // Handled BEFORE the coming-soon gate on purpose. The PFP and banner
    // shelves are shut until the owner stocks them, but ASTRATOK is live, and a
    // player who cannot open the rig store cannot stream either. Gating a
    // gameplay requirement behind a cosmetic launch date would break the game.
    const rigQuery = (sub === 'info' || sub === 'view' || sub === 'buy' || sub === 'purchase')
      ? args.slice(1).join(' ').trim()
      : ''
    if (sub === 'pcs' || sub === 'pc' || sub === 'rigs' || sub === 'rig' || sub === 'computers') {
      return sendRigShelf(ctx, { page: Number(args[1]) || 1 })
    }
    // `info <rig>` and `buy <rig>` also live above the gate. A rig id is
    // unambiguous — the two catalogues never share one — and the first version
    // of this routed only the SHELF above, so `.store buy scrap_box` answered
    // "the PFP & Banner Store is coming soon" about a machine ASTRATOK needs.
    if (rigQuery && pcById(rigQuery)) {
      if (sub === 'buy' || sub === 'purchase') return buyRig(ctx, rigQuery)
      return showRig(ctx, rigQuery)
    }

    // ── coming soon ──────────────────────────────────────────────────────
    // While the owner is stocking the shelves, every browse request gets the
    // teaser instead of an empty (or placeholder) gift shop. `help` and the
    // owner's `admin` panel stay reachable so the store can be worked on.
    const status = storeStatus()
    if (!status.open) {
      // A teardown of the shop is the right answer for browsing, but not for
      // someone trying to buy — they need to know the purchase did not happen.
      if (sub === 'buy' || sub === 'purchase') {
        return ctx.reply(
          '🚧 *The PFP & Banner Store is coming soon.*\n' +
          '_Nothing is for sale yet, and nothing was charged — your Gems are untouched._\n\n' +
          `⌁ *${prefix}cosmetics* — what you already own`,
        )
      }
      if (sub !== 'help' && sub !== 'admin') return comingSoonScreen(ctx)
    }

    if (!sub) return sendShelf(ctx, { line: 'all', page: 1 })

    if (sub === 'buy' || sub === 'purchase') {
      const query = args.slice(1).join(' ').trim()
      if (!query) return ctx.reply(`🛒 What do you want to buy?\n*${prefix}store* to browse.`)
      // A rig id buys a rig. Checked first because the two catalogues are
      // separate: falling through would answer "no store item matches" for
      // something that is very much for sale.
      if (pcById(query)) return buyRig(ctx, query)
      return buy(ctx, query)
    }
    if (sub === 'info' || sub === 'view') {
      const query = args.slice(1).join(' ').trim()
      if (!query) return ctx.reply(`📖 *${prefix}store info <id>* — try *${prefix}store* for ids.`)
      if (pcById(query)) return showRig(ctx, query)
      return showInfo(ctx, query)
    }
    if (sub === 'equip' || sub === 'wear') {
      const query = args.slice(1).join(' ').trim()
      if (!query) return ctx.reply(`⌁ *${prefix}store equip <id>*`)
      return equip(ctx, query)
    }
    if (sub === 'owned' || sub === 'mine' || sub === 'collection') return ctx.reply(ownedScreen(ctx))
    if (sub === 'help') {
      return ctx.reply([
        '✨ *COSMETICS & GIF EFFECTS STORE*',
        '',
        `⌁ *${prefix}store* — all shelves`,
        `⌁ *${prefix}store effects* / *${prefix}store frames* — animated GIF effects & Fluid Frames`,
        `⌁ *${prefix}store pfps* / *${prefix}store banners* — portraits & banners`,
        `⌁ *${prefix}store info <id>* — live GIF/art preview + price`,
        `⌁ *${prefix}store buy <id>* — unlock with 💎 Gems`,
        `⌁ *${prefix}store equip <id>* — wear it immediately`,
        `⌁ *${prefix}store owned* — your collection`,
        '',
        '🖥️ *RIG STORE* — the machine ASTRATOK needs',
        `⌁ *${prefix}store pcs* — gaming PCs, cheap to legendary`,
        `⌁ *${prefix}store buy <rig id>* — pay in ☀️ solars or 💎 gems`,
        `⌁ *${prefix}stream pc <rig id>* — plug one in`,
        '',
        '_Equipping also works via_ *.pickpfp*, *.pickbanner*, *.pickframe*, _and_ *.pickeffect*._',
        isStoreOwner(ctx.from) ? `\n👑 *${prefix}store admin* — add your own art (owner)` : '',
      ].filter(Boolean).join('\n'))
    }

    const shelf = resolveShelf(sub)
    if (args[1] && Number.isFinite(Number(args[1])) && Number(args[1]) >= 1) {
      shelf.page = Math.floor(Number(args[1]))
    }
    return sendShelf(ctx, shelf)
  },
}
