/**
 * validate — Data integrity checker.
 * Owner-only command. Also exports runValidation() for boot-time use.
 *
 * Checks (without exception):
 *   1. Every class's startingItems resolve to a real item with a valid slot.
 *   2. Every recipe's materials reference items/materials that actually exist.
 *   3. Every armor/weapon item has a real, non-generic slot (never 'armor').
 *   4. Every recipe material is obtainable (mine, monster/boss drop, material
 *      reaction, or another recipe).
 *   5. The achievement catalog is structurally sound (ids, tiers, tracks,
 *      checks, rewards) per lib/achievement-engine.js's validateCatalog.
 *   6. The redeem catalog is sound (codes, pool entries, weights, item and
 *      pet ids) per lib/redeem-engine.js's validateRedeemCatalog.
 *
 * Usage: <prefix>validate  (owner only)
 */
import { config } from '../config.js'
import { allItems, classes, recipes, materials, monsters, materialReactions } from '../lib/game-data.js'
import { ALL_BOSSES, DREAMLAND_BOSSES } from '../bosses/index.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import { validateCatalog } from '../lib/achievement-engine.js'
import { validateRedeemCatalog } from '../lib/redeem-engine.js'

const VALID_SLOTS   = new Set(['weapon', 'offhand', 'helmet', 'chestplate', 'boots', 'accessory', 'relic', 'tool'])
const itemMap       = Object.fromEntries(allItems.map(i => [i.id, i]))

// Materials the mine can yield. Kept in step with plugins/mine.js's ORE_POOL
// (BONUS_ORE_POOL only ever repeats ids from it).
const MINE_IDS = new Set([
  'iron_ore','wood_plank','leather_scrap','silver_ore',
  'mythril_ore','diamond_ore','titanium_ore','celestial_ore',
])

/** Every id a kill can put in a player's bag. */
function dropIds() {
  const ids = new Set()
  // Dungeon/world monsters (data/monsters.json) drop {itemId, chance} rows.
  for (const m of [...(monsters.regular ?? []), ...(monsters.bosses ?? [])]) {
    for (const d of m.drops ?? []) ids.add(d.itemId)
  }
  // Anime bosses (bosses/*.js, spawned via plugins/dungeon.js's spawnBoss())
  // are the actual boss roster used in dungeons — monsters.json's own
  // `bosses` array is only a fallback for unmapped slots. Their `drops`
  // field is a flat string[] of itemIds (normalized to {itemId,chance} at
  // spawn time in dungeon.js), not the {itemId,chance} shape used above.
  for (const b of ALL_BOSSES) {
    for (const itemId of b.drops ?? []) ids.add(itemId)
  }
  // The Dreamlands champions are a separate roster (NOT in ALL_BOSSES: they are
  // keyed by location + floor, see data/dreamlands-bosses.json) but they pay out
  // through the same flat `drops` array — lib/dreamlands-rewards.js rolls
  // `drops` against `dropChances` on a clear. Walking only ALL_BOSSES reported
  // the realm's trophy crown_of_the_distorted as a dead end even though
  // the_distorted_one hands it over on every kill.
  for (const b of DREAMLAND_BOSSES ?? []) {
    for (const itemId of b.drops ?? []) ids.add(itemId)
  }
  return ids
}

/**
 * Every id a player can actually get hold of, resolved to a fixed point.
 *
 * Three sources feed it: the mine, kills, and the two conversion paths that
 * turn one set of owned ids into another —
 *   · material reactions (data/material-reactions.json, plugins/react.js)
 *   · the crafting bench (data/recipes.json, plugins/craft.js and
 *     `.empire forge`), which is how the refined ladder exists at all:
 *     astral_ingot → resonant_alloy → voidbound_plate are never dropped, they
 *     are forged. Without this the whole boss table read as a dead end.
 * Both are resolved together because a chain can be several rungs deep
 * (voidbound_plate needs resonant_alloy, which needs astral_ingot). A recipe
 * whose ingredients can never all be held simply never resolves, and its
 * materials stay in the "not obtainable" report — which is the point.
 *
 * Exported so the test suite can assert against the same set the boot gate uses.
 */
export function buildObtainable() {
  const obtainable = new Set([...MINE_IDS, ...dropIds()])
  let grew = true
  while (grew) {
    grew = false
    for (const reaction of materialReactions ?? []) {
      const outId = reaction.output?.itemId
      if (!outId || obtainable.has(outId)) continue
      if ((reaction.ingredients ?? []).every(ing => obtainable.has(ing.itemId))) {
        obtainable.add(outId)
        grew = true
      }
    }
    for (const recipe of recipes) {
      const outId = recipe.output
      if (!outId || obtainable.has(outId)) continue
      const mats = recipe.materials ?? []
      if (!mats.length) continue
      if (mats.every(m => obtainable.has(m.itemId))) {
        obtainable.add(outId)
        grew = true
      }
    }
  }
  return obtainable
}
const OBTAINABLE = buildObtainable()

/**
 * Run all validation checks. Returns { passed: boolean, errors: string[] }.
 * Does not throw — all failures are collected and returned.
 */
export function runValidation() {
  const errors = []

  // ── 1. Class startingItems ─────────────────────────────────────────────────
  for (const [classId, cls] of Object.entries(classes)) {
    for (const itemId of cls.startingItems ?? []) {
      const item = itemMap[itemId]
      if (!item) {
        errors.push(`[class:${classId}] startingItem "${itemId}" not found in allItems`)
        continue
      }
      // Consumables have slot=null — that's valid.
      if (item.type !== 'consumable' && item.slot !== null) {
        if (!VALID_SLOTS.has(item.slot)) {
          errors.push(`[class:${classId}] startingItem "${itemId}" has invalid slot "${item.slot}"`)
        }
      }
    }
  }

  // ── 2. Recipe materials exist ──────────────────────────────────────────────
  for (const recipe of recipes) {
    for (const { itemId } of recipe.materials ?? []) {
      if (!itemMap[itemId]) {
        errors.push(`[recipe:${recipe.id}] material "${itemId}" not found in allItems`)
      }
    }
    if (!itemMap[recipe.output]) {
      errors.push(`[recipe:${recipe.id}] output "${recipe.output}" not found in allItems`)
    }
  }

  // ── 3. No armor item with generic slot "armor" ─────────────────────────────
  for (const item of allItems) {
    if (item.type === 'armor' && item.slot === 'armor') {
      errors.push(`[item:${item.id}] still has generic slot "armor" — must be helmet/chestplate/boots`)
    }
    if ((item.type === 'armor' || item.type === 'weapon') && item.slot !== null && !VALID_SLOTS.has(item.slot)) {
      errors.push(`[item:${item.id}] has unrecognised slot "${item.slot}"`)
    }
  }

  // ── 4. No dead-end recipes (every material has a real source) ──────────────
  for (const recipe of recipes) {
    for (const { itemId } of recipe.materials ?? []) {
      if (itemMap[itemId] && !OBTAINABLE.has(itemId)) {
        errors.push(`[recipe:${recipe.id}] material "${itemId}" is not obtainable (not mined, dropped, reacted, or crafted)`)
      }
    }
  }

  // ── 5. Achievement catalog (ids, tiers, tracks, checks, rewards) ──────────
  for (const problem of validateCatalog()) {
    errors.push(`[achievements] ${problem}`)
  }

  // ── 6. Redeem catalog (codes, pool entries, weights, grantable ids) ──────
  for (const problem of validateRedeemCatalog()) {
    errors.push(`[redeem] ${problem}`)
  }

  return { passed: errors.length === 0, errors }
}

export default {
  name:           'validate',
  aliases:        ['checkdata'],
  category:       'admin',
  requiresPlayer: false,
  description:    'Run data integrity validation (owner only)',

  async run(ctx) {
    // Owner gate — was only checking config.ownerNumbers (phone-number JIDs)
    // and never config.ownerLid, so LID-based owner accounts were incorrectly
    // rejected. Now uses the same shared check as every other owner gate.
    const isOwner = ctx.from ? isOwnerJid(ctx.from) : false
    if (!isOwner) {
      return ctx.reply(`❌ This command is restricted to the bot owner.`)
    }

    const { passed, errors } = runValidation()

    if (passed) {
      return ctx.reply(
        `✅ *Validation passed!*\n` +
        `All class startingItems, recipe materials, item slots, and recipe obtainability checks are clean.\n` +
        `Items: ${allItems.length}  |  Recipes: ${recipes.length}  |  Classes: ${Object.keys(classes).length}`,
      )
    }

    const lines = errors.map((e, i) => `  ${i + 1}. ${e}`)
    return ctx.reply(
      `❌ *Validation FAILED — ${errors.length} error(s)*\n\n` +
      lines.join('\n') +
      `\n\n_Fix all errors above before deploying._`,
    )
  },
}
