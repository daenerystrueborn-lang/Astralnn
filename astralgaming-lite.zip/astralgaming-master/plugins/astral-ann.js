/**
 * astral-ann.js — marks a group as a League UPDATE group.
 *
 * Owner only, run inside the group. More than one group may carry it. An update
 * group receives the 00:05 fixtures card, the featured match and the 23:55 end
 * of day post from lib/league/league-scheduler.js.
 *
 * The flag lives in that group's existing settings record
 * (data/group-settings.json, key `leagueAnnounce`), so no new file is needed and
 * nothing has to be added to MUTABLE_FILES.
 *
 * The name is hyphenated, which this bot already supports (aizen-spin,
 * cb-state). Checked against plugins/: astral-ann is free.
 */
import { config } from '../config.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import { getGroupSettings, saveGroupSettings, saveFailedMessage, parseOnOff } from '../lib/group-settings.js'
import { leagueGate, getLeague } from '../lib/league/league-repo.js'

export default {
  name: 'astral-ann',
  aliases: [],
  category: 'admin',
  requiresPlayer: false,
  description: 'Owner only: mark this group as an Astral League update group.',

  async run(ctx) {
    const { db, from, args, reply } = ctx
    if (!isOwnerJid(from)) return reply('🔒 That is an owner command.')
    if (!ctx.isGroup) return reply('❌ Run that inside the group you want to mark.')

    const current = (await getGroupSettings(ctx.sender))?.leagueAnnounce === true
    // With no argument it toggles, which is what `.astral-ann` feels like. An
    // explicit on/off is honoured so the owner can be sure which way it went.
    const parsed = parseOnOff(args[0])
    const want = parsed === null ? !current : parsed === true

    if (current === want) {
      return reply(want
        ? '📣 This group is already an Astral League update group.'
        : '📣 This group is not an Astral League update group.')
    }

    // saveGroupSettings, not updateGroupSettings: it hands back { ok, settings,
    // error } instead of throwing, which is the repo's toggle convention (see
    // handleBoolToggle). A thrown write used to leave the group with no reply at
    // all, which reads exactly like the bot ignoring the owner.
    const res = await saveGroupSettings(ctx.sender, (settings) => { settings.leagueAnnounce = want; return settings })
    if (!res.ok) return reply(saveFailedMessage('League update posts', res.error))

    if (!want) return reply('📣🔕 *This group will no longer carry the League posts.*')
    const gate = leagueGate(db)
    if (!gate.open) {
      return reply([
        '📣✅ *This group is now an Astral League update group.*',
        '━━━━━━━━━━━━━━━━━━━━',
        gate.message,
        '✨ _The posts start the moment the League is switched on and a season is open._',
      ].join('\n'))
    }
    const league = getLeague(db)
    return reply([
      '📣🔥 *This group is now an Astral League update group.* 🔥📣',
      '━━━━━━━━━━━━━━━━━━━━',
      '📅 *The fixtures card lands at 00:05*, the *featured match* at its set time, and the *end of day post at 23:55*, all West Africa Time.',
      league.fixtures.length
        ? '✅ *The next card goes out on schedule.*'
        : '⏳ _Nothing posts until the owner opens a season._',
      `ℹ️ Turn it off any time with *${config.prefix}astral-ann off*.`,
    ].join('\n'))
  },
}
