/**
 * victory.js — Victoria Minayoko's Sanctum Victoriae (`.victory`).
 *
 *   "Your home is in Victoria, so is your soul.
 *    For as long as she stands protecting you, misfortune will break against
 *    her like waves on stone."
 *
 * Claims the ground: for 10 turns nothing can harm or kill her owner. Usable
 * from turn 6 (five turns to claim), once per battle, and in a boss fight only
 * while the owner is below 50% HP. The rules, the narration and how "absolute"
 * is enforced across every fight type are in lib/victoria.js.
 *
 * Where each fight type goes:
 *   League fixture  playLeagueMove() -> runPvpTurn('victory') (turn limit,
 *                   the stand-in's answer and the table come with it)
 *   Duel            pvpVictory() -> runPvpTurn('victory')
 *   Party fight     battleVictory() in plugins/party.js (`@ally` names allies
 *                   under her roof)
 *   Pack floor      one swarm turn (resolveSwarmAbility), the pack still moves
 *   Dungeon / boss  this file: the raise is the whole turn, then the enemy's
 *                   answer, which the Sanctum nullifies (lib/king-yato.js's
 *                   shared hold hook)
 *
 * Usage: <prefix>victory
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { calcMonsterHitChance, calcMonsterDamage, hpBar } from '../lib/combat-engine.js'
import {
  handleVictory,
  processStatusTurn,
  resolvePlayerHpZero,
  checkCatFormOngoingTurn,
  resolveCatFormDefeat,
} from '../lib/combat-handlers.js'
import { getEffectiveStat } from '../lib/effects.js'
import {
  applyBossSpecial, buildEnemyAttack, getBossTaunt,
  incrementBossTurn, cleanupBossFight, EVENT,
} from '../lib/boss-engine.js'
import { sendWillowAdvisory, tickPermanentSever, applyIncomingDamage } from '../lib/character-abilities.js'
import { heroesAnswerHit, heroesTurnBoundary } from '../lib/witch-heroes-pve.js'
import { resolveSwarmAbility } from '../lib/swarm-combat.js'
import { graceHoldsEnemyTurn, graceEnemyHeldLine } from '../lib/king-yato.js'
import { canRaiseSanctum, raiseSanctum, sanctumStatusLine } from '../lib/victoria.js'
import { pvpVictory } from './pvp.js'
import { playLeagueMove } from './league-battle.js'
import { battleVictory, findPartyForPlayer } from './party.js'
import { sendBattleTurnReply } from '../lib/battle-frame-render.mjs'

/** Boss-engine hooks only run for a boss with a bossState (same test as atomic.js). */
function hasBossEngine(player) {
  return !!(player.battleState?.enemy?.isBoss && player.battleState?.bossState)
}

export default {
  name: 'victory',
  aliases: ['sanctum', 'sanctumvictoriae', 'sanctum-victoriae'],
  category: 'combat',
  requiresPlayer: true,
  description: `${config.prefix}victory — Victoria's Sanctum Victoriae: 10 turns where nothing can harm or kill you (from turn 6, once per battle)`,

  async run(ctx) {
    const p = config.prefix

    // A League fixture first: playLeagueMove() sends and writes, so it must run
    // before updatePlayer() (same order every signature move uses).
    if (await playLeagueMove(ctx, 'victory', '')) return

    // Duels run their own two-player engine.
    if (ctx.player?.battleState?.type === 'pvp') return pvpVictory(ctx)

    // A party fight: members carry no battleState of their own.
    if (ctx.player?.inBattle && !ctx.player.battleState && findPartyForPlayer(ctx.db, ctx.from)?.battle) {
      return battleVictory(ctx)
    }

    if (!ctx.player?.inBattle || !ctx.player?.battleState) {
      return ctx.reply(`🏛️ The Sanctum is claimed in battle. There is no ground to hold here.`)
    }

    await updatePlayer(ctx.db, ctx.from, async player => {
      const catTurn = await checkCatFormOngoingTurn(player, ctx, { boss: hasBossEngine(player) })
      if (catTurn.intercepted) return catTurn.returnValue

      const bs = player.battleState
      // The HP rule applies to EVERY boss, including a plain one with no
      // boss-engine state; the engine hooks below only to the ones that have it.
      const bossRule = !!bs?.enemy?.isBoss
      const gate = canRaiseSanctum(player, { bs, boss: bossRule })
      if (!gate.ok) {
        await ctx.reply(gate.message)
        return player
      }

      // Pack floors: the raise is folded into one swarm turn. The pack still
      // closes and swings, and every swing lands on the Sanctum.
      if (bs.mode === 'swarm') {
        return resolveSwarmAbility(player, ctx, () => {
          const raised = raiseSanctum(player, { bs, boss: false })
          return { lines: raised.ok ? raised.lines : [raised.message] }
        })
      }

      const e = bs.enemy
      const boss = hasBossEngine(player)
      const hpBeforeTurn  = player.hp
      const eHpBeforeTurn = e.hp
      bs.playerDefending = false
      let msg = ''

      // Urahara's permanent Tear — action-triggered tick, same as every other
      // combat entry point.
      const permaSeverLine = tickPermanentSever(player)
      if (permaSeverLine) msg += permaSeverLine + '\n'
      if (player.hp <= 0) {
        const res = await resolvePlayerHpZero(player, ctx, msg, {})
        if (!res.fallThrough) return res.returnValue
        msg = res.msg
      }

      if (boss) {
        incrementBossTurn(player)
        const tsResult = applyBossSpecial(player, EVENT.TURN_START, {})
        if (tsResult.narrativeLine) msg += `_${tsResult.narrativeLine}_\n`
      }

      const playerStatus = processStatusTurn(player)
      if (playerStatus.incapacitated && player.battleState?.enemy?.tower) player.battleState.towerTacticIncapacitatedTurn = player.battleState.turn ?? 1
      if (!playerStatus.incapacitated && player.hp > 0 && player.battleState?.bossState?._def?.orv) applyBossSpecial(player, EVENT.PLAYER_ABILITY, {})
      if (playerStatus.lines.length) msg += playerStatus.lines.join('\n') + '\n'
      if (player.hp <= 0) {
        const res = await resolvePlayerHpZero(player, ctx, msg, { boss })
        if (!res.fallThrough) return res.returnValue
        msg = res.msg
      }

      if (playerStatus.incapacitated) {
        // The gate passed but she cannot move: the charge is NOT spent.
        msg += `💫 *${player.name}* is unable to act this turn!\n`
      } else {
        const raised = raiseSanctum(player, { bs, boss: bossRule })
        msg += (raised.ok ? raised.lines : [raised.message]).join('\n') + '\n'
      }

      const enemyStatus = processStatusTurn(e, { bossState: player.battleState?.bossState })
      if (enemyStatus.lines.length) msg += enemyStatus.lines.join('\n') + '\n'
      if (e.hp <= 0) {
        if (boss) cleanupBossFight(player)
        return handleVictory(player, e, ctx)
      }

      // The enemy's answer. While the Sanctum stands this hook holds it (its
      // attack lands on the Sanctum and is nullified), exactly as it does on
      // every other combat verb for the next ten turns.
      if (graceHoldsEnemyTurn(player)) {
        msg += `\n${graceEnemyHeldLine(e, player)}\n`
      } else if (enemyStatus.incapacitated) {
        msg += `💫 *${e.name}* is unable to attack this turn!\n`
      } else if (boss) {
        const bossAtk    = buildEnemyAttack(player)
        const dealResult = applyBossSpecial(player, EVENT.ENEMY_DEAL_DAMAGE, { damage: bossAtk.damage, isHit: true })
        const rawBossAtk = (dealResult.modified && dealResult.damage !== undefined) ? dealResult.damage : bossAtk.damage
        const incoming   = bossAtk.bypassDefense
          ? rawBossAtk
          : calcMonsterDamage(rawBossAtk, getEffectiveStat(player, 'def'), false)
        const witchHit = heroesAnswerHit({ player, enemy: e, ctx, msg: '', damage: incoming, directAttack: true, boss })
        if (witchHit.returnValue !== undefined) return witchHit.returnValue
        if (witchHit.lines.length) msg += witchHit.lines.map(l => l + '\n').join('')
        const applied = applyIncomingDamage(player, witchHit.damage)
        if (applied.message) msg += applied.message + '\n'
        msg += `\n${e.emoji ?? '👾'} *${e.name}* uses *${bossAtk.attackName}*!\n`
        if (!witchHit.turned) msg += `🩸 *${applied.damage}* damage!${bossAtk.bypassDefense ? ' _(bypasses DEF)_' : ''}\n`
        if (dealResult.narrativeLine) msg += `_${dealResult.narrativeLine}_\n`
        msg += `\n💬 _"${getBossTaunt(player)}"_\n`
        if (applied.catFormDefeated) return resolveCatFormDefeat(player, ctx, { boss: true })
        if (player.hp <= 0) {
          const res = await resolvePlayerHpZero(player, ctx, msg, { boss: true })
          if (!res.fallThrough) return res.returnValue
          msg = res.msg
        }
      } else if (Math.random() > calcMonsterHitChance(e, player)) {
        msg += `\n${e.emoji ?? '👾'} *${e.name}* retaliates... and *MISSES!*`
      } else {
        const enemyDmg = calcMonsterDamage(e.atk, getEffectiveStat(player, 'def'), false)
        const witchHit = heroesAnswerHit({ player, enemy: e, ctx, msg: '', damage: enemyDmg, directAttack: true, boss })
        if (witchHit.returnValue !== undefined) return witchHit.returnValue
        if (witchHit.lines.length) msg += witchHit.lines.map(l => l + '\n').join('')
        const applied = applyIncomingDamage(player, witchHit.damage)
        if (applied.message) msg += applied.message + '\n'
        if (!witchHit.turned) msg += `\n${e.emoji ?? '👾'} *${e.name}* retaliates!\n🩸 *${applied.damage}* damage!`
        if (applied.catFormDefeated) return resolveCatFormDefeat(player, ctx)
        if (player.hp <= 0) {
          const res = await resolvePlayerHpZero(player, ctx, msg, {})
          if (!res.fallThrough) return res.returnValue
          msg = res.msg
        }
      }

      if (boss) {
        const teResult = applyBossSpecial(player, EVENT.TURN_END, {})
        if (teResult.narrativeLine) msg += `\n_${teResult.narrativeLine}_`
      }

      // The enemy has answered this turn already, so the count is what is left after it.
      const sanctumLine = sanctumStatusLine(player, { prefix: p, after: true })
      msg += `\n\n👤 *${player.name}*\n❤️ ${hpBar(player.hp, player.maxHp)}  💧 ${player.mp}/${player.maxMp} MP\n` +
             `${e.emoji ?? '👾'} *${e.name}*\n❤️ ${hpBar(e.hp, e.maxHp)}\n` +
             (sanctumLine ? `${sanctumLine}\n` : '') + `\n` +
             `*${p}attack* · *${p}skill <name>* · *${p}defend* · *${p}flee*`

      // The shared completed-turn clock (lib/witch-heroes-pve.js). A turn that
      // skips it is a turn the kit never saw.
      const witchTurn = await heroesTurnBoundary({ player, enemy: e, ctx, msg, turnId: bs.turn ?? 1, boss })
      if (witchTurn.returnValue !== undefined) return await witchTurn.returnValue
      msg = witchTurn.msg
      bs.turn = (bs.turn ?? 1) + 1
      player.battleState = bs
      await sendWillowAdvisory(ctx, player, e, boss)
      await sendBattleTurnReply(ctx, { bs, player, e, msg, hpBeforeTurn, eHpBeforeTurn, boss })
      return player
    })
  },
}
