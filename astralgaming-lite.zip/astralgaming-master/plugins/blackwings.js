// <prefix>blackwings - Kim Dokja, Demon King form. Once per fight.
import { config } from '../config.js'
import { activateBlackWings } from '../lib/regressor-form-commands.js'
import { runRegressorCommand } from '../lib/regressor-command-runner.js'

export default {
  name: 'blackwings',
  aliases: ['blackwingsform'],
  category: 'combat',
  description: `${config.prefix}blackwings - Demon King form. +25% ATK, INT reflect 30%, burns double for 3 turns.`,
  requiresPlayer: true,
  async run(ctx) { return runRegressorCommand(ctx, activateBlackWings) },
}
