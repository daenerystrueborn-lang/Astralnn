/**
 * skills.js — .skills [page | filter | info <name>] · view every skill you've unlocked
 * or inspect any skill's full Affinity & Element breakdown.
 *
 * Usage:
 *   <prefix>skills                   — page 1, sorted by impact
 *   <prefix>skills 2 / page 3        — jump to page
 *   <prefix>skills fire|water|earth|air|neutral|dominant — filter owned skills by Affinity
 *   <prefix>skills info <skill name> — full Skill Info Card (Element, Affinity, Domain/Mismatch)
 *   <prefix>skills <skill name>      — shortcut to Skill Info Card
 */
import { config } from '../config.js'
import { skills as allSkills, skillTierMap, skillTierOrder } from '../lib/game-data.js'
import { getEquippedSkills, ensureUniversalNeutralSkills, ensureAffinityBendingSkills } from '../lib/skill-slots.js'
import { isInSectEmpire } from '../lib/worlds.js'
import { sectCombatCommand } from '../lib/sect-fight.js'
import { affinityOfSkill, AFFINITY_SLOTS, AFFINITY_BADGE } from '../lib/skill-element.js'
import { fuzzyMatchScore } from '../lib/fuzzy.js'
import {
  MIN_AWAKEN_LEVEL,
  hasAffinity,
  skillAffinityProfile,
  formatAffinityBadgeLine,
} from '../lib/affinity-engine.js'
import {
  findAnySkill,
  formatSkillElementTag,
  formatSkillCompatTag,
  formatSkillInfoCard,
} from '../lib/skill-info.js'

const PAGE_SIZE = 12

const skillMap = Object.fromEntries(allSkills.map((s) => [s.id, s]))
const tierRank = Object.fromEntries(skillTierOrder.map((id, i) => [id, i]))

const FILTER_ALIASES = Object.freeze({
  fire: 'fire', firebending: 'fire',
  water: 'water', waterbending: 'water',
  earth: 'earth', earthbending: 'earth',
  air: 'air', airbending: 'air', wind: 'air',
  neutral: 'neutral', martial: 'neutral',
  dominant: 'dominant', domain: 'dominant', matched: 'dominant',
  ready: 'ready', usable: 'ready',
  bending: 'bending', avatar: 'bending', bend: 'bending',
})

function resolveFilterWord(word) {
  if (FILTER_ALIASES[word]) return FILTER_ALIASES[word]
  let best = null
  let bestSc = 0
  for (const [alias, target] of Object.entries(FILTER_ALIASES)) {
    const sc = fuzzyMatchScore(word, alias)
    if (sc >= 0.85 && sc > bestSc) {
      bestSc = sc
      best = target
    }
  }
  return best
}

function parseSkillsArgs(args = []) {
  const parts = (args ?? []).map((a) => String(a ?? '').trim()).filter(Boolean)
  if (!parts.length) return { mode: 'list', filter: null, page: 1 }

  const first = parts[0].toLowerCase()
  if (first === 'info' || first === 'view' || first === 'check') {
    return { mode: 'info', query: parts.slice(1).join(' ') }
  }

  // Page-only forms: `.skills 2` or `.skills page 2`
  if (/^\d+$/.test(first) && parts.length === 1) {
    return { mode: 'list', filter: null, page: parseInt(first, 10) }
  }
  if (first === 'page' && parts[1] && /^\d+$/.test(parts[1])) {
    return { mode: 'list', filter: null, page: parseInt(parts[1], 10) }
  }

  // Element / dominant / bending filter forms (exact or fuzzy, e.g. `.skills benidng`)
  const resolvedFilter = resolveFilterWord(first)
  if (resolvedFilter && (parts.length === 1 || /^\d+$/.test(parts[1]) || parts[1]?.toLowerCase() === 'page')) {
    let page = 1
    if (parts[1] && /^\d+$/.test(parts[1])) page = parseInt(parts[1], 10)
    else if (parts[1]?.toLowerCase() === 'page' && parts[2] && /^\d+$/.test(parts[2])) page = parseInt(parts[2], 10)
    return { mode: 'list', filter: resolvedFilter, page }
  }

  // Otherwise treat `.skills <name>` as a direct Skill Info lookup!
  return { mode: 'info', query: parts.join(' ') }
}

function paginate(list, page) {
  const totalPages = Math.max(1, Math.ceil(list.length / PAGE_SIZE))
  const clamped = Math.min(Math.max(1, page), totalPages)
  const start = (clamped - 1) * PAGE_SIZE
  return { pageItems: list.slice(start, start + PAGE_SIZE), page: clamped, totalPages }
}

function pageFooter(page, totalPages, filter) {
  if (totalPages <= 1) return ''
  const p = config.prefix
  const fPart = filter ? ` ${filter}` : ''
  const nav = []
  if (page > 1) nav.push(`*${p}skills${fPart} page ${page - 1}* ◀️`)
  if (page < totalPages) nav.push(`▶️ *${p}skills${fPart} page ${page + 1}*`)
  return `\n\n📄 _Page ${page}/${totalPages}_${nav.length ? '   ' + nav.join('   ') : ''}`
}

function tierEmoji(tierId) {
  return skillTierMap[tierId]?.emoji ?? '⚪'
}

function typeTag(s) {
  return s.type === 'active' ? `⚔️ Active _(${s.mpCost} MP)_` : '🧬 Passive'
}

const EFFECT_LABEL = {
  attack: (e) => `⚔️ ${Math.round((e.multiplier ?? 1) * 100)}% ${(e.stat ?? 'atk').toUpperCase()} dmg`,
  heal:   (e) => `💚 Heals ${Math.round((e.multiplier ?? 1) * 100)}% ${(e.stat ?? 'hp').toUpperCase()}`,
  shield: (e) => `🛡️ Shields ${Math.round((e.pct ?? e.multiplier ?? 0.2) * 100)}% HP`,
  regen:  (e) => `💫 Regens ${Math.round((e.pct ?? e.multiplier ?? 0.08) * 100)}% HP/turn`,
  strengthen: (e) => `📈 +${Math.round((e.pct ?? e.multiplier ?? 0.15) * 100)}% ${(e.stat ?? 'stat').toUpperCase()}`,
}

function effectSummary(s) {
  const e = s.effects?.[0]
  if (!e) return ''
  const label = EFFECT_LABEL[e.type]
  return label ? label(e) : ''
}

function formatSkillLine(s, equippedSet, player) {
  const star = equippedSet.has(s.id) ? ' ⭐' : ''
  const effect = effectSummary(s)
  const elemTag = formatSkillElementTag(s)
  const compat = formatSkillCompatTag(player, s)
  const compatSuffix = compat ? ` · ${compat}` : ''
  return `${tierEmoji(s.tier)} *${s.name}*${star}  \`${elemTag}\`\n   _${s.tier.toUpperCase()}_ · ${typeTag(s)}${effect ? ` · ${effect}` : ''}${compatSuffix}`
}

export default {
  name: 'skills',
  aliases: ['myskills', 'skilllist', 'allskills', 'skillinfo'],
  category: 'account',
  requiresPlayer: true,
  description: `View unlocked skills & inspect Skill Element/Affinity info (${config.prefix}skills [page|fire|info <name>])`,

  async run(ctx) {
    if (isInSectEmpire(ctx.player) && await sectCombatCommand(ctx, 'skills')) return
    const { player, args, reply } = ctx
    const p = config.prefix

    const parsed = parseSkillsArgs(args ?? [])
    if (parsed.mode === 'info') {
      if (!parsed.query) {
        return reply(`ℹ️ Usage: *${p}skills info <skill name>*\n_Example: ${p}skills info fireball_`)
      }
      const found = findAnySkill(parsed.query, player)
      if (!found) {
        return reply(`❌ No skill found matching *"${parsed.query}"*.\nBrowse yours with *${p}skills*!`)
      }
      return reply(formatSkillInfoCard(found, player, p))
    }

    ensureUniversalNeutralSkills(player)
    ensureAffinityBendingSkills(player)
    const ownedIds = (player.skills ?? []).filter((id) => id !== undefined)
    const owned = ownedIds.map((id) => skillMap[id]).filter(Boolean)

    if (!owned.length) {
      return reply(
        `✨ *Skills*\n\nYou haven't unlocked any skills yet — keep leveling up!\n` +
        `Check *${p}profile* to see your progress.`,
      )
    }

    const readinessRank = (s) => {
      if (s.type !== 'active') return 1
      const r = skillAffinityProfile(player, s).relation
      if (r === 'dominant' || r === 'sub_bridge') return 0
      if (r === 'neutral') return 1
      return 2
    }

    let filtered = owned
    if (parsed.filter) {
      if (parsed.filter === 'dominant') {
        filtered = owned.filter((s) => {
          const r = skillAffinityProfile(player, s).relation
          return r === 'dominant' || r === 'sub_bridge'
        })
      } else if (parsed.filter === 'ready') {
        filtered = owned.filter((s) => readinessRank(s) <= 1)
      } else if (parsed.filter === 'bending') {
        filtered = owned.filter((s) => s.classId === 'bending')
      } else if (AFFINITY_SLOTS.includes(parsed.filter)) {
        filtered = owned.filter((s) => affinityOfSkill(s) === parsed.filter)
      }
      if (!filtered.length) {
        const label = parsed.filter === 'dominant'
          ? 'Dominant Affinity'
          : parsed.filter === 'bending'
            ? '🌀 Avatar Bending'
            : parsed.filter === 'ready'
              ? 'Ready-to-Use'
              : `${AFFINITY_BADGE[parsed.filter]?.emoji ?? ''} ${AFFINITY_BADGE[parsed.filter]?.label ?? parsed.filter}`
        return reply(`✨ You don't have any unlocked *${label}* skills yet.\nView all with *${p}skills*.`)
      }
    }

    const sorted = [...filtered].sort((a, b) => {
      const readyDiff = readinessRank(a) - readinessRank(b)
      if (readyDiff !== 0) return readyDiff
      const rankDiff = (tierRank[a.tier] ?? 99) - (tierRank[b.tier] ?? 99)
      if (rankDiff !== 0) return rankDiff
      return a.name.localeCompare(b.name)
    })

    const equippedSet = new Set(getEquippedSkills(player))
    const { pageItems, page, totalPages } = paginate(sorted, parsed.page)

    const groups = []
    for (const s of pageItems) {
      const last = groups[groups.length - 1]
      if (last && last.tier === s.tier) last.items.push(s)
      else groups.push({ tier: s.tier, items: [s] })
    }

    const body = groups
      .map((g) => {
        const meta = skillTierMap[g.tier]
        const header = `${tierEmoji(g.tier)} *${g.tier.toUpperCase()}* _(x${meta?.multiplier ?? '?'} impact)_`
        const lines = g.items.map((s) => formatSkillLine(s, equippedSet, player)).join('\n')
        return `${header}\n${lines}`
      })
      .join('\n\n')

    const affinityBanner = hasAffinity(player)
      ? `${formatAffinityBadgeLine(player)}\n👑 _Matching Affinity skills are *DOMINANT*; off-element skills fizzle at *12% power*!_`
      : `⚪ *Unawakened Vessel:* *Neutral* skills work right now with no element! Elemental skills unlock at *Lv. ${MIN_AWAKEN_LEVEL}+* via *${p}affinity*.`

    const filterLabel = parsed.filter ? ` · Filter: *${parsed.filter.toUpperCase()}*` : ''
    const header =
      `✨ *${player.name}'s Skills* _(${filtered.length}/${owned.length} shown${filterLabel})_\n` +
      `${affinityBanner}\n` +
      `⭐ = equipped · \`[Affinity · Element]\`\n\n`

    const footer =
      pageFooter(page, totalPages, parsed.filter) +
      `\n\n_Inspect any skill: *${p}skills info <name>* · Filter: *${p}skills dominant* · Loadout: *${p}skillslot*_`

    return reply(header + body + footer)
  },
}
