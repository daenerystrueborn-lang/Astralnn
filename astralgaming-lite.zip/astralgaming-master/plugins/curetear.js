/**
 * <prefix>curetear
 *
 * Removes Urahara's Tear/Reshape — in BOTH shapes it can take on a player:
 *
 *   1. `player.permanentSever` — the losing side of a duel against Urahara.
 *      It lives outside activeEffects on purpose (so pvpConclude's end-of-duel
 *      reset cannot clear it) and it costs SEVERING_ELIXIRS_REQUIRED Severing
 *      Elixirs, all at once, exactly as before.
 *
 *   2. A `tear` entry in `player.activeEffects` — the same wound caught in a
 *      fight, or one left behind by a duel that died before it was concluded.
 *      One elixir, the same price as `.use severing_elixir`.
 *
 * WHY THIS CHANGED
 * ─────────────────
 * This command used to read `player.permanentSever?.active` and nothing else.
 * A player who was genuinely marked — bleeding, with the Tear in their status —
 * was told "✅ You don't have a permanent Tear debuff to cure", and the
 * Severing Elixirs they had just bought could not help them either (the item
 * only clears the activeEffects form, and the permanent flag is invisible to
 * it). The two records exist for good reasons; the cure simply has to know
 * about both, which is what lib/character-abilities.js's hasTear() and
 * curePermanentSever() now do.
 *
 * Ordering bug also fixed: the old mutator consumed the 30 elixirs and THEN
 * called the cure, so a record whose flag changed between the pre-check and
 * the write could lose thirty elixirs and be told there was nothing to cure.
 * The cure now runs first and the inventory is only touched when it succeeded.
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { hasEffect } from '../lib/effects.js'
import {
  curePermanentSever,
  OUT_OF_BATTLE_SEVER_PCT,
  SEVERING_ELIXIRS_REQUIRED,
} from '../lib/character-abilities.js'

const ELIXIR_ID = 'severing_elixir'
const REQUIRED = SEVERING_ELIXIRS_REQUIRED
const EFFECT_COST = 1

function countElixirs(player) {
  return (player?.inventory ?? []).filter((id) => id === ELIXIR_ID).length
}

/** Read both records off a live player object. */
function tearState(player) {
  const flag = player?.permanentSever
  const permanent = flag === true || flag?.active === true
  const effect = hasEffect(player, 'tear')
  return { permanent, effect }
}

/** Removes `count` Severing Elixirs. Caller has already verified the count. */
function consumeElixirs(player, count) {
  let left = count
  player.inventory = (player.inventory ?? []).filter((id) => {
    if (id === ELIXIR_ID && left > 0) {
      left -= 1
      return false
    }
    return true
  })
}

export default {
  name: 'curetear',
  aliases: ['cureTear', 'removetear', 'cure_tear', 'tearcure'],
  category: 'combat',
  description: `${config.prefix}curetear — consume Severing Elixirs to close Urahara's Tear (${REQUIRED} for a permanent Tear, 1 for a Tear caught mid-fight).`,
  requiresPlayer: true,

  async run(ctx) {
    const { db, from, player } = ctx
    const p = config.prefix

    const { permanent, effect } = tearState(player)

    if (!permanent && !effect) {
      return ctx.reply(
        `✅ *You are not carrying a Tear.*\n` +
        `_Nothing to cure — your Severing Elixirs are untouched._\n\n` +
        `_A Tear only comes from Urahara: losing a duel to him leaves a permanent one ` +
        `(30 Elixirs), while one caught mid-fight costs a single Elixir._`,
      )
    }

    const cost = permanent ? REQUIRED : EFFECT_COST
    const owned = countElixirs(player)
    if (owned < cost) {
      return ctx.reply(
        `🩸 *${permanent ? 'Permanent Tear active' : 'Tear active'}.* ` +
        `_(${(OUT_OF_BATTLE_SEVER_PCT * 100).toFixed(1)}% max HP lost on every action, until cured.)_\n\n` +
        `You need *${cost}* Severing Elixir${cost === 1 ? '' : 's'} to cure it. You have *${owned}*.\n` +
        `_Buy them cheap from the ${p}shop, or find them in Season 1's dungeon (${p}dungeon: The Beginning of the End) and its boss._`,
      )
    }

    let replyMsg = ''
    await updatePlayer(db, from, (fresh) => {
      // Re-check against the live record, then CURE FIRST — the elixirs are
      // only spent once the wound is actually closed (see this file's header).
      const state = tearState(fresh)
      if (!state.permanent && !state.effect) {
        replyMsg =
          `✅ *You are not carrying a Tear.*\n` +
          `_Nothing to cure — your Severing Elixirs are untouched._`
        return
      }
      const liveCost = state.permanent ? REQUIRED : EFFECT_COST
      const liveOwned = countElixirs(fresh)
      if (liveOwned < liveCost) {
        replyMsg =
          `❌ Inventory changed — you now have *${liveOwned}/${liveCost}* Severing Elixirs. Try again.`
        return
      }

      const result = curePermanentSever(fresh)
      if (!result.cured) {
        replyMsg = `✅ You are not carrying a Tear — nothing was spent.`
        return
      }
      consumeElixirs(fresh, liveCost)

      replyMsg = result.permanent
        ? `🌿✨ *The Tear closes.* _${liveCost} Severing Elixirs consumed._\n\n` +
          `You're fully cured of the permanent bleed.`
        : `🌿✨ *The Tear closes.* _${liveCost} Severing Elixir consumed._\n\n` +
          `The wound Urahara opened is gone — your next turn won't bleed.`
    })

    return ctx.reply(replyMsg)
  },
}
