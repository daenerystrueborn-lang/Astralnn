import { config } from '../config.js'
import {
  chanceForExclusiveSpin,
  getExclusiveSpinWinner,
  claimExclusiveSpinForPlayer,
  addOwnedSeasonContent,
} from '../lib/season-engine.js'
import { characterMap } from '../lib/game-data.js'
import { updatePlayer } from '../lib/player-repo.js'
import { characterStars } from '../lib/rarity.js'
import { spinLockGate } from '../lib/spin-locks.js'

export const CHARACTER_ID = 'alpha'
export const SPIN_FIELD = 'alphaSpins'
export const COST_PER_SPIN = 5000     // ☀️ Solars
export const DEAD_ZONE_UNTIL = 240    // spins 1-240: 0%
export const PLATEAU_CHANCE = 1.0     // spin 241+: certain
export const PITY_AT = 241            // the first live spin is a guaranteed win
export const MAX_SPINS_PER_PLAYER = 280
export const MAX_SPINS_PER_COMMAND = 50

const RULE = '━━━━━━━━━━━━━━━━━━━━'
const sol = (n) => `☀️*${Math.floor(n).toLocaleString()}*`

const MISS_LINES = [
  'A blade glints. Seven shadows cross the wall, but none come closer.',
  'The Garden does not answer.',
  'A shadow slips past without stopping.',
  'A name is whispered, then lost.',
  'She hears the call, but does not follow it.',
  'The Garden keeps its silence.',
]
const missLine = (spin) => `🌑 _${MISS_LINES[spin % MISS_LINES.length]}_`

function pityBar(spin, width = 10) {
  const filled = Math.max(0, Math.min(width, Math.round((spin / MAX_SPINS_PER_PLAYER) * width)))
  return `${'▰'.repeat(filled)}${'▱'.repeat(width - filled)}`
}

function reel(results) {
  const MAX_ROWS = 5
  const marks = results.map(r => (r.won ? '✦' : '·'))
  const rows = []
  for (let i = 0; i < marks.length; i += 10) rows.push(marks.slice(i, i + 10).join(' '))
  if (rows.length <= MAX_ROWS) return rows.join('\n')
  return [`_…${(rows.length - MAX_ROWS) * 10} earlier spins_`, ...rows.slice(-MAX_ROWS)].join('\n')
}

async function replyOverArt(ctx, character, text) {
  if (!character?.image || typeof ctx.replyImage !== 'function') return ctx.reply(text)
  try {
    return await ctx.replyImage(character.image, text)
  } catch {
    return ctx.reply(text)
  }
}

/** Pure roll for one spin number: exported for tests. */
export function alphaSpinWins(spin, rng = Math.random) {
  if (spin >= PITY_AT) return true
  const chance = chanceForExclusiveSpin(spin, { deadZoneUntil: DEAD_ZONE_UNTIL, plateauChance: PLATEAU_CHANCE, pityAt: PITY_AT })
  return rng() < chance
}

export default {
  name: 'alpha-spin',
  aliases: ['alphaspin'],
  category: 'character',
  requiresPlayer: true,
  description: 'Spin for Alpha: 5,000 Solars per spin, one winner bot-wide',

  async run(ctx) {
    if (spinLockGate(ctx, CHARACTER_ID, 'Alpha')) return
    const p = config.prefix
    if (!ctx.player) return ctx.reply(`⚠️ Register first with *${p}register*.`)

    const character = characterMap[CHARACTER_ID]
    if (!character) return ctx.reply(`⚠️ Alpha isn't configured yet.`)

    const isFirstEverAttempt = (ctx.player[SPIN_FIELD] ?? 0) === 0
    const requested = Math.floor(Number(ctx.args?.[0]) || 1)
    const spinCount = Math.min(MAX_SPINS_PER_COMMAND, MAX_SPINS_PER_PLAYER, Math.max(1, requested))

    const existingWinner = getExclusiveSpinWinner(ctx.db, CHARACTER_ID)
    if (existingWinner) {
      return replyOverArt(ctx, character, existingWinner === ctx.from
        ? `🌑 *Alpha is already beside you.*\n${RULE}\n_She is not going anywhere. There is nothing left to spin for._`
        : `🔒 *ALREADY TAKEN*\n${RULE}\n_${character.name} has been claimed by another player._\n\nOnly one player, bot-wide, could ever obtain her. No solars were spent.`)
    }

    let outcome = null
    await updatePlayer(ctx.db, ctx.from, (player) => {
      if (getExclusiveSpinWinner(ctx.db, CHARACTER_ID)) { outcome = { reason: 'claimed' }; return }
      player.wallet = player.wallet ?? {}

      const results = []
      let won = false
      let spinsUsed = 0
      let solars = Math.floor(player.wallet.solars ?? 0)

      for (let i = 0; i < spinCount; i++) {
        if (getExclusiveSpinWinner(ctx.db, CHARACTER_ID)) break
        if (solars < COST_PER_SPIN) break
        if ((player[SPIN_FIELD] ?? 0) >= MAX_SPINS_PER_PLAYER) break

        const nextSpin = (player[SPIN_FIELD] ?? 0) + 1
        const thisWon = alphaSpinWins(nextSpin)

        solars -= COST_PER_SPIN
        player.wallet.solars = solars
        player[SPIN_FIELD] = nextSpin
        spinsUsed++
        results.push({ spin: nextSpin, won: thisWon })

        if (thisWon) {
          if (claimExclusiveSpinForPlayer(ctx.db, CHARACTER_ID, ctx.from)) {
            addOwnedSeasonContent(player, 'character', character.id)
            won = true
          }
          break
        }
      }

      if (!results.length) {
        outcome = { reason: (player[SPIN_FIELD] ?? 0) >= MAX_SPINS_PER_PLAYER ? 'exhausted_lifetime' : 'solars', solars }
        return
      }
      outcome = { reason: won ? 'won' : 'exhausted', results, spinsUsed, remaining: player.wallet.solars }
    })

    if (outcome?.reason === 'claimed') {
      return replyOverArt(ctx, character,
        `🔒 *ALREADY TAKEN*\n${RULE}\n_${character.name} was taken in the same moment you reached for her._\n\nNo solars were spent.`)
    }
    if (outcome?.reason === 'solars') {
      return ctx.reply(
        `☀️ *Not enough Solars.*\n${RULE}\n` +
        `One spin costs ${sol(COST_PER_SPIN)}. You hold ${sol(outcome.solars)}.\n\n` +
        `_Dungeons, quests and bosses pay Solars, not this banner._`,
      )
    }
    if (outcome?.reason === 'exhausted_lifetime') {
      return ctx.reply(`🌑 *No spins left.*\n${RULE}\n_You've used all *${MAX_SPINS_PER_PLAYER}* of your spins for ${character.name}._`)
    }

    const last = outcome.results[outcome.results.length - 1]
    const spent = outcome.spinsUsed * COST_PER_SPIN
    const range = outcome.spinsUsed === 1
      ? `Spin *${last.spin}*`
      : `Spins *${outcome.results[0].spin}* → *${last.spin}*`

    if (outcome.reason === 'won') {
      const ability = character.ability
      return replyOverArt(ctx, character,
        `🌑✨ *THE GARDEN ANSWERS* ✨🌑\n${RULE}\n` +
        `_Spin ${last.spin}. Seven shadows fall into step behind her._\n\n` +
        `🏆 *${character.name.toUpperCase()} OBTAINED*\n` +
        `${character.emoji ?? '🌑'} *${characterStars(character.stars)}*` +
        (ability?.name ? `  ·  *${ability.name}*` : '') + `\n` +
        (ability?.flavor ? `_${ability.flavor}_\n` : '') +
        `\n🔒 *GLOBALLY LOCKED.* No other player can ever obtain her.\n` +
        `_Taken on spin ${last.spin}, for ${sol(spent)} this pull._\n\n` +
        `☀️ Remaining: ${sol(outcome.remaining)}\n\n` +
        `_Equip her with *${p}character equip ${CHARACTER_ID}*. After two turns, call *${p}garden* once per battle._`,
      )
    }

    const lines = [
      `🌑 *THE GARDEN PASSES YOU BY*`,
      RULE,
      `_You spent ${sol(spent)}._`,
      ``,
      range,
      reel(outcome.results),
      ``,
      missLine(last.spin),
      ``,
      `📿 Pity  ${pityBar(last.spin)}`,
      `☀️ Remaining: ${sol(outcome.remaining)}`,
    ]
    if (requested > MAX_SPINS_PER_COMMAND) {
      lines.push(``, `_Capped at *${MAX_SPINS_PER_COMMAND}* spins per command, run it again for more._`)
    } else if (outcome.spinsUsed < spinCount) {
      lines.push(``, `_Solars ran out after *${outcome.spinsUsed}* of *${spinCount}* requested spins._`)
    }
    const text = lines.join('\n')
    return isFirstEverAttempt ? replyOverArt(ctx, character, text) : ctx.reply(text)
  },
}
