/**
 * excalibur.js — Saber's one move, and the scene the owner supplied.
 *
 * `<prefix>excalibur`. Exactly 3000 damage, DEF never applies, once per battle,
 * and it belongs to Saber alone: the command refuses outright unless she is the
 * equipped character AND the sword is in the weapon slot. A player who owns
 * the sword without her still gets its flat 500 bonus on every hit (see the
 * `excalibur_light` handler in lib/named-passives.js) — the sword is heavy in
 * any hand. The LIGHT is hers.
 *
 * The art is the owner's own Giphy URL, stored verbatim in lib/image.js and
 * sent through replyGif so it actually animates (a raw .gif sent as a video
 * message is the exact silent failure lib/card-media.js documents). The send
 * happens inside the shared battle-cinematic lock, so two scenes can never
 * overlap in one fight.
 *
 * DUELS. `.excalibur` works in a duel and in a League fixture: this file only
 * knows the PvE battleState shape (bs.enemy), so when the caller is in one it
 * hands off to pvp.js's pvpExcalibur(), exactly the way plugins/atomic.js hands
 * off to pvpAtomic(). That side runs the same gate (armExcalibur) and the same
 * flat 3000, spends the turn inside the duel engine, and lets every reaction
 * the duel engine owns answer it — Serpent's Grace, Mahoraga's Wheel, the
 * beast, a Sword Maiden's answer, a Scarlett reflection, shields, Mei's
 * sustain, Yoriichi's cat form. DEF and the accuracy roll are what this move
 * does not care about, in either mode.
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import {
  armExcalibur, runSignatureTurn, isBossFight,
  EXCALIBUR_DAMAGE, EXCALIBUR_ART, EXCALIBUR_NAME, EXCALIBUR_OPENINGS,
} from '../lib/starfall-kits.js'
import { playLeagueMove } from './league-battle.js'
import { pvpExcalibur } from './pvp.js'
import { battleExcalibur, findPartyForPlayer } from './party.js'

export default {
  name: 'excalibur',
  aliases: [
    'excaliber',
    'exc',
    'excal',
    'saber',
    'swordofpromisedvictory',
    'sword-of-promised-victory',
    'promisedvictory',
    'promised-victory',
    'sopv',
  ],
  category: 'combat',
  requiresPlayer: true,
  description: `${config.prefix}excalibur — Saber's once-per-battle light (3000, DEF does not apply)`,

  async run(ctx) {
    // Astral League fixture — runs through playLeagueMove so stand-in replies,
    // turn limits, and match conclusions settle properly.
    if (await playLeagueMove(ctx, 'excalibur', '')) return

    // A duel plays this move on the duel side, where the defender's whole kit
    // can answer it. This plugin has no idea what bs.opponentJid means.
    if (ctx.player?.battleState?.type === 'pvp') {
      return pvpExcalibur(ctx)
    }

    // Co-op dungeon party battle (inBattle: true, battleState: null).
    if (ctx.player?.inBattle && !ctx.player.battleState && findPartyForPlayer(ctx.db, ctx.from)?.battle) {
      return battleExcalibur(ctx)
    }

    await updatePlayer(ctx.db, ctx.from, async player => {
      const gate = armExcalibur(player)
      if (!gate.ok) {
        if (gate.message) await ctx.reply(gate.message)
        return player
      }

      // armExcalibur() already proved there is a live enemy to point this at.
      const move = {
        name: EXCALIBUR_NAME,
        damage: EXCALIBUR_DAMAGE,
        guaranteedHit: true,
        openings: EXCALIBUR_OPENINGS,
        landedLine: e => `The light goes through *${e.name}* and keeps going, out the far wall of the world.`,
        missLine: e => `💨 The beam splits the room in half a breath to the left of *${e.name}* — *MISSED!*\n_And the light does not come twice._`,
      }

      return runSignatureTurn({
        player, ctx, move, boss: isBossFight(player), art: EXCALIBUR_ART,
      })
    })
  },
}
