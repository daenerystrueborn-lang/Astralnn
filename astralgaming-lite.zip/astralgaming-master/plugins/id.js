/**
 * id.js — Player ID card.
 *
 * Commands:
 *   .id                          — show your Astral ID card (image)
 *   .id @player                  — view another player's public ID card
 *   .id image set <url>          — set your ID photo by URL or attached/quoted image
 *   .id image reset              — clear custom ID photo and use your profile picture
 *   .id color <hex>              — change accent color (title, swoosh, text)
 *   .id color border <hex>       — change card border + photo frame color
 *   .id color reset              — reset colors to default black
 *
 * Photo resolution order:
 *   player.idImage → equipped Store/Pass PFP → player.pfp → WhatsApp/Telegram avatar → default PFP
 */
import { config } from '../config.js'
import { updatePlayer, getPlayer } from '../lib/player-repo.js'
import { getRankForLevel } from '../lib/rank-engine.js'
import { renderPlayerIdCard } from '../lib/player-id-render.mjs'
import { extractTarget } from '../lib/group-helpers.js'
import { hidesLevel, titleTier } from '../lib/level-display.js'
import { getActiveSeason } from '../lib/season-engine.js'
import { readProfilePictureBuffer } from '../lib/pfp.js'
import { uploadToImgbb } from '../lib/imgbb.js'
import { ensureDbNamesDeduplicatedSync } from '../lib/unique-names.js'

/** Pull a URL from text args. */
function urlFromArgs(args) {
  for (const a of args) {
    if (a.startsWith('http://') || a.startsWith('https://')) return a
  }
  return null
}

/** Try to pull a URL from a quoted message's text body or image caption. */
function urlFromQuote(msg) {
  const qCtx = msg?.message?.extendedTextMessage?.contextInfo
  if (!qCtx) return null
  const qm = qCtx.quotedMessage
  if (!qm) return null
  const body =
    qm.conversation ||
    qm.extendedTextMessage?.text ||
    qm.imageMessage?.caption ||
    ''
  const match = body.match(/https?:\/\/\S+/)
  return match ? match[0] : null
}

/** Basic hex color validation — must #RGB or #RRGGBB. */
function isValidHex(str) {
  return /^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/.test(str)
}

/** Normalize short #RGB to #RRGGBB. */
function normalizeHex(hex) {
  if (hex.length === 4) {
    return '#' + hex[1] + hex[1] + hex[2] + hex[2] + hex[3] + hex[3]
  }
  return hex.toUpperCase()
}

function withTimeout(promise, ms) {
  return Promise.race([
    promise,
    new Promise(resolve => setTimeout(() => resolve(null), ms)),
  ])
}

/**
 * Resolves the target player's live WhatsApp or Telegram avatar when they have
 * not set an explicit custom/cosmetic in-game PFP yet.
 */
async function resolvePlatformAvatar(ctx, targetId, target) {
  const hasExplicitInGamePfp = Boolean(
    target?.idImage ||
    target?.pfp ||
    (target?.profilePfpId && target.profilePfpId !== 'default'),
  )
  if (hasExplicitInGamePfp) return null

  // WhatsApp profile picture URL
  if (typeof ctx.sock?.profilePictureUrl === 'function') {
    const jidCandidates = [
      targetId,
      target?.phone ? `${String(target.phone).replace(/\D/g, '')}@s.whatsapp.net` : null,
      target?.lid ?? null,
    ].filter(Boolean)
    for (const jid of jidCandidates) {
      if (!String(jid).includes('@')) continue
      const url = await withTimeout(
        ctx.sock.profilePictureUrl(jid, 'image').catch(() => null),
        3500,
      )
      if (url && /^https?:\/\//i.test(url)) return url
    }
  }

  // Telegram profile picture bytes
  if (ctx.platform === 'telegram' && ctx.bot?.api) {
    const rawTgId = String(targetId).startsWith('tg:')
      ? String(targetId).slice(3)
      : (targetId === ctx.from && String(ctx.platformId ?? '').startsWith('tg:')
          ? String(ctx.platformId).slice(3)
          : null)
    const tgUserId = rawTgId && /^\d+$/.test(rawTgId) ? Number(rawTgId) : null
    if (tgUserId) {
      const buf = await withTimeout((async () => {
        try {
          const photos = await ctx.bot.api.getUserProfilePhotos(tgUserId, { limit: 1 })
          const sizes = photos?.photos?.[0]
          const best = Array.isArray(sizes) && sizes.length ? sizes[sizes.length - 1] : null
          if (!best?.file_id) return null
          const file = await ctx.bot.api.getFile(best.file_id)
          if (!file?.file_path || !ctx.bot.token) return null
          const res = await fetch(`https://api.telegram.org/file/bot${ctx.bot.token}/${file.file_path}`, {
            signal: AbortSignal.timeout(3000),
          })
          if (!res.ok) return null
          return Buffer.from(await res.arrayBuffer())
        } catch {
          return null
        }
      })(), 3500)
      if (buf) return buf
    }
  }

  return null
}

export default {
  name: 'id',
  aliases: ['playerid', 'pid'],
  category: 'account',
  requiresPlayer: true,
  description: 'Show your Astral ID card — .id color / .id color border to customize',

  async run(ctx) {
    const { args, reply, player, db, msg } = ctx
    ensureDbNamesDeduplicatedSync(db)
    const pr  = config.prefix
    const sub = (args[0] ?? '').toLowerCase()

    // ── .id image set <url> | .id image reset ─────────────────────────────
    if (sub === 'image' || sub === 'photo') {
      const action = (args[1] ?? '').toLowerCase()
      if (action === 'reset' || action === 'clear' || action === 'default' || action === 'remove') {
        await updatePlayer(db, ctx.from, async p => { p.idImage = null; return p })
        return reply(`🔄 *ID photo reset!* Your ID card now uses your profile picture.`)
      }

      if (!action || action === 'set') {
        const urlArgs = action === 'set' ? args.slice(2) : args.slice(1)
        let url = urlFromArgs(urlArgs) ?? urlFromQuote(msg)
        if (!url) {
          const buf = await readProfilePictureBuffer(ctx).catch(() => null)
          if (buf) {
            try {
              url = await uploadToImgbb(buf, `id-${Date.now()}`)
            } catch (err) {
              return reply(`⚠️ Couldn't upload attached photo: _${err?.message ?? err}_`)
            }
          }
        }
        if (!url) {
          return reply(
            `📸 *Set ID Photo*\n\n` +
            `• Reply to a photo with *${pr}id image set*\n` +
            `• Or paste a direct link: *${pr}id image set <url>*\n` +
            `• Or reset to your profile picture: *${pr}id image reset*`,
          )
        }
        await updatePlayer(db, ctx.from, async p => { p.idImage = url; return p })
        return reply(`✅ *ID photo updated!* Type *${pr}id* to see your card.`)
      }
    }

    // ── .id color … ───────────────────────────────────────────────────────
    if (sub === 'color' || sub === 'colour') {
      const target2 = args[1]?.toLowerCase() ?? ''

      // .id color reset
      if (target2 === 'reset') {
        await updatePlayer(db, ctx.from, async p => { p.idColors = {}; return p })
        return reply(`🔄 ID colors reset to default.`)
      }

      // .id color border <hex>
      if (target2 === 'border') {
        const hex = args[2]?.startsWith('#') ? args[2] : (args[2] ? '#' + args[2] : null)
        if (!hex || !isValidHex(hex)) {
          const cur = player.idColors?.border ?? '#111111'
          return reply(
            `🖊️ *ID Border Color*\n\n` +
            `Current: *${cur}*\n\n` +
            `*${pr}id color border <#hex>*\n` +
            `Example: *${pr}id color border #CC0000*`,
          )
        }
        const clean = normalizeHex(hex)
        await updatePlayer(db, ctx.from, async p => {
          p.idColors = { ...(p.idColors ?? {}), border: clean }
          return p
        })
        return reply(`✅ ID border color set to *${clean}*`)
      }

      // .id color <hex>  → accent color
      const hex = target2.startsWith('#') ? target2 : (target2 ? '#' + target2 : null)
      if (!hex || !isValidHex(hex)) {
        const curAcc = player.idColors?.accent ?? '#111111'
        const curBrd = player.idColors?.border ?? '#111111'
        return reply(
          `🎨 *ID Card Colors*\n\n` +
          `Accent (title/text): *${curAcc}*\n` +
          `Border: *${curBrd}*\n\n` +
          `*${pr}id color <#hex>* — set accent color\n` +
          `*${pr}id color border <#hex>* — set border color\n` +
          `*${pr}id color reset* — reset to default black`,
        )
      }
      const clean = normalizeHex(hex)
      await updatePlayer(db, ctx.from, async p => {
        p.idColors = { ...(p.idColors ?? {}), accent: clean }
        return p
      })
      return reply(`✅ ID accent color set to *${clean}*`)
    }

    // ── .id @player ── view someone else ──────────────────────────────────
    const mentionedId = extractTarget(ctx)
    const targetId    = (mentionedId && mentionedId !== ctx.from) ? mentionedId : ctx.from
    const target      = getPlayer(db, targetId)
    if (!target) return reply(`❌ That player isn't registered yet.`)

    const rank = getRankForLevel(target.level)
    const season = getActiveSeason(db)
    const platformAvatar = await resolvePlatformAvatar(ctx, targetId, target)

    try {
      const buf = await renderPlayerIdCard(target, rank, { season, platformAvatar })
      const caption =
        `🪪 *${target.name}'s Astral ID*\n` +
        (hidesLevel(target) ? `${titleTier(target).glyph} ${titleTier(target).name}\n` : `${rank.emoji} ${rank.title}  •  Level ${target.level}\n`) +
        (target.username ? `🏷️ @${target.username}` : `_No username set — use ${pr}username add_`)
      return ctx.replyImage(buf, caption)
    } catch (err) {
      return reply(
        `🪪 *${target.name}'s Astral ID*\n\n` +
        `🏷️ Username: ${target.username ? `@${target.username}` : '—'}\n` +
        `🐾 Pokémon: ${(target.pokemon ?? []).length}\n` +
        `🏅 Level: ${target.level}\n` +
        `${rank.emoji} Rank: ${rank.title}\n` +
        `⚔️ Battles Won: ${target.battleRecord?.wins ?? 0}`,
      )
    }
  },
}
