/**
 * kyato.js — speak to King Yato, the sun king whose grace decides who is
 * allowed to swing at you.
 *
 *   <prefix>kyato <anything>   talk to him — AI-powered (the same askAI stack
 *                              Yu Miaoyi uses), in character, briefed on his
 *                              owner's live state (lib/queen-king-persona.js)
 *   <prefix>kyato              his card — the three prices, what the grace
 *                              does, and for how long
 *
 * Aliases: <prefix>king, <prefix>kingyato, <prefix>king-yato.
 *
 * Note the command name: there is already a 5★ *Yato* in the roster (and a
 * `.yato-spin` for him), so the sun king answers to *kyato* / *king* rather
 * than stealing a name that is spoken for. Equipping him is still
 * `.character equip king_yato`.
 *
 * Equipped-only, exactly like the Queen's door: a stranger gets a static line
 * and never an API call. A fused player is answered here too.
 *
 * The personality lives in data/king-yato-personality.json.
 */
import { config } from '../config.js'
import {
  GRACE_LOCK_TURNS, GRACE_OWNER_PCT, GRACE_WEAK_FROM_TURN, GRACE_WEAK_PCT,
} from '../lib/king-yato.js'
import { CONST_TURN_GATE } from '../lib/queen-esta.js'
import { CROWN_ART, KING_ID, crownDef, crownHoldings } from '../lib/queen-king.js'
import { crownChat } from '../lib/queen-king-persona.js'

const RULE = '━━━━━━━━━━━━━━━━━━━━'

const STRANGER_LINES = [
  `☀️ _He does not put his pen down._ "I receive petitions at court. You have not been granted an audience."`,
  `☀️ _One courteous, final look._ "The crown is not yours to speak through. That is the entire answer."`,
]

const UNEQUIPPED_LINES = [
  `☀️ _"You left the crown in its box. I am not less a king for it, but I am less available." (${config.prefix}character equip ${KING_ID})_`,
  `☀️ _"Return me to your shoulder and the court is open." (${config.prefix}character equip ${KING_ID})_`,
]

const QUIET = `☀️ _The king is in council. He will hear you later._`

export default {
  name: 'kyato',
  aliases: ['king', 'kingyato', 'king-yato'],
  category: 'character',
  requiresPlayer: true,
  description: `${config.prefix}kyato <message>: talk to King Yato (works while he is equipped). Bare command shows his card.`,

  async run(ctx) {
    const pr = config.prefix
    const sub = String(ctx.args[0] ?? '').toLowerCase()
    const def = crownDef(KING_ID)
    const held = crownHoldings(ctx.player)

    if (!sub || ['status', 'info', 'help', 'card'].includes(sub)) {
      const owned = ctx.player?.ownedCharacters?.includes(KING_ID)
      const equipped = ctx.player?.equippedCharacter === KING_ID
      const lines = [
        `☀️ *KING YATO — Grace of the Crown*`,
        RULE,
        `${'★'.repeat(def?.stars ?? 6)} _${def?.stars ?? 6}-star · ${def?.rarity ?? 'boundless'} · an Astral Pass Elite reward — no spin, no drop, not season-locked_`,
        held.fused
          ? `👑 _You hold the fused *Queen-King* — he is in there, and so is she._`
          : equipped
            ? `✅ _Equipped. Nothing is being permitted to reach you._`
            : owned
              ? `📦 _Yours, but shelved. Equip him: *${pr}character equip ${KING_ID}*._`
              : `🌠 _Not yours yet — and not for sale. He is the tier *100* reward of the Astral Pass Elite column: *${pr}ap* to see where you are._`,
        ``,
        `👑 *GRACE OF THE CROWN* — passive, always on while he is worn, in dungeons, boss floors, swarms, rescues and duels alike.`,
        `🚫 Turns *1–${GRACE_LOCK_TURNS}*: the far side cannot attack you at all. \`.attack\`, \`.battle attack\`, the duel attack, attack skills and signature moves are all refused; only defending passes, and monsters simply do not move.`,
        `🌤️ From turn *${GRACE_WEAK_FROM_TURN}*: every attack aimed at you deals *${Math.round(GRACE_WEAK_PCT * 100)}%* less for the rest of the fight.`,
        `⚔️ Everything you deal is *${Math.round(GRACE_OWNER_PCT * 100)}%* stronger, every turn, the whole fight.`,
        `🌙 _His grace does not run against an opponent fielding Queen Esta — and hers does not run against his. The two crowns are never allowed to face each other; whoever holds both (${CONST_TURN_GATE.pvp}-turn fuse on *${pr}const* removed entirely) is the exception._`,
        ``,
        `💬 Talk to him (equipped only): *${pr}kyato <message>*`,
      ]
      const { sendImage } = await import('../lib/image.js')
      return sendImage(ctx, CROWN_ART.kingInfo, lines.join('\n'))
    }

    return crownChat(ctx, {
      persona: 'king',
      text: ctx.args.join(' ').trim(),
      strangerLines: STRANGER_LINES,
      unequippedLines: UNEQUIPPED_LINES,
      quietLine: QUIET,
    })
  },
}
