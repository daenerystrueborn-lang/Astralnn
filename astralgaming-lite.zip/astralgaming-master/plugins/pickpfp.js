import { selectProfileCosmeticCommand } from './profile-cosmetics.js'
export default {
  name: 'pickpfp', aliases: ['equipfp'], category: 'account', requiresPlayer: true,
  description: 'Select an unlocked profile picture',
  async run(ctx) { return selectProfileCosmeticCommand(ctx, 'pfp') },
}
