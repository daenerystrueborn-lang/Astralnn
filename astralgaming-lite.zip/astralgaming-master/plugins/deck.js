/**
 * deck.js — view all anime cards you own, as a paginated 3x3 art grid.
 * Usage: .deck [page]   (aliases: .collection, .coll, .mycards)
 */
import { config } from '../config.js'
import { tierStars, cardSellPrice, hasCardSeries, tierRank } from '../lib/card-engine.js'
import { CARDS_PER_PAGE, ownedCardToGrid, sendCardGrid } from '../lib/card-grid.js'

const PAGE_SIZE = CARDS_PER_PAGE

export default {
  name: 'deck',
  aliases: ['mycards', 'collection', 'coll'],
  category: 'cards',
  requiresPlayer: true,
  description: 'View your anime card collection as an image grid',

  async run(ctx) {
    const { args, reply, player } = ctx
    const cards = player.cards ?? []

    if (!cards.length) {
      return reply(
        `🎴 *${player.name}'s Deck*\n\n` +
        `_Empty._\n\n` +
        `_Cards spawn in enabled groups — grab one with *${config.prefix}collect <code>*._`
      )
    }

    const sorted = [...cards].sort((a, b) =>
      (tierRank(b.tier) - tierRank(a.tier)) || String(a.title ?? '').localeCompare(String(b.title ?? '')))
    const totalPages = Math.max(1, Math.ceil(sorted.length / PAGE_SIZE))
    const clamped = Math.min(Math.max(1, parseInt(args[0], 10) || 1), totalPages)
    const start = (clamped - 1) * PAGE_SIZE
    const pageItems = sorted.slice(start, start + PAGE_SIZE)

    const gridCards = pageItems.map(c => ownedCardToGrid(c, { waifu: player.waifuId === c.id }))
    const pageNote = totalPages > 1
      ? `Page ${clamped} / ${totalPages}`
      : `${sorted.length} cards`

    // The old text list stays as the fallback if canvas or an art URL dies:
    // the collection is never lost just because the picture failed.
    const text = pageItems.map(c => {
      const waifuTag = player.waifuId === c.id ? ' 💘' : ''
      const meta = [hasCardSeries(c.series) ? c.series : null, `☀️${cardSellPrice(c.tier)}`].filter(Boolean).join(' · ')
      return `${tierStars(c.tier)} *${c.title}*${waifuTag}\n     _${meta}_`
    }).join('\n\n')

    const caption =
      `🎴 *${player.name}'s Deck* — ${sorted.length} card${sorted.length === 1 ? '' : 's'}\n` +
      `_${pageNote}_` +
      (clamped < totalPages ? `\n▶️ *${config.prefix}deck ${clamped + 1}*` : '') +
      `\n_${config.prefix}card info <#>_ · _${config.prefix}setwaifu <name>_`

    return sendCardGrid(ctx, {
      title: `${player.name}'s Deck`,
      cards: gridCards,
      page: clamped,
      totalPages,
      footerNote: `${sorted.length} cards · ${config.prefix}deck ${clamped + 1}`,
      caption,
      fallbackText:
        `🎴 *${player.name}'s Deck* _(${sorted.length} cards)_\n\n` + text +
        (totalPages > 1 ? `\n\n📄 _Page ${clamped}/${totalPages}_` : '') +
        `\n\n_${config.prefix}setwaifu <name>_ · _${config.prefix}sellcard <name>_`,
    })
  },
}
