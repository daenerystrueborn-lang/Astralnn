import {finiteNumber} from '../lib/vitals.js'
/**
 * adventurers.js — the thirteen, and who they are.
 *
 * Read only in this phase. The Adventurers are Astral's own characters, not
 * NPCs, and the word NPC never appears in anything a player reads.
 *
 * Their stats, skills and personality come from the repo (see
 * lib/league/adventurer-repo.js), never from the database, so a content edit
 * ships with a deploy instead of drifting inside a save file. What the database
 * holds is their League duel record and their story purse.
 */
import { config } from '../config.js'
import {
  getLeague,
  leagueGate,
  seatOfAdventurer,
} from '../lib/league/league-repo.js'
import { rowForSeat, placeWord } from '../lib/league/league-table.js'
import {
  listAdventurers,
  getPersonality,
  getAdventurer,
  validationProblems,
  loreOf,
  findAdventurerByQuery,
} from '../lib/league/adventurer-repo.js'
import { lifeLines, portraitUrlOf } from '../lib/league/league-life.js'
import { getGuildDef } from '../lib/guild-repo.js'
import { replyAdventurerPortrait } from '../lib/portrait-reply.js'
import {
  renderAdventurersRoster,
  renderAdventurerLoreCard,
} from '../lib/league-adventurers-render.mjs'
import { loreCaption, loreListCaption } from '../lib/league/league-copy.js'

async function replyCard(ctx, renderFn, caption) {
  if (typeof ctx.replyImage === 'function' && typeof renderFn === 'function') {
    try {
      const png = await renderFn()
      if (png) return ctx.replyImage(png, caption)
    } catch {}
  }
  return ctx.reply(caption)
}

/** Where a composure becomes a line a player can read. */
const COMPOSURE_WORD = {
  dead_calm: '🧊 *dead calm*',
  steady: '⚖️ *steady*',
  playful: '🎭 *playful*',
  shifting: '🌀 *shifting*',
  loud: '🔥 *loud*',
}

function rosterList(league) {
  const lines = [
    '🌟👑 *THE ASTRAL LEAGUE · THE ADVENTURERS* 👑🌟',
    '━━━━━━━━━━━━━━━━━━━━',
    '⚔️ *Thirteen of them, and every one of them holds a permanent seat at the League table.*',
    '',
  ]
  for (const npc of listAdventurers()) {
    const seat = seatOfAdventurer(league, npc.id)
    const row = seat ? rowForSeat(league, seat.seat) : null
    const standing = row ? `🏅 *${placeWord(row.rank)} place*, *${row.points} points*` : '🪑 *not seated yet*'
    lines.push(`${npc.tier?.glyph ?? '🌟'} *${npc.name}*  ·  _${npc.byname ?? ''}_  ·  ${standing}`)
  }
  lines.push('')
  lines.push('━━━━━━━━━━━━━━━━━━━━')
  lines.push(`📖 *Inspect a dossier:* *${config.prefix}adventurers <name>*`)
  lines.push(`⚡ *Rivalries:* *${config.prefix}adventurers rivals*  ·  📰 *News:* *${config.prefix}adventurers news*`)
  return lines.join('\n')
}

function profile(db, league, npc) {
  const personality = getPersonality(npc.id)
  const seat = seatOfAdventurer(league, npc.id)
  const record = db?.data?.npcs?.adventurers?.[npc.id] ?? null
  const lines = [
    `${npc.tier?.glyph ?? '🌟'}🔥 *${npc.name}${npc.surname ? ` ${npc.surname}` : ''}* 🔥${npc.tier?.glyph ?? '🌟'}`,
    '━━━━━━━━━━━━━━━━━━━━',
  ]
  if (npc.byname) lines.push(`💬 *Epithet:* Called *"${npc.byname}"*.`)
  lines.push(`🎭 *Class & Tier:* Level *${npc.level?.value ?? '?'}* ${npc.raceId} *${npc.classId}*${npc.level?.reborn ? ', *reborn*' : ''}, *${npc.tier?.name ?? ''}* tier`)

  if (npc.stats) {
    lines.push(`❤️ *HP:* *${finiteNumber(npc.stats.maxHp).toLocaleString()}*  ·  🔷 *MP:* *${finiteNumber(npc.stats.maxMp).toLocaleString()}*`)
    lines.push(`⚔️ *STR:* *${npc.stats.str}*  ·  💨 *AGI:* *${npc.stats.agi}*  ·  ✨ *INT:* *${npc.stats.int}*  ·  🛡️ *DEF:* *${npc.stats.def}*  ·  🍀 *LCK:* *${npc.stats.lck}*`)
  }

  if (record?.guildId) {
    const guildName = getGuildDef(record.guildId)?.name
    if (guildName) lines.push(`🏰 *Guild:* *${guildName}*`)
  }
  if (record && Number.isFinite(record.level) && record.level !== npc.level?.value) {
    lines.push(`📈 *Grown:* now level *${record.level}* from their dungeon runs`)
  }
  if (record?.totals) {
    const conquered = Object.values(record.dungeonProgress ?? {}).filter((p) => p?.conquered).length
    lines.push(`🗺️ *Dungeons:* *${conquered}* conquered, *${record.totals.kills ?? 0}* floors cleared`)
    const conquests = (record.awards ?? []).filter((a) => a.kind === 'conquest').slice(-3)
    for (const a of conquests) lines.push(`🏆 Conquered *${a.locId}*`)
  }

  const hometown = npc.hometown?.name ?? personality?.identity?.hometown?.name
  if (hometown) lines.push(`🏘️ *Origin:* From *${hometown}*`)
  if (npc.specialty) lines.push(`⚔️ *Specialty:* _${npc.specialty}_`)
  if (npc.personality) lines.push(`🧠 *Demeanor:* ${npc.personality}`)

  if (personality) {
    if (personality.composure) lines.push(`🎙️ *Voice:* ${COMPOSURE_WORD[personality.composure] ?? personality.composure}`)
    if (personality.fighting?.style) lines.push(`🥊 *Combat Style:* ${personality.fighting.style}`)
    if (personality.commentary?.nicknames?.length) {
      lines.push(`📣 *Booth Nicknames:* The commentators call them *${personality.commentary.nicknames.slice(0, 2).join('* or *')}*.`)
    }
  }
  if (npc.powerSkill?.name) {
    lines.push('')
    lines.push(`🌟💥 *Power skill:* *${npc.powerSkill.name}*`)
    if (npc.powerSkill.blurb) lines.push(`   ✨ _${npc.powerSkill.blurb}_`)
  }
  if (npc.rival) {
    const rival = getAdventurer(npc.rival)
    lines.push(`⚡🔥 *Rival:* *${rival?.name ?? npc.rival}*`)
  } else {
    lines.push('⚡ *Rival:* none they will name.')
  }

  if (seat) {
    const row = rowForSeat(league, seat.seat)
    lines.push('')
    lines.push('━━━━━━━━━━━━━━━━━━━━')
    lines.push(`🏆 *Seat #${seat.seat}:* *${placeWord(row.rank)} place*, *${row.points} points*, *${row.wins} wins* and *${row.losses} losses*`)
  }
  if (record) {
    lines.push(...lifeLines(record))
  }
  return lines.join('\n')
}

export default {
  name: 'adventurers',
  aliases: ['advs', 'adv', 'roster'],
  category: 'social',
  requiresPlayer: false,
  description: `${config.prefix}adventurers — the thirteen Adventurers who hold seats in the Astral League.`,
  subcommands: ['news', 'rivals', 'lore'],

  async run(ctx) {
    const { db, args, reply } = ctx
    const gate = leagueGate(db)
    if (!gate.open) return reply(gate.message)

    const league = getLeague(db)
    const query = args.join(' ').trim().toLowerCase()

    if (!query) {
      const caption = rosterList(league)
      return replyCard(ctx, () => renderAdventurersRoster(league), caption)
    }

    if (query === 'lore' || query.startsWith('lore ') || query.startsWith('info ')) {
      const name = query.replace(/^(lore|info)\s*/, '')
      if (!name) return reply(loreListCaption(listAdventurers(), config.prefix))
      const found = findAdventurerByQuery(name)
      if (!found) return reply(`🌟❓ *No Adventurer called "${name}".* Try *${config.prefix}adventurers lore* for the thirteen.`)
      return replyCard(ctx, () => renderAdventurerLoreCard(found), loreCaption(loreOf(found)))
    }

    if (query === 'news') {
      return reply([
        '📰🔥 *ADVENTURER NEWS · ARENA BULLETIN* 🔥📰',
        '━━━━━━━━━━━━━━━━━━━━',
        '🍃 *Nothing to report today.*',
        '✨ _They keep their own lives between matches, and the news board opens once the season is under way._',
        '',
        `🌟 *Inspect the roster:* *${config.prefix}adventurers*`,
      ].join('\n'))
    }
    if (query === 'rivals') {
      const pairs = listAdventurers().filter(n => n.rival)
      if (!pairs.length) {
        return reply([
          '⚡🔥 *ASTRAL LEAGUE · RIVALS* 🔥⚡',
          '━━━━━━━━━━━━━━━━━━━━',
          '🕯️ *Nobody has named one yet.* _That changes the first time two of them meet twice in a season._',
        ].join('\n'))
      }
      const lines = [
        '⚡🔥 *ASTRAL LEAGUE · RIVALS* 🔥⚡',
        '━━━━━━━━━━━━━━━━━━━━',
        '🗡️ *Sworn arena blood feuds among the Thirteen:*',
        '',
      ]
      for (const npc of pairs) {
        const rival = getAdventurer(npc.rival)
        lines.push(`   ⚔️ *${npc.name}* and *${rival?.name ?? npc.rival}*`)
      }
      lines.push('')
      lines.push(`🥊 *Compare any pair:* *${config.prefix}league vs <name>*`)
      const caption = lines.join('\n')
      return replyCard(ctx, () => renderAdventurersRoster(league), caption)
    }

    const npc = listAdventurers().find(n =>
      n.id === query
      || n.name.toLowerCase() === query
      || `${n.name} ${n.surname ?? ''}`.trim().toLowerCase() === query)
      ?? listAdventurers().find(n => n.name.toLowerCase().includes(query))

    if (!npc) {
      const problems = validationProblems()
      return reply(problems.length
        ? `🌟⚠️ *Nobody by that name*, and the roster has *${problems.length}* content problem(s) the owner needs to clear.`
        : `🌟❓ *Nobody by that name.* Try *${config.prefix}adventurers* for the thirteen!`)
    }
    const record = db?.data?.npcs?.adventurers?.[npc.id] ?? null
    const text = profile(db, league, npc)
    // Their info is their own portrait with the text, nothing generated.
    return replyAdventurerPortrait(ctx, portraitUrlOf(npc), text)
  },
}
