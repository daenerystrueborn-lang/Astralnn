/**
 * sectstudy.js — `.study` : the manuals in the Library.
 *
 *   .study                    the shelves of the sect you are standing in
 *   .study <manual>           take one off the shelf (contribution, then hours)
 *   .study                    again, once the hours are in, to collect it
 *
 * What a manual teaches is written by the owner, not here: every shipped manual
 * has an empty technique list and the shapes (lib/sect-manuals.js) are waiting
 * for it. A manual is bound to one pair of hands: it is not traded and not
 * shared, and only a member studies their own sect's.
 */
import { config } from '../config.js'
import { studyCommand } from '../lib/sect-commands.js'
import { sectDoorRefusal } from '../lib/world-guards.js'

export default {
  name: 'study',
  aliases: ['manuals', 'manual'],
  category: 'sect',
  requiresPlayer: true,
  description: `${config.prefix}study [manual] — read a sect manual (or collect the one you are reading)`,
  subcommands: [
    { cmd: '<manual>', desc: 'take a manual off the shelf, by name or number' },
  ],

  async run(ctx) {
    const wrongWorld = sectDoorRefusal(ctx.player, {
      emoji: '📚', title: '*The training manuals are kept in a sect Library.*',
      here: { cmd: 'menu', label: 'see what Astra teaches instead' },
    })
    if (wrongWorld) return ctx.reply(wrongWorld)
    return studyCommand(ctx)
  },
}
