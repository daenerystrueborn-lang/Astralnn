/**
 * plugins/salvage.js — ♻️ Scrapyard: turn dead leftovers & unwanted gear into Solars.
 *
 *   .salvage                        view scrapable junk & unequipped bag summary
 *   .salvage junk                   scrap inert curios, stranded cosmetics & retired IDs
 *   .salvage <common|uncommon|rare|epic>
 *                                   bulk-scrap unequipped, non-enchanted gear of that rarity
 *   .salvage all                    scrap junk immediately (or preview bulk Common–Rare scrap)
 *   .salvage all confirm            scrap all junk + unequipped Common–Rare gear
 *   .salvage <item> [qty|all]       scrap specific unequipped item(s) for Solars
 */
import { config } from '../config.js'
import { allItems } from '../lib/game-data.js'
import { updatePlayer } from '../lib/player-repo.js'
import { getInventoryCap } from '../lib/inventory-limits.js'
import { CURIO_USES, isInertCurio, salvageValue, humanizeId, JUNK_VALUE } from '../lib/curios.js'
import { STARFALL_BOX_IDS } from '../lib/starfall-engine.js'
import { ensureCharacterSkins } from '../lib/character-skins.js'
import { addProfileCosmetic } from '../lib/profile-cosmetics.js'
import { isInSectEmpire } from '../lib/worlds.js'
import { recordSink } from '../lib/economy-ledger.js'

const itemMap = Object.fromEntries(allItems.map((i) => [i.id, i]))
const RULE = '━━━━━━━━━━━━━━━━━━━━'

const RARITY_FLOOR = Object.freeze({
  common:    25,
  uncommon:  75,
  rare:      220,
  epic:      600,
  legendary: 1500,
})

const BULK_GEAR_TYPES = new Set(['weapon', 'armor', 'accessory'])
const BULK_RARITIES = new Set(['common', 'uncommon', 'rare', 'epic'])
const BOX_IDS = new Set([...STARFALL_BOX_IDS, 'mythic_box', 'silver_chest', 'diamond_chest', 'core_chest'])
const PROTECTED_IDS = new Set(['blue_band', 'ha_neul', 'ghostblade', 'oliver-goggles', 'chains-of-resurrection'])

function hasEnchants(player, itemId) {
  const rec = player?.enchants?.[itemId]
  return Boolean(rec && typeof rec === 'object' && Object.keys(rec).length > 0)
}

function isBoxItem(id, item) {
  return BOX_IDS.has(id) || item?.type === 'box'
}

function isProtectedItem(id, item) {
  if (!item) return false
  if (PROTECTED_IDS.has(id)) return true
  if (item.exclusive || item.starterPackExclusive || item.named) return true
  if (item.rarity === 'mythic' || item.rarity === 'boundless') return true
  if (item.type === 'summon') return true
  if (CURIO_USES[id]) return true
  if ((Number(item.gemPrice) || 0) > 0) return true
  return false
}

function isStrandedBagCosmetic(item) {
  return item?.type === 'cosmetic' || item?.type === 'character'
}

function unitScrapValue(item) {
  if (!item) return JUNK_VALUE
  if (isInertCurio(item)) return salvageValue(item)
  if (isStrandedBagCosmetic(item)) return Math.max(Number(item.sellPrice) || 0, 250)
  const floor = RARITY_FLOOR[item.rarity] ?? 25
  return Math.max(Number(item.sellPrice) || 0, floor)
}

function preserveStrandedCosmetic(player, id, item) {
  if (!item) return
  if (item.slot === 'skin') {
    const skins = ensureCharacterSkins(player)
    if (!skins.owned[id]) skins.owned[id] = { level: 1, purchasedAt: Date.now(), source: 'salvage-repair' }
  } else if (item.slot === 'pfp') {
    addProfileCosmetic(player, 'profilePfp', id)
  } else if (item.slot === 'banner') {
    addProfileCosmetic(player, 'profileBanner', id)
  }
}

/**
 * Count how many unequipped copies of each item ID exist in `player.inventory`.
 * If 1 copy of `iron_sword` is equipped and 3 are in `inventory`, 2 are free to scrap.
 */
function countUnequippedBag(player) {
  const equippedCounts = {}
  for (const eqId of Object.values(player?.equipped ?? {})) {
    if (eqId) equippedCounts[eqId] = (equippedCounts[eqId] ?? 0) + 1
  }
  const bagCounts = {}
  for (const id of player?.inventory ?? []) {
    if (id == null || id === '') continue
    bagCounts[id] = (bagCounts[id] ?? 0) + 1
  }
  const freeCounts = {}
  for (const [id, total] of Object.entries(bagCounts)) {
    const reserved = equippedCounts[id] ?? 0
    // Only reserve against inventory if equipped copy also resides in inventory;
    // in most flows `equip` moves or tags the id, so reserving min(total, reserved)
    // guarantees we never scrap the copy currently worn.
    const available = Math.max(0, total - reserved)
    if (available > 0) freeCounts[id] = available
  }
  return freeCounts
}

/** Junk & dead-weight rows (`unknown`, inert `misc`, stranded `cosmetic`/`character`). */
export function scanJunkSalvage(player) {
  const freeCounts = countUnequippedBag(player)
  const rows = []
  for (const [id, count] of Object.entries(freeCounts)) {
    const item = itemMap[id]
    if (!item) {
      rows.push({ id, name: humanizeId(id), count, unit: JUNK_VALUE, kind: 'junk' })
    } else if (isInertCurio(item)) {
      rows.push({ id, name: item.name, count, unit: unitScrapValue(item), kind: 'curio', item })
    } else if (isStrandedBagCosmetic(item)) {
      rows.push({ id, name: item.name, count, unit: unitScrapValue(item), kind: 'cosmetic', item })
    }
  }
  return rows
}

/** Bulk-scrappable unequipped, non-enchanted, non-protected gear for a rarity set. */
export function scanGearSalvage(player, allowedRarities = new Set(['common', 'uncommon', 'rare'])) {
  const freeCounts = countUnequippedBag(player)
  const rows = []
  for (const [id, count] of Object.entries(freeCounts)) {
    const item = itemMap[id]
    if (!item) continue
    if (!BULK_GEAR_TYPES.has(item.type)) continue
    if (!allowedRarities.has(item.rarity ?? 'common')) continue
    if (isProtectedItem(id, item) || isBoxItem(id, item)) continue
    if (hasEnchants(player, id)) continue
    rows.push({ id, name: item.name, count, unit: unitScrapValue(item), kind: 'gear', rarity: item.rarity ?? 'common', item })
  }
  return rows
}

const rowTotal = (r) => r.count * r.unit
const sumRows = (rows) => rows.reduce((s, r) => s + rowTotal(r), 0)
const sumSlots = (rows) => rows.reduce((s, r) => s + r.count, 0)

function normalizeKey(s) {
  return String(s ?? '').toLowerCase().replace(/[^a-z0-9]+/g, '')
}

function removeCopiesFromInventory(player, targets) {
  const remainingToRemove = new Map(targets.map((t) => [t.id, t.count]))
  const next = []
  for (const id of player.inventory ?? []) {
    const need = remainingToRemove.get(id) ?? 0
    if (need > 0) {
      remainingToRemove.set(id, need - 1)
      const item = itemMap[id]
      if (item && isStrandedBagCosmetic(item)) preserveStrandedCosmetic(player, id, item)
    } else {
      next.push(id)
    }
  }
  player.inventory = next
}

function renderPreview(player, pr) {
  const junk = scanJunkSalvage(player)
  const gear = scanGearSalvage(player, BULK_RARITIES)
  const cap = getInventoryCap(player)
  const held = (player.inventory ?? []).length

  const lines = [
    `♻️ *SCRAPYARD*`,
    RULE,
    `_Turn dead leftovers and unwanted unequipped items into Solars._`,
    `🎒 Bag: *${held}/${cap}*`,
  ]

  if (junk.length) {
    lines.push(
      ``,
      `🗑️ *Dead Weight (${sumSlots(junk)} slot${sumSlots(junk) === 1 ? '' : 's'} · ☀️ ${sumRows(junk).toLocaleString()})*`,
      ...junk.slice(0, 8).map((r) => `  ▸ *${r.name}*${r.count > 1 ? ` ×${r.count}` : ''} · ☀️ ${rowTotal(r).toLocaleString()}`),
    )
    if (junk.length > 8) lines.push(`  _…and ${junk.length - 8} more_`)
  }

  if (gear.length) {
    const byRarity = {}
    for (const r of gear) {
      const k = r.rarity
      byRarity[k] = byRarity[k] ?? { slots: 0, solars: 0 }
      byRarity[k].slots += r.count
      byRarity[k].solars += rowTotal(r)
    }
    lines.push(``, `⚔️ *Unequipped Gear Ready to Scrap*`)
    for (const rar of ['common', 'uncommon', 'rare', 'epic']) {
      if (!byRarity[rar]) continue
      const label = rar[0].toUpperCase() + rar.slice(1)
      lines.push(`  ▸ *${label}:* ${byRarity[rar].slots} item${byRarity[rar].slots === 1 ? '' : 's'} · ☀️ ${byRarity[rar].solars.toLocaleString()} _(${pr}salvage ${rar})_`)
    }
  }

  if (!junk.length && !gear.length) {
    lines.push(``, `_No junk or unequipped Common–Epic gear in your bag right now._`)
  }

  lines.push(
    ``,
    `✨ *Commands*`,
    `  ▸ *${pr}salvage <item> [qty|all]* — scrap specific item(s)`,
    `  ▸ *${pr}salvage common* _(or uncommon / rare / epic)_`,
    ...(junk.length ? [`  ▸ *${pr}salvage junk* — scrap dead leftovers`] : []),
    `  ▸ *${pr}salvage all confirm* — scrap all junk & Common–Rare gear`,
  )
  return lines.join('\n')
}

function formatScrapReceipt(targets, total, balance, used, cap) {
  const slots = sumSlots(targets)
  const shown = targets.slice(0, 10).map(
    (r) => `  ▸ *${r.name}*${r.count > 1 ? ` ×${r.count}` : ''} · ☀️ ${rowTotal(r).toLocaleString()}`,
  )
  if (targets.length > 10) shown.push(`  _…and ${targets.length - 10} more_`)

  return [
    `♻️ *SALVAGED*`,
    RULE,
    ...shown,
    ``,
    `☀️ Earned: *+${total.toLocaleString()} Solars*`,
    `💳 Balance: *${balance.toLocaleString()} Solars*`,
    `🎒 Bag: *${used}/${cap}* _(freed ${slots} slot${slots === 1 ? '' : 's'})_`,
  ].join('\n')
}

export default {
  name: 'salvage',
  aliases: ['scrap'],
  category: 'inventory',
  requiresPlayer: true,
  description: 'Scrap leftovers or unwanted unequipped items for Solars',
  subcommands: [
    { cmd: '', desc: 'view scrapable junk & unequipped gear' },
    { cmd: '<item> [qty|all]', desc: 'scrap specific unequipped item(s)' },
    { cmd: '<common|uncommon|rare|epic>', desc: 'bulk-scrap unequipped gear by rarity' },
    { cmd: 'junk', desc: 'scrap dead curios & retired leftovers' },
    { cmd: 'all confirm', desc: 'scrap all junk & unequipped Common–Rare gear' },
  ],

  async run(ctx) {
    const pr = config.prefix
    if (isInSectEmpire(ctx.player)) {
      return ctx.reply(
        `♻️ The Astra Scrapyard doesn't reach the Sect.\n` +
        `Use *${pr}shop sell* or *${pr}drop* for Sect items.`,
      )
    }

    const args = (ctx.args ?? []).map((a) => String(a ?? '').trim()).filter(Boolean)
    if (!args.length) {
      return ctx.reply(renderPreview(ctx.player, pr))
    }

    const first = args[0].toLowerCase()
    const second = (args[1] ?? '').toLowerCase()

    // 1) `.salvage junk`
    if (first === 'junk' || first === 'curios' || first === 'leftovers') {
      let out = null
      await updatePlayer(ctx.db, ctx.from, (player) => {
        const targets = scanJunkSalvage(player)
        if (!targets.length) { out = { reason: 'none' }; return player }
        removeCopiesFromInventory(player, targets)
        const total = sumRows(targets)
        player.wallet = player.wallet ?? {}
        player.wallet.solars = (player.wallet.solars ?? 0) + total
        out = { reason: 'ok', targets, total, balance: player.wallet.solars, used: player.inventory.length, cap: getInventoryCap(player) }
        return player
      })
      if (out?.reason !== 'ok') return ctx.reply(`♻️ No dead curios or retired leftovers in your bag.`)
      return ctx.reply(formatScrapReceipt(out.targets, out.total, out.balance, out.used, out.cap))
    }

    // 2) `.salvage common | uncommon | rare | epic`
    if (BULK_RARITIES.has(first) && (!second || second === 'all' || second === 'confirm')) {
      let out = null
      await updatePlayer(ctx.db, ctx.from, (player) => {
        const targets = scanGearSalvage(player, new Set([first]))
        if (!targets.length) { out = { reason: 'none' }; return player }
        removeCopiesFromInventory(player, targets)
        const total = sumRows(targets)
        player.wallet = player.wallet ?? {}
        player.wallet.solars = (player.wallet.solars ?? 0) + total
        out = { reason: 'ok', targets, total, balance: player.wallet.solars, used: player.inventory.length, cap: getInventoryCap(player) }
        return player
      })
      if (out?.reason !== 'ok') {
        return ctx.reply(`♻️ You have no unequipped, non-enchanted *${first}* gear to scrap.`)
      }
      return ctx.reply(formatScrapReceipt(out.targets, out.total, out.balance, out.used, out.cap))
    }

    // 3) `.salvage all` / `.salvage all confirm`
    if (first === 'all') {
      const confirmed = second === 'confirm'
      let out = null
      await updatePlayer(ctx.db, ctx.from, (player) => {
        const junk = scanJunkSalvage(player)
        const gear = scanGearSalvage(player, new Set(['common', 'uncommon', 'rare']))
        if (confirmed) {
          const targets = [...junk, ...gear]
          if (!targets.length) { out = { reason: 'none' }; return player }
          removeCopiesFromInventory(player, targets)
          const total = sumRows(targets)
          player.wallet = player.wallet ?? {}
          player.wallet.solars = (player.wallet.solars ?? 0) + total
          out = { reason: 'ok', targets, total, balance: player.wallet.solars, used: player.inventory.length, cap: getInventoryCap(player) }
          return player
        }
        // Without `confirm`, scrap safe junk immediately (backwards-compatible);
        // if there is no junk, preview Common–Rare gear instead of saying "nothing".
        if (junk.length) {
          removeCopiesFromInventory(player, junk)
          const total = sumRows(junk)
          player.wallet = player.wallet ?? {}
          player.wallet.solars = (player.wallet.solars ?? 0) + total
          out = { reason: 'ok', targets: junk, total, balance: player.wallet.solars, used: player.inventory.length, cap: getInventoryCap(player) }
          return player
        }
        if (gear.length) {
          out = { reason: 'preview_gear', slots: sumSlots(gear), total: sumRows(gear) }
          return player
        }
        out = { reason: 'none' }
        return player
      })

      if (out?.reason === 'ok') {
        return ctx.reply(formatScrapReceipt(out.targets, out.total, out.balance, out.used, out.cap))
      }
      if (out?.reason === 'preview_gear') {
        return ctx.reply(
          `♻️ *BULK SCRAP PREVIEW*\n${RULE}\n` +
          `Found *${out.slots}* unequipped Common–Rare gear item${out.slots === 1 ? '' : 's'} worth *☀️ ${out.total.toLocaleString()} Solars*.\n\n` +
          `▸ Run *${pr}salvage all confirm* to scrap them all\n` +
          `▸ Or scrap one tier with *${pr}salvage common* / *uncommon* / *rare*`,
        )
      }
      return ctx.reply(`♻️ Nothing ready for bulk salvage. Use *${pr}salvage <item>* to scrap a specific item.`)
    }

    // 4) `.salvage <item> [qty|all]`
    let wantAll = false
    let qty = 1
    let nameParts = [...args]
    const tail = args[args.length - 1].toLowerCase()
    if (args.length > 1 && (tail === 'all' || tail === 'max')) {
      wantAll = true
      nameParts = args.slice(0, -1)
    } else if (args.length > 1 && /^\d+$/.test(tail)) {
      qty = Math.max(1, Math.min(999, parseInt(tail, 10)))
      nameParts = args.slice(0, -1)
    }
    const query = nameParts.join(' ').trim()
    const qLower = query.toLowerCase()
    const qKey = normalizeKey(query)

    let out = null
    await updatePlayer(ctx.db, ctx.from, (player) => {
      const freeCounts = countUnequippedBag(player)
      const bagIds = [...new Set((player.inventory ?? []).filter(Boolean))]

      // Match against items actually in the player's bag first
      let matchedId = bagIds.find((id) => id.toLowerCase() === qLower || normalizeKey(id) === qKey)
      if (!matchedId) {
        matchedId = bagIds.find((id) => {
          const item = itemMap[id]
          const nm = item ? item.name : humanizeId(id)
          return nm.toLowerCase() === qLower || normalizeKey(nm) === qKey
        })
      }
      if (!matchedId) {
        matchedId = bagIds.find((id) => {
          const item = itemMap[id]
          const nm = item ? item.name : humanizeId(id)
          return nm.toLowerCase().includes(qLower) || id.toLowerCase().includes(qLower) || (qKey && normalizeKey(nm).includes(qKey))
        })
      }

      if (!matchedId) {
        out = { reason: 'missing' }
        return player
      }

      const item = itemMap[matchedId]
      if (isBoxItem(matchedId, item)) {
        out = { reason: 'box', name: item?.name ?? humanizeId(matchedId) }
        return player
      }
      if (isProtectedItem(matchedId, item)) {
        out = { reason: 'protected', name: item?.name ?? humanizeId(matchedId) }
        return player
      }

      const available = freeCounts[matchedId] ?? 0
      if (available <= 0) {
        out = { reason: 'equipped', name: item?.name ?? humanizeId(matchedId) }
        return player
      }

      const count = wantAll ? available : Math.min(qty, available)
      const unit = unitScrapValue(item)
      const target = {
        id: matchedId,
        name: item ? item.name : humanizeId(matchedId),
        count,
        unit,
        item,
      }
      removeCopiesFromInventory(player, [target])
      const total = rowTotal(target)
      player.wallet = player.wallet ?? {}
      player.wallet.solars = (player.wallet.solars ?? 0) + total
      recordSink(ctx.db, 'salvage_item', { items: count })

      out = {
        reason: 'ok',
        targets: [target],
        total,
        balance: player.wallet.solars,
        used: player.inventory.length,
        cap: getInventoryCap(player),
      }
      return player
    })

    if (out?.reason === 'missing') {
      return ctx.reply(`❌ You don't have *"${query}"* in your bag. Check *${pr}inv*.`)
    }
    if (out?.reason === 'box') {
      return ctx.reply(`📦 *${out.name}* is a mystery box — open it with *${pr}openbox* instead!`)
    }
    if (out?.reason === 'protected') {
      return ctx.reply(`🛡️ *${out.name}* is a protected mythic/exclusive item and cannot be scrapped.`)
    }
    if (out?.reason === 'equipped') {
      return ctx.reply(`⚡ *${out.name}* is currently equipped. Unequip it first if you want to scrap it.`)
    }
    return ctx.reply(formatScrapReceipt(out.targets, out.total, out.balance, out.used, out.cap))
  },
}
