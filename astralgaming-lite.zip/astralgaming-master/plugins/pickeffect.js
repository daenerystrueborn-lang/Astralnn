import { selectProfileCosmeticCommand } from './profile-cosmetics.js'
export default {
  name: 'pickeffect',
  aliases: ['equipeffect', 'gifeffect', 'pickgif'],
  category: 'account',
  requiresPlayer: true,
  description: 'Select an unlocked animated GIF Effect for .me',
  async run(ctx) { return selectProfileCosmeticCommand(ctx, 'effect') },
}
