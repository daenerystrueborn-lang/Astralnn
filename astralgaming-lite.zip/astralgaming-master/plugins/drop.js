/**
 * <prefix>drop <item id or partial name> [confirm]
 * Permanently removes one instance of an item from inventory.
 * Requires the "confirm" flag to prevent accidental drops.
 * Equipped items must be unequipped first.
 */

import { config } from '../config.js'
import { allItems } from '../lib/game-data.js'
import { updatePlayer } from '../lib/player-repo.js'
import { isInSectEmpire } from '../lib/worlds.js'
import {
  STONE_NAME, ensureItems, itemById, matchItem, countOf, artifactsOf,
  isEquippedUid, removeItem, takeStones,
} from '../lib/sect-items.js'
import { pillById, selectPillLots } from '../lib/sect-pills.js'
import { qualityLabel } from '../lib/sect-marks.js'

const itemMap = Object.fromEntries(allItems.map((i) => [i.id, i]))

/** Find first matching item id in the player's inventory (exact id or partial name). */
function findInInventory(inventory, query) {
  const q = query.toLowerCase()
  if (inventory.includes(q)) return q
  for (const id of inventory) {
    const item = itemMap[id]
    if (item && item.name.toLowerCase().includes(q)) return id
  }
  return null
}

function isStoneWord(word) {
  return ['stone', 'stones', 'spiritstone', 'spiritstones', 'spirit_stone', 'spirit_stones'].includes(String(word ?? '').toLowerCase())
}

async function runSectDrop(ctx) {
  const p = config.prefix
  const args = (ctx.args ?? []).map(value => String(value ?? ''))
  if (!args.length) {
    return ctx.reply(`Usage: *${p}drop <Sect item> [count] confirm* or *${p}drop stones <count> confirm*`)
  }

  const hasConfirm = args.at(-1).toLowerCase() === 'confirm'
  const parts = hasConfirm ? args.slice(0, -1) : args
  let amount = 1
  if (parts.length > 1 && /^\d+$/.test(parts.at(-1)) && parts.at(-2).toLowerCase() !== 'grade') amount = Number(parts.pop())
  let grade = null
  if (parts.length >= 2 && parts.at(-2).toLowerCase() === 'grade') {
    grade = Number(parts.pop())
    parts.pop()
    if (!Number.isInteger(grade) || grade < 1 || grade > 9) return ctx.reply('💊 _Choose a whole pill grade from 1 to 9._')
  }
  const query = parts.join(' ').trim()
  if (!query || !Number.isSafeInteger(amount) || amount <= 0) {
    return ctx.reply(`Usage: *${p}drop <Sect item> [count] confirm* or *${p}drop stones <count> confirm*`)
  }

  const sect = ctx.player?.sect
  if (!sect) return ctx.reply(`🚪 *The mountain has no Sect inventory for you.*`)
  if (isStoneWord(query)) {
    if (grade != null) return ctx.reply('💊 _Only pills have a selectable grade._')
    const held = Math.max(0, Math.round(Number(sect.spiritStones) || 0))
    if (amount > held) {
      return ctx.reply(`❌ You hold only *${held} ${STONE_NAME}*.`)
    }
    if (!hasConfirm) {
      return ctx.reply(`⚠️ Permanently drop *${amount} ${STONE_NAME}*? This cannot be undone.\n\nRe-send: *${p}drop stones ${amount} confirm*`)
    }
    let spent = 0
    await updatePlayer(ctx.db, ctx.player.id, fresh => {
      const result = takeStones(fresh?.sect, amount)
      if (result.ok) spent = result.spent
    }, { critical: true })
    if (!spent) return ctx.reply(`❌ Your Sect purse changed before the drop. Nothing was removed.`)
    return ctx.reply(`🗑️ *${spent} ${STONE_NAME}* dropped and gone forever.`)
  }

  const entry = matchItem(query)
  if (!entry) {
    return ctx.reply(`❌ *"${query}"* is not a Sect item. Use *${p}inventory* to see your Sect bag.`)
  }
  if (grade != null && entry.kind !== 'pill') return ctx.reply('💊 _Only pills have a selectable grade._')
  const pillPlan = entry.kind === 'pill' ? selectPillLots(sect, pillById(entry.id), { grade, count: amount }) : null
  if (entry.kind === 'pill' && !pillPlan) {
    return ctx.reply(`❌ _You do not hold ${amount} ${grade == null ? '' : `grade ${grade} `}${entry.name}._`)
  }
  if (entry.kind === 'artifact') {
    const held = artifactsOf(sect, entry.id)
    const free = held.filter(record => !isEquippedUid(sect, record.uid) && record.bonded !== true && record.bound !== true)
    if (free.length < amount) {
      const protectedCount = held.length - free.length
      return ctx.reply(protectedCount
        ? `🚫 *${entry.name}* is equipped, bonded, or bound. Unequip/unbond it first; protected artifacts cannot be dropped.`
        : `❌ You hold only *${free.length} unbound ${entry.name}*.`)
    }
  } else if (amount > countOf(sect, entry.id)) {
    return ctx.reply(`❌ You do not have *${amount} ${entry.name}* in your Sect bag.`)
  }

  if (!hasConfirm) {
    return ctx.reply(
      `⚠️ Permanently drop *${amount} ${entry.name}*? This cannot be undone.` +
      (pillPlan ? `\n${pillPlan.map(lot => `• ×${lot.count} ${lot.grade == null ? 'realm-scaled' : `grade ${lot.grade}`}${lot.quality ? `, ${qualityLabel(lot.quality)}` : ''}`).join('\n')}` : '') +
      `\n\nRe-send: *${p}drop ${entry.id}${grade != null ? ` grade ${grade}` : ''}${amount > 1 ? ` ${amount}` : ''} confirm*`,
    )
  }

  let removed = 0
  let reason = null
  await updatePlayer(ctx.db, ctx.player.id, fresh => {
    const profile = fresh?.sect
    if (!profile) { reason = 'no-record'; return }
    if (entry.kind !== 'artifact') {
      // Validate the same lot chosen at command entry inside the write. If the
      // bag changed in the meantime, refuse rather than discard a substitute.
      const result = removeItem(profile, entry.id, amount, pillPlan ? { lots: pillPlan } : {})
      if (result.ok) removed = result.removed
      else reason = result.reason
      return
    }
    const bag = ensureItems(profile)
    const candidates = artifactsOf(profile, entry.id)
      .filter(record => !isEquippedUid(profile, record.uid) && record.bonded !== true && record.bound !== true)
      .slice(0, amount)
    if (candidates.length < amount) { reason = 'protected-or-missing'; return }
    const uids = new Set(candidates.map(record => String(record.uid)))
    bag.artifacts = bag.artifacts.filter(record => !uids.has(String(record.uid)))
    removed = candidates.length
  }, { critical: true })

  if (!removed) {
    return ctx.reply(reason === 'protected-or-missing'
      ? `🚫 *${entry.name}* changed before the drop or is protected. Nothing was removed.`
      : `❌ *${entry.name}* is no longer in your Sect bag. Nothing was removed.`)
  }
  return ctx.reply(`🗑️ *${removed} ${entry.name}* dropped from the Sect bag and gone forever.`)
}

export default {
  name: 'drop',
  aliases: ['discard'],
  category: 'inventory',
  description: `${config.prefix}drop <item> [confirm] — permanently remove an item from your inventory; in the Sect Empire it can also drop Sect items and Spirit Stones.`,
  subcommands: [
    { cmd: '<Sect item> [count] confirm', desc: 'permanently drop an unbound Sect item' },
    { cmd: 'stones <count> confirm', desc: 'permanently drop Spirit Stones' },
  ],
  requiresPlayer: true,

  async run(ctx) {
    const { player, args, db } = ctx

    if (isInSectEmpire(player)) return runSectDrop(ctx)

    if (!args || args.length === 0) {
      return ctx.reply(`Usage: *${config.prefix}drop <item id or name> confirm*`)
    }

    // Split off trailing "confirm" flag.
    const hasConfirm = args[args.length - 1].toLowerCase() === 'confirm'
    const queryParts = hasConfirm ? args.slice(0, -1) : args
    const query = queryParts.join(' ')

    if (!query) {
      return ctx.reply(`Usage: *${config.prefix}drop <item id or name> confirm*`)
    }

    const foundId = findInInventory(player.inventory ?? [], query)

    if (!foundId) {
      return ctx.reply(
        `❌ *"${query}"* not found in your inventory.\n` +
        `Use *${config.prefix}inventory* to see what you're carrying.`,
      )
    }

    const item = itemMap[foundId]
    const itemName = item?.name ?? foundId

    // Check if the item is currently equipped.
    const equipped = player.equipped ?? {}
    const isEquipped = Object.values(equipped).includes(foundId)
    if (isEquipped) {
      const slot = Object.keys(equipped).find((k) => equipped[k] === foundId)
      return ctx.reply(
        `❌ *${itemName}* is currently equipped in your *${slot}* slot.\n` +
        `Use *${config.prefix}unequip ${slot}* first, then drop it.`,
      )
    }

    // Require explicit confirm flag.
    if (!hasConfirm) {
      return ctx.reply(
        `⚠️ Are you sure you want to permanently drop *${itemName}*? This cannot be undone.\n\n` +
        `Re-send: *${config.prefix}drop ${foundId} confirm*`,
      )
    }

    // Perform the drop.
    let raceAborted = false

    await updatePlayer(db, player.id, (p) => {
      const inv = p.inventory ?? []
      const idx = inv.indexOf(foundId)
      if (idx === -1) {
        raceAborted = true
        return // item no longer present — abort without mutation
      }
      inv.splice(idx, 1)
      p.inventory = inv
    })

    if (raceAborted) {
      return ctx.reply(
        `❌ *${itemName}* is no longer in your inventory. Inventory state changed — please try again.`,
      )
    }

    return ctx.reply(`🗑️ *${itemName}* has been dropped and is gone forever.`)
  },
}
