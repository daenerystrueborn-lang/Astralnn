/**
 * transfer.js — now delegates to lib/astralpay.js / lib/transfer-guards.js.
 * .send solars → sendSolars() in lib/astralpay.js (same logic as .pay)
 * .send item   → unchanged, handled locally below
 * Guards (resolveTargetJid, MIN_LEVEL, cooldown) from lib/transfer-guards.js.
 *
 * DO NOT DELETE — kept so .send / .give / .transfer muscle-memory commands
 * keep working exactly as before. See plugins/astralpay.js for the hub.
 */
import { config } from '../config.js'
import { updateAllPlayers, getPlayer, playerExists } from '../lib/player-repo.js'
import { allItems, characters, characterMap } from '../lib/game-data.js'
import { hasInventoryRoom, inventoryFullMessage } from '../lib/inventory-limits.js'
import { sendSolars } from '../lib/astralpay.js'
import { rarityRank } from '../lib/rarity.js'
import {
  MIN_LEVEL,
  TRANSFER_COOLDOWN_MS,
  MAX_SOLARS_PER_TRANSFER,
  resolveTargetJid,
  runTransferGuards,
} from '../lib/transfer-guards.js'

// ── Character transfer ──────────────────────────────────────────────────
// Characters are one-per-account (plugins/character.js, every *-spin.js:
// `if (!ownedCharacters.includes(id)) push(id)`), never stacked like items.
// So "send character" isn't a quantity move like items/solars, it's a
// full handoff: the sender loses it entirely, the recipient gains it,
// guarded so neither side can end up in a state normal play can't reach.
//
// Capped at SPARK — two stars and below (rarityRank <= 2, see lib/rarity.js)
// on purpose: paid/rare pulls are the bot's monetization and reward layer. An
// uncapped character-send would let one account fund pulls, then gift every
// high-rarity hit to a second (or a paying customer's) account, laundering RNG
// the same way open gem transfers would launder currency — the exact risk this
// file already blocks gems for. Two stars and below are starter/low-value
// pulls, so gifting them costs the sender something (their only copy) without
// creating a duplication or resale path for anything worth protecting.
//
// The threshold is written as a character tier ('spark'), not as the item word
// 'uncommon' it used to borrow. Characters stopped using the item ladder when
// every star rung got its own name (lib/rarity.js CHARACTER_TIERS), and a rank
// borrowed from the item words would have silently re-opened this door the day
// 'uncommon' stopped existing on a character.
const MAX_SEND_RARITY_RANK = rarityRank('spark')

function findCharacterDef(query) {
  const q = query.toLowerCase().trim()
  return characters.find(c => c.id.toLowerCase() === q) ??
    characters.find(c => c.name.toLowerCase() === q) ??
    characters.find(c => c.id.toLowerCase().includes(q) || c.name.toLowerCase().includes(q))
}

async function sendCharacter(ctx, targetJid, query) {
  const p = config.prefix
  if (!query) {
    return ctx.reply(`❓ Usage: *${p}send character <@player> <character name>*\nExample: *${p}send character @friend willow*`)
  }

  const messages = []
  const sendReply = ctx.reply
  ctx = { ...ctx, reply: async text => { messages.push(text) } }
  let outcome = null // { ok:false } | { ok:true, charDef }

  // Validate, remove and credit inside one writer transaction.
  await updateAllPlayers(ctx.db, async () => {
    const sender = getPlayer(ctx.db, ctx.from)
    if (!sender) { outcome = { ok: false }; return false }
    const guard = await runTransferGuards(ctx, sender, targetJid)
    if (guard) { outcome = { ok: false }; return false }

    const charDef = findCharacterDef(query)
    if (!charDef) {
      await ctx.reply(`❌ No character matching *"${query}"* found.`)
      outcome = { ok: false }
      return false
    }

    const owned = sender.ownedCharacters ?? []
    if (!owned.includes(charDef.id)) {
      await ctx.reply(`❌ You don't own *${charDef.name}*.`)
      outcome = { ok: false }
      return false
    }

    if (rarityRank(charDef.rarity) > MAX_SEND_RARITY_RANK) {
      await ctx.reply(
        `❌ *${charDef.name}* is too rare to send (${charDef.rarity}). ` +
        `Only uncommon and below can be transferred between players.`
      )
      outcome = { ok: false }
      return false
    }

    const recipientNow = getPlayer(ctx.db, targetJid)
    if ((recipientNow?.ownedCharacters ?? []).includes(charDef.id)) {
      await ctx.reply(`❌ They already own *${charDef.name}*.`)
      outcome = { ok: false }
      return false
    }

    if (sender.equippedCharacter === charDef.id) {
      await ctx.reply(`❌ Unequip *${charDef.name}* before sending it.`)
      outcome = { ok: false }; return false
    }
    sender.ownedCharacters = owned.filter(id => id !== charDef.id)
    sender.lastTransferAt = Date.now()

    recipientNow.ownedCharacters = [...(recipientNow.ownedCharacters ?? []), charDef.id]
    outcome = { ok: true, charDef }
    return true
  }, { requireWrite: true })

  for (const text of messages) await sendReply(text)
  ctx = { ...ctx, reply: sendReply }
  if (!outcome?.ok) return

  const { charDef } = outcome

  const recipientName = getPlayer(ctx.db, targetJid)?.name ?? 'player'
  return ctx.reply(
    `🎭 *Sent ${charDef.name}* to *${recipientName}!*\n` +
    `_You no longer own this character._`
  )
}

function findItemDef(query) {
  const q = query.toLowerCase().trim()
  return allItems.find(i => i.id.toLowerCase() === q) ??
    allItems.find(i => i.name.toLowerCase() === q) ??
    allItems.find(i => i.id.toLowerCase().includes(q) || i.name.toLowerCase().includes(q))
}

async function sendItem(ctx, targetJid, query, qtyRaw) {
  const p = config.prefix
  if (!query) {
    return ctx.reply(`❓ Usage: *${p}send item <@player> <item name> [qty]*\nExample: *${p}send item @friend iron_ore 3*`)
  }
  const qty = Math.max(1, parseInt(qtyRaw, 10) || 1)

  // Validate recipient capacity and move both inventories under one lock.
  const messages = []
  const sendReply = ctx.reply
  ctx = { ...ctx, reply: async text => { messages.push(text) } }
  let outcome = null // { ok:false } | { ok:true, itemDef, owned }

  await updateAllPlayers(ctx.db, async () => {
    const sender = getPlayer(ctx.db, ctx.from)
    if (!sender) { outcome = { ok: false }; return false }
    const guard = await runTransferGuards(ctx, sender, targetJid)
    if (guard) { outcome = { ok: false }; return false }

    const inv = sender.inventory ?? []
    const itemDef = findItemDef(query)
    if (!itemDef) {
      await ctx.reply(`❌ No item matching *"${query}"* found.`)
      outcome = { ok: false }
      return false
    }

    const owned = inv.filter(id => id === itemDef.id).length
    if (owned < qty) {
      await ctx.reply(`❌ You only have *${owned}x ${itemDef.name}*, can't send *${qty}*.`)
      outcome = { ok: false }
      return false
    }

    const recipientNow = getPlayer(ctx.db, targetJid)
    if (!hasInventoryRoom(recipientNow, qty)) {
      await ctx.reply(inventoryFullMessage(recipientNow.name ?? 'They'))
      outcome = { ok: false }
      return false
    }

    // Remove items from sender
    let removed = 0
    sender.inventory = inv.filter(id => {
      if (id === itemDef.id && removed < qty) { removed++; return false }
      return true
    })
    sender.lastTransferAt = Date.now()

    recipientNow.inventory = [...(recipientNow.inventory ?? []), ...Array(qty).fill(itemDef.id)]
    outcome = { ok: true, itemDef, owned }
    return true
  }, { requireWrite: true })

  for (const text of messages) await sendReply(text)
  ctx = { ...ctx, reply: sendReply }
  if (!outcome?.ok) return

  const { itemDef, owned } = outcome

  const recipientName = getPlayer(ctx.db, targetJid)?.name ?? 'player'
  return ctx.reply(
    `🎒 *Sent ${qty}x ${itemDef.name}* to *${recipientName}!*\n` +
    `_You have ${owned - qty}x ${itemDef.name} remaining._`
  )
}

export default {
  name: 'send',
  aliases: ['give', 'transfer'],
  category: 'economy',
  requiresPlayer: true,
  description: 'Send solars, items, or low-rarity characters to another player',

  async run(ctx) {
    const p = config.prefix
    const [type, targetRaw, ...rest] = ctx.args

    if (!type) {
      return ctx.reply(
        `💸 *TRANSFERS*\n\n` +
        `*${p}send solars <target> <amount>*\n` +
        `_Example: ${p}send solars @friend 100_\n\n` +
        `*${p}send item <target> <item> [qty]*\n` +
        `_Example: ${p}send item @friend iron_ore 3_\n\n` +
        `*${p}send character <target> <character>*\n` +
        `_Example: ${p}send character @friend willow_\n` +
        `_Uncommon and below only. You lose it, they gain it._\n\n` +
        `_Target can be a reply, an @mention, or a phone number._\n\n` +
        `⚠️ Gems can't be transferred — they're account-bound.\n` +
        `📋 Level ${MIN_LEVEL}+ · 5 min cooldown · Max ☀️${MAX_SOLARS_PER_TRANSFER.toLocaleString()} per transfer.\n\n` +
        `_Also try: *${p}pay* · *${p}tip* · *${p}apay* (AstralPay hub)_`
      )
    }

    const targetJid = resolveTargetJid(ctx, targetRaw)
    const sub = type.toLowerCase()

    if (sub === 'solars' || sub === 'solar' || sub === 'gold' || sub === '☀️') {
      return sendSolars(ctx, targetJid, rest[0], rest.slice(1).join(' ') || undefined)
    }
    if (sub === 'item' || sub === 'items') {
      return sendItem(ctx, targetJid, rest[0], rest[1])
    }
    if (sub === 'character' || sub === 'char') {
      return sendCharacter(ctx, targetJid, rest.join(' '))
    }
    if (sub === 'gems' || sub === 'gem' || sub === '💎') {
      return ctx.reply(`❌ Gems cannot be transferred — they're a bound, non-tradeable currency.`)
    }

    return ctx.reply(`❓ Unknown transfer type. Use *${p}send solars ...*, *${p}send item ...*, or *${p}send character ...*`)
  },
}
