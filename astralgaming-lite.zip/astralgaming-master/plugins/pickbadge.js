import { selectProfileCosmeticCommand } from './profile-cosmetics.js'
export default {
  name: 'pickbadge', aliases: ['equipbadge'], category: 'account', requiresPlayer: true,
  description: 'Select an unlocked profile badge',
  async run(ctx) { return selectProfileCosmeticCommand(ctx, 'badge') },
}
