// <prefix>realityedit - Kim Dokja, Oldest Dream form. Once per fight, PvE.
import { config } from '../config.js'
import { activateRealityEdit } from '../lib/regressor-form-commands.js'
import { runRegressorCommand } from '../lib/regressor-command-runner.js'

export default {
  name: 'realityedit',
  aliases: ['reality'],
  category: 'combat',
  description: `${config.prefix}realityedit - Oldest Dream form. Undo the last failed action. Costs one journal memory.`,
  requiresPlayer: true,
  async run(ctx) { return runRegressorCommand(ctx, activateRealityEdit) },
}
