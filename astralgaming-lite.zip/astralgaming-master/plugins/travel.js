/**
 * travel.js — World map + location movement.
 *
 * Commands:
 *   .travel               — show every location (town + dungeons), locked or
 *                            unlocked, with your progress on each
 *   .travel town           — head back to Astral Town from wherever you are
 *   .travel <dungeonId>     — travel straight to an unlocked dungeon
 *                            (resumes at your checkpoint, same as .enter)
 *
 * This exists because .enter only ever pointed *into* a dungeon — there was
 * no single command that showed the whole map or let a player move on to
 * the next unlocked dungeon after conquering one. .travel is the front door;
 * it delegates to dungeon.js's handleEnter() for actual dungeon entry so the
 * unlock/stamina/checkpoint rules stay in exactly one place.
 *
 * Player-built empires large enough to matter also appear on the map, but they
 * are NOT locations: travel to one with .empire visit, which sets
 * player.visitingEmpire and leaves player.location alone. A visitor is still
 * literally in town, so every reader of player.location here and elsewhere
 * stays correct. .travel town is what ends a visit.
 */
import { travelTollFor, hasFreeTravel } from '../lib/travel-price.js'
import { config } from '../config.js'
import { isFactionPending } from '../lib/faction-choice.js'
import { canFindPlace, hasGogglesEquipped, isHiddenPlace, GOGGLES_NAME } from '../lib/story-perks.js'
import { updatePlayer } from '../lib/player-repo.js'
import { locationsMap } from '../lib/game-data.js'
import { spotsIn } from '../lib/town.js'
import { getGroupSettings } from '../lib/group-settings.js'
import { MARKET_CONFIG, tierOf } from '../lib/empire-engine.js'
import { isDungeonUnlocked, handleEnter } from './dungeon.js'
import { isSeasonLocationAvailable, seasonLockdownRefusal } from '../lib/season-engine.js'
import { locationPurpose, purposeLine, servicesLine } from '../lib/location-purpose.js'
import { isNewbieLocation, isNewbieGraduated, newbieFloorsLine, NEWBIE_MAX_LEVEL } from '../lib/newbie-dungeon.js'
import { releaseDungeonSlot } from '../lib/dungeon-slots.js'
import { isEventActive, endPhase, getEndEvent, THE_END_LOCATION_ID } from '../lib/end-event.js'
// Season 2's map skin: the System re-labels places and regions while the ORV
// season runs. Display only — ids, tolls and unlocks are untouched.
import {
  placeName, regionName, mapHeading, placeNote,
  mapSectors, mapSectorForLocation, findMapSector,
} from '../lib/orv-map.js'
import { styleOn, orvTitle } from '../lib/orv-style.js'
// The Dreamlands: their own map, their own way of moving (on foot, see
// plugins/walk.js), and a hard refusal for anyone trying to walk in from
// the Astra Kingdom without going through the door.
import {
  DREAMLAND_PLACES, DREAMLAND_PLACE_IDS, SPAWN_PLACE_ID, dreamlandsRealm,
  isDreamlandsLocation, realmOf, realmsMap, stepsBetween, NO_SERVICES_LINE,
} from '../lib/dreamlands-core.js'
import { travelToPlace, canWalkTo } from './walk.js'
import { listFrozenBodies } from '../lib/dreamlands-death.js'
// The three worlds (data/worlds.json). `.map` opens on them; `.travel` still
// opens on the kingdom, exactly as it always has.
import {
  worldRecord, ASTRA_KINGDOM, SECT_EMPIRE, DIMENSION_REALM, isWorldOpenFor, isInSectEmpire,
  worldIdForWord,
} from '../lib/worlds.js'
// Arriving in a world is one beat, shared with the roads up and down the
// mountain: the tear, the welcome, and that world's own picture underneath
// (lib/world-arrival.js, links in lib/image.js's map).
import { sendWorldScreen, tearingText } from '../lib/world-arrival.js'
import { replyWithPicture } from '../lib/image.js'
import { TOWER_LOC_ID, TOWER_STAGING_LOCATION_ID } from '../lib/orv-tower.js'
import { sectTravelCommand, sectMapLines } from '../lib/sect-commands.js'
import { COOLDOWN_MS as CROSSING_COOLDOWN_MS, crossingTollWords } from '../lib/sect-crossing.js'
import { wayBackOpen } from '../lib/sect-wayback.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import { entryRefusal } from '../lib/inverted-entry.js'
import { ownsEnd, END_DIMENSION_ID } from '../lib/the-end.js'
import { nationTravelRefusal } from '../lib/affinity-engine.js'

const TOWN_ID = 'astral_town'

/** Every word `.travel` says for the world a cultivator is standing in. */
const SECT_WORLD_IDS = ['sect_empire', 'sect']

// The sections of the world map, home ground first and the sealed frontier
// last. Every Astra place carries a `region` from this list (see
// data/locations.json); anything new without one falls in under the last.
// The list itself lives on the world record (data/worlds.json), so the map and
// the kingdom can never disagree about what the kingdom is made of.
const ASTRAL_REGIONS = [...(worldRecord(ASTRA_KINGDOM)?.regions ?? [
  'The Heartland',
  'The Foothills',
  'The Midlands',
  'The High Peaks',
  'The Riftside',
  'The Frontier',
])]

// ── Map listing ─────────────────────────────────────────────────────────

/**
 * The empires worth putting on a map: big enough to have a name that travels,
 * and hidden entirely where the group has the pillar switched off.
 */
async function visitableEmpires(ctx) {
  if (ctx.isGroup) {
    const settings = await getGroupSettings(ctx.sender).catch(() => null)
    if (!settings?.empireEnabled) return []
  }
  const minRank = MARKET_CONFIG?.mapMinRank ?? 3
  return Object.values(ctx.db?.data?.empires ?? {})
    .filter(rec => rec && !rec.dormant && tierOf(rec).rank >= minRank)
    .sort((a, b) => (b.fame ?? 0) - (a.fame ?? 0))
    .slice(0, 10)
}

/**
 * One place, one line. Shared by the region sections and the off-the-map
 * section below so the two can never drift: a hidden place reads exactly like
 * any other dungeon once you can see it, and the hidden ones only differ by
 * HOW they got onto this map.
 */
function placeLine(loc, player, db) {
  const here = player.location === loc.id ? ' 📍_(you are here)_' : ''
  const terrain = loc.mapTag ? `${loc.mapTag} · ` : ''
  const purpose = locationPurpose(loc) ? `  📌 _${locationPurpose(loc)}_` : ''

  if (loc.type === 'town') {
    const tag = loc.mapTag ? `  _(${loc.mapTag})_` : ''
    const costTag = travelTollFor(loc, player) ? `  💰 ${travelTollFor(loc, player).toLocaleString('en-US')} ☀️` : ''
    return `✅ *${loc.id}* — ${placeName(loc, db)}${tag}${purpose}${costTag}${here}`
  }

  // The rift ignores unlock/progress rules — it's gated by the event clock,
  // and walking in early is fatal, so it gets its own line.
  if (loc.id === THE_END_LOCATION_ID) {
    return getEndEvent(db).defeated
      ? `🌑 *${loc.id}* — ${placeName(loc, db)}  _(OPEN — rematch, no spoils)_${here}`
      : endPhase(db) === 'reckoning'
        ? `🌑 *${loc.id}* — ${placeName(loc, db)}  _(OPEN — the End can be fought)_${here}`
        : `☠️ *${loc.id}* — ${placeName(loc, db)}  _(lethal — the aura kills on contact)_${here}`
  }

  // The Newcomer's Hollow reads differently from every other dungeon: no
  // prerequisite, no travel cost, a LEVEL CEILING rather than a floor, and its
  // own 50-floors-a-day allowance. Showing it as one more locked tower would
  // hide the only thing a new player needs to know about it.
  if (isNewbieLocation(loc.id)) {
    return isNewbieGraduated(player)
      ? `🎓 *${loc.id}* — ${placeName(loc, db)}  _(${terrain}lv 1-${NEWBIE_MAX_LEVEL} · graduated)_${here}`
      : `🕯️ *${loc.id}* — ${placeName(loc, db)}  _(${terrain}lv 1-${NEWBIE_MAX_LEVEL} · ${newbieFloorsLine(player, '.')})_${here}`
  }

  const unlocked = isDungeonUnlocked(player, loc.id)
  const progress = player.dungeonProgress?.[loc.id]
  const status = progress?.conquered
    ? '🏆 Conquered'
    : progress?.highestFloor
      ? `📍 Floor ${progress.highestFloor}`
      : unlocked ? '🆕 Not started' : null

  if (!unlocked) {
    const prereqName = placeName(locationsMap[loc.prerequisite] ?? loc.prerequisite, db)
    return `🔒 *${loc.id}* — ${placeName(loc, db)}  _(${terrain}requires: ${prereqName})_${purpose}`
  }
  if (loc.id === TOWER_LOC_ID) {
    const approachCost = player?.location === TOWER_STAGING_LOCATION_ID
      ? 0
      : travelTollFor(locationsMap[TOWER_STAGING_LOCATION_ID], player)
    const approach = player?.location === TOWER_STAGING_LOCATION_ID
      ? ' · airlock is here'
      : ` · via Wardgate${approachCost ? ` (${approachCost.toLocaleString('en-US')} ☀️ to reach)` : ''}`
    return `☣️ *${loc.id}* — ${placeName(loc, db)}  _(${terrain}500 floors · ${status} · toxic air${approach})_${purpose}${here}`
  }
  const costTag = travelTollFor(loc, player) ? `  💰 ${travelTollFor(loc, player).toLocaleString('en-US')} ☀️` : ''
  return `🗝️ *${loc.id}* — ${placeName(loc, db)}  _(${terrain}${status})_${purpose}${costTag}${here}`
}

function renderMap(player, db, empires = [], options = {}) {
  const sectors = mapSectors(db)
  if (sectors.length) return renderSeasonMap(player, db, empires, { ...options, sectors })
  return renderLegacyMap(player, db, empires)
}

/** Season 2: one detailed sector at a time, with a short overview for navigation. */
function renderSeasonMap(player, db, empires = [], { sectors, sector = null, overview = false } = {}) {
  const location = locationsMap[player?.location]
  const currentSector = mapSectorForLocation(location, db) ?? sectors[0]
  const selectedSector = sector ?? currentSector
  const heading = mapHeading(db)
  const lines = heading
    ? [`${orvTitle(heading.title, '🗺️')}\n_${heading.subtitle}_\n`]
    : [`🗺️ *ASTRA KINGDOM*  ·  WORLD MAP\n`]

  if (overview) {
    lines.push(`_📍 Your current sector: ${currentSector.name}._`, '')
    for (const entry of sectors) {
      const marker = entry.region === currentSector.region ? '📍' : '▫️'
      lines.push(`${marker} *${entry.heading.toUpperCase()}*`)
      if (entry.details?.condition) lines.push(`   _${entry.details.condition}_`)
      if (entry.details?.airQuality) lines.push(`   ☣️ _AIR: ${entry.details.airQuality}_`)
    }
    lines.push(
      '',
      `_Use *${config.prefix}map <1–6>* to inspect a sector. With no number, the map returns to your current sector._`,
      `_Sector notes and hiding-place reports are unverified. They do not create safe zones or travel destinations._`,
    )
    return lines.join('\n')
  }

  if (selectedSector.region === currentSector.region) {
    const note = placeNote(player?.location, db)
    if (note) lines.push(`_❝ ${note} ❞_`, '')
  } else {
    lines.push(`_📍 Your position: ${placeName(location ?? player?.location, db)} · ${currentSector.name}._`, '')
  }

  lines.push(`*${selectedSector.heading.toUpperCase()}*`)
  const details = selectedSector.details
  if (details?.condition) lines.push(`🚨 *${details.condition}*`)
  if (details?.airQuality) lines.push(`☣️ *AIR QUALITY: ${details.airQuality}*`)
  if (details?.situation) lines.push(`_${details.situation}_`)
  lines.push('')

  const places = []
  const offTheMap = []
  for (const loc of Object.values(locationsMap)) {
    if (realmOf(loc.id) !== 'astral_world' || loc.region !== selectedSector.region) continue
    if (!isSeasonLocationAvailable(db, loc)) continue
    if (loc.id === THE_END_LOCATION_ID && !(db && (isEventActive(db) || getEndEvent(db).defeated))) continue
    if (isHiddenPlace(loc)) {
      if (canFindPlace(player, loc)) offTheMap.push(loc)
      continue
    }
    places.push(loc)
  }
  for (const loc of places) lines.push(placeLine(loc, player, db))

  if (offTheMap.length) {
    lines.push(`\n🕯️ *HIDDEN LOCATIONS*  _(${offTheMap.length} discovered)_`)
    for (const loc of offTheMap) lines.push(placeLine(loc, player, db))
    lines.push(hasGogglesEquipped(player)
      ? `_Revealed by *${GOGGLES_NAME}*._`
      : `_Revealed by your discovery perk._`)
  }

  if (details?.hideout) {
    lines.push(`\n🛖 *POSSIBLE HIDING PLACE*`)
    lines.push(`_${details.hideout}_`)
    lines.push(`_Unverified field report. This is descriptive only, not an active safe zone._`)
  }

  if (empires.length) {
    lines.push(`\n🏰 *PLAYER EMPIRES*`)
    for (const rec of empires) {
      const visiting = player.visitingEmpire === rec.id ? '  📍_(visiting)_' : ''
      const shop = (rec.market?.stock?.length ?? 0) > 0 ? '  🏪 _market open_' : ''
      lines.push(`🏰 *${rec.name}*  ·  ${tierOf(rec).name}${shop}${visiting}`)
    }
  }

  lines.push(
    `\n🌀 _Other dimensions are outside the Astra sector map._`,
    `_Sector ${selectedSector.number}/${sectors.length} · browse with *${config.prefix}map overview* or *${config.prefix}map <1–6>*._`,
  )
  return lines.join('\n')
}

function renderLegacyMap(player, db, empires = []) {
  // The kingdom's own map. The title names the world (Astra Kingdom) and keeps
  // the WORLD MAP line every screen and test already reads it by.
  // While the ORV season runs the System's own heading sits above the map, and
  // the plain ASTRA KINGDOM / WORLD MAP line stays under it as the subtitle so
  // every screen and test that reads the map by that line still finds it.
  const heading = mapHeading(db)
  const lines = heading
    ? [`${orvTitle(heading.title, '🗺️')}\n_${heading.subtitle}_\n`]
    : [`🗺️ *ASTRA KINGDOM*  ·  WORLD MAP\n`]

  // The System's note on wherever the hunter is standing. One italic line, at
  // the top, only while the season's map skin is on.
  if (styleOn(db)) {
    const note = placeNote(player.location, db)
    if (note) lines.push(`_❝ ${note} ❞_`, '')
  }

  // The world reads in sections: home ground first, then the road out toward
  // the sealed frontier. One pass buckets every place under its region, then
  // the sections render in the order the realm is meant to be read in.
  //
  // A hidden place (data/locations.json `hidden: true`) is pulled out of its
  // region and held back for the off-the-map block at the bottom of the map —
  // and only if this player can find it at all (Monica's perk, or Oliver's
  // goggles actually worn). Everyone else's map simply does not have it, which
  // is the entire point of a place being off the map.
  const groups = new Map()
  const offTheMap = []
  for (const loc of Object.values(locationsMap)) {
    // The Dreamlands are not on this map. They are behind the door, and the
    // dimensions block at the bottom is where they are pointed at.
    if (realmOf(loc.id) !== 'astral_world') continue
    if (!isSeasonLocationAvailable(db, loc)) continue

    // The End exists in data/locations.json permanently. It shows on the map
    // while its event is live, and stays listed once it has been beaten, as an
    // open on-demand rematch (see dungeon.js handleEnter).
    if (loc.id === THE_END_LOCATION_ID && !(db && (isEventActive(db) || getEndEvent(db).defeated))) continue

    if (isHiddenPlace(loc)) {
      if (canFindPlace(player, loc)) offTheMap.push(loc)
      continue
    }

    const region = ASTRAL_REGIONS.includes(loc.region) ? loc.region : ASTRAL_REGIONS[ASTRAL_REGIONS.length - 1]
    if (!groups.has(region)) groups.set(region, [])
    groups.get(region).push(loc)
  }

  const regions = [
    ...ASTRAL_REGIONS.filter(r => groups.has(r)),
    ...[...groups.keys()].filter(r => !ASTRAL_REGIONS.includes(r)),
  ]

  for (const region of regions) {
    lines.push(`*${String(regionName(region, db)).toUpperCase()}*`)
    for (const loc of groups.get(region)) lines.push(placeLine(loc, player, db))
    lines.push('')
  }

  // ── OFF THE MAP ────────────────────────────────────────────────────────
  // The places that exist and are on nobody's map: drawn by Monica, seen
  // through Oliver's goggles. Held as its own block rather than mixed into the
  // regions because that is the reward talking — a reader who finished the
  // volume should be able to see, at a glance, that their map is bigger than
  // everyone else's.
  if (offTheMap.length) {
    lines.push(`🕯️ *OFF THE MAP*  _(${offTheMap.length} place${offTheMap.length === 1 ? '' : 's'} nobody else can find)_`)
    for (const loc of offTheMap) lines.push(placeLine(loc, player, db))
    lines.push(hasGogglesEquipped(player)
      ? `_Shown to you by *${GOGGLES_NAME}*, worn in your offhand._`
      : `_Drawn by Monica. Nobody else's map has these._`)
    if (hasFreeTravel(player)) lines.push(`_Monica's map: the road charges you nothing._`)
    lines.push('')
  }

  if (empires.length) {
    lines.push(`\n🏰 *PLAYER EMPIRES*`)
    for (const rec of empires) {
      const visiting = player.visitingEmpire === rec.id ? '  📍_(visiting)_' : ''
      const shop = (rec.market?.stock?.length ?? 0) > 0 ? '  🏪 _market open_' : ''
      lines.push(`🏰 *${rec.name}*  ·  ${tierOf(rec).name}${shop}${visiting}`)
    }
    lines.push(`_Head to one with *${config.prefix}empire visit <name>*._`)
  }

  // ── DIMENSIONS ────────────────────────────────────────────────────────
  // Other realities, listed as themselves rather than as more dungeons: you do
  // not walk into them, you find the door. Kept after the world map on purpose
  // — Astral first, because that is where everybody lives.
  if (db) {
    lines.push(`\n🌀 *DIMENSIONS*`)
    const dream = player?.portal?.unlocked
      ? `_(open to you — ${config.prefix}portal enter)_`
      : `_(shut — ${config.prefix}portal for what it wants)_`
    lines.push(`🌫️ *${dreamlandsRealm?.name ?? 'The Dreamlands'}*  ${dream}`)
    lines.push(`_A wasteland of nightmares. No town, no inn, no shop. Death there is not a respawn._`)
    if (ownsEnd(player)) {
      lines.push(`🌑 *The End Dimension*  _(yours — ${config.prefix}travel ${END_DIMENSION_ID})_`)
      lines.push(`_A private thirty-floor dimension. End monsters walk it, and the last door answers only to you._`)
    }
  }

  lines.push(`\nType *${config.prefix}travel <location_id>* to head there.`)
  return lines.join('\n')
}

/**
 * renderDreamlandsMap(player) — the map you get while you are inside.
 *
 * Deliberately not the Astral map with a different header: distances are
 * STEPS, the locks are champion locks, and there is nothing on it that can be
 * bought. One line per place, with the walk time and what still stands in the
 * way.
 */
function renderDreamlandsMap(player, db = null) {
  const lines = [`🌫️ *THE DREAMLANDS*\n`]
  const here = player.location
  const hereName = DREAMLAND_PLACES[here]?.name ?? here
  lines.push(`📍 _You are in *${hereName}*._`)
  lines.push(`❤️ ${player.hp}/${player.maxHp}  ·  ⚡ ${player.stamina?.current ?? 0}/${player.stamina?.max ?? 0}\n`)

  for (const id of DREAMLAND_PLACE_IDS) {
    const place = DREAMLAND_PLACES[id]
    const steps = here === id ? 0 : stepsBetween(here, id)
    const blocked = canWalkTo(player, id)
    const marks = [
      place.type === 'town' ? '🏠 safe' : null,
      place.type === 'dungeon' ? `floors 1-${place.floors}` : null,
      place.type === 'wasteland' ? 'no floors' : null,
      place.alwaysOpen ? 'always open' : null,
      place.type === 'dungeon' && !blocked ? `champion on floor ${(place.bossFloors ?? []).slice(-1)[0] ?? place.floors}` : null,
      place.type === 'dungeon' && player.dungeonProgress?.[id]?.conquered ? '🏆 beaten' : null,
    ].filter(Boolean)
    const dist = steps === 0 ? '_(you are here)_' : `*${steps}* step${steps === 1 ? '' : 's'}`
    if (id === here) {
      lines.push(`📍 *${place.id}* — ${place.name}  ${dist}`)
    } else if (blocked) {
      lines.push(`🔒 *${place.id}* — ${place.name}  _(${dist} · locked)_`)
    } else {
      lines.push(`🚶 *${place.id}* — ${place.name}  _(${dist}${marks.length ? ' · ' + marks.join(' · ') : ''})_`)
    }
  }

  if (db) {
    const bodies = listFrozenBodies(db)
    if (bodies.length) {
      lines.push(`\n🧊 *IN THE ICE*  _(${bodies.length})_`)
      for (const body of bodies.slice(0, 8)) {
        lines.push(`❄️ *${body.name}* — ${DREAMLAND_PLACES[body.locationId]?.name ?? body.locationId}`)
      }
      lines.push(`_Lift one with_ *${config.prefix}rescue <name>*_._`)
    }
  }
  lines.push(`\n_Every step out there can ambush you. Nothing out there heals you._`)
  lines.push(`_Walk with_ *${config.prefix}travel <place>* _· the door home is at Cradlehold:_ *${config.prefix}portal exit*_`)
  return lines.join('\n')
}

// ── The three worlds (.map) ─────────────────────────────────────────────
// `.map` with nothing after it opens here. `.travel` still opens on the
// kingdom: this block adds a screen, it does not move the old front door.

/**
 * renderWorldMenu — the three worlds, and how to actually reach each one.
 * Plain text on purpose: this is a signpost, not a map.
 *
 * It used to list only the `.map <world>` LOOK command, which answered
 * "where can I look" and never "how do I go" — the single most repeated
 * player question about the worlds. Each world now carries its door: the
 * kingdom's road home, the mountain road up (Monica's card and the shared
 * clock), and the two doors of the Dimension Realm.
 *
 * While the Sect Empire's switch is off it is not on the signpost at all for
 * anyone but the owner (and anyone already standing inside it): the world is
 * not announced before it opens. `.openworld sect_empire on` puts it back.
 */
function renderWorldMenu(player, db) {
  const p = config.prefix
  const showSect = isInSectEmpire(player) || isWorldOpenFor(db, SECT_EMPIRE) || isOwnerJid(player?.id ?? '')
  const crossingDays = Math.max(1, Math.round(CROSSING_COOLDOWN_MS / 86_400_000))
  const toll = crossingTollWords()
  const lines = [
    `🗺️ *WORLD MAP*`,
    `_Three worlds. Looking is free; going needs a door._`,
    ``,
    `🌍 *Astra Kingdom* — the home world`,
    `   look: *${p}map astra_kingdom*`,
    `   go: *${p}travel town* walks you home from anywhere in the kingdom`,
  ]
  if (showSect) {
    lines.push(
      ``,
      `⛰️ *Sect Empire* — the cultivation world`,
      `   look: *${p}map sect_empire*`,
      `   go up: *${p}road* from any kingdom town — Monica's card, a ${crossingDays}-day clock each way`,
      `   come back: *${p}travel astra_kingdom* from the empire${toll ? ` — the card + a ${toll} toll` : ''}`,
      `   _the road lets you out in Astral Town;_ *${p}travel <place>* _takes you onward_`,
    )
  }
  lines.push(
    ``,
    `🌀 *Dimension Realm* — the Dreamlands and the Inverted Dimension`,
    `   look: *${p}map dimension_realm*`,
    `   doors: *${p}portal* (the Dreamlands, Astral Town square) · *${p}mirror* (the Inverted)`,
    `   come back: *${p}portal exit* at Cradlehold — or beat the trial`,
  )
  return lines.join('\n')
}

/**
 * renderSectEmpireScreen — what the mountain road says from the kingdom's side.
 *
 * Closed (the shipped default, data/worlds.json `open: false`, amending by the
 * owner's .openworld): the road is not open and this screen says so.
 * Open: the road is open and this screen points at it.
 *
 * Nobody enters from HERE either way. This is a signpost: the only way up is
 * the gatekeeper (.road), and this screen never moves anybody.
 *
 * Returns null while the world is not announced at all, so the caller can give
 * the answer a made-up word gets: no tear, no picture, no hint that a mountain
 * exists.
 */
function renderSectEmpireScreen(player, db) {
  const p = config.prefix
  const inside = isInSectEmpire(player)

  // Shut, and the caller is not the owner and not already standing inside:
  // the world is not announced at all. The owner, who holds the switch, still
  // sees the real signpost below.
  if (!inside && !isWorldOpenFor(db, SECT_EMPIRE) && !isOwnerJid(player?.id ?? '')) {
    return null
  }

  // Open, or standing inside it: the arrival place and the five mountains, read
  // out of the sect data itself (lib/sect-commands.js), so the signpost outside
  // and the map inside can never disagree about who lives up here.
  const lines = []
  if (!inside) lines.push(`🟢 *The road is open.*`, ``)
  lines.push(...sectMapLines(player, db, { prefix: p }))
  return lines.join('\n')
}

/** "level 100 to 200", from a realm record's levelRange. */
function levelBand(realm) {
  const band = Array.isArray(realm?.levelRange) ? realm.levelRange : null
  if (!band || band.length < 2) return ''
  return `level ${band[0]} to ${band[1]}`
}

/**
 * renderDimensionRealm — the Dreamlands and the Inverted Dimension, listed as
 * themselves: the name, the levels they cover, and whether THIS player may
 * walk in yet, answered by the same gate the doors themselves use
 * (player.portal.unlocked for the fog, lib/inverted-entry.js's entryRefusal
 * for the white). Read only. Nothing here moves anybody.
 */
function renderDimensionRealm(player, db) {
  const p = config.prefix
  const lines = [
    `🌀 *DIMENSION REALM*`,
    `_Every door out of the world, and what stands in front of it._`,
    ``,
  ]

  const lockdown = seasonLockdownRefusal(db)
  const dream = realmsMap.dreamlands ?? null
  if (dream) {
    const band = levelBand(dream)
    lines.push(`🌫️ *${dream.name}*${band ? `  ·  ${band}` : ''}`)
    lines.push(`_A wasteland of nightmares. No town, no inn, no shop. Death there is not a respawn._`)
    lines.push(lockdown
      ? `🔒 _Sealed for the season:_ ${lockdown}`
      : player?.portal?.unlocked === true
        ? `🔓 _Open to you:_ *${p}portal enter*`
        : `🔒 _Shut to you:_ *${p}portal* _for what it wants._`)
    lines.push('')
  }

  const inverted = realmsMap.inverted ?? null
  if (inverted) {
    const band = levelBand(inverted)
    const why = entryRefusal(player, db)
    lines.push(`🪞 *${inverted.name}*${inverted.altName ? `  ·  ${inverted.altName}` : ''}${band ? `  ·  ${band}` : ''}`)
    lines.push(`_White, and nothing else, all the way down. Trials against a perfect copy of you._`)
    lines.push(why
      ? `🔒 _Shut to you:_ ${why}`
      : `🔓 _Open to you:_ *${p}mirror enter*`)
    lines.push('')
  }

  if (ownsEnd(player)) {
    lines.push(`🌑 *The End Dimension*  ·  private`)
    lines.push(`_The ending of the season, given ground. Thirty floors of End monsters, and a title at the last door._`)
    lines.push(lockdown
      ? `🔒 _Sealed for the season:_ ${lockdown}`
      : `🔓 _Open to you:_ *${p}travel ${END_DIMENSION_ID}*`)
    lines.push('')
  }

  lines.push(`_This screen only tells you about them. Entry is through the doors themselves._`)
  return lines.join('\n')
}

// The pictures above these screens live in lib/image.js's map and are named in
// lib/world-arrival.js: 'world-map' for the menu of the three worlds,
// 'astra-kingdom-map' for the kingdom's own map, 'world-tearing' for the tear a
// player arrives through, 'dimension-realm-map' for the doors (link still to
// come, so that screen ships as text until it is dropped in). Every one of them
// goes out through replyWithPicture, which sends the map as the caption when it
// fits and as the next message when it does not, and sends the words alone if
// the picture cannot be sent at all.

// ── Travel to town ──────────────────────────────────────────────────────

async function handleTravelToTown(ctx, targetId = TOWN_ID) {
  const { reply } = ctx
  const p = config.prefix
  const target = locationsMap[targetId] ?? locationsMap[TOWN_ID]
  let arrivalReply = null
  let arrivalImage = null

  await updatePlayer(ctx.db, ctx.from, player => {
    if (player.inBattle) {
      arrivalReply = `⚔️ Finish your current battle first!`
      return player
    }

    // The tower opens only through Wardgate's filtered airlock. Do not let a
    // player use the ordinary town-travel command to step directly into toxic
    // outside air, and do not charge a second road fare for the airlock return.
    if (player.location === TOWER_LOC_ID && target.id !== TOWER_STAGING_LOCATION_ID) {
      arrivalReply =
        `☣️ The air outside the tower is toxic. Your only safe road is back through Wardgate’s filtered airlock: ` +
        `*${p}dungeon leave* or *${p}travel ${TOWER_STAGING_LOCATION_ID}*.`
      return player
    }
    const towerAirlockReturn = player.location === TOWER_LOC_ID && target.id === TOWER_STAGING_LOCATION_ID

    // A visitor to another player's empire never left town, so ending a visit
    // has to be handled before the already-in-town shortcut below.
    if (player.visitingEmpire) {
      const name = ctx.db.data.empires?.[player.visitingEmpire]?.name ?? 'the empire'
      player.visitingEmpire = null
      player.visitingSince = null
      player.inDungeon = false
      player.battleState = null
      player.location = TOWN_ID
      arrivalReply =
        `🚪 *${player.name}* leaves *${name}* and returns to *${locationsMap[TOWN_ID].name}*.\n` +
        `_Its market is out of reach until you visit again._`
      return player
    }

    if (player.location === target.id) {
      arrivalReply = `📍 You're already in *${target.name}*.`
      return player
    }

    const toll = towerAirlockReturn ? 0 : travelTollFor(target, player)
    if (toll > 0 && (player.wallet?.solars ?? 0) < toll) {
      arrivalReply =
        `❌ The road to *${target.name}* costs *${toll.toLocaleString('en-US')} ☀️*. ` +
        `_You only have *${player.wallet?.solars ?? 0} ☀️*._`
      return player
    }

    const savedFloor = player.dungeonFloor ?? 0
    const wasInDungeon = player.inDungeon
    const prevLoc = player.location

    player.inDungeon    = false
    player.battleState  = null
    player.location     = target.id
    // Arriving in a town puts you at its first street, so .where and .talk
    // always know a real person is standing on a real street of THIS town.
    const firstSpot     = spotsIn(target.id)[0] ?? null
    player.townSpot     = firstSpot?.id ?? null
    arrivalImage        = firstSpot?.image ?? target.image ?? null
    if (toll > 0) {
      player.wallet = player.wallet ?? {}
      player.wallet.solars = (player.wallet.solars ?? 0) - toll
    }
    releaseDungeonSlot(ctx.isGroup ? ctx.sender : null, player, ctx.from)

    arrivalReply =
      `🚪 *${player.name}* travels ${targetId === TOWN_ID ? 'back to' : 'to'} *${target.name}*.\n` +
      (towerAirlockReturn ? `☣️ Wardgate’s filtered airlock clears the route; there is no second fare.\n` : '') +
      (toll > 0 ? `_The road cost you *${toll.toLocaleString('en-US')} ☀️*._\n` : '') +
      (wasInDungeon
        ? `📍 Progress in *${locationsMap[prevLoc]?.name ?? prevLoc}* saved at Floor ${savedFloor}.\n`
        : '') +
      [purposeLine(target), servicesLine(target)].filter(Boolean).join('\n') +
      (purposeLine(target) || servicesLine(target) ? '\n' : '') +
      `_Type *${p}travel* to see the map, or *${p}inn* to rest up._`
    return player
  })

  if (arrivalReply) {
    return replyWithPicture(ctx, arrivalImage, arrivalReply)
  }
}

// ── Plugin export ────────────────────────────────────────────────────────

export default {
  name:           'travel',
  aliases:        ['go', 'map'],
  category:       'dungeon',
  requiresPlayer: true,
  description:    `${config.prefix}travel [location_id] — move through Astra; ${config.prefix}map [overview|sector 1-6] — view the current sector or browse the seasonal map.`,

  async run(ctx) {
    const { args, player, reply } = ctx

    // No roaming before the faction choice — a pending character has neither
    // a confirmed world nor hub to travel from.
    if (isFactionPending(player)) {
      return reply(
        `🧭 *Choose your world first.*\n\n` +
        `_${config.prefix}faction kingdom_ — Astra Kingdom\n` +
        `_${config.prefix}faction sect_ — Sect Empire_`,
      )
    }

    // ── The Sect Empire ──────────────────────────────────────────────────
    // Inside this world the map IS this world's map: the places a cultivator
    // can stand on, and nothing else. Checked before every Astra branch
    // below, so nothing below can be reached — except the one word that is
    // the WORLD step of the two-step travel: `.travel astra_kingdom` opens
    // the road down exactly as `.road` does (same state machine, same card,
    // same clock, same toll — lib/sect-wayback.js), because "travel to the
    // world first, then to a location" is how going home reads.
    if (isInSectEmpire(player)) {
      if (worldIdForWord(args.join(' ')) === ASTRA_KINGDOM) {
        let out = null
        await updatePlayer(ctx.db, ctx.from, pl => { out = wayBackOpen(pl, { now: Date.now() }); return pl })
        return reply((out?.lines ?? []).join('\n\n'))
      }
      const first = String(args[0] ?? '').toLowerCase()
      if (!args.length) return sectTravelCommand(ctx, { map: true })
      if (SECT_WORLD_IDS.includes(first)) return sectTravelCommand(ctx, { map: true })
      return sectTravelCommand(ctx)
    }

    // Season 2 keeps the command local and readable: `.map` shows the sector
    // the player is standing in, and a number/name opens another sector.
    // Non-season maps retain the existing three-world menu behavior.
    if (String(ctx.cmd ?? '').toLowerCase() === 'map' && mapSectors(ctx.db).length && !isDreamlandsLocation(player.location)) {
      const query = args.join(' ').trim()
      const overview = /^(overview|all|sectors)$/i.test(query)
      const sector = findMapSector(query, ctx.db)
      if (!query || /^(current|here)$/i.test(query) || overview || sector) {
        return sendWorldScreen(ctx, ASTRA_KINGDOM, renderMap(
          player,
          ctx.db,
          await visitableEmpires(ctx),
          { sector, overview },
        ))
      }
    }

    // Inside the Dreamlands the map IS the realm's map: the Astra towers are
    // not reachable from here and listing them would be a lie. That holds for
    // `.map` too: a player behind the door never gets the three world menu.
    if (!args.length) {
      if (isDreamlandsLocation(player.location)) return reply(renderDreamlandsMap(player, ctx.db))
      // `.map` with nothing after it is the menu of the three worlds, under the
      // world art. Every other way in (.travel, .go) still opens on the
      // kingdom's own map, with the kingdom's own picture.
      if (String(ctx.cmd ?? '').toLowerCase() === 'map') {
        return sendWorldScreen(ctx, 'menu', renderWorldMenu(player, ctx.db))
      }
      return sendWorldScreen(ctx, ASTRA_KINGDOM, renderMap(player, ctx.db, await visitableEmpires(ctx)))
    }

    const locId = args[0].toLowerCase().replace(/\s+/g, '_')
    // The world the words name, in any of their spellings: the whole argument is
    // read, because a player types `.map sect empire` and not `sect_empire`.
    const worldId = worldIdForWord(args.join(' '))

    // ── The three worlds ─────────────────────────────────────────────────
    // Checked BEFORE the word is treated as a location id, so `.map
    // astra_kingdom` can never be mistaken for a place named astra_kingdom, and
    // `.map sect` reaches the mountain instead of an "unknown location". A
    // player standing inside a dimension keeps the dimension's own answers
    // below: the world menu is for the kingdom's side of the door.
    //
    // Naming a world is arriving in it, so the tear comes first (the picture,
    // and the words under it) and the world's own screen follows. The
    // Dimension Realm is not arrived in from here: it is a list of doors, so it
    // gets its screen and its own picture and no tear.
    if (worldId && !isDreamlandsLocation(player.location)) {
      if (worldId === ASTRA_KINGDOM) {
        const mapBody = renderMap(player, ctx.db, await visitableEmpires(ctx))
        return sendWorldScreen(ctx, ASTRA_KINGDOM, `${tearingText(ASTRA_KINGDOM)}\n\n${mapBody}`)
      }
      if (worldId === SECT_EMPIRE) {
        const screen = renderSectEmpireScreen(player, ctx.db)
        // A world that is not open is not announced: the same answer a made-up
        // word gets, with no tear and no picture in front of it.
        if (!screen) return reply(`❌ Unknown location *${SECT_EMPIRE}*.`)
        const combined = `${tearingText(SECT_EMPIRE, { from: ASTRA_KINGDOM })}\n\n${screen}`
        return sendWorldScreen(ctx, SECT_EMPIRE, combined)
      }
      return sendWorldScreen(ctx, DIMENSION_REALM, renderDimensionRealm(player, ctx.db))
    }

    // ── The Dreamlands ───────────────────────────────────────────────────
    if (DREAMLAND_PLACES[locId]) {
      if (isDreamlandsLocation(player.location)) return travelToPlace(ctx, locId)
      return reply(
        `🌫️ *You cannot walk into the Dreamlands.*\n` +
        `_There is a door standing in the Astral Town square, and it is the only way in:_ *${config.prefix}portal*_._`,
      )
    }

    if (locId === 'town' || locId === TOWN_ID) {
      // No road home from the Dreamlands. The only way back is the door, and
      // the door is at Cradlehold, and it costs 10,000 Solars.
      if (isDreamlandsLocation(player.location)) {
        return reply(
          `🚪 *There is nothing here but the dark.*\n` +
          `_No road leads back to Astral Town. The door is at Cradlehold, and it will want ` +
          `10,000 Solars to let you through:_ *${config.prefix}travel cradlehold* _then_ *${config.prefix}portal exit*_._`,
        )
      }
      return handleTravelToTown(ctx)
    }

    const loc = locationsMap[locId]

    if (locId === END_DIMENSION_ID) {
      if (!ownsEnd(player)) return reply(`🌑 *The End Dimension* belongs to The End's collector. Spin: *${config.prefix}end-spin*.`)
      return handleEnter(ctx)
    }

    // A place that belongs to another world is not on this map and not a
    // destination from it. The tag lives in the data (locations.json `realm` /
    // `world`); this is what keeps the Sect Empire's own ground out of every
    // kingdom list, and it is checked before the town branch below can move
    // anybody. The road is the only way in.
    if (loc && realmOf(loc.id) !== 'astral_world') {
      return reply(
        `🚧 *That place is not in this world.*\n` +
        `_${loc.name} stands somewhere no road from here reaches._`,
      )
    }

    // Any town on the map can be walked to. The realm's towns are all safe
    // ground: no prerequisite, no floor, just the travel cost on the signpost.
    if (loc?.type === 'town') {
      if (isDreamlandsLocation(player.location)) {
        return reply(
          `🚪 *There is nothing here but the dark.*\n` +
          `_No road leads from the Dreamlands to *${loc.name}*. The door home is at Cradlehold:_ *${config.prefix}portal exit*_._`,
        )
      }
      return handleTravelToTown(ctx, locId)
    }

    if (!loc || loc.type !== 'dungeon') {
      if (isDreamlandsLocation(player.location)) {
        return reply(`❌ Unknown place *${locId}*.\n\n${renderDreamlandsMap(player)}`)
      }
      return reply(`❌ Unknown location *${locId}*.\n\n${renderMap(player, ctx.db, await visitableEmpires(ctx))}`)
    }
    if (isDreamlandsLocation(player.location)) {
      return reply(
        `🌫️ *Not from here.*\n_The towers of the Astra Kingdom are behind the door, and the door is at Cradlehold._\n` +
        `_${NO_SERVICES_LINE}_`,
      )
    }

    // Delegate straight to dungeon.js's entry logic — same unlock checks,
    // stamina cost, and checkpoint resume as !enter.
    return handleEnter(ctx)
  },
}
