/**
 * mirror.js — THE WORLD THAT NEVER ENDS (THE INVERTED DIMENSION).
 *
 *   <prefix>mirror            the portal in Astral Town, and today's omen (free)
 *   <prefix>mirror omen       the same omen card
 *   <prefix>mirror enter      ask to step through (a confirmation, then the fee)
 *   <prefix>mirror confirm    confirm the pending entry (or leave) within 60 s
 *   <prefix>mirror status     your run, or your lock
 *   <prefix>mirror ready      begin the next trial / resume a frozen run
 *   <prefix>mirror leave      between trials, after one cleared: pay and go (no reward)
 *   <prefix>mirror board      this season's leaderboards
 *
 * Inside a run, <prefix>attack / <prefix>skill <n> / <prefix>defend fight the
 * reflection (routed by lib/inverted-gate.js). Every tunable is in
 * lib/inverted-core.js; every line Me and You says is in
 * data/inverted-voice.json.
 */

import { config } from '../config.js'
import { updatePlayer, getPlayer, updateWorldState } from '../lib/player-repo.js'
import {
  INVERTED, moodAt, moodEndsAt, omenLine, whimHint, moodConfig, invertedVoice,
} from '../lib/inverted-core.js'
import { createRun, getRun, leaveRefusal, leaveRun } from '../lib/inverted-run.js'
import { entryRefusal, entryCost } from '../lib/inverted-entry.js'
import { claimFirstVisitor, topBoard } from '../lib/inverted-world.js'
import { statusScreen, fightScreen, moodTag, TITLE } from '../lib/inverted-text.js'
import {
  sendLines, sendBeats, broadcast, currentSeasonId, handleReady, lockScreenLines,
} from '../lib/inverted-actions.js'
import { entryBeats } from '../lib/inverted-cinematics.js'
import { isLocked } from '../lib/inverted-usurp.js'

function omenCard(player) {
  const p = config.prefix
  const now = Date.now()
  const mood = moodAt(now)
  const mc = moodConfig(mood)
  const cost = entryCost(player)
  const mins = Math.max(1, Math.round((moodEndsAt(now) - now) / 60000))
  return [
    TITLE,
    `_In the middle of the Astral Town square there is a portal that shows nothing but white. If you stand close enough, your reflection in it does not quite keep up with you._`,
    `🔮 *Omen:* _${omenLine(mood, now)}_`,
    `_${whimHint(mood)}_ (the mood turns in about ${mins >= 60 ? `${Math.round(mins / 60)} h` : `${mins} min`})`,
    `━━━━━━━━━━━━━━━━━━━━`,
    `*What waiting inside looks like:* trials of three stages against a perfect copy of you, rules rewritten by *${INVERTED.bossName}*, and a best-of-three final.`,
    `*If you win:* up to *${Math.floor(INVERTED.reward.baseSolars * mc.rewardMult).toLocaleString()}* ☀️ and *${Math.floor(INVERTED.reward.baseGems * mc.rewardMult)}* 🔮 at today's mood, before the audience decides.`,
    `*If you lose once:* your copy walks out wearing your name, and you stay behind the glass until you pay, or wait ${Math.round(INVERTED.usurp.autoReleaseMs / 86_400_000)} days.`,
    `*Entry:* beaten The End · level ${INVERTED.entry.minLevel}+ · ☀️ ${cost.solars.toLocaleString()} each time${cost.gems ? ` · 🔮 ${cost.gems} once` : ''}`,
    `*${p}mirror enter* when you are sure.`,
  ].join('\n\n')
}

function confirmCard(player, action) {
  const p = config.prefix
  if (action === 'leave') {
    return `🚪 *Leave the white?* It costs *${INVERTED.leave.feeSolars.toLocaleString()}* ☀️ and you take *nothing* with you. Your Distance stays on the board.\n\n*${p}mirror confirm* within ${INVERTED.entry.confirmTtlMs / 1000} seconds.`
  }
  const cost = entryCost(player)
  return [
    `🪞 *STEP INTO ${INVERTED.name}?*`,
    `☀️ *${cost.solars.toLocaleString()} Solars*${cost.gems ? ` and 🔮 *${cost.gems} Gems* (once, ever)` : ''} will be taken.`,
    `⚠️ _Inside: no potions, no characters, no pets, no party, no fleeing, no healing between stages. Lose a single stage and you are replaced. Leaving early costs ${INVERTED.leave.feeSolars.toLocaleString()} Solars and pays nothing._`,
    `Today's mood is *${moodTag(moodAt())}*. It is locked in the moment you step through.`,
    `*${p}mirror confirm* within ${INVERTED.entry.confirmTtlMs / 1000} seconds.`,
  ].join('\n\n')
}

async function handleEnter(ctx) {
  const refusal = entryRefusal(ctx.player, ctx.db)
  if (refusal) return ctx.reply(refusal)
  await updatePlayer(ctx.db, ctx.from, (pl) => {
    pl.inverted = pl.inverted ?? {}
    pl.inverted.pendingAction = { action: 'enter', at: Date.now() }
    return pl
  })
  ctx.player = getPlayer(ctx.db, ctx.from)
  return ctx.reply(confirmCard(ctx.player, 'enter'))
}

async function confirmEnter(ctx) {
  const now = Date.now()
  const seasonId = currentSeasonId(ctx.db)
  let outcome = null
  await updatePlayer(ctx.db, ctx.from, (pl) => {
    const refusal = entryRefusal(pl, ctx.db)
    if (refusal) { outcome = { ok: false, refusal }; return pl }
    const cost = entryCost(pl)
    pl.wallet = pl.wallet ?? { solars: 0, gems: 0 }
    pl.wallet.solars -= cost.solars
    if (cost.gems) pl.wallet.gems -= cost.gems
    pl.inverted = pl.inverted ?? {}
    pl.inverted.unlocked = true
    pl.inverted.pendingAction = null
    const mood = moodAt(now)
    const run = createRun(pl, { now, mood, seasonId })
    outcome = { ok: true, mood, run }
    return pl
  })
  if (!outcome?.ok) return ctx.reply(outcome?.refusal ?? '⚠️ Something changed. No charge was made.')
  ctx.player = getPlayer(ctx.db, ctx.from)

  let first = false
  await updateWorldState(ctx.db, 'inverted', (data) => { first = claimFirstVisitor(data, ctx.player, now) })
  const run = getRun(ctx.player)
  await sendBeats(ctx, entryBeats({ pl: ctx.player, run, first }))
  if (first) await broadcast(ctx, `🪞 *${INVERTED.broadcasts.firstVisitor}*`)
  return ctx.player
}

async function handleLeave(ctx) {
  const refusal = leaveRefusal(ctx.player)
  if (refusal) return ctx.reply(refusal)
  await updatePlayer(ctx.db, ctx.from, (pl) => {
    pl.inverted.pendingAction = { action: 'leave', at: Date.now() }
    return pl
  })
  return ctx.reply(confirmCard(ctx.player, 'leave'))
}

async function confirmLeave(ctx) {
  let res = null
  let mood = 'bored'
  await updatePlayer(ctx.db, ctx.from, (pl) => {
    mood = getRun(pl)?.mood ?? mood
    res = leaveRun(pl, Date.now())
    if (pl.inverted) pl.inverted.pendingAction = null
    return pl
  })
  ctx.player = getPlayer(ctx.db, ctx.from)
  if (!res?.ok) return ctx.reply(res?.lines?.[0] ?? 'You cannot leave right now.')
  return sendLines(ctx, [`🚪 ${invertedVoice.leave[0]}`, `☀️ Solars: *${(ctx.player.wallet?.solars ?? 0).toLocaleString()}*`])
}

async function handleBoard(ctx) {
  const seasonId = currentSeasonId(ctx.db)
  const deepest = topBoard(ctx.db.data, seasonId, 'deepest')
  const runs = topBoard(ctx.db.data, seasonId, 'runs')
  const fmt = (rows, unit) => rows.length ? rows.map((r, i) => `${i + 1}. *${r.name}* · ${r.value} ${unit}`).join('\n') : '_nobody yet_'
  return ctx.reply(
    `${TITLE}\n\n🧭 *Deepest this season*\n${fmt(deepest, 'Distance')}\n\n🏁 *Runs finished this season*\n${fmt(runs, 'runs')}`,
  )
}

export default {
  name: 'mirror',
  aliases: ['inverted', 'neverends', 'theworld'],
  category: 'dungeon',
  requiresPlayer: true,
  description: `${config.prefix}mirror [enter|confirm|status|ready|leave|omen|board] — The World That Never Ends (the Inverted Dimension): fight yourself, or be replaced.`,

  subcommands: [
    { cmd: 'omen', desc: "today's mood, free" },
    { cmd: 'enter', desc: 'step through the portal (asks for confirmation)' },
    { cmd: 'confirm', desc: 'confirm entering or leaving (60 s)' },
    { cmd: 'status', desc: 'your run, or your lock' },
    { cmd: 'ready', desc: 'begin the next trial / resume a frozen run' },
    { cmd: 'leave', desc: 'between trials: pay and walk out with nothing' },
    { cmd: 'board', desc: "this season's leaderboards" },
  ],

  async run(ctx) {
    const { args, player } = ctx
    const sub = String(args?.[0] ?? '').toLowerCase()

    if (isLocked(player)) {
      if (sub === 'board') return handleBoard(ctx)
      return sendLines(ctx, lockScreenLines(player), 'locked')
    }

    const run = getRun(player)
    if (!sub || sub === 'status' || sub === 'info') {
      if (run) return ctx.reply(run.fight && !run.fight.over ? fightScreen(run) : statusScreen(run))
      if (sub === 'status') return ctx.reply(`⬜ You are not inside. *${config.prefix}mirror* shows the portal.`)
      return sendLines(ctx, [omenCard(player)], 'arrival')
    }
    if (sub === 'omen') return sendLines(ctx, [omenCard(player)])
    if (sub === 'board' || sub === 'top' || sub === 'leaderboard') return handleBoard(ctx)
    if (sub === 'enter' || sub === 'go') return handleEnter(ctx)
    if (sub === 'ready' || sub === 'next' || sub === 'resume') {
      if (!run) return ctx.reply(`⬜ You are not inside. *${config.prefix}mirror enter* first.`)
      return handleReady(ctx)
    }
    if (sub === 'leave' || sub === 'exit') return handleLeave(ctx)
    if (sub === 'confirm') {
      const pending = player.inverted?.pendingAction
      if (!pending || Date.now() - (pending.at ?? 0) > INVERTED.entry.confirmTtlMs) {
        return ctx.reply(`⌛ Nothing is waiting to be confirmed. Start again with *${config.prefix}mirror enter*.`)
      }
      return pending.action === 'leave' ? confirmLeave(ctx) : confirmEnter(ctx)
    }
    return ctx.reply(`🪞 *Usage:* *${config.prefix}mirror <enter|confirm|status|ready|leave|omen|board>*`)
  },
}
