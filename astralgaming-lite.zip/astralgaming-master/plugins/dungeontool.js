/** Class-specific preparation usable once at an ordinary dungeon rest floor. */
import { config } from '../config.js'
import { hasInventoryRoom, inventoryFullMessage } from '../lib/inventory-limits.js'
import { DUNGEON_CLASS_TOOLS, useDungeonClassTool } from '../lib/dungeon-tools.js'
import { updatePlayer } from '../lib/player-repo.js'

export default {
  name: 'dungeontool',
  aliases: ['class-tool', 'classskill'],
  category: 'dungeon',
  requiresPlayer: true,
  description: `${config.prefix}dungeontool — use your class tool at an ordinary dungeon rest floor`,

  async run(ctx) {
    const { player } = ctx
    const prefix = config.prefix
    if (player.inBattle) return ctx.reply('⚔️ You cannot use a class tool during battle.')
    if (!player.inDungeon) return ctx.reply(`🗺️ Class tools can only be used at a dungeon rest floor. Use *${prefix}dungeon* to enter.`)

    let outcome = null
    await updatePlayer(ctx.db, ctx.from ?? player.id, fresh => {
      outcome = useDungeonClassTool(fresh, {
        hasInventoryRoom: hasInventoryRoom(fresh, 1),
      })
      return fresh
    })

    if (outcome?.ok) {
      return ctx.reply(
        `🧰 *${outcome.tool.name}* — ${outcome.line}\n` +
        `_You can use one class tool per rest floor._`,
      )
    }

    if (outcome?.reason === 'not_resting') {
      return ctx.reply(`🧭 Class tools work only in the safe rest area between ordinary dungeon floors. You are not resting there now.`)
    }
    if (outcome?.reason === 'already_used') {
      return ctx.reply(`🧰 You have already used your class tool for Floor ${outcome.floor}.`)
    }
    if (outcome?.reason === 'inventory_full') return ctx.reply(inventoryFullMessage(player))
    if (outcome?.reason === 'already_full') return ctx.reply(`🔷 Your MP is already full.`)
    if (outcome?.reason === 'nothing_to_purify') return ctx.reply(`✨ You have no negative status effect to remove.`)
    if (outcome?.reason === 'unknown_class') {
      return ctx.reply(`❌ Your class has no dungeon tool yet. Available classes: ${Object.keys(DUNGEON_CLASS_TOOLS).join(', ')}.`)
    }
    return ctx.reply(`❌ Your class tool could not be used.`)
  },
}
