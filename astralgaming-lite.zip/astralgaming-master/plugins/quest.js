/**
 * quest — the player-facing window on the quest pillar (lib/quest-engine.js).
 *
 *   .quest            show today's daily set + your live milestones
 *   .quest list       same as above
 *   .quest claim      claim every finished quest at once
 *   .quest claim <id> claim one finished quest by its id
 *   .quest complete   alias for claim (matches the old .quest complete button)
 *
 * Progress itself is recorded elsewhere, wherever the tracked thing happens
 * (a kill in combat-handlers.js, a catch in collect.js, a battle win in the
 * poke/pvp conclude paths). This plugin only reads the board and pays out
 * finished quests, so it never touches combat state.
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { getActiveSeason, getSeasonRuntime, isSeasonRunActive, ensurePlayerSeasonState, grantSeasonPassXp } from '../lib/season-engine.js'
import { levelsData, classes, races, getTotalStats } from '../lib/game-data.js'
import { applyLevelUps } from '../lib/combat-engine.js'
import { sendRankUp } from '../lib/rank-up.js'
// Tutorial hook — fires when a quest is claimed
import { recordTutorialEvent, tutorialNotice } from '../lib/tutorial-engine.js'
import {
  getQuestBoard, claimQuest, ensureQuestState, DAILY_COUNT,
} from '../lib/quest-engine.js'
import { styleOn, orvPanel, orvBar, styledPanel } from '../lib/orv-style.js'
import {
  getSeason02QuestBoard, claimSeason02Quest, deliverPendingSeason02Items,
} from '../lib/season-02-quest-engine.js'

function bar(progress, goal) {
  const pct = goal > 0 ? Math.min(1, progress / goal) : 1
  const filled = Math.round(pct * 10)
  return '▰'.repeat(filled) + '▱'.repeat(10 - filled)
}

function rewardTag(reward) {
  if (!reward) return ''
  const amt = reward.amount ?? 1
  switch (reward.type) {
    case 'solars':       return `☀️ ${amt}`
    case 'gems':         return `💎 ${amt}`
    case 'xp':           return `📈 ${amt} XP`
    case 'seasonPoints': return `✨ ${amt} SP`
    case 'stamina':      return `⚡ ${amt}`
    case 'character':    return `🎴 character`
    case 'item':         return `🎁 item`
    default:             return `${amt}`
  }
}

function renderLine(q) {
  const status = q.claimed ? '☑️' : q.done ? '✅' : '⬜'
  const prog = q.done ? '' : `  _${q.progress}/${q.goal}_`
  const barStr = q.done ? '' : `\n   ${bar(q.progress, q.goal)}`
  const claimHint = q.done && !q.claimed ? `  ·  🎁 ${rewardTag(q.reward)} _(ready)_` : `  ·  ${rewardTag(q.reward)}`
  return `${status} *${q.name}*${prog}${claimHint}\n   _${q.desc}_${barStr}`
}

/**
 * The board. While the ORV season runs it wears the System window (brackets,
 * bold font, one narrator line, commands in the footer) exactly like the daily
 * and the gate cards; with no season it is the legacy board, unchanged.
 */
function renderBoard(player, db = null) {
  const { daily, milestone } = getQuestBoard(player)
  const ready = daily.filter(q => q.done && !q.claimed).length + milestone.filter(q => q.done).length

  if (styleOn(db)) {
    const row = (q) => {
      const status = q.claimed ? '☑️' : q.done ? '✅' : '▫️'
      const prog = q.done ? '' : `  *${q.progress}/${q.goal}*`
      const claim = q.done && !q.claimed ? `  🎁 ${rewardTag(q.reward)} _ready_` : `  ${rewardTag(q.reward)}`
      return `${status} *${q.name}*${prog}${claim}\n   ${q.desc}${q.done ? '' : `\n   ${orvBar(q.progress, q.goal)}`}`
    }
    return orvPanel({
      emoji: '📜',
      title: 'Quest Board',
      subtitle: `${DAILY_COUNT} daily objectives · rotate at midnight`,
      blocks: [
        daily.length ? daily.map(row).join('\n') : '_No daily quests today._',
        milestone.length ? `🏆 *Milestones*\n${milestone.map(row).join('\n')}` : null,
        ready > 0
          ? `🎁 *${ready}* quest${ready === 1 ? '' : 's'} ready to claim.`
          : null,
      ],
      footer: ['quest claim', 'daily'],
    })
  }

  const lines = [`📜 *QUEST BOARD*\n`]

  lines.push(`☀️ *DAILY* _(rotates at midnight, ${DAILY_COUNT} a day)_`)
  if (daily.length) {
    for (const q of daily) lines.push(renderLine(q))
  } else {
    lines.push('_No daily quests today._')
  }

  if (milestone.length) {
    lines.push(`\n🏆 *MILESTONES* _(one time)_`)
    for (const q of milestone) lines.push(renderLine(q))
  }

  lines.push(
    ready > 0
      ? `\n🎁 *${ready}* quest${ready === 1 ? '' : 's'} ready. Claim with *${config.prefix}quest claim*.`
      : `\n_Claim finished quests with *${config.prefix}quest claim*._`,
  )
  return lines.join('\n')
}

function seasonRewardText(reward = {}) {
  const bits = []
  if (reward.stars) bits.push(`⭐ ${reward.stars}`)
  if (reward.xp) bits.push(`📈 ${reward.xp} XP`)
  if (reward.passXp) bits.push(`✨ ${reward.passXp} Pass XP`)
  for (const item of reward.items ?? []) bits.push(`🎁 ${item.id.replaceAll('_', ' ')} ×${item.amount}`)
  return bits.join(' · ') || 'story record'
}

function seasonQuestRow(q) {
  const marker = q.claimed ? '☑️' : q.locked ? '🔒' : q.done ? '✅' : '▫️'
  const progress = q.goal > 1 || q.track === 'milestone' ? `  _${q.progress}/${q.goal}_` : ''
  return `${marker} *${q.title}*${progress}${q.done && !q.claimed ? ' · 🎁 ready' : ''}\n   _${q.objective}_\n   _Reward: ${seasonRewardText(q.reward)}_`
}

function renderSeasonQuestBoard(board, pending = []) {
  const section = (title, rows) => rows?.length ? `\n*${title}*\n${rows.map(seasonQuestRow).join('\n')}` : ''
  const pendingLine = pending.length
    ? `\n📦 Delivered held items: ${pending.map(x => `${x.id.replaceAll('_', ' ')} ×${x.amount}`).join(', ')}\n`
    : ''
  return (
    `「 📜 SEASON 2 QUEST BOARD 」\n` +
    `_Main story · WAT daily and weekly rotations · one-time Tower and gate rewards_\n` +
    section('MAIN SCENARIO', board.main) +
    section('TODAY · 3 DAILY SCENARIOS', board.daily) +
    section('WEEKLY SCENARIOS', board.weekly) +
    section('TOWER MILESTONES', board.milestone) +
    section('GATE SCENARIOS', board.gate) +
    section('HIDDEN SCENARIOS', board.hidden) +
    `\n\n${pendingLine}` +
    `⌁ _${config.prefix}quest season claim [id|all]_ · claim completed rewards\n` +
    `⌁ _${config.prefix}scavenge_ · one capped search per WAT day\n` +
    `⌁ _${config.prefix}memory_ · replay a recorded Tower observation`
  )
}

async function handleSeasonQuestBoard(ctx) {
  const season = getActiveSeason(ctx.db)
  if (season?.id !== 'season_02') {
    return ctx.reply('🌙 The seasonal quest board opens during Season 2, Life of a Regressor.')
  }
  const runtime = getSeasonRuntime(ctx.db)
  const action = String(ctx.args[1] ?? 'list').toLowerCase()
  const claiming = action === 'claim' || action === 'complete'
  const requested = claiming ? String(ctx.args[2] ?? 'all').toLowerCase() : null
  const id = requested && requested !== 'all' ? requested : null
  let outcome = null
  let board = null
  let delivered = []
  let levelMsgs = []
  let rankChange = null
  await updatePlayer(ctx.db, ctx.from, player => {
    delivered = deliverPendingSeason02Items(player, { runNumber: runtime.runNumber })
    if (claiming) {
      outcome = claimSeason02Quest(player, id, { runNumber: runtime.runNumber })
      if (!outcome.nothing) {
        const result = applyLevelUps(player, levelsData, classes, races, getTotalStats)
        levelMsgs = result.msgs ?? []
        rankChange = result.rankChange ?? null
      }
    }
    board = getSeason02QuestBoard(player, { runNumber: runtime.runNumber })
    return player
  })
  if (claiming) {
    const rewardLines = (outcome?.claimed ?? []).map(item =>
      `✅ *${item.title}* · ${item.rewardLines.join(' · ') || 'story recorded'}`,
    )
    if (!rewardLines.length && !delivered.length) {
      return ctx.reply(`📜 Nothing is ready to claim. Check progress with *${config.prefix}quest season*.`)
    }
    const text = [
      `「 ✅ SEASON SCENARIO CLEARED 」`,
      rewardLines.join('\n'),
      delivered.length ? `📦 Held items delivered: ${delivered.map(x => `${x.id.replaceAll('_', ' ')} ×${x.amount}`).join(', ')}` : '',
      levelMsgs.length ? levelMsgs.join('\n') : '',
      `\n${config.prefix}quest season · view the next objective`,
    ].filter(Boolean).join('\n\n')
    await ctx.reply(text)
    if (rankChange) await sendRankUp(ctx, ctx.player?.name ?? 'Hunter', rankChange.from, rankChange.to)
    return
  }
  return ctx.reply(renderSeasonQuestBoard(board, delivered))
}

export default {
  name:           'quest',
  aliases:        ['quests', 'missions'],
  category:       'progression',
  requiresPlayer: true,
  description:    `${config.prefix}quest [claim] — view your daily quests and milestones, and claim finished ones.`,

  async run(ctx) {
    const { args, reply } = ctx
    const sub = (args[0] ?? '').toLowerCase()

    // The season board is an explicit subcommand; the existing daily and
    // milestone board keeps its old default path and claim semantics.
    if (sub === 'season') return handleSeasonQuestBoard(ctx)

    // ── Claim path ─────────────────────────────────────────────────────────
    if (sub === 'claim' || sub === 'complete' || sub === 'turnin') {
      const id = args[1] ? args[1].toLowerCase() : null
      let outcome = null
      let lvlMsgs = []
      let rankChange = null
      let tutorialResult = null
      const activeSeason = getActiveSeason(ctx.db)
      const activeSeasonRun = activeSeason ? getSeasonRuntime(ctx.db).runNumber : null

      await updatePlayer(ctx.db, ctx.from, player => {
        outcome = claimQuest(player, id)
        const seasonRunStillActive = activeSeason?.id === 'season_02'
          && isSeasonRunActive(ctx.db, activeSeason.id, activeSeasonRun)
        if (!outcome.nothing && seasonRunStillActive) {
          ensurePlayerSeasonState(player, activeSeason.id)
          const dailyClaims = outcome.claimed.filter((claim) => claim.track === 'daily').length
          if (dailyClaims) {
            grantSeasonPassXp(
              player,
              activeSeason,
              dailyClaims * Number(activeSeason.battlePass?.dailyScenarioXp ?? 45),
              { source: 'dailyScenario' },
            )
          }
          const dailyBoard = getQuestBoard(player).daily
          const allDailyConditionsCleared = dailyBoard.length > 0 && dailyBoard.every((quest) => quest.done && quest.claimed)
          if (allDailyConditionsCleared && player.seasonProgress.dailyClearConditionDay !== player.quests.day) {
            player.seasonProgress.dailyClearConditionDay = player.quests.day
            grantSeasonPassXp(player, activeSeason, activeSeason.battlePass?.dailyClearConditionBonusXp ?? 60, { source: 'dailyClearCondition' })
          }
        }
        // Quest XP can push a level, same as daily.js: settle it here so the
        // player sees the level in the same breath as the claim.
        if (!outcome.nothing) {
          const res = applyLevelUps(player, levelsData, classes, races, getTotalStats)
          lvlMsgs = res.msgs ?? []
          rankChange = res.rankChange ?? null
          // ── Tutorial hook: quest completed ──────────────────────────
          tutorialResult = recordTutorialEvent(player, 'quest_completed')
        }
        return player
      })

      if (outcome.nothing) {
        return reply(
          `📜 *Nothing to claim yet.*\n\n_Finish a quest first, then come back. See the board with *${config.prefix}quest*._`,
        )
      }

      const rewardLines = outcome.claimed
        .map(c => `✅ *${c.name}*  ·  ${c.rewardLabel ?? 'reward'}`)
        .join('\n')
      const legacyClaim =
        `🎁 *QUESTS CLAIMED*\n\n${rewardLines}` +
        (lvlMsgs.length ? `\n\n${lvlMsgs.join('\n')}` : '') +
        (tutorialResult ? `\n\n${tutorialNotice(tutorialResult, config.prefix)}` : '') +
        `\n\n_See what's left with *${config.prefix}quest*._`
      await reply(styledPanel(ctx.db, {
        emoji: '🎁',
        title: 'Quests Claimed',
        blocks: [
          rewardLines,
          lvlMsgs.length ? lvlMsgs.join('\n') : null,
          tutorialResult ? tutorialNotice(tutorialResult, config.prefix) : null,
        ],
        footer: ['quest', 'gate'],
      }, legacyClaim))

      if (rankChange) {
        await sendRankUp(ctx, ctx.player?.name ?? 'Hunter', rankChange.from, rankChange.to)
      }
      return
    }

    // ── List path (default) ──────────────────────────────────────────────────
    // Touch state once so a brand-new player or a day rollover is persisted even
    // if they only ever look at the board.
    let board = null
    await updatePlayer(ctx.db, ctx.from, player => {
      ensureQuestState(player)
      board = renderBoard(player, ctx.db)
      return player
    })
    return reply(board)
  },
}
