/**
 * answer.js — `.answer <text>` : answer whoever is asking.
 *
 * TWO ASKERS, one command, and only one of them can ever be waiting:
 *
 *   · the old gatekeeper on the mountain road (lib/sect-road.js) — his two
 *     questions and his final "will you walk it?" are answered here, because a
 *     conversation that has to be answered with a second command name is a
 *     conversation players get stuck in. He takes a number or words.
 *   · the old woman's riddle in Astral Town (The End event, below).
 *
 * The road is checked FIRST and only when the player is actually mid-road, so
 * the Blue Band flow cannot change behaviour for anybody who is not standing in
 * front of the gatekeeper.
 *
 * The old woman's branch. The Blue Band arc (The End event) hinges on one question — "Are you from this
 * world, young boy?" — asked by `.shop buy blue band`. This is a real command
 * rather than a free-text capture so it works identically in DMs and in groups,
 * and can never be triggered by accident mid-conversation.
 *
 * Honest answer ("no") → she hands over the Blue Band.
 * Anything else        → her door locks until the player leaves Astral Town and
 *                        comes back (the lock is cleared by applyEndEventTick,
 *                        see lib/end-event.js).
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { answerRoadOnce, isOnRoad, roadAnswer } from '../lib/sect-road.js'
import { isOnWayBack, wayBackAnswer } from '../lib/sect-wayback.js'
import { deliverPendingSeasonPoints, getActiveSeason, settleSeasonOnReturn, takeLateSeasonNote } from '../lib/season-engine.js'
import { ASTRA_KINGDOM, SECT_EMPIRE } from '../lib/worlds.js'
// The last answer of either conversation is a crossing, and a crossing gets the
// arrival beat: the picture of the world tearing, with the welcome under it.
import { sendWorldTear } from '../lib/world-arrival.js'
import { hasInventoryRoom, inventoryFullMessage } from '../lib/inventory-limits.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import {
  BLUE_BAND_ID, hasBlueBand,
  RIDDLE_CORRECT, RIDDLE_WRONG, RIDDLE_ALREADY_BANDED,
} from '../lib/end-event.js'

/**
 * Is this an honest "I am not from this world"?
 *
 * Generous on purpose — she's reading magical energy, not grading grammar — but
 * an explicit "yes" (or "I am from...") always loses, even when padded with a
 * stray "not", so a contradictory answer can never sneak through.
 */
function isHonestNo(text) {
  const t = String(text ?? '')
    .toLowerCase()
    .replace(/[^a-z\s']/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
  if (!t) return false
  if (/\byes\b/.test(t) || /\byeah\b/.test(t) || /\bhai\b/.test(t)) return false
  if (/\bi am from\b/.test(t) || /\bi'm from\b/.test(t)) return false
  return /\b(no|nope|nah|naw|iie|not|isekai|another)\b/.test(t)
}

export default {
  name: 'answer',
  aliases: ['ans', 'respond'],
  category: 'event',
  requiresPlayer: true,
  description: `${config.prefix}answer <your reply> — answer the old woman's riddle in Astral Town (The End event)`,

  async run(ctx) {
    const p = config.prefix
    const text = (ctx.args ?? []).join(' ').trim()

    // ── The mountain road ─────────────────────────────────────────────────
    // Answered inside the caller's own mutator so the answer, the next step and
    // (on the last one) the whole conversion are one write. A double tap lands
    // on the second call finding the road already finished.
    if (isOnRoad(ctx.player)) {
      let out = null
      // Per-player single flight: a double tap cannot run two answers (and so
      // cannot reach the last step twice) for the same person.
      const ran = await answerRoadOnce(ctx.from, async () => {
        await updatePlayer(ctx.db, ctx.from, pl => {
          out = roadAnswer(pl, text, { db: ctx.db, from: ctx.from, isOwner: isOwnerJid(ctx.from) })
          return pl
        })
      })
      if (!ran) return ctx.reply(`🪨 *One answer at a time.* _He heard the first one._`)
      if (out?.kind === 'nothing') {
        return ctx.reply(`🪨 *Nobody is asking you anything.* _The road is closed behind you._`)
      }
      // 'committed' is the last answer, and the conversion is already written by
      // the time this runs: the player is standing at the foot of the mountain,
      // so the arrival gets the tear on the way in. Every other kind is still
      // the conversation, and gets its words alone.
      if (out?.kind === 'committed') await sendWorldTear(ctx, SECT_EMPIRE, { from: ASTRA_KINGDOM })
      return ctx.reply((out?.lines ?? []).join('\n\n'))
    }

    // ── The way back down (Prompt 8) ─────────────────────────────────────
    // The same gatekeeper, the same command, the other direction. The
    // crossing itself is one mutator (lib/sect-wayback.js), so a double tap
    // finds the player already down the mountain and changes nothing.
    if (isOnWayBack(ctx.player)) {
      let out = null
      const ran = await answerRoadOnce(ctx.from, async () => {
        await updatePlayer(ctx.db, ctx.from, pl => {
          const now = Date.now()
          out = wayBackAnswer(pl, text, { now })
          if (out?.kind === 'committed') {
            // A season that ended while they were up the mountain never paid
            // them (endSeason leaves a cultivator's Astra record alone). It is
            // settled here, on the step that brings them home, BEFORE anything
            // rolls their record into the new season and zeroes the points.
            if (settleSeasonOnReturn(ctx.db, pl, now)) {
              const note = takeLateSeasonNote(pl)
              if (note) out.lines.push(note)
            }
            const delivered = deliverPendingSeasonPoints(ctx.db, pl, now)
            if (delivered) {
              const season = getActiveSeason(ctx.db, now)
              const currency = season?.currencyLabel ?? (season?.id === 'season_02' ? 'Stars' : 'Season Points')
              const emoji = season?.id === 'season_02' ? '⭐' : '✨'
              out.lines.push(`${emoji} *${delivered} saved ${currency}* arrived with your Astra record.`)
            }
          }
          return pl
        })
      })
      if (!ran) return ctx.reply(`🪨 *One answer at a time.* _He heard the first one._`)
      if (out?.kind === 'nothing') {
        return ctx.reply(`🪨 *Nobody is asking you anything.*`)
      }
      // The same beat, walked down: the world tore again and the kingdom they
      // came to is the one they left this morning, exactly as they left it.
      if (out?.kind === 'committed') await sendWorldTear(ctx, ASTRA_KINGDOM, { from: SECT_EMPIRE })
      return ctx.reply((out?.lines ?? []).join('\n\n'))
    }

    if (!text) {
      return ctx.reply(
        `❌ *Usage:* *${p}answer <your reply>*\n` +
        `_Example:_ *${p}answer no*`,
      )
    }

    // Read the pending riddle off the live record, not ctx.player, so two fast
    // messages can't both be answered.
    let outcome = null
    await updatePlayer(ctx.db, ctx.from, (player) => {
      if (player.blueBandRiddle?.state !== 'awaiting_answer') {
        outcome = { kind: 'nothing' }
        return player
      }

      if (hasBlueBand(player) || (player.inventory ?? []).includes(BLUE_BAND_ID)) {
        player.blueBandRiddle = null
        outcome = { kind: 'already' }
        return player
      }

      if (!isHonestNo(text)) {
        player.blueBandRiddle = { state: 'locked', lockedAt: Date.now() }
        outcome = { kind: 'wrong' }
        return player
      }

      // Honest. Room is checked inside the mutator so a full bag can't eat the
      // band — the riddle stays pending and they can answer again after tidying.
      if (!hasInventoryRoom(player, 1)) {
        outcome = { kind: 'full', message: inventoryFullMessage(player) }
        return player
      }

      player.inventory.push(BLUE_BAND_ID)
      player.blueBandRiddle = null
      outcome = { kind: 'granted' }
      return player
    })

    if (outcome.kind === 'nothing') {
      return ctx.reply(
        `🤔 *Nobody asked you anything.*\n` +
        `_If you're after a Blue Band, ask the old woman in Astral Town:_ *${p}shop buy blue band*`,
      )
    }
    if (outcome.kind === 'already') return ctx.reply(RIDDLE_ALREADY_BANDED)
    if (outcome.kind === 'wrong')   return ctx.reply(RIDDLE_WRONG)
    if (outcome.kind === 'full') {
      return ctx.reply(
        `❌ ${outcome.message}\n` +
        `👵 _"Hands full, hands full. Come back when you can carry it, child."_\n` +
        `_Her question still stands — answer again once you've made room._`,
      )
    }

    return ctx.reply(RIDDLE_CORRECT.replaceAll('{prefix}', p))
  },
}
