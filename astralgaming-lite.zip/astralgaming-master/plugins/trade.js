import { hasTradeMastery, TRADE_MASTERY_MESSAGE } from '../lib/survival-progression.js'
/**
 * trade.js — player-to-player secure direct trade & barter responses.
 *
 * Supports:
 *   - Trader NPC barter responses from .roam (.trade accept / .trade decline)
 *   - Player-to-Player Direct Trade sessions with Escrow Safeguards:
 *       .trade @player            — initiate a direct trade session
 *       .trade offer solars <n>   — add solars to your trade offer
 *       .trade offer item <item>  — Astra inventory item, or a Sect item
 *       .trade offer stones <n>   — Spirit Stones in a Sect-world trade
 *       .trade confirm            — lock in & accept trade offer (both must confirm)
 *       .trade cancel             — cancel current trade session
 *       .trade status             — view current trade escrow
 */

import { tradeStatus as roamTradeStatus, tradeAccept as roamTradeAccept, tradeDecline as roamTradeDecline } from './roam.js'
import { config } from '../config.js'
import { extractTarget } from '../lib/group-helpers.js'
import { getPlayer, updatePlayer, updateAllPlayers } from '../lib/player-repo.js'
import { resolvePlayerId } from '../lib/identity-resolver.js'
import { allItems } from '../lib/game-data.js'
import { isInSectEmpire } from '../lib/worlds.js'
import {
  STONE_NAME, ensureItems, slotsFree, itemById, matchItem, countOf,
  artifactByUid, artifactsOf, isEquippedUid, addItem, removeItem, addStones, takeStones,
} from '../lib/sect-items.js'
import { pillById, selectPillLots } from '../lib/sect-pills.js'
import { qualityLabel } from '../lib/sect-marks.js'

const itemMap = Object.fromEntries(allItems.map(i => [i.id, i]))

export default {
  name: 'trade',
  aliases: ['p2ptrade'],
  category: 'town',
  requiresPlayer: true,
  description: 'Player-to-player direct trading; in the Sect Empire it exchanges Spirit Stones and Sect items',
  subcommands: [
    { cmd: '@player', desc: 'initiate a direct trading session with another player in the same world' },
    { cmd: 'offer solars <n>', desc: 'add Solars to an Astra trade' },
    { cmd: 'offer item <item>', desc: 'add an inventory item in Astra, or a Sect item on the mountain' },
    { cmd: 'offer stones <n>', desc: 'add Spirit Stones to a Sect trade' },
    { cmd: 'confirm', desc: 'lock in and finalize the trade (both must confirm)' },
    { cmd: 'cancel', desc: 'cancel the active trade session' },
    { cmd: 'accept / decline', desc: 'respond to roaming NPC barter offers' },
  ],

  async run(ctx) {
    const p = config.prefix
    const sub = ctx.args[0]?.toLowerCase()

    // 1. Check for Roam Trader NPC barter commands
    if (ctx.player.pendingTrade && (sub === 'accept' || sub === 'yes')) {
      return roamTradeAccept(ctx)
    }
    if (ctx.player.pendingTrade && (sub === 'decline' || sub === 'no')) {
      return roamTradeDecline(ctx)
    }
    if (ctx.player.pendingTrade && (!sub || sub === 'npc')) {
      return roamTradeStatus(ctx)
    }

    // 2. Direct Player-to-Player Trading
    if (!ctx.db.data.directTrades) ctx.db.data.directTrades = {}

    const mentionedTarget = extractTarget(ctx)
    if (mentionedTarget && mentionedTarget !== ctx.from) {
      return startDirectTrade(ctx, mentionedTarget)
    }

    if (sub === 'offer') {
      return addTradeOffer(ctx, ctx.args.slice(1))
    }
    if (sub === 'confirm' || sub === 'lock' || sub === 'accept') {
      return confirmDirectTrade(ctx)
    }
    if (sub === 'cancel' || sub === 'abort') {
      return cancelDirectTrade(ctx)
    }
    if (sub === 'status' || sub === 'view' || !sub) {
      return viewDirectTrade(ctx)
    }

    const sectMode = isInSectEmpire(ctx.player)
    return ctx.reply(
      `🤝 *PLAYER-TO-PLAYER DIRECT TRADE*${sectMode ? '  ·  SECT EMPIRE' : ''}\n\n` +
      `*Commands:*\n` +
      `• *${p}trade @player* — open a direct trading session\n` +
      (sectMode
        ? `• *${p}trade offer stones <amount>* — offer Spirit Stones\n• *${p}trade offer item <name> [grade n] [count]* — offer Sect items\n`
        : `• *${p}trade offer solars <amount>* — offer Solars\n• *${p}trade offer item <name>* — offer an Astra inventory item\n`) +
      `• *${p}trade confirm* — lock in & accept\n` +
      `• *${p}trade cancel* — abort session\n\n` +
      `_Nothing transfers until both players confirm._`,
    )
  },
}

function findActiveTrade(db, playerId) {
  const key = resolvePlayerId(db, playerId)
  const trades = Object.values(db.data.directTrades || {})
  return trades.find(t => t.status === 'active'
    && [t.playerA, t.playerB].some(id => resolvePlayerId(db, id) === key))
}

function emptyOffer() {
  return { solars: 0, items: [], spiritStones: 0, sectItems: [] }
}

function ensureTradeShape(trade) {
  if (!trade.offerA || typeof trade.offerA !== 'object') trade.offerA = emptyOffer()
  if (!trade.offerB || typeof trade.offerB !== 'object') trade.offerB = emptyOffer()
  for (const offer of [trade.offerA, trade.offerB]) {
    if (!Number.isFinite(Number(offer.solars))) offer.solars = 0
    if (!Array.isArray(offer.items)) offer.items = []
    if (!Number.isFinite(Number(offer.spiritStones))) offer.spiritStones = 0
    if (!Array.isArray(offer.sectItems)) offer.sectItems = []
  }
  if (trade.world !== 'sect') trade.world = 'astra'
  return trade
}

async function startDirectTrade(ctx, targetJid) {
  const p = config.prefix
  const playerId = resolvePlayerId(ctx.db, ctx.from)
  const targetId = resolvePlayerId(ctx.db, targetJid)
  if (playerId === targetId) return ctx.reply(`❌ You cannot trade with yourself.`)
  const target = getPlayer(ctx.db, targetId)
  if (!target) {
    return ctx.reply(`❌ Target player is not registered yet.`)
  }

  const sectTrade = isInSectEmpire(ctx.player)
  if (!sectTrade && (!hasTradeMastery(ctx.player) || !hasTradeMastery(target))) return ctx.reply(TRADE_MASTERY_MESSAGE)
  if (sectTrade !== isInSectEmpire(target)) {
    return ctx.reply(`🚪 *Both players must be in the same world to trade.* _Cross with_ *${p}road* _before opening the session._`)
  }
  if (sectTrade && (!ctx.player?.sect || !target?.sect)) {
    return ctx.reply(`🚪 *Both players need a Sect cultivation record to trade Spirit Stones and Sect items.*`)
  }

  const existingTrade = findActiveTrade(ctx.db, playerId) || findActiveTrade(ctx.db, targetId)
  if (existingTrade) {
    return ctx.reply(`⚠️ One of you is already in an active trade session! Use *${p}trade status* or *${p}trade cancel*.`)
  }

  if (!ctx.db.data.directTrades) ctx.db.data.directTrades = {}
  const tradeId = `p2p_${Date.now()}`
  ctx.db.data.directTrades[tradeId] = {
    id: tradeId,
    status: 'active',
    world: sectTrade ? 'sect' : 'astra',
    playerA: playerId,
    playerAName: ctx.player.name,
    playerB: targetId,
    playerBName: target.name,
    offerA: emptyOffer(),
    offerB: emptyOffer(),
    confirmedA: false,
    confirmedB: false,
    startedAt: Date.now(),
  }
  await ctx.db.write()

  const offerHelp = sectTrade
    ? `• *${p}trade offer stones <n>*\n• *${p}trade offer item <Sect item> [count]*`
    : `• *${p}trade offer solars <n>*\n• *${p}trade offer item <Astra item>*`
  return ctx.reply(
    `🤝 *TRADE SESSION OPENED!*${sectTrade ? '  ·  SECT EMPIRE' : ''}\n\n` +
    `*${ctx.player.name}* is trading with *${target.name}*.\n\n` +
    `Add to your offer with:\n${offerHelp}\n\n` +
    `Once both players are satisfied, type *${p}trade confirm* to finalize.`,
  )
}

async function addTradeOffer(ctx, args) {
  const p = config.prefix
  const trade = findActiveTrade(ctx.db, ctx.from)
  if (!trade) {
    return ctx.reply(`❌ You are not in an active trade session. Open one with *${p}trade @player*.`)
  }
  ensureTradeShape(trade)

  const kind = args[0]?.toLowerCase()
  const isA = resolvePlayerId(ctx.db, trade.playerA) === resolvePlayerId(ctx.db, ctx.from)
  const myOffer = isA ? trade.offerA : trade.offerB
  if (trade.world === 'sect') return addSectTradeOffer(ctx, trade, myOffer, args)

  if (kind === 'solars' || kind === 'solar') {
    const amt = parseInt(args[1], 10)
    if (isNaN(amt) || amt <= 0) {
      return ctx.reply(`❌ Specify a valid Solars amount: *${p}trade offer solars 5000*`)
    }
    const currentSolars = ctx.player.wallet?.solars || 0
    if (currentSolars < amt) {
      return ctx.reply(`❌ You only have ☀️ ${currentSolars.toLocaleString()} Solars.`)
    }
    myOffer.solars = amt
  } else if (kind === 'item') {
    const query = args.slice(1).join(' ').trim().toLowerCase()
    if (!query) return ctx.reply(`❌ Specify an item name: *${p}trade offer item iron_sword*`)

    const inv = ctx.player.inventory || []
    const matchId = inv.find(id => id === query || (itemMap[id]?.name?.toLowerCase().includes(query)))
    if (!matchId) {
      return ctx.reply(`❌ You do not have "${query}" in your inventory.`)
    }
    if (myOffer.items.includes(matchId)) {
      return ctx.reply(`⚠️ That item is already added to your trade offer.`)
    }
    const def = itemMap[matchId]
    if (def?.guildBound || def?.tradeLock || def?.guildId) {
      return ctx.reply(`🚫 *${def?.name ?? matchId}* is guild-bound — it cannot be traded. _Guild exclusives stay with their banner._`)
    }
    myOffer.items.push(matchId)
  } else {
    return ctx.reply(`Usage: *${p}trade offer solars <amount>* or *${p}trade offer item <name>*`)
  }

  // Any changes reset confirmations
  trade.confirmedA = false
  trade.confirmedB = false
  await ctx.db.write()

  return viewDirectTrade(ctx, `✅ *Offer updated!* (Confirmations reset for safety)`)
}

async function addSectTradeOffer(ctx, trade, myOffer, args) {
  const p = config.prefix
  const sect = ctx.player?.sect
  if (!sect) return ctx.reply(`🚪 *The mountain has no Sect inventory for you.*`)
  ensureItems(sect)

  const kind = String(args[0] ?? '').toLowerCase()
  if (['stone', 'stones', 'spiritstone', 'spiritstones', 'spirit_stone', 'spirit_stones'].includes(kind)) {
    const amount = Number(args[1])
    if (!Number.isSafeInteger(amount) || amount <= 0) {
      return ctx.reply(`Usage: *${p}trade offer stones <amount>*`)
    }
    const already = Math.max(0, Math.round(Number(myOffer.spiritStones) || 0))
    const held = Math.max(0, Math.round(Number(sect.spiritStones) || 0))
    if (already + amount > held) {
      return ctx.reply(`❌ You hold *${held} ${STONE_NAME}* and have already offered *${already}*.`)
    }
    myOffer.spiritStones = already + amount
  } else if (kind === 'item' || kind === 'sectitem' || kind === 'sect-item') {
    const parts = args.slice(1).map(String)
    let amount = 1
    if (parts.length > 1 && /^\d+$/.test(parts.at(-1)) && parts.at(-2).toLowerCase() !== 'grade') amount = Number(parts.pop())
    let grade = null
    if (parts.length >= 2 && parts.at(-2).toLowerCase() === 'grade') {
      grade = Number(parts.pop())
      parts.pop()
      if (!Number.isInteger(grade) || grade < 1 || grade > 9) return ctx.reply('💊 _Choose a whole pill grade from 1 to 9._')
    }
    const query = parts.join(' ').trim()
    if (!query || !Number.isSafeInteger(amount) || amount <= 0) {
      return ctx.reply(`Usage: *${p}trade offer item <Sect item> [count]*`)
    }
    const entry = matchItem(query)
    if (!entry) return ctx.reply(`❌ *"${query}"* is not a Sect item. Check *${p}inventory*.`)

    if (grade != null && entry.kind !== 'pill') return ctx.reply('💊 _Only pills have a selectable grade._')
    if (entry.kind === 'artifact') {
      if (amount !== 1) return ctx.reply(`⚠️ Sect artifacts are individual items. Offer one copy at a time.`)
      const artifact = artifactsOf(sect, entry.id).find(record =>
        !isEquippedUid(sect, record.uid) && record.bonded !== true && record.bound !== true
          && !myOffer.sectItems.some(row => row?.kind === 'artifact' && String(row.uid) === String(record.uid)))
      if (!artifact) {
        const copies = artifactsOf(sect, entry.id)
        const protectedCopies = copies.some(record => isEquippedUid(sect, record.uid) || record.bonded === true || record.bound === true)
        return ctx.reply(protectedCopies
          ? `🚫 *${entry.name}* is equipped, bonded, or bound. Those artifacts cannot be traded.`
          : `❌ You do not have an unoffered *${entry.name}* in your Sect bag.`)
      }
      myOffer.sectItems.push({ kind: 'artifact', id: entry.id, uid: String(artifact.uid) })
    } else {
      const held = countOf(sect, entry.id)
      const offered = myOffer.sectItems
        .filter(row => row?.kind === 'stack' && String(row.id) === String(entry.id))
        .reduce((sum, row) => sum + Math.max(0, Math.round(Number(row.count) || 0)), 0)
      if (offered + amount > held) {
        return ctx.reply(`❌ You hold *${held} ${entry.name}* and have already offered *${offered}*.`)
      }
      if (entry.kind === 'pill') {
        // Reserve the exact grade and quality in the offer, not just an id.
        // Work on a copy so multiple offers cannot select the same dose twice.
        const available = copyPlain(sect)
        for (const row of myOffer.sectItems.filter(row => row?.kind === 'stack' && row.id === entry.id)) {
          const gone = removeItem(available, entry.id, row.count, row.lots ? { lots: row.lots } : {})
          if (!gone.ok) return ctx.reply('❌ _A previously offered pill changed. Cancel and make the offer again._')
        }
        const lots = selectPillLots(available, pillById(entry.id), { grade, count: amount })
        if (!lots) return ctx.reply(`❌ _You do not hold ${amount} unoffered ${grade == null ? '' : `grade ${grade} `}${entry.name}._`)
        myOffer.sectItems.push({ kind: 'stack', id: entry.id, count: amount, lots })
      } else {
        myOffer.sectItems.push({ kind: 'stack', id: entry.id, count: amount })
      }
    }
  } else {
    return ctx.reply(`Usage: *${p}trade offer stones <amount>* or *${p}trade offer item <Sect item> [count]*`)
  }

  trade.confirmedA = false
  trade.confirmedB = false
  await ctx.db.write()
  return viewDirectTrade(ctx, `✅ *Offer updated!* (Confirmations reset for safety)`)
}

function viewDirectTrade(ctx, headerNote = '') {
  const p = config.prefix
  const trade = findActiveTrade(ctx.db, ctx.from)
  if (!trade) {
    return ctx.reply(`ℹ️ No active trade session. Start one with *${p}trade @player*.`)
  }
  ensureTradeShape(trade)

  const formatOffer = (name, offer, confirmed) => {
    const status = confirmed ? '🔒 *CONFIRMED*' : '⏳ _Pending_'
    if (trade.world === 'sect') {
      const sectItems = offer.sectItems.map(row => {
        const name = itemById(row.id)?.name ?? row.id
        if (row.kind === 'artifact') return `${name} (artifact)`
        if (Array.isArray(row.lots)) return row.lots.map(lot =>
          `${name} ×${lot.count} (${lot.grade == null ? 'realm-scaled' : `grade ${lot.grade}`}${lot.quality ? `, ${qualityLabel(lot.quality)}` : ''})`,
        ).join(', ')
        return `${name} ×${row.count}`
      }).join(', ') || 'none'
      return `*${name}* (${status}):\n  💎 ${STONE_NAME}: ${Number(offer.spiritStones).toLocaleString()}\n  🎒 Sect items: ${sectItems}`
    }
    const items = offer.items.map(id => itemMap[id]?.name || id).join(', ') || 'none'
    return `*${name}* (${status}):\n  ☀️ Solars: ${Number(offer.solars).toLocaleString()}\n  📦 Items: ${items}`
  }

  const note = headerNote ? `${headerNote}\n\n` : ''
  const offerHelp = trade.world === 'sect' ? 'stones|item' : 'solars|item'
  return ctx.reply(
    `${note}🤝 *TRADE WINDOW*${trade.world === 'sect' ? '  ·  SECT EMPIRE' : ''}\n\n` +
    `${formatOffer(trade.playerAName, trade.offerA, trade.confirmedA)}\n\n` +
    `${formatOffer(trade.playerBName, trade.offerB, trade.confirmedB)}\n\n` +
    `*Commands:* *${p}trade offer <${offerHelp}>* · *${p}trade confirm* · *${p}trade cancel*`,
  )
}

async function confirmDirectTrade(ctx) {
  const p = config.prefix
  const trade = findActiveTrade(ctx.db, ctx.from)
  if (!trade) return ctx.reply(`❌ You are not in an active trade session.`)
  ensureTradeShape(trade)

  const isA = resolvePlayerId(ctx.db, trade.playerA) === resolvePlayerId(ctx.db, ctx.from)
  if (isA) trade.confirmedA = true
  else trade.confirmedB = true

  if (trade.world === 'sect') {
    if (trade.confirmedA && trade.confirmedB) return settleSectTrade(ctx, trade)
    await ctx.db.write()
    return viewDirectTrade(ctx, `🔒 *You confirmed the trade!* Waiting on the other player...`)
  }

  // Check if both confirmed
  if (trade.confirmedA && trade.confirmedB) {
    // Execute trade atomically
    const pA = getPlayer(ctx.db, trade.playerA)
    const pB = getPlayer(ctx.db, trade.playerB)

    if (!hasTradeMastery(pA) || !hasTradeMastery(pB)) return ctx.reply(TRADE_MASTERY_MESSAGE)

    // Final inventory & solar check
    const solarsA = pA.wallet?.solars || 0
    const solarsB = pB.wallet?.solars || 0

    if (solarsA < trade.offerA.solars || solarsB < trade.offerB.solars) {
      delete ctx.db.data.directTrades[trade.id]
      await ctx.db.write()
      return ctx.reply(`❌ Trade failed: One of the players no longer holds the offered Solars.`)
    }

    // Execute swap on Player A
    await updatePlayer(ctx.db, trade.playerA, player => {
      const w = player.wallet ?? (player.wallet = {})
      w.solars = (w.solars || 0) - trade.offerA.solars + trade.offerB.solars
      const inv = player.inventory ?? (player.inventory = [])
      for (const id of trade.offerA.items) {
        const idx = inv.indexOf(id)
        if (idx !== -1) inv.splice(idx, 1)
      }
      for (const id of trade.offerB.items) {
        inv.push(id)
      }
    })

    // Execute swap on Player B
    await updatePlayer(ctx.db, trade.playerB, player => {
      const w = player.wallet ?? (player.wallet = {})
      w.solars = (w.solars || 0) - trade.offerB.solars + trade.offerA.solars
      const inv = player.inventory ?? (player.inventory = [])
      for (const id of trade.offerB.items) {
        const idx = inv.indexOf(id)
        if (idx !== -1) inv.splice(idx, 1)
      }
      for (const id of trade.offerA.items) {
        inv.push(id)
      }
    })

    delete ctx.db.data.directTrades[trade.id]
    await ctx.db.write()

    return ctx.reply(
      `🎉 *TRADE COMPLETED SUCCESSFULLY!*\n\n` +
      `Both *${trade.playerAName}* and *${trade.playerBName}* confirmed the exchange.\n` +
      `All Solars and items have been safely transferred through escrow!`,
    )
  }

  await ctx.db.write()
  return viewDirectTrade(ctx, `🔒 *You confirmed the trade!* Waiting on the other player...`)
}

function copyPlain(value) {
  return JSON.parse(JSON.stringify(value))
}

function sectTransferOf(profile, offer) {
  ensureItems(profile)
  const stones = Number(offer.spiritStones)
  if (!Number.isSafeInteger(stones) || stones < 0) return { error: 'invalid-offer' }
  const heldStones = Math.max(0, Math.round(Number(profile.spiritStones) || 0))
  if (heldStones < stones) return { error: 'stones-changed' }

  const stacks = []
  const stackTotals = new Map()
  const artifactUids = new Set()
  const artifacts = []
  for (const row of offer.sectItems) {
    const entry = itemById(row?.id)
    if (!entry) return { error: 'item-changed' }
    if (row.kind === 'stack') {
      const count = Number(row.count)
      if (entry.kind === 'artifact' || !Number.isSafeInteger(count) || count <= 0) return { error: 'invalid-offer' }
      if (row.lots != null && (entry.kind !== 'pill' || !Array.isArray(row.lots))) return { error: 'invalid-offer' }
      stackTotals.set(entry.id, (stackTotals.get(entry.id) ?? 0) + count)
      stacks.push({ id: entry.id, count, ...(row.lots ? { lots: copyPlain(row.lots) } : {}) })
    } else if (row.kind === 'artifact') {
      const uid = String(row.uid ?? '')
      const artifact = artifactByUid(profile, uid)
      if (!uid || artifactUids.has(uid) || !artifact || String(artifact.id) !== String(entry.id)) return { error: 'item-changed' }
      if (isEquippedUid(profile, uid) || artifact.bonded === true || artifact.bound === true) return { error: 'artifact-protected' }
      artifactUids.add(uid)
      artifacts.push(copyPlain(artifact))
    } else return { error: 'invalid-offer' }
  }

  for (const [id, count] of stackTotals) {
    if (countOf(profile, id) < count) return { error: 'item-changed' }
  }
  return {
    error: null,
    stones,
    stacks,
    artifacts,
  }
}

function removeSectTransfer(profile, transfer) {
  if (transfer.stones > 0 && !takeStones(profile, transfer.stones).ok) return 'stones-changed'
  for (const row of transfer.stacks) {
    const removed = removeItem(profile, row.id, row.count, row.lots ? { lots: row.lots } : {})
    if (!removed.ok) return 'item-changed'
    // Old pending offers did not name lots. Capture whatever was actually
    // removed so even those offers cannot destroy grade or quality in transit.
    if (removed.lots) row.lots = removed.lots
  }
  if (transfer.artifacts.length) {
    const uids = new Set(transfer.artifacts.map(record => String(record.uid)))
    const bag = ensureItems(profile)
    const before = bag.artifacts.length
    bag.artifacts = bag.artifacts.filter(record => !uids.has(String(record.uid)))
    if (before - bag.artifacts.length !== uids.size) return 'item-changed'
  }
  return null
}

function addSectTransfer(profile, transfer) {
  if (transfer.stones > 0) addStones(profile, transfer.stones)
  for (const row of transfer.stacks) {
    const lots = row.lots ?? [{ count: row.count }]
    for (const lot of lots) {
      const result = addItem(profile, row.id, lot.count, { grade: lot.grade ?? null, quality: lot.quality ?? null })
      if (!result.ok) return result.reason === 'full' ? 'bag-full' : 'item-changed'
    }
  }
  for (const artifact of transfer.artifacts) {
    const bag = ensureItems(profile)
    if (slotsFree(profile) < 1) return 'bag-full'
    const used = new Set(bag.artifacts.map(record => String(record.uid)))
    let next = Math.max(1, Math.round(Number(bag.nextUid) || 1))
    while (used.has(String(next))) next++
    const uid = String(next)
    bag.nextUid = next + 1
    bag.artifacts.push({ ...copyPlain(artifact), uid, bonded: false })
  }
  return null
}

function sectTradeFailure(reason) {
  const words = {
    'missing-player': 'One player is no longer registered.',
    'missing-sect': 'Both players need a Sect inventory to complete this trade.',
    'stones-changed': 'A Spirit Stones offer changed before confirmation.',
    'item-changed': 'An offered Sect item is no longer available.',
    'artifact-protected': 'An offered artifact is equipped, bonded, or bound and cannot be traded.',
    'bag-full': 'One player’s Sect bag has no room for the incoming items.',
    'invalid-offer': 'The offer is invalid; no assets were moved.',
  }
  return words[reason] ?? 'The trade could not be completed; no assets were moved.'
}

async function settleSectTrade(ctx, trade) {
  const db = ctx.db
  const playerAId = resolvePlayerId(db, trade.playerA)
  const playerBId = resolvePlayerId(db, trade.playerB)
  if (playerAId === playerBId) {
    delete db.data.directTrades[trade.id]
    await db.write()
    return ctx.reply(`❌ A player cannot trade with the same account.`)
  }

  let failure = null
  let settled = false
  await updateAllPlayers(db, users => {
    const playerA = users[playerAId]
    const playerB = users[playerBId]
    if (!playerA || !playerB) failure = 'missing-player'
    else if (!playerA.sect || !playerB.sect) failure = 'missing-sect'

    let sectA = null
    let sectB = null
    let transferA = null
    let transferB = null
    if (!failure) {
      sectA = copyPlain(playerA.sect)
      sectB = copyPlain(playerB.sect)
      transferA = sectTransferOf(sectA, trade.offerA)
      transferB = sectTransferOf(sectB, trade.offerB)
      failure = transferA.error || transferB.error || null
    }
    if (!failure) failure = removeSectTransfer(sectA, transferA) || removeSectTransfer(sectB, transferB)
    if (!failure) failure = addSectTransfer(sectB, transferA) || addSectTransfer(sectA, transferB)

    if (failure) {
      // Close a failed escrow in the same global write; the original profiles
      // were only changed on clones, so no partial transfer can escape.
      delete db.data.directTrades[trade.id]
      return true
    }

    playerA.sect = sectA
    playerB.sect = sectB
    delete db.data.directTrades[trade.id]
    settled = true
    return true
  })

  if (!settled) {
    return ctx.reply(`❌ *Sect trade cancelled.* ${sectTradeFailure(failure)}`)
  }
  return ctx.reply(
    `🎉 *SECT TRADE COMPLETED!*\n\n` +
    `Both *${trade.playerAName}* and *${trade.playerBName}* confirmed. ` +
    `${STONE_NAME} and Sect items were transferred atomically; artifact details were kept with fresh receiver ids.`,
  )
}

async function cancelDirectTrade(ctx) {
  const trade = findActiveTrade(ctx.db, ctx.from)
  if (!trade) return ctx.reply(`❌ No active trade session to cancel.`)

  delete ctx.db.data.directTrades[trade.id]
  await ctx.db.write()
  return ctx.reply(`🚫 The trade session was canceled. All escrowed assets returned safely.`)
}
