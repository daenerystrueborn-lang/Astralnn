/**
 * combos — view your combo book and discovered ability chains.
 *
 * Usage:
 *   .combos           — view your combo book
 *   .combos list      — same as above
 *   .combos hints     — get vague hints about undiscovered combos
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import {
  ensureCombos,
  formatComboBook,
  getUndiscoveredCombos,
  getDiscoveredCombos,
  totalCombosForClass,
  COMBOS,
} from '../lib/combo-engine.js'

export default {
  name: 'combos',
  aliases: ['combo', 'combobook'],
  category: 'combat',
  requiresPlayer: true,
  description: 'View your discovered ability combos',
  subcommands: [
    { cmd: '', desc: 'view your combo book' },
    { cmd: 'hints', desc: 'get hints about undiscovered combos' },
    { cmd: 'all', desc: 'list all combo tiers and class restrictions' },
  ],

  async run(ctx) {
    const p = config.prefix
    const sub = (ctx.args[0] ?? '').toLowerCase().trim()

    // ── .combos hints ───────────────────────────────────────────────────
    if (sub === 'hints' || sub === 'hint') {
      let text = ''
      await updatePlayer(ctx.db, ctx.from, player => {
        ensureCombos(player)
        const undiscovered = getUndiscoveredCombos(player)
        const discovered = getDiscoveredCombos(player)
        const total = totalCombosForClass(player.classId)

        if (undiscovered.length === 0) {
          text = `📖 *Combo Book*\n\nYou've discovered all ${total} combos available to your class! 🎉`
          return player
        }

        const lines = [
          `📖 *Combo Hints* (${discovered.length}/${total} discovered)`,
          ``,
        ]

        // Give vague hints without revealing sequences
        for (const combo of undiscovered.slice(0, 5)) {
          const hints = []
          if (combo.sequence.length === 2) hints.push('2-ability chain')
          if (combo.sequence.length === 3) hints.push('3-ability chain')
          if (combo.classRestriction) hints.push(`Class: ${combo.classRestriction}`)
          hints.push(`Tier: ${combo.tier}`)

          lines.push(`${combo.emoji} *???* — ${combo.bonus.label}`)
          lines.push(`   _${hints.join(' | ')}_`)
          lines.push(``)
        }

        if (undiscovered.length > 5) {
          lines.push(`_...and ${undiscovered.length - 5} more undiscovered._`)
        }

        lines.push(``, `_Experiment with different ability sequences in combat!_`)
        text = lines.join('\n')
        return player
      })
      return ctx.reply(text)
    }

    // ── .combos all ─────────────────────────────────────────────────────
    if (sub === 'all') {
      const tiers = ['basic', 'advanced', 'master']
      const lines = [`📖 *All Combos*`, ``]

      for (const tier of tiers) {
        const combosInTier = COMBOS.filter(c => c.tier === tier)
        lines.push(`*${tier.toUpperCase()} (${combosInTier.length} combos)*`)
        for (const combo of combosInTier) {
          const classLabel = combo.classRestriction ? ` [${combo.classRestriction}]` : ' [all classes]'
          lines.push(`  ${combo.emoji} ${combo.name}${classLabel}`)
        }
        lines.push(``)
      }

      lines.push(
        `_Combos marked with a class are only available to that class._\n` +
        `_Universal combos work for everyone._\n` +
        `_Use ${p}combos hints to find undiscovered combos._`,
      )
      return ctx.reply(lines.join('\n'))
    }

    // ── .combos (default) ───────────────────────────────────────────────
    let text = ''
    await updatePlayer(ctx.db, ctx.from, player => {
      text = formatComboBook(player, p)
      return player
    })
    return ctx.reply(text)
  },
}
