/**
 * event.js — `.event` : the current world event hub.
 *
 * Player-facing:
 *   .event                  — the featured world event, its clock, and your standing
 *                             (live event first, otherwise the NEWEST event in
 *                             lib/world-events.js — so new events show up here
 *                             automatically as soon as they are registered)
 *
 * Owner-only (lib/group-helpers.js's isOwnerJid). <event> defaults to the
 * newest registered event; name one to target an older event (e.g. `the end`):
 *   .event start [event] [days]   — open the event
 *   .event end   [event]          — close it now
 *   .event skip  [event] [days]   — test hook: move its clock forward
 *   .event list                   — every registered event and its state
 *
 * Every lifecycle flip is a single write inside updateAllPlayers, so it rides
 * the same serialized queue as every other mutation (lib/player-repo.js) and
 * can't race a concurrent command.
 */
import { config } from '../config.js'
import { updateWorldState, flushNow, updateAllPlayers, getPlayer } from '../lib/player-repo.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import { formatTimeLeft } from '../lib/time-format.js'
import {
  getEndEvent, isEventActive, endPhase, endOpensAt,
  startEndEvent, forceEndEvent, skipEndEventWait, syncEndWeakenForAll,
  endStatusBadge,
  END_START_BROADCAST, END_FORCE_END_BROADCAST,
  END_WEAKEN_PCT, SLEEP_MAX_LEVEL, LUNA_GRACE_MS, THE_END_LOCATION_ID,
} from '../lib/end-event.js'
import {
  WORLD_EVENTS, WORLD_EVENT_MAP, featuredWorldEventKey, findWorldEvent, newestWorldEventKey,
} from '../lib/world-events.js'
import { EVENTS as SEASON_EVENTS, currentEvent, nextEvent, seasonWeek, eventCardText, eventScheduleText, findSeasonEvent, controlSeasonEvent, seasonEventControl } from '../lib/season-events.js'
import { getActiveSeason } from '../lib/season-engine.js'

// ── Overview routing ───────────────────────────────────────────────────────
// Which event to show lives in lib/world-events.js (featuredWorldEventKey).

const OWNER_ACTIONS = Object.freeze(Object.assign(Object.create(null), {
  start: 'start', open: 'start', end: 'end', stop: 'end', close: 'end', skip: 'skip', auto: 'auto',
}))

const RENDERERS = {
  end:      (ctx) => renderEndStatus(ctx),
}

function renderFeatured(ctx) {
  const live = currentEvent(ctx.db)
  if (live) return eventCardText(ctx.player ?? getPlayer(ctx.db, ctx.from), live, ctx.db, Date.now(), config.prefix)
  if (getActiveSeason(ctx.db)?.id === 'season_02' && seasonEventControl(ctx.db)?.manual) return eventScheduleText(ctx.db) + `\n\n${config.prefix}season event — participation and rewards`
  const key = featuredWorldEventKey(ctx.db)
  const render = RENDERERS[key]
  return render ? render(ctx) : seasonEventsText(ctx)
}

/**
 * seasonEventsText(ctx) — what `.event` shows when no world event is running.
 *
 * Guardian of the Innocent used to sit here as the free standing event between
 * The End's runs. It is gone, and the thing the realm actually has to look
 * forward to is the six scheduled Season 2 events, so this page names them
 * rather than leaving a bare "nothing is running" where a member expects to
 * find something to do.
 *
 * The six use their season gameplay board; owner controls here can override
 * the weekly schedule without changing the season-wide clock.
 */
function seasonEventsText(ctx) {
  const p = config.prefix
  const db = ctx.db
  const season = getActiveSeason(db)
  const lines = [
    '🌌 *No world event is running.*',
    '',
    `_The End is asleep. When the owner opens it, ${p}event shows its clock and your standing._`,
    '',
    '📺 *SEASON EVENTS*',
  ]
  if (!season) {
    lines.push(
      '_No season is running. The six scheduled events open inside Season 2, Life of a Regressor._',
      '',
      `▶️ *${p}season* : where the realm is in its run`,
    )
    return lines.join('\n')
  }
  if (season.id === 'season_02') {
    const week = seasonWeek(db)
    const live = currentEvent(db)
    const ahead = nextEvent(db)
    lines.push(`_Season 2 · Week ${week} of 10. Each event keeps its own week, and opens by itself._`, '')
    for (const ev of SEASON_EVENTS) {
      const mark = ev.week === week ? '  ← this week' : ev.week < week ? '  ← done' : ''
      lines.push(`• Week ${ev.week} · *${ev.name}*${mark}`)
    }
    lines.push('')
    if (live) {
      lines.push(`🟢 *${live.name} is live right now.*`, `▶️ *${p}season event* : its board and your progress`)
    } else if (ahead) {
      lines.push(`⏳ *${ahead.name}* opens on week ${ahead.week}.`, `▶️ *${p}season event* : the full schedule`)
    } else {
      lines.push(`_The scheduled run is over. The season closes in week 10._`, `▶️ *${p}season* : the closing record`)
    }
    return lines.join('\n')
  }
  // Another season is the live one. The six belong to Season 2 and there is no
  // way to reach them early, so name them, say where they are, and stop.
  lines.push(
    `_They belong to *Season 2, Life of a Regressor*, not to ${season.name}._`,
    '_Nothing is wrong: there is no command to open one early. The first lands on_',
    `_day 8 of Season 2, then one a week through week 7._`,
    '',
  )
  for (const ev of SEASON_EVENTS) {
    lines.push(`• Week ${ev.week} · *${ev.name}*`)
  }
  lines.push(
    '',
    `▶️ *${p}season event* : the schedule, and where Season 2 is`,
  )
  return lines.join('\n')
}

function renderList(ctx) {
  const p = config.prefix
  const featured = featuredWorldEventKey(ctx.db)
  const now = Date.now()
  const lines = ['🗓️ *WORLD EVENTS*', '']
  for (const ev of [...WORLD_EVENTS].reverse()) {
    const st = ev.state(ctx.db, now)
    const status = st.active ? '🟢 live' : st.startedAt ? '🔚 ended' : '🔒 not started'
    lines.push(`${ev.key === featured ? '⭐' : '•'} *${ev.name}* — ${status}  _(${ev.key})_`)
  }
  lines.push('', `_⭐ is what *${p}event* shows. Owner: *${p}event start <name>*._`)
  lines.push('', eventScheduleText(ctx.db), '', `Owner: ${p}event start <season-event-id> · ${p}event end <season-event-id> · ${p}event auto`)
  return lines.join('\n')
}

// ── Guardian of the Innocent ───────────────────────────────────────────────

// ── The End / Blue Band ────────────────────────────────────────────────────

function renderEndStatus(ctx) {
  const p = config.prefix
  const db = ctx.db
  const e = getEndEvent(db)
  const phase = endPhase(db)

  // Never started. The air is clean, and what the realm has to look forward to
  // is the scheduled season events, so the page says so instead of stopping.
  if (!e.startedAt) return seasonEventsText(ctx)

  // Over — leave the record standing as a monument.
  if (e.defeated) {
    const slayer = e.defeatedBy && e.defeatedBy !== 'owner' ? getPlayer(db, e.defeatedBy) : null
    const when = e.defeatedAt ? `${formatTimeLeft(Date.now() - e.defeatedAt)} ago` : 'some time ago'
    return (
      `🌅 *THE END — over.*\n\n` +
      (slayer
        ? `🗡️ Slain by *${slayer.name}* _(${when})_.\n\n`
        : `🌫️ The aura lifted _(${when})_.\n\n`) +
      `_The sky is clear. Keep your Blue Band anyway._`
    )
  }

  const you = ctx.player ? endStatusBadge(db, ctx.player) : null
  const header =
    `🌑 *THE END — ${phase === 'reckoning' ? 'THE RECKONING' : 'THE LONG SLEEP'}*\n\n`

  const aura =
    `🌫️ A concentrated magical air covers *Astral Town* and *every dungeon*.\n` +
    `• Unbanded: *−${Math.round(END_WEAKEN_PCT * 100)}%* to every stat.\n` +
    `• Unbanded and *Level ≤ ${SLEEP_MAX_LEVEL}*: *deep sleep*.\n` +
    `• *Blue Band* in your offhand: untouched.\n\n`

  const howTo =
    `🧿 *Getting a Blue Band*\n` +
    `1. Be in Astral Town — *${p}travel town*\n` +
    `2. Ask the old woman — *${p}shop buy blue band*\n` +
    `3. Answer her honestly — *${p}answer <your reply>*\n` +
    `4. Wear it — *${p}equip blue band*\n` +
    `_Answer wrong and her door shuts until you've been to a dungeon and back._\n\n` +
    `🍶 *${p}give-drink luna @player* — banded players can wake a sleeper for ` +
    `${Math.round(LUNA_GRACE_MS / 60000)} minutes.\n\n`

  const opensAt = endOpensAt(db)
  const clock = phase === 'reckoning'
    ? `⚔️ *The rift is open.* — *${p}enter ${THE_END_LOCATION_ID}*\n` +
      `☠️ _It does not care how strong you think you are._\n\n`
    : `⏳ *The rift opens in ${formatTimeLeft(Math.max(0, opensAt - Date.now()))}.*\n` +
      `☠️ _Enter *${THE_END_LOCATION_ID}* before then and the aura kills you on contact._\n\n`

  return header + aura + howTo + clock + (you ? `👤 *You:* ${you}` : '')
}

// ── Owner controls ────────────────────────────────────────────────────────

async function handleStart(ctx) {
  const p = config.prefix

  if (isEventActive(ctx.db)) {
    return ctx.reply(
      `⚠️ The End's aura is *already live*.\n` +
      `_${p}event — status · ${p}event end — lift it_`,
    )
  }

  await updateAllPlayers(ctx.db, (users) => {
    startEndEvent(ctx.db)
    syncEndWeakenForAll(ctx.db, users)
    return true
  })

  // Announce ONLY here, in the group where the owner ran it. Fanning the same
  // message out to every group is exactly what gets a WhatsApp number banned
  // for spam; players in other groups learn of the aura through their own
  // .event / .profile / .stats status lines.
  const text = END_START_BROADCAST.replaceAll('{prefix}', p)
  return ctx.reply(
    text +
    `\n\n⏳ _The rift opens in ${formatTimeLeft(Math.max(0, endOpensAt(ctx.db) - Date.now()))}._`,
  )
}

async function handleEnd(ctx) {
  const p = config.prefix

  let result = null
  await updateAllPlayers(ctx.db, (users) => {
    result = forceEndEvent(ctx.db)
    // Sweep the cached flags either way — a failed force still shouldn't leave
    // stale weaken flags lying around.
    const swept = syncEndWeakenForAll(ctx.db, users)
    return result.ok || swept
  })

  if (!result.ok) {
    return ctx.reply(
      result.reason === 'not_started'
        ? `⚠️ The event was never started. _${p}event start_`
        : `⚠️ The End is already down. _${p}event — status_`,
    )
  }

  // Announce only in this group (see handleStart — no fan-out).
  return ctx.reply(
    END_FORCE_END_BROADCAST +
    `\n\n✅ _Every sleeper is awake and every stat is back to normal._`,
  )
}

async function handleSkip(ctx) {
  const p = config.prefix

  let result = null
  await updateAllPlayers(ctx.db, () => {
    result = skipEndEventWait(ctx.db)
    return result.ok
  })

  if (!result.ok) {
    return ctx.reply(`⚠️ Nothing to skip — the event isn't running. _${p}event start_`)
  }
  return ctx.reply(
    `⏩ *Clock pulled forward.* The rift is open now.\n` +
    `_${p}enter ${THE_END_LOCATION_ID}_ — good luck.`,
  )
}

// ── Plugin export ─────────────────────────────────────────────────────────

export default {
  name:           'event',
  aliases:        ['endevent', 'theend', 'worldevent', 'events'],
  category:       'event',
  requiresPlayer: false,
  description:    `${config.prefix}event — the latest world event and your standing in it`,
  subcommands: [
    { cmd: 'event',                 desc: 'Current world event, how long it lasts, and your status' },
    { cmd: 'event list',            desc: 'Every world event and whether it is live' },
    { cmd: 'event start [event]',   desc: 'Owner — open the newest event (or the one named)' },
    { cmd: 'event auto', desc: 'Owner — restore automatic Season 2 scheduling' },
    { cmd: 'event end [event]',     desc: 'Owner — close the newest event (or the one named)' },
    { cmd: 'event skip [event] [n]', desc: 'Owner — move an event clock forward (testing)' },
  ],

  async run(ctx) {
    const args = ctx.args ?? []
    const action = String(args[0] ?? 'status').toLowerCase()

    if (action === 'status' || action === 'info') return ctx.reply(renderFeatured(ctx))
    if (action === 'list' || action === 'all') return ctx.reply(renderList(ctx))

    const op = OWNER_ACTIONS[action]
    if (op) {
      if (!isOwnerJid(ctx.from)) return ctx.reply('❌ Owner only.')
      const p = config.prefix
      const rest = args.slice(1).map(String)
      const numArg = rest.find(a => /^\d+$/.test(a))
      const nameStr = rest.filter(a => !/^\d+$/.test(a)).join(' ').trim()
      const seasonEvent = findSeasonEvent(nameStr)
      if (seasonEvent || op === 'auto') {
        const result = await updateWorldState(ctx.db, 'season-event-controls', () => controlSeasonEvent(ctx.db, op, seasonEvent?.id))
        await flushNow(ctx.db)
        return ctx.reply(result.replaceAll('.event', `${p}event`).replaceAll('.season', `${p}season`).replaceAll('.admin', `${p}admin`))
      }
      const key = nameStr ? findWorldEvent(nameStr) : newestWorldEventKey()
      if (!key) {
        return ctx.reply(
          `❌ No event called *${nameStr}*.\n` +
          `_Events: ${[...WORLD_EVENTS.map(ev => ev.key), ...SEASON_EVENTS.map(ev => ev.id)].map(id => `*${id}*`).join(', ')} — see *${p}event list*._`,
        )
      }
      if (key === 'end') {
        if (op === 'start') return handleStart(ctx)
        if (op === 'end') return handleEnd(ctx)
        return handleSkip(ctx)
      }
      return ctx.reply(`⚠️ *${WORLD_EVENT_MAP[key]?.name ?? key}* has no owner controls here yet.`)
    }

    // `.event theend` — peek at a specific event.
    // (Checked after owner actions: `.event end` means "close", not "show The End".)
    const peek = findWorldEvent(args.join(' '))
    if (peek && RENDERERS[peek]) return ctx.reply(RENDERERS[peek](ctx))

    return ctx.reply(
      `❌ Unknown option *${action}*.\n` +
      `_Try_ *${config.prefix}event* _for the current world event, or_ *${config.prefix}event list*.`,
    )
  },
}
