/**
 * takeitem.js — .takeitem <itemId|petId|beastId> [amount|all] [@mention | reply | phone | name]
 * Owner-only command to remove an item, weapon, pet, or beast from a player.
 */
import { isOwnerJid } from '../lib/group-helpers.js'
import { takeItem } from './admin.js'

export default {
  name: 'takeitem',
  aliases: ['removeitem', 'takepet', 'removepet', 'takeweapon', 'removeweapon'],
  category: 'admin',
  requiresPlayer: false,
  description: 'Owner-only: remove an item, weapon, pet, or beast from a player',

  async run(ctx) {
    if (!ctx.from || !isOwnerJid(ctx.from)) {
      return ctx.reply('❌ This command is restricted to the bot owner.')
    }
    return takeItem({ ...ctx, args: [null, ...ctx.args] })
  },
}
