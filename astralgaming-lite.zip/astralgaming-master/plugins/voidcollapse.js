// <prefix>voidcollapse - Rimuru, Veldanava form. Once per fight, PvE.
import { config } from '../config.js'
import { activateVoidCollapse } from '../lib/regressor-form-commands.js'
import { runRegressorCommand } from '../lib/regressor-command-runner.js'

export default {
  name: 'voidcollapse',
  aliases: ['nihilitycollapse'],
  category: 'combat',
  description: `${config.prefix}voidcollapse - Veldanava form. Massive AoE, no healing for 3 turns, kills cannot resurrect.`,
  requiresPlayer: true,
  async run(ctx) { return runRegressorCommand(ctx, activateVoidCollapse) },
}
