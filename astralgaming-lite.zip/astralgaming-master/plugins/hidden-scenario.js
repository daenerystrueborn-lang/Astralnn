/**
 * hidden-scenario. The Season 2 hidden scenarios and the 3am scene (Phase G).
 *
 *   .hiddenscenario               the clues you have not found, and your journal
 *   .hiddenscenario investigate <id>   follow a clue (h1 to h8)
 *   .hiddenscenario evelyn        the three scenes of the name Evelyn lost
 *   .hiddenscenario evelyn <1-3>  read one scene; the third only at 3am
 *
 * A Hidden Scenario is "one player, only if they find it": no deadline, it
 * cannot fail, and it is never a menu entry (docs/season-02-scenarios.md section
 * 2). The clues live in world text; this command shows them so nobody needs a
 * secret command list, and follows them. The discovery ledger, rewards and the
 * 3am gate live in lib/hidden-scenarios.js. Reading all three of Evelyn's scenes
 * reveals her lost name and records evelyn_true_name, which makes The Name You
 * Lost (scenario 37) claimable on the ladder.
 *
 * This is distinct from `.scenario` (the Personal Scenario window) and from
 * `.heavens`, which already owns the `hidden` alias. Copy follows
 * docs/season-02-style.md: short lines, no em dashes, no "!" in the System voice.
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { getActiveSeason } from '../lib/season-engine.js'
import {
  HIDDEN_SCENARIOS, EVELYN_SCENES, EVELYN_TRUE_NAME, NAME_HOUR_WAT,
  investigateHidden, readEvelynScene,
} from '../lib/hidden-scenarios.js'

const NOT_S2 = '🌙 Hidden scenarios belong to Season 2, Life of a Regressor. There is nothing to find right now.'

async function handleList(ctx) {
  const p = config.prefix
  const h = ctx.player?.hiddenScenarios ?? {}
  const found = h.found ?? {}
  const journal = h.journal ?? []
  const evelyn = h.evelyn ?? { scenes: [], nameFound: false }
  const foundCount = HIDDEN_SCENARIOS.filter(s => found[s.id]).length

  const lines = [
    `「 🗝 HIDDEN SCENARIOS 」`,
    `Found ${foundCount} of ${HIDDEN_SCENARIOS.length}. They cannot fail. They are only found.`,
    '',
  ]
  const undiscovered = HIDDEN_SCENARIOS.filter(s => !found[s.id])
  if (undiscovered.length) {
    lines.push('Clues:')
    for (const s of undiscovered) {
      lines.push(`⌁ ${s.no} · *${s.title}* · ${s.where}`)
      lines.push(`_${s.clue}_`)
    }
    lines.push('', `Follow a clue with *${p}hiddenscenario investigate <id>*, like h1.`)
  } else {
    lines.push('You have found every hidden scenario. The journal is yours.')
  }
  if (journal.length) {
    lines.push('', `In your journal: ${journal.map(j => j.title).join(', ')}.`)
  }
  const nameLine = evelyn.nameFound
    ? `The name Evelyn lost was *${EVELYN_TRUE_NAME}*.`
    : `The name Evelyn lost: ${evelyn.scenes.length} of 3 scenes read. *${p}hiddenscenario evelyn*`
  lines.push('', nameLine)
  return ctx.reply(lines.join('\n'))
}

async function handleInvestigate(ctx) {
  const p = config.prefix
  const id = (ctx.args[1] ?? '').toLowerCase()
  if (!id) {
    return ctx.reply(`Name a clue to follow, like *${p}hiddenscenario investigate h1*. See the clues with *${p}hiddenscenario*.`)
  }
  let result
  await updatePlayer(ctx.db, ctx.from, player => {
    result = investigateHidden(player, id)
    return player
  })
  if (result.status === 'unknown') {
    return ctx.reply(`No clue goes by that name. See the clues with *${p}hiddenscenario*.`)
  }
  if (result.status === 'found') {
    return ctx.reply(`*${result.def.title}*\n\n${result.def.scene}\n\n_Already in your journal._`)
  }
  if (result.status === 'locked') {
    return ctx.reply(`${result.def.clue}\n\n_You have not reached it yet. Climb to tower floor ${result.needFloor} first._`)
  }
  if (result.status === 'progress') {
    return ctx.reply(`${result.def.clue}\n\n_You have read it ${result.reads} of ${result.needReads} times._`)
  }
  const lines = [`「 🗝 HIDDEN SCENARIO FOUND 」`, `*${result.def.no} · ${result.def.title}*`, '', result.scene]
  if (result.rewardLabels?.length) lines.push('', result.rewardLabels.join('  ·  '))
  return ctx.reply(lines.join('\n'))
}

async function handleEvelyn(ctx) {
  const p = config.prefix
  const n = ctx.args[1]
  if (!n) {
    const h = ctx.player?.hiddenScenarios ?? {}
    const evelyn = h.evelyn ?? { scenes: [], nameFound: false }
    const lines = [
      `「 🕯 THE NAME EVELYN LOST 」`,
      'Three scenes. One of them only surfaces at 3am.',
      '',
    ]
    for (const s of EVELYN_SCENES) {
      const read = evelyn.scenes.includes(s.no)
      const gate = s.hourGate != null ? ` · only at ${s.hourGate}am` : ''
      lines.push(`⌁ Scene ${s.no} · *${s.title}*${gate} · ${read ? 'read' : 'unread'}`)
    }
    if (evelyn.nameFound) lines.push('', `Her name was *${EVELYN_TRUE_NAME}*.`)
    lines.push('', `Read a scene with *${p}hiddenscenario evelyn <1-3>*.`)
    return ctx.reply(lines.join('\n'))
  }
  let result
  await updatePlayer(ctx.db, ctx.from, player => {
    result = readEvelynScene(player, n)
    return player
  })
  if (result.status === 'unknown') {
    return ctx.reply('There are three scenes. Name one, 1 to 3.')
  }
  if (result.status === 'lockedHour') {
    return ctx.reply(`That scene only surfaces at ${result.hourGate}am server time, when the record spins the wrong way. Come back at the hour.`)
  }
  const lines = [`*Scene ${result.scene.no} · ${result.scene.title}*`, '', result.scene.text]
  if (result.nameRevealed) {
    lines.push('', `The name she lost was *${EVELYN_TRUE_NAME}*.`)
    lines.push(`_The Name You Lost is now ready to claim on *${p}quest*._`)
  }
  return ctx.reply(lines.join('\n'))
}

export default {
  name: 'hiddenscenario',
  aliases: ['hiddenscenarios'],
  category: 'season',
  requiresPlayer: true,
  description: `${config.prefix}hiddenscenario [investigate <id>|evelyn] · the Season 2 hidden scenarios`,
  subcommands: [
    { cmd: 'investigate <id>', desc: 'follow a clue, h1 to h8' },
    { cmd: 'evelyn [1-3]', desc: 'read the scenes of the name Evelyn lost' },
  ],

  async run(ctx) {
    const sub = (ctx.args[0] ?? 'list').toLowerCase()
    const season = getActiveSeason(ctx.db)
    if (!season || season.id !== 'season_02') return ctx.reply(NOT_S2)
    if (sub === 'investigate') return handleInvestigate(ctx)
    if (sub === 'evelyn') return handleEvelyn(ctx)
    return handleList(ctx)
  },
}
