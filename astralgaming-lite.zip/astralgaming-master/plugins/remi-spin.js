// <prefix>remi-spin [amount] — Remi's banner.
// 2 Gems a spin, 300 spins per player, guaranteed by spin 300. One-of-one
// bot-wide. The OTHER door is .character buy remi for 5 Monds.
import { runRegressorSpin } from '../lib/regressor-spin-runner.js'

export default {
  name: 'remi-spin',
  aliases: ['remispin', 'scarlet-spin', 'padlock-spin'],
  category: 'character',
  requiresPlayer: true,
  description: 'Spin for Remi: 2 Gems per spin, one-of-one, 300 spins, guaranteed by spin 300',
  async run(ctx) { return runRegressorSpin(ctx, 'remi') },
}
