/**
 * takegems.js — .takegems <amount|all> [@mention | reply | phone | name]
 * Owner-only command to remove Gems from a player's wallet.
 */
import { isOwnerJid } from '../lib/group-helpers.js'
import { takeGems } from './admin.js'

export default {
  name: 'takegems',
  aliases: ['takegem', 'removegems', 'removegem', 'tgem'],
  category: 'admin',
  requiresPlayer: false,
  description: 'Owner-only: remove Gems from a player',

  async run(ctx) {
    if (!ctx.from || !isOwnerJid(ctx.from)) {
      return ctx.reply('❌ This command is restricted to the bot owner.')
    }
    return takeGems({ ...ctx, args: [null, ...ctx.args] })
  },
}
