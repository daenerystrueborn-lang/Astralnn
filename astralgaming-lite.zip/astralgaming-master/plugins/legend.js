import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { withGrowthLock } from '../lib/sect-progress.js'
import { settlePendingHook } from '../lib/sect-fight.js'
import { beginLegendFight, legendScreen, masterOrder, legendRefusal } from '../lib/sect-legends.js'
import '../lib/sect-hooks.js'

export default {
  name: 'legend',
  category: 'sect',
  requiresPlayer: true,
  description: `${config.prefix}legend — your rival, story chapters and Master orders`,
  subcommands: [
    { cmd: 'rival', desc: 'challenge Shen Rui across three ascents' },
    { cmd: 'story [choice]', desc: 'choose your path through three story chapters' },
    { cmd: 'rule [scout|mentor|collect]', desc: 'lead your disciples as Sect Master' },
  ],
  async run(ctx) {
    const refusal = legendRefusal(ctx.player)
    if (refusal) return ctx.reply(refusal)
    const [word = '', choice = ''] = (ctx.args ?? []).map(s => String(s).toLowerCase())
    let lines = []
    const ran = await withGrowthLock(ctx.from, async () => {
      await updatePlayer(ctx.db, ctx.from, fresh => {
        const denied = legendRefusal(fresh)
        if (denied) { lines = [denied]; return fresh }
        const pending = settlePendingHook(fresh)
        if (pending?.length) { lines = pending; return fresh }
        const options = { now: Date.now(), prefix: config.prefix }
        if (word === 'rival' || word === 'story') lines = beginLegendFight(fresh, word, choice, options).lines
        else if (word === 'rule') lines = masterOrder(fresh, choice, options).lines
        else lines = legendScreen(fresh, config.prefix)
        return fresh
      })
    })
    return ctx.reply(ran ? lines.join('\n') : '⏳ *One chapter at a time. Your last action is still settling.*')
  },
}
