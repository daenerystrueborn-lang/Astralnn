/**
 * <prefix>companion — your companion.
 *
 *   .companion                   her card: perk, bond, story progress
 *   .companion talk <message>    talk to her (AI, Groq first via lib/ai.js)
 *   .companion <message>         same as talk
 *   .companion story [n]         the chapters of her past she has told you
 *   .companion accept|reject     answer a freed companion's request
 *
 * Companions speak in lowercase with no punctuation and no emoji. The model is
 * told so in renderCompanionSystemPrompt() and sanitizeCompanionSpeech() then
 * enforces it on whatever comes back, so a model that slips still reads right.
 *
 * The network call is made OUTSIDE updatePlayer, so a slow reply never holds
 * the save queue. The turn is written back afterwards.
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { askAI, hasAIKey } from '../lib/ai.js'
import {
  COMPANION_MAP, TYPE_BADGE, ensureCompanionState, playerCompanion, companionStoryChapters,
  renderCompanionSystemPrompt, sanitizeCompanionSpeech, companionChatHistory,
  rememberCompanionTurn, recordCompanionTalk,
} from '../lib/companions.js'
import { RULE, replyOverImage, companionCardText } from '../lib/guardian-ui.js'

// Companions used to come from the beastkin rescue event. That event is gone
// and no new one can be earned, so this must not send anyone looking for it.
const NO_COMPANION = () =>
  `🕊️ *You have no companion.*\n` +
  `_The five companions were one-of-one and were claimed during the rescue event, which has ended. ` +
  `There is no way to earn another one._`

// Short, in-character fallbacks for when the model cannot be reached. Same
// style rules as everything else a companion says.
const OFFLINE = {
  lebore: 'sorry i lost count of what i was saying give me a moment',
  minna: 'not now someone is watching the road',
  rune_lica: 'rune is signing something and lica is laughing too hard to translate it',
  yenisei: 'she looks at you and nods very small',
  tenma: 'hold that thought darling my voice needs a moment',
}

async function runTalk(ctx, text) {
  const p = config.prefix
  const c = playerCompanion(ctx.player)
  if (!c) return ctx.reply(NO_COMPANION())
  const msg = String(text ?? '').trim().slice(0, 500)
  if (!msg) return ctx.reply(`💬 Say something: *${p}companion talk <message>*`)
  if (!hasAIKey()) return ctx.reply(`💬 *${c.name}:* ${OFFLINE[c.id] ?? '...'}`)

  const history = companionChatHistory(ctx.player)
  let answer = ''
  try {
    const res = await askAI({
      system: renderCompanionSystemPrompt(c, ctx.player, ctx.db),
      messages: [...history, { role: 'user', content: msg }],
      temperature: c.id === 'yenisei' ? 0.8 : 0.95,
      maxTokens: 300,
    })
    answer = sanitizeCompanionSpeech(res.text)
  } catch {
    answer = ''
  }
  if (!answer) return ctx.reply(`💬 *${c.name}:* ${OFFLINE[c.id] ?? 'give me a moment'}`)

  let bond = null
  await updatePlayer(ctx.db, ctx.from, (player) => {
    if (player.guardian?.companion !== c.id) return
    rememberCompanionTurn(player, msg, answer)
    bond = recordCompanionTalk(player)
  })

  const label = c.id === 'yenisei' ? 'trust' : 'bond'
  const unlockedNow = bond?.gained && c.storyUnlocks?.includes(bond.trust)
  return ctx.reply(
    `💬 *${c.name}:* ${answer}` +
    (unlockedNow ? `\n\n📖 _${c.name} trusts you enough to tell you a little more. *${p}companion story*_` : '') +
    (bond?.gained && [10, 25, 50].includes(bond.trust) && c.id === 'yenisei'
      ? `\n✨ _Her ${label} reached *${bond.trust}*. ${bond.trust === 10 ? 'She will tend your wounds after fights now.' : bond.trust === 25 ? 'She tells people what you did. Rescue fame +25%.' : 'She would step in front of a killing blow for you now.'}_`
      : ''),
  )
}

function storyText(ctx, n) {
  const p = config.prefix
  const c = playerCompanion(ctx.player)
  if (!c) return NO_COMPANION(p)
  const known = companionStoryChapters(c, ctx.player)
  if (known <= 0) return `📖 _${c.name} has not told you anything yet. Talk to ${c.pronoun === 'they' ? 'them' : 'her'}._`
  const idx = Number.isInteger(n) && n >= 1 ? Math.min(n, known) : null
  const chapters = idx ? [[idx, c.backstory[idx - 1]]] : c.backstory.slice(0, known).map((t, i) => [i + 1, t])
  const nextAt = c.storyUnlocks?.[known]
  return [
    `📖 *${c.name.toUpperCase()}*`,
    RULE,
    ...chapters.map(([i, t]) => `*${i}.* _${t}_`).flatMap(l => [l, '']),
    known < c.backstory.length
      ? `_There is more. ${c.name} is not ready yet${nextAt != null ? ` (trust ${nextAt})` : ''}._`
      : `_That is all of it. You are the only one ${c.pronoun === 'they' ? 'they have' : 'she has'} ever told._`,
  ].join('\n')
}

/**
 * The companion request needed the rescue event, which is gone. An offer left
 * on a record from before the removal is just stale state, so clear it and say
 * so plainly instead of pretending to resolve it.
 */
async function answerOffer(ctx) {
  let had = false
  await updatePlayer(ctx.db, ctx.from, (player) => {
    if (player.guardian?.offer) { player.guardian.offer = null; had = true }
  })
  return ctx.reply(had
    ? `🕊️ _That request is closed. The rescue event has ended, so no companion can be claimed any more._`
    : `🕊️ Nobody is waiting on an answer from you.`)
}

export default {
  name: 'companion',
  aliases: ['comp', 'mycompanion'],
  category: 'event',
  requiresPlayer: true,
  description: 'Your companion: her card, her story, and talking to her',

  async run(ctx) {
    const p = config.prefix
    const args = ctx.args ?? []
    const sub = String(args[0] ?? '').toLowerCase()
    ensureCompanionState(ctx.player)

    if (sub === 'accept' || sub === 'reject') return answerOffer(ctx)
    if (sub === 'story' || sub === 'past' || sub === 'backstory') return ctx.reply(storyText(ctx, Number(args[1])))
    if (sub === 'talk' || sub === 'say' || sub === 'chat') return runTalk(ctx, args.slice(1).join(' '))

    const c = playerCompanion(ctx.player)
    if (!sub || sub === 'info' || sub === 'card') {
      if (!c) return ctx.reply(NO_COMPANION())
      return replyOverImage(ctx, c.image, companionCardText(c, ctx.player))
    }
    return runTalk(ctx, args.join(' '))
  },
}

export { storyText, OFFLINE, COMPANION_MAP, TYPE_BADGE }
