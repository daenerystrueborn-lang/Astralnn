// <prefix>surtr-spin [amount] — Surtr's banner.
// 3 Gems a spin, 300 spins per player, nothing before spin 277. One-of-one
// bot-wide. The OTHER door is .character buy surtr for 10 Monds — a spin never
// charges Monds, and a buy never charges Gems.
//
// The banner itself (cost, cap, curve) lives in lib/spin-banners.js and the
// reading of it in lib/regressor-spin-runner.js; this file is the command and
// nothing else, the same shape every other Season 2 chase uses.
//
// Player-facing copy shows the spin count, the cost and the distance to the
// guarantee only — never the dead zone, never the chance. See the rule at the
// top of lib/spin-banners.js.
import { runRegressorSpin } from '../lib/regressor-spin-runner.js'

export default {
  name: 'surtr-spin',
  aliases: ['surtrspin', 'molten-spin', 'lavaspin'],
  category: 'character',
  requiresPlayer: true,
  description: 'Spin for Surtr — 3 Gems per spin, one-of-one, 300 spins, guaranteed by spin 300',
  async run(ctx) { return runRegressorSpin(ctx, 'surtr') },
}
