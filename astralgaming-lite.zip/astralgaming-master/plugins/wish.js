// <prefix>wish - Klein Moretti, Red Priest form. Once per fight, PvE.
import { config } from '../config.js'
import { activateWish } from '../lib/regressor-form-commands.js'
import { runRegressorCommand } from '../lib/regressor-command-runner.js'

export default {
  name: 'wish',
  aliases: ['redwish'],
  category: 'combat',
  description: `${config.prefix}wish - Red Priest form. Draw 3 cards, pick one. Heal, refresh cooldowns, or strip a special.`,
  requiresPlayer: true,
  async run(ctx) { return runRegressorCommand(ctx, activateWish) },
}
