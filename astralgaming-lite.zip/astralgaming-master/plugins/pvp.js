import { isSupportSkill, applySupportSelf, applySupportRider } from '../lib/support-skills.js'
import { queueHeartReaction, applyQueuedHeartReactions, acknowledgeHeartReactions } from '../lib/god-series/pvp-reaction.js'
import { creditSummonTithe } from '../lib/god-series/tithe.js'
import { applyGodTargetEffects, applyGodSummonRebounds } from '../lib/god-series/action-effects.js'
import { observeWorldIntervention } from '../lib/god-series/world-observer.js'
import { planGodSummonTurn } from '../lib/god-series/pve.js'
import { ownsGod, battleGodReady } from '../lib/god-series/catalog.js'
import { godMortalDown, godDeathRefusal, godLethalHit } from '../lib/god-series/battle.js'
import { pvpFundingAllowed, wagerFundingRefusal, pvpSeizure, PVP_FUNDING_CAP } from '../lib/pvp-funding.js'
import { rollUltraInstinctDodge } from '../lib/ultra-instinct.js'
import { canCallGarden, gardenStrikes, gardenStatus, grudgeStatus, GRUDGE_STORE_PCT, GRUDGE_THRESHOLD } from '../lib/garden.js'
import { isBattleCinematicActive } from '../lib/battle-presentation.js'
// Spectator system — broadcast duel updates to cross-group watchers
import { broadcastSpectatorUpdate, broadcastDuelEnd, formatSpectatorView } from '../lib/spectator-engine.js'
// Combo system — track ability chains for bonus effects
import { recordAbilityUse, resetFightCombos, formatComboTrigger, applyComboBonus } from '../lib/combo-engine.js'
/**
 * pvp.js — player-vs-player duels.
 *
 * Reuses the exact same damage/hit-chance/effects math PvE combat uses
 * (lib/combat-engine.js, lib/effects.js) — no forked formulas. It does NOT
 * reuse lib/combat-handlers.js's handleDeath/handleVictory (those are
 * PvE-specific: gear strip, dungeon floor advance, fame, drops) — PvP has
 * its own resolution (pvpConclude below): 5% of the loser's wallet.solars
 * ONLY (never gems/vault) moves to the winner, both players are fully
 * healed, and no gear is lost either way.
 *
 * TURN MODEL: unlike PvE (where the enemy's counter-attack resolves
 * automatically within the same command), PvP alternates between two real
 * players, so each `.pvp attack|skill|ability|defend` command resolves exactly one
 * player's turn, then flips a `myTurn` flag stored on both players'
 * battleState so the next command from the WRONG player is rejected
 * ("wrong-turn move"). The challenger acts first.
 *
 * STATE: a pending challenge lives on the target's own record as
 * `player.pvpChallenge = { fromJid, expiresAt }` (no shared collection
 * needed — mirrors rob.js's nested-updatePlayer, two-party-mutation
 * pattern rather than lib/guild-repo.js's shared-store pattern, since a
 * duel is inherently a 1:1 relationship with no server-wide lookup need).
 * Once accepted, both players get `player.battleState = { type: 'pvp', ... }`
 * and `player.inBattle = true`, reusing the same fields PvE combat uses so
 * profile.js's "in battle" indicator keeps working unmodified. attack.js/
 * skill.js/defend.js explicitly refuse to run against a `type: 'pvp'`
 * battleState and point the player at these commands instead.
 *
 * Usage:
 *   <prefix>pvp on|off       — bot mods: enable/disable PvP in this group
 *   <prefix>pvp @target       — challenge (reply or @mention)
 *   <prefix>pvp accept        — accept a pending challenge against you
 *   <prefix>pvp decline       — decline a pending challenge against you
 *   <prefix>pvp moves          — every move you can make this turn + a hint
 *   <prefix>pvp status         — the board, without spending a turn
 *   <prefix>pvp attack         — basic attack (your turn only)
 *   <prefix>pvp skill <name>   — skill attack (your turn only)
 *   <prefix>pvp ability <name> — use an equipped active ability (your turn only)
 *   <prefix>pvp wildcard      — Circe's Wild Card: draw one of six fates (3/battle)
 *   <prefix>pvp defend         — defensive stance, +MP, halves incoming dmg
 *   <prefix>pvp rematch        — re-challenge your last opponent
 *   <prefix>pvp claim          — take the win when an opponent has stalled out
 *   <prefix>pvp forfeit        — concede the current match
 *
 * HELPERS live in lib/pvp-engine.js — the Elo ladder, the move list, the
 * scouting math behind plugins/scout.js, and the stall timeout. None of them
 * feed back into damage: lib/combat-engine.js stays the single source of
 * truth for how hard a hit lands. Guild perks (lib/guild-engine.js) are the
 * same — spoilsPct changes the payout and duelSlots the frequency, never the
 * numbers traded in the loop.
 *
 * DAILY LIMIT: challenging costs one of the CHALLENGER's daily duel slots
 * (FREE_DAILY_PVP_LIMIT free / PREMIUM_DAILY_PVP_LIMIT premium — see
 * lib/premium.js's isPremiumActive()). Charged only at the *challenge*
 * step (not accept/attack/etc.), same "gate at the point of the action"
 * pattern daily.js uses, and only once the challenge is confirmed
 * possible (target valid, not already mid-battle/dungeon/challenged) so a
 * doomed challenge never burns a slot. The count resets on a new calendar
 * day via startOfDay(), mirroring daily.js's own streak-reset logic — no
 * separate cron/sweep needed. Being challenged (defending) never costs a
 * slot, only initiating one does.
 */
import { config } from '../config.js'
import { applyNighOmni } from '../lib/texas.js'
import { minatoTurnTick, minatoStatusLine, rollFlyingThunderGodDodge } from '../lib/minato.js'
import {
  applyFlameCombo, activateBlazeHeart, rengokuStatusLines, sendBlazeHeartImage, BLAZE_HEART_NAME,
} from '../lib/rengoku.js'
// 🌋 Surtr — her kit in a duel: the gates burned on the actor's own battleState,
// the multiplier and DEF pierce in the opponent-hit phase, and clearSurtrKit()
// at both ends of pvpConclude() (Twilight grows max HP, and a duel that ends
// while it runs has to give it back).
import {
  hasSurtr, surtrSkillByCommand, surtrStatusLine, buildSurtrMenu, ensureSurtrState,
  laevatainStoked, laevatainMultiplier, noteLaevatainHit,
  activateMoltenGiant, activateSurtrFlame, activateTwilight, endTwilight,
  twilightActive, resolveTwilightGuard, clearSurtrKit, surtrTurnTick,
  MOLTEN_GIANT_MULT, MOLTEN_GIANT_OUTGOING, TWILIGHT_OUTGOING,
  SURTR_FLAME_BURN_TURNS, SURTR_FLAME_BURN_FRACTION, TWILIGHT_HP_GATE,
} from '../lib/surtr.js'
import {
  armTrioCharacters,
  tickTrioTurnStart,
  trioBattleStatusLine,
  aimiyaFreeCastActive,
  tryCardiaButterflyRewind,
  flushTrioPendingCounters,
  activateCardiaWindup,
  activateAimiyaTrick,
  activateRemiHeartlock,
  isRemiCharacterSealed,
  remiCharacterSealRefusal,
} from '../lib/trio-characters.js'
import { applyEndMonsterTurn, endSummonEnabled } from '../lib/the-end.js'
import { applyStarterRelicsAfterDamage } from '../lib/starter-pack-engine.js'
import {
  chargeSwordTurn, completeTurn, useSword, swordReaction, reflectAttack,
  absoluteCutDamage, activateEndworld, endworldStatus, scarlettStatus, heroesTicker,
  SWORD_SKILLS, SWORD_CHARGE_MAX,
} from '../lib/witch-heroes.js'
import { showEndworldClash, showCoordinate } from '../lib/witch-heroes-cinematic.js'
import { tickShunShunRikka } from '../lib/orihime.js'
import { sendRankUp } from '../lib/rank-up.js'
import { sendBattleTurnReply } from '../lib/battle-frame-render.mjs'
// Duel arenas: `.pvp @target castle` picks the battlefield, `.pvp arenas` lists them.
import { PVP_ARENAS, extractArena } from '../lib/battle-sprites.mjs'
import { renderArenaMenu, renderArenaPreview } from '../lib/pvp-arenas-render.mjs'
import { replyWithPanel } from '../lib/rpg-ui-send.js'
import { sendTotemReviveAnimation } from '../lib/item-art-render.mjs'
import { flushPendingCriticalWrites, updatePlayer, updateAllPlayers, getPlayer, playerExists } from '../lib/player-repo.js'
import { skills as allSkills, levelsData, classes, races, getTotalStats, characterMap } from '../lib/game-data.js'
import {
  calcPlayerDamage,
  attackStatKey,
  applyDefense,
  calcPlayerHitChance,
  findSkill,
  hpBar,
  buildEffectDef,
  applyLevelUps,
  applyEquipmentBonus,
} from '../lib/combat-engine.js'
import { repairCharacterBonus } from '../lib/character-bonus-fix.js'
import { processStatusTurn, checkTotemRevive } from '../lib/combat-handlers.js'
import { armRegressor } from '../lib/regressor-passives.js'
import { activateWall } from '../lib/regressor-characters.js'
import { S2_IDS } from '../lib/regressor-state.js'
import { seasonBattleVoiceActive } from '../lib/season-battle-voice.js'
import { noteDoctrineAction, flushDoctrineLines } from '../lib/combat-doctrine.js'
import { hasEffect, addStatusEffect, getEffectiveStat, absorbDamage, absorbInstinctAttack, isNegativeEffect, applyReboundEffect } from '../lib/effects.js'
import { armCathedral, armEdoTensei, starfallTurnTick } from '../lib/starfall-champion.js'
import { findEquippedAbility, resolveActiveAbility } from '../lib/ability-engine.js'
import { armJustice, hasAudrey, isAudreyAbilityQuery, justiceReadout, takeJusticeCounter } from '../lib/audrey.js'
import { beastIntervention, awardBeastCp, applyBeastTargetEffects, clearBeastEffects, BEAST_EVENT } from '../lib/beast-engine.js'
import { dreamstepActive, dreamstepHitLine } from '../lib/dreamstep.js'
import { wearWeaponOnTurn, wearArmorOnHit, breakMessage } from '../lib/durability.js'
import { applyStruckReactions, applyPackLifestealOnDeal } from '../lib/premium-abilities.js'
// §11.8: a frozen body is not a duel target, and not a duelist.
import { isFrozen, isUnconscious } from '../lib/dreamlands-death.js'
import { getGroupSettings, saveGroupSettings, saveFailedMessage, isBotStaff } from '../lib/group-settings.js'
import { NOT_GROUP, NOT_ALLOWED, NOT_STAFF, extractTarget } from '../lib/group-helpers.js'
import { idForUsername } from '../lib/telegram-moderation.js'
import { toPlayerId } from '../lib/platform/identity.js'
import { isPremiumActive } from '../lib/premium.js'
// Saber's Excalibur. The gate and the number are the same ones the PvE turn in
// plugins/excalibur.js uses — a duel and a dungeon must not disagree about how
// hard the sword hits or when it is allowed out.
import {
  armExcalibur,
  hasSaberEquipped,
  hasExcaliburEquipped,
  EXCALIBUR_DAMAGE,
  EXCALIBUR_NAME,
  EXCALIBUR_OPENINGS,
} from '../lib/starfall-kits.js'
import { startOfDay } from '../lib/sleep-engine.js'
import { findActiveMatchFor, advanceMatch } from '../lib/tourney-repo.js'
import {
  findActiveWarMatchFor,
  beginWarDuel,
  pvpConcludeWar,
  settleWalkover,
} from '../lib/guild-war-repo.js'
import { WAR_KIT_TIERS, hasWarKit, removeWarKit as removeWarKitPublic } from '../lib/war-kit.js'
import { finishTourney } from './tourney.js'
import { getActiveSeason, applySeasonPoints } from '../lib/season-engine.js'
import { awardAstralPoints, POINT_VALUES } from '../lib/astral-pass-engine.js'
import { recordQuestEvent } from '../lib/quest-engine.js'
import {
  activateFinalForm,
  activateCinderVerdict,
  activateIAmAtomic,
  applyAtomicFlash,
  I_AM_ATOMIC_MULT,
  hasSecondTranscendance,
  CINDER_VERDICT_MULT,
  applyTearOnHit,
  sendFinalFormVideo,
  sendWillowAdvisory,
  tickPermanentSever,
  applyPermanentSeverOnWin,
  tickFrostbindAura,
  applyFrostlockGate,
  applyAbsoluteOneSiphon,
  rollSerpentsGrace,
  checkYoriichiCatForm,
  resolveCatFormAction,
  isCatFormActive,
  isOpponentLive,
  applyIncomingDamage,
  healCatFormPool,
  buildCatFormDefeatMessage,
  grantYoriichiExp,
  catFormAttackDamage,
  resolveCatFormDamage,
  applyAlyaStatBreak,
  megumiTurnStart,
  resolveMegumiIncoming,
  activateChimeraDomain,
  sendDomainImage,
  sendWheelSpin,
  danceOfTheRainMultiplier,
  buildDanceOfTheRainMessage,
  hasAnastasia,
  armHypnosis,
  canHypnosisRewind,
  resolveHypnosisRewind,
  restoreHypnosisSnapshot,
  hypnosisTollStep,
  buildHypnosisMessage,
  clearHypnosis,
  hasCirce,
  wildCardUsesLeft,
  drawWildCard,
  resolveWildCard,
  buildWildCardReveal,
  circeGuardStatus,
  WILD_CARD_MAX_USES,
  activateThiefsEye,
  resolveThiefsEyeDamage,
  recordEnemyMove,
  recordThiefsEyeDeny,
  applyThiefsEyeDenyGate,
  activateHollowExchange,
  buildHollowExchangeReveal,
  activateHollowPurple,
  activateUnlimitedVoid,
  UNLIMITED_VOID_STUN_TURNS,
  activateKurohitsugi,
  kurohitsugiMultiplier,
  aizenSenses,
  AIZEN_MAX_SENSES,
  activateHogyoku,
  activatePuppetStrings,
  resolvePuppetSelfHit,
  buildPuppetStringsReveal,
  PUPPET_TANGLE_TURNS,
  activateTimeStop,
  hasMontana,
  resolveMontanaCounter,
  TIME_STOP_TURNS,
  activateKurama,
  resolveKuramaDrain,
  sendKuramaSummonImage,
  armLovestruck,
  applyAweGate,
  hasGogeta,
  armFusion,
  fusionTurnsLeft,
  rollInstantTransmissionOpener,
  activateSoulPunisher,
  activateBigBangKamehameha,
  gogetaCooldowns,
  sendKamehamehaImage,
  hasWitchOfEnvy,
  advanceWondersOfEnvy,
  bypassesWondersOfEnvy,
  armWondersOfEnvy,
  applyWondersCurseOnWin,
  activateGreedTithe,
  echidnaPvpTithe,
  buildGreedTitheReveal,
  GREED_TANGLE_TURNS,
  isLeagueAdventurer,
  isMasterAdventurer,
  isNonExclusiveCharacter,
  syncEmptyVesselFlag,
  syncLucidImmunityFlag,
  applyYelanGate,
  tickBethMend,
  tickClaneDrain,
  armSnapshot,
  clearSnapshot,
  canSnapshotRewind,
  resolveSnapshotRewind,
  restoreOpponentSnapshot,
  tickLioreiTurnStart,
  captureMiniSnapshot,
  checkAndApplyMiniSnapshotReverse,
} from '../lib/character-abilities.js'
import {
  hasFairyQueen,
  fairySpellById,
  fairySpellGate,
  consumeFairySpell,
  applyFairySpellSelf,
  applyFairySpellEnemy,
  buildFairySpellReveal,
  applyFairySealGate,
  noteDuelMoveUse,
  fairyEncore,
  tickFairyEncore,
  setFairyEncore,
  fairySealStatus,
  fairyEncoreUsed,
  markFairyEncoreUsed,
  FAIRY_SPELLS,
} from '../lib/fairy-queen.js'
import {
  kurohitsugiCastLine, kurohitsugiImpactLine,
} from '../lib/aizen-flavor.js'
// Yu Miaoyi — Lucid Embrace. The duel side of her kit: she arms at accept
// beside Hypnosis, refuses her owner's commands, answers her own turns from
// the seeded fight AI, lands sure hits nobody can dodge or intercept, cannot
// be touched for her opening turns, and wakes her owner when the duel settles.
import {
  isLucidBattle,
  armLucidEmbrace,
  lucidSureHits,
  lucidUntouchable,
  lucidUntouchedLine,
  lucidFloorDamage,
  lucidRefusalLine,
  lucidActionLine,
  lucidWakeLine,
  lucidEmbraceScene,
  pickLucidAction,
  markLucidPowerUsed,
  characterExtraImage,
  YU_CHARACTER_ID,
} from '../lib/yu-miaoyi.js'
import { roundGems } from '../lib/format.js'
import {
  activateDragonUltimate,
  resolveDragonUltimateDamage,
  buildDragonUltimateSequence,
  buildDragonRestFooter,
  markDragonAsleep,
} from '../lib/dragon-engine.js'
import { sendImageTo } from '../lib/image.js'
import {
  applyDeadlyPoison,
  finalizeSlainCharacters,
  isCharacterSlain,
  isYelanEngaged,
  runYelanDuelRound,
  slayCharacter,
} from '../lib/yelan-engine.js'
import { mixSeed, characterHpBar, barLine, yelanFormCombat } from '../lib/character-combat.js'
import { armMirror, cloneTakeHit, mirrorOpenLine, mirrorTurnLines, hasAvessa } from '../lib/avessa-engine.js'
import {
  ensurePvp, ratingOf, ratingDelta, recordWin, recordLoss, rankFor, streakLabel,
  moveOptions, suggestMove, statusBoard, effectLine,
  isStale, idleMs, formatDuration, TURN_TIMEOUT_MS,
} from '../lib/pvp-engine.js'
import { getGuildRecord, getGuildDef } from '../lib/guild-repo.js'
import {
  findOpenClashMatch, hasOpenClash, recordClashResult, clashResultText,
  clashLiveLine, clashChallengeLine, clashKey,
} from '../lib/guild-clash.js'
import { guildPerksFor } from '../lib/guild-engine.js'
import { getAbilityDef } from '../lib/ability-engine.js'
import { skillAwakeningGate, formatSkillAffinityBattleLine, hasAffinity, normalizeAffinityId, getElementDef } from '../lib/affinity-engine.js'
import { PVP_BEND_MP_COST, computeBendProfile } from './bend.js'
import { resolveBendingPhaseChain } from '../lib/bending-chains.js'

const BEND_ALIASES = new Set(['bend', 'bendingart', 'elementart'])

function resolvePvpSkill(skillQuery, actor) {
  if (typeof skillQuery === 'string' && skillQuery.startsWith('__pvpBend:')) {
    if (!hasAffinity(actor)) return null
    const reqEl = skillQuery.slice('__pvpBend:'.length) || null
    const prof = computeBendProfile(actor, reqEl)
    const subBonus = prof.sub ? (prof.sub.stage === 3 ? 0.14 : 0.08) : 0
    const mult = Number((1.82 + 0.65 * (prof.curve ?? 0) + subBonus + (prof.isAvatarState ? 0.30 : 0)).toFixed(2))
    const subId = prof.sub?.id ?? null
    const rider = subId === 'ice'
      ? { type: 'frostlock', turns: 1 }
      : subId === 'lightning' || subId === 'voidwind'
        ? { type: 'stun', turns: 1 }
        : subId === 'blood' || subId === 'metal'
          ? { type: 'bleed', dmgPct: 0.04, turns: 2 }
          : subId === 'lava' || subId === 'blue_flame' || prof.element === 'fire'
            ? { type: 'burn', dmgPct: subId === 'blue_flame' ? 0.05 : 0.04, turns: 2 }
            : prof.element === 'water'
              ? { type: 'slow', turns: 2 }
              : prof.element === 'earth'
                ? { type: 'stun', turns: 1 }
                : { type: 'blind', turns: 1 }
    return {
      id: `pvp_bend_${prof.element}`,
      name: prof.artName,
      description: prof.flavor,
      type: 'active',
      mpCost: PVP_BEND_MP_COST,
      element: prof.moveElement ?? (prof.element === 'air' ? 'wind' : prof.element),
      affinity: prof.element,
      effects: [{ type: 'attack', stat: 'str', multiplier: mult }, rider],
      _isPvpBend: true,
      _crestKey: prof.crestKey,
      _emoji: prof.emoji,
    }
  }
  return findSkill(skillQuery, actor.skills ?? [], allSkills)
}
import { detectGambits, formatGambits } from '../lib/pvp-gambits.js'
// ── Wager duels (the no-turns, stake-on-the-line mode) ────────────────────
// The engine lives in lib/pvp-wager.js; this file only routes commands into it
// and owns persistence, because updatePlayer() must stay top-level (see
// runPvpTurn's header for why nesting it deadlocks).
import {
  isWagerState, makeWagerState, wagerIdleMs, WAGER_IDLE_TIMEOUT_MS,
  WAGER_MIN_STAKE, parseStake, checkPacing, notePacing, pacingMessage,
  hasUsableSkill, PACING_FORCED_NOTE,
  ppLeft, maxPpFor,
  resolveWagerAction, drinkFromKit, refillPpFromKit, mendFromKit,
  swapTotemFromKit, swapArmorFromKit, swapWeaponFromKit,
  escrowStake, refundStake, payWagerPot, clearWagerState,
  wagerBoard, kitPanel,
} from '../lib/pvp-wager.js'
import {
  PVP_KIT_SLOTS, ensureKit, kitSpace, moveToKit, takeFromKit,
} from '../lib/pvp-kit.js'
import { sendKitReply } from '../lib/pvp-kit-render.mjs'
import { getInventoryCap } from '../lib/inventory-limits.js'
// The Astral League fixture hook. Lives in its own module so the diff to this
// 5,000 line file stays a handful of lines and the ending stays testable on its
// own. findLeagueDuel() returns null for any duel that is not a scheduled
// fixture, so every older path below runs untouched.
import { findLeagueDuel, concludeLeagueDuel, concludeQualifierBout } from '../lib/league/league-conclude.js'
import { findQualifierBout } from '../lib/league/league-qualify.js'
import { concludeTrialFight } from './league-qualify.js'
// Lives in the lib, not in plugins/league-battle.js: importing it from there
// would close a cycle with the runPvpTurn import above.
import { inLeagueFixture } from '../lib/league/league-match.js'
import { applyAdventurerLifesteal } from '../lib/league/league-lifesteal.js'
// ── 👑 The Season 1 crowns — Queen Esta's Mother of Constellations and King
// Yato's Grace of the Crown (lib/queen-esta.js, lib/king-yato.js, and the
// shared ownership/matchup layer in lib/queen-king.js). The duel is the only
// place the two can meet, so BOTH halves of their mutual ban are computed here:
// the grace lock is enforced on the victim's own turn, and the sky is fired
// from pvpQueenConst() below.
import { constGate, planConstellation, queenLockActive, queenLockStamp } from '../lib/queen-esta.js'
import { playCrownScene, showCrownScene } from '../lib/queen-esta-scene.js'
import { graceActive, graceAttackLocked, graceCommandBlock, gracePhase, GRACE_DUEL_ALLOWED_ACTIONS } from '../lib/king-yato.js'
// 🏛️ Victoria Minayoko — Sanctum Victoriae (lib/victoria.js has the whole ability).
import {
  sanctumShields, raiseSanctum, sanctumNullifiedLine, sanctumBreakLine, sanctumStatusLine, sanctumState,
  SANCTUM_DUEL_ALLOWED_ACTIONS, SANCTUM_TURNS, SANCTUM_READY_AT_TURN,
} from '../lib/victoria.js'
import { armCrownPresence } from '../lib/queen-king.js'
import { levelTag } from '../lib/level-display.js'

const CHALLENGE_TIMEOUT_MS = 2 * 60 * 1000 // 2 minutes to accept/decline
const VICTORY_SOLARS_PCT = 0.05 // 5% of the LOSER's wallet.solars — never gems/vault

// Daily duel cap — charged to the CHALLENGER only, at challenge time.
const FREE_DAILY_PVP_LIMIT = 5
const PREMIUM_DAILY_PVP_LIMIT = 10

// ── PvP fight-length cap ─────────────────────────────────────────────────
// A single basic attack or skill can never carve away more than this fraction
// of the TARGET's max HP in one hit. This is what ends the one-tap era: at
// level 100 a focused build's primary stat (~1,300-1,800 — it rides the
// 1,500-point allocation pool + 2/level + gear) has caught up to the HP pool
// (~1,300, which only grows +10/level and CANNOT be allocated into), so an
// uncapped hit ≈ a kill and a 2-3x skill one-shots straight through defense.
//
// Capping per hit as a FRACTION OF MAX HP — rather than a flat damage scalar —
// is deliberately level-agnostic: it lengthens a duel identically at level 20
// and level 100, where a single tuned multiplier could only ever fix one end.
// Every hit BELOW the cap stays fully stat-scaled, so gear and tactics still
// decide the match: higher level is a FAVOURITE (bigger HP pool, reaches the
// cap reliably) but never a guaranteed win — a geared, well-played underdog
// who also reaches the cap trades evenly, and out-defending / out-timing /
// crit luck settles it. Elo is a favourite, not a verdict; anything can happen.
//
// Skills cap higher than basics so spending MP on a skill is a real tactical
// lever, not a same-damage reskin of a basic swing. Signature ultimates
// (Cinder Verdict, Wild Card, the dragon ultimate) and Yoriichi's cat form are
// EXEMPT — they are the rare, uncapped burst the baseline exchange is built
// around. PvP only; PvE stays balanced by the monster engine.
const PVP_BASIC_HIT_MAX_HP_FRAC = 0.15  // basic attack ceiling: 15% of target max HP
const PVP_SKILL_HIT_MAX_HP_FRAC = 0.25  // skill ceiling: 25% of target max HP
// A League fixture bounds every character signature move to this share of the
// target's max HP (the cap itself is applied in the hit phase of runPvpTurn).
// Named here because Minato's doubled strike reads it too: in a fixture his
// lifted hit ceiling stops at this line.
const PVP_LEAGUE_SIGNATURE_MAX_HP_FRAC = 0.25

/* ───────────────────────── wager-mode aliases ─────────────────────────── */
/*
 * Short forms are the point, not a convenience. Wager duels run on a 2-second
 * cooldown with no turn order, so the winner is partly whoever types faster:
 * `.pvp atk` has to be typeable in one breath. The long forms stay accepted so
 * nobody has to relearn the commands they already know.
 */
const WAGER_ALIASES   = new Set(['wager', 'w', 'stake', 'bet'])
const STOCK_ALIASES   = new Set(['stock', 'st', 'pack'])
const UNSTOCK_ALIASES = new Set(['unstock', 'us', 'unpack'])
const KIT_ALIASES     = new Set(['inv', 'inventory', 'kit'])
const W_ATTACK        = new Set(['atk', 'a'])
const W_SKILL         = new Set(['sk', 's'])
const W_DEFEND        = new Set(['def', 'd'])
const W_DRINK         = new Set(['dr', 'drink'])
const W_TOTEM         = new Set(['tot', 'totem'])
const W_ARMOR         = new Set(['arm', 'armor', 'armour'])
const W_WEAPON        = new Set(['wpn', 'weapon'])
const W_MEND          = new Set(['mnd', 'mend', 'repair'])
const W_REFILL        = new Set(['rf', 'refill', 'vial'])

/**
 * One side's HP line for the per-turn BATTLE STATUS footer, cat-form-aware.
 * When a side has Yoriichi's cat form active, their OWN hp is deliberately
 * pinned at 1 (see checkYoriichiCatForm) while Yoriichi fights from a SEPARATE
 * pool — so `hpBar(entity.hp, entity.maxHp)` would misleadingly render "1/maxHp"
 * (the source of the "why is it showing 1/1055?" report). Show Yoriichi's own
 * pool instead, mirroring lib/pvp-engine.js's sideLine() which already does this
 * for the `.pvp status` board.
 */
function pvpStatusLine(entity, heart) {
  const cat = isCatFormActive(entity) ? entity.battleState.yoriichiCatFormActive : null
  if (cat) {
    return (
      `${heart} *${entity.name}*: 🐈‍⬛ ${hpBar(cat.hp, cat.maxHp)}  ${cat.hp}/${cat.maxHp} _cat-form HP_  💧 ${entity.mp}/${entity.maxMp} MP\n` +
      `   _Yoriichi fights in ${entity.name}'s place._`
    )
  }
  return `${heart} *${entity.name}*: ${hpBar(entity.hp, entity.maxHp)}  💧 ${entity.mp}/${entity.maxMp} MP`
}

/**
 * One side's companion line (and, for Yelan's holder, her own engagement bar).
 *
 * A companion is not always at full health in a duel — Yelan can be halfway
 * through killing one — and while that is true the two bars exist entirely on
 * battleState, so a footer that only shows player HP leaves the most important
 * number in the fight invisible. A slain companion is reported as slain rather
 * than as a bar, because a bar would imply it can still be used.
 *
 * Returns '' when neither player brought a companion, so an ordinary duel's
 * footer is unchanged.
 */
function pvpCompanionBlock(actorEntity, oppEntity) {
  const rows = []
  for (const [entity, heart] of [[actorEntity, '❤️'], [oppEntity, '💙']]) {
    // Yelan's engagement lives on HER owner's battleState only, so read the
    // other duelist's record for both directions.
    const duel = entity?.battleState?.yelanDuel
    if (duel?.engaged && !duel.repelled) {
      rows.push(
        `${heart} 🖤 *Yelan*  ${barLine(duel.hpA, characterHpBar(yelanFormCombat(duel.form)))}` +
        `  _vs ${duel.characterName}${duel.form === 'base' ? '' : ` · ${duel.form === 'final1' ? 'final form' : 'FINAL FORM II'}`}_`,
      )
    }
    const id = entity?.equippedCharacter
    const def = id ? characterMap[id] : null
    if (!def?.combat) continue
    const label = `${def.emoji ?? '🎭'} *${def.name}*`
    if (isCharacterSlain(entity, id)) {
      rows.push(`${heart} ${label}  💀 _slain — a Revival Stone is the only way back_`)
      continue
    }
    const heldBy = [actorEntity, oppEntity]
      .map(e => e?.battleState?.yelanDuel)
      .find(d => d?.engaged && !d.repelled && d.characterId === id)
    if (heldBy) {
      rows.push(`${heart} ${label}  ${barLine(heldBy.hpB, characterHpBar(def.combat))}  _locked with Yelan_`)
      continue
    }
    rows.push(`${heart} ${label}  ${characterHpBar(def.combat)} HP  _standing_`)
  }
  return rows.length ? `🎭 *COMPANIONS* 🎭\n${rows.join('\n')}\n` : ''
}

/**
 * The full BATTLE STATUS + "turn passes to" footer, shared by the normal turn
 * path and Yoriichi's auto-answer path so both show identical, cat-form-aware
 * HP bars for the two combatants.
 *
 * Who's next is read off `battleState.myTurn` rather than assumed to be the
 * non-actor. Two reasons, and the second one is the important one:
 *
 *  - Yoriichi answers her own turns the instant the baton reaches her owner
 *    (autoResolveCatFormTurns), so the baton can come straight back to the
 *    person who just moved and "the other one" would be wrong.
 *  - It makes it STRUCTURALLY IMPOSSIBLE to print "TURN PASSES TO <owner>" for
 *    a player Yoriichi is fighting for. That line used to be the loudest way the
 *    bot handed the turn back to someone lying unconscious on the floor, and it
 *    is not something a future edit should be able to reintroduce by accident.
 */
function pvpStatusFooter(actorEntity, oppEntity) {
  const board =
    `\n🩸 *BATTLE STATUS* 🩸\n` +
    pvpStatusLine(actorEntity, '❤️') + '\n' +
    pvpStatusLine(oppEntity, '💙') + '\n' +
    pvpCompanionBlock(actorEntity, oppEntity) +
    // The Heroes clock, on every turn message, for both sides. A charge counter,
    // an armed riposte, a drawn invisible sword and Ronova's countdown are all
    // otherwise invisible until they fire, and "I armed something and never heard
    // about it again" is indistinguishable from a broken command.
    // Alpha and Delta each have a live in-duel board of their own, not just
    // a move-list entry. The holder and the rival both see when she is ready
    // or how much of the next Grudge has been stored.
    (() => {
      const lines = [actorEntity, oppEntity]
        .flatMap(who => [gardenStatus(who), grudgeStatus(who)])
        .filter(Boolean)
      return lines.length ? `\n🌑 *SHADOW GARDEN* 🌑\n${lines.join('\n')}\n` : ''
    })() +
    (witchTicker(actorEntity) || witchTicker(oppEntity)
      ? `\n🌹 *THE HEROES* 🌹\n${witchTicker(actorEntity)}${witchTicker(oppEntity)}`
      : '') +
    // Victoria's Sanctum, for both sides: the rival has to be able to see that
    // it is up and for how long, or ten nullified turns read as a broken duel.
    (() => {
      const lines = [actorEntity, oppEntity].map(who => sanctumStatusLine(who)).filter(Boolean)
      return lines.length ? `\n${lines.join('\n')}\n` : ''
    })() +
    (() => {
      const lines = [actorEntity, oppEntity]
        .map(who => trioBattleStatusLine(who, who?.battleState, { prefix: config.prefix }))
        .filter(Boolean)
      return lines.length ? `\n${lines.join('\n')}\n` : ''
    })() + '\n\n'
  const next = oppEntity?.battleState?.myTurn
    ? oppEntity
    : actorEntity?.battleState?.myTurn
      ? actorEntity
      : oppEntity
  if (isCatFormActive(next)) {
    return board + `🐈‍⬛ *YORIICHI FIGHTS ON — ${next.name.toUpperCase()} HAS NO TURN.* 🐈‍⬛`
  }
  return board + `⏭️ *TURN PASSES TO ${next.name.toUpperCase()}!* ⏭️`
}

/**
 * The player's guild perks, or the all-zero Outpost baseline if they're
 * guildless. Read fresh at the point of the action rather than cached on the
 * player, so leaving a guild stops applying immediately and a guild that
 * levels up mid-duel takes effect on the very next one — the contract
 * lib/guild-engine.js's header sets out.
 */
function perksFor(db, player) {
  const record = player?.guildId ? getGuildRecord(db, player.guildId) : null
  return guildPerksFor(player, record)
}

/** The player's daily duel cap, including any guild-tier bonus slots. */
function pvpChallengeLimit(player, bonusSlots = 0) {
  const base = isPremiumActive(player) ? PREMIUM_DAILY_PVP_LIMIT : FREE_DAILY_PVP_LIMIT
  return base + Math.max(0, bonusSlots)
}

/** Duel slots the player has left today (resets automatically at midnight). */
function pvpChallengesRemaining(player, bonusSlots = 0) {
  const limit = pvpChallengeLimit(player, bonusSlots)
  const today = startOfDay(Date.now())
  const usedToday = player.pvpChallengeDate === today ? (player.pvpChallengesUsed ?? 0) : 0
  return Math.max(0, limit - usedToday)
}

/** Records that the player just spent one of today's duel slots. Call only
 *  once a challenge is confirmed going out (after all validity checks). */
function consumePvpChallenge(player) {
  const today = startOfDay(Date.now())
  if (player.pvpChallengeDate !== today) {
    player.pvpChallengeDate = today
    player.pvpChallengesUsed = 0
  }
  player.pvpChallengesUsed = (player.pvpChallengesUsed ?? 0) + 1
}

// Flat XP-equivalent figure fed into awardBeastCp() for a PvP win — there's
// no monster xp reward to derive from here, so this stands in for it,
// pegged near a "strong" PvE kill (see lib/xp-regulator.js's TIER_PCT) so
// beast growth from duels tracks roughly the same pace as dungeon grinding.
const PVP_WIN_XP_EQUIVALENT = 60

const EFFECT_APPLIED_LINE = {
  stun: (n) => `⚡🌀 *${n} IS STUNNED — LOCKED DOWN!*\n`,
  freeze: (n) => `❄️🧊 *${n} IS FROZEN SOLID!*\n`,
  blind: (n) => `🌑👁️ *${n} IS BLINDED — CAN'T SEE THE NEXT HIT!*\n`,
  burn: (n) => `🔥🔥 *${n} IS BURNING ALIVE!*\n`,
  poison: (n) => `☠️🟢 *${n} IS POISONED — TICKING DOWN!*\n`,
  bleed: (n) => `🩸💢 *${n} IS BLEEDING OUT!*\n`,
  weaken: (n) => `💔⬇️ *${n} IS WEAKENED — POWER DRAINED!*\n`,
  slow: (n) => `🐢⏱️ *${n} IS SLOWED TO A CRAWL!*\n`,
}

/**
 * Who is being challenged.
 *
 * THREE PLATFORMS, ONE ANSWER, AND THE CROSS-PLATFORM PART WAS ALREADY WRITTEN.
 * This used to read the WhatsApp message shape directly, so on Telegram every
 * mention produced null and the player got "Usage: .pvp @target" as though they
 * had not named anybody. `extractTarget()` in lib/group-helpers.js has handled
 * the WhatsApp JID, the Discord snowflake and the Telegram entity for a while;
 * pvp.js simply never called it.
 *
 * The order matters and is deliberate:
 *   1. the platform's own mention/reply, which carries a real id
 *   2. a bare @username, looked up in the registry of users the bot has seen
 *   3. a typed phone number, which is the WhatsApp habit
 *
 * A typed number is only treated as an id on WhatsApp. On Telegram a player id
 * is an integer that looks exactly like a phone number, so guessing would
 * address a stranger's account; those players get the username path instead.
 */
function resolveTargetJid(ctx, raw) {
  const native = extractTarget(ctx)
  if (native) return native

  // A plain "@username" is text, not an entity: Telegram only attaches an id to
  // a text_mention. It is still by far the commonest way people tag someone, so
  // resolve it the only way available — look the handle up.
  if (ctx?.platform === 'telegram' && typeof raw === 'string' && raw.startsWith('@') && raw.length > 1) {
    return resolveTelegramHandle(raw)
  }

  if (!raw) return null
  // WhatsApp is the only platform where a typed number addresses a player.
  // Telegram ids are integers that look exactly like phone numbers, so guessing
  // there would address a stranger's account; those players have the handle path.
  if (ctx?.platform && ctx.platform !== 'whatsapp') return null
  const digits = String(raw).replace(/[^0-9]/g, '')
  if (!digits) return null
  return `${digits}@s.whatsapp.net`
}

/**
 * Turn a typed "@name" into a player.
 *
 * Telegram attaches no id to a plain mention — the entity is three characters of
 * text and nothing else — so a handle can only be honoured if the bot has seen
 * that user before. lib/telegram-moderation.js already keeps exactly that map
 * (every message sender is remembered), so this reuses it instead of growing a
 * second registry that would disagree with the first.
 *
 * Returns null when the handle has never been seen. The challenge path then says
 * so plainly and names the two ways that always work, rather than pretending the
 * player did not type anything.
 */
function resolveTelegramHandle(handle) {
  const id = idForUsername(String(handle ?? '').replace(/^@/, ''))
  return id ? toPlayerId('telegram', id) : null
}

/** Small delay for the dragon ultimate's multi-message cinematic. */
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

function inPvp(player) {
  return !!(player.inBattle && player.battleState?.type === 'pvp')
}

/**
 * warDuelKitLine(warDuel) — the one-line banner prefix for a pairing that
 * just went live: which kit tier loaded and the isolation promise. Shared by
 * the normal and wager accept paths so a war duel always announces the same
 * way however it was opened.
 */
function warDuelKitLine(warDuel) {
  const tier = warDuel?.war?.kitTier
  const kit = WAR_KIT_TIERS?.[tier]
  const size = warDuel?.war?.matchType
  const label = kit ? `${kit.emoji} *${kit.name}* (Preset 5 · Tier ${kit.tier})` : `Preset 5`
  return `🎒 ${label} loaded on both champions — war *${size ?? 'duel'}*, pairing ${((warDuel?.match?.i ?? 0) + 1)}.`
}

/** Ends a duel with no winner (both just walk away) — used by the /timeout path. */
async function clearBattle(db, jid) {
  // Belt-and-braces: if this player was mid-PAIRING when their duel died
  // without a conclusion, Preset 5 must never be left on them. removeWarKit
  // is idempotent, so calling it for an ordinary duel is free.
  await updatePlayer(db, jid, (p) => {
    if (hasWarKit(p)) removeWarKitPublic(p)
    // 🌋 Surtr — a duel that dies without a conclusion still has to take the
    // colossus off. Neither pvpConclude nor the forfeit path runs here, so this
    // is the only place her max HP and ATK get put back.
    clearSurtrKit(p, p.battleState)
    p.inBattle = false
    p.battleState = null
    clearBeastEffects(p)
    // End-of-battle housekeeping for Yelan's kills: a character who died in this
    // duel is unequipped here, and any deadly poison dies with the fight.
    finalizeSlainCharacters(p)
    // A duel that dies WITHOUT a conclusion (the opponent's record vanished, a
    // crash, an owner unstick) used to leave the fight's ailments on the player
    // forever: Urahara's `tear` is written with a 999-turn duration, so it
    // survived the fight that caused it and every `.curetear` afterwards said
    // "you don't have a Tear" because only the *permanent* flag was consulted.
    // The fight is over, so its debuffs go with it — the same rule pvpConclude
    // applies to both duelists. Buffs (potions, warcries) are left alone here;
    // only the hostile entries are stripped.
    if (Array.isArray(p.activeEffects)) {
      p.activeEffects = p.activeEffects.filter((e) => !isNegativeEffect(e.type))
    }
  })
}

/**
 * tryHypnosisRewindPvp — the duel half of Anastasia's Hypnosis. Returns a
 * truthy value if the duel was rewound instead of concluded (in which case
 * pvpConclude must return immediately and touch nothing: no solars change
 * hands, no rating moves, no win/loss is recorded — the duel is still live),
 * or null to let the normal conclusion run.
 *
 * Both sides are unwound. The loser goes back through resolveHypnosisRewind
 * (which spends one of their two rewinds), the winner through
 * restoreHypnosisSnapshot (which spends nothing — they don't own her) and
 * then pays the 15% toll off the HP they opened the duel on. Uses the same
 * read-fresh / sequential-updatePlayer pattern as the rest of this file
 * rather than nesting, since nested updatePlayer calls deadlock on
 * player-repo's single write queue.
 */
async function tryHypnosisRewindPvp(db, winnerJid, loserJid, ctx, reasonLine) {
  if (!canHypnosisRewind(getPlayer(db, loserJid))) return null

  let rewind = null
  await updatePlayer(db, loserJid, (loser) => {
    rewind = resolveHypnosisRewind(loser)
  })
  if (!rewind?.rewound) return null

  // toll is null out of resolveHypnosisRewind here — a PvP opponent is their
  // own player record, not a battleState.enemy object — so it's applied to
  // the winner directly. hypnosisTollStep() off their RESTORED opening HP is
  // the same call the dungeon path makes, so a duel rewind and a dungeon
  // rewind chip identical amounts.
  let toll = null
  await updatePlayer(db, winnerJid, (winner) => {
    restoreHypnosisSnapshot(winner)
    const step = hypnosisTollStep(winner.hp, rewind.rewindNumber)
    winner.hp = step.after
    toll = { name: winner.name, ...step, maxHp: winner.maxHp }
  })

  const loserAfter = getPlayer(db, loserJid)
  const winnerAfter = getPlayer(db, winnerJid)
  // Whoever held the opening move holds it again — myTurn came back with the
  // rest of each side's restored battleState.
  const firstMover = loserAfter.battleState?.myTurn ? loserAfter : winnerAfter

  await ctx.reply(
    reasonLine +
    buildHypnosisMessage(loserAfter, { ...rewind, toll }) +
    `\n\n🩸 *BATTLE STATUS* 🩸\n` +
    pvpStatusLine(loserAfter, '❤️') + '\n' +
    pvpStatusLine(winnerAfter, '💙') + '\n\n' +
    `⏭️ *THE DUEL RESUMES — ${firstMover.name.toUpperCase()} MOVES FIRST!* ⏭️`,
  )
  return loserAfter
}

async function trySnapshotRewindPvp(db, winnerJid, loserJid, ctx, reasonLine) {
  if (!canSnapshotRewind(getPlayer(db, loserJid))) return null

  let rewind = null
  let snapAbility = null
  await updatePlayer(db, loserJid, (loser) => {
    rewind = resolveSnapshotRewind(loser, { lethal: true })
    snapAbility = loser.snapshotAbility
  })
  if (!rewind?.rewound) return null

  await updatePlayer(db, winnerJid, (winner) => {
    restoreOpponentSnapshot(winner, snapAbility)
  })

  const loserAfter = getPlayer(db, loserJid)
  const winnerAfter = getPlayer(db, winnerJid)
  const firstMover = loserAfter.battleState?.myTurn ? loserAfter : winnerAfter

  const fullMsg =
    reasonLine +
    rewind.message +
    `\n\n🩸 *BATTLE STATUS* 🩸\n` +
    pvpStatusLine(loserAfter, '❤️') + '\n' +
    pvpStatusLine(winnerAfter, '💙') + '\n\n' +
    `⏭️ *THE DUEL RESUMES — ${firstMover.name.toUpperCase()} MOVES FIRST!* ⏭️`

  if (ctx?.sock && ctx?.jid && rewind.image) {
    const sent = await sendImageTo(ctx.sock, ctx.jid, rewind.image, fullMsg).catch(() => false)
    if (!sent) await ctx.reply(fullMsg)
  } else {
    await ctx.reply(fullMsg)
  }
  return loserAfter
}

/**
 * pvpConclude — the ONLY PvP win/loss handler. Deliberately does not touch
 * handleDeath/handleVictory. Transfers 5% of the loser's wallet.solars
 * (never gems/vault — see plugins/vault.js's exclusion guarantee), fully
 * heals both players, clears both battleStates, no gear loss either side.
 *
 * allowRewind: whether Anastasia's Hypnosis may unwind this ending instead
 * of letting it stand. Defaults to true so a new death path added later
 * gets her for free — the failure mode that actually happened with
 * Yoriichi was an ability wired into one call site and silently missing
 * from the rest. Pass false for endings that are NOT a combat death:
 * forfeits and turn-timeout claims. Rewinding those would let a player
 * chip 15% off an opponent by quitting, and would drag someone who won on
 * time back into a duel their opponent had already abandoned.
 */
export async function pvpConclude(db, winnerJid, loserJid, ctx, reasonLine, { allowRewind = true } = {}) {
  await flushPendingCriticalWrites(db)
  // Backstop for scripted endpoints that bypass a normal damage predicate.
  // A surrender/timeout at positive HP remains a nonlethal match result.
  const godLoser = loserJid ? getPlayer(db, loserJid) : null
  if (godLoser && godLoser.hp <= 0 && godDeathRefusal(structuredClone(godLoser))) {
    let line = ''
    await updatePlayer(db, loserJid, player => { line = godDeathRefusal(player); return player })
    if (line) await ctx.reply(line)
    return
  }

  // ── Spectator broadcast — notify all watchers the duel is ending ────
  // This runs before any conclusion path so spectators see the result
  // regardless of whether it's a wager, league, tournament, or normal duel.
  try {
    const winnerPlayer = winnerJid ? await getPlayer(db, winnerJid) : null
    const loserPlayer = loserJid ? await getPlayer(db, loserJid) : null
    const resultText = [
      `👁️ *DUEL CONCLUDED*`,
      ``,
      `🏆 *${winnerPlayer?.name ?? 'Winner'}* defeats *${loserPlayer?.name ?? 'Loser'}*!`,
      ``,
      reasonLine ? `_${reasonLine}_` : '',
      ``,
      `_The duel has ended. Thanks for watching!_`,
    ].filter(Boolean).join('\n')
    await broadcastDuelEnd(winnerJid ?? loserJid, resultText)
  } catch {
    // Spectator failure must never prevent the duel from concluding
  }

  // ── Guild War pairing — settles FIRST, before everything else ─────────
  // A live war pairing IS this duel. It has to run ahead of the wager branch
  // (a wager war carries a real stake AND a war point — one branch must own
  // both, or the war never scores), ahead of Hypnosis (a rewind would strand
  // Preset 5 on both fighters and un-decide a pairing that is already over),
  // and ahead of the tournament hook (a war pairing is never a bracket match).
  // Returns false only when there was nothing war-shaped about this duel, in
  // which case every older path below runs untouched.
  const warMatch = findActiveWarMatchFor(db, winnerJid, loserJid)
  if (warMatch) {
    const handled = await pvpConcludeWar(db, winnerJid, loserJid, ctx, reasonLine, warMatch)
    if (handled) return undefined
  }

  // ── Wager duels settle differently, and settle FIRST ────────────────────
  // Ahead of the Hypnosis check on purpose: wager mode disables every character
  // power (spec §1), and Anastasia unwinding a duel that has real solars in
  // escrow would be the single most exploitable thing in the mode. Ahead of the
  // tournament hook too, since a bracket match is never a wager.
  const wagerStake = wagerStakeOf(db, winnerJid, loserJid)
  if (wagerStake > 0) {
    return pvpConcludeWager(db, winnerJid, loserJid, ctx, reasonLine, wagerStake)
  }

  // ── Astral League fixture ─────────────────────────────────────────────
  // Ahead of Hypnosis for the same reason the war pairing is: a league result
  // goes on a published table whose tie break is the time a seat reached its
  // total, so un-deciding it would corrupt the tie break for every seat below.
  // Ahead of the tournament hook because a fixture is never a bracket match.
  // Returns false only when the duel was not a scheduled league match, in
  // which case every older path below runs untouched.
  const leagueMatch = findLeagueDuel(db, winnerJid, loserJid)
  if (leagueMatch) {
    const handled = await concludeLeagueDuel(db, winnerJid, loserJid, ctx, reasonLine, leagueMatch)
    if (handled) return undefined
  }

  // ── Astral League qualifier bout ───────────────────────────────────────
  // A qualifier card bout is fought as a battle but scored on the card, and
  // settling it here is the same no solars rule as a fixture: qualifying for a
  // competition that moves no money must not move money. Same placement as the
  // fixture hook for the same reasons, and it returns true so the normal
  // duel's solars ending below never runs on a bout.
  const qualifierBout = findQualifierBout(db, winnerJid, loserJid)
  if (qualifierBout) {
    return concludeQualifierBout(db, winnerJid, loserJid, ctx, reasonLine, qualifierBout)
  }

  // ── Astral League entrance trial ────────────────────────────────────────
  // Master Del Astra. Scored on damage dealt and turns survived rather than on
  // a win, because nobody wins, and settled here for the same no solars reason
  // as a bout: the 100k was already taken at the door, so a trial must not move
  // money a second time on the way out.
  const trialSettled = await concludeTrialFight(db, winnerJid, loserJid, ctx, reasonLine)
  if (trialSettled) return trialSettled

  // ── Liorei — Snapshot & Anastasia — Hypnosis ─────────────────────────
  // Ahead of the tournament hook on purpose: a bracket match is still a
  // duel, and "if they lose, whether in pvp or dungeon" covers it.
  if (allowRewind) {
    const snapRewound = await trySnapshotRewindPvp(db, winnerJid, loserJid, ctx, reasonLine)
    if (snapRewound) return snapRewound
    const rewound = await tryHypnosisRewindPvp(db, winnerJid, loserJid, ctx, reasonLine)
    if (rewound) return rewound
  }

  // ── Tournament hook ──────────────────────────────────────────────────
  // Was this duel actually a paired bracket match from an active
  // plugins/tourney.js tournament? If so, it does NOT go through the
  // normal 5%-solars-steal ending — bracket matches settle via the
  // tournament's fixed prize payout once the final concludes, not per-duel theft.
  // Both players are still healed/cleared exactly as a normal duel would
  // be; only the "who gets paid what and what message shows" branches.
  const tourneyMatch = findActiveMatchFor(db, winnerJid, loserJid)
  if (tourneyMatch) {
    return pvpConcludeTourneyMatch(db, winnerJid, loserJid, ctx, reasonLine, tourneyMatch)
  }

  let winnerName = ''
  let loserName = ''
  let pvpRankUp = null
  let transferred = 0
  let severLine = ''
  let wondersLine = ''
  let slainLine = ''

  // Need the winner's equippedCharacter before the loser's activeEffects
  // gets wiped below — applyPermanentSeverOnWin() must run before that
  // wipe, since permanentSever deliberately lives outside activeEffects
  // (see lib/character-abilities.js) specifically so it survives it, but
  // the *decision* of whether to apply it at all still has to happen here.
  const winnerSnapshot = getPlayer(db, winnerJid)
  const loserSnapshot = getPlayer(db, loserJid)

  // ── Ladder ──────────────────────────────────────────────────────────────
  // The rating swing MUST be computed from both ratings as they stand right
  // now, before either side is written. Deriving it inside the mutators
  // would read one player post-update and skew the other's swing.
  ensurePvp(winnerSnapshot ?? {})
  ensurePvp(loserSnapshot ?? {})
  const winnerRatingBefore = ratingOf(winnerSnapshot)
  const loserRatingBefore = ratingOf(loserSnapshot)
  const delta = ratingDelta(winnerRatingBefore, loserRatingBefore)
  // Guild spoils are paid on top of the seizure, not carved out of it — the
  // loser never loses more than VICTORY_SOLARS_PCT because their opponent
  // happens to belong to a Citadel.
  const spoilsPct = perksFor(db, winnerSnapshot).spoilsPct
  let spoilsBonus = 0

  // A duel that began as a Guild Clash match (stamped at accept, and carried
  // through a Hypnosis rewind) takes nothing from the loser: the bot picked the
  // fighters at random, so nobody loses 5% of their purse for being drawn. The
  // winner is paid the match prize below instead.
  const clashStamp = winnerSnapshot?.battleState?.clashId || loserSnapshot?.battleState?.clashId || null
  const clashDuel = Boolean(clashStamp)

  let beastCpMsg = ''
  let seasonMsg = ''
  let levelUpMsg = ''
  const expectedWinnerState=winnerSnapshot?.battleState, expectedLoserState=loserSnapshot?.battleState
  let settled=false
  await updateAllPlayers(db,()=>{
    const winner=getPlayer(db,winnerJid),loser=getPlayer(db,loserJid)
    if(!winner || !loser || winner===loser || !expectedWinnerState || winner.battleState!==expectedWinnerState || loser.battleState!==expectedLoserState)return false
    loserName = loser.name
    loser.wallet = loser.wallet ?? {}
    transferred = clashDuel ? 0 : pvpSeizure(winner, loser, VICTORY_SOLARS_PCT)
    loser.wallet.solars = Math.max(0, (loser.wallet.solars ?? 0) - transferred)
    // 🌋 Surtr — Twilight has to come off BEFORE this heal and BEFORE the battle
    // state is dropped, or a duelist who lost as a colossus is healed back to a
    // max HP that never existed for her (300,000 instead of her own 200,000).
    clearSurtrKit(loser, loser.battleState)
    loser.hp = loser.maxHp
    loser.mp = loser.maxMp
    loser.inBattle = false
    loser.battleState = null
    clearHypnosis(loser)
    clearSnapshot(loser)
    recordLoss(loser, winnerSnapshot?.name ?? null, delta, transferred)
    loser.pvp.lastOpponentJid = winnerJid

    // Urahara — Tear/Reshape permanent bleed (spec §13.2, "in PvP
    // specifically the bleed becomes a PERMANENT debuff on the losing
    // player"). Must run BEFORE activeEffects is wiped below, even though
    // permanentSever itself lives on a separate field, so this line stays
    // physically adjacent to (and clearly ordered before) the wipe for
    // anyone reading/maintaining this later.
    if (winnerSnapshot) {
      const line = applyPermanentSeverOnWin(winnerSnapshot, loser)
      if (line) severLine = line
    }

    // Tella — the "even after the battle" half of Wonders of You. Keyed off
    // loser.wondersCursePending (stamped when her final form forced the loss),
    // so it fires ONLY when she actually forsook them, never on an ordinary KO.
    // Runs after the full heal above so the 5% it removes reads as a wound that
    // did not close, and sits beside the sever it mirrors.
    {
      const line = applyWondersCurseOnWin(winnerSnapshot, loser)
      if (line) wondersLine = line
    }

    loser.activeEffects = []
    // Yelan's kill is settled at the END of the duel, never mid-turn: the slain
    // character is unequipped and the deadly poison is taken off. One call, both
    // conclusion paths, see finalizeSlainCharacters in lib/yelan-engine.js.
    {
      const line = finalizeSlainCharacters(loser)
      if (line) slainLine = line
    }
    winnerName = winner.name
    winner.wallet = winner.wallet ?? {}
    spoilsBonus = Math.floor(transferred * (spoilsPct / 100))
    winner.wallet.solars = (winner.wallet.solars ?? 0) + transferred + spoilsBonus
    // 🌋 Surtr — the same exit for the side that won: max HP and ATK go back
    // BEFORE the heal above, or a duelist who won as a colossus walks out of the
    // arena with 300,000 "total HP" instead of her own 200,000.
    clearSurtrKit(winner, winner.battleState)
    winner.hp = winner.maxHp
    winner.mp = winner.maxMp
    winner.inBattle = false
    winner.battleState = null
    winner.activeEffects = []
    clearHypnosis(winner)
    clearSnapshot(winner)
    {
      const line = finalizeSlainCharacters(winner)
      if (line) slainLine = slainLine ? `${slainLine}\n${line}` : line
    }
    recordWin(winner, loserSnapshot?.name ?? null, delta, transferred + spoilsBonus)
    winner.pvp.lastOpponentJid = loserJid

    // Yoriichi's own growth track — PvP wins are worth more than dungeon
    // wins (see YORIICHI_EXP_PER_PVP_WIN in character-abilities.js). No-op
    // if she isn't the winner's equipped character.
    grantYoriichiExp(winner, 'pvp')

    // Quest progress: a duel win. Recorded before applyLevelUps below so a
    // level bought by this duel's XP is also counted (level quests).
    recordQuestEvent(winner, 'pvp_win', 1)

    // 🌠 Astral Pass — a duel won pays points whether or not a season is
    // running, so it sits OUTSIDE the season block below. The tourney conclude
    // (pvpConcludeTourneyMatch) carries its own copy for the same reason: it
    // does not call through here, and the two are mutually exclusive.
    awardAstralPoints(winner, POINT_VALUES.pvp, 'pvp')

    // Summon Beast: the winner's active beast (if any) gains CP for the
    // win, same lever PvE kills use — see PVP_WIN_XP_EQUIVALENT above.
    beastCpMsg = awardBeastCp(winner, PVP_WIN_XP_EQUIVALENT)
    const season = getActiveSeason(db)
    if (season) {
      const result = applySeasonPoints(winner, season, season.bonuses?.winPoints)
      const seasonXp = Math.max(0, Math.floor(PVP_WIN_XP_EQUIVALENT * (Number(season.bonuses?.winXpPercent ?? 0) / 100)))
      const seasonSolars = Math.max(0, Math.floor(transferred * (Number(season.bonuses?.winSolarsPercent ?? 0) / 100)))
      winner.xp = (winner.xp ?? 0) + seasonXp
      winner.wallet.solars += seasonSolars
      const currencyLabel = season.currencyLabel ?? (season.id === 'season_02' ? 'Stars' : 'Season Points')
      const currencyEmoji = season.id === 'season_02' ? '⭐' : '🌞'
      seasonMsg = result.gained
        ? `\n${currencyEmoji} Season bonus: +${result.gained} ${currencyLabel}, +${seasonXp} XP, +${seasonSolars} Solars`
        : ''
    }

    // Duel XP has to be able to LEVEL the winner. Adding to winner.xp without
    // this call was the whole bug: player.xp is cumulative and is compared
    // against levelsData.xpTable, so XP banked past the next threshold just sat
    // there and profile.js rendered a negative "to next". Called unconditionally
    // (not just inside the season branch above) on purpose: applyLevelUps is a
    // catch-up while-loop, so a winner who already banked XP past one or more
    // thresholds while this was broken collects every pending level here, and a
    // winner with nothing pending no-ops. The full heal it does on each level is
    // consistent with the duel healing both players anyway (see above).
    const lvl = applyLevelUps(winner, levelsData, classes, races, getTotalStats)
    if (lvl.msgs.length) { levelUpMsg = `\n\n${lvl.msgs.join('\n')}`; recordQuestEvent(winner, 'level', lvl.msgs.length) }
    if (lvl.rankChange) {
      levelUpMsg += `\n\n⚔️ *RANK UP!* ${lvl.rankChange.to.emoji} *${lvl.rankChange.to.title}*\n_"${lvl.rankChange.to.epithet}"_`
      pvpRankUp = { from: lvl.rankChange.from, to: lvl.rankChange.to }
    }
    settled=true;return true
  },{requireWrite:true})
  if(!settled)return

  // The clash match is claimed and paid in one synchronous step (a second
  // conclusion for the same match finds it decided and pays nothing). A match
  // that was voided by the week rolling over mid duel pays nothing either, and
  // still took nothing from the loser, which is what both players were told.
  // The stamp has to name the match that is open NOW, so a duel begun in an
  // earlier week can never be credited to a different match of this one.
  let clashText = ''
  if (clashDuel) {
    const found = findOpenClashMatch(db, winnerJid, loserJid)
    const recorded = found && clashKey(found) === clashStamp
      ? await recordClashResult(db, found, winnerJid, loserJid)
      : null
    clashText = recorded
      ? clashResultText(recorded)
      : `🤺 *GUILD CLASH*\n_This match closed with the clash, so there is no prize. Nothing was taken from the loser._`
  }

  const winnerAfter = getPlayer(db, winnerJid)
  const loserAfter = getPlayer(db, loserJid)
  const winnerBand = rankFor(winnerAfter)
  const loserBand = rankFor(loserAfter)
  const guildDef = winnerSnapshot?.guildId ? getGuildDef(winnerSnapshot.guildId) : null
  const spoilsLine = spoilsBonus > 0
    ? `\n🏰 *${guildDef?.name ?? 'Guild'}* spoils: *+${spoilsBonus}* extra _(${spoilsPct}% guild cut)_`
    : ''

  // Yu Miaoyi — the wake line (§3.3). The snapshots were taken BEFORE the
  // mutators above nulled battleState, so they still carry her possession
  // stamp; whichever duelist she was driving wakes up with a word from her,
  // win or lose.
  const lucidWake = [winnerSnapshot, loserSnapshot]
    .filter((s) => s && isLucidBattle(s))
    .map((s) => lucidWakeLine(s))
    .join('\n')

  await ctx.reply(
    `🏆🔥 *DUEL OVER!!* 🔥🏆\n\n` +
    reasonLine + `\n\n` +
    `👑💀 *${winnerName.toUpperCase()} DEFEATS ${loserName.toUpperCase()}!* 💀👑\n` +
    (clashDuel
      ? `🤝 _A Guild Clash match: nothing is taken from the loser._`
      : `☀️💰 *+${transferred} SOLARS SEIZED!* _(5% of their wallet — gems & vault untouched)_`) +
    spoilsLine + `\n\n` +
    (clashText ? `${clashText}\n\n` : '') +
    `📈 *RATING*\n` +
    `${winnerBand.emoji} *${winnerName}*: ${ratingOf(winnerAfter)} _(+${delta})_  ·  streak ${streakLabel(winnerAfter)}\n` +
    `${loserBand.emoji} *${loserName}*: ${ratingOf(loserAfter)} _(-${delta})_  ·  streak ${streakLabel(loserAfter)}\n\n` +
    `❤️‍🩹 Both duelists are fully healed. No gear was lost.` +
    (severLine ? `\n\n${severLine}` : '') +
    (wondersLine ? `\n\n${wondersLine}` : '') +
    (slainLine ? `\n\n${slainLine}` : '') +
    (beastCpMsg ? `\n\n${beastCpMsg}` : '') + seasonMsg + levelUpMsg +
    (lucidWake ? `\n\n${lucidWake}` : '') +
    `\n\n_Rematch: *${config.prefix}pvp rematch* · Ladder: *${config.prefix}pvptop*_`,
  )

  // Rank promotion — the dedicated rank-up card, after the duel summary.
  if (pvpRankUp) await sendRankUp(ctx, winnerName, pvpRankUp.from, pvpRankUp.to)
}

/**
 * pvpConcludeTourneyMatch — the tournament-flavored twin of pvpConclude().
 * Both duelists are healed and cleared exactly as usual (no gear loss, no
 * PvP daily-limit interaction), but no solars/gems change hands here —
 * that only happens once when the whole tournament finishes, via
 * finishTourney()'s fixed prize1st/prize2nd payout. This just records the bracket
 * result and shows either an "advance to next round" or, once the final
 * resolves, hands off to finishTourney() for the full payout + title.
 */
async function pvpConcludeTourneyMatch(db, winnerJid, loserJid, ctx, reasonLine, tourneyMatch) {
  let winnerName = ''
  let loserName = ''
  let pvpRankUp = null
  let severLine = ''
  let wondersLine = ''
  let slainLine = ''
  const winnerSnapshot = getPlayer(db, winnerJid)
  const loserSnapshot = getPlayer(db, loserJid)

  // A bracket match is still a duel, so it still moves the ladder. Same
  // both-ratings-before-either-write rule as pvpConclude() above.
  ensurePvp(winnerSnapshot ?? {})
  ensurePvp(loserSnapshot ?? {})
  const delta = ratingDelta(ratingOf(winnerSnapshot), ratingOf(loserSnapshot))

  await updatePlayer(db, loserJid, (loser) => {
    loserName = loser.name
    // 🌋 Surtr — a bracket match is a duel too, so the colossus has to come off
    // before the heal, exactly as in pvpConclude().
    clearSurtrKit(loser, loser.battleState)
    loser.hp = loser.maxHp
    loser.mp = loser.maxMp
    loser.inBattle = false
    loser.battleState = null
    clearHypnosis(loser)
    clearSnapshot(loser)
    recordLoss(loser, winnerSnapshot?.name ?? null, delta, 0)
    if (winnerSnapshot) {
      const line = applyPermanentSeverOnWin(winnerSnapshot, loser)
      if (line) severLine = line
    }
    // Tella — Wonders of You's lingering curse also carries into a bracket
    // match. Same placement and reasoning as in pvpConclude() above.
    {
      const line = applyWondersCurseOnWin(winnerSnapshot, loser)
      if (line) wondersLine = line
    }
    loser.activeEffects = []
    // Yelan's kill is settled at the END of the duel, never mid-turn: the slain
    // character is unequipped and the deadly poison is taken off. One call, both
    // conclusion paths, see finalizeSlainCharacters in lib/yelan-engine.js.
    {
      const line = finalizeSlainCharacters(loser)
      if (line) slainLine = line
    }
  })

  let beastCpMsg = ''
  let seasonMsg = ''
  let levelUpMsg = ''
  await updatePlayer(db, winnerJid, (winner) => {
    winnerName = winner.name
    clearSurtrKit(winner, winner.battleState)
    winner.hp = winner.maxHp
    winner.mp = winner.maxMp
    winner.inBattle = false
    winner.battleState = null
    winner.activeEffects = []
    clearHypnosis(winner)
    clearSnapshot(winner)
    {
      const line = finalizeSlainCharacters(winner)
      if (line) slainLine = slainLine ? `${slainLine}\n${line}` : line
    }
    recordWin(winner, loserSnapshot?.name ?? null, delta, 0)
    grantYoriichiExp(winner, 'pvp')
    // 🌠 Astral Pass — the tourney conclude's copy of the award in pvpConclude.
    // This path does not call through there, so it needs its own; the two can
    // never both fire for one fight.
    awardAstralPoints(winner, POINT_VALUES.pvp, 'pvp')
    beastCpMsg = awardBeastCp(winner, PVP_WIN_XP_EQUIVALENT)
    const season = getActiveSeason(db)
    if (season) {
      const result = applySeasonPoints(winner, season, season.bonuses?.winPoints)
      const seasonXp = Math.max(0, Math.floor(PVP_WIN_XP_EQUIVALENT * (Number(season.bonuses?.winXpPercent ?? 0) / 100)))
      winner.xp = (winner.xp ?? 0) + seasonXp
      const currencyLabel = season.currencyLabel ?? (season.id === 'season_02' ? 'Stars' : 'Season Points')
      const currencyEmoji = season.id === 'season_02' ? '⭐' : '🌞'
      seasonMsg = result.gained
        ? `\n${currencyEmoji} Season bonus: +${result.gained} ${currencyLabel}, +${seasonXp} XP`
        : ''
    }

    // Same catch-up as pvpConclude() above — a bracket win is still a duel, so
    // its XP still has to be able to level the winner.
    const lvl = applyLevelUps(winner, levelsData, classes, races, getTotalStats)
    if (lvl.msgs.length) levelUpMsg = `\n\n${lvl.msgs.join('\n')}`
    if (lvl.rankChange) {
      levelUpMsg += `\n\n⚔️ *RANK UP!* ${lvl.rankChange.to.emoji} *${lvl.rankChange.to.title}*\n_"${lvl.rankChange.to.epithet}"_`
      pvpRankUp = { from: lvl.rankChange.from, to: lvl.rankChange.to }
    }
  })

  const { groupJid, roundIdx, matchIdx, tourney } = tourneyMatch
  const result = await advanceMatch(db, groupJid, roundIdx, matchIdx, winnerJid)

  if (result.finished) {
    return finishTourney(
      ctx, db, groupJid, result.tourney, result.championJid, result.runnerUpJid,
      reasonLine,
    )
  }

  const tourneyLucidWake = [winnerSnapshot, loserSnapshot]
    .filter((s) => s && isLucidBattle(s))
    .map((s) => lucidWakeLine(s))
    .join('\n')

  await ctx.reply(
    `🏆 *${tourney.name}* — BRACKET RESULT 🏆\n\n` +
    reasonLine + `\n\n` +
    `👑 *${winnerName.toUpperCase()} DEFEATS ${loserName.toUpperCase()}!*\n` +
    `➡️ *${winnerName}* advances to the next round!\n\n` +
    `❤️‍🩹 Both duelists are fully healed. No gear or currency was lost.` +
    (severLine ? `\n\n${severLine}` : '') +
    (wondersLine ? `\n\n${wondersLine}` : '') +
    (slainLine ? `\n\n${slainLine}` : '') +
    (beastCpMsg ? `\n\n${beastCpMsg}` : '') + seasonMsg + levelUpMsg +
    // Yu Miaoyi's wake line, same rule as pvpConclude (§3.3): the snapshots
    // still carry the possession stamp the mutators above just cleared.
    (tourneyLucidWake ? `\n\n${tourneyLucidWake}` : '') +
    `\n\n_Check the bracket anytime: *${config.prefix}tourney bracket*_`,
  )

  // Rank promotion — the dedicated rank-up card, after the bracket summary.
  if (pvpRankUp) await sendRankUp(ctx, winnerName, pvpRankUp.from, pvpRankUp.to)
}

const ARENA_LIST_ALIASES = new Set(['arenas', 'arena', 'maps', 'map', 'locations', 'location', 'places', 'battlefields', 'stages'])

/** `.pvp arenas` — the picture of every arena and the word that picks each one. */
async function showArenas(ctx) {
  const pr = config.prefix
  const lines = Object.values(PVP_ARENAS).map((a) => `• *${a.name}* — ${a.blurb}\n   → *${pr}pvp @name ${a.word}*`)
  const text =
    `🏟️ *DUEL ARENAS*\n\n` +
    `Pick where the fight happens by adding the arena's word to your challenge:\n\n` +
    `${lines.join('\n')}\n\n` +
    `_Wagers too: *${pr}pvp wager 5k @name castle*_\n` +
    `_No word, no problem — the arena is picked at random._`
  return replyWithPanel(ctx, () => renderArenaMenu(), text)
}

export default {
  name: 'pvp',
  aliases: ['duel'],
  category: 'pvp',
  requiresPlayer: true,
  description: `${config.prefix}pvp @target — challenge another player to a duel`,
  subcommands: [
    { cmd: '@target [arena]', desc: 'challenge someone (reply or @mention), optionally naming the arena' },
    { cmd: 'arenas', desc: 'see the duel arenas and how to pick one' },
    { cmd: 'accept / decline', desc: 'answer a challenge against you' },
    { cmd: 'moves', desc: 'every move you can make this turn, and what it costs' },
    { cmd: 'status', desc: 'the current board — HP, MP, effects, whose turn' },
    { cmd: 'attack', desc: 'basic attack' },
    { cmd: 'skill <name>', desc: 'spend MP on a skill' },
    { cmd: 'ability <name>', desc: 'fire an equipped active ability' },
    { cmd: 'defend', desc: 'brace — +MP and the next hit is halved' },
    { cmd: 'rematch', desc: 'challenge your last opponent again' },
    { cmd: 'claim', desc: 'take the win if your opponent has stalled out' },
    { cmd: 'forfeit', desc: 'concede the duel' },
    { cmd: 'on / off', desc: 'bot mods — allow duels in this group' },
    // ── wager mode ──
    { cmd: 'wager <amount> @target', desc: 'stake solars: no turns, no characters, loser pays in full' },
    { cmd: 'stock <item> [n]', desc: 'pack an item into your 15-slot PvP kit' },
    { cmd: 'unstock <item> [n]', desc: 'pull an item back out of the kit' },
    { cmd: 'inv', desc: 'the PvP kit, drawn as a 5x3 grid' },
    { cmd: 'atk / sk <name> / def', desc: 'wager duel moves (2s cooldown, no same move twice in a row)' },
    { cmd: 'dr <item>', desc: 'wager: drink a potion out of the kit' },
    { cmd: 'tot', desc: 'wager: slot a fresh totem into your off hand' },
    { cmd: 'arm <slot> / wpn <name>', desc: 'wager: swap in stocked gear' },
    { cmd: 'mnd arm / mnd wpn', desc: 'wager: repair half the durability lost' },
    { cmd: 'rf', desc: 'wager: Focus Vial — refill every spent skill PP' },
  ],

  async run(ctx) {
    await flushPendingCriticalWrites(ctx.db)
    if (isBattleCinematicActive(ctx)) return
    const { player, args, db } = ctx
    const pr = config.prefix
    const sub = (args[0] ?? '').toLowerCase()

    // ── ON / OFF (bot mods only) ────────────────────────────────────────
    if (sub === 'on' || sub === 'off') {
      if (!ctx.isGroup) return ctx.reply(NOT_GROUP)
      if (!(await isBotStaff(ctx))) return ctx.reply(NOT_STAFF)
      const res = await saveGroupSettings(ctx.sender, (s) => { s.pvpEnabled = (sub === 'on') })
      if (!res.ok) return ctx.reply(saveFailedMessage('PvP', res.error))
      // Reported from the stored value, not from `sub` — a confirmation built
      // out of the request is a claim with nothing behind it.
      return ctx.reply(`🥊 PvP is now *${res.settings.pvpEnabled ? 'ON' : 'OFF'}* in this group.`)
    }

    // ── KIT: stock / unstock / inv ────────────────────────────────────────
    // Deliberately ahead of the group gate below. Packing a kit is preparation,
    // not a duel: it changes nothing for anyone else in the chat, so a group
    // with PvP switched off has no reason to stop someone getting ready for a
    // duel they will fight somewhere else.
    if (STOCK_ALIASES.has(sub))   return stockKit(ctx, args.slice(1))
    if (UNSTOCK_ALIASES.has(sub)) return unstockKit(ctx, args.slice(1))
    if (KIT_ALIASES.has(sub))     return showKit(ctx)
    if (ARENA_LIST_ALIASES.has(sub)) return showArenas(ctx)

    // ── Group gate ───────────────────────────────────────────────────────────
    // One deliberate exemption: a GUILD WAR must never be blocked by this
    // toggle. A war pairing is declared by two guild leaders, tracked by the
    // bot, and announced in the group — if `.pvp off` could wedge it, one
    // admin mute would park a live war until it voided on the sweep. The
    // exemption is narrow: only an incoming war challenge (`.pvp accept`)
    // and only while the sender is inside a war pairing.
    //
    // A second, narrower exemption: a GUILD CLASH champion may fight their clash
    // opponent here. The bot drew the champions at random, so a group that has
    // switched PvP off must not be able to strand a match. The pass only gets the
    // sender past this gate. The accept path and the challenge path below each
    // refuse anything that is not the clash match (clashOnlyHere), so a champion
    // still cannot duel anyone else in a group with PvP off.
    let clashOnlyHere = false
    if (ctx.isGroup) {
      const settings = await getGroupSettings(ctx.sender)
      const warPass = !!(
        (player?.pvpChallenge?.warId)
        || (player?.battleState?.warId && player?.inBattle)
      )
      const clashPass = !settings.pvpEnabled && !warPass && !!(
        player?.pvpChallenge?.clashId
        || (player?.battleState?.clashId && player?.inBattle)
        || hasOpenClash(db, ctx.from)
      )
      if (!settings.pvpEnabled && !warPass && !clashPass) {
        return ctx.reply(
          `🚫 PvP is disabled in this group.\n` +
          `_A bot mod can turn it back on with *${pr}pvp on*._`,
        )
      }
      clashOnlyHere = clashPass
    }
    const pvpOffReply = () => ctx.reply(
      `🚫 PvP is disabled in this group.\n` +
      `_The only duel allowed here is your Guild Clash match. A bot mod can turn PvP back on with *${pr}pvp on*._`,
    )

    // ── ACCEPT ────────────────────────────────────────────────────────────
    if (sub === 'accept') {
      const challenge = player.pvpChallenge
      if (!challenge) return ctx.reply(`❌ You have no pending duel challenge.`)
      if (Date.now() > challenge.expiresAt) {
        await updatePlayer(db, ctx.from, (p) => { p.pvpChallenge = null })
        return ctx.reply(`⏳ That challenge expired.`)
      }
      const challengerJid = challenge.fromJid
      if (!playerExists(db, challengerJid)) {
        await updatePlayer(db, ctx.from, (p) => { p.pvpChallenge = null })
        return ctx.reply(`❌ That challenger is no longer registered.`)
      }
      const challenger = getPlayer(db, challengerJid)
      if (challenger.inBattle || challenger.inDungeon) {
        await updatePlayer(db, ctx.from, (p) => { p.pvpChallenge = null })
        return ctx.reply(`❌ *${challenger.name}* is no longer available to duel.`)
      }
      if (player.inBattle || player.inDungeon) {
        return ctx.reply(`❌ You can't accept a duel while in battle or a dungeon.`)
      }

      // ── GUILD CLASH? A duel between the two champions the bot paired this clash
      // is the clash match, so it is stamped on BOTH battle states from the first
      // move (inside the object literal, so Hypnosis' opening snapshot carries it
      // too). A guild war pairing between the same two keeps its own settlement.
      // Wagers are a different mode and never count.
      const clashDuel = challenge.wagerAmount > 0 || findActiveWarMatchFor(db, challengerJid, ctx.from)
        ? null
        : findOpenClashMatch(db, challengerJid, ctx.from)
      // A replaced or closed clash challenge must never become an ordinary
      // purse-taking duel merely because PvP is enabled in this chat.
      if (challenge.clashId && (!clashDuel || clashKey(clashDuel) !== challenge.clashId)) {
        await updatePlayer(db, ctx.from, p => { p.pvpChallenge = null })
        return ctx.reply(`⏳ That Guild Clash match changed or closed. Check *${pr}guild clash*.`)
      }
      if (clashOnlyHere && !clashDuel) {
        if (challenge.clashId) {
          await updatePlayer(db, ctx.from, (p) => { p.pvpChallenge = null })
          return ctx.reply(`⏳ That Guild Clash match closed with the clash, so the challenge is gone.`)
        }
        return pvpOffReply()
      }
      const clashStamp = clashDuel ? { clashId: clashKey(clashDuel) } : {}

      // ── Wager duels take a different opening: both stakes are escrowed here
      // and neither side gets a turn flag. Everything above (expiry, both
      // players still free, challenger still registered) is shared, so the
      // branch sits after the checks rather than duplicating them.
      if (challenge.wagerAmount > 0) {
        return acceptWagerDuel(ctx, challengerJid, challenge.wagerAmount)
      }

      let raceAborted = false
      // Gogeta — Instant Transmission, the turn-order face of it. A duel
      // alternates strictly and the challenger opens by default, so the only
      // turn that can be seized is this one, and only the ACCEPTER has anything
      // to win by seizing it. Rolled once here, before either battleState is
      // built, so both records agree on who is holding the baton.
      let gogetaOpener = rollInstantTransmissionOpener(player)
      // Rimuru's Magic Sense: no ambush, always the first opening turn. If both
      // duelists are Rimuru, the accepter's claim is read last and holds.
      if (challenger.equippedCharacter === S2_IDS.rimuru) gogetaOpener = false
      if (player.equippedCharacter === S2_IDS.rimuru) gogetaOpener = true
      // Computed OUTSIDE both mutators, from the two records already in hand:
      // the King and the Queen cannot face each other, and whichever side is
      // shut out has to be told in the fight's own opening line rather than
      // finding out by wasting a turn on a refused command.
      const crownChallenger = armCrownPresence(challenger, player, { otherName: player.name })
      const crownAccepter = armCrownPresence(player, challenger, { otherName: challenger.name })
      const crownLine = [crownChallenger.line, crownAccepter.line].filter(Boolean).join('\n')
      // Anastasia — Hypnosis. A duel rewind has to unwind BOTH sides, so if
      // either duelist holds her, both get an opening-state snapshot; the
      // winner's is what puts them back where they started before the 15%
      // toll lands. force mirrors that: when she's in the duel everyone is
      // armed, and when she isn't, armHypnosis() clears any stale snapshot
      // left on a record by an earlier fight rather than leaving it to rot.
      const duelHasAnastasia = hasAnastasia(challenger) || hasAnastasia(player)
      // One arena for the whole duel: the same bgSeed on both battle states,
      // so neither duelist's frames re-roll the background mid-match.
      const duelBgSeed = `bg${Date.now().toString(36)}${Math.floor(Math.random() * 0xffffffff).toString(36)}`
      await updatePlayer(db, challengerJid, (c) => {
        if (c.inBattle || c.inDungeon) { raceAborted = true; return }
        // This runs in the player write lane, which is excluded by the guild
        // selection's global barrier. Freeze the fixture before either battle
        // state can later be cleared during duel settlement.
        if (clashDuel) {
          const live = findOpenClashMatch(db, challengerJid, ctx.from)
          if (!live || clashKey(live) !== clashStamp.clashId) { raceAborted = true; return }
          live.match.startedAt = Date.now()
        }
        c.inBattle = true
        c.battleState = { type: 'pvp', opponentJid: ctx.from, myTurn: !gogetaOpener, defending: false, turn: 1, startedAt: Date.now(), lastMoveAt: Date.now(), arena: challenge.arena ?? null, bgSeed: duelBgSeed, ...clashStamp }
        // Yu Miaoyi arms BEFORE Anastasia's snapshot on purpose: the rewind
        // has to carry the possession through with it (§7.1), so the stamp
        // must exist when the snapshot captures battleState.
        armLucidEmbrace(c)
        armHypnosis(c, { force: duelHasAnastasia })
        armSnapshot(c)
        // Alexa — Lovestruck. One call arms BOTH directions for this side: if
        // the challenger holds her, the accepter's blows lose their will; if the
        // ACCEPTER holds her, the challenger's own companion stops working. The
        // opponent has to be passed in because the tier is a comparison, and
        // this is the only moment in a duel where both records are in hand.
        armLovestruck(c, player)
        // Tella — Wonders of You. Armed here beside Lovestruck so a stale
        // envy phase from an earlier duel can never ride into this one.
        armWondersOfEnvy(c)
        // Gogeta — Fusion of Equals. Armed on the same terms, and the clock
        // starts on turn 1 for whichever side holds him.
        armFusion(c)
        armRegressor(c)
        c.battleState._trioIntro = armTrioCharacters(c, player, { prefix: pr }) || undefined
        // Avessa — the Perfect Mirror. Copied ONCE, here, from the other
        // player's companion, or (nothing copyable) from the other player
        // themselves — and only for the side actually fielding her: armMirror
        // refuses an owner without her equipped, so a duel between two players
        // who do not own her arms nothing at all (lib/avessa-engine.js).
        if (hasAvessa(c)) armMirror({ owner: c, opponent: player, battleState: c.battleState })
        // 👑 The crowns, challenger's half. armCrownPresence is PURE and takes
        // both records — it is the only cross-player read a duel is allowed to
        // do from inside a mutator, because it awaits nothing. It stamps
        // battleState.crown with what this side fields and what the other side
        // shuts off, and hands back the opening line for the accept reply.
        c.battleState.crown = crownChallenger.crown ?? undefined
      })
      if (raceAborted) {
        await updatePlayer(db, ctx.from, (p) => { p.pvpChallenge = null })
        return ctx.reply(`❌ *${challenger.name}* is no longer available to duel.`)
      }

      await updatePlayer(db, ctx.from, (p) => {
        p.pvpChallenge = null
        p.inBattle = true
        p.battleState = { type: 'pvp', opponentJid: challengerJid, myTurn: gogetaOpener, defending: false, turn: 1, startedAt: Date.now(), lastMoveAt: Date.now(), arena: challenge.arena ?? null, bgSeed: duelBgSeed, ...clashStamp }
        // Yu Miaoyi, accepter's half — armed before the snapshot, same rule.
        armLucidEmbrace(p)
        armHypnosis(p, { force: duelHasAnastasia })
        armSnapshot(p)
        // Alexa — the accepter's half of the same arming, mirrored.
        armLovestruck(p, challenger)
        // Tella — the accepter's half of the Wonders of You arming, mirrored.
        armWondersOfEnvy(p)
        // Gogeta — the accepter's half of the fusion arming, mirrored.
        armFusion(p)
        armRegressor(p)
        p.battleState._trioIntro = armTrioCharacters(p, challenger, { prefix: pr }) || undefined
        // Avessa — the accepter's half of the mirror arming, mirrored — and
        // gated on the same rule: without her equipped there is nothing to arm.
        if (hasAvessa(p)) armMirror({ owner: p, opponent: challenger, battleState: p.battleState })
        // 👑 The crowns, accepter's half — the mirrored read of the same pair.
        p.battleState.crown = crownAccepter.crown ?? undefined
      })

      // ── GUILD WAR pairing? Isolate both fighters behind Preset 5 NOW, at
      // the exact moment the duel starts, and stamp the battleStates with the
      // war id (plugins/pvp.js's group gate above reads that stamp). No-op
      // for an ordinary duel — beginWarDuel returns null when this pair is
      // not the live war pairing.
      const warDuel = await beginWarDuel(db, challengerJid, ctx.from)
      const freshChallenger = warDuel ? getPlayer(db, challengerJid) : challenger
      const freshMe = warDuel ? getPlayer(db, ctx.from) : player

      await ctx.reply(
        (warDuel
          ? `⚔️🔥 *GUILD WAR PAIRING — LIVE!* 🔥⚔️\n` +
            `${warDuelKitLine(warDuel)}\n` +
            `_Your real inventory is stored and comes back the moment this duel ends._\n\n`
          : '') +
        (clashDuel && !warDuel ? `${clashLiveLine(clashDuel)}\n\n` : '') +
        `⚔️ *DUEL ACCEPTED!*\n\n` +
        `🥊 *${freshChallenger.name}* ${levelTag(freshChallenger)} vs *${freshMe.name}* ${levelTag(freshMe)}\n` +
        `❤️ ${freshChallenger.name}: ${freshChallenger.hp}/${freshChallenger.maxHp}   ❤️ ${freshMe.name}: ${freshMe.hp}/${freshMe.maxHp}\n\n` +
        (gogetaOpener
          ? `✨ _Instant Transmission: ${player.name} is already standing where the duel starts._\n` +
            `*${player.name}* goes first!\n`
          : `*${challenger.name}* goes first!\n`) +
        `Moves: *${pr}pvp attack* · *${pr}pvp skill <name>* · *${pr}pvp ability <name>* · *${pr}pvp defend*\n` +
        `_Not sure what you can cast? *${pr}pvp moves* lists everything._` +
        (crownLine ? `\n\n` + crownLine : '') +
        (() => {
          const intros = [freshChallenger?.battleState?._trioIntro, freshMe?.battleState?._trioIntro].filter(Boolean)
          return intros.length ? `\n\n${intros.join('\n\n')}` : ''
        })()
      )

      // ── Yu Miaoyi — the Embrace scene, whichever duelist holds her ──────
      // She tucks her owner in the moment the duel opens (§3.2), shows her
      // talking image, and if the opening baton landed on her owner she takes
      // that first turn on the spot — the opponent is never left waiting on a
      // player who is asleep. Both duelists can't hold her at once (one-of-one
      // lock), but the loop reads each side honestly anyway.
      for (const [jid, duelist, otherName] of [
        [challengerJid, freshChallenger, freshMe.name],
        [ctx.from, freshMe, freshChallenger.name],
      ]) {
        if (!isLucidBattle(duelist)) continue
        const talk = characterExtraImage(YU_CHARACTER_ID, 'talk')
        const scene = lucidEmbraceScene(duelist, { opponentName: otherName })
        if (talk) await sendImageTo(ctx.sock, ctx.jid, talk, scene).catch(async () => { await ctx.reply(scene).catch(() => {}) })
        else await ctx.reply(scene).catch(() => {})
      }
      const opener = getPlayer(db, gogetaOpener ? ctx.from : challengerJid)
      if (isLucidBattle(opener)) {
        await autoResolveCatFormTurns(db, ctx, challengerJid, ctx.from, { lead: '' })
      }
      // The duel is open and announced; nothing below applies to `accept`. Without
      // this the command fell through to the challenge path and every accept was
      // followed by a stray "Usage: .pvp @target" message.
      return
    }

    // ── DECLINE ───────────────────────────────────────────────────────────
    if (sub === 'decline') {
      if (!player.pvpChallenge) return ctx.reply(`❌ You have no pending duel challenge.`)
      const fromJid = player.pvpChallenge.fromJid
      await updatePlayer(db, ctx.from, (p) => { p.pvpChallenge = null })
      const fromName = playerExists(db, fromJid) ? getPlayer(db, fromJid).name : 'them'
      return ctx.reply(`🚫 You declined the duel from *${fromName}*.`)
    }

    // ── FORFEIT ───────────────────────────────────────────────────────────
    if (sub === 'forfeit' || sub === 'flee') {
      if (!inPvp(player)) return ctx.reply(`❌ You're not in a duel.`)
      const opponentJid = player.battleState.opponentJid
      // Conceding a wager duel concedes the stake. Settlement is identical
      // either way (pvpConclude routes into pvpConcludeWager), so only the line
      // that tells the chat what just happened changes — quitting must not read
      // like a free exit when it costs the full stake.
      const forfeitLine = isWagerState(player.battleState)
        ? `_${player.name} forfeits and concedes the ${(player.battleState.wagerAmount ?? 0).toLocaleString()} solar stake!_`
        : `_${player.name} forfeits the duel!_`
      // allowRewind: false — a forfeit is a choice, not a death. Rewinding it
      // would let an Anastasia owner farm 15% off an opponent by quitting
      // twice, and there is nothing to put them "back" into: they asked out.
      return pvpConclude(db, opponentJid, ctx.from, ctx, forfeitLine, { allowRewind: false })
    }

    // ── MOVES / STATUS / CLAIM ────────────────────────────────────────────
    if (sub === 'seal' || sub === 'seals' || sub === 'fairyseal') {
      return ctx.reply(fairySealStatus(player, player?.battleState))
    }
    if (sub === 'moves' || sub === 'move' || sub === 'options') return showMoves(ctx)
    if (sub === 'status' || sub === 'board' || sub === 'hp')   return showStatus(ctx)
    if (sub === 'claim' || sub === 'timeout')                   return claimStale(ctx)

    // ── WAGER MODE actions ────────────────────────────────────────────────
    // Ahead of the normal action block on purpose. A wager battleState carries
    // type: 'pvp' (so the rest of the bot's duel guards keep working), which
    // means `.pvp attack` would otherwise fall straight into runPvpTurn and
    // bring the whole character layer with it. Everything wager routes here
    // instead, and runPvpTurn refuses a wager state as a backstop.
    const wagerBs = inPvp(player) && isWagerState(player.battleState) ? player.battleState : null
    if (wagerBs) {
      if (W_ATTACK.has(sub) || sub === 'attack') return runWagerAction(ctx, 'attack', '')
      if (W_SKILL.has(sub)  || sub === 'skill')  return runWagerAction(ctx, 'skill', args.slice(1).join(' '))
      if (W_DEFEND.has(sub) || sub === 'defend') return runWagerAction(ctx, 'defend', '')
      if (W_DRINK.has(sub))  return runWagerItem(ctx, 'drink', args.slice(1).join(' '))
      if (W_TOTEM.has(sub))  return runWagerItem(ctx, 'totem', '')
      if (W_ARMOR.has(sub))  return runWagerItem(ctx, 'armor', args.slice(1).join(' '))
      if (W_WEAPON.has(sub)) return runWagerItem(ctx, 'weapon', args.slice(1).join(' '))
      if (W_MEND.has(sub))   return runWagerItem(ctx, 'mend', args.slice(1).join(' '))
      if (W_REFILL.has(sub)) return runWagerItem(ctx, 'refill', '')
    }

    // Audrey's readout is free after activation; the first use goes through the
    // same turn engine and wager restriction as every other character move.
    if (sub === 'spectate' || (sub === 'ability' && isAudreyAbilityQuery(args.slice(1).join(' ')))) {
      return pvpSpectate(ctx)
    }

    // ── ATTACK / SKILL / DEFEND / ABILITY / CINDER VERDICT / ULTIMATE / WILD CARD ──
    const CINDER_ALIASES = new Set(['cinderverdict', 'cinder', 'cv', 'verdict'])
    // 🔥 Rengoku's Blaze Heart. Every token the top-level `.blaze-heart` command
    // answers to (plugins/blaze-heart.js), so `.pvp blaze-heart` and `.pvp bh`
    // work the same way from inside the duel.
    const BLAZEHEART_ALIASES = new Set(['blaze-heart', 'blazeheart', 'blaze', 'bh', 'flameheart', 'ninthform'])
    const ULTIMATE_ALIASES = new Set(['ultimate', 'dragon'])
    const WILDCARD_ALIASES = new Set(['wildcard', 'wc', 'wild', 'card'])
    const DOMAIN_ALIASES = new Set(['domain', 'domainexpansion', 'domain-expansion', 'de', 'chimera'])
    const THIEFSEYE_ALIASES = new Set(['thiefseye', 'thiefs-eye', 'steal', 'te', 'mimic'])
    const HOLLOW_ALIASES = new Set(['hollowexchange', 'hollow-exchange', 'hollow', 'exchange', 'hx'])
    const HOLLOWPURPLE_ALIASES = new Set(['hollowpurple', 'purple', 'hollow-purple'])
    const UNLIMITEDVOID_ALIASES = new Set(['unlimitedvoid', 'unlimited-void', 'void', 'uv'])
    const SOULPUNISHER_ALIASES = new Set(['soulpunisher', 'soulpunish', 'soul-punisher', 'punisher', 'spunisher', 'kiblast'])
    const KAMEHAMEHA_ALIASES = new Set(['kamehameha', 'bbk', 'bigbang', 'bigbangkamehameha', 'kame', 'big-bang-kamehameha'])
    const PUPPET_ALIASES = new Set(['puppetstrings', 'puppet-strings', 'puppet', 'puppetry', 'strings', 'marionette'])
    const KURAMA_ALIASES = new Set(['kurama', 'baryon', 'kuramamode', 'ninetails', 'bijuu', 'krm'])
    const TIMESTOP_ALIASES = new Set(['timestop', 'time-stop', 'tms', 'stoptime'])
    const KUROHITSUGI_ALIASES = new Set(['kurohitsugi', 'kuro', 'blackcoffin', 'black-coffin', 'coffin', 'hado90'])
    const HOUGYOKU_ALIASES = new Set(['hougyoku', 'hogyoku', 'transcend', 'transcendence', 'the-one-above-all'])
    const GREED_ALIASES = new Set(['greed', 'tithe', 'greedgrab', 'gospel', 'gospelofgreed', 'witchs-grasp', 'stealgreed'])
    // The Heroes' own actions, reachable from inside the duel as well as from
    // the top-level .sword / .endworld commands (which delegate here). Both go
    // through runPvpTurn like every other signature move, so a wager duel refuses
    // them, the turn flips, and the result is written into the same battle
    // message every other move lands in.
    const SWORD_ALIASES = new Set(['sword', 'absolutesword', 'absolute-sword', 'swordmaiden'])
    const ENDWORLD_ALIASES = new Set(['endworld', 'end-world', 'endofworld', 'worldend'])
    const GARDEN_ALIASES = new Set(['garden'])
    // Cid Kagenou's I Am Atomic. Duels used to refuse it outright ("not
    // available in duels yet"), which left Cid's one combat move dungeon-only.
    const ATOMIC_ALIASES = new Set(['atomic', 'iamatomic', 'i-am-atomic'])
    // Victoria Minayoko's Sanctum Victoriae.
    const VICTORY_ALIASES = new Set(['victory', 'sanctum', 'sanctumvictoriae'])
    // 🔱 Saber's Excalibur. Duels used to refuse it outright ("not available in
    // duels yet"), which left the most expensive character in the game with no
    // move in the only mode other players can watch. It now runs as a duel
    // action with the SAME gate as PvE (lib/starfall-kits.js armExcalibur: Saber
    // equipped, the sword in the weapon slot, once per fight) and the same flat
    // 3000 that ignores DEF. What it does not ignore is the person holding it
    // together: Serpent's Grace, the Wheel, the beast, shields, Mei's sustain,
    // cat form and a League Adventurer's resilience all still answer it below.
    // 🌋 Surtr. Her four skills share ONE action ('surtr'), exactly like the PvE
    // command and like the Queen of Fairies' spells: which skill it is arrives
    // as skillQuery. Every alias of every skill is a token here, so
    // `.pvp surtr flame`, `.pvp flame` and `.pvp colossus` all reach her —
    // except 'sword', which is Laevatain's alias and already belongs to Sword
    // Maiden in this file (that one stays hers; use `.pvp surtr laevatain`).
    const SURTR_SKILL_TOKENS = new Set([
      'laevatain', 'lae', 'flame', 'molten-giant', 'molten', 'giant', 'mg',
      "surtr's-flame", 'surtrsflame', 'surtr-flame', 'detonate', 'flameburst',
      'twilight', 'transform', 'awaken',
      'remnant-ash', 'remnantash', 'ash', 'revert', 'restore',
    ])
    const SURTR_ALIASES = new Set(['surtr', 'colossus', ...SURTR_SKILL_TOKENS])
    const EXCALIBUR_ALIASES = new Set([
      'excalibur', 'excaliber', 'exc', 'excal', 'saber',
      'swordofpromisedvictory', 'sword-of-promised-victory',
      'promisedvictory', 'promised-victory', 'sopv',
    ])
    // 🧚‍♀️ Queen of Fairies. Encore is the signature move; the ten Creative
    // Magic incantations share ONE action ('fairyspell') because everything
    // they have in common — the once-per-battle gate, the self half, the dodge
    // rules, the opponent write — is identical. Which spell it is arrives as
    // skillQuery, exactly like `.pvp skill <name>`.
    const FAIRY_ENCORE_ALIASES = new Set(['encore', 'fairyencore', 'fairy-encore'])
    const FAIRY_SPELL_ALIASES = new Set(
      FAIRY_SPELLS.flatMap(s => [s.command, ...(s.aliases ?? [])]),
    )
    if (sub === 'attack' || sub === 'skill' || sub === 'defend' || sub === 'ability' || BEND_ALIASES.has(sub) || SURTR_ALIASES.has(sub) || FAIRY_ENCORE_ALIASES.has(sub) || FAIRY_SPELL_ALIASES.has(sub) || CINDER_ALIASES.has(sub) || BLAZEHEART_ALIASES.has(sub) || ULTIMATE_ALIASES.has(sub) || WILDCARD_ALIASES.has(sub) || DOMAIN_ALIASES.has(sub) || THIEFSEYE_ALIASES.has(sub) || HOLLOW_ALIASES.has(sub) || HOLLOWPURPLE_ALIASES.has(sub) || UNLIMITEDVOID_ALIASES.has(sub) || SOULPUNISHER_ALIASES.has(sub) || KAMEHAMEHA_ALIASES.has(sub) || PUPPET_ALIASES.has(sub) || KURAMA_ALIASES.has(sub) || TIMESTOP_ALIASES.has(sub) || KUROHITSUGI_ALIASES.has(sub) || HOUGYOKU_ALIASES.has(sub) || GREED_ALIASES.has(sub) || SWORD_ALIASES.has(sub) || ENDWORLD_ALIASES.has(sub) || GARDEN_ALIASES.has(sub) || ATOMIC_ALIASES.has(sub) || VICTORY_ALIASES.has(sub) || EXCALIBUR_ALIASES.has(sub)) {
      if (!inPvp(player)) {
        return ctx.reply(`❌ You're not in a duel. Challenge someone: *${pr}pvp @target*`)
      }
      if (!player.battleState.myTurn) {
        const waited = idleMs(player.battleState)
        return ctx.reply(
          `⏳ It's not your turn yet — wait for your opponent to move.\n` +
          (waited >= TURN_TIMEOUT_MS
            ? `_They've stalled for ${formatDuration(waited)}. Take the win with *${pr}pvp claim*._`
            : `_Stalling? You can claim the win after ${formatDuration(TURN_TIMEOUT_MS - waited)} of silence._`),
        )
      }
      if (BEND_ALIASES.has(sub)) {
        if (!hasAffinity(player)) {
          return ctx.reply(`🐢 You haven't awakened an Elemental Affinity yet! Run *${pr}affinity* at Level 60+.`)
        }
        const reqEl = normalizeAffinityId(args[1])
        if (reqEl && !hasAffinity(player, reqEl)) {
          return ctx.reply(`🚫 You do not possess *${getElementDef(reqEl).name}*!`)
        }
        if (player.battleState.affinityBendUsed) {
          return ctx.reply(`🌀 You have already unleashed *${pr}bend* in this duel!`)
        }
        if ((player.mp ?? 0) < PVP_BEND_MP_COST) {
          return ctx.reply(`💧 Need *${PVP_BEND_MP_COST} MP* to channel *${pr}bend* in PvP _(You have ${player.mp ?? 0} MP)_.`)
        }
        return runPvpTurn(ctx, 'skill', `__pvpBend:${reqEl ?? ''}`)
      }
      const resolvedAction = SURTR_ALIASES.has(sub)
        ? 'surtr'
        : EXCALIBUR_ALIASES.has(sub)
        ? 'excalibur'
        : FAIRY_ENCORE_ALIASES.has(sub)
        ? 'encore'
        : FAIRY_SPELL_ALIASES.has(sub)
        ? 'fairyspell'
        : VICTORY_ALIASES.has(sub)
        ? 'victory'
        : ATOMIC_ALIASES.has(sub)
        ? 'atomic'
        : CINDER_ALIASES.has(sub)
        ? 'cinderverdict'
        : BLAZEHEART_ALIASES.has(sub)
        ? 'blazeheart'
        : ULTIMATE_ALIASES.has(sub)
          ? 'ultimate'
          : WILDCARD_ALIASES.has(sub)
            ? 'wildcard'
            : DOMAIN_ALIASES.has(sub)
              ? 'domain'
              : THIEFSEYE_ALIASES.has(sub)
                ? 'thiefseye'
                : HOLLOW_ALIASES.has(sub)
                  ? 'hollowexchange'
                  : HOLLOWPURPLE_ALIASES.has(sub)
                    ? 'hollowpurple'
                    : UNLIMITEDVOID_ALIASES.has(sub)
                      ? 'unlimitedvoid'
                      : SOULPUNISHER_ALIASES.has(sub)
                        ? 'soulpunisher'
                        : KAMEHAMEHA_ALIASES.has(sub)
                          ? 'kamehameha'
                          : PUPPET_ALIASES.has(sub)
                            ? 'puppetstrings'
                            : KURAMA_ALIASES.has(sub)
                              ? 'kurama'
                              : TIMESTOP_ALIASES.has(sub)
                                ? 'timestop'
                                : KUROHITSUGI_ALIASES.has(sub)
                                  ? 'kurohitsugi'
                            : HOUGYOKU_ALIASES.has(sub)
                              ? 'hougyoku'
                              : GREED_ALIASES.has(sub)
                                ? 'greedtithe'
                                : SWORD_ALIASES.has(sub)
                                  ? 'sword'
                                  : ENDWORLD_ALIASES.has(sub)
                                    ? 'endworld'
                                  : GARDEN_ALIASES.has(sub) ? 'garden'
                                    : sub
      return runPvpTurn(
        ctx,
        resolvedAction,
        resolvedAction === 'fairyspell' ? sub
          : resolvedAction === 'surtr'
            ? (SURTR_SKILL_TOKENS.has(sub) ? sub : args.slice(1).join(' '))
            : args.slice(1).join(' '),
      )
    }

    // ── CHALLENGE (default), and its WAGER variant ────────────────────────
    if (inPvp(player)) {
      return ctx.reply(
        isWagerState(player.battleState)
          ? `❌ You're already in a wager duel. *${pr}pvp status* for the board, *${pr}pvp forfeit* to concede _(you lose the stake)_.`
          : `❌ You're already in a duel. Use *${pr}pvp moves* to see your options, or *${pr}pvp forfeit* to concede.`,
      )
    }

    // A wager challenge is the same challenge with a stake attached, so it runs
    // the identical path below (daily slots, group gate, target-busy checks) and
    // only shifts where the target token sits: `pvp wager 5k @them`.
    const isWagerChallenge = WAGER_ALIASES.has(sub)
    // `.pvp @them castle`, `.pvp wager 5k @them dead forest`: the arena word is
    // taken out first so the stake and target keep the positions they always had.
    const { arena: chosenArena, rest: cargs } = extractArena(args)
    let wagerAmount = 0
    if (isWagerChallenge) {
      const purse = player.wallet?.solars ?? 0
      wagerAmount = parseStake(cargs[1], purse) ?? 0
      if (!wagerAmount) {
        return ctx.reply(
          `❓ Usage: *${pr}pvp wager <amount> @target*\n` +
          `_Example:_ *${pr}pvp wager 5k @them* _· "all" stakes your whole purse._\n\n` +
          `☀️ Your purse: *${purse.toLocaleString()}* solars`,
        )
      }
      if (wagerAmount < WAGER_MIN_STAKE) {
        return ctx.reply(`❌ Minimum stake is *${WAGER_MIN_STAKE.toLocaleString()}* solars.`)
      }
      if (purse < wagerAmount) {
        return ctx.reply(
          `☀️ *Not enough solars.* You staked *${wagerAmount.toLocaleString()}* but hold *${purse.toLocaleString()}*.\n` +
          `_Gems and vault balances cannot be wagered._`,
        )
      }
    }

    // `rematch` reuses the whole challenge path below — it only substitutes
    // the target, so daily slots, group gates and busy checks all still apply.
    const isRematch = sub === 'rematch' || sub === 'again'
    if (isRematch && !player.pvp?.lastOpponentJid) {
      return ctx.reply(`❌ You haven't finished a duel yet — nobody to rematch.`)
    }
    const targetJid = isRematch
      ? player.pvp.lastOpponentJid
      : resolveTargetJid(ctx, isWagerChallenge ? cargs[2] : cargs[0])
    if (!targetJid) {
      // A typed @handle the bot has never seen is NOT "you forgot to name
      // anyone" — saying that to someone who tagged a person reads like the
      // command is broken, which is exactly how this bug was reported. Tell them
      // what happened and give them the two forms that always resolve.
      const typedHandle = (isWagerChallenge ? cargs[2] : cargs[0]) ?? ''
      if (ctx.platform === 'telegram' && /^@\w{2,}$/.test(typedHandle)) {
        return ctx.reply(
          `❔ *I couldn't find ${typedHandle} yet.*\n\n` +
          `_Telegram doesn't tell the bot who a typed @name is until that person has sent a message here. ` +
          `Reply to their message or tap their name from the member list instead._\n\n` +
          `👉 *Reply to a message of theirs with* *${pr}pvp*`,
        )
      }
      return ctx.reply(
        isWagerChallenge
          ? `❓ Usage: *${pr}pvp wager ${wagerAmount} @target* — reply to or @mention who you want to stake against.`
          : `❓ Usage: *${pr}pvp @target* — reply to or @mention who you want to duel.\n_Pick the battlefield too: *${pr}pvp @target castle* · see *${pr}pvp arenas*_`,
      )
    }
    if (targetJid === ctx.from) return ctx.reply(`❌ You can't duel yourself.`)
    if (!playerExists(db, targetJid)) return ctx.reply(`❌ That player isn't registered yet.`)
    if (player.inDungeon) return ctx.reply(`🗺️ Exit the dungeon first. Use *${pr}dungeon leave*.`)

    // ── Astral League fixture ─────────────────────────────────────────────
    // A fixture is compulsory, so a seat locked into one cannot start a second
    // fight, and its opponent cannot be pulled out of it either. The ordinary
    // `inBattle` check below already refuses both, but it says "already in a
    // battle", which reads like a bug to someone who knows they have a fixture
    // on the calendar today. This is the same refusal with the right reason.
    if (inLeagueFixture(db, ctx.from)) {
      return ctx.reply(
        `🏟️ *You have a League fixture live right now.*\n\n` +
        `_Finish it with *${config.prefix}battle atk* before duelling anyone else. It is on the calendar, so it cannot be walked away from._`,
      )
    }
    if (inLeagueFixture(db, targetJid)) {
      return ctx.reply(`🏟️ *That player is in a League fixture right now.*\n\n_Try them once it is settled._`)
    }

    // ── GUILD CLASH? The two champions the bot paired this clash fight each other
    // with a plain challenge. It does not use up a daily duel (the bot picked the
    // fight, the player did not choose to spend a slot on it), and in a group with
    // PvP off it is the only duel allowed. A wager is never a clash match.
    const clashFound = isWagerChallenge ? null : findOpenClashMatch(db, ctx.from, targetJid)
    if (clashOnlyHere && !clashFound) return pvpOffReply()

    const perks = perksFor(db, player)
    const remaining = pvpChallengesRemaining(player, perks.duelSlots)
    if (remaining <= 0 && !clashFound) {
      const limit = pvpChallengeLimit(player, perks.duelSlots)
      return ctx.reply(
        `⏳ You've used all *${limit}* of your duel challenges today.\n` +
        (perks.duelSlots > 0 ? `_(includes +${perks.duelSlots} from your ${perks.tier.name})_\n` : '') +
        (isPremiumActive(player)
          ? `_Come back tomorrow for ${limit} more._`
          : `_Premium members get *${PREMIUM_DAILY_PVP_LIMIT}* duels a day instead of *${FREE_DAILY_PVP_LIMIT}* — check *${pr}premium*._`) +
        (perks.duelSlots === 0 ? `\n_A guild hall grants extra slots too — see *${pr}guild perks*._` : ''),
      )
    }

    const target = getPlayer(db, targetJid)
    if (isWagerChallenge) { const refusal = wagerFundingRefusal(player, target, wagerAmount); if (refusal) return ctx.reply(refusal) }
    if (target.inBattle) return ctx.reply(`⚔️ *${target.name}* is already in a battle.`)
    if (target.inDungeon) return ctx.reply(`🗺️ *${target.name}* is deep in a dungeon right now.`)
    if (target.pvpChallenge && Date.now() < target.pvpChallenge.expiresAt) {
      return ctx.reply(`⏳ *${target.name}* already has a pending duel challenge.`)
    }
    // Checked here as a courtesy, and AGAIN at accept where the escrow actually
    // happens. Both checks are needed: this one stops a challenge nobody can
    // answer, and the one at accept is the one that is authoritative, because
    // either side can spend their purse during the two minutes in between.
    if (isWagerChallenge && (target.wallet?.solars ?? 0) < wagerAmount) {
      return ctx.reply(
        `☀️ *${target.name}* only holds *${(target.wallet?.solars ?? 0).toLocaleString()}* solars, ` +
        `so they cannot cover a *${wagerAmount.toLocaleString()}* stake.\n_Name a smaller number._`,
      )
    }

    await updatePlayer(db, targetJid, (t) => {
      t.pvpChallenge = {
        fromJid: ctx.from,
        expiresAt: Date.now() + CHALLENGE_TIMEOUT_MS,
        // 0 on a normal challenge, which is what the accept path branches on.
        wagerAmount,
        // The arena the challenger named, copied onto both battleStates at accept.
        ...(chosenArena ? { arena: chosenArena } : {}),
        // Only on a Guild Clash match: the group gate lets the accepter through
        // a group with PvP off on the strength of this stamp.
        ...(clashFound ? { clashId: clashKey(clashFound) } : {}),
      }
    })

    let remainingAfter = 0
    await updatePlayer(db, ctx.from, (p) => {
      if (!clashFound) consumePvpChallenge(p)
      remainingAfter = pvpChallengesRemaining(p, perks.duelSlots)
    })

    const arenaLine = chosenArena
      ? `🏟️ *Arena:* ${PVP_ARENAS[chosenArena].name}\n\n`
      : `_🏟️ Pick the battlefield: *${pr}pvp @name castle* · *${pr}pvp arenas*_\n\n`
    // With a named arena the challenge goes out as a picture of that arena.
    // A challenge is a question, so it arrives as one: ✅ Accept / ❌ Decline
    // are buttons on the challenge card. Each `data` is `c:pvp accept`, i.e.
    // the exact command the text already tells them to type — a button can
    // never mean something the typed version does not.
    const answerButtons = [
      [
        { text: '✅ Accept', data: 'c:pvp accept' },
        { text: '❌ Decline', data: 'c:pvp decline' },
      ],
    ]

    const announce = (text) => {
      if (chosenArena) return replyWithPanel(ctx, () => renderArenaPreview(chosenArena), text)
      // Platforms without inline keyboards keep the typed instructions that
      // are already in `text`.
      if (typeof ctx.replyWithButtons === 'function') return ctx.replyWithButtons(text, answerButtons)
      return ctx.reply(text)
    }

    if (isWagerChallenge) {
      return announce(
        `💰🔥 *WAGER CHALLENGE!* 🔥💰\n\n` +
        `⚔️ *${player.name}* stakes *☀️ ${wagerAmount.toLocaleString()} solars* against *${target.name}*!\n\n` +
        `❤️ ${player.name}: ${player.hp}/${player.maxHp}   ❤️ ${target.name}: ${target.hp}/${target.maxHp}\n\n` +
        `📜 *WAGER RULES*\n` +
        `• No turns. Either fighter may swing at any moment.\n` +
        `• 2 second cooldown between your own moves.\n` +
        `• You cannot use the same move twice in a row.\n` +
        `• No character powers. Raw stats, skills and items only.\n` +
        `• The loser pays the *full* stake. Both stakes are held the moment this is accepted.\n\n` +
        arenaLine +
        `*${target.name}*, answer with *${pr}pvp accept* or *${pr}pvp decline* within 2 minutes.\n` +
        `_Pack your kit first: *${pr}pvp inv* · *${pr}pvp stock <item>*_\n\n` +
        `_🥊 Duel challenges left today: ${remainingAfter}_`,
      )
    }

    return announce(
      (isRematch ? `🔁 *REMATCH!*\n\n` : '') +
      `⚔️ *${player.name}* challenges *${target.name}* to a duel!\n\n` +
      `❤️ ${player.name}: ${player.hp}/${player.maxHp}   ❤️ ${target.name}: ${target.hp}/${target.maxHp}\n\n` +
      arenaLine +
      `*${target.name}*, use *${pr}pvp accept* or *${pr}pvp decline* within 2 minutes.\n` +
      `_Size them up first — reply to their message with *${pr}scout*._\n\n` +
      (clashFound
        ? clashChallengeLine(clashFound)
        : `_🥊 Duel challenges left today: ${remainingAfter}_`),
    )
  },
}

/**
 * showMoves — every move available this turn, each tagged usable or not.
 *
 * This is the fix for the single most annoying thing about duelling over
 * chat: `.pvp skill <name>` demands a name the player cannot see, so they
 * guessed, ate "you don't know that skill", and lost tempo to a typo. The
 * costs and cooldowns printed here are read off the live battleState, so
 * what it says is usable really is usable.
 */
async function showMoves(ctx) {
  const { player, db } = ctx
  const pr = config.prefix
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel. Challenge someone: *${pr}pvp @target*`)
  }
  // A wager duel has a different move list (no abilities at all, PP instead of
  // cooldowns, item actions that cost no turn), so it gets its own panel rather
  // than a moveOptions() list half of which would be a lie here.
  if (isWagerState(player.battleState)) return showWagerMoves(ctx)
  const opponentJid = player.battleState.opponentJid
  const opponent = playerExists(db, opponentJid) ? getPlayer(db, opponentJid) : null
  if (!opponent) return ctx.reply(`❌ Your opponent is no longer registered.`)

  const knownSkills = (player.skills ?? [])
    .map(id => allSkills.find(s => s.id === id))
    .filter(Boolean)
  const equipped = (player.equippedAbilities ?? []).map(getAbilityDef).filter(Boolean)
  const moves = moveOptions(player, knownSkills, equipped, player.battleState.turn ?? 1)

  const KIND_ICON = { attack: '⚔️', skill: '✨', ability: '🌟', passive: '🔸', defend: '🛡️' }
  const lines = moves.map((m) => {
    const mark = m.usable ? '✅' : '⛔'
    const how = m.kind === 'skill' ? `${pr}pvp skill ${m.name}`
      : m.kind === 'ability' ? `${pr}pvp ability ${m.name}`
      : m.kind === 'defend' ? `${pr}pvp defend`
      : m.kind === 'attack' ? `${pr}pvp attack`
      : null
    return `${mark} ${KIND_ICON[m.kind] ?? '•'} *${m.name}* — _${m.note}_` +
      (how ? `\n    \`${how}\`` : '')
  })

  if (hasAudrey(player)) {
    const used = !!player.battleState?.justiceOfTheMind?.used
    lines.push(
      `${used ? '👁️' : '✅'} 👁️ *Justice of the Mind* — _${used ? 'read the open page' : 'one counter per duel'}_` +
      `\n    \`${pr}spectate\``,
    )
  }

  // Circe's Wild Card isn't in moveOptions() (that lives in lib/pvp-engine.js
  // and only knows skills/abilities/attack/defend), but unlike Cinder Verdict
  // it's a limited resource the player needs to be able to count mid-duel — so
  // it gets appended here when she's the equipped character.
  if (hasCirce(player)) {
    const left = wildCardUsesLeft(player)
    lines.push(
      `${left > 0 ? '✅' : '⛔'} 🃏 *Wild Card* — _one of six fates, no MP · ${left}/${WILD_CARD_MAX_USES} draws left_` +
      `\n    \`${pr}pvp wildcard\``,
    )
  }

  // Saber's Excalibur, for the same reason as Wild Card: it is not in
  // moveOptions(), it is once per duel, and its two requirements (Saber
  // equipped, the sword in the weapon slot) are exactly what a player forgets
  // mid-fight. A Saber owner whose sword is in the bag is told why, not left to
  // guess.
  if (hasSaberEquipped(player) || hasExcaliburEquipped(player)) {
    const spent = Boolean(player.battleState.starfallKit?.excaliburUsed)
    const armed = hasSaberEquipped(player) && hasExcaliburEquipped(player)
    const note = spent
      ? 'already drawn this duel'
      : !hasSaberEquipped(player)
        ? 'the sword alone is just a sword — Saber has to be the one holding it'
        : !hasExcaliburEquipped(player)
          ? 'Excalibur must be in your weapon slot'
          : `once per duel · no MP · ${EXCALIBUR_DAMAGE.toLocaleString()} flat, DEF never applies`
    lines.push(
      `${!spent && armed ? '✅' : '⛔'} 🔱 *Excalibur* — _${note}_\n    \`${pr}pvp excalibur\``,
    )
  }

  // Sword Maiden's Absolute Sword uses its normal MP costs in PvP. Other
  // completed turns build charge; a .sword technique spends charge and MP,
  // consumes the turn, and cannot recharge itself. The armed states are spelled
  // out here because all three of them are invisible on the board: a sword drawn
  // out of nowhere, a riposte waiting for one specific kind of hit, and a
  // once-per-duel finisher. A player who cannot see them cannot tell them apart
  // from a command that did nothing.
  if (player.equippedCharacter === 'sword_maiden') {
    const swordState = player.battleState.witchHeroes ?? {}
    const charge = swordState.charge ?? 0
    lines.push(
      `⚔️🔋 *ABSOLUTE SWORD* — _charge ${'▰'.repeat(charge)}${'▱'.repeat(Math.max(0, SWORD_CHARGE_MAX - charge))} *${charge}/${SWORD_CHARGE_MAX}*; ` +
      `+1 after each completed non-sword PvP turn. A .sword technique spends both charge and MP, uses your turn, and does not recharge itself._`,
    )
    for (const [key, skill] of Object.entries(SWORD_SKILLS)) {
      const cost = Math.ceil(Math.max(1, player.maxMp ?? 1) * skill.mp)
      const alreadyUsed = (key === 'transcended' && swordState.transcended) ||
        (key === 'return' && swordState.returnStroke) ||
        (key === 'coordinate' && swordState.coordinateUsed)
      const ready = !alreadyUsed && charge >= skill.charge && (player.mp ?? 0) >= cost
      const note = alreadyUsed
        ? (key === 'coordinate'
            ? '🎯 already spent this duel'
            : key === 'transcended'
              ? `🌫️ DRAWN · ${pr}pvp defend releases it, it costs nothing to spend`
              : `🔁 ARMED · answers the next direct hit they land on you`)
        : `${skill.charge} charge · ${cost} MP`
      lines.push(`${ready ? '✅' : '⛔'} ${skill.emoji} *${skill.name}* — _${note}_\n    \`.sword ${key}\``)
    }
  }

  if (player.equippedCharacter === 'alpha') {
    lines.push(`${canCallGarden(player).ok ? '✅' : '⛔'} 🌑 *Garden Call* — _after two turns · once per duel_\n    \`${pr}garden\``)
  }
  if (player.equippedCharacter === 'cid') {
    const atomicReady = !player.battleState.cidUsed
    lines.push(
      `${atomicReady ? '✅' : '⛔'} ☢️ *I Am Atomic* — _` +
      (atomicReady
        ? `once per duel · no MP · ${I_AM_ATOMIC_MULT}x strike, the flash costs them their next turn even on a miss, the overload costs you 10% of max HP`
        : 'already spent this duel') +
      `_\n    \`${pr}atomic\``,
    )
  }
  if (player.equippedCharacter === 'victoria_minayoko') {
    const s = sanctumState(player)
    const ready = s.state === 'ready'
    const note = s.state === 'up'
      ? `🛡️ standing · ${s.turnsLeft} turn${s.turnsLeft === 1 ? '' : 's'} left`
      : s.state === 'spent'
        ? 'already spent this duel'
        : s.state === 'charging'
          ? `charging · ready in ${s.turnsToReady} turn${s.turnsToReady === 1 ? '' : 's'} (turn ${SANCTUM_READY_AT_TURN})`
          : `ready · ${SANCTUM_TURNS} turns of absolute immunity`
    const sanctum = sanctumStatusLine(player, { prefix: pr })
    lines.push(
      `${ready ? '✅' : '⛔'} 🏛️ *Sanctum Victoriae* — _${note}_\n    \`${pr}victory\`` +
      (sanctum ? `\n    ${sanctum}` : ''),
    )
  }
  if (player.equippedCharacter === 'delta') {
    lines.push(`🔸 🐺 *Beast's Grudge* — _automatic: stores ${Math.round(GRUDGE_STORE_PCT * 100)}% of actual direct-hit damage; at ${GRUDGE_THRESHOLD.toLocaleString()}, returns the full meter and resets_\n    ${grudgeStatus(player)}`)
  }

  // Scarlett's My Desire and Ronova's End of the World, same reason: both are
  // budgets the holder has to be able to count mid-duel, and neither appears in
  // moveOptions() because neither is a move you can pick twice.
  if (player.equippedCharacter === 'scarlett') {
    lines.push(`${scarlettStatus(player)}\n    _She only turns a blow that actually lands. Nothing forces it: ${pr}pvp attack, ${pr}pvp defend, ask her when it is ready._`)
  }
  if (player.equippedCharacter === 'ronova') {
    lines.push(`${endworldStatus(player)}${player.battleState.witchHeroes?.endworld ? '' : `\n    \`${pr}endworld\``}`)
  }


  // Gogeta's two actives, appended for the same reason: neither is in
  // moveOptions(), and both are things the player has to be able to count
  // mid-duel — a turn cooldown each, a full energy bar on the ultimate, and a
  // fusion clock over the top of it that takes the ultimate away for good when
  // it runs out. Odds are never printed anywhere in his kit, but timers are.
  if (hasGogeta(player)) {
    const cd = gogetaCooldowns(player, player.battleState)
    const fuse = fusionTurnsLeft(player, player.battleState)
    const broken = !!player.battleState.fusionBroken
    const needed = Math.max(1, Math.ceil(player.maxMp ?? 0))
    const bbkReady = cd.kamehameha === 0 && (player.mp ?? 0) >= needed && !broken
    lines.push(
      `${cd.soulPunisher === 0 ? '✅' : '⛔'} 🔵 *Soul Punisher* — _ranged ki, no MP · ` +
      `${cd.soulPunisher === 0 ? 'ready' : `${cd.soulPunisher}t cooldown`}_` +
      `\n    \`${pr}pvp soulpunisher\``,
    )
    lines.push(
      `${bbkReady ? '✅' : '⛔'} 🔵💥 *Big Bang Kamehameha* — _ignores DEF · ` +
      (broken
        ? 'the fusion has broken, gone for this fight'
        : cd.kamehameha > 0
          ? `${cd.kamehameha}t cooldown`
          : bbkReady
            ? 'full bar, ready'
            : `needs a full bar: ${player.mp ?? 0}/${needed} MP`) +
      `_\n    \`${pr}pvp kamehameha\``,
    )
    if (fuse > 0) {
      lines.push(`🔸 🔵 *Fusion of Equals* — _+STR, +AGI · ${fuse} turn${fuse === 1 ? '' : 's'} left_`)
    }
  }

  // Rengoku's finisher and combo chain, and Minato's technique: neither is in
  // moveOptions(), and both are clocks the player has to be able to read
  // mid-duel (which move Blaze Heart opens on, when the next flash falls).
  // Each helper returns nothing for anyone without that character equipped.
  lines.push(...rengokuStatusLines(player, player.battleState, `${pr}pvp blaze-heart`))
  {
    const flashStatus = minatoStatusLine(player, player.battleState)
    if (flashStatus) lines.push(flashStatus)
    const trioStatus = trioBattleStatusLine(player, player.battleState, { prefix: pr })
    if (trioStatus) lines.push(trioStatus)
  }

  return ctx.reply(
    `🎯 *YOUR MOVES* — turn ${player.battleState.turn ?? 1}\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `${lines.join('\n')}\n\n` +
    `${suggestMove(player, opponent, moves)}\n\n` +
    (player.battleState.myTurn
      ? `_It's your turn — pick one._`
      : `_Waiting on *${opponent.name}*. Nothing you pick lands until they move._`),
  )
}

/** showStatus — the board, without spending a turn to see it. */
async function showStatus(ctx) {
  const { player, db } = ctx
  const pr = config.prefix
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel. Challenge someone: *${pr}pvp @target*`)
  }
  const opponentJid = player.battleState.opponentJid
  const opponent = playerExists(db, opponentJid) ? getPlayer(db, opponentJid) : null
  if (!opponent) return ctx.reply(`❌ Your opponent is no longer registered.`)

  // Wager mode has no turn to report and three things normal PvP has no concept
  // of (the cooldown, the blocked moves, gear durability), so it prints its own
  // board. Reading it is free: no cooldown bump, no repeat-window entry.
  if (isWagerState(player.battleState)) {
    return ctx.reply(wagerBoard(player, opponent, pr))
  }

  const mine = effectLine(player)
  const theirs = effectLine(opponent)
  const waited = idleMs(player.battleState)

  return ctx.reply(
    `🩸 *DUEL STATUS* — turn ${player.battleState.turn ?? 1}\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    statusBoard(player, opponent) + `\n\n` +
    (mine ? `🌀 You: ${mine}\n` : '') +
    (theirs ? `🌀 ${opponent.name}: ${theirs}\n` : '') +
    (player.battleState.defending ? `🛡️🔰 _You're braced: the next hit that lands on you is halved._\n` : '') +
    (opponent.battleState?.defending ? `🛡️ _${opponent.name} is braced too: your next hit on them is halved._\n` : '') +
    // What the Heroes kit is holding, on both sides, read straight off the same
    // battleState the duel itself uses. Read-only, like the rest of this panel.
    (witchTicker(player) ? `\n${witchTicker(player)}` : '') +
    (witchTicker(opponent) ? witchTicker(opponent) : '') +
    `\n${player.battleState.myTurn ? `▶️ *It's your turn.*` : `⏸️ Waiting on *${opponent.name}* _(${formatDuration(waited)} so far)_`}\n` +
    (!player.battleState.myTurn && waited >= TURN_TIMEOUT_MS
      ? `\n⌛ _They've timed out — *${pr}pvp claim* takes the win._`
      : '') +
    `\n_*${pr}pvp moves* for what you can do about it._`,
  )
}

/**
 * claimStale — the escape hatch for an abandoned duel.
 *
 * A duel writes `inBattle = true` to BOTH players and only pvpConclude()
 * clears it, so an opponent who simply walks away used to lock the other
 * player out of every inBattle-gated command with no way back. The timeout
 * is compared on read (no scheduler, survives restarts, can't fire against
 * someone mid-message) — see TURN_TIMEOUT_MS in lib/pvp-engine.js.
 */
async function claimStale(ctx) {
  const { player, db } = ctx
  const pr = config.prefix
  if (!inPvp(player)) return ctx.reply(`❌ You're not in a duel.`)

  const opponentJid = player.battleState.opponentJid

  // Opponent gone entirely — release this player rather than stranding them.
  if (!playerExists(db, opponentJid)) {
    // ── GUILD WAR pairing: the absent champion's opponent takes the point.
    // Settle the war FIRST — settleWalkover clears both fighters (Preset 5
    // and all) and drives the bracket on — before any ordinary duel cleanup.
    const warFound = findActiveWarMatchFor(db, ctx.from, opponentJid)
    if (warFound) {
      await settleWalkover(
        db, warFound.war, warFound.matchIdx, ctx.from, ctx,
        `_*The opposing champion is gone from the roster — the pairing is awarded on the spot.*_`,
      )
      return undefined
    }

    // A wager duel has real solars sitting in escrow on this player's own
    // battleState. Clearing the state without paying that back would delete
    // them, so the refund happens here, before the state is dropped.
    const stake = isWagerState(player.battleState) ? (player.battleState.wagerAmount ?? 0) : 0
    if (stake > 0) {
      return voidWagerDuel(db, ctx, ctx.from, opponentJid, 'Opponent missing — wager voided.', 'Missing opponent')
    }
    await clearBattle(db, ctx.from)
    return ctx.reply(`🧹 Your opponent no longer exists — duel cleared. You're free.`)
  }

  // ── Wager duels time out on silence, not on a turn ──────────────────────
  // Both sides carry myTurn: true in this mode, so the "it's your turn, you
  // can't claim on yourself" rule below has nothing to measure. The idle clock
  // is the only fair signal: whoever last touched the duel is still fighting.
  if (isWagerState(player.battleState)) {
    const idle = wagerIdleMs(player.battleState)
    const opp = getPlayer(db, opponentJid)
    if (idle < WAGER_IDLE_TIMEOUT_MS) {
      return ctx.reply(
        `⏳ The duel is still live — last move was ${formatDuration(idle)} ago.\n` +
        `_A wager duel is only claimable after ${formatDuration(WAGER_IDLE_TIMEOUT_MS)} of total silence._\n` +
        `_Swing instead: *${pr}pvp atk*._`,
      )
    }
    // Nobody moved for five minutes, including the claimant. Neither side wins
    // a stake off that, so both are refunded and the duel is voided.
    return voidWagerDuel(
      db, ctx, ctx.from, opponentJid,
      `⌛ *WAGER VOID* — nothing happened for ${formatDuration(idle)}.`,
      opp.name,
    )
  }

  if (player.battleState.myTurn) {
    return ctx.reply(
      `❌ It's *your* turn — you can't claim a timeout on yourself.\n` +
      `_Move with *${pr}pvp moves*, or concede with *${pr}pvp forfeit*._`,
    )
  }

  // ── Yu Miaoyi holds the baton: she does not stall (§4.3) ─────────────────
  // The only way her turn ever goes quiet is a restart mid-duel — her
  // auto-turns stamp lastMoveAt every flip, so a stale clock on her side means
  // the loop was severed, not that she idled. Resume her instead of handing
  // the claimant a win by silence; the idle timeout applies to the OPPONENT
  // only, exactly as specced.
  {
    const holder = getPlayer(db, opponentJid)
    if (isLucidBattle(holder)) {
      await ctx.reply(lucidRefusalLine(holder.battleState)).catch(() => {})
      const auto = await autoResolveCatFormTurns(db, ctx, ctx.from, opponentJid, { lead: '' })
      if (auto.concluded) return
      const a = getPlayer(db, ctx.from)
      const b = getPlayer(db, opponentJid)
      if (inPvp(a) && inPvp(b)) {
        return ctx.reply((auto.text.trim() ? auto.text.trim() + '\n' : '') + pvpStatusFooter(a, b))
      }
      return
    }
  }

  const waited = idleMs(player.battleState)
  if (!isStale(player.battleState)) {
    const opponent = getPlayer(db, opponentJid)
    return ctx.reply(
      `⏳ *${opponent.name}* still has time — they've been idle ${formatDuration(waited)}.\n` +
      `_You can claim the win after ${formatDuration(TURN_TIMEOUT_MS - waited)} more of silence._`,
    )
  }

  const opponent = getPlayer(db, opponentJid)
  // allowRewind: false — the loser here never took a fatal hit, they just
  // stopped answering. Rewinding would drag the claimant back into a duel
  // against someone who has already walked away, twice over.
  return pvpConclude(
    db, ctx.from, opponentJid, ctx,
    `_${opponent.name} stalled for ${formatDuration(waited)} and forfeits on time!_`,
    { allowRewind: false },
  )
}

/**
 * runPvpTurn — resolves exactly one player's move against their opponent.
 * Mirrors attack.js/skill.js/defend.js's per-turn structure (status ticks,
 * beast intervention at the same checkpoints, durability wear) but for two
 * real players instead of player-vs-monster.
 */
/**
 * Backstop on the loop below. Two Yoriichi owners can duel (she is `exclusive`,
 * not unique), so if both fall, both cat forms answer each other with no human
 * in the loop at all — that has to be bounded. It should never be reached: a
 * level-appropriate strike at CAT_FORM_ATTACK_MULT is a few hundred damage and
 * her pool is 3,000, so ~40 unanswered turns settles it many times
 * over. If it somehow is reached, the fight is left mid-duel and simply resumes
 * on the next command — the cap never decides a winner.
 */
const CAT_FORM_PVP_MAX_AUTO_TURNS = 40

/**
 * lucidDuelMove(holder, chosen) → { kind, query, power }
 *
 * Turns pickLucidAction()'s choice into exactly what runPvpTurn will accept on
 * the first try. A skill goes in by ID (findSkill() resolves a NAME to the
 * highest owned tier, which can be one the body cannot afford) and only once
 * the body really owns it and can pay its MP now; anything else becomes a
 * plain attack, which is always legal. Without this, a refused pick ended the
 * turn without moving the baton and the seeded chooser picked it again.
 */
export function lucidDuelMove(holder, chosen) {
  if (chosen?.kind === 'defend') return { kind: 'defend', query: '', power: false }
  if (chosen?.kind === 'skill') {
    const def = chosen.skill?.id ? findSkill(chosen.skill.id, holder?.skills ?? [], allSkills) : null
    if (def && def.id === chosen.skill.id && (holder?.mp ?? 0) >= (def.mpCost ?? 0)) {
      return { kind: 'skill', query: def.id, power: Boolean(chosen.power) }
    }
  }
  return { kind: 'attack', query: '', power: false }
}

/** True when a driven turn left the possessed holder exactly where it started. */
function lucidTurnStalled(holderAfter, turnBefore) {
  const bs = holderAfter?.battleState
  return Boolean(bs?.myTurn) && (bs.turn ?? 1) === turnBefore
}

/**
 * autoResolveCatFormTurns(db, ctx, aJid, bJid, { lead }) -> { text, concluded }
 *
 * The whole point of Yoriichi's rebuild, PvP side: the moment the turn baton
 * lands on a player she is fighting for, SHE TAKES IT. The owner is unconscious.
 * They do not get the turn, they are not asked for a move, and they are never
 * told the turn is theirs.
 *
 * Call this immediately after any flip of `battleState.myTurn`. It looks at who
 * actually holds the baton, and while that side has cat form active it resolves
 * her attack, hands the baton straight back to the other side, and looks again.
 * The loop is what handles both-sides-in-cat-form: they trade blows until one
 * pool empties, with nobody typing anything.
 *
 * YU MIAOYI rides the same loop (the two cannot coexist — one equipped
 * character per player, and cat form only runs for Yoriichi's owner): when the
 * baton lands on a possessed holder, her seeded AI picks a move and the REAL
 * turn pipeline (runPvpTurn) resolves it, frame and all. The opponent keeps
 * playing by hand; only her turns are automatic, and the idle clock applies to
 * the opponent alone.
 *
 * Returns concluded: true when the duel is over — pvpConclude() has already run
 * and replied, so the caller must return without sending anything else. On
 * concluded: false the caller appends `text` to its own message; `lead` is the
 * narration the caller has accumulated so far, needed here only so a duel that
 * ends inside the loop still shows the turn that ended it.
 *
 * Not called from pvpAccept(): a duel starts with both sides freshly healed and
 * a brand-new battleState, so cat form cannot already be up at the opening bell.
 */
async function autoResolveCatFormTurns(db, ctx, aJid, bJid, { lead = '' } = {}) {
  let text = ''

  for (let i = 0; i < CAT_FORM_PVP_MAX_AUTO_TURNS; i++) {
    const a = getPlayer(db, aJid)
    const b = getPlayer(db, bJid)
    if (!inPvp(a) || !inPvp(b)) return { text, concluded: true }

    // Read the baton rather than being told where it is — this is called from
    // three different flip sites and one refusal path.
    const holderJid = a.battleState.myTurn ? aJid : b.battleState.myTurn ? bJid : null
    if (!holderJid) return { text, concluded: false } // nobody holds it; a conclude is in flight
    const waiterJid = holderJid === aJid ? bJid : aJid
    const holder = holderJid === aJid ? a : b
    // Hard control spends the holder's turn immediately, before companion AI
    // or human input. Reuse the real turn pipeline so DOT, death, clocks and
    // one-turn effects behave exactly as they do on a submitted command.
    if (!hasMontana(holder) && ['stun', 'freeze', 'sleep'].some(type => hasEffect(holder, type))) {
      const result = await runPvpTurn(
        { ...ctx, from: holderJid, player: holder }, 'defend', '', { automaticPass: true },
      )
      if (!result || result.concluded) return { text, concluded: true }
      text += result.text
      continue
    }
    if (!isCatFormActive(holder)) {
      // ── Yu Miaoyi — the possessed holder answers for herself too ──────────
      // Same contract as the cat form below: the owner is asleep and never
      // gets the turn. Her move comes from the seeded fight AI over her
      // owner's real kit (pickLucidAction), her voice line posts first, and
      // the move itself runs through the REAL turn pipeline (runPvpTurn) so
      // DOT, clocks, shields, passives, turn boundaries and conclusion all
      // behave exactly as on a submitted command. The baton can only rest
      // here across a process restart (every flip re-enters this loop), and
      // both duelists cannot be possessed at once (one-of-one lock), so the
      // recursion this creates is at most two deep.
      if (isLucidBattle(holder)) {
        // ── Why this branch is shaped the way it is (2026-10-15) ────────────
        // Players reported "Yu Miaoyi spams comments in PvP and doesn't
        // actually do anything", and the send queue backed up behind it
        // ("Outbound Send Backlog Alert"). Three defects, all fixed here:
        //
        //  1. runPvpTurn's possession guard refused HER OWN driven turn. It
        //     could not tell this loop from the sleeping owner typing, so it
        //     posted a refusal and re-entered this loop, which posted another
        //     taunt and called runPvpTurn again: unbounded recursion, two
        //     messages per level, and no turn ever resolved. The driver now
        //     identifies itself (automaticPass + __lucidDriver) and the guard
        //     lets it through.
        //  2. The move went in by skill NAME. findSkill() resolves a name to
        //     the HIGHEST owned tier, so a cheaper tier she chose could come
        //     back as one she cannot pay for, fail validation, end without
        //     moving the baton, and be picked again (the pick is seeded per
        //     turn) up to the loop cap. lucidDuelMove() passes the skill id
        //     and checks the MP first.
        //  3. Nothing noticed a turn that did not move. A stall now retries
        //     once with a plain attack, then hands control back instead of
        //     looping. A cinematic still playing is waited out, not talked over.
        //
        // Her taunt rides at the top of the turn's own frame (__lucidLead)
        // instead of going out as a separate message first: one message per
        // turn instead of two.
        if (isBattleCinematicActive({ ...ctx, from: holderJid, player: holder })) return { text, concluded: false }
        const waiter = getPlayer(db, waiterJid)
        const chosen = await pickLucidAction(holder, holder.battleState, { foe: waiter })
        const move = lucidDuelMove(holder, chosen)
        if (move.power) {
          await updatePlayer(db, holderJid, (h) => { if (h.battleState) markLucidPowerUsed(h.battleState) })
        }
        const turnBefore = holder.battleState.turn ?? 1
        const driverCtx = { ...ctx, from: holderJid, player: holder, __lucidDriver: true }
        await runPvpTurn(
          { ...driverCtx, __lucidLead: lucidActionLine(holder.battleState, { power: move.power, defend: move.kind === 'defend' }) },
          move.kind, move.query, { automaticPass: true },
        )
        // Whatever runPvpTurn returned — a concluded duel, an incapacity pass,
        // or a normal turn that already rendered its own frame — the board is
        // the source of truth now: if either side is no longer in the duel the
        // fight is over; otherwise loop and read the baton again.
        let aAfter = getPlayer(db, aJid)
        let bAfter = getPlayer(db, bJid)
        if (!inPvp(aAfter) || !inPvp(bAfter)) return { text, concluded: true }
        if (lucidTurnStalled(getPlayer(db, holderJid), turnBefore)) {
          // A plain attack is legal for any body, so this is the one retry.
          await runPvpTurn({ ...driverCtx, player: getPlayer(db, holderJid) }, 'attack', '', { automaticPass: true })
          aAfter = getPlayer(db, aJid)
          bAfter = getPlayer(db, bJid)
          if (!inPvp(aAfter) || !inPvp(bAfter)) return { text, concluded: true }
          // Still stuck (a scene holding the board, a state this loop cannot
          // read): stop here. The next command from either duelist resumes her
          // through the possession guard or claimStale, so nothing is lost.
          if (lucidTurnStalled(getPlayer(db, holderJid), turnBefore)) return { text, concluded: false }
        }
        continue
      }
      return { text, concluded: false } // an able human's turn
    }


    // ── Her turn. Same read-fresh-snapshot / one-updatePlayer-at-a-time pattern
    // the rest of this file uses instead of nesting (see runPvpTurn's header).
    let turnText =
      `\n🐈‍⬛ *YORIICHI'S TURN* — _${holder.name} is down; she answers for them._\n`
    let opponentDefeated = false
    await updatePlayer(db, waiterJid, (opp) => {
      // isOpponentLive() treats an active cat form as still standing (their
      // owner-hp is pinned on purpose) — this only skips when there is genuinely
      // nothing left for the hit to land on.
      if (!isOpponentLive(opp)) {
        opponentDefeated = true
        return
      }
      // 🏛️ Her strike goes through no runPvpTurn door, so the Sanctum answers
      // it here: it lands on the Sanctum and is nullified like any other.
      if (sanctumShields(opp)) {
        turnText += sanctumNullifiedLine({ actorName: 'Yoriichi', moveLabel: 'a cat-form strike', holder: opp, turn: holder.battleState?.turn }) + '\n'
        return
      }
      // No skill, no MP, no owner input: resolveCatFormAction() takes an actor
      // and a target and nothing else. She picks her own move.
      const action = resolveCatFormAction(holder, opp, {
        damageSink: amount => applyIncomingDamage(opp, amount, null, true, {
          godHeartReaction: (defender, damage) => queueHeartReaction(defender, getPlayer(db, holderJid), damage),
        }),
      })
      turnText += action.message
      if (action.opponentDefeated) opponentDefeated = true
    })
    const reactions = getPlayer(db, waiterJid)?.battleState?.godReactionOutbox ?? []
    let reactionIds = [], holderDown = false
    if (reactions.length) {
      await updatePlayer(db, holderJid, h => {
        reactionIds = applyQueuedHeartReactions(h, waiterJid, reactions)
        holderDown = Boolean(h.battleState?.yoriichiCatFormDefeated) || godMortalDown(h)
      })
      await updatePlayer(db, waiterJid, w => acknowledgeHeartReactions(w, reactionIds))
    }
    text += turnText
    if (holderDown) {
      await pvpConclude(db, waiterJid, holderJid, ctx, (lead + text).trim())
      return { text, concluded: true }
    }

    if (opponentDefeated) {
      await pvpConclude(db, holderJid, waiterJid, ctx, (lead + text).trim())
      return { text, concluded: true }
    }

    // ── Baton straight back to the other side. It never rests on her owner.
    // lastMoveAt is stamped on both records as usual, which also means a
    // cat-form owner can no longer lose by `.pvp claim` (see claimStale) for
    // "not moving" while she is fighting for them.
    const movedAt = Date.now()
    await updatePlayer(db, holderJid, (h) => {
      if (!h.battleState) return
      chargeSwordTurn(h)
      h.battleState.myTurn = false
      h.battleState.turn = (h.battleState.turn ?? 1) + 1
      h.battleState.lastMoveAt = movedAt
    })
    await updatePlayer(db, waiterJid, (w) => {
      if (!w.battleState) return
      w.battleState.myTurn = true
      w.battleState.lastMoveAt = movedAt
    })
    // The duel-wide clock advances for her turn too: it is a completed turn of
    // the duel whether or not a human typed anything, and Ronova's countdown is
    // keyed on ids both sides agree about.
    const boundary = await resolveDuelTurnBoundary(db, holderJid, waiterJid)
    if (boundary.lines.length) text += boundary.lines.join('\n') + '\n'
    if (boundary.kill) {
      const winnerJid = boundary.kill === 'actor' ? waiterJid : holderJid
      const loserJid = boundary.kill === 'actor' ? holderJid : waiterJid
      await showEndworldClash(ctx, (lead + text).trim(), { participants: [holderJid, waiterJid] })
      await pvpConclude(db, winnerJid, loserJid, ctx,
        `☠️🌑 *THE END OF THE WORLD* lands while Yoriichi is fighting for them. _The beam does not care._`)
      return { text, concluded: true }
    }
  }

  // Cap hit — both sides are cat forms that refused to die. Nothing is decided;
  // say so plainly rather than inventing a result.
  return {
    text: text + `\n_Automatic turn limit reached. The duel goes on._\n`,
    concluded: false,
  }
}

/**
 * duelProxy(entity) — a DETACHED copy of the far side of a duel.
 *
 * The Heroes rules in lib/witch-heroes.js are written for one function to hold
 * both combatants (they read the attacker, wound the defender, clear a guard,
 * spend a charge). A duel cannot: every write has to go through its own
 * top-level updatePlayer() call, because the shared write queue deadlocks on a
 * nested one (see runPvpTurn's header). So the far side is handed over as a
 * stand-in, the rules mutate it harmlessly, and the adapter carries whatever the
 * return value said into that player's real write. Same trick
 * applyAbsoluteOneSiphon() plays with a throwaway actor proxy.
 */
function duelProxy(entity) {
  if (!entity) return null
  return {
    ...entity,
    battleState: { ...(entity.battleState ?? {}) },
    activeEffects: [...(entity.activeEffects ?? [])],
  }
}

/**
 * applyAbsoluteCut(target, damage) -> { damage, defeated, saved, message }
 *
 * The one place a duel spends an "absolute" hit (Sword Maiden's cuts, her
 * riposte, Scarlett's reflection). Absolute means what lib/witch-heroes.js says
 * it means: no accuracy roll, no DEF, no shield absorb, no beast redirect, no
 * fight-length cap, straight onto HP. It has never meant "past Yoriichi", and
 * every other hit path in this file redirects into her pool while she is up (see
 * the ability branch) because the owner's HP is a pinned 1 that nothing may be
 * measured against. Subtracting from that 1 instead is precisely the one-turn
 * death in duels this codebase already fixed once.
 */
function applyAbsoluteCut(target, damage) {
  if (!target || !(damage > 0)) return { damage: 0, defeated: false, saved: false, message: '' }
  const godHit = godLethalHit(target, damage)
  if (godHit) return { ...godHit, defeated: false, saved: true }
  // 🏛️ "Absolute" means past DEF, shields and dodges. It does not mean past the
  // Sanctum Victoriae, which is not a defence: harm simply does not land.
  if (sanctumShields(target)) return { damage: 0, defeated: false, saved: true, message: sanctumBreakLine(target) }
  if (rollUltraInstinctDodge(target, { damage })) return { damage: 0, defeated: false, saved: false, dodged: true, message: '💨 *Ultra Instinct!* Attack dodged.' }
  if (isCatFormActive(target)) {
    const res = resolveCatFormDamage(target, damage)
    return {
      damage: res.damage,
      defeated: res.defeated,
      saved: res.damage === 0,
      message: res.message + (res.defeated ? buildCatFormDefeatMessage() : ''),
    }
  }
  const previousHp = Math.max(0, Number(target.hp) || 0)
  target.hp = Math.max(0, previousHp - damage)
  const relic = applyStarterRelicsAfterDamage(target, previousHp)
  const relicMessage = relic.lines.join('\n')
  if (target.hp > 0) return { damage, defeated: false, saved: false, message: relicMessage }
  const catMsg = checkYoriichiCatForm(target)
  if (catMsg) return { damage, defeated: false, saved: true, message: [relicMessage, catMsg].filter(Boolean).join('\n') }
  return { damage, defeated: true, saved: false, message: relicMessage }
}

/** Texas's cut also ignores Yoriichi's dodge, without bypassing her HP pool. */
export function resolveTexasDuelFollowUp(owner, target, ownerDamage) {
  return applyNighOmni(owner, target, ownerDamage, {
    applyHit: damage => {
      const godHit = godLethalHit(target, damage)
      if (godHit) return { ...godHit, defeated: false, saved: true }
      // A generic ability writes the defender's body to 0 directly. Resolve that
      // existing death-save first, so Texas follows against the newly live pool
      // rather than merely summoning it with her own already-spent damage.
      const catEntrance = godMortalDown(target) && !isCatFormActive(target) ? checkYoriichiCatForm(target) : ''
      if (!isCatFormActive(target)) return applyAbsoluteCut(target, damage)
      // resolveCatFormDamage rolls dodge, so it is NOT an absolute writer.
      // Spend the exact number on the live pool instead; normal duel defeat
      // settlement still reads the same cat-form-defeated flag.
      const cat = target.battleState.yoriichiCatFormActive
      if (rollUltraInstinctDodge(target, { damage })) return { damage: 0, defeated: false, dodged: true, message: '💨 *Ultra Instinct!* Attack dodged.' }
      cat.hp = Math.max(0, cat.hp - damage)
      const defeated = cat.hp <= 0
      if (defeated) target.battleState.yoriichiCatFormDefeated = true
      return {
        defeated,
        message: [catEntrance, `🐈‍⬛ *Yoriichi* takes *${damage}* absolute damage! (${cat.hp}/${cat.maxHp} HP)` +
          (defeated ? '\n' + buildCatFormDefeatMessage() : '')].filter(Boolean).join('\n'),
      }
    },
  })
}

/**
 * resolveFlameComboDuel(owner, target, ownerDamage)
 *
 * Rengoku's Flame Breathing combo in a duel. Spent through applyAbsoluteCut(),
 * the same absolute HP writer Texas's follow-up and the Sword Maiden's cuts
 * use, so it answers to exactly what they answer to: the Sanctum nullifies it,
 * Ultra Instinct may dodge it, an active Yoriichi takes it into her own pool,
 * and a lethal combo still offers her death save. It is NOT run back through
 * DEF or the fight-length caps: it is a share of a hit that already paid both.
 *
 * A defender already at 0 HP is not followed (lib/rengoku.js refuses it), so
 * the main hit's own defeat / cat-form settlement runs exactly as it would
 * without him.
 */
export function resolveFlameComboDuel(owner, target, ownerDamage) {
  return applyFlameCombo(owner, target, ownerDamage, {
    applyHit: damage => applyAbsoluteCut(target, damage),
  })
}

/**
 * resolveDuelTurnBoundary(db, moverJid, waiterJid) — the duel-wide turn clock.
 *
 * lib/witch-heroes.js counts "completed battle turns" off a single id that both
 * participants agree on. A duel has no such field: battleState.turn is
 * per-player and counts only that player's own moves, which is why Ronova could
 * never reach five turns in a duel at all, and why her beam never fell.
 * `battleState.ply` is that shared id: mirrored onto BOTH records at every flip
 * (like gambitLog already is), monotonic, and bumped whether the turn was a
 * strike, a guard, a sword technique or a turn stolen by a stun.
 *
 * Returns { lines, kill } where kill is 'actor' | 'opponent' | null. A terminal
 * event (the beam landing) zeroes the loser here; the CALLER settles it exactly
 * once through pvpConclude, which is the only PvP ending in this file.
 */
async function resolveDuelTurnBoundary(db, moverJid, waiterJid) {
  const mover = getPlayer(db, moverJid)
  const waiter = getPlayer(db, waiterJid)
  if (!mover?.battleState || !waiter?.battleState) return { lines: [], kill: null }
  const ply = Math.max(Number(mover.battleState.ply) || 0, Number(waiter.battleState.ply) || 0) + 1

  let lines = []
  let kill = null
  let carriedHeroes = null
  let carriedBackground
  let carriedEndHit = null
  let carriedPureHp = null
  let carriedPureEffects = null
  await updatePlayer(db, moverJid, (actor) => {
    if (!actor.battleState) return
    actor.battleState.ply = ply
    const far = getPlayer(db, waiterJid)
    if (!far?.battleState) return
    const proxy = duelProxy(far)
    const events = completeTurn([actor, proxy], ply, { chargeSword: false })
    // An empty event list is the NORMAL case: completeTurn() only narrates the
    // Heroes countdown, so most fighters — The End among them — produce nothing
    // to say here. Returning early on that used to be read as "the turn had no
    // consequences", which silently skipped the End Monster below and made the
    // summon look broken in every duel that was not Ronova's (reported
    // 2026-10-31). Only the carry needs an event to exist, because it only
    // fires when the stand-in actually changed; the summon is owed every turn.
    if (events.length) {
      lines = events.map(e => e.text)
      // The far side's clock and background advanced on the stand-in: carry them
      // into their own write below rather than mutating them from in here.
      if (JSON.stringify(proxy.battleState.witchHeroes ?? null) !== JSON.stringify(far.battleState.witchHeroes ?? null)) {
        carriedHeroes = proxy.battleState.witchHeroes
      }
      if (proxy.battleState.cinematicBackground && proxy.battleState.cinematicBackground !== far.battleState.cinematicBackground) {
        carriedBackground = proxy.battleState.cinematicBackground
      }
      if (proxy.equippedCharacter === 'ronova' && proxy.hp !== far.hp) carriedPureHp = proxy.hp
      if (proxy.equippedCharacter === 'ronova' && JSON.stringify(proxy.activeEffects ?? []) !== JSON.stringify(far.activeEffects ?? [])) {
        carriedPureEffects = proxy.activeEffects ?? []
      }
    }
    if (!events.some(e => e.terminal) && endSummonEnabled(actor) && far.hp > 0 && actor.hp > 0) {
      const endProxy = duelProxy(far)
      carriedEndHit = applyEndMonsterTurn(actor, endProxy, {
        turnId: ply,
        applyHit: damage => ({ damage, defeated: false }),
      })
      if (carriedEndHit.triggered) lines.push(carriedEndHit.message)
    }
    const terminal = events.find(e => e.terminal)
    if (terminal) {
      // 🏛️ The End of the World is an ending, not a hit, but it is still harm,
      // and nothing harms anyone under the Sanctum Victoriae.
      const loserEntity = terminal.loser === actor ? actor : far
      if (sanctumShields(loserEntity)) {
        lines.push(`🏛️ *THE END OF THE WORLD* falls on *${loserEntity.name}* and breaks against the Sanctum like a wave on stone.`)
      } else if (terminal.loser === actor) {
        actor.hp = 0
        kill = 'actor'
      } else if (isMasterAdventurer(far)) {
        lines.push(`💨👑 *${far.name}*'s monster LCK and instincts step outside the beam's coordinate — *THE END OF THE WORLD* is dodged completely!`)
      } else if (isLeagueAdventurer(far) || far?.battleState?.league) {
        lines.push(`💨⚡ *${far.name}* dives through the edge of the coordinate — *THE END OF THE WORLD* is evaded!`)
      } else {
        kill = 'opponent'
      }
    }
  })

  if (carriedHeroes || carriedBackground || carriedEndHit?.triggered || carriedPureHp !== null || carriedPureEffects || kill === 'opponent') {
    await updatePlayer(db, waiterJid, (opp) => {
      if (!opp.battleState) return
      opp.battleState.ply = ply
      if (carriedHeroes) opp.battleState.witchHeroes = carriedHeroes
      if (carriedBackground) opp.battleState.cinematicBackground = carriedBackground
      if (carriedPureHp !== null && kill !== 'opponent') opp.hp = carriedPureHp
      if (carriedPureEffects && kill !== 'opponent') opp.activeEffects = carriedPureEffects
      if (carriedEndHit?.triggered && opp.hp > 0 && kill !== 'opponent') {
        if (carriedEndHit.empowered && Array.isArray(opp.activeEffects)) {
          const positive = new Set(['regen','shield','strengthen','haste','damage_boost','reflect'])
          const idx = opp.activeEffects.findIndex(e => positive.has(e.type) && (e.remaining ?? 1) > 0)
          if (idx >= 0) opp.activeEffects.splice(idx, 1)
        }
        const res = applyAbsoluteCut(opp, carriedEndHit.damage)
        if (res.message) lines.push(res.message)
        if (res.defeated) kill = 'opponent'
      }
      if (kill === 'opponent') opp.hp = 0
    })
  }
  return { lines, kill }
}

/**
 * witchTicker(entity) — one line, what the Heroes kit is doing right now.
 *
 * Every mechanic below is invisible by design until it fires: a charge counter,
 * a sword drawn out of nowhere, a guard waiting for one answer, three reflections
 * per battle. In a duel that reads as "I pressed the button and nothing
 * happened", which is the complaint these lines exist to end. Printed for both
 * sides in the turn footer, so both players can see what is armed against them.
 */
function witchTicker(entity) {
  // One implementation for both modes: lib/witch-heroes.js owns the line, the
  // dungeon bar and the duel footer print it, and a mechanic cannot look alive
  // in one and invisible in the other.
  const line = heroesTicker(entity)
  return line ? `${line}\n` : ''
}

// Exported for the Astral League: an Adventurer's stand in takes its turn
// through this same funnel, so a character move, the wager guard and the
// myTurn check behave identically for a scheduled fixture. This is the one
// funnel every duel turn goes through — see the header below.
/**
 * duelActionLabel(action, skillQuery) -> the human name of a refused move, or
 * null when this action has no special name.
 *
 * Only used by the two refusal paths (the King's grace and Victoria's Sanctum),
 * which print "⚔️ *<whatever> refused*" and "it broke against the Sanctum".
 * Those used to interpolate the raw router token, so the Queen's Encore read
 * "⚔️ *encore* refused" (a command, not a move) and a Creative Magic spell read
 * "⚔️ *fairyspell* refused" instead of naming the incantation the player
 * actually cast. Unknown actions return null so the caller keeps its own
 * fallback.
 */
function duelActionLabel(action, skillQuery) {
  if (action === 'excalibur') return 'Excalibur'
  if (action === 'encore') return 'Encore'
  if (action === 'fairyspell') {
    return fairySpellById(skillQuery)?.name ?? (skillQuery ? String(skillQuery) : 'a Creative Magic spell')
  }
  if (action === 'skill') return skillQuery ? String(skillQuery) : 'a skill'
  return null
}

export async function runPvpTurn(ctx, action, skillQuery, { automaticPass = false } = {}) {
  if (isBattleCinematicActive(ctx)) return
  if (action === 'dragonultimate') action = 'ultimate'
  else if (action === 'mahoraga') action = 'domain'
  else if (action === 'hogyoku') action = 'hougyoku'
  else if (action === 'ss') action = 'garden'
  const { db } = ctx
  const actorJid = ctx.from

  // ── Pre-flight checks + snapshot the actor (read-only, no lock held) ────
  // We deliberately do NOT nest updatePlayer(opponentJid, ...) inside
  // updatePlayer(actorJid, ...) below — updatePlayer() serializes every
  // call on one shared global queue (see lib/player-repo.js's writeQueue),
  // and a queued task only frees the queue once its mutatorFn resolves. A
  // nested call sits behind its own still-running outer call on that same
  // queue, so it can never run — every PvP turn deadlocked until the 20s
  // withTimeout ceiling fired and threw. Instead we run one updatePlayer
  // per player, sequentially, same top-level pattern pvpConclude uses,
  // and pass state between the two mutator calls via plain variables.
  const actorSnapshot = getPlayer(db, actorJid)
  // ── Wager mode never enters this function ───────────────────────────────
  // This is the ONE place the character layer is refused, and it is here rather
  // than at each of the twelve entry points (`.pvp attack`, `.cinderverdict`,
  // `.wildcard`, `.ultimate`, `.domain`, `.purple`, `.thiefseye`,
  // `.hollowexchange`, `.unlimitedvoid`, ...) because every one of them funnels
  // through runPvpTurn. A signature move added later cannot leak into a wager
  // duel by forgetting a guard, since there is only one guard to forget.
  if (isWagerState(actorSnapshot?.battleState)) {
    return ctx.reply(
      `🚫 *No character powers in a wager duel.*\n` +
      `_Raw stats, skills and your kit decide this one._\n\n` +
      `⚔️ *${config.prefix}pvp atk* · ✨ *${config.prefix}pvp sk <name>* · 🛡️ *${config.prefix}pvp def*\n` +
      `_Full board: *${config.prefix}pvp status*_`,
    )
  }
  // ── Yu Miaoyi — the possessed holder never takes commands (§3.3) ────────
  // Her owner is asleep; whatever they typed, the answer is a playful refusal
  // and her own turn, resolved by the auto-loop the same way Yoriichi's cat
  // form owns its owner's turn. If the baton is on the OPPONENT (e.g. right
  // after a restart mid-duel), the refusal still stands and the auto-loop
  // resolves nothing — her turn comes the moment the baton flips back, and
  // claimStale resumes her directly if she is the one holding it.
  // Her OWN driven turns (autoResolveCatFormTurns: automaticPass, and the
  // __lucidDriver marker on its ctx) are not the owner typing and must pass.
  // Refusing them is what made her loop forever posting lines (see the Yu
  // branch of autoResolveCatFormTurns).
  if (isLucidBattle(actorSnapshot) && !automaticPass && !ctx.__lucidDriver) {
    await ctx.reply(lucidRefusalLine(actorSnapshot.battleState)).catch(() => {})
    if (actorSnapshot.battleState.myTurn) {
      const oppJid = actorSnapshot.battleState.opponentJid
      if (playerExists(db, oppJid) && inPvp(getPlayer(db, oppJid))) {
        const auto = await autoResolveCatFormTurns(db, ctx, actorJid, oppJid, { lead: '' })
        if (auto.concluded) return
        const a = getPlayer(db, actorJid)
        const b = getPlayer(db, oppJid)
        if (inPvp(a) && inPvp(b)) await ctx.reply(auto.text.trim() + pvpStatusFooter(a, b)).catch(() => {})
      }
    }
    return
  }
  if (!inPvp(actorSnapshot) || !actorSnapshot.battleState.myTurn) {
    // Yu Miaoyi: the baton can only rest on her side across a process restart
    // or a Snapshot/Hypnosis rewind — every normal flip re-enters the
    // auto-loop. When that happens, the opponent's poke resumes her turn
    // instead of bouncing off a bare "not your turn", so the duel is never
    // left waiting on a player who is asleep.
    const holderJid = actorSnapshot.battleState?.opponentJid
    if (holderJid && playerExists(db, holderJid)) {
      const holder = getPlayer(db, holderJid)
      if (holder?.battleState?.myTurn && isLucidBattle(holder)) {
        await ctx.reply(lucidRefusalLine(holder.battleState)).catch(() => {})
        const auto = await autoResolveCatFormTurns(db, ctx, actorJid, holderJid, { lead: '' })
        if (auto.concluded) return
        const a = getPlayer(db, actorJid)
        const b = getPlayer(db, holderJid)
        if (inPvp(a) && inPvp(b)) {
          return ctx.reply((auto.text.trim() ? auto.text.trim() + '\n' : '') + pvpStatusFooter(a, b))
        }
        return
      }
    }
    return ctx.reply(`⏳ It's not your turn yet.`)
  }
  const opponentJid = actorSnapshot.battleState.opponentJid
  if (!playerExists(db, opponentJid)) {
    await updatePlayer(db, actorJid, (actor) => {
      // 🌋 Surtr — the walk-away path. Twilight's max HP and ATK go back with
      // the rest of the duel state.
      clearSurtrKit(actor, actor.battleState)
      actor.inBattle = false
      actor.battleState = null
      clearBeastEffects(actor)
    })
    return ctx.reply(`❌ Your opponent is no longer registered — duel cancelled.`)
  }

  // A crash can occur after the target's final transaction but before match
  // settlement. Resume the stored finale before spending another move or
  // allowing an ordinary death handler to offer a rewind of the last card.
  const pendingFinale = actorSnapshot.battleState.godPendingSummon
  if (pendingFinale?.spade && pendingFinale.opponentId === opponentJid) {
    let receipt = null
    let down = false
    await updatePlayer(db, opponentJid, target => {
      if (!inPvp(target) || target.battleState.opponentJid !== actorJid) return
      const receipts = target.battleState.godSummonReceipts ??= {}
      receipt = receipts[pendingFinale.id]
      if (!receipt) {
        const result = applyGodTargetEffects(target, pendingFinale, { pvp: true })
        receipt = { rebounds: result.rebounds, tithe: result.tithe }
        target.battleState.godSummonReceipts[pendingFinale.id] = receipt
      }
      down = godMortalDown(target)
    })
    if (!receipt) return
    await updatePlayer(db, actorJid, source => { creditSummonTithe(source, pendingFinale, receipt.tithe) })
    if (down) return pvpConclude(db, actorJid, opponentJid, ctx, pendingFinale.lines.join('\n'), { allowRewind: false })
    return ctx.reply('♠️ The final card cannot overrule this opponent’s protection.')
  }

  if (ownsGod(actorSnapshot, 'namidrek')) {
    let worldLines = []
    await updatePlayer(db, actorJid, async actor => {
      const opponent = getPlayer(db, opponentJid)
      if (actor.battleState?.opponentJid !== opponentJid || !inPvp(opponent)) return actor
      worldLines = await observeWorldIntervention({ owner: actor, enemy: opponent, turnId: actor.battleState.turn, mode: 'pvp' })
      return actor
    })
    if (worldLines.length) await ctx.reply(worldLines.join('\n'))
  }

  // ── 🧚‍♀️ Queen of Fairies — Encore ────────────────────────────────────────
  // A lock written onto THIS record by the other side's `.encore` (see the
  // opponent phase far below). It has to be resolved before the grace and
  // Sanctum gates, because those read `action` to decide whether the move is
  // offence — and "I refuse the encore" is not one of the choices. The forced
  // move is spent exactly like a typed one: MP, cooldowns, accuracy and the
  // defender's full mitigation all still apply. Encore never invents a move
  // the player does not have; the stored token is what they last used.
  const pendingEncore = fairyEncore(actorSnapshot.battleState)
  let encoreForced = false
  let encoreForcedLabel = ''
  if (pendingEncore) {
    const forced = pendingEncore.action ?? 'attack'
    const forcedSkill = pendingEncore.skillQuery ?? ''
    if (action !== forced || (forced === 'skill' && skillQuery !== forcedSkill)) {
      encoreForced = true
      encoreForcedLabel = pendingEncore.label
      action = forced
      skillQuery = forcedSkill
    }
  }

  // ── 👑 King Yato — Grace of the Crown: the locked side of a duel ──────────
  // Turns 1 to 5, the side standing opposite a grace cannot attack at all. It
  // is enforced HERE rather than in each attack command because this is the one
  // funnel every duel action passes through (see the wager-mode guard above for
  // the same reasoning): a signature move added next month cannot leak past a
  // lock that is default-blocked. Defence, fleeing and the kit stay open — the
  // grace forbids offence, it does not pause the fight — and an automatic pass
  // is never blocked, because refusing a forced pass would strand the baton.
  //
  // The window is counted on the locked side's OWN turns (graceAttackLocked):
  // their turns 1-5 are refused whichever duelist moved first. An automatic
  // move (a possessed body's AI, a forced pass) is not refused — that would
  // strand the baton — it is turned into a defend instead, so nothing on the
  // far side attacks during the window by any route.
  {
    const graceVictim = getPlayer(db, opponentJid)
    if (graceAttackLocked(actorSnapshot, graceVictim) && !GRACE_DUEL_ALLOWED_ACTIONS.has(action)) {
      if (!automaticPass) {
        return ctx.reply(
          graceCommandBlock(graceVictim, duelActionLabel(action, skillQuery) ?? action, actorSnapshot),
        )
      }
      action = 'defend'
      skillQuery = ''
    } else if (
      graceActive(graceVictim)
      && !graceAttackLocked(actorSnapshot, graceVictim)
      && gracePhase(graceVictim?.battleState) === 'lock'
    ) {
      // The challenger is on turn 6+ but the King moved second, so his own
      // counter still reads 5: release his half too, or the damage funnel
      // would quietly swallow a sixth turn of attacks.
      await updatePlayer(db, opponentJid, (o) => { if (o.battleState) o.battleState.graceReleased = true })
    }
  }

  // ── 🏛️ Victoria Minayoko — Sanctum Victoriae: the attacked side ──────────
  // While the Sanctum stands over the far side, anything the actor tries
  // except standing down, items and leaving hits the Sanctum and is nullified:
  // the turn is spent, the move does nothing. Decided HERE, at the one door
  // every duel action passes through, for the same reason the grace is above:
  // a signature move added next month cannot leak past a default-deny list.
  // Manual and automatic moves alike (a League stand-in, a possessed body):
  // the Sanctum does not care who is swinging. The move itself never runs, so
  // none of its riders (stuns, steals, poisons, possessions, instant kills)
  // can either.
  let sanctumFizzle = null
  {
    const sanctumHolder = getPlayer(db, opponentJid)
    if (action !== 'victory' && sanctumShields(sanctumHolder) && !SANCTUM_DUEL_ALLOWED_ACTIONS.has(action)) {
      const TRIED = {
        attack: 'an attack', ability: 'an ability', ultimate: 'Dragon Ultimate',
        endworld: 'The End of the World', sword: 'the Absolute Sword', garden: 'Garden Call',
      }
      sanctumFizzle = {
        holder: sanctumHolder,
        moveLabel: duelActionLabel(action, skillQuery)
          ?? TRIED[action] ?? characterMap[actorSnapshot?.equippedCharacter]?.ability?.name ?? action,
      }
    }
  }

  // Yu Miaoyi's taunt for a turn she is driving leads that turn's own frame
  // (see autoResolveCatFormTurns) instead of costing a message of its own.
  let msg = ctx.__lucidLead ? `${ctx.__lucidLead}\n` : ''
  let hpBeforeTurn = 0
  let opponentDefeated = false
  let selfDefeated = false
  function receiveOpponentHit(target, damage, override = null, directHit = true, info = {}) {
    return applyIncomingDamage(target, damage, override, directHit, { ...info,
      godHeartReaction: (defender, amount) => queueHeartReaction(defender, getPlayer(db, actorJid), amount, { directHit, origin: info.origin }),
    })
  }
  function receiveOpponentCut(target, damage) {
    const reaction = queueHeartReaction(target, getPlayer(db, actorJid), damage)
    return reaction ? { ...reaction, defeated: false, saved: true } : applyAbsoluteCut(target, damage)
  }
  async function drainHeartReactions() {
    const pending = getPlayer(db, opponentJid)?.battleState?.godReactionOutbox
    if (!pending?.length) return
    let acknowledged = []
    await updatePlayer(db, actorJid, actor => {
      acknowledged = applyQueuedHeartReactions(actor, opponentJid, pending)
      if (acknowledged.length && (actor.battleState?.yoriichiCatFormDefeated || godMortalDown(actor))) {
        const saved = actor.battleState?.yoriichiCatFormDefeated ? null : checkYoriichiCatForm(actor) || checkTotemRevive(actor)
        if (saved) msg += saved + '\n'
        else selfDefeated = true
      }
      return actor
    })
    if (acknowledged.length) await updatePlayer(db, opponentJid, defender => {
      acknowledgeHeartReactions(defender, acknowledged)
      return defender
    })
  }
  async function writeOpponent(mutator) {
    if (selfDefeated) return
    const result = await updatePlayer(db, opponentJid, mutator)
    await drainHeartReactions()
    return result
  }
  // Resume an interrupted defender-write/attacker-write pair before spending
  // this command's MP, charges or turn. No write is nested inside another.
  await drainHeartReactions()
  if (selfDefeated) return pvpConclude(db, opponentJid, actorJid, ctx, msg.trim())
  let incapacitated = false
  let catFormAnswers = false // Yoriichi holds this turn — she resolves it, not the owner
  let catFormOwnDefeat = false // her own pool ran out to a DOT before she could swing
  // 🏛️ A turn the Sanctum settled on its own: Victoria raising it, or the
  // far side's move nullified against it. Leaves through the same exit a stun
  // does (baton flips, the board's turn boundary runs, nothing else happens).
  let sanctumQuietTurn = false
  let pendingStarfallDuel = null // Starfall champion tick, computed in the actor write, applied after it
  let pendingTrioDuel = null
  let trioMoveMult = 1
  let trioDefPierce = 0
  let trioBypassDef = false
  let trioInvertedDrain = 0
  let trioSealTurns = 0
  let cinderMult = 0 // set when action === 'cinderverdict', once the charge is burned
  // ── 🔥 Rengoku ───────────────────────────────────────────────────────────
  // blazeHeartMult is the same shape as cinderMult: the gate burns the
  // once-per-battle charge in the actor's own updatePlayer below and hands the
  // multiplier to the shared opponent-hit phase, so DEF and every defender
  // reaction still apply. blazeHeartSplash carries "send the finishing-move
  // art" out past the mutations (no network I/O inside updatePlayer), the same
  // way kamehamehaSplash does. flameCarry is his Flame Breathing chain: the
  // combo resolves in the OPPONENT's write (their HP is what it hits), and the
  // chain it advances belongs on the ACTOR's record, so it is carried out here
  // and written in the actor's own turn-flip write at the end.
  let blazeHeartMult = 0
  let blazeHeartSplash = false
  let flameCarry = null
  // ── 🌋 Surtr (action === 'surtr') ───────────────────────────────────────
  // Her four skills ride this one action, picked by skillQuery. surtrMult /
  // surtrDefPierce are handed to the shared opponent-hit phase (so accuracy,
  // DEF, the caps and every defender reaction still apply); surtrBurn asks that
  // phase to leave the target burning; surtrSelfOnly marks Twilight and Remnant
  // Ash, which never reach the other side and must still take the turn.
  let surtrSkill = null
  let surtrMult = 1
  let surtrDefPierce = 0
  let surtrBurn = false
  let surtrSelfOnly = false
  let surtrReveal = ''
  // ── Cid Kagenou's I Am Atomic (action === 'atomic') ─────────────────────
  // Same shape as cinderMult: the gate burns the once-per-battle charge in the
  // actor's own updatePlayer below and hands back the multiplier (it rides the
  // shared opponent-hit phase, so accuracy, DEF and every defender reaction
  // still apply) and the backlash, which is paid after the strike whether or
  // not it landed. The flash (a one-turn stun) lands on a hit OR a miss, the
  // same as the PvE turn in plugins/atomic.js.
  let atomicMult = 0
  let atomicBacklashHp = 0
  // ── 🔱 Saber's Excalibur (action === 'excalibur') ────────────────────────
  // Not a multiplier: the sword lands exactly EXCALIBUR_DAMAGE. The flag only
  // records that the gate in the actor phase passed and the charge is spent, so
  // the opponent phase knows to write the flat number instead of the roll.
  let excaliburArmed = false
  // ── Naruto's Baryon Mode (action === 'kurama') ──────────────────────────
  // Same shape as cinderMult: the gate burns the once-per-battle charge (AND a
  // slice of Naruto's own health, the Baryon self-cost) in the actor's own
  // updatePlayer below and hands back two numbers. kuramaMult flows through the
  // shared opponent-hit phase exactly like cinderMult, so DEF, the accuracy
  // roll, and the defender's dodge / Wheel / beast / shield all still apply.
  // kuramaDrainPct is applied there as a true-damage rider AFTER the strike,
  // a flat share of the opponent's max HP that no armour softens.
  let kuramaMult = 0
  let kuramaDrainPct = 0
  // ── Echidna's Gospel of Greed (action === 'greedtithe') ──────────────────
  // Same shape as kuramaMult: the gate burns the once-per-battle charge in
  // the actor's own updatePlayer below and rolls her MOOD; the theft itself
  // resolves in the opponent write (it has to come off their REAL wallet),
  // and the holder's credit lands in a second actor write after, the exact
  // opponent-then-actor split hollowexchange uses.
  let greedMood = null
  let greedTaken = null // { solarsTaken, gemsTaken, child } once the opp write lands
  // Carries "send the Nine Tails summon splash" out past the mutations, the same
  // way domainSplash / kamehamehaSplash do (no network I/O inside updatePlayer).
  let kuramaSplash = false
  // ── Gojo's Hollow Purple (action === 'hollowpurple') ────────────────────
  // Same shape as cinderMult: the gate burns the once-per-battle charge in the
  // actor's own updatePlayer below and hands back the 18x multiplier, which the
  // opponent-hit phase applies through calcPlayerDamage — RAW, bypassing DEF and
  // skipping the accuracy roll, exactly as plugins/purple.js does in PvE.
  let hollowPurpleMult = 0
  // ── Gogeta's two actives ────────────────────────────────────────────────
  // Same shape again. soulPunisherMult is mitigated by DEF and just skips the
  // accuracy roll; kamehamehaMult behaves exactly like hollowPurpleMult (raw,
  // no DEF, no accuracy roll). gogetaExtra carries the Instant Transmission
  // "no cooldown" line out of the gate so the turn text can show it, and
  // kamehamehaSplash carries "send the beam art" out past the mutations, the
  // same way domainSplash does below (no network I/O inside updatePlayer).
  let soulPunisherMult = 0
  let kamehamehaMult = 0
  let gogetaExtra = ''
  let kamehamehaSplash = false
  // ── Megumi's Chimera Shadow Garden (action === 'domain') ────────────────
  // Same shape as cinderMult above: the gate runs in the actor's own
  // updatePlayer below and hands back the opening-horde multiplier, which the
  // opponent-hit phase applies through calcPlayerDamage. domainSplash carries
  // "show the Domain art" out to after the mutations (no network I/O inside
  // updatePlayer). wheelSpinCaption does the same for Mahoraga's Wheel-spin
  // GIF, which is sent as its own message before the turn text.
  let domainMult = 0
  let domainSplash = null
  let wheelSpinCaption = null
  // ── Circe's Wild Card (action === 'wildcard') ──────────────────────────
  // The draw happens in the actor's own updatePlayer below, so what the card
  // turned out to be has to be carried into the opponent-hit phase through
  // plain variables — same reason cinderMult exists rather than re-deriving.
  // Only 2 of her 6 cards deal damage at all; the 3 defensive ones arm state
  // on her battleState that applyIncomingDamage() reads on the OPPONENT's
  // turn, and Vanishing Act ends the duel outright (wildCardVanished).
  let wildCardMult = 0
  let wildCardIgnoreDefense = false
  let wildCardGuaranteedHit = false
  let wildCardMoveName = 'WILD CARD'
  let wildCardVanished = false
  // ── Xiao's Thief's Eye (action === 'thiefseye') ─────────────────────────
  // Same carry-it-out-in-plain-variables shape as cinderMult/wildCardMult: the
  // gate runs in the actor's own updatePlayer below, and the opponent-hit phase
  // needs three things out of it — the multiplier, the echo floor (the damage
  // the stolen move originally did, times THIEFS_EYE_ECHO_MULT), and the move
  // itself, which is both what gets narrated and what gets denied on the
  // opponent's record. thiefsEyeEchoed carries whether the floor is what decided
  // the final number, so the narration only claims it when it's true.
  let thiefsEyeMult = 0
  let thiefsEyeFloor = 0
  let thiefsEyeMove = null
  let thiefsEyeEchoed = false
  // 🧚‍♀️ Queen of Fairies. `fairySpellCaster` carries the chosen incantation
  // out of the actor's mutator into the opponent phase; `fairyEncorePlan` does
  // the same for `.encore` (which must be WRITTEN onto the opponent's record,
  // and no mutator may touch the other player — see the header).
  let fairySpellCaster = null
  let fairyEncorePlan = null
  // ── Minna's Hollow Exchange (action === 'hollowexchange') ────────────────
  // Carries the finished exchange out of the opponent phase so the actor's own
  // half can be written afterwards. THE SWAP NEEDS BOTH PLAYERS AT ONCE, which
  // no single updatePlayer gives us (see the no-nesting note at the top of this
  // function), so it runs in three steps: a dry-run gate in the actor phase that
  // refuses for free, the real call in the opponent phase where opp.hp is
  // writable, then a short updatePlayer on the actor to write her new HP and burn
  // the charge — the same opponent-then-actor pattern the dragon ultimate uses
  // for markDragonAsleep().
  let hollowRes = null
  let montanaCounter = null // Montana negated a .tms and struck back; applied to the caster below
  let supportSkill = null
  let turnEnded = false // set once we know the whole turn (incl. beast follow-ups) is resolved
  // ── Sword Maiden's Absolute Sword (action === 'sword') ─────────────────
  // Same carry-it-out-in-plain-variables shape as every gate above. useSword()
  // wants both fighters in one call, which a duel cannot give it (no nested
  // updatePlayer, see this function's header), so it resolves against a
  // duelProxy() of the far side and the *intent* it returns (damage, shields
  // stripped, guard broken) is written into the opponent's own updatePlayer.
  // swordStrikes is The Coordinate's real, sequentially resolved bill: it is
  // what the cinematic renderer prints, so it can never narrate a strike that
  // did not land or a death that did not happen.
  let swordPlan = null
  const swordStrikes = []
  let maidenAnswer = 0   // Return Stroke riposte, dealt to the attacker
  let desireReflect = 0  // Scarlett's My Desire, dealt to the attacker
  let diamondReflect = 0
  let wallReflect = 0    // Kim Dokja's Fourth Wall reflection, banked by the defender hook
  let justiceReflect = 0 // Audrey's counter, settled in the attacker's own write
  // Her reactions are decided BEFORE the blow resolves (a reflection is what
  // makes it land for 0), but they are printed after "X attacks -> N DMG":
  // narration that reads out of order is narration people assume is broken.
  let heroReactions = ''
  let defendRelease = null // Transcended Sword, released by this turn's own guard
  // ── Yelan's engagement (action === 'attack') ─────────────────────────────
  // One finished duel round, carried out of the actor's mutator. Right below the
  // actor write, this turn is settled by hand: the kill and the deadly poison go
  // onto the OTHER player's record, the baton flips, and we return — nothing
  // else in the swing pipeline may run, because nothing else happened. See
  // lib/yelan-engine.js for the engagement itself and `yelanRound` below.
  let yelanRound = null
  let yelanKill = null // { characterId } once the companion's bar hit 0
  let yelanPoison = false // Form 2 arrived this round: the OWNER is poisoned

  const beastTurnId = actorSnapshot.battleState.turn ?? 1
  // Independent summons also act on a committed forced pass or a Sanctum
  // activation. Compute on the owner, then apply the result on the target;
  // updatePlayer's shared writer must never be nested across these records.
  async function resolveSummonTurn() {
    let beastTurn = null
    const targetSnapshot = getPlayer(db, opponentJid)
    await updatePlayer(db, actorJid, (actor) => {
      if (!actor.inBattle || !actor.battleState) return
      beastTurn = beastIntervention(actor, BEAST_EVENT.TURN_START, {
        enemy: targetSnapshot, bs: actor.battleState, turnId: beastTurnId, deferTarget: true,
      })
      if (beastTurn.modified) msg += beastTurn.lines.join('\n') + '\n'
    })
    if (!beastTurn?.modified || !(beastTurn.bonusDamage > 0 || beastTurn.targetEffects?.length)) return false

    let defeated = false
    await writeOpponent((opp) => {
      if (!isOpponentLive(opp)) return
      // A strike that cannot arrive must not consume a shield or apply riders.
      if (sanctumShields(opp)) { msg += sanctumBreakLine(opp) + '\n'; return }
      if (lucidUntouchable(opp)) { msg += lucidUntouchedLine(opp.battleState) + '\n'; return }
      if (dreamstepActive(opp)) { msg += dreamstepHitLine(opp.battleState) + '\n'; return }
      if (graceAttackLocked({ battleState: { turn: beastTurnId } }, opp)) {
        msg += `👑 _The King's grace holds the summon back._\n`
        return
      }
      if (beastTurn.bonusDamage > 0) {
        // The summon, rather than its owner, is the attacker. Omitting the live
        // owner prevents shield reflection from mutating a different write.
        const instinct = absorbInstinctAttack(opp, beastTurn.bonusDamage)
        const remaining = instinct.damage
        if (instinct.dodged) msg += '💨 *Ultra Instinct!* Attack dodged.\n'
        const applied = receiveOpponentHit(opp, remaining, null, true, { ultraInstinctChecked: true })
        if (applied.message) msg += applied.message + '\n'
        if (!instinct.dodged && remaining < beastTurn.bonusDamage) msg += `🛡️ A shield absorbs *${beastTurn.bonusDamage - remaining}* summon damage.\n`
        if (applied.catFormDefeated) defeated = true
        else if (godMortalDown(opp)) {
          const cat = checkYoriichiCatForm(opp)
          if (cat) msg += cat
          else defeated = true
        }
      }
      if (!defeated && beastTurn.targetEffects?.length) {
        msg += applyBeastTargetEffects(opp, beastTurn.targetEffects).map(line => line + '\n').join('')
      }
    })
    return defeated
  }

  // ── Actor's own status tick + move resolution ───────────────────────────
  await updatePlayer(db, actorJid, (actor) => {
    hpBeforeTurn = actor.hp

    // Tella — Wonders of You reads whether the rival stood down (defended) on
    // their OWN last turn to decide the reprieve. Stamp it here at the top of
    // every actor turn, where `action` is unambiguously what they chose, so the
    // opponent can read it on their next turn (see the ambient hook below).
    if (actor.battleState) actor.battleState.lastActionWasDefend = (action === 'defend')
    // A guard is a stance, not a savings account. It has to survive the wait
    // between this turn and the opponent's swing (that is the entire point of
    // it), but it is dropped the moment the holder chooses to do anything else,
    // so a braced player who was never hit cannot bank it for three rounds.
    // lib/pvp-wager.js clears it the same way; normal duels only ever cleared it
    // when a hit actually landed, so `.pvp defend` against an opponent who spends
    // their turn on something other than a swing left "braced" sitting on the
    // board for the rest of the duel.
    if (actor.battleState && action !== 'defend') actor.battleState.defending = false

    // 🧚‍♀️ QUEEN OF FAIRIES — the actor's own duel bookkeeping, at the top of
    // the turn so it runs before every gate.
    //
    //   1. An Encore written by the other side is spent here. One turn of the
    //      three is gone whether or not the forced move resolves, exactly like
    //      Pokémon: you do not get your turns back by failing to comply.
    //   2. The move about to be used is COUNTED for the other side's Seal. The
    //      count lives on the USER's battleState because that is the record the
    //      user's next action can read without a cross-player write.
    //   3. The token is stamped as `lastMoveUsed` so the other side's `.encore`
    //      knows what to lock — `lastEnemyMove` is only written for named moves
    //      (recordEnemyMove skips a plain attack), and an Encore on a basic
    //      attack is a legitimate, very funny outcome.
    if (actor.battleState && encoreForced) {
      msg +=
        `🎼 *ENCORE — THE COURT CHOOSES FOR YOU*\n` +
        `_*${encoreForcedLabel || 'Your last move'}* is the only word left in your mouth this turn._\n`
    }
    if (actor.battleState?.fairyEncore) tickFairyEncore(actor.battleState)

    // Urahara's permanent Tear — action-triggered tick, fires on every PvP
    // action same as PvE (see lib/character-abilities.js doc comment).
    const permaSeverLine = tickPermanentSever(actor)
    if (permaSeverLine) msg += permaSeverLine + '\n'
    if (godMortalDown(actor) && !isCatFormActive(actor)) {
      const catMsg = checkYoriichiCatForm(actor)
      if (catMsg) {
        // The turn the player typed belonged to the owner, who is now at 0 hp —
        // there is no move of theirs left to resolve, and there never will be
        // again this duel. Yoriichi takes over completely: skip the whole
        // action-resolution branch below and let autoResolveCatFormTurns() run
        // her turn (and every turn after it) once this mutator returns.
        msg += catMsg
        catFormAnswers = true
        return
      } else {
        selfDefeated = true
        return
      }
    }

    const hpBeforeActorTick = actor.hp
    const actorStatus = processStatusTurn(actor)
    if (actorStatus.lines.length) msg += actorStatus.lines.join('\n') + '\n'
    // 🌋 Surtr — the transformation's own clock. In a dungeon it ticks inside
    // processStatusTurn() (lib/combat-handlers.js), which is deliberately gated
    // off for duels because a duel's turn counter is per-player and the tick
    // must land on THIS actor's own turn. So it is called here, once, right
    // after that funnel — the price of Twilight, and the Molten Giant's exit.
    {
      const surtrTick = surtrTurnTick(actor, actor.battleState)
      if (surtrTick.lines.length) msg += surtrTick.lines.join('\n') + '\n'
    }
    // 🌠 Starfall champion package — Seong-ha's clock, the cathedral's ledger
    // and Ha-neul. Computed against a READ-ONLY snapshot of the opponent; the
    // damage and the marks land on the opponent's record AFTER this mutator,
    // in their own write (no nesting). applyToFoe: false is the whole point.
    {
      const liveFoe = getPlayer(db, opponentJid)
      const foeSnap = !liveFoe ? null
        : typeof structuredClone === 'function' ? structuredClone(liveFoe)
        : { ...liveFoe, activeEffects: [...(liveFoe.activeEffects ?? [])] }
      const starTouch = starfallTurnTick(actor, actor.battleState, foeSnap, { applyToFoe: false })
      if (starTouch.lines.length) msg += starTouch.lines.join('\n') + '\n'
      if (starTouch.foeDamage > 0 || starTouch.foeEffects.length) {
        pendingStarfallDuel = starTouch
      }
      const trioTick = tickTrioTurnStart(actor, foeSnap, actor.battleState, { isPvp: true })
      if (trioTick.lines.length) msg += trioTick.lines.join('\n') + '\n'
      if (trioTick.enemyDamage > 0 || foeSnap) {
        pendingTrioDuel = {
          enemyDamage: trioTick.enemyDamage,
          foeEffects: foeSnap?.activeEffects ?? null,
          foeShield: foeSnap?.shield,
        }
      }
    }
    // Cat form: the owner's hp is pinned at 1 while Yoriichi fights, so the
    // tick's hp change is lifted back off the owner and redirected into HER
    // pool — matching the PvE driver in lib/combat-handlers.js. Without this a
    // burn ticks into a pinned hp bar that nothing reads and no check can act
    // on (the `!isCatFormActive` guard below is what skips it), so a DOT landed
    // before she stood up cost the duel exactly nothing.
    if (isCatFormActive(actor)) {
      const tickDelta = actor.hp - hpBeforeActorTick
      actor.hp = hpBeforeActorTick
      if (tickDelta < 0) {
        const applied = applyIncomingDamage(actor, -tickDelta, null, false)
        if (applied.message) msg += applied.message + '\n'
        if (applied.catFormDefeated) {
          msg += buildCatFormDefeatMessage()
          catFormOwnDefeat = true
          return
        }
      } else if (tickDelta > 0) {
        const healed = healCatFormPool(actor, tickDelta)
        if (healed > 0) msg += `🐈‍⬛💚 *Yoriichi* recovers *${healed} HP*!\n`
      }
    }
    if (godMortalDown(actor) && !isCatFormActive(actor)) {
      // Should not normally happen (PvP fully heals both sides between
      // matches), but guard anyway: a DOT ticking them to 0 is still a loss.
      const catMsg2 = checkYoriichiCatForm(actor)
      if (catMsg2) {
        msg += catMsg2
        catFormAnswers = true
        return
      } else {
        selfDefeated = true
        return
      }
    }

    // Mei's Final Form — automatic trigger at <=70% HP.
    const finalForm = activateFinalForm(actor)
    if (finalForm.ok) {
      msg += finalForm.message + '\n'
      void sendFinalFormVideo(ctx, finalForm.message, actorJid).catch(() => {})
    }

    // Orihime — Shun Shun Rikka, halved in duels so a fight against her ends.
    const rikka = tickShunShunRikka(actor, actor.battleState, { pvp: true })
    if (rikka) msg += rikka.message + '\n'

    // Beth — Mend & Reinforce (Turn 2+ armor repair + HP heal).
    const bethMend = tickBethMend(actor, actor.battleState)
    if (bethMend) msg += bethMend.message + '\n'

    // Liorei — Snapshot passive: automatic framing (opening frame on Turn 4, then
    // random re-frames never inside 5 moves) + flavor lapse check (Turn 3+).
    {
      const oppSnapshotForLiorei = getPlayer(db, opponentJid)
      const lioreiTick = tickLioreiTurnStart(actor, actor.battleState, { opponent: oppSnapshotForLiorei })
      if (lioreiTick) {
        msg += lioreiTick.message + '\n'
        if (ctx?.sock && ctx?.jid) {
          if (lioreiTick.snapImage && lioreiTick.autoSnapshot?.message) {
            void sendImageTo(ctx.sock, ctx.jid, lioreiTick.snapImage, lioreiTick.autoSnapshot.message).catch(() => {})
          }
          if (lioreiTick.lapseImage && lioreiTick.lapse?.message) {
            void sendImageTo(ctx.sock, ctx.jid, lioreiTick.lapseImage, lioreiTick.lapse.message).catch(() => {})
          }
        }
      }
    }

    if (actorStatus.incapacitated) {
      msg += automaticPass
        ? `🛡️ *${actor.name}: automatic defend/pass* — frozen, stunned or asleep; turn skipped.\n`
        : `💫😵 *${actor.name} IS UNABLE TO ACT THIS TURN!*\n`
      // A forced pass is not a chosen guard: no MP, mitigation or sword attack.
      actor.battleState.defending = false
      chargeSwordTurn(actor)
      actor.battleState.myTurn = false
      actor.battleState.turn = (actor.battleState.turn ?? 1) + 1
      incapacitated = true
      return
    }

    // 🏛️ The far side's Sanctum nullifies this move (decided at the door above).
    if (sanctumFizzle) {
      msg += sanctumNullifiedLine({
        actorName: actor.name,
        moveLabel: sanctumFizzle.moveLabel,
        holder: sanctumFizzle.holder,
        turn: actor.battleState.turn,
      }) + '\n'
      actor.battleState.defending = false
      chargeSwordTurn(actor)
      actor.battleState.myTurn = false
      actor.battleState.turn = (actor.battleState.turn ?? 1) + 1
      sanctumQuietTurn = true
      return
    }

    // Miyashi's Frostbind — if the opponent has Miyashi equipped and landed
    // a frostlock on the actor last turn, downgrade whatever action they
    // requested (skill/ability/cinderverdict) down to a basic attack. Does
    // NOT skip the turn (that's incapacitated, above) — the actor still
    // acts, just with a plain attack. See lib/effects.js's 'frostlock' doc
    // comment for why this needs an explicit gate instead of processStatusTurn.
    const frostGate = applyFrostlockGate(actor, action)
    if (frostGate.blocked) {
      msg += `🥶 *${actor.name}* is still locked by *Frostbind* — forced into a basic attack!\n`
      action = frostGate.action
    }

    // Alexa's Lovestruck, duel half — the opponent has the Witch of Love out,
    // and the actor's OWN companion has fallen for her. Same shape as the
    // Frostbind gate directly above: the turn is not skipped, the actor just
    // has to take it alone, because whatever they were about to call on is
    // stood there staring. Ticks down every turn and narrates itself once on
    // the way in and once on the way out. See armLovestruck()/applyAweGate().
    const aweGate = applyAweGate(actor, action)
    if (aweGate.message) msg += aweGate.message + '\n'
    if (aweGate.blocked) action = aweGate.action

    // Yelan's half of the same idea: a companion held in her engagement cannot
    // answer its owner. The marker is stamped on THIS record by the other
    // player's turn (see the yelanRound block below), which is why the gate can
    // read it locally like the awe one does.
    const yelanGate = applyYelanGate(actor, action)
    if (yelanGate.message) msg += yelanGate.message + '\n'
    if (yelanGate.blocked) action = yelanGate.action

    // ── 🏛️ Victoria Minayoko raises the Sanctum (action === 'victory') ──────
    // A self-only move: the whole turn is the claim. It works in League
    // fixtures too (the owner's call), and a wager duel never gets here (the
    // character layer is refused at the top of this function). A refusal (not
    // her, too early, already used) ends nothing and keeps the turn.
    if (action === 'victory') {
      const raised = raiseSanctum(actor, { bs: actor.battleState, boss: false })
      if (!raised.ok) {
        msg += raised.message + '\n'
        turnEnded = true
        return
      }
      msg += raised.lines.join('\n') + '\n'
      actor.battleState.defending = false
      actor.battleState.myTurn = false
      actor.battleState.turn = (actor.battleState.turn ?? 1) + 1
      sanctumQuietTurn = true
      return
    }

    // ── Yelan, the Character Killer — the engagement IS the turn ────────────
    // With her equipped and the other player's companion standing, this
    // player's BASIC attack goes into the small fight between the two of them
    // instead of into the other player. Only a basic attack: a skill, a stance
    // or a signature move is the owner's own turn and she steps aside. The gate
    // (isYelanEngaged) refuses in League fixtures and wager duels by itself, so
    // nothing here reaches either of those modes — see lib/yelan-engine.js.
    if (action === 'attack') {
      const oppLive = getPlayer(db, opponentJid)
      if (isYelanEngaged(actor, oppLive, actor.battleState)) {
        const round = runYelanDuelRound({
          attacker: actor,
          defender: oppLive,
          battleState: actor.battleState,
          turn: actor.battleState.turn ?? 1,
        })
        if (round.involved) {
          yelanRound = round
          msg += round.lines.join('\n') + '\n'
          if (round.killed) yelanKill = { characterId: round.killedCharacterId }
          // Form 2's parting gift lands on the COMPANION'S OWNER, not on the
          // companion, so it is written in the opponent phase below.
          if (round.formChanged === 'final2') yelanPoison = true
          return
        }
      }
    }

    // Xiao's Thief's Eye — if the opponent has already stolen the move being
    // asked for, it does not exist for this player any more. Unlike Frostbind
    // above this does NOT downgrade to a basic attack: it refuses the command
    // and leaves the turn intact, the same way "you don't know a skill called
    // X" is handled below, because naming a move you no longer have is an
    // invalid command rather than a punished one. A basic attack is never
    // deniable, so there is always something left to do — see
    // applyThiefsEyeDenyGate() in lib/character-abilities.js.
    const denyGate = applyThiefsEyeDenyGate(
      actor,
      action,
      action === 'skill' ? resolvePvpSkill(skillQuery, actor) : null,
    )
    if (denyGate.blocked) {
      msg += denyGate.message + '\n'
      turnEnded = true
      return
    }

    // 🧚‍♀️ Queen of Fairies — the Seal gate. Same contract as Thief's Eye
    // directly above, and for the same reason: naming a move the court has
    // already taken is an INVALID COMMAND, not a punished turn. The player
    // keeps their turn and picks something they still own. A basic attack can
    // be sealed in a duel too (after four uses), but defend, items and every
    // unsealed skill remain, so there is never a dead end.
    const fairySealGate = applyFairySealGate(
      actor,
      action,
      action === 'skill'
        ? resolvePvpSkill(skillQuery, actor)
        : (action === 'fairyspell' ? fairySpellById(skillQuery) : null),
    )
    if (fairySealGate.blocked) {
      msg += fairySealGate.message + '\n'
      turnEnded = true
      return
    }

    // Yoriichi took over on an earlier turn, and a command has arrived from the
    // owner anyway. It is refused outright: no MP spent, no skill handed to her,
    // and the turn is NOT consumed — because the turn was never the owner's to
    // consume. autoResolveCatFormTurns() below runs HER turn instead.
    //
    // This branch used to validate `.pvp skill <name>`, charge its MP, and pass
    // the move to her, on the reasoning that "the move is still the owner's to
    // choose." It isn't. That was the same defect as the old
    // "TURN PASSES TO <owner>" footer wearing a different hat, and it is the
    // reason resolveCatFormAction() no longer accepts a skill at all.
    //
    // Sits AFTER the incapacitation check and the Frostbind gate on purpose:
    // above them, a frostlocked or stunned owner could smuggle a full action
    // through. Below them, the checks that end the turn early still win.
    if (isCatFormActive(actor)) {
      msg +=
        `🐈‍⬛ *Yoriichi is fighting this duel.*\n` +
        `_${actor.name} is down. She doesn't take orders — your command is ignored._\n`
      catFormAnswers = true
      return
    }

    // ❤️🔒 Remi's Fifth-Heart Seal: blocks ALL character signature actives for 3 turns!
    const SEALABLE_CHAR_ACTIONS = new Set([
      'cinderverdict', 'blazeheart', 'domain', 'hollowpurple', 'kurohitsugi', 'soulpunisher',
      'kamehameha', 'kurama', 'thiefseye', 'wildcard', 'hollowexchange',
      'unlimitedvoid', 'puppetstrings', 'timestop', 'greedtithe', 'sword', 'atomic',
      'encore', 'fairyspell', 'excalibur', 'surtr', 'windup', 'trick', 'heartlock',
    ])
    if (SEALABLE_CHAR_ACTIONS.has(action) && isRemiCharacterSealed(actor, actor.battleState)) {
      msg += `${remiCharacterSealRefusal(actor, actor.battleState)}\n`
      turnEnded = true
      return
    }

    if (action === 'skill') {
      const skill = resolvePvpSkill(skillQuery, actor)
      if (!skill) { msg += `❌ You don't know a skill called *"${skillQuery}"*.\n`; turnEnded = true; return }
      if (skill.type === 'passive') { msg += `❌ That skill is passive.\n`; turnEnded = true; return }
      const sealedGate = skillAwakeningGate(actor, skill, config.prefix)
      if (sealedGate) { msg += `${sealedGate}\n`; turnEnded = true; return }
      if (skill._isPvpBend && actor.battleState?.affinityBendUsed) {
        msg += `🌀 You have already unleashed *${config.prefix}bend* in this duel!\n`
        turnEnded = true
        return
      }
      const pvpSkillCost = aimiyaFreeCastActive(actor) ? 0 : (skill.mpCost ?? 0)
      if ((actor.mp ?? 0) < pvpSkillCost) { msg += `❌ Not enough MP for *${skill.name}*.\n`; turnEnded = true; return }
      if (skill._isPvpBend && actor.battleState) {
        actor.battleState.affinityBendUsed = true
      }
      // ── Starfall: the two mythic skills are not damage multipliers. Burning
      // Cathedral raises a domain; Edo Tensei arms the rite. Neither throws a
      // blow — the turn is the liturgy, and the baton passes exactly as it
      // does after the Sanctum (sanctumQuietTurn). A refusal costs nothing.
      if (skill.id === 'burning_cathedral') {
        if (hasEffect(actor, 'cathedral')) { msg += `⛪ The cathedral already stands. One nave per duel.\n`; turnEnded = true; return }
        const armed = armCathedral(actor, actor.battleState)
        actor.mp = Math.max(0, (actor.mp ?? 0) - skill.mpCost)
        msg += `✨ *${actor.name}* invokes *${skill.name}*! _(${skill.mpCost} MP)_\n` + armed.lines.join('\n') + '\n'
        sanctumQuietTurn = true
        return
      }
      if (skill.id === 'edo_tensei_no_jutsu') {
        const bsx = actor.battleState
        if (bsx?.edoUsed) { msg += `📿 That name has already been called once this duel.\n`; turnEnded = true; return }
        if (bsx?.edoPrepared) { msg += `📿 *Edo Tensei* is already prepared — the dead will answer when you fall.\n`; turnEnded = true; return }
        const armed = armEdoTensei(actor, bsx)
        actor.mp = Math.max(0, (actor.mp ?? 0) - skill.mpCost)
        msg += `✨ *${actor.name}* channels *${skill.name}*! _(${skill.mpCost} MP)_\n` + armed.lines.join('\n') + '\n'
        sanctumQuietTurn = true
        return
      }
    }

    if (action === 'ability') {
      const ability = findEquippedAbility(actor, skillQuery)
      if (!ability) {
        msg += `❌ Ability *"${skillQuery}"* not found or not equipped.\n`; turnEnded = true; return
      }
      if (ability.type !== 'active') {
        msg += `⚠️ *${ability.name}* is passive — it's already applying automatically.\n`; turnEnded = true; return
      }
      actor.battleState.abilityCooldowns = actor.battleState.abilityCooldowns ?? {}
      const readyAtTurn = actor.battleState.abilityCooldowns[ability.id] ?? 0
      const currentTurn = actor.battleState.turn ?? 1
      if (currentTurn < readyAtTurn) {
        msg += `⏳ *${ability.name}* is on cooldown for *${readyAtTurn - currentTurn}* more turn(s).\n`
        turnEnded = true
        return
      }
    }

    // Audrey's counter is a self-only, once-per-duel move. The opponent is
    // read, never mutated, inside this actor write; a failed gate keeps the turn.
    if (action === 'spectate') {
      const gate = armJustice(actor)
      if (!gate.ok) { msg += gate.message + '\n'; turnEnded = true; return }
      msg += gate.message + '\n' + justiceReadout(getPlayer(db, opponentJid), actor) + '\n'
    }

    // Kim Dokja's Fourth Wall (.wall) — self-only, once per duel: one turn
    // he cannot be hurt and hits reflect at 40%. The immunity lives in
    // regressorIncomingDamage; a reflection against a duelist is banked on
    // the defender's state and settled below with the other reflects.
    if (action === 'wall') {
      const gate = activateWall(actor)
      if (!gate.ok) { msg += (gate.error ?? gate.message) + '\n'; turnEnded = true; return }
      msg += gate.message + '\n'
    }

    // Wither's Cinder Verdict — once-per-battle, no MP. Burns the charge here
    // (activateCinderVerdict sets battleState.witherUsed); the 8x multiplier is
    // applied in the opponent-hit phase below via calcPlayerDamage. A failed
    // gate (wrong character / already used) does NOT consume the turn.
    if (action === 'cinderverdict') {
      const gate = activateCinderVerdict(actor)
      if (!gate.ok) {
        if (gate.message) msg += gate.message + '\n'
        turnEnded = true
        return
      }
      cinderMult = gate.multiplier
    }

    // 🔥 Rengoku's Blaze Heart — once per battle, no MP, and only from this
    // duelist's 3rd move (activateBlazeHeart reads their own turn counter and
    // burns battleState.blazeHeartUsed). The multiplier lands in the
    // opponent-hit phase below through calcPlayerDamage, mitigated by DEF and
    // without an accuracy roll. A failed gate (wrong character, too early,
    // already used) does NOT consume the turn.
    if (action === 'blazeheart') {
      const gate = activateBlazeHeart(actor, actor.battleState)
      if (!gate.ok) {
        if (gate.message) msg += gate.message + '\n'
        turnEnded = true
        return
      }
      blazeHeartMult = gate.multiplier
      blazeHeartSplash = true
    }

    if (action === 'windup') {
      const gate = activateCardiaWindup(actor, actor.battleState, { isPvp: true })
      if (!gate.ok) {
        if (gate.message) msg += gate.message + '\n'
        turnEnded = true
        return
      }
      trioMoveMult = gate.multiplier
      trioDefPierce = gate.defPierce
      msg += `${gate.openingLine}\n`
    }

    if (action === 'trick') {
      const foeRead = getPlayer(db, opponentJid)
      const foeCopy = foeRead ? { ...foeRead, activeEffects: [...(foeRead.activeEffects ?? [])] } : null
      const gate = activateAimiyaTrick(actor, foeCopy, actor.battleState, { isPvp: true })
      if (!gate.ok) {
        if (gate.message) msg += gate.message + '\n'
        turnEnded = true
        return
      }
      trioMoveMult = gate.multiplier
      trioBypassDef = true
      trioInvertedDrain = gate.invertedDrain ?? 0
      if (foeCopy) {
        pendingTrioDuel = {
          enemyDamage: (pendingTrioDuel?.enemyDamage ?? 0) + trioInvertedDrain,
          foeEffects: foeCopy.activeEffects ?? null,
          foeShield: foeCopy.shield,
        }
      }
      msg += `${gate.openingLine}\n${gate.effectLines.join('\n')}\n`
    }

    if (action === 'heartlock') {
      const foeRead = getPlayer(db, opponentJid)
      const foeCopy = foeRead ? { ...foeRead, activeEffects: [...(foeRead.activeEffects ?? [])] } : null
      const gate = activateRemiHeartlock(actor, foeCopy, actor.battleState, { isPvp: true })
      if (!gate.ok) {
        if (gate.message) msg += gate.message + '\n'
        turnEnded = true
        return
      }
      trioMoveMult = gate.multiplier
      trioBypassDef = true
      trioSealTurns = gate.sealTurns ?? 3
      if (foeCopy) {
        pendingTrioDuel = {
          enemyDamage: pendingTrioDuel?.enemyDamage ?? 0,
          foeEffects: foeCopy.activeEffects ?? null,
          foeShield: foeCopy.shield,
        }
      }
      msg += `${gate.openingLine}\n🌹 Restored *+${gate.healAmt.toLocaleString()} HP* & branding *5/5 🌹 Black Roses*!\n`
    }

    // Cid Kagenou's I Am Atomic — once per battle, no MP. Same gate contract as
    // Cinder Verdict: activateIAmAtomic() burns bs.cidUsed, and a failed gate
    // (wrong character / already used) does NOT consume the turn. League
    // fixtures never allow it (lib/league/league-block.js refuses `.atomic`,
    // and `.battle` has no alias for it); refused here too so no route can
    // reach it there.
    if (action === 'atomic') {
      if (actor.battleState?.league) {
        msg += `⚔️🔒 *I Am Atomic* is not allowed in League fixtures.\n`
        turnEnded = true
        return
      }
      const gate = activateIAmAtomic(actor)
      if (!gate.ok) {
        if (gate.message) msg += gate.message + '\n'
        turnEnded = true
        return
      }
      atomicMult = gate.multiplier
      atomicBacklashHp = gate.backlash
      msg +=
        `☢️ *I AM ATOMIC*\n` +
        `_The mana comes up through ${actor.name} in layers. Compressing… compressing…_\n` +
        `_The air goes white. Every sound stops at once._\n` +
        `_"I am atomic."_\n`
    }

    // 🌋 Surtr — the four Arknights skills on ONE action, exactly like the PvE
    // command (plugins/surtr.js): skillQuery names which. Each gate follows the
    // contract every character active in this file keeps — a refusal (not her,
    // charge spent, HP too high, nothing to put out) costs neither the turn nor
    // the charge, and the effect itself is written by the shared opponent-hit
    // phase below (Twilight and Remnant Ash are self-only and land here).
    if (action === 'surtr') {
      const chosen = surtrSkillByCommand(skillQuery)
      if (!hasSurtr(actor)) {
        msg += `🌋 *Surtr* is not on your slot — equip her first.\n`
        turnEnded = true
        return
      }
      if (!chosen) {
        msg += buildSurtrMenu(actor, config.prefix, actor.battleState) + '\n'
        turnEnded = true
        return
      }
      surtrSkill = chosen
      let gate = { ok: true }
      if (chosen.id === 'molten_giant') gate = activateMoltenGiant(actor, actor.battleState)
      else if (chosen.id === 'surtrs_flame') gate = activateSurtrFlame(actor, actor.battleState)
      else if (chosen.id === 'twilight') gate = activateTwilight(actor, actor.battleState)
      else if (chosen.id === 'remnant_ash') {
        if (!twilightActive(actor, actor.battleState)) {
          gate = { ok: false, message: `🕯️ *Remnant Ash* has nothing to put out. _Twilight is not running._` }
        } else {
          gate = { ok: true, ash: endTwilight(actor, actor.battleState, { heal: true }) }
        }
      }
      if (!gate.ok) {
        if (gate.message) msg += gate.message + '\n'
        turnEnded = true
        return
      }

      if (chosen.id === 'twilight') {
        surtrSelfOnly = true
        surtrReveal =
          `🌋 *TWILIGHT — THE COLOSSUS STOPS PRETENDING* 🌋\n` +
          `_She gets taller. The fires get louder._\n\n` +
          `❤️ Max HP *${gate.beforeMax} → ${gate.grownMax}* _(${gate.hp} now)_\n` +
          `⚔️ +*${gate.atkGain}* ${String(gate.atkKey).toUpperCase()}\n` +
          `🔥 *+${Math.round((TWILIGHT_OUTGOING - 1) * 100)}%* damage · *+1* target\n` +
          `⏳ *No duration.* _It ends when she ends it, or when she does._\n` +
          `🩸 _It costs her *${Math.round(gate.tickFraction * 100)}%* of her max HP every turn._\n`
        msg += surtrReveal
      } else if (chosen.id === 'remnant_ash') {
        surtrSelfOnly = true
        surtrReveal =
          `🕯️ *REMNANT ASH*\n` +
          `_The fires fold back down into the sword._\n` +
          `💚 *+${gate.ash.healed}* HP restored _(now ${gate.ash.hp}/${gate.ash.maxHp})_\n`
        msg += surtrReveal
      } else {
        if (chosen.id === 'molten_giant') {
          msg +=
            `🗡️ *MOLTEN GIANT* 🗡️\n` +
            `_The floor splits, and something the size of a house climbs out of it, already on fire._\n` +
            `_It stands beside her for *${gate.turns}* turns — *+${Math.round((MOLTEN_GIANT_OUTGOING - 1) * 100)}%* damage and one more target._\n\n`
        }
        if (chosen.id === 'laevatain') {
          surtrMult = laevatainMultiplier(actor, actor.battleState)
          if (laevatainStoked(actor, actor.battleState)) {
            msg += `🔥 *The fires are stoked.* _This one lands for more, and it does not miss._\n`
          }
        } else if (chosen.id === 'molten_giant') {
          surtrMult = MOLTEN_GIANT_MULT
        } else if (chosen.id === 'surtrs_flame') {
          surtrMult = gate.multiplier
          surtrDefPierce = gate.defPierce
          surtrBurn = true
        }
        msg += `${chosen.emoji} *${chosen.name.toUpperCase()}*\n📖 _${chosen.flavor}_\n\n`
      }
    }

    // 🔱 Saber's Excalibur — once per battle, no MP, and the SAME gate the PvE
    // turn uses (armExcalibur, which burns bs.starfallKit.excaliburUsed and
    // checks Saber + the sword in the weapon slot). A failed gate does NOT
    // consume the turn or the charge: "you equipped the wrong character" must
    // not cost a duelist their move.
    //
    // The number itself is applied in the opponent-hit phase below, not here.
    // That is deliberate — the flat 3000 rides the shared hit funnel, so every
    // defender reaction and every shield this engine owns gets its say, and the
    // duel's damage bookkeeping (lifesteal, the attacker's pack, the League
    // cap) stays in one place.
    if (action === 'excalibur') {
      const gate = armExcalibur(actor, actor.battleState, { opponent: getPlayer(db, opponentJid) })
      if (!gate.ok) {
        if (gate.message) msg += gate.message + '\n'
        turnEnded = true
        return
      }
      excaliburArmed = true
      msg +=
        `🔱 *${EXCALIBUR_NAME}*\n` +
        EXCALIBUR_OPENINGS.map(line => `${line}\n`).join('') +
        `_${EXCALIBUR_DAMAGE.toLocaleString()} damage. Armour is not part of this conversation._\n`
    }

    // Xiao's Thief's Eye — once-per-battle, no MP. Burns the charge here
    // (activateThiefsEye sets battleState.thiefsEyeUsed) and reads what the
    // opponent last hit them with off battleState.lastEnemyMove, recorded in
    // the opponent-hit phase below. A failed gate — wrong character, already
    // used, or nothing named to copy yet — does NOT consume the turn.
    if (action === 'thiefseye') {
      const gate = activateThiefsEye(actor)
      if (!gate.ok) {
        if (gate.message) msg += gate.message + '\n'
        turnEnded = true
        return
      }
      thiefsEyeMult = gate.multiplier
      thiefsEyeFloor = gate.echoFloor
      thiefsEyeMove = gate.move
    }

    // Minna's Hollow Exchange — once-per-battle, no MP. DRY RUN ONLY here: the
    // real call needs a writable opponent, which this mutator does not have, so
    // it happens in the opponent phase further down. What this buys is the free
    // refusal — "not hollow enough" and "nothing worth taking" both depend on HP
    // that moves every turn, so they are the refusals players will actually hit,
    // and neither should cost the turn or the charge. Read the opponent through a
    // plain getPlayer() snapshot, the same read-only way actorSnapshot is taken
    // up top; nesting updatePlayer here would deadlock the write queue.
    if (action === 'hollowexchange') {
      const dry = activateHollowExchange(actor, getPlayer(db, opponentJid), actor.battleState, { dryRun: true })
      if (!dry.ok) {
        if (dry.message) msg += dry.message + '\n'
        turnEnded = true
        return
      }
    }

    if (action === 'garden') {
      const gate = canCallGarden(actor)
      if (!gate.ok) { msg += gate.message + '\n'; turnEnded = true; return }
      actor.battleState.gardenUsed = true
    }

    // Megumi's Chimera Shadow Garden — once-per-battle, 0 MP (canon: an
    // INCOMPLETE domain, cheap enough to maintain). Opening it doubles the
    // Thousand Shadows Swarm, grants shadow-travel dodge for the rest of the
    // duel and calls Mahoraga out; the opening horde's multiplier resolves in
    // the opponent-hit phase below. Deliberately still rolls accuracy there:
    // CSG has no barrier, so it grants NO sure-hit — the one thing that
    // separates it from a complete domain. A failed gate (wrong character /
    // already open) does NOT consume the turn.
    if (action === 'domain') {
      const gate = activateChimeraDomain(actor)
      if (!gate.ok) {
        if (gate.message) msg += gate.message + '\n'
        turnEnded = true
        return
      }
      domainMult = gate.multiplier
      domainSplash = gate.message
      msg += gate.message + '\n\n'
    }

    // Gojo's Hollow Purple — once-per-battle, no MP. Burns the charge here
    // (activateHollowPurple sets battleState.hollowPurpleUsed); the 18x
    // multiplier lands in the opponent-hit phase below, applied RAW: it bypasses
    // DEF and never misses, the same as its PvE turn in plugins/purple.js. A
    // failed gate (wrong character / already used) does NOT consume the turn.
    if (action === 'hollowpurple') {
      const gate = activateHollowPurple(actor, actor.battleState)
      if (!gate.ok) {
        if (gate.message) msg += gate.message + '\n'
        turnEnded = true
        return
      }
      hollowPurpleMult = gate.multiplier
    }

    // Gogeta's Soul Punisher — no MP, short cooldown. The gate commits the
    // cooldown (and Instant Transmission may refuse to start it, which is what
    // gate.extra reports); the multiplier lands in the opponent-hit phase,
    // mitigated by DEF but with no accuracy roll. A failed gate (wrong
    // character / still recharging) does NOT consume the turn.
    if (action === 'soulpunisher') {
      const gate = activateSoulPunisher(actor, actor.battleState)
      if (!gate.ok) {
        if (gate.message) msg += gate.message + '\n'
        turnEnded = true
        return
      }
      soulPunisherMult = gate.multiplier
      if (gate.extra) gogetaExtra = gate.extra
    }

    // Gogeta's Big Bang Kamehameha — needs a full energy bar and empties it,
    // needs the fusion to still be holding, and carries a long cooldown. The
    // gate spends all three; the multiplier lands in the opponent-hit phase
    // applied RAW, bypassing DEF and never missing, the same as Hollow Purple.
    // A failed gate does NOT consume the turn.
    if (action === 'kamehameha') {
      const gate = activateBigBangKamehameha(actor, actor.battleState)
      if (!gate.ok) {
        if (gate.message) msg += gate.message + '\n'
        turnEnded = true
        return
      }
      kamehamehaMult = gate.multiplier
      if (gate.extra) gogetaExtra = gate.extra
      kamehamehaSplash = true
    }

    // Gojo's Unlimited Void — once-per-battle, no MP, no damage. Burns the
    // charge here (activateUnlimitedVoid sets battleState.unlimitedVoidUsed); the
    // opponent-hit phase applies the hard stun (UNLIMITED_VOID_STUN_TURNS) and
    // the void spends the opponent's action, so no counter lands this turn. A
    // failed gate does NOT consume the turn.
    if (action === 'unlimitedvoid') {
      const gate = activateUnlimitedVoid(actor, actor.battleState)
      if (!gate.ok) {
        if (gate.message) msg += gate.message + '\n'
        turnEnded = true
        return
      }
    }

    // Aizen's Kurohitsugi — once-per-battle, no MP. Burns the charge here
    // (activateKurohitsugi sets battleState.kurohitsugiUsed); the multiplier is
    // NOT carried out as a constant because it scales with his stolen senses
    // and how wounded the opponent already is — it is computed live in the
    // opponent-hit phase via kurohitsugiMultiplier(). Lands RAW: it bypasses
    // DEF and never misses, the same as its PvE turn in plugins/kurohitsugi.js.
    // A failed gate (wrong character / already used) does NOT consume the turn.
    if (action === 'kurohitsugi') {
      const gate = activateKurohitsugi(actor, actor.battleState)
      if (!gate.ok) {
        if (gate.message) msg += gate.message + '\n'
        turnEnded = true
        return
      }
    }

    // Sword Maiden's Absolute Sword (action === 'sword', skillQuery = the
    // technique). A gate exactly like every other signature move here: a refusal
    // (no charge, no MP, already armed, not her) costs nothing and does NOT take
    // the turn. A success spends MP and charge on her own record, and the cut
    // itself is written in the opponent's phase below. The far side is handed to
    // useSword() as a duelProxy so nothing about it is mutated from in here.
    if (action === 'sword') {
      const gate = useSword(actor, duelProxy(getPlayer(db, opponentJid)), skillQuery)
      if (!gate.ok) {
        if (gate.message) msg += gate.message + '\n'
        turnEnded = true
        return
      }
      swordPlan = gate
      msg += gate.message + '\n'
    }

    // Ronova's The End of the World (action === 'endworld'). Pure declaration: no
    // damage this turn, so it sits with the other self-contained gates and the
    // opponent takes no hit. The five-turn gate and the once-per-duel latch are
    // both enforced inside activateEndworld(); what advances the countdown is
    // resolveDuelTurnBoundary(), run once at every flip below. A failed gate does
    // NOT consume the turn.
    if (action === 'endworld') {
      const gate = activateEndworld(actor)
      if (!gate.ok) {
        if (gate.message) msg += gate.message + '\n'
        turnEnded = true
        return
      }
      msg += gate.message + '\n'
    }

    // Aizen's Hōgyoku — once-per-battle, no MP, no damage. The whole evolution
    // (heal, all five senses, rest-of-battle stat surge) resolves on the actor
    // right here inside their own mutator — it touches nobody else — and the
    // gate returns its own reveal copy. The opponent takes no hit this action
    // (skipsOpponentHit below), same as a defend turn: their answer is simply
    // their own turn against whatever he has become. A failed gate does NOT
    // consume the turn.
    if (action === 'hougyoku') {
      const gate = activateHogyoku(actor, actor.battleState)
      if (!gate.ok) {
        if (gate.message) msg += gate.message + '\n'
        turnEnded = true
        return
      }
      if (gate.message) msg += gate.message + '\n'
    }

    // Echidna's Gospel of Greed - once per battle, no MP. Burns the charge
    // here (activateGreedTithe sets battleState.greedTitheUsed) and rolls her
    // mood; the opponent-hit phase lifts the money and gems straight off the
    // opponent's wallet (mood-shaped) and hangs them distracted for a turn,
    // then a second actor write credits the holder - same opponent-then-actor
    // split hollowexchange uses. A failed gate does NOT consume the turn.
    if (action === 'greedtithe') {
      const gate = activateGreedTithe(actor, actor.battleState)
      if (!gate.ok) {
        if (gate.message) msg += gate.message + '\n'
        turnEnded = true
        return
      }
      greedMood = gate.mood
    }

    // Red Rose's Puppet Strings — once-per-battle, no MP. Burns the charge here
    // (activatePuppetStrings sets battleState.puppetStringsUsed); the
    // opponent-hit phase turns the opponent's own attack on themselves (floored,
    // never lethal) and tangles them for PUPPET_TANGLE_TURNS, so the actor-phase
    // incapacitation branch above skips their action while it holds — their
    // companion caught right along with them. A failed gate does NOT consume the
    // turn.
    if (action === 'puppetstrings') {
      const gate = activatePuppetStrings(actor, actor.battleState)
      if (!gate.ok) {
        if (gate.message) msg += gate.message + '\n'
        turnEnded = true
        return
      }
    }

    // Reverie's Time Stop — once-per-battle, no MP. Burns the charge here
    // (activateTimeStop sets battleState.timeStopUsed); the opponent-hit phase
    // below freezes them for TIME_STOP_TURNS so their next moves are skipped by
    // the shared incapacitation branch — UNLESS they have Montana equipped, in
    // which case she negates the stop and answers with a counter (see the
    // 'timestop' branch further down). A failed gate does NOT consume the turn.
    if (action === 'timestop') {
      const gate = activateTimeStop(actor, actor.battleState)
      if (!gate.ok) {
        if (gate.message) msg += gate.message + '\n'
        turnEnded = true
        return
      }
    }

    // Naruto's Baryon Mode — once-per-battle, no MP, but it costs NARUTO his own
    // health. activateKurama burns the charge (battleState.kuramaUsed) AND spends
    // a slice of his max HP to hold the fusion (floored, never self-lethal), then
    // hands back the strike multiplier and the lifespan-drain share. The strike
    // itself resolves through the shared opponent-hit phase below via kuramaMult
    // (so DEF, accuracy and the defender's dodge / Wheel / beast / shield all
    // still apply); the drain rider is added there as true damage. A failed gate
    // does NOT consume the turn. The self-cost is paid the moment it goes off, so
    // its line is shown here whether the strike then lands or misses.
    if (action === 'kurama') {
      const gate = activateKurama(actor, actor.battleState)
      if (!gate.ok) {
        if (gate.message) msg += gate.message + '\n'
        turnEnded = true
        return
      }
      kuramaMult = gate.multiplier
      kuramaDrainPct = gate.drainPct
      kuramaSplash = true
      if (gate.selfCostLine) msg += gate.selfCostLine + '\n'
    }

    // The dragon's ultimate — Nisha's spin-exclusive standalone companion
    // (lib/dragon-engine.js). PvP-only, once-per-battle, gated to turn 4+.
    // True-damage kill applied in the opponent-hit phase below, NOT a
    // damageMultiplier like Cinder Verdict — see resolveDragonUltimateDamage().
    // A failed gate (no dragon / too early / already used / not PvP) does
    // NOT consume the turn, same as a failed Cinder Verdict gate above.
    if (action === 'ultimate') {
      const gate = activateDragonUltimate(actor)
      if (!gate.ok) {
        if (gate.message) msg += gate.message + '\n'
        turnEnded = true
        return
      }
    }

    // Circe's Wild Card — three draws per battle, no MP. The draw itself is
    // the turn: drawWildCard() spends one use and picks from the 5-card pool
    // (6 once she's at her limit — Vanishing Act only shows up then), and
    // resolveWildCard() applies whatever it landed on. A failed gate (wrong
    // character / hand empty) does NOT consume the turn, same as the two
    // gates above, and deliberately does not consume a draw either.
    //
    // Note this sits BELOW the Frostbind gate, which means a frostlocked
    // Circe has already had `action` rewritten to 'attack' by the time we get
    // here — she can't snap her fingers through a frostlock, and crucially
    // doesn't burn a draw failing to.
    if (action === 'wildcard') {
      if (!hasCirce(actor)) {
        msg += `🃏 *Wild Card* belongs to *Circe, the Jester* — equip her first.\n`
        turnEnded = true
        return
      }
      // Vanishing Act is a walkout: it clears the fight and settles outside
      // pvpConclude (nobody wins, nobody loses). In a League fixture that would
      // strand a scheduled match with no result on the table, so the escape card
      // is not dealt into a fixture at all. The fixture is compulsory; the five
      // that remain are all battle state and HP. See
      // docs/league-signature-move-audit.md.
      const draw = drawWildCard(actor, { allowEscape: !actor.battleState?.league })
      if (!draw.ok) {
        msg += (draw.message ?? `🃏 Her hand is empty.`) + '\n'
        turnEnded = true
        return
      }
      const outcome = resolveWildCard(actor, draw.card, { isPvp: true, enemyIsBoss: false })
      msg += buildWildCardReveal(draw.card, draw, outcome.lines) + '\n'
      wildCardMoveName = draw.card.name.toUpperCase()

      if (outcome.kind === 'escape') {
        // 🦋 Vanishing Act — resolveWildCard() has already cleared her out of
        // the fight. Handled outside this mutator (the opponent needs clearing
        // too), so just flag it and stop the turn here.
        wildCardVanished = true
        turnEnded = true
        return
      }
      if (outcome.kind === 'damage') {
        wildCardMult = outcome.multiplier
        // Wishing Star's PvE execute is deliberately suppressed in duels (the
        // `isPvp: true` above is what does it) — a 1-in-6 draw should not
        // decide a rated match outright. It lands as a 12x hit instead, which
        // is still the single heaviest strike in the bot.
        wildCardIgnoreDefense = !!outcome.ignoreDefense
        wildCardGuaranteedHit = !!outcome.guaranteedHit
      }
      // 🃏 Final Dash / 🤡 Last Laugh / 🎪 Wings of a Butterfly fall through
      // with wildCardMult still 0: nothing to resolve against the opponent
      // this turn. resolveWildCard() armed flags on her own battleState, and
      // applyIncomingDamage() reads them when the opponent swings back.
    }

    // ── 🧚‍♀️ Queen of Fairies — Encore (action === 'encore') ────────────────
    // The gate runs on the ACTOR's own record (equipped? already used? is
    // there anything to echo?), but the lock itself is written onto the
    // OPPONENT in the opponent phase below — no mutator may touch the other
    // player (see this function's header). A failed gate does NOT consume the
    // turn, matching every other signature move here.
    if (action === 'encore') {
      if (!hasFairyQueen(actor)) {
        msg += `🧚‍♀️ *Encore* belongs to the *Queen of Fairies* — equip her first.\n`
        turnEnded = true
        return
      }
      if (fairyEncoreUsed(actor.battleState)) {
        msg += `🧚‍♀️ _She has already taken her bow this duel. One encore per battle._\n`
        turnEnded = true
        return
      }
      const enemyLast = getPlayer(db, opponentJid)?.battleState?.lastMoveUsed
      if (!enemyLast) {
        msg += `🎼 _There is nothing to echo yet — let them move first._\n`
        turnEnded = true
        return
      }
      markFairyEncoreUsed(actor.battleState)
      fairyEncorePlan = enemyLast
      msg +=
        `🧚‍♀️💫 *ENCORE*\n` +
        `─────────────\n` +
        `_The Queen claps once, and the dark court remembers the last thing ${getPlayer(db, opponentJid)?.name ?? 'the enemy'} did._\n` +
        `🎼 *${enemyLast.name}* will be the only move they can make for the next *3* turns.\n`
    }

    // ── 🧚‍♀️ Queen of Fairies — Creative Magic (action === 'fairyspell') ────
    // One action for ten incantations: `skillQuery` is the typed command
    // (resolved by fairySpellById in the router). The gate is once-per-battle
    // per spell and costs no MP; the self half lands here, and the hostile half
    // is written in the opponent phase, where every other signature move's
    // damage is written. A failed gate does NOT consume the turn.
    if (action === 'fairyspell') {
      const spell = fairySpellById(skillQuery)
      const gate = fairySpellGate(actor, spell, actor.battleState)
      if (!gate.ok) {
        msg += gate.message + '\n'
        turnEnded = true
        return
      }
      consumeFairySpell(actor, spell, actor.battleState)
      fairySpellCaster = spell
      msg += buildFairySpellReveal(spell, actor.name, getPlayer(db, opponentJid)?.name ?? null) + '\n\n'
      const self = applyFairySpellSelf(spell, actor)
      if (self.lines.length) msg += self.lines.join('\n') + '\n'
    }

    if (action === 'skill') {
      const skill = resolvePvpSkill(skillQuery, actor)
      if (isSupportSkill(skill)) {
        supportSkill = skill
        msg += applySupportSelf(actor, skill)
      }
    }

    // ⚡ MINATO — Flying Thunder God, the duel half of his clock. In every other
    // fight type the seal lands (and a flash is announced) from
    // processStatusTurn(), at the top of the turn. A duel resolves that tick
    // BEFORE it knows whether the typed command is even legal, so here it would
    // spend the announcement on a refusal ("unknown skill", "not enough MP")
    // and print nothing on the retry that actually hits for double. So the
    // shared funnel skips duels and the tick sits here instead, for the same
    // reason the Queen's record just below does: a refused command is not a
    // move. Narration and the one-time seal only; the doubled strike and the
    // dodge read battleState directly and need nothing from this line.
    {
      const flashLine = minatoTurnTick(actor, actor.battleState, { enemyName: getPlayer(db, opponentJid)?.name })
      if (flashLine) msg += flashLine + '\n'
    }

    // 🧚‍♀️ QUEEN OF FAIRIES — record the move only AFTER every gate above has
    // let it through. This sits here, not at the top of the turn, because a
    // refused command is not a move: a sealed spell, an unknown skill, an
    // empty Encore or a failed once-per-battle gate must not become the thing
    // the other side's next `.encore` locks, and must not inflate a Seal count
    // toward a technique the player never actually used.
    {
      const enemyEquippedId = getPlayer(db, opponentJid)?.equippedCharacter ?? null
      const usedSkill = action === 'skill'
        ? resolvePvpSkill(skillQuery, actor)
        : (action === 'fairyspell' ? fairySpellById(skillQuery) : null)
      const sealsCountable = action === 'attack' || action === 'skill' || action === 'fairyspell'
      const sealedNow = sealsCountable
        ? noteDuelMoveUse(actor, enemyEquippedId, action, usedSkill)
        : null
      if (sealedNow) {
        msg +=
          `🧚‍♀️⛓️ *THE COURT SEALS A WORD.*\n` +
          `_*${sealedNow.label}* has been used four times against the Queen. ` +
          `It is taken out of ${actor.name}'s hands for the rest of this duel._\n`
      }
      const moveName = action === 'attack'
        ? 'Basic Attack'
        : (usedSkill?.name ?? (action === 'defend' ? 'Defend' : action))
      if (actor.battleState) {
        actor.battleState.lastMoveUsed = {
          action,
          skillQuery: action === 'skill' || action === 'fairyspell' ? skillQuery : '',
          id: usedSkill?.id ?? action,
          name: moveName,
        }
      }
    }

    if (action === 'defend' || action === 'spectate' || action === 'ability' || action === 'cinderverdict' || action === 'blazeheart' || action === 'windup' || action === 'trick' || action === 'heartlock' || action === 'ultimate' || action === 'wildcard' || action === 'domain' || action === 'thiefseye' || action === 'hollowexchange' || action === 'hollowpurple' || action === 'unlimitedvoid' || action === 'puppetstrings' || action === 'timestop' || action === 'kurama' || action === 'soulpunisher' || action === 'kamehameha' || action === 'sword' || action === 'endworld' || action === 'garden' || action === 'atomic' || action === 'kurohitsugi' || action === 'hougyoku' || action === 'greedtithe' || action === 'encore' || action === 'fairyspell' || action === 'excalibur') {
      if (action === 'defend') {
        const mpRegen = Math.floor(actor.maxMp * 0.05)
        actor.mp = Math.min(actor.maxMp, actor.mp + mpRegen)
        // THE GUARD LIVES ON THE GUARDIAN. This used to be written onto the
        // OPPONENT's battleState (see the old `else if (action === 'defend')`
        // below), while every mitigation read in this file looks at
        // `opp.battleState.defending` of whoever is about to be hit. So the
        // halving was handed to the other side of the duel: defending protected
        // them from you, and you never got the brace you paid a turn for. Read
        // the flag where it is consumed (3296) and this is the only sane place
        // for it to be written.
        actor.battleState.defending = true
        msg += `🛡️🔰 *${actor.name} BRACES FOR IMPACT!* _(+${mpRegen} MP, next hit halved)_\n`
        const doctrineGuard = noteDoctrineAction(actor, actor.battleState, 'defend', { target: duelProxy(getPlayer(db, opponentJid)) })
        if (doctrineGuard.lines.length) msg += doctrineGuard.lines.join('\n') + '\n'
        // Transcended Sword: drawing it is one turn, standing behind the guard
        // is the release. Same swordReaction() the PvE defend turn calls
        // (plugins/defend.js), same absolute cut, and it is spent whether or not
        // the opponent was foolish enough to swing into it.
        const release = swordReaction(actor, duelProxy(getPlayer(db, opponentJid)), { defend: true })
        if (release) {
          defendRelease = release
          msg += release.message + '\n'
        }
      }
      // 'ability'/'ultimate'/'wildcard' fall through with no weapon wear —
      // mirrors PvE's useability.js, which never touches durability for
      // ability use. Circe never draws a weapon at all, she draws a card.
      // 'thiefseye' and 'hollowexchange' are here for the same reason: Xiao
      // throws a technique she took, and Minna does not swing at anyone.
      // Gogeta's two moves are both ki thrown from a distance, so nothing in
      // his hand touches anything either. Aizen's two are the same shape:
      // Kurohitsugi is Hadō #90, a coffin dropped from a distance, and the
      // Hōgyoku is a transformation that holds no weapon at all.
      // 'endworld' is weather, and 'sword' is a blade that is not there: neither
      // of them is a weapon in the inventory wearing down.
      //
      // 'excalibur' is here for parity, not because it is intangible: PvE's
      // `.excalibur` turn (lib/starfall-kits.js runSignatureTurn) never calls
      // wearWeaponOnTurn either, so a sword that dulled in duels and not in
      // dungeons would be a second, worse kind of asymmetry.
    } else if (!supportSkill) {
      const wWear = wearWeaponOnTurn(actor)
      msg += breakMessage(wWear)
    }
  })

  // 🌠 Starfall — the duel twin of the PvE tick lands here: damage and marks
  // the actor's turn computed against a snapshot, applied to the opponent in
  // their own updatePlayer. A kill from the clock is settled by the ordinary
  // godMortalDown check below like any other blow.
  if (pendingStarfallDuel) {
    const pending = pendingStarfallDuel
    pendingStarfallDuel = null
    await writeOpponent((opp) => {
      if (!isOpponentLive(opp)) return
      if (pending.foeDamage > 0) opp.hp = Math.max(0, opp.hp - pending.foeDamage)
      for (const fx of pending.foeEffects) {
        if (fx?.type === 'strip_buff') {
          const BUFF_TYPES = ['strengthen', 'shield', 'haste', 'warcry', 'damage_boost', 'regen']
          const candidates = (opp.activeEffects ?? []).filter(e => BUFF_TYPES.includes(e?.type) && e.remaining > 0)
          if (candidates.length) {
            let best = candidates[0]
            let bestScore = -1
            for (const c of candidates) {
              const score = Number(c.value ?? c.amount ?? c.percent ?? 0)
              if (Number.isFinite(score) && score > bestScore) { bestScore = score; best = c }
            }
            opp.activeEffects = opp.activeEffects.filter(e => e !== best)
          }
          continue
        }
        if (fx?.sourceId === 'six_laws_weight') {
          opp.activeEffects = (opp.activeEffects ?? []).filter(e => e?.sourceId !== 'six_laws_weight')
        }
        addStatusEffect(opp, fx)
      }
    })
    const oppAfterClock = getPlayer(db, opponentJid)
    if (oppAfterClock && !isCatFormActive(oppAfterClock) && godMortalDown(oppAfterClock)) {
      opponentDefeated = true
    }
  }

  if (pendingTrioDuel) {
    const trioPending = pendingTrioDuel
    pendingTrioDuel = null
    await writeOpponent((opp) => {
      if (!isOpponentLive(opp)) return
      if (Array.isArray(trioPending.foeEffects)) {
        opp.activeEffects = trioPending.foeEffects
      }
      if (trioPending.foeShield !== undefined) {
        opp.shield = trioPending.foeShield
      }
      if (trioPending.enemyDamage > 0) {
        opp.hp = Math.max(1, (Number(opp.hp) || 1) - trioPending.enemyDamage)
      }
    })
  }

  if (selfDefeated) {
    return pvpConclude(db, opponentJid, actorJid, ctx, `_${actorSnapshot.name} succumbs to lingering damage!_`)
  }
  if (catFormOwnDefeat) {
    // A lingering DOT drained her pool before she could swing. Same real loss as
    // any other, carrying the defeat cinematic into the conclude message.
    return pvpConclude(db, opponentJid, actorJid, ctx, msg.trim())
  }
  if (catFormAnswers) {
    // She holds this turn — either she stood up during it, or she was already up
    // and the owner's command was refused above. Either way the baton is still
    // on her owner's record, so autoResolveCatFormTurns() picks it up, resolves
    // her attack, and hands it to the other side. It keeps going while the baton
    // keeps landing on a cat form, which is also what makes a duel between two
    // Yoriichi owners resolve itself with nobody typing anything.
    const auto = await autoResolveCatFormTurns(db, ctx, actorJid, opponentJid, { lead: msg })
    if (auto.concluded) return
    msg += auto.text
    const actorAfterAuto = getPlayer(db, actorJid)
    const oppAfterAuto = getPlayer(db, opponentJid)
    return ctx.reply(msg.trim() + pvpStatusFooter(actorAfterAuto, oppAfterAuto))
  }
  if (incapacitated || sanctumQuietTurn) {
    if (await resolveSummonTurn()) return pvpConclude(db, actorJid, opponentJid, ctx, msg.trim())
    await updatePlayer(db, actorJid, (actor) => { if (actor.battleState) actor.battleState.lastMoveAt = Date.now() })
    await writeOpponent((opp) => {
      opp.battleState.myTurn = true
      opp.battleState.lastMoveAt = Date.now()
    })
    // A stolen turn is still a turn of the duel. Ronova's countdown runs on the
    // board, not on whether the person holding the baton got to choose something,
    // so a stun freezes a player out of their moves and not out of the world
    // ending around them. Without this the shared ply id would also leave a gap
    // here, and completeTurn() reads ids as monotonic.
    const stunBoundary = await resolveDuelTurnBoundary(db, actorJid, opponentJid)
    if (stunBoundary.lines.length) msg += stunBoundary.lines.join('\n') + '\n'
    if (stunBoundary.kill) {
      const winnerJid = stunBoundary.kill === 'actor' ? opponentJid : actorJid
      const loserJid = stunBoundary.kill === 'actor' ? actorJid : opponentJid
      await showEndworldClash(ctx, msg.trim(), { participants: [actorJid, opponentJid] })
      return pvpConclude(db, winnerJid, loserJid, ctx,
        `☠️🌑 *THE END OF THE WORLD* lands while *${getPlayer(db, loserJid)?.name ?? 'they'}* cannot move. _That was the whole point of the countdown._`)
    }
    // The outer automatic-turn loop owns further passes and presentation.
    // Returning here avoids recursive auto loops and duplicate status cards.
    if (automaticPass) return { text: msg, concluded: false }
    // The baton just moved. If it landed on a side Yoriichi is fighting for, she
    // answers now — the opponent is not left waiting on a player who has no turn.
    const auto = await autoResolveCatFormTurns(db, ctx, actorJid, opponentJid, { lead: msg })
    if (auto.concluded) return
    msg += auto.text
    return ctx.reply(
      msg.trim() +
      pvpStatusFooter(getPlayer(db, actorJid), getPlayer(db, opponentJid)),
    )
  }
  if (wildCardVanished) {
    // 🦋 Vanishing Act in a duel — a clean exit, deliberately NOT routed
    // through pvpConclude(). Nobody won this match: no rating change on
    // either side, no solars seized, and nothing written to either player's
    // win/loss record or streak. She didn't beat them and they didn't beat
    // her; the show simply ended.
    //
    // Both sides are still cleared and fully healed, exactly the way every
    // other duel ending leaves them (pvpConclude, forfeit, tournament match),
    // so neither player walks into their next dungeon carrying duel damage.
    // She keeps the town relocation resolveWildCard() already did.
    let oppName = ''
    await writeOpponent((opp) => {
      oppName = opp.name
      // 🌋 Surtr — the show ending is still an exit: the colossus comes off
      // before the heal, or she keeps a max HP the fight invented.
      clearSurtrKit(opp, opp.battleState)
      opp.hp = opp.maxHp
      opp.mp = opp.maxMp
      opp.inBattle = false
      opp.battleState = null
      opp.activeEffects = []
      clearHypnosis(opp)
      clearSnapshot(opp)
      finalizeSlainCharacters(opp)
    })
    await updatePlayer(db, actorJid, (actor) => {
      // resolveWildCard() already dropped inBattle/battleState and set her
      // location; this only tops her back up so both sides leave level.
      actor.hp = actor.maxHp
      actor.mp = actor.maxMp
      actor.activeEffects = []
      clearHypnosis(actor)
      clearSnapshot(actor)
    })
    return ctx.reply(
      msg.trim() + `\n\n` +
      `🎪 *— THE SHOW'S OVER —*\n\n` +
      `_A puff of coloured smoke, and *${actorSnapshot.name}* is simply not there anymore._\n` +
      `📍 She turns up in *Astral Town*, entirely unbothered.\n\n` +
      `🤝 *No result.* Nobody won, nobody lost — no rating change, no solars, ` +
      `nothing on either record.\n` +
      `❤️‍🩹 *${oppName}* is left swinging at empty air, fully healed.\n\n` +
      `_Rematch: *${config.prefix}pvp rematch*_`,
    )
  }
  // ── Yelan's engagement settles here, before anything else ────────────────
  // Both consequences belong to the OTHER PLAYER (their companion dies, they are
  // the one poisoned), so both are written on their own record in one mutator —
  // the same opponent-side discipline every other cross-player effect in this
  // file uses. Then the baton flips and the turn ends: the engagement replaced
  // this player's attack, so no damage may land on the other player from it.
  if (yelanRound) {
    await writeOpponent((opp) => {
        // The engagement is a property of the OTHER player's companion, but the
        // gate that silences it reads its own record (a lib file has no db), so
        // the marker is mirrored here: held while she is still locked with them,
        // cleared the moment she is repelled, kills them, or dies.
        if (opp.battleState) {
          const held = yelanRound.involved && !yelanRound.killed && !yelanRound.repelled
          const sameCharacter = opp.battleState.yelanHeld?.characterId === yelanRound.targetCharacterId
          opp.battleState.yelanHeld = held
            ? {
                characterId: yelanRound.targetCharacterId,
                characterName: yelanRound.targetCharacterName,
                // Narrate the lock once per engagement, not once per turn.
                shown: sameCharacter ? (opp.battleState.yelanHeld?.shown ?? false) : false,
              }
            : null
        }
        if (yelanKill) {
          const targetId = yelanKill.characterId
          if (slayCharacter(opp, targetId)) {
            const name = characterMap[targetId]?.name ?? targetId
            msg += `\n🖤 *${name}* is marked on *${opp.name}*'s record as SLAIN. ` +
              `_They are still owned. They cannot be equipped, and they cannot fight, until a Revival Stone brings them back._\n`
            // Unequip them the same way `.character unequip` does, stat bonuses
            // and all — a dead companion must not keep lending its passive.
            if (opp.equippedCharacter === targetId) {
              const def = characterMap[targetId]
              repairCharacterBonus(opp) // a pre-fix Beth is made whole before her bonus comes off
              if (def?.statBonuses) applyEquipmentBonus(opp, def, -1)
              opp.equippedCharacter = null
              syncEmptyVesselFlag(opp)
              msg += `_(*${name}* has been unequipped — revive them, then: *${config.prefix}character equip ${targetId}*.)_\n`
            }
          }
        }
      if (yelanPoison) {
        const line = applyDeadlyPoison(opp, mixSeed(actorJid, opponentJid, actorSnapshot.battleState?.turn ?? 1))
        if (line) msg += `\n${line}\n`
      }
    })
    const yelanMovedAt = Date.now()
    await updatePlayer(db, actorJid, (actor) => {
      if (!actor.battleState) return
      actor.battleState.myTurn = false
      actor.battleState.turn = (actor.battleState.turn ?? 1) + 1
      actor.battleState.lastMoveAt = yelanMovedAt
    })
    await writeOpponent((opp) => {
      if (!opp.battleState) return
      opp.battleState.myTurn = true
      opp.battleState.lastMoveAt = yelanMovedAt
    })
    // A stolen turn is still a turn of the duel — same rule the incapacitated
    // branch above follows, for the same reason: Ronova's countdown runs on the
    // board, and completeTurn() reads the shared ply id as monotonic.
    const yelanBoundary = await resolveDuelTurnBoundary(db, actorJid, opponentJid)
    if (yelanBoundary.lines.length) msg += yelanBoundary.lines.join('\n') + '\n'
    if (yelanBoundary.kill) {
      const winnerJid = yelanBoundary.kill === 'actor' ? opponentJid : actorJid
      const loserJid = yelanBoundary.kill === 'actor' ? actorJid : opponentJid
      return pvpConclude(db, winnerJid, loserJid, ctx,
        `☠️🌑 *THE END OF THE WORLD* lands while *${getPlayer(db, loserJid)?.name ?? 'they'}* is watching the other fight. _That was the whole point of the countdown._`)
    }
    return ctx.reply(
      msg.trim() + pvpStatusFooter(getPlayer(db, actorJid), getPlayer(db, opponentJid)),
    )
  }

  if (turnEnded) {
    // Skill lookup/MP failure — nothing happened, turn stays with the actor.
    return ctx.reply(msg)
  }

  const eHpBeforeTurn = getPlayer(db, opponentJid)?.hp ?? 0
  const actorForCalc = getPlayer(db, actorJid) // re-read post-mutation (mp spend, etc.)

  // ── Tella's Wonders of You — ambient, once per the actor's own turn, same
  // slot and the same two-call discipline as Frostbind / Absolute One below
  // (this file never nests updatePlayer). She lives on the ACTOR's battleState,
  // so her clock is advanced inside an actorJid mutator (the phase MUST persist)
  // and the plan it returns is applied to the OPPONENT in separate calls. She
  // reads whether the opponent stood down on their own last turn
  // (lastActionWasDefend, stamped at the top of every actor turn) to decide the
  // reprieve. The two world-enders are immune; nothing else in a duel is. She
  // ticks first among the ambient auras, so a forced loss concludes before the
  // rest run; skipped entirely if the opponent is already down this turn.
  const envyOppSnap = hasWitchOfEnvy(actorForCalc) ? getPlayer(db, opponentJid) : null
  // 🏛️ Her halving and her forced loss are harm; under the Sanctum they wait.
  if (envyOppSnap && isOpponentLive(envyOppSnap) && !sanctumShields(envyOppSnap)) {
    const envyOppDefended = envyOppSnap?.battleState?.lastActionWasDefend === true
    let envyPlan = null
    await updatePlayer(db, actorJid, (actor) => {
      if (!actor.battleState) return
      envyPlan = advanceWondersOfEnvy(actor.battleState, {
        context: 'pvp',
        foeName: envyOppSnap?.name ?? 'your rival',
        ownerName: actor.name ?? 'you',
        immune: bypassesWondersOfEnvy(envyOppSnap),
        oppDefendedLast: envyOppDefended,
      })
    })
    if (envyPlan) {
      if (envyPlan.lines) msg += envyPlan.lines + '\n'
      if (envyPlan.art) {
        await sendImageTo(ctx, envyPlan.art, `🖤 ${actorForCalc?.name ?? 'The Witch of Envy'} takes her final form.`, ctx.sender)
      }
      if (envyPlan.halveFraction) {
        await writeOpponent((opp) => {
          if (!isOpponentLive(opp)) return
          opp.hp = Math.max(1, Math.floor(opp.hp * envyPlan.halveFraction))
        })
      }
      if (envyPlan.forcedLoss) {
        await writeOpponent((opp) => {
          opp.hp = 0
          // The "even after the battle" curse: consumed in pvpConclude AFTER the
          // loser is healed, so the 5% it removes reads as a wound that did not
          // close. Stamped only here, so it can never fire on an ordinary KO.
          opp.wondersCursePending = envyPlan.cursePct ?? 0.05
        })
        opponentDefeated = true
      }
    }
    if (opponentDefeated) {
      return pvpConclude(db, actorJid, opponentJid, ctx, msg)
    }
  }

  // ── Miyashi's Frostbind / Nisha's Absolute One — ambient, once per the
  // equipped side's own turn, independent of what action they chose. Both
  // move HP between actor and opponent simultaneously, so — same reason
  // updatePlayer() is never nested elsewhere in this file (see the top-of-
  // function comment) — each is split into two sequential updatePlayer
  // calls (drain the opponent, then apply the corresponding change to the
  // actor) with the amount passed between them as a plain variable.
  // ── Shunya — The Empty Vessel, the drain half ────────────────────────────
  // addStatusEffect() already refuses every DURATION debuff aimed at her, and
  // the secondaryEffect rebound further down hands those back to the caster.
  // These five ambient auras are the channels that bypass both: Frostbind,
  // Absolute One, Clane's bite and the Thousand Shadows Swarm move HP
  // directly, and Alya's Stat Break was landing in the immunity gate and
  // vanishing silently, which read as "Alya's turn did nothing" rather than as
  // the void refusing it.
  // Each now reports what it FAILED to take, and the whole bill is paid by the
  // caster in one place below — carried in these two accumulators because the
  // caster is mutated in a different updatePlayer() call than the target (this
  // file never nests them; see the top-of-function comment).
  //
  // Only ever one entry per turn in practice: a player has exactly one
  // equippedCharacter, so at most one of these four auras can fire.
  let voidReboundDmg = 0
  const voidReboundEffects = []

  // Damage-linked reactions (ability status, pack thorns and lifesteal) are
  // collected while the opponent is being mutated, then applied to the actor
  // in a separate write. Adventurer lifesteal is fixed at 20% of damage dealt.
  let pvpDmgDealtToOpp = 0        // feeds pack and Adventurer lifesteal after the hit resolves
  let pvpDefenderCanReact = false // the defender was struck AND is still standing
  // Avessa's mirror clone eats a blow that was already announced. The headline
  // is printed inside the opponent mutator, before the clone is consulted (it
  // has to be: the clone's own record lives on the defender), so the number is
  // remembered here and the line is re-stated once the clone has actually taken
  // it. See the clone block after this turn's writes.
  let pvpLastHeadlineDamage = 0   // the `👉 *N DMG*` the turn just printed

  let frostbindIntensified = false
  await updatePlayer(db, actorJid, (actor) => {
    // Only touched for the Absolute Zero one-way latch (battleState) — the
    // opponent's HP/effects mutation happens in the next updatePlayer call,
    // once we know here whether the aura is intensified yet.
    if (actor.equippedCharacter === 'miyashi' && actor.battleState) {
      frostbindIntensified = !!actor.battleState.miyashiIntensified
    }
  })
  await writeOpponent((opp) => {
    // 🏛️ The ambient auras below all write onto the far side directly, so each
    // one asks the Sanctum itself: under it, they reach nothing.
    if (!isOpponentLive(opp) || sanctumShields(opp)) return
    const frostbind = tickFrostbindAura(actorForCalc, opp, { miyashiIntensified: frostbindIntensified })
    if (frostbind) {
      msg += frostbind.message + '\n'
      voidReboundDmg += frostbind.reboundDamage ?? 0
      if (frostbind.reboundEffects?.length) voidReboundEffects.push(...frostbind.reboundEffects)
      if (frostbind.intensified && !frostbindIntensified) {
        // Latch flipped this turn — persist it back onto the actor next.
        frostbindIntensified = true
      }
      if (!isCatFormActive(opp) && godMortalDown(opp)) {
        const catMsg = checkYoriichiCatForm(opp)
        if (catMsg) {
          msg += catMsg
        } else {
          opponentDefeated = true
        }
      }
    }
  })
  if (frostbindIntensified) {
    await updatePlayer(db, actorJid, (actor) => {
      if (actor.battleState) actor.battleState.miyashiIntensified = true
    })
  }
  if (opponentDefeated) {
    return pvpConclude(db, actorJid, opponentJid, ctx, msg)
  }

  // ── Avessa's reflection, on its owner's own turn, in the same ambient slot
  // as Frostbind and Tella above. Nothing here touches the opponent's record
  // directly: the plan is applied through the target object and the numbers are
  // reported, so the ordinary pipeline still owns HP.
  if (hasAvessa(actorForCalc) && actorForCalc.battleState?.mirror) {
    const record = actorForCalc.battleState.mirror
    await writeOpponent((opp) => {
      if (!isOpponentLive(opp) || sanctumShields(opp)) return
      const mirror = mirrorTurnLines({ record, owner: actorForCalc, target: opp, battleState: actorForCalc.battleState })
      if (mirror.lines.length) msg += mirror.lines.join('\n') + '\n'
      if (!isCatFormActive(opp) && godMortalDown(opp)) opponentDefeated = true
    })
    if (opponentDefeated) {
      await updatePlayer(db, actorJid, (actor) => { actor.inBattle = false; actor.battleState = null })
      return pvpConclude(db, actorJid, opponentJid, ctx, msg.trim())
    }
  }

  let siphonAmt = 0
  await writeOpponent((opp) => {
    if (!isOpponentLive(opp) || sanctumShields(opp)) return
    // applyAbsoluteOneSiphon mutates BOTH objects it's given — here we only
    // want its drain-from-opponent half, so pass a throwaway proxy for
    // 'player' (its .hp write below is discarded on purpose) and apply the
    // matching heal to the real actor in the next updatePlayer call.
    const proxyActor = { ...actorForCalc }
    const absoluteOne = applyAbsoluteOneSiphon(proxyActor, opp)
    if (absoluteOne) {
      msg += absoluteOne.message + '\n'
      siphonAmt = absoluteOne.drained ?? 0
      // Voided: nothing was drained, so the heal below is skipped and Nisha
      // pays what she reached for instead.
      voidReboundDmg += absoluteOne.reboundDamage ?? 0
    }
  })
  if (siphonAmt > 0) {
    await updatePlayer(db, actorJid, (actor) => {
      actor.hp = Math.min(actor.maxHp, actor.hp + siphonAmt)
    })
  }

  // ── Clane's Crimson Hunger — ambient, once per the actor's own turn, in the
  // same slot as Frostbind / Absolute One above. She is TWO changes on one
  // tick: the BITE lands on the opponent, and the TOLL is paid by the actor out
  // of their own max HP. Both halves are applied through separate
  // updatePlayer() calls for the same reason the two auras above are — this
  // file never nests them — and the actor's Clane book-keeping (fedTotal,
  // killedByHer) rides across on the proxy, since a duel's actor is a
  // post-mutation snapshot and mutating it persists nothing.
  //
  // She is also the only ambient aura that can kill her OWN owner. That is not
  // an accident of the numbers; it is the design on her card, so it concludes
  // the duel: the opponent wins, on the exact terms the void-rebound block
  // below uses when a caster's own reaching hand finishes them.
  let claneOwnerCost = 0
  let claneStateAfter = null
  let claneKilledOwner = false
  await writeOpponent((opp) => {
    if (!isOpponentLive(opp)) return
    const proxyActor = { ...actorForCalc }
    const feed = tickClaneDrain(proxyActor, opp)
    if (!feed) return
    msg += feed.message + '\n'
    claneOwnerCost = feed.ownerCost ?? 0
    claneStateAfter = proxyActor.clane ?? null
    // The bite is an ambient drain, not a hit: a Sanctum or a void refuses it
    // inside tickClaneDrain and reports the rebound here, and the actor pays it
    // in the same settle-up the four other auras feed.
    voidReboundDmg += feed.reboundDamage ?? 0
    if (!isCatFormActive(opp) && godMortalDown(opp)) {
      const catMsg = checkYoriichiCatForm(opp)
      if (catMsg) {
        msg += catMsg
      } else {
        opponentDefeated = true
      }
    }
  })
  if (claneStateAfter || claneOwnerCost > 0) {
    await updatePlayer(db, actorJid, (actor) => {
      if (claneOwnerCost > 0) actor.hp = Math.max(0, (actor.hp ?? 0) - claneOwnerCost)
      if (claneStateAfter) actor.clane = claneStateAfter
      if (godMortalDown(actor)) claneKilledOwner = true
    })
  }
  // Floor first, owner second — the same precedence plugins/attack.js gives a
  // tick that empties the enemy and the owner on the same turn.
  if (opponentDefeated) {
    return pvpConclude(db, actorJid, opponentJid, ctx, msg)
  }
  if (claneKilledOwner) {
    msg += `\n🩸 _*Clane takes the last of what she is owed. The leash goes slack.*_\n`
    return pvpConclude(db, opponentJid, actorJid, ctx, msg)
  }

  // ── Alya's Stat Break — ambient, once per the actor's own turn,
  // independent of which action they chose (mirrors Frostbind/Absolute
  // One above). Keyed off actorForCalc.battleState.turn since that's the
  // actor's own turn counter — opp's bs.turn tracks the OPPONENT's turns,
  // a different count entirely in PvP.
  await writeOpponent((opp) => {
    if (!isOpponentLive(opp) || sanctumShields(opp)) return
    const alyaBreak = applyAlyaStatBreak(actorForCalc, opp, actorForCalc.battleState)
    if (alyaBreak.triggered) msg += alyaBreak.message + '\n'
    if (alyaBreak.reboundEffects?.length) voidReboundEffects.push(...alyaBreak.reboundEffects)
  })

  // ── Megumi's Thousand Shadows Swarm — ambient, once per the actor's own
  // turn, same slot as Frostbind / Absolute One / Stat Break above. It drains
  // the opponent AND heals the actor, so it takes the same split-updatePlayer
  // treatment as Absolute One: run it against a throwaway actor proxy to get
  // the drain half, then apply the heal to the real actor next.
  //
  // The swarm's per-turn counter and the Domain/Mahoraga latches live on
  // bs.megumi, and actorForCalc is a post-mutation SNAPSHOT — mutating it
  // doesn't persist. So the mutated state is carried out in megumiStateAfter
  // and written back onto the actor's real battleState below, or the swarm
  // would restart at turn 1 every single turn.
  let swarmHeal = 0
  let megumiStateAfter = null
  await writeOpponent((opp) => {
    if (!isOpponentLive(opp) || sanctumShields(opp)) return
    const proxyActor = { ...actorForCalc }
    const bsProxy = actorForCalc.battleState
    const swarm = megumiTurnStart(proxyActor, opp, bsProxy)
    if (swarm) {
      msg += swarm.message + '\n'
      swarmHeal = swarm.healed ?? 0
      voidReboundDmg += swarm.reboundDamage ?? 0
      if (swarm.reboundEffects?.length) voidReboundEffects.push(...swarm.reboundEffects)
      megumiStateAfter = bsProxy?.megumi ?? null
      if (!isCatFormActive(opp) && godMortalDown(opp)) {
        const catMsg = checkYoriichiCatForm(opp)
        if (catMsg) {
          msg += catMsg
        } else {
          opponentDefeated = true
        }
      }
    }
  })
  if (megumiStateAfter) {
    await updatePlayer(db, actorJid, (actor) => {
      if (!actor.battleState) return
      actor.battleState.megumi = megumiStateAfter
      if (swarmHeal > 0) actor.hp = Math.min(actor.maxHp, actor.hp + swarmHeal)
    })
  }
  // ── Shunya — The Empty Vessel: the void settles up ───────────────────────
  // Everything the four auras above failed to take is paid here, by the caster,
  // in the caster's own updatePlayer() call. Note what the void does NOT do:
  // she is not healed by a rebounded drain and the caster is not healed either
  // (applyAbsoluteOneSiphon/megumiTurnStart both report healed: 0 when voided).
  // Zero in both directions — otherwise she'd have unkillable sustain against
  // every lifesteal character in the roster.
  //
  // The damage goes through absorbDamage() + applyIncomingDamage(), the same two
  // steps a landed duel hit uses, rather than a raw hp subtraction: a rebound is
  // a real incoming hit with an unusual source, so the caster's shields, relics
  // and reborn-defense all still get their say. checkYoriichiCatForm() is
  // deliberately NOT consulted for the actor — the actor is by definition the
  // one with Miyashi/Nisha/Megumi/Alya equipped, and only one character can be
  // equipped at a time, so no other character's death-save can be live here.
  if (voidReboundDmg > 0 || voidReboundEffects.length) {
    let actorDefeated = false
    await updatePlayer(db, actorJid, (actor) => {
      for (const def of voidReboundEffects) applyReboundEffect(actor, def)
      if (voidReboundDmg > 0) {
        const absorbed = absorbDamage(actor, voidReboundDmg, opp)
        const shielded = voidReboundDmg - absorbed
        const applied = applyIncomingDamage(actor, absorbed, null, true, { ultraInstinctChecked: true })
        if (applied.message) msg += applied.message + '\n'
        msg += `⭕ *${actor.name}* takes *${applied.damage}* from their own reaching hand.\n`
        if (shielded > 0) msg += `🛡️✨ *SHIELD ABSORBED ${shielded} DMG!*\n`
        if (applied.catFormDefeated || godMortalDown(actor)) actorDefeated = true
      }
    })
    if (actorDefeated) {
      // Killed by their own aura on their own turn — so the jids are REVERSED
      // here against every other pvpConclude() call in this function: the
      // opponent standing in the void is the winner.
      //
      // This check deliberately sits AHEAD of the opponentDefeated check below,
      // which is why the payment block moved above it. Megumi is the one case
      // where both sides can drop on the same turn — his swarm rebounds onto him
      // and his Domain's true strikes can still kill her — and the swarm's drain
      // resolves before those strikes do, so the rebound is chronologically
      // first and the void's owner takes the double-KO.
      msg += `\n⭕ _*It was never taken from her. It was only ever given back.*_\n`
      return pvpConclude(db, opponentJid, actorJid, ctx, msg)
    }
  }

  if (opponentDefeated) {
    return pvpConclude(db, actorJid, opponentJid, ctx, msg)
  }

  // ── Opponent takes the hit (skipped entirely for 'defend') ──────────────
  // The dragon's ultimate — true damage, no accuracy roll, no dodge, no
  // beast intervention, no defense math, and deliberately NEVER routed
  // through applyMeiSustainHeal(). Mei's sustain only intercepts damage
  // passed to applyMeiSustainHeal() before it's subtracted from hp (see
  // character-abilities.js) — resolveDragonUltimateDamage() sets opp.hp = 0
  // directly and never calls it, so an opponent equipped with Mei is NOT
  // saved by her sustain-heal against this hit. This is intentional: the
  // ultimate is a guaranteed kill with no exceptions, Mei included.
  // It cannot miss and cannot be mitigated (see lib/dragon-engine.js's file
  // doc comment for why). Yoriichi's cat form (checkYoriichiCatForm) is
  // likewise deliberately NOT checked here for the same reason — a
  // guaranteed kill has no exceptions, full stop. The cinematic sequence itself is sent separately,
  // BEFORE this function's normal turn-status footer, from plugins/pvp.js's
  // runPvpTurn caller — see the dragonUltimateSequence handling right after
  // this block.
  // A turn that lands nothing on the opponent: 'defend', 'endworld' (Ronova's
  // countdown is a declaration, the beam arrives on the turn boundary), and a
  // Wild Card that came up one of the three defensive cards (wildCardMult stays
  // 0 for those — they arm her own battleState instead of hitting anyone).
  // 🌋 Surtr's Twilight and Remnant Ash join that list: both are self-only
  // (Twilight raises her own max HP and ATK, Remnant Ash puts them back), so
  // there is nothing for the opponent's phase to receive. Her two damage skills
  // do NOT skip it.
  const skipsOpponentHit = !!supportSkill || action === 'defend' || action === 'spectate' || action === 'wall' || action === 'endworld' || action === 'hougyoku'
    || action === 'encore'
    || (action === 'fairyspell' && !fairySpellCaster?.enemy)
    || (action === 'wildcard' && wildCardMult <= 0)
    || (action === 'surtr' && surtrSelfOnly)

  const PVP_CHARACTER_ABILITY_ACTIONS = new Set([
    'cinderverdict', 'blazeheart', 'domain', 'hollowpurple', 'kurohitsugi', 'soulpunisher',
    'kamehameha', 'kurama', 'thiefseye', 'wildcard', 'hollowexchange',
    'unlimitedvoid', 'puppetstrings', 'timestop', 'greedtithe', 'sword', 'atomic',
    'encore', 'fairyspell', 'excalibur', 'surtr', 'windup', 'trick', 'heartlock',
  ])
  const lioreiPreAbilitySnap =
    !skipsOpponentHit && PVP_CHARACTER_ABILITY_ACTIONS.has(action)
      ? captureMiniSnapshot(getPlayer(db, opponentJid))
      : null

  let dragonUltimateSequence = null
  if (action === 'ultimate') {
    await writeOpponent((opp) => {
      if (isMasterAdventurer(opp)) {
        msg += `💨👑 *${opp.name}*'s monster LCK and speed outrun the Dragon's descent — *DRAGON ULTIMATE* is dodged completely! *(0 DMG)*\n`
        return
      }
      if (isLeagueAdventurer(opp)) {
        msg += `💨⚡ *${opp.name}* dives clear of the Dragon's breath — *DRAGON ULTIMATE* misses! *(0 DMG)*\n`
        return
      }
      if (actorForCalc?.battleState?.league || opp?.battleState?.league) {
        const capDmg = Math.max(1, Math.floor((opp.maxHp ?? 100) * 0.25))
        opp.hp = Math.max(1, (opp.hp ?? 1) - capDmg)
        msg += `🐉🔥 *${actorForCalc.name}*'s Dragon descends on *${opp.name}* for *${capDmg} DMG*! _(League resilience prevents an instant kill)_\n`
        return
      }
      const result = resolveDragonUltimateDamage(opp)
      dragonUltimateSequence = buildDragonUltimateSequence(actorForCalc.name, opp.name, result.damage)
      if (result.message) dragonUltimateSequence.push(result.message)
      opponentDefeated = result.defeated
    })
    // The dragon belongs to the ACTOR, not the opponent — its sleep flag
    // lives on the actor's own record.
    await updatePlayer(db, actorJid, (actor) => { markDragonAsleep(actor) })
  } else if (action === 'garden') {
    await writeOpponent((opp) => {
      if (isMasterAdventurer(opp)) {
        msg += `💨👑 *${opp.name}*'s monster LCK and reflexes weave through the sixty-six cuts unscathed — *SHADOW GARDEN* is dodged completely! *(0 DMG)*\n`
        return
      }
      if (isLeagueAdventurer(opp)) {
        msg += `💨⚡ *${opp.name}* evades the *SHADOW GARDEN* barrage! *(0 DMG)*\n`
        return
      }
      // The same absolute-hit resolver Sword Maiden uses preserves Yoriichi's
      // cat-form save. No DEF, shields, guard or basic-hit cap touch the cuts.
      const result = gardenStrikes(opp, { applyHit: damage => receiveOpponentCut(opp, damage) })
      msg += result.message + '\n'
      if (result.defeated) opponentDefeated = true
    })
  } else if (action === 'ability') {
    // Abilities use resolveActiveAbility() — the same engine useability.js
    // uses for PvE — rather than the manual attack/skill damage math below,
    // since it already bundles primary damage + secondary effects (burn,
    // weaken, freeze, etc.) as one unit straight from data/abilities.json.
    await writeOpponent((opp) => {
      const bs = opp.battleState
      const ability = findEquippedAbility(actorForCalc, skillQuery)

      const oppStatus = processStatusTurn(opp, { skipHardControl: true })
      if (oppStatus.lines.length) msg += oppStatus.lines.join('\n') + '\n'
      if (!isCatFormActive(opp) && godMortalDown(opp)) {
        const catMsg = checkYoriichiCatForm(opp)
        if (catMsg) { msg += catMsg } else { opponentDefeated = true; return }
      }

      if (isMasterAdventurer(opp)) {
        msg += `💨👑 *${opp.name}*'s monster LCK and reflexes read *${ability.name}* — dodged completely! *(0 DMG)*\n`
        return
      }
      if (isLeagueAdventurer(opp) && (actorForCalc.equippedCharacter === 'urahara' || actorForCalc.equippedCharacter === 'wither')) {
        const stance = actorForCalc.equippedCharacter === 'urahara' ? 'Benihime' : 'Cinder'
        msg += `💨⚡ *${opp.name}* reads ${actorForCalc.name}'s ${stance} stance and dodges *${ability.name}* completely! *(0 DMG)*\n`
        return
      }

      const hitChance = calcPlayerHitChance(actorForCalc, opp)
      if (Math.random() > hitChance) {
        msg += `💨❌ *${actorForCalc.name}'s ${ability.name} MISSED ${opp.name}!*\n`
        if (lucidUntouchable(opp)) msg += lucidUntouchedLine(opp.battleState) + '\n'
        return
      }

      const wasDefending = bs.defending

      // Nisha's Serpent's Grace — checked before resolveActiveAbility() runs
      // since that function writes opp.hp directly with no return value to
      // intercept; a dodge here skips calling it entirely. Yu Miaoyi's sure
      // hits (§3.6) skip the dodge roll itself.
      const dodgeRoll = lucidSureHits(actorForCalc)
        ? { dodged: false }
        : rollSerpentsGrace(opp, { damage: 1, trueDamage: false })
      if (dodgeRoll.dodged) {
        msg += `✨🌟 *${actorForCalc.name} UNLEASHES ${ability.name.toUpperCase()} ON ${opp.name}!* 🌟✨\n`
        msg += dodgeRoll.message + '\n'
        return
      }

      // ⚡ Minato (DEFENDER) — Flying Thunder God, the dodge half, for equipped
      // abilities. Everywhere else his dodge lives in applyIncomingDamage(),
      // but this branch never reaches that funnel (resolveActiveAbility()
      // writes opp.hp directly), so it is asked here for the same reason
      // Serpent's Grace is asked just above: a dodged ability must skip the
      // resolver entirely rather than be refunded afterwards. Only an ability
      // whose primary effect is an ATTACK is dodged: a buff the caster puts on
      // themselves is not a blow, and the flash must not be spent cancelling
      // it. Below the accuracy roll on purpose, so an ability that missed by
      // itself does not spend the flash. A Master Adventurer and Yu Miaoyi's
      // sure hits go through, as they go through every dodge in this branch.
      if (ability.effects?.[0]?.type === 'attack'
          && !isMasterAdventurer(actorForCalc) && !lucidSureHits(actorForCalc)) {
        const flash = rollFlyingThunderGodDodge(opp, opp.battleState, { damage: 1 })
        if (flash.dodged) {
          msg += `✨🌟 *${actorForCalc.name} UNLEASHES ${ability.name.toUpperCase()} ON ${opp.name}!* 🌟✨\n`
          msg += flash.message + '\n'
          bs.defending = false // the turn still happened
          return
        }
      }

      // Megumi (DEFENDER) — Mahoraga adapts to equipped abilities too, each
      // under its own identity ('skill:<abilityId>'). Checked here for the same
      // reason Serpent's Grace is: resolveActiveAbility() writes opp.hp
      // directly with no return value to intercept, so a nullified/evaded
      // ability has to skip calling it entirely rather than refund afterwards.
      // Yu Miaoyi's sure hits walk through the Wheel here too (§3.6).
      const megaAbility = lucidSureHits(actorForCalc)
        ? { damage: 1, wheelCaption: null, nullified: false, dodged: false, message: '' }
        : resolveMegumiIncoming(opp, {
            damage: 1, trueDamage: false,
            kind: 'skill', id: ability.id ?? ability.name ?? '',
            label: `*${ability.name}*`,
            bs: opp.battleState,
          })
      if (megaAbility.wheelCaption) wheelSpinCaption = megaAbility.wheelCaption
      if (megaAbility.nullified || megaAbility.dodged) {
        msg += `✨🌟 *${actorForCalc.name} UNLEASHES ${ability.name.toUpperCase()} ON ${opp.name}!* 🌟✨\n`
        if (megaAbility.message) msg += megaAbility.message + '\n'
        bs.defending = false // the turn still happened
        return
      }
      if (megaAbility.message) msg += megaAbility.message + '\n'

      // Equipped damaging abilities use a separate resolver from attacks. Run
      // it against detached copies to calculate the real post-DEF hit without
      // applying its damage or secondary effects to Audrey before the counter.
      if (opp.battleState?.justiceOfTheMind?.counterReady && ability.effects?.[0]?.type === 'attack'
          && !isMasterAdventurer(actorForCalc) && !lucidSureHits(actorForCalc)) {
        const preview = resolveActiveAbility(ability, structuredClone(actorForCalc), structuredClone(opp))
        const damage = wasDefending ? Math.floor(preview.damage * 0.5) : preview.damage
        justiceReflect = takeJusticeCounter(opp, damage)
        if (justiceReflect > 0) {
          bs.defending = false
          msg += `👁️🪞 *JUSTICE OF THE MIND* turns *${ability.name}* back on *${actorForCalc.name}* for *${justiceReflect}* damage!\n`
          return
        }
      }

      // Yoriichi cat form is already active: resolveActiveAbility() below
      // writes opp.hp directly with no hook to intercept, so instead we let it
      // compute against her pool, then move whatever it took off opp.hp into
      // that pool rather than leaving it on opp.hp.
      //
      // The baseline MUST be the exact value written into opp.hp. It used to be
      // opp.maxHp while the value written was min(maxHp, catHp), so every
      // ability hit was inflated by (maxHp - catHp) — a full pool measured
      // correctly, but a chipped one took hundreds of points of phantom damage
      // and emptied in a single turn. The min(opp.maxHp, ...) clamp is gone for
      // the same reason: her pool is a flat 3,000, past a lot of owners' maxHp,
      // and clamping it truncated the ability's real damage
      // against a fake 0-hp floor.
      const wasCatFormActiveBefore = isCatFormActive(opp)
      const hpForCalc = wasCatFormActiveBefore
        ? Math.max(1, opp.battleState.yoriichiCatFormActive.hp)
        : opp.hp
      if (wasCatFormActiveBefore) opp.hp = hpForCalc

      const { lines, damage: primaryAbilityDamage } = resolveActiveAbility(ability, actorForCalc, opp)
      // Keep the full post-DEF attack number (including overkill), rather than
      // inferring it from a zero-floored HP bar. Guard halves this number too;
      // the existing owner HP refund/pool handling below stays unchanged.
      let ownerAbilityDamage = wasDefending ? Math.floor(primaryAbilityDamage * 0.5) : primaryAbilityDamage
      // resolveActiveAbility() writes opp.hp directly — honor 'defend' by
      // refunding half the damage it just dealt, same 0.5x rule attack/
      // skill apply via applyDefense() above. Measured off hpForCalc so that
      // defending protects Yoriichi's pool too; it used to be skipped outright
      // whenever cat form was up, meaning `.pvp defend` bought her nothing.
      if (wasDefending && hpForCalc > opp.hp) {
        const dealt = hpForCalc - opp.hp
        const refund = Math.ceil(dealt * 0.5)
        opp.hp = Math.min(wasCatFormActiveBefore ? hpForCalc : opp.maxHp, opp.hp + refund)
      }
      bs.defending = false // consumed

      msg += `✨🌟 *${actorForCalc.name} UNLEASHES ${ability.name.toUpperCase()} ON ${opp.name}!* 🌟✨\n`
      if (lines.length) msg += lines.join('\n') + '\n'

      // No armor-wear call here — mirrors PvE's useability.js, which never
      // touches durability for ability use (only attack.js/skill.js do).

      if (wasCatFormActiveBefore) {
        const dealtToCat = Math.max(0, hpForCalc - opp.hp)
        const catResult = resolveCatFormDamage(opp, dealtToCat)
        if (!(catResult.damage > 0)) ownerAbilityDamage = 0 // the owner's attack was dodged
        // Back to the 1 hp checkYoriichiCatForm() pins the owner at while she
        // fights — NOT 0. Setting it to 0 here made the "would this kill them"
        // check at the end of this branch fire on every single ability hit:
        // cat form is already spent by then, so checkYoriichiCatForm() returns
        // '' and the duel was declared over with her pool still nearly full.
        // That is the one-turn death in duels the owner was reporting.
        opp.hp = 1
        if (catResult.message) msg += catResult.message + '\n'
        if (catResult.defeated) {
          msg += buildCatFormDefeatMessage()
          opponentDefeated = true
        }
      }

      // All multi-hit damage and the guard refund have resolved; Texas
      // follows once, never once per hit, and never copies a secondary DoT.
      const texasHit = resolveTexasDuelFollowUp(actorForCalc, opp, ownerAbilityDamage)
      if (texasHit.message) msg += texasHit.message + '\n'
      if (texasHit.defeated) opponentDefeated = true
      // 🔥 Rengoku follows a landed ability the same way he follows a hit.
      {
        const flameCombo = resolveFlameComboDuel(actorForCalc, opp, ownerAbilityDamage)
        if (flameCombo.message) msg += flameCombo.message + '\n'
        if (flameCombo.defeated) opponentDefeated = true
        if (flameCombo.triggered) flameCarry = { ...actorForCalc.battleState.rengoku }
      }

      // Urahara — Tear/Reshape: applies on any actor hit landing in PvP too.
      //
      // This guard used to read `!instinct.dodged && isOpponentLive(opp)`. There
      // is no `instinct` in this branch: an equipped ability never goes through
      // absorbInstinctAttack() (resolveActiveAbility() writes HP itself), so
      // the name only exists in the attack/skill branch further down. Every
      // equipped ability that LANDED in a duel therefore threw a ReferenceError
      // right here, after its damage was already on the defender and before the
      // baton flipped: the caster got an error instead of a turn message, kept
      // the turn, and the hit stood. Anything that reaches this line was not
      // dodged (each dodge above returns early), so the guard is the same one
      // the attack/skill branch uses for the Tear.
      if (isOpponentLive(opp)) {
        const tearLine = applyTearOnHit(actorForCalc, opp, ctx)
        if (tearLine) msg += tearLine + '\n'
      }

      if (godMortalDown(opp)) {
        const catMsg = checkYoriichiCatForm(opp)
        if (catMsg) { msg += catMsg } else { opponentDefeated = true }
      }
    })
  } else if (action === 'hollowexchange') {
    // NOT A HIT, and this branch is deliberately shaped by everything it leaves
    // out: no accuracy roll, no crit, no DEF, no shields, no fight-length damage
    // cap, no on-damage hooks. She trades conditions; she does not strike. The
    // floor inside activateHollowExchange guarantees neither side can be brought
    // to 0, so there is no defeat branch for the exchange itself — the only thing
    // that can end the duel in here is the opponent's own lingering damage.
    await writeOpponent((opp) => {
      const oppStatus = processStatusTurn(opp, { skipHardControl: true })
      if (oppStatus.lines.length) msg += oppStatus.lines.join('\n') + '\n'
      if (!isCatFormActive(opp) && godMortalDown(opp)) {
        const catMsg = checkYoriichiCatForm(opp)
        if (catMsg) { msg += catMsg } else { opponentDefeated = true; return }
      }

      if (isMasterAdventurer(opp)) {
        msg += `💨👑 *${opp.name}*'s monster LCK and overwhelming aura reject *HOLLOW EXCHANGE* — their vitality refuses to be traded!\n`
        hollowRes = { after: { playerHp: actorForCalc.hp } }
        return
      }

      // The real call, re-running the guards the dry run already passed — which
      // CAN legitimately fail by now, because the status tick just above may have
      // dropped the opponent below the floor, leaving nothing to trade for. The
      // charge is still unburned at that point (it is spent in the actor write
      // below, not here), so the honest outcome is to say so and let the turn
      // pass rather than quietly swallow her one exchange.
      const res = activateHollowExchange(actorForCalc, opp, actorForCalc.battleState)
      if (!res.ok) {
        if (res.message) msg += res.message + '\n'
        return
      }
      hollowRes = res
      msg += buildHollowExchangeReveal(actorForCalc, opp, res)
    })

    // Her own half of the trade. activateHollowExchange wrote it onto
    // actorForCalc, which is only a snapshot (line ~1524), so this is the write
    // that actually persists — and the one place the charge is burned.
    if (hollowRes) {
      await updatePlayer(db, actorJid, (actor) => {
        actor.hp = hollowRes.after.playerHp
        if (actor.battleState) actor.battleState.hollowExchangeUsed = true
      })
    }
  } else if (action === 'unlimitedvoid') {
    // Gojo's Unlimited Void — pure control, no damage. The domain floods the
    // opponent with infinite information and locks them out for
    // UNLIMITED_VOID_STUN_TURNS of their turns; the actor-phase incapacitation
    // branch above reads that stun and skips their action each turn until it
    // lifts. Same "does not strike" shape as hollowexchange: no accuracy, no
    // crit, no DEF, no cap, no on-damage hooks, and no defeat branch — the void
    // spends the opponent's action, it does not spend their HP.
    await writeOpponent((opp) => {
      const oppStatus = processStatusTurn(opp, { skipHardControl: true })
      if (oppStatus.lines.length) msg += oppStatus.lines.join('\n') + '\n'
      if (godMortalDown(opp)) {
        const catMsg = checkYoriichiCatForm(opp)
        if (catMsg) { msg += catMsg } else { opponentDefeated = true; return }
      }
      msg += `🌌 *${actorForCalc.name}* opens *UNLIMITED VOID* on *${opp.name}*!\n`
      if (isMasterAdventurer(opp) || isLeagueAdventurer(opp)) {
        msg += `💨👑 _*${opp.name}* steps outside the barrier before the domain closes — completely dodged!_\n`
        return
      }
      // A status-immune opponent (a Shunya owner) leaves the void nothing to
      // fill; addStatusEffect no-sells it and reports immune, same as PvE.
      const res = addStatusEffect(opp, {
        type: 'stun',
        duration: UNLIMITED_VOID_STUN_TURNS,
        sourceId: 'unlimited_void',
      })
      if (res?.immune) {
        msg += `⭕ _There is nothing in ${opp.name} to flood. The void closes on emptiness._\n`
      } else {
        msg += `🕳️ _Infinite information pours in. ${opp.name} cannot move, cannot think, cannot act._\n`
        msg += `💤 _Locked down for the next *${UNLIMITED_VOID_STUN_TURNS}* turns._\n`
      }
    })
  } else if (action === 'puppetstrings') {
    // Red Rose's Puppet Strings — the opponent's OWN attack, turned on them.
    // Not a strike of hers: no accuracy roll, no crit, no fight-length damage
    // cap, no on-damage hooks. resolvePuppetSelfHit builds it from the
    // opponent's own attack/defense and floors it at 20% of their max HP, so it
    // can never finish them — there is no defeat branch for the redirect itself,
    // only for the opponent's own lingering statuses. Then a tangle (a plain
    // stun for PUPPET_TANGLE_TURNS) skips their next turn, companion and all.
    await writeOpponent((opp) => {
      const oppStatus = processStatusTurn(opp, { skipHardControl: true })
      if (oppStatus.lines.length) msg += oppStatus.lines.join('\n') + '\n'
      if (godMortalDown(opp)) {
        const catMsg = checkYoriichiCatForm(opp)
        if (catMsg) { msg += catMsg } else { opponentDefeated = true; return }
      }

      if (isMasterAdventurer(opp) || isLeagueAdventurer(opp)) {
        msg += `💨⚡ *${opp.name}* snaps the threads before they catch — *PUPPET STRINGS* is dodged completely!\n`
        return
      }

      const selfHit = resolvePuppetSelfHit(opp)
      opp.hp = selfHit.newHp

      const tangle = addStatusEffect(opp, {
        type: 'stun',
        duration: PUPPET_TANGLE_TURNS,
        sourceId: 'puppet_strings',
      })

      msg += buildPuppetStringsReveal(actorForCalc.name, opp.name, selfHit, {
        context: 'pvp',
        tangled: !tangle?.immune,
        immune: !!tangle?.immune,
      }) + '\n'
    })
  } else if (action === 'timestop') {
    // Reverie's Time Stop — pure control, no strike of her own. The opponent
    // FREEZES for TIME_STOP_TURNS and the actor-phase incapacitation branch skips
    // their moves until it lifts, the same shape as Unlimited Void's stun.
    //
    // The one exception is Montana: if the opponent has her equipped, she moves
    // faster than the stopped moment, so NO freeze lands — instead she answers
    // with a counter built from her summoner's own offence (resolveMontanaCounter,
    // floored non-lethal like Puppet Strings' redirect). Her HP write is on the
    // opponent record here; the caster's HP loss is deferred to the actor write
    // below, the exact opponent-then-actor split hollowexchange uses.
    await writeOpponent((opp) => {
      const oppStatus = processStatusTurn(opp, { skipHardControl: true })
      if (oppStatus.lines.length) msg += oppStatus.lines.join('\n') + '\n'
      if (godMortalDown(opp)) {
        const catMsg = checkYoriichiCatForm(opp)
        if (catMsg) { msg += catMsg } else { opponentDefeated = true; return }
      }

      if (isMasterAdventurer(opp)) {
        msg += `⏱️ *${actorForCalc.name}* stops time on *${opp.name}*!\n`
        msg += `💨👑 _*${opp.name}*'s monster LCK and aura shatter the frozen instant — *TIME STOP* finds no hold!_\n`
        return
      }

      if (hasMontana(opp)) {
        // Negated. Compute her counter against the caster snapshot (persisted on
        // the real actor record below) — never lethal, so no defeat branch.
        montanaCounter = resolveMontanaCounter(opp, actorForCalc)
        msg += `🕰️ *${opp.name}* has *Montana* — she moves before time can close on her!\n`
        msg += `⛔ _${actorForCalc.name}'s Time Stop finds no hold. The stillness never reaches her._\n`
        msg += montanaCounter.dealt > 0
          ? (montanaCounter.floored
              ? `🗡️ _Faster than the frozen moment, she strikes back for *${montanaCounter.dealt}* — pulling the blow before it can finish anyone._\n`
              : `🗡️ _Faster than the frozen moment, she strikes back for *${montanaCounter.dealt}*, matching ${opp.name} blow for blow._\n`)
          : `🗡️ _She strikes back, but there is almost nothing left of ${actorForCalc.name} to take._\n`
        return
      }

      msg += `⏱️ *${actorForCalc.name}* stops time on *${opp.name}*!\n`
      // A status-immune opponent (a Shunya owner) stands outside the stopped
      // moment; addStatusEffect no-sells the freeze and reports immune, as in PvE.
      const res = addStatusEffect(opp, {
        type: 'freeze',
        duration: TIME_STOP_TURNS,
        sourceId: 'time_stop',
      })
      if (res?.immune) {
        msg += `⭕ _${opp.name} stands outside the stopped moment. Time finds no hold on them._\n`
      } else {
        msg += `❄️ _${opp.name} freezes mid-motion, caught between one instant and the next._\n`
        msg += `🕛 _Frozen for the next *${TIME_STOP_TURNS}* turns while ${actorForCalc.name} acts alone._\n`
      }
    })

    // Montana's counter half — the caster's HP loss, written on the real actor
    // record (montanaCounter was computed against a snapshot above). Floored
    // non-lethal in resolveMontanaCounter, so this can never end the duel.
    if (montanaCounter) {
      await updatePlayer(db, actorJid, (actor) => {
        actor.hp = montanaCounter.newHp
      })
    }
  } else if (action === 'greedtithe') {
    // Echidna's Gospel of Greed - NOT A STRIKE: no accuracy roll, no crit, no
    // DEF, no fight-length damage cap, no on-damage hooks. She reaches through
    // the opponent's pockets - mood decides how much comes out (half their
    // money when amused/capricious, a quarter when displeased; gems stolen
    // from their own wallet on a mood-shaped chance, her holder's granted
    // child adding its stage-scaled cut). Both amounts are floored at zero and
    // capped at what exists - she can never push a wallet negative - so there
    // is no defeat branch for the theft itself, only for the opponent's own
    // lingering statuses. The distraction (a plain stun for
    // GREED_TANGLE_TURNS) skips their next turn, same shape as Puppet
    // Strings' tangle. The holder's credit lands on the actor record below,
    // the exact opponent-then-actor split hollowexchange uses.
    await updateAllPlayers(db, () => {
      const opp=getPlayer(db,opponentJid), actor=getPlayer(db,actorJid)
      if(!opp || !actor)return false
      const oppStatus = processStatusTurn(opp, { skipHardControl: true })
      if (oppStatus.lines.length) msg += oppStatus.lines.join('\n') + '\n'
      if (godMortalDown(opp)) {
        const catMsg = checkYoriichiCatForm(opp)
        if (catMsg) { msg += catMsg } else { opponentDefeated = true; return }
      }

      const inLeagueMatch = Boolean(actorForCalc?.battleState?.league || opp?.battleState?.league || isLeagueAdventurer(opp))
      opp.wallet = opp.wallet ?? { solars: 0, gems: 0 }
      const res = inLeagueMatch || !pvpFundingAllowed(actor,opp)
        ? { solarsTaken: 0, gemsTaken: 0, child: actorForCalc.echidnaChild ?? null }
        : echidnaPvpTithe(opp.wallet, greedMood, { child: actorForCalc.echidnaChild })
      res.solarsTaken = Math.min(PVP_FUNDING_CAP, res.solarsTaken)
      if (!inLeagueMatch) {
        opp.wallet.solars = Math.max(0, (opp.wallet.solars ?? 0) - res.solarsTaken)
        opp.wallet.gems = roundGems(Math.max(0, (opp.wallet.gems ?? 0) - res.gemsTaken))
      }
      actor.wallet ??= {solars:0,gems:0}
      actor.wallet.solars=(actor.wallet.solars??0)+res.solarsTaken
      actor.wallet.gems=roundGems((actor.wallet.gems??0)+res.gemsTaken)
      greedTaken = res

      const distract = isMasterAdventurer(opp)
        ? { immune: true }
        : addStatusEffect(opp, {
            type: 'stun',
            duration: GREED_TANGLE_TURNS,
            sourceId: 'gospel_of_greed',
          })

      msg += buildGreedTitheReveal({
        ownerName: actorForCalc.name,
        enemyName: opp.name,
        mood: greedMood,
        solars: res.solarsTaken,
        gems: res.gemsTaken,
        context: 'pvp',
        childRec: res.child,
        immune: !!distract?.immune,
      }) + '\n'
      return true
    },{requireWrite:true})

    // Both purse changes already settled together; narrate only after the save.
    if (greedTaken && !opponentDefeated && (greedTaken.solarsTaken > 0 || greedTaken.gemsTaken > 0)) {
      const tookBoth = greedTaken.solarsTaken > 0 && greedTaken.gemsTaken > 0
      msg += `🍵 _${tookBoth ? 'Gems and coin' : 'The coin'} settle into ${actorForCalc.name}'s purse. She never looks at what she hands over._\n`
    }
  } else if (action === 'sword') {
    // ── The Absolute Sword, written into the side it was aimed at ──────────
    // Deliberately NOT routed through the mitigation stack below: no accuracy
    // roll, no Serpent's Grace dodge, no Mahoraga nullify, no beast redirect, no
    // shield absorb, no fight-length hit cap, no applyIncomingDamage() passive
    // layer. That is what "absolute" means in lib/witch-heroes.js, it is what
    // docs/witches-and-heroes.md specifies, and it is the same contract the
    // dragon ultimate and Kurohitsugi run on in here. The ONE defender-side save
    // that still applies is Yoriichi standing up, because every death path in
    // this file consults checkYoriichiCatForm() before it declares a loss, and a
    // sword that skipped it would be the "one-turn death in duels" bug again.
    const plan = swordPlan
    await writeOpponent((opp) => {
      const oppStatus = processStatusTurn(opp, { skipHardControl: true })
      if (oppStatus.lines.length) msg += oppStatus.lines.join('\n') + '\n'
      if (!isCatFormActive(opp) && godMortalDown(opp)) {
        const catMsg = checkYoriichiCatForm(opp)
        if (catMsg) { msg += catMsg } else { opponentDefeated = true; return }
      }
      if (!isOpponentLive(opp) || !plan) return

      if (isMasterAdventurer(opp) && (plan.damage > 0 || plan.cinematic === 'coordinate')) {
        msg += `💨👑 *${opp.name}*'s monster LCK and instincts read the unseen coordinate — *ABSOLUTE SWORD* is dodged completely! *(0 DMG)*\n`
        return
      }

      if (plan.strippedShields) {
        opp.activeEffects = (opp.activeEffects ?? []).filter(e => e.type !== 'shield')
      }
      if (plan.brokeGuard) {
        opp.battleState.defending = false
        opp.battleState.playerDefending = false
        if (opp.battleState.witchHeroes) opp.battleState.witchHeroes.returnStroke = false
      }

      const cutLines = []
      const cut = (damage) => {
        const res = receiveOpponentCut(opp, damage)
        if (res.message) cutLines.push(res.message)
        if (res.defeated) opponentDefeated = true
        return res
      }

      if (plan.cinematic === 'coordinate') {
        // Three strikes, resolved one at a time against the real body and
        // stopped the moment there is nothing left to hit. absoluteCutDamage()
        // PRICES a cut and applyAbsoluteCut() is the only thing that SPENDS it:
        // calling absoluteSlash() in here would subtract once on the way in and
        // once again on the way out, which is how an HP bar ends up dropping by
        // double what the text says. A save that fires between cuts is reported
        // as a genuine revive (the renderer prints its "a second life begins"
        // beat off exactly this flag), never invented.
        for (let i = 0; i < 3; i++) {
          if (!isOpponentLive(opp) || godMortalDown(opp)) break
          const price = absoluteCutDamage(actorForCalc, opp, 1)
          const res = cut(price)
          swordStrikes.push({ damage: price, revived: res.saved })
          if (res.defeated || !isOpponentLive(opp)) break
        }
        msg += swordStrikes
          .map((hit, i) => `🎯⚔️ *STRIKE ${i + 1}/3* · *${opp.name}* takes *${hit.damage}*` + (hit.revived ? '\n🐈‍⬛🌱 _A second life begins. She adjusts her grip._' : ''))
          .join('\n') + '\n'
      } else if (plan.damage > 0) {
        cut(plan.damage)
      }
      if (cutLines.length) msg += cutLines.join('\n') + '\n'
      // Only for a turn that actually cut: arming the invisible sword or setting
      // a Return Stroke takes the turn and leaves their HP exactly where it was,
      // and printing a fake "is down to" line under it is how a working command
      // starts looking like a broken one.
      if (plan.damage > 0 || swordStrikes.length) {
        if (godMortalDown(opp) && isCatFormActive(opp)) {
          msg += `🗡️🐈‍⬛ _The cut lands on her, not on ${opp.name}. Pool: ${opp.battleState.yoriichiCatFormActive.hp}/${opp.battleState.yoriichiCatFormActive.maxHp}._\n`
        } else {
          msg += `🗡️❤️‍🔥 *${opp.name}* is down to *${opp.hp}/${opp.maxHp} HP*.\n`
        }
      }
    })
  } else if (action === 'encore') {
    // The lock is written onto the TARGET's battleState — that is the record
    // their own runPvpTurn reads at the top of their next turn (see the
    // `pendingEncore` block). `action` is stored as well as the label so the
    // forced move is a real token (attack vs skill) and, for a skill, the
    // name findSkill() needs. A target who is already holding an Encore simply
    // gets a fresh one: the court does not queue encores.
    await writeOpponent((opp) => {
      if (!isOpponentLive(opp)) return
      const plan = fairyEncorePlan ?? { action: 'attack', skillQuery: '', id: 'attack', name: 'Basic Attack' }
      const set = setFairyEncore(opp.battleState, {
        id: plan.id ?? plan.action ?? 'attack',
        name: plan.name ?? 'Basic Attack',
        action: plan.action ?? 'attack',
        skillQuery: plan.skillQuery ?? '',
      })
      msg += `🎼 *${opp.name}* is caught in the encore — *${set?.label ?? plan.name}* is the only move left.\n`
    })
  } else if (action === 'fairyspell' && fairySpellCaster?.enemy) {
    // Creative Magic's hostile half. Damage goes through the same two funnels a
    // signature move uses — absorbDamage() for shields, then applyIncomingDamage()
    // for every defensive passive (Sanctum, Mei's sustain, cat form, Yoriichi's
    // pool) — so a spell can never quietly bypass a defence that a duel would
    // otherwise honour. The statuses (stun/freeze/weaken) are applied by
    // applyFairySpellEnemy() afterwards, through addStatusEffect, so Shunya's
    // void and the Sanctum refuse them exactly as they refuse any other debuff.
    await writeOpponent((opp) => {
      if (!isOpponentLive(opp)) return
      if (isMasterAdventurer(opp)) {
        msg += `💨👑 *${opp.name}*'s monster LCK reads the incantation and steps out of it completely — *${fairySpellCaster.name}* finds nothing! *(0 DMG)*\n`
        return
      }
      const result = applyFairySpellEnemy(fairySpellCaster, actorForCalc, opp, {
        boss: false,
        // Klaatu's seal belongs to the TARGET's own record: it is their last
        // move the court takes away, and their next turn is where the seal gate
        // reads it.
        sealState: opp.battleState,
        lastMove: opp.battleState.lastMoveUsed ?? null,
        damageSink: (raw) => {
          const instinct = absorbInstinctAttack(opp, raw, actorForCalc)
          const absorbed = instinct.damage
          if (instinct.dodged) msg += '💨 *Ultra Instinct!* Attack dodged.\n'
          const applied = receiveOpponentHit(opp, absorbed, null, true, { ultraInstinctChecked: true })
          if (applied.message) msg += applied.message + '\n'
          if (applied.catFormDefeated) opponentDefeated = true
          return applied.damage
        },
      })
      if (result.lines.length) msg += result.lines.join('\n') + '\n'
      if (result.defeated || (godMortalDown(opp) && !isCatFormActive(opp))) {
        const catMsg = checkYoriichiCatForm(opp)
        if (catMsg) { msg += catMsg } else { opponentDefeated = true }
      }
      if (!opponentDefeated) {
        recordEnemyMove(opp, {
          name: fairySpellCaster.name,
          damage: result.damage,
          kind: 'skill',
          id: fairySpellCaster.id,
        })
      }
    })
  } else if (supportSkill) {
    await writeOpponent((opp) => {
      msg += applySupportRider(opp, supportSkill)
    })
  } else if (!skipsOpponentHit) {
    await writeOpponent((opp) => {
      const bs = opp.battleState

      const oppStatus = processStatusTurn(opp, { skipHardControl: true })
      if (oppStatus.lines.length) msg += oppStatus.lines.join('\n') + '\n'
      if (godMortalDown(opp)) {
        const catMsg = checkYoriichiCatForm(opp)
        if (catMsg) { msg += catMsg } else { opponentDefeated = true; return }
      }

      let skill = null
      if (action === 'skill') {
        skill = resolvePvpSkill(skillQuery, actorForCalc)
        // (already validated above; re-resolved here just to compute damage)
      }

      const moveName = action === 'cinderverdict'
        ? 'CINDER VERDICT'
        : action === 'surtr' ? String(surtrSkill?.name ?? 'SURTR').toUpperCase()
        : action === 'blazeheart' ? 'BLAZE HEART'
        : action === 'windup' ? 'GRAND ESCAPEMENT'
        : action === 'trick' ? 'CARNIVAL INVERSION'
        : action === 'heartlock' ? 'KEY OF THE FIFTH HEART'
        : action === 'excalibur' ? 'EXCALIBUR'
        : action === 'atomic' ? 'I AM ATOMIC'
        : action === 'domain' ? 'CHIMERA SHADOW GARDEN'
        : action === 'hollowpurple' ? 'HOLLOW PURPLE'
        : action === 'kurohitsugi' ? 'KUROHITSUGI'
        : action === 'soulpunisher' ? 'SOUL PUNISHER'
        : action === 'kamehameha' ? 'BIG BANG KAMEHAMEHA'
        : action === 'kurama' ? 'BARYON RASENGAN'
        : action === 'thiefseye' ? (thiefsEyeMove?.name ?? "THIEF'S EYE")
        : action === 'wildcard' ? wildCardMoveName : (skill ? skill.name : 'ATTACK')

      const isSignatureMove = (
        action === 'cinderverdict' || action === 'domain' || action === 'hollowpurple' ||
        action === 'kurohitsugi' || action === 'soulpunisher' || action === 'kamehameha' ||
        action === 'kurama' || action === 'thiefseye' || action === 'wildcard' ||
        action === 'atomic' || action === 'excalibur' || action === 'blazeheart' ||
        action === 'surtr' || action === 'windup' || action === 'trick' || action === 'heartlock'
      )
      const inLeague = Boolean(actorForCalc?.battleState?.league || opp?.battleState?.league || isLeagueAdventurer(opp))
      const attackerIsMasterAdv = isMasterAdventurer(actorForCalc)
      const defenderIsMasterAdv = isMasterAdventurer(opp)
      const defenderIsAdv = isLeagueAdventurer(opp)

      // ── League Adventurer & Character Dodge Rules ──────────────────────────
      // 1. Wither's Cinder Verdict and Urahara/Wither-backed attacks are read
      //    and dodged outright in the League / by League Adventurers.
      if (action === 'cinderverdict' && inLeague) {
        msg += `💨🔥 *${opp.name}* reads the Cinder stance and dodges *CINDER VERDICT* completely! *(0 DMG)*\n`
        return
      }
      if (defenderIsAdv && (actorForCalc?.equippedCharacter === 'urahara' || actorForCalc?.equippedCharacter === 'wither')) {
        const stance = actorForCalc.equippedCharacter === 'urahara' ? 'Benihime' : 'Cinder'
        msg += `💨⚡ *${opp.name}* reads ${actorForCalc.name}'s ${stance} stance and dodges *${moveName}* completely! *(0 DMG)*\n`
        return
      }
      // 2. GM, AM, and LM Adventurers are literal monsters with overwhelming LCK,
      //    resistance, and dodge: they dodge Gogeta's attacks and all other
      //    devastating character signature moves 100% of the time, and roll
      //    high LCK evasion against character-boosted attacks and skills.
      if (defenderIsMasterAdv) {
        if (isSignatureMove) {
          msg += `💨👑 *${opp.name}*'s monster LCK and overwhelming reflexes read *${moveName}* — dodged completely! *(0 DMG)*\n`
          if (action === 'thiefseye' && thiefsEyeMove) {
            recordThiefsEyeDeny(opp, thiefsEyeMove)
          }
          return
        }
        if (Boolean(actorForCalc?.equippedCharacter) || action === 'skill') {
          const advTier = opp?.leagueStandIn?.tier
          const masterDodgeChance = advTier === 'lm' ? 0.65 : advTier === 'gm' ? 0.55 : 0.45
          if (Math.random() < masterDodgeChance) {
            msg += `💨👑 *${opp.name}*'s monster LCK and speed evade *${actorForCalc.name}'s ${moveName}*! *(0 DMG)*\n`
            return
          }
        }
      } else if (defenderIsAdv && isSignatureMove) {
        // Normal Adventurers dodge non-exclusive character signatures outright
        // and evade exclusive signatures at a high rate.
        if (isNonExclusiveCharacter(actorForCalc?.equippedCharacter) || Math.random() < 0.65) {
          msg += `💨⚡ *${opp.name}*'s Adventurer reflexes dodge *${actorForCalc.name}'s ${moveName}*! *(0 DMG)*\n`
          return
        }
      }

      const hitChance = attackerIsMasterAdv ? 1 : calcPlayerHitChance(actorForCalc, opp)
      // 🎭 Fool's Gambit cannot miss — she strikes herself and swaps places, so
      // there is no aim involved. It skips the accuracy roll ONLY: the
      // defender's Serpent's Grace dodge, their beast, and their shield below
      // all still get their say, same as against any other hit. Hollow Purple is
      // the same: it never misses (its imaginary mass erases the space it crosses),
      // but the defender's Serpent's Grace / Mahoraga / shield still apply.
      // Gogeta's two moves are exempt for the reason no character move in the
      // bot rolls accuracy: the cooldown is already burned in the actor phase,
      // so a whiff would read as the command being broken.
      // In a League match, signature moves still roll accuracy against the
      // opponent's evasion/AGI so no character move is a free guaranteed nuke.
      // Excalibur is on that list of no-miss moves too: PvE never rolls
      // accuracy for it (the light fills the room), so a duel must not, and
      // `inLeague` must not put the roll back for it either.
      // Blaze Heart is the same as Gogeta's pair: the charge and the 3rd-move
      // wait are already spent in the actor phase, so outside the League it
      // does not roll. Inside a League match it rolls like every other
      // signature move there.
      // 🌋 Surtr's Laevatain is in the same position as Blaze Heart's — free,
      // every turn — so a whiff outside the League would read as a broken
      // command. The other three either burn a once-per-duel charge (a whiff
      // there is the dice, and is intended) or never aim at anyone.
      const surtrNoRoll = action === 'surtr' && (surtrSelfOnly || surtrSkill?.id === 'laevatain')
      const trioNoRoll = action === 'windup' || action === 'trick' || action === 'heartlock'
      if (!attackerIsMasterAdv &&
          ((inLeague && action !== 'excalibur') || (!wildCardGuaranteedHit &&
          action !== 'hollowpurple' && action !== 'kurohitsugi' && action !== 'soulpunisher' && action !== 'kamehameha' && action !== 'excalibur' && action !== 'blazeheart' && !surtrNoRoll && !trioNoRoll)) &&
          Math.random() > hitChance) {
        msg += `💨❌ *${actorForCalc.name}'s ${moveName} MISSED ${opp.name}!*\n`
        // Yu Miaoyi — untouchable window (§3.5): the miss is hers, not the
        // attacker's aim. Her line reads on the board the same way PvE does.
        if (lucidUntouchable(opp)) msg += lucidUntouchedLine(opp.battleState) + '\n'
        // A whiffed theft still keeps the move. The charge was already burned in
        // the actor phase, and PvE denies in the gate itself — so the deny has
        // to land here too, or a missed duel theft would quietly do nothing.
        if (action === 'thiefseye' && thiefsEyeMove) {
          recordThiefsEyeDeny(opp, thiefsEyeMove)
          msg += `🚫 _${thiefsEyeMove.name} is gone all the same. She kept it._\n`
        }
        return
      }

      // Dance of the Rain — same "just the multiplier" contract as
      // catFormAttackDamage, keyed off the actor's own turn count.
      const danceMult = defenderIsMasterAdv ? 1 : danceOfTheRainMultiplier(actorForCalc, actorForCalc.battleState)
      const moveMult = action === 'cinderverdict'
        ? cinderMult
        : action === 'surtr' ? surtrMult
        : action === 'blazeheart' ? blazeHeartMult
        : (action === 'windup' || action === 'trick' || action === 'heartlock') ? trioMoveMult
        : action === 'atomic' ? atomicMult
        : action === 'domain' ? domainMult
        : action === 'hollowpurple' ? hollowPurpleMult
        : action === 'kurohitsugi' ? kurohitsugiMultiplier(actorForCalc, opp)
        : action === 'soulpunisher' ? soulPunisherMult
        : action === 'kamehameha' ? kamehamehaMult
        : action === 'kurama' ? kuramaMult
        : action === 'thiefseye' ? thiefsEyeMult
        : action === 'wildcard' ? wildCardMult : 1
      const dmgMult = moveMult * catFormAttackDamage(actorForCalc) * danceMult
      const dmgRoll = calcPlayerDamage(actorForCalc, skill, dmgMult)
      const rawDmg = dmgRoll.rawDmg
      // Excalibur is a flat number, not a crit and not a roll. Everything the
      // roll would have contributed is discarded here; every defence that is
      // NOT the DEF stat (the defend stance, shields, Mei's sustain, cat form,
      // the League signature cap below) still applies to what lands, because
      // this hit keeps walking the same funnel as every other.
      const isCrit = action === 'excalibur' ? false : dmgRoll.isCrit
      // Fool's Gambit is their own blow redirected into them — their DEF never
      // gets to mitigate it. Their 'defend' stance below still halves it,
      // since that's a chosen stance rather than a stat. Big Bang Kamehameha is
      // here for the same reason it is in PvE: armour is not a meaningful answer
      // to it. Soul Punisher is deliberately NOT — it is a normal hit, just a
      // strong one, so DEF applies to it.
      // Against Master Adventurers, their monster aura always enforces DEF mitigation.
      const bypassDef = !defenderIsMasterAdv && (wildCardIgnoreDefense || action === 'hollowpurple' || action === 'kamehameha' || action === 'kurohitsugi' || trioBypassDef)
      // Surtr's Flame reaches through a quarter of their DEF: expressed as a
      // reduced defense, exactly like the PvE turn does, so the armour-break and
      // doctrine stages downstream still run normally.
      const surtrTargetDef = action === 'surtr' && surtrDefPierce > 0
        ? Math.max(0, getEffectiveStat(opp, 'def') * (1 - surtrDefPierce))
        : action === 'windup' && trioDefPierce > 0
          ? Math.max(0, getEffectiveStat(opp, 'def') * (1 - trioDefPierce))
          : getEffectiveStat(opp, 'def')
      let dmg = action === 'excalibur' && excaliburArmed
        ? EXCALIBUR_DAMAGE
        : bypassDef ? rawDmg : applyDefense(rawDmg, surtrTargetDef, actorForCalc, opp)
      if (action === 'skill' && skill) {
        const pvpAffLine = formatSkillAffinityBattleLine(actorForCalc, skill, { type: 'pvp' })
        if (pvpAffLine) msg += `${pvpAffLine}\n`
        const pvpChain = resolveBendingPhaseChain(actorForCalc, opp, skill, dmg, { isPvp: true })
        dmg = pvpChain.damage
        if (pvpChain.lines.length) msg += pvpChain.lines.join('\n') + '\n'
      }

      // ── Combo System Hook ──────────────────────────────────────────
      // Check if this PVP action triggers a combo
      const comboActionType = action === 'attack' ? 'basic_attack' : action === 'skill' ? 'skill' : action === 'defend' ? 'defend' : null
      if (comboActionType) {
        const comboResult = recordAbilityUse(actorForCalc, comboActionType)
        if (comboResult.combo) {
          const baseDmg = dmg
          dmg = applyComboBonus(dmg, comboResult.combo)
          msg += `\n${formatComboTrigger(comboResult.combo, comboResult.isNew, baseDmg, dmg)}\n`
        }
      }

      // Thief's Eye floors the echo at THIEFS_EYE_ECHO_MULT times the hit it was
      // copied from. Placed after applyDefense but BEFORE the defend stance on
      // the same principle the Fool's Gambit comment above states: a stolen move
      // ignores the stat, never the choice. The move was tuned against the
      // caster's defense, so re-aiming it is not re-mitigated by DEF — but the
      // opponent choosing to guard this turn still halves what lands.
      if (action === 'thiefseye' && !defenderIsMasterAdv) {
        const echo = resolveThiefsEyeDamage({ echoFloor: thiefsEyeFloor }, dmg)
        dmg = echo.damage
        thiefsEyeEchoed = echo.echoed
      }
      if (bs.defending) dmg = Math.max(1, Math.floor(dmg * 0.5))

      // ── Monster Resistance Aura & League Signature Caps ─────────────────
      if (defenderIsMasterAdv) {
        const advTier = opp?.leagueStandIn?.tier
        const resistMult = advTier === 'lm' ? 0.30 : advTier === 'gm' ? 0.40 : 0.50
        const maxHpCapFrac = advTier === 'lm' ? 0.05 : advTier === 'gm' ? 0.07 : 0.09
        dmg = Math.max(1, Math.floor(dmg * resistMult))
        const masterCap = Math.max(1, Math.floor((opp.maxHp ?? 100) * maxHpCapFrac))
        if (dmg > masterCap) dmg = masterCap
      } else if (defenderIsAdv && isSignatureMove) {
        dmg = Math.max(1, Math.floor(dmg * 0.40))
        const advSigCap = Math.max(1, Math.floor((opp.maxHp ?? 100) * 0.15))
        if (dmg > advSigCap) dmg = advSigCap
      } else if (inLeague && isSignatureMove) {
        const leagueSigCap = Math.max(1, Math.floor((opp.maxHp ?? 100) * PVP_LEAGUE_SIGNATURE_MAX_HP_FRAC))
        if (dmg > leagueSigCap) dmg = leagueSigCap
      }

      // ── Fight-length cap (see PVP_*_HIT_MAX_HP_FRAC up top) ────────────
      // Bound a basic attack / skill to a fraction of the target's MAX HP so
      // no single hit is a one-tap. Applied AFTER defense and the defend
      // stance, so both still matter below the ceiling. Gated to the baseline
      // exchange ONLY: 'cinderverdict'/'wildcard' resolve through this same
      // branch (via moveMult) but must stay uncapped, and cat form on EITHER
      // side is exempt — Yoriichi's 4k-10k pool has its own balance and would
      // be made near-unkillable if a 15%-of-owner-maxHp cap were applied to it.
      //
      // ⚡ Minato — the strike that lands on the seal is DOUBLE the blow it would
      // have been, and "would have been" includes this ceiling. The doubling
      // itself happens upstream, in calcPlayerDamage(); without lifting the cap
      // by the same factor, a duelist who already reaches it (most do) would
      // see the same number on a flash turn as on any other, and the ×2 on the
      // board would be a lie. So the ceiling scales with dmgRoll.flashMult,
      // which is 1 for everyone else and on every ordinary turn. Inside a
      // League match it still stops at the League's own signature ceiling: a
      // fixture bounds every character move, and this is one.
      if ((action === 'attack' || action === 'skill') &&
          !isCatFormActive(actorForCalc) && !isCatFormActive(opp)) {
        const baseFrac = action === 'skill' ? PVP_SKILL_HIT_MAX_HP_FRAC : PVP_BASIC_HIT_MAX_HP_FRAC
        const flashMult = Number(dmgRoll.flashMult) > 1 ? Number(dmgRoll.flashMult) : 1
        const capFrac = flashMult > 1
          ? (inLeague ? Math.max(baseFrac, Math.min(baseFrac * flashMult, PVP_LEAGUE_SIGNATURE_MAX_HP_FRAC)) : baseFrac * flashMult)
          : baseFrac
        const hitCap = Math.max(1, Math.floor(opp.maxHp * capFrac))
        if (dmg > hitCap) dmg = hitCap
      }

      // Nisha's Serpent's Grace — flat dodge chance if the DEFENDER (opp)
      // has Nisha equipped. Same trueDamage exemption as PvE's usage.
      // Master Adventurers pierce character dodge/reflect/wheel passives.
      // Yu Miaoyi's sure hits (§3.6) pierce it too: no dodge mechanic gets a
      // say against her.
      const dodgeRoll = (attackerIsMasterAdv || lucidSureHits(actorForCalc)) ? { dodged: false } : rollSerpentsGrace(opp, { damage: dmg, trueDamage: false })
      if (dodgeRoll.dodged) {
        dmg = 0
        msg += dodgeRoll.message + '\n'
      }

      // ── Megumi (DEFENDER) — Mahoraga's Wheel + the Garden's shadow dodge ──
      // Move identity is the ACTOR's exact move, so `.pvp skill fireball` three
      // times running gets fireball mastered and dealing 0 from then on, and
      // `.pvp attack` three times running does the same to the basic attack.
      // Switching moves starts a fresh 3-count on the new one while everything
      // already mastered stays at 0. The Wheel adapts to signature moves too,
      // each under its own identity (skill:domain, skill:cinderverdict, …).
      const megaKind = action === 'attack' ? 'attack' : 'skill'
      const megaId = action === 'skill' ? (skill?.id ?? skillQuery ?? '') : action
      // Yu Miaoyi's sure hits walk through the Wheel and the Garden's shadow
      // dodge exactly like they walk through Serpent's Grace (§3.6).
      const mega = (attackerIsMasterAdv || lucidSureHits(actorForCalc))
        ? { damage: dmg, wheelCaption: null, message: '' }
        : resolveMegumiIncoming(opp, {
            damage: dmg,
            trueDamage: false,
            kind: megaKind,
            id: megaId,
            label: `*${moveName}*`,
            bs: opp.battleState,
          })
      if (mega.wheelCaption) wheelSpinCaption = mega.wheelCaption
      if (mega.message) msg += mega.message + '\n'
      dmg = mega.damage

      // ── Summon Beast: opponent's beast may redirect this hit ──────────
      // Yu Miaoyi's sure hits cannot be intercepted by a summon (§3.6): the
      // beast never gets the redirect roll against her.
      const beastResult = lucidSureHits(actorForCalc)
        ? { modified: false }
        : beastIntervention(opp, BEAST_EVENT.ENEMY_DEAL_DAMAGE, {
            enemy: actorForCalc,
            bs,
            damage: dmg,
            deferTarget: true, // an attacker is written in their own lane
          })
      if (beastResult.modified) {
        if (beastResult.damage !== undefined) dmg = beastResult.damage
        msg += beastResult.lines.join('\n') + '\n'
      }

      // Justice turns the landed direct hit before shields, follow-ups or
      // secondary effects can touch Audrey. A miss/zero hit does not spend it;
      // Master Adventurers and Yu's explicitly unavoidable hits bypass it.
      justiceReflect = takeJusticeCounter(opp, dmg, {
        unreflectable: attackerIsMasterAdv || lucidSureHits(actorForCalc),
      })
      if (justiceReflect > 0) {
        bs.defending = false
        msg += `👁️🪞 *JUSTICE OF THE MIND* turns *${justiceReflect}* damage back on *${actorForCalc.name}*!\n`
        return
      }

      // ── Sword Maiden and Scarlett, on the RECEIVING end ──────────────────
      // These two are defender-side reactions to a direct hit, so they belong in
      // the exact slot attack.js gives them in a dungeon: after the dodge /
      // Wheel / beast mitigations, before shields and HP. Order between them is
      // the PvE order too (answer first, then the desire), so a duel and a floor
      // cannot disagree about which of her two "she just hit me back" lines you
      // get. Both are absolute, both mutate only state that lives on THIS
      // record (the return-stroke latch, the reflection counter), and both hand
      // back a number the attacker's own write below spends once.
      //
      // Before this existed, none of it ran in a duel at all: a Sword Maiden
      // player could arm a Return Stroke forever and the opponent's swing would
      // walk straight past it, while the same opponent's Scarlett reflected 4k
      // off them in the next dungeon. That asymmetry was the whole complaint.
      const answer = attackerIsMasterAdv ? null : swordReaction(opp, duelProxy(actorForCalc), { directAttack: true })
      if (answer) {
        maidenAnswer = answer.damage
        heroReactions += answer.message + '\n'
      }
      const desire = attackerIsMasterAdv ? null : reflectAttack(opp, duelProxy(actorForCalc), dmg, { indirect: false })
      if (desire) {
        // Her pool turned the blow: she takes nothing, and the amount that was
        // about to land is what walks back. dmg = 0 here is what stops the
        // lifesteal, the riposte and the shield bookkeeping below from crediting
        // a hit that no longer happened.
        desireReflect = desire.reflected
        dmg = 0
        heroReactions += desire.message + '\n'
      }

      // Yu Miaoyi's attacks cannot be reduced to 0 (§3.6): the damage floor
      // is a flag the damage code reads, applied after shields and every
      // mitigation above, right before the universal funnel.
      const instinct = absorbInstinctAttack(opp, dmg, actorForCalc)
      const absorbed = instinct.dodged ? 0 : lucidFloorDamage(actorForCalc, opp, instinct.damage)
      const shieldBlocked = instinct.dodged ? 0 : dmg - absorbed
      if (instinct.dodged) msg += '💨 *Ultra Instinct!* Attack dodged.\n'
      if (bs) bs._incomingFromMasterAdventurer = attackerIsMasterAdv
      const rInfo = {
        godAttacker: actorForCalc,
        godApplyTargetDamage(_target, amount) { diamondReflect += amount; return { message: '' } },
        ultraInstinctChecked: true,
        attackName: action,
        element: attackStatKey(actorForCalc) === 'int' ? 'magic' : 'physical',
        isSpecial: action !== 'attack' && action !== 'defend',
      }
      const applied = receiveOpponentHit(opp, absorbed, null, true, rInfo)
      // The Fourth Wall banks its reflection on the defender's state during
      // their write; collect it here so it settles in the attacker's lane.
      if (bs.regressor?.wallReflectPending > 0) {
        wallReflect += bs.regressor.wallReflectPending
        bs.regressor.wallReflectPending = 0
      }
      if (bs) delete bs._incomingFromMasterAdventurer
      bs.defending = false // consumed

      if (applied.message) msg += applied.message + '\n'
      if (applied.catFormDefeated) opponentDefeated = true
      // 🌋 Surtr's Flame leaves them burning, on the same addStatusEffect() rail
      // every other debuff in this engine uses — so a Sanctum, a void or a
      // status-immune target refuses it exactly as they refuse any other. Only
      // on a hit that drew blood (a turned or dodged blow starts nothing), and
      // never on the killing one.
      let surtrBurnLine = ''
      if (action === 'surtr' && surtrBurn && applied.damage > 0 && isOpponentLive(opp)) {
        const burnAmount = Math.max(1, Math.floor((Number(opp.maxHp) || 0) * SURTR_FLAME_BURN_FRACTION))
        const burnDef = { type: 'burn', amount: burnAmount, duration: SURTR_FLAME_BURN_TURNS, sourceId: 'surtr_flame' }
        if (opp.statusImmune && isNegativeEffect(burnDef.type)) {
          surtrBurnLine = `⭕ *${opp.name}* is the void — the fire finds no purchase.\n`
        } else if (defenderIsMasterAdv) {
          surtrBurnLine = `🛡️✨ *${opp.name}*'s monster resistance smothers the *burn*.\n`
        } else {
          const burnRes = addStatusEffect(opp, burnDef)
          if (burnRes?.immune || burnRes?.blocked) {
            surtrBurnLine = `🚫 _The fire does not take._\n`
          } else {
            surtrBurnLine = `🔥 _Burning for *${SURTR_FLAME_BURN_TURNS}* turns — *${burnAmount}* a turn._\n`
          }
        }
      }
      // Laevatain's own rule: the killing blow stokes the next one. Recorded on
      // the actor's record (which is where the ember lives), read through the
      // snapshot the damage roll already used.
      if (action === 'surtr' && surtrSkill?.id === 'laevatain') {
        noteLaevatainHit(actorForCalc.battleState, { killed: godMortalDown(opp) })
      }
      const actionVerb = action === 'excalibur'
        ? `🔱 unleashes *EXCALIBUR* on`
        : action === 'cinderverdict'
        ? `🔥⚖️ passes *Cinder Verdict* on`
        : action === 'surtr'
        ? `${surtrSkill?.emoji ?? '🌋'} brings *${surtrSkill?.name ?? 'SURTR'}* down on`
        : action === 'blazeheart'
        ? `🔥❤️‍🔥 drives *${BLAZE_HEART_NAME}* through`
        : action === 'windup'
        ? `⚙️🦋 locks *GRAND ESCAPEMENT* around`
        : action === 'trick'
        ? `🎩🎉 casts *CARNIVAL INVERSION* on`
        : action === 'heartlock'
        ? `❤️🔒 turns *KEY OF THE FIFTH HEART* on`
        : action === 'atomic'
          ? `☢️ detonates *I Am Atomic* on`
        : action === 'domain'
          ? `🌑 floods the *Chimera Shadow Garden* over`
          : action === 'hollowpurple'
          ? `🟦🟥 brings *Hollow Purple* down on`
          : action === 'kurohitsugi'
          ? `⬛ seals a *KUROHITSUGI* over`
          : action === 'soulpunisher'
          ? `🔵 puts a *Soul Punisher* through`
          : action === 'kamehameha'
          ? `🔵💥 fires the *BIG BANG KAMEHAMEHA* into`
          : action === 'kurama'
          ? `🦊🌀 folds the Nine Tails into a strike on`
          : action === 'thiefseye'
          ? `👁️🗝️ turns *${thiefsEyeMove?.name ?? "their own move"}* back on`
          : action === 'wildcard'
          ? `${wildCardMoveName === 'WISHING STAR' ? '🌟 drops a *Wishing Star* on' : `🎭 turns *Fool's Gambit* back onto`}`
          : skill ? `unleashes *${skill.name}*` : 'attacks'
      // A blow that took nothing off the other bar is not a critical hit, however
      // the dice fell. `isCrit` is rolled before the defender answers, so a hit
      // that was dodged, absorbed, reflected or nullified used to be announced
      // as "CRITICAL HIT!!" / "The probability breaks." over *0 DMG*, turn after
      // turn, and read as the damage being broken. A blank reads as a blank; the
      // defender's own line, printed just above, says what stopped it.
      const landed = applied.damage > 0
      if (seasonBattleVoiceActive()) {
        // Season 2 ORV voice: keep the named-ultimate callouts and the damage
        // core (the action verbs carry their own prepositions), but read the
        // hit as a scenario advancing instead of an arcade scoreboard.
        const orvHead = !landed ? '🚫 ' : isCrit ? '⚡ Critical.\n' : '⚔️ '
        const orvTail = !landed ? 'Nothing gets through.' : isCrit ? 'The probability breaks.' : 'The scenario records it.'
        msg += `${orvHead}*${actorForCalc.name}* ${actionVerb} 👉 *${applied.damage} DMG* to *${opp.name}*. ${orvTail}\n`
      } else if (!landed) {
        msg += `🚫 *${actorForCalc.name}* ${actionVerb} 👉 *0 DMG* to *${opp.name}*. Nothing gets through.\n`
      } else {
        msg += `${isCrit ? '💥🔥 *CRITICAL HIT!!* 🔥💥\n' : '⚔️ '}*${actorForCalc.name}* ${actionVerb} 👉 *${applied.damage} DMG* to *${opp.name}*! 💢\n`
        // Remembered so the Avessa clone block below can restate what really
        // happened. A clone absorbs the blow, so the defender's HP does NOT
        // move by this number — see the re-statement there.
        pvpLastHeadlineDamage = applied.damage
      }
      // The burn reads after the blow that started it, not before it.
      if (surtrBurnLine) msg += surtrBurnLine
      const texasHit = resolveTexasDuelFollowUp(actorForCalc, opp, applied.damage)
      if (texasHit.message) msg += texasHit.message + '\n'
      if (texasHit.defeated) opponentDefeated = true
      // 🔥 Rengoku — Flame Breathing in a duel. The combo follows the hit that
      // just landed (a basic attack or a skill), off applied.damage, the number
      // that already paid for DEF, the guard, the caps and every defender
      // reaction above. A blow that was dodged or turned (0 damage) is followed
      // by nothing. His own finisher is the end of the string, not a link in
      // it, so Blaze Heart is never followed.
      if (action !== 'blazeheart') {
        const flameCombo = resolveFlameComboDuel(actorForCalc, opp, applied.damage)
        if (flameCombo.message) msg += flameCombo.message + '\n'
        if (flameCombo.defeated) opponentDefeated = true
        if (flameCombo.triggered) flameCarry = { ...actorForCalc.battleState.rengoku }
      }
      // pvpDmgDealtToOpp below remains the OWNER's applied.damage only.
      if (heroReactions) { msg += heroReactions; heroReactions = '' }
      if (action === 'hollowpurple') msg += `🟪 _The clash of Blue and Red erases the space between. No armour softens it._\n`
      if (action === 'kurohitsugi') {
        // Hadō #90 in the duel: the coffin's cast and impact read from the same
        // pools the PvE turn uses (lib/aizen-flavor.js), so a duel's Kurohitsugi
        // sounds like the fight it is, with the enemy's reaction to being sealed
        // inside time that no longer agrees with them.
        const senses = aizenSenses(actorForCalc, actorForCalc.battleState)
        msg += `${kurohitsugiCastLine(senses)}\n`
        if (senses > 0) {
          msg += `_He already owns ${senses}/${AIZEN_MAX_SENSES} of their senses. The seal tightens around what remains._\n`
        }
        msg += `${kurohitsugiImpactLine({ execute: opp.hp > 0 && (opp.hp / (opp.maxHp || 1)) < 0.35, kill: godMortalDown(opp) })}\n`
      }
      if (action === 'soulpunisher') msg += `💠 _A point of ki the size of a fist, across the gap before the sound of it._\n`
      if (action === 'blazeheart') msg += `🔥 _"Set your heart ablaze." Flame Breathing, Ninth Form: one line of fire across the whole arena._\n`
      if (action === 'windup') {
        msg += `⚙️🦋 *Grand Escapement:* enemy turn locked · *${actorForCalc.name}* gains *2 consecutive turns*\n`
      }
      if (action === 'trick') {
        msg += `🎩🔥 *Carnival Inversion:* ignored 100% of *${opp.name}* defense\n`
      }
      if (action === 'heartlock' && isOpponentLive(opp)) {
        const oppTurn = Number(opp.battleState?.turn) || 1
        if (opp.battleState) {
          opp.battleState.remiSealedUntilTurn = oppTurn + (trioSealTurns || 3)
        }
        msg += `🔒💔 *Fifth-Heart Seal:* *${opp.name}* character abilities and regen sealed for *${trioSealTurns || 3} turns*\n`
      }
      {
        const counterRes = flushTrioPendingCounters(opp, actorForCalc)
        if (counterRes.lines.length) msg += counterRes.lines.join('\n') + '\n'
      }
      // 🌋 Surtr — the flavor that belongs to the skill that just landed, and
      // the readout of what she still holds (Twilight running, the giant up,
      // the sword stoked, the Flame spent).
      if (action === 'surtr' && surtrSkill) {
        msg += `📖 _"${surtrSkill.quip}"_\n`
        const footer = surtrStatusLine(actorForCalc, actorForCalc.battleState)
        if (footer) msg += footer + '\n'
      }
      if (action === 'excalibur') msg += `🔱✨ _The light does not care what the armour was made of._ _(ignores DEF)_\n`
      if (action === 'kamehameha') {
        msg += `🌀 _Hands together, elbows locked, and then there is no longer a between._ _(ignores DEF)_\n`
        msg += `💧 _Energy bar spent down to nothing._\n`
      }
      // Instant Transmission refusing to start a cooldown, narrated on the turn
      // the move went off so it does not look like the cooldown is broken.
      if (gogetaExtra) { msg += gogetaExtra + '\n'; gogetaExtra = '' }
      const gogetaFusionLeft = fusionTurnsLeft(actorForCalc, actorForCalc.battleState)
      if ((action === 'soulpunisher' || action === 'kamehameha') && gogetaFusionLeft > 0) {
        msg += `_Fusion of Equals: ${gogetaFusionLeft} turn${gogetaFusionLeft === 1 ? '' : 's'} left._\n`
      }
      if (shieldBlocked > 0) msg += `🛡️✨ *SHIELD ABSORBED ${shieldBlocked} DMG!*\n`

      // ── Xiao's Thief's Eye ────────────────────────────────────────────────
      if (action === 'thiefseye' && thiefsEyeMove) {
        if (thiefsEyeEchoed) msg += `👁️ _The echo lands heavier than the blow that taught it._\n`
        recordThiefsEyeDeny(opp, thiefsEyeMove)
        msg += `🚫 *${thiefsEyeMove.name}* is hers now — *${opp.name}* will not use it again this duel.\n`
      }

      // THIEF'S EYE (copy) — record the actor's move onto the DEFENDER, since
      // the defender is the side who might have Xiao equipped. Same target and
      // the same move identity resolveMegumiIncoming() above already uses.
      //
      // A plain `.pvp attack` is deliberately NOT recorded: it has no name, so
      // there is nothing to steal — matching PvE, where an ordinary monster
      // swinging without naming it writes nothing either. It also has to stay
      // undeniable, or a duelist out of MP could be left with no legal move at
      // all (see applyThiefsEyeDenyGate in lib/character-abilities.js).
      if (action !== 'attack') {
        recordEnemyMove(opp, { name: moveName, damage: applied.damage, kind: megaKind, id: megaId })
      }
      msg += buildDanceOfTheRainMessage(actorForCalc.battleState, actorForCalc)

      // `applied.dodged` is Minato's Flying Thunder God (the only dodge the
      // funnel reports on this path: Ultra Instinct was already rolled above).
      // A burn or a stun riding a blow he was not there for does not stick.
      if (!instinct.dodged && !applied.dodged && skill?.secondaryEffect) {
        const effectDef = buildEffectDef(skill.secondaryEffect, opp, skill.id)
        if (effectDef) {
          // Shunya — The Empty Vessel: a debuff aimed at her finds nothing to
          // hold and rebounds onto the caster. addStatusEffect would already
          // swallow it on `opp` (statusImmune); in a duel the void hands it
          // back instead — actorForCalc is the attacker, in scope right here.
          // If the attacker is ALSO immune, the central gate voids it again.
          if (opp.statusImmune && isNegativeEffect(effectDef.type)) {
            addStatusEffect(actorForCalc, effectDef)
            msg += `⭕ *${opp.name}* is the void — the ${skill.secondaryEffect.type} finds no purchase and *rebounds onto ${actorForCalc.name}*!\n`
          } else if (opp.statusImmuneSilent && isNegativeEffect(effectDef.type)) {
            // Yu Miaoyi's keeper: the same "no negative status ever lands"
            // wall, minus the void's rebound — against her the effect simply
            // fails, in her voice (§3.7).
            msg += `🌙 _The ${skill.secondaryEffect.type} reaches for ${opp.name} and finds the door locked. Yu Miaoyi keeps the keys._\n`
          } else if (defenderIsMasterAdv && isNegativeEffect(effectDef.type)) {
            msg += `🛡️✨ *${opp.name}*'s monster LCK and resistance shrug off the *${skill.secondaryEffect.type}*!\n`
          } else {
            addStatusEffect(opp, effectDef)
            msg += EFFECT_APPLIED_LINE[skill.secondaryEffect.type]?.(opp.name) ?? ''
          }
        }
      }

      const aWear = wearArmorOnHit(opp, absorbed)
      msg += breakMessage(aWear)

      // Urahara — Tear/Reshape: applies on attack/skill hits landing too.
      if (isOpponentLive(opp)) {
        const tearLine = applyTearOnHit(actorForCalc, opp, ctx)
        if (tearLine) msg += tearLine + '\n'
      }

      // Capture the landed hit for the actor-side premium/pack effects applied
      // after this mutator closes (see the accumulators up top). isOpponentLive
      // is already false if this hit downed opp, so a felled defender doesn't
      // riposte or chill — but the actor still lifesteals off the killing blow.
      pvpDmgDealtToOpp += applied.damage
      pvpDefenderCanReact = applied.damage > 0 && isOpponentLive(opp)

      // Yoriichi's cat form — check at the same "would this hit kill them"
      // point Mei's sustain already occupies, since PvP has no
      // handleDeath()/checkTotemRevive() call chain of its own to hook
      // into (see this file's top doc comment: PvP never calls
      // combat-handlers.js). If she triggers, opp.hp stays at 0 (matches
      // the narrative — the owner IS down) but opponentDefeated stays
      // false since Yoriichi is now the one fighting.
      if (godMortalDown(opp)) {
        const catMsg = checkYoriichiCatForm(opp)
        if (catMsg) {
          msg += catMsg
        } else {
          opponentDefeated = true
        }
      }

      // 🦊 Baryon Mode's lifespan drain — a flat share of the opponent's MAX HP
      // as true damage no armour touches, landed AFTER the strike so the two
      // together can finish someone the strike alone left standing. Skipped when
      // the strike already downed them (isOpponentLive false), so it never
      // double-credits a kill, and it runs its own Yoriichi-aware defeat check.
      if (action === 'kurama' && isOpponentLive(opp)) {
        const effectiveDrainPct = inLeague ? Math.min(kuramaDrainPct, 0.08) : kuramaDrainPct
        const drainRes = resolveKuramaDrain(opp, effectiveDrainPct)
        opp.hp = drainRes.newHp
        if (drainRes.drain > 0) {
          msg += `🦊 _The fox's touch drags the lifespan out of *${opp.name}*: *${drainRes.drain}* more, and no armour in the world softens it._\n`
        }
        if (godMortalDown(opp)) {
          pvpDefenderCanReact = false
          const catMsg = checkYoriichiCatForm(opp)
          if (catMsg) { msg += catMsg } else { opponentDefeated = true }
        }
      }

      // ⚡ Second Transcendance (duel) — the equipped Transcendent strikes a
      // SECOND time. A fresh accuracy + damage roll routed through the SAME
      // defensive pipeline the primary hit used (DEF, the fight-length hit-cap,
      // Serpent's Grace, Megumi's Wheel, the Summon Beast, and shields), so no
      // defender's character ability is bypassed — the echo is treated as the
      // real extra hit it is (Mahoraga adapts to it, a mastered move zeroes it,
      // Nisha can dodge it, a shield eats it). Deliberately NONE of the one-time
      // move machinery re-runs: MP was already spent, and the skill's secondary
      // effect / Thief's Eye record / Dance line / move-record above all fired
      // once for the primary. It fires only after a LANDED primary (the miss
      // path returned above) and only for basic attack + skill — the sole
      // actions a Transcendent, being one equipped character, takes here.
      if (!opponentDefeated && isOpponentLive(opp) &&
          hasSecondTranscendance(actorForCalc) &&
          (action === 'attack' || action === 'skill')) {
        if (defenderIsMasterAdv) {
          msg += `⚡💨 *SECOND TRANSCENDANCE* — *${opp.name}*'s monster reflexes dodge the echo strike!\n`
        } else if (Math.random() > calcPlayerHitChance(actorForCalc, opp)) {
          msg += `⚡❌ *SECOND TRANSCENDANCE* — *${actorForCalc.name}*'s echo misses!\n`
        } else {
          const echoRoll = calcPlayerDamage(actorForCalc, skill, catFormAttackDamage(actorForCalc) * danceMult)
          let echoDmg = applyDefense(echoRoll.rawDmg, getEffectiveStat(opp, 'def'), actorForCalc, opp)
          // Same fight-length cap as the primary attack/skill hit — no one-tap.
          if (!isCatFormActive(actorForCalc) && !isCatFormActive(opp)) {
            const echoCap = Math.max(1, Math.floor(
              opp.maxHp * (action === 'skill' ? PVP_SKILL_HIT_MAX_HP_FRAC : PVP_BASIC_HIT_MAX_HP_FRAC),
            ))
            if (echoDmg > echoCap) echoDmg = echoCap
          }
          const echoDodge = rollSerpentsGrace(opp, { damage: echoDmg, trueDamage: false })
          if (echoDodge.dodged) { echoDmg = 0; msg += echoDodge.message + '\n' }
          const echoMega = resolveMegumiIncoming(opp, {
            damage: echoDmg,
            trueDamage: false,
            kind: action === 'attack' ? 'attack' : 'skill',
            id: action === 'skill' ? (skill?.id ?? skillQuery ?? '') : action,
            label: `*SECOND TRANSCENDANCE*`,
            bs: opp.battleState,
          })
          if (echoMega.wheelCaption) wheelSpinCaption = echoMega.wheelCaption
          if (echoMega.message) msg += echoMega.message + '\n'
          echoDmg = echoMega.damage
          const echoBeast = lucidSureHits(actorForCalc)
            ? { modified: false }
            : beastIntervention(opp, BEAST_EVENT.ENEMY_DEAL_DAMAGE, {
                enemy: actorForCalc, bs, damage: echoDmg, deferTarget: true,
              })
          if (echoBeast.modified) {
            if (echoBeast.damage !== undefined) echoDmg = echoBeast.damage
            msg += echoBeast.lines.join('\n') + '\n'
          }
          const echoInstinct = absorbInstinctAttack(opp, echoDmg, actorForCalc)
          const echoAbsorbed = echoInstinct.damage
          const echoShield = echoInstinct.dodged ? 0 : echoDmg - echoAbsorbed
          if (echoInstinct.dodged) msg += '💨 *Ultra Instinct!* Attack dodged.\n'
          const echoApplied = receiveOpponentHit(opp, echoAbsorbed, null, true, { ultraInstinctChecked: true })
          if (echoApplied.message) msg += echoApplied.message + '\n'
          msg += `⚡ *SECOND TRANSCENDANCE* — *${actorForCalc.name}* strikes again 👉 *${echoApplied.damage} DMG* to *${opp.name}*!\n`
          if (echoShield > 0) msg += `🛡️✨ *SHIELD ABSORBED ${echoShield} DMG!*\n`
          if (echoApplied.catFormDefeated) opponentDefeated = true
          if (godMortalDown(opp)) {
            const echoCat = checkYoriichiCatForm(opp)
            if (echoCat) { msg += echoCat } else { opponentDefeated = true }
          }
        }
      }
    })
  } else if (action === 'defend') {
    // Standing down costs nothing except the turn, so this phase exists only for
    // what a guard also does: spend the Transcended Sword. The `defending` flag
    // itself is now written on its OWNER in the actor phase above (see THE GUARD
    // LIVES ON THE GUARDIAN), and read back here is not needed: the cut lands on
    // whoever is holding the sword for, which is the other side.
    if (defendRelease) {
      await writeOpponent((opp) => {
        if (!isOpponentLive(opp)) return
        const res = receiveOpponentCut(opp, defendRelease.damage)
        // The cut's own narration was already added in the actor phase (it is
        // her line, not the adapter's); all that is left is what it cost.
        if (res.message) msg += res.message + '\n'
        if (res.defeated) { opponentDefeated = true; return }
        msg += `🩸 *${opp.name}* is down to *${opp.hp}/${opp.maxHp} HP*.\n`
      })
    }
  }
  if (selfDefeated) return pvpConclude(db, opponentJid, actorJid, ctx, msg.trim())

  // (the remaining skipsOpponentHit cases — a defensive Wild Card and Aizen's
  // Hōgyoku — have nothing to do to the opponent at all: her cards resolve on
  // THEIR swing, and the Hōgyoku is a self-evolution that touches nobody.)

  // ── Cid Kagenou — the flash and the overload (I Am Atomic, duel half) ────
  // Both land whether or not the blast did, exactly as in plugins/atomic.js:
  // the light is the move, and the backlash is what he pays for pushing it
  // out. The flash is a one-turn stun, so the opponent's next turn is spent
  // by the hard-control pass in autoResolveCatFormTurns, the same as any other
  // stun in a duel. A status-immune opponent (Shunya's void, Yu Miaoyi's
  // keeper) is not blinded; addStatusEffect reports immune and nothing lands.
  // Separate top-level writes, one per player, never nested (see the header).
  if (action === 'atomic' && atomicMult > 0 && !opponentDefeated) {
    if (!justiceReflect) {
      await writeOpponent((opp) => {
        if (!isOpponentLive(opp)) return
        if (isMasterAdventurer(opp) || isLeagueAdventurer(opp)) return
        const flash = applyAtomicFlash(opp)
        if (flash.stunned) {
          msg += `💫 The flash blinds *${opp.name}*. They lose their next turn.\n`
        } else if (flash.immune) {
          msg += `⭕ _The flash finds nothing in *${opp.name}* to blind._\n`
        }
      })
    }
    if (atomicBacklashHp > 0) {
      await updatePlayer(db, actorJid, (actor) => {
        const burned = Math.min(atomicBacklashHp, Math.max(0, (actor.hp ?? 0) - 1))
        if (burned > 0) {
          actor.hp -= burned
          msg += `🩸 Backlash: the overload takes *${burned}* HP from *${actor.name}*'s own body.\n`
        }
      })
    }
  }

  // ── Liorei — Snapshot Reverse on enemy character abilities ──────────────
  // Runs in League fixtures too: the League tunes character powers (signature
  // moves are capped at 25% max HP, League Adventurers read Cinder Verdict)
  // rather than switching them off, and this is the same family of in-turn
  // defensive reaction as Aizen's misdirect, which has never been gated. The
  // one thing a League fixture does NOT allow is un-deciding a result, and that
  // is enforced where the result is settled: pvpConclude() concludes the
  // fixture before its lethal Rewind/Hypnosis hooks (see the ordering comment
  // there), so a killing blow ends the match instead of being rewound.
  if (lioreiPreAbilitySnap) {
    let reversedResult = null
    await writeOpponent((opp) => {
      const rev = checkAndApplyMiniSnapshotReverse(opp, lioreiPreAbilitySnap, {
        isCharacterAbility: true,
        characterId: actorForCalc?.equippedCharacter ?? null,
        abilityName: characterMap[actorForCalc?.equippedCharacter]?.ability?.name ?? action,
      })
      if (rev.reversed) {
        reversedResult = rev
        opponentDefeated = false
        pvpDefenderCanReact = false
        pvpDmgDealtToOpp = 0
        maidenAnswer = 0
        desireReflect = 0
        justiceReflect = 0
        msg += rev.message + '\n'
      }
    })
    if (reversedResult?.image && ctx?.sock && ctx?.jid) {
      void sendImageTo(ctx.sock, ctx.jid, reversedResult.image, reversedResult.message).catch(() => {})
    }
  }

  // ── Her answer, paid by the side that swung ─────────────────────────────
  // Two separate reasons these numbers could not be written where they were
  // computed: the defender's HP is being mutated inside their own updatePlayer()
  // right now (this file never nests a write, see the header), and a swing that
  // My Desire turned around has already zeroed `dmg`, so there is nothing left in
  // that mutator for the reflection to come out of. All are absolute: no
  // shield, no absorb, no pack thorns softening them, because a riposte you can
  // armor your way out of is not a punish.
  if (diamondReflect > 0) {
    let down = false
    await updatePlayer(db, actorJid, actor => {
      const absorbed = absorbInstinctAttack(actor, diamondReflect)
      const applied = applyIncomingDamage(actor, absorbed.damage, null, true, { origin: 'god-diamond', ultraInstinctChecked: true })
      if (applied.message) msg += applied.message + '\n'
      msg += `♦️ The rewritten wound deals *${applied.damage}* damage to *${actor.name}*.\n`
      if (godMortalDown(actor)) {
        const saved = checkTotemRevive(actor)
        if (saved) msg += saved + '\n'
        else down = true
      }
      return actor
    })
    if (down && !opponentDefeated) return pvpConclude(db, opponentJid, actorJid, ctx, msg.trim())
  }

  if (maidenAnswer > 0 || desireReflect > 0 || justiceReflect > 0 || wallReflect > 0) {
    const total = maidenAnswer + desireReflect + justiceReflect + wallReflect
    let actorDown = false
    await updatePlayer(db, actorJid, (actor) => {
      const before = actor.hp
      const res = applyAbsoluteCut(actor, total)
      if (res.message) msg += res.message + '\n'
      if (res.defeated) actorDown = true
      else if (before - actor.hp > 0) msg += `💔🗡️ *${actor.name}* wears the answer: *${before - actor.hp}* damage.\n`
    })
    if (actorDown && !opponentDefeated) {
      // Killed by the thing she was waiting for. The duel still ends through
      // pvpConclude, the only ending this file has, and the winner is the side
      // she was guarding against. If BOTH sides are down (her cut landed and the
      // answer landed back), the swing is the older blow and the actor keeps the
      // win: conclude heals both fighters anyway, so nobody walks out of a
      // double KO at 0 HP.
      // Leave both battle records intact for pvpConclude: League fixtures,
      // qualifiers and other match handlers identify their fight from them.
      return pvpConclude(db, opponentJid, actorJid, ctx, msg.trim())
    }
  }

  // ── Damage reactions and lifesteal (actor-side) ──────────────────────────
  // Applied now that the opponent mutator has closed. If the duel continues,
  // the defender's status/thorns effects resolve and the actor heals from damage
  // dealt. Riposte stays non-lethal because PvP has no attacker-death chain
  // (see the cat-form note in the hit block), so a reflect cannot end the duel.
  if (!opponentDefeated && pvpDmgDealtToOpp > 0) {
    const oppSnap = pvpDefenderCanReact ? getPlayer(db, opponentJid) : null
    await updatePlayer(db, actorJid, (actor) => {
      if (actor.leagueStandIn) {
        const sustain = applyAdventurerLifesteal(actor, pvpDmgDealtToOpp)
        if (sustain.healed > 0) msg += sustain.lines.join('\n') + '\n'
      }
      const ls = applyPackLifestealOnDeal(actor, pvpDmgDealtToOpp)
      if (ls.heal > 0) {
        actor.hp = Math.min(actor.maxHp, actor.hp + ls.heal)
        msg += ls.lines.join('\n') + '\n'
      }
      if (oppSnap) {
        const struck = applyStruckReactions(oppSnap, actor, pvpDmgDealtToOpp)
        if (struck.lines.length) msg += struck.lines.join('\n') + '\n'
        // 🏛️ Thorns and counters are harm too: none lands on a Sanctum holder.
        if (struck.counterDamage > 0 && !sanctumShields(actor)) actor.hp = Math.max(1, actor.hp - struck.counterDamage)
      }
    })
  }

  // ── Avessa's reflection eats the blow ──────────────────────────────────
  // The other player brought a mirror clone: whatever this turn landed on them
  // hit the glass first. The clone's own HP is spent instead, and the owner is
  // refunded exactly what it absorbed (capped at their own max HP) — the clone
  // is a bodyguard, not a second health bar. It is destroyed at 0 HP and gone
  // for the rest of the fight (spec 10.3: removable, never permanent).
  if (!opponentDefeated && pvpDmgDealtToOpp > 0) {
    const oppLive = getPlayer(db, opponentJid)
    // hasAvessa gates this too, and not only for tidiness: a duel that was
    // already in flight when this gate was added still carries a phantom
    // `mirror.clone` on its battleState, and without the check that stale
    // record would keep eating hits until the fight ended. Re-checking here
    // means the next blow lands on the player it was aimed at.
    if (hasAvessa(oppLive) && oppLive?.battleState?.mirror?.clone?.hp > 0) {
      let absorbedTotal = 0
      await writeOpponent((opp) => {
        if (!hasAvessa(opp) || !opp.battleState?.mirror?.clone) return
        const absorbed = Math.min(pvpDmgDealtToOpp, opp.battleState.mirror.clone.hp)
        const hit = cloneTakeHit(opp.battleState.mirror, pvpDmgDealtToOpp)
        absorbedTotal = absorbed
        if (absorbed > 0) opp.hp = Math.min(opp.maxHp, (opp.hp ?? 0) + absorbed)
        if (hit.line) msg += hit.line + '\n'
        if (hit.destroyed) msg += `🪞 _The blow passes through nothing and lands on *${opp.name}*._\n`
      })
      // The headline above already announced `👉 *N DMG* to <them>` before the
      // clone was ever consulted, and the clone then refunds the owner exactly
      // what it absorbed — so the defender's real HP moved by ZERO while the
      // turn claimed N. That is the "I deal damage but their health never
      // changes" report, and it is a REPORTING fault, not a damage fault: the
      // clone genuinely did its job. State the outcome instead of leaving the
      // number looking broken. Only printed when the clone actually swallowed
      // the blow; a clone that only part-covered it still moved the bar, and
      // the refund already leaves the right total for the arithmetic to add up.
      if (absorbedTotal > 0 && pvpLastHeadlineDamage > 0) {
        msg +=
          `🪞 *${pvpLastHeadlineDamage} DMG* went into the glass, not into *${oppLive.name}*: ` +
          `*their HP did not change.* The clone has to be destroyed first.\n`
        // A clone is a bodyguard, so no lifesteal or pack thorns are owed on a
        // blow that never reached the duelist. Clearing the accumulator stops
        // the actor healing off damage the defender never took.
        pvpDmgDealtToOpp = 0
        pvpDefenderCanReact = false
      }
    }
  }

  // ── Deduct skill MP cost now that the hit has resolved (actor-side) ─────
  if (action === 'skill') {
    await updatePlayer(db, actorJid, (actor) => {
      const skill = resolvePvpSkill(skillQuery, actor)
      if (skill) {
        const cost = aimiyaFreeCastActive(actor) ? 0 : (skill.mpCost ?? 0)
        actor.mp = Math.max(0, (actor.mp ?? 0) - cost)
        if (cost === 0 && (skill.mpCost ?? 0) > 0) {
          msg += `🎩✨ *Aimiya's Carnival Free-Cast:* *${skill.name}* cost *0 MP*!\n`
        } else {
          const rewindLine = tryCardiaButterflyRewind(actor, skill.name, cost, actor.battleState)
          if (rewindLine) msg += `${rewindLine}\n`
        }
      }
    })
  }

  // ── Set ability cooldown now that it has resolved (actor-side) ──────────
  // Turn-based like useability.js's PvE cooldown model — goes on cooldown
  // whether it hit or missed, since the turn was still spent.
  if (action === 'ability') {
    await updatePlayer(db, actorJid, (actor) => {
      const ability = findEquippedAbility(actor, skillQuery)
      if (ability) {
        actor.battleState.abilityCooldowns = actor.battleState.abilityCooldowns ?? {}
        const currentTurn = actor.battleState.turn ?? 1
        actor.battleState.abilityCooldowns[ability.id] = currentTurn + ability.cooldownTurns
        const rewindLine = tryCardiaButterflyRewind(actor, ability.name, 0, actor.battleState)
        if (rewindLine) msg += `${rewindLine}\n`
      }
    })
  }

  // ── Megumi's media, as their own messages ───────────────────────────────
  // Sent here (after every mutation, before the turn text / any conclude) so
  // the Domain art lands whenever the Garden is opened — including on a turn
  // that ends the duel — and so the Wheel-spin GIF plays right before the
  // ordinary battle message continues, exactly like PvE's attack.js/skill.js.
  if (domainSplash) {
    await sendDomainImage(ctx, `🌑 *CHIMERA SHADOW GARDEN* — the shadows swallow the arena.`, ctx.sender)
  }
  // The beam art, sent only on the turn the gate actually passed. Same
  // "own message" treatment as the Domain splash, and the same reason: the
  // energy bar is already spent, so media must never block the turn text.
  if (kamehamehaSplash) {
    await sendKamehamehaImage(ctx, `🔵💥 *BIG BANG KAMEHAMEHA* 💥🔵`, ctx.sender)
  }
  // 🔥 Rengoku's finishing-move art. Same "own message" treatment, sent only
  // on the turn the Blaze Heart gate actually passed.
  if (blazeHeartSplash) {
    await sendBlazeHeartImage(ctx, `🔥❤️‍🔥 *${BLAZE_HEART_NAME.toUpperCase()}*`, ctx.sender)
  }
  if (wheelSpinCaption) {
    await sendWheelSpin(ctx, wheelSpinCaption, ctx.sender)
  }
  // The Nine Tails summon splash, sent only on the turn the gate passed. Same
  // "own message" treatment as the Domain and beam art: the charge (and Naruto's
  // self-cost) are already spent, so media must never block the turn text.
  if (kuramaSplash) {
    await sendKuramaSummonImage(ctx, `🦊🌀 *${actorForCalc.name} tears the seal open. KURAMA answers.*`, ctx.sender)
  }

  // Delta's return comes out of the defender's own damage funnel. Resolve the
  // pending bill on the other player's record without nesting updatePlayer;
  // direct HP subtraction means it cannot charge another grudge or reflect.
  for (const [holderJid, targetJid] of [[opponentJid, actorJid], [actorJid, opponentJid]]) {
    let debt = 0
    await updatePlayer(db, holderJid, (holder) => {
      debt = holder.battleState?.pendingGrudgeReturn ?? 0
      if (holder.battleState) delete holder.battleState.pendingGrudgeReturn
    })
    if (debt > 0) {
      await updatePlayer(db, targetJid, (target) => {
        // 🏛️ Delta's returned grudge is direct damage: it breaks on the Sanctum.
        if (sanctumShields(target)) { msg += sanctumBreakLine(target) + '\n'; return }
        target.hp = Math.max(0, target.hp - debt)
      })
      if (targetJid === actorJid && getPlayer(db, actorJid).hp <= 0) selfDefeated = true
      if (targetJid === opponentJid && getPlayer(db, opponentJid).hp <= 0) opponentDefeated = true
    }
  }
  // The Golden Knight's Last Stand belongs to its owner's battle state, but
  // the burst hits the other player's actual record. Never nest write lanes.
  for (const [holderJid, targetJid] of [[opponentJid, actorJid], [actorJid, opponentJid]]) {
    if (!(getPlayer(db, holderJid)?.battleState?.pendingBeastCounter > 0)) continue
    let burst = 0
    await updatePlayer(db, holderJid, (holder) => {
      burst = holder.battleState?.pendingBeastCounter ?? 0
      if (holder.battleState) delete holder.battleState.pendingBeastCounter
    })
    if (burst <= 0) continue
    await updatePlayer(db, targetJid, (target) => {
      // Absolute untouchability is checked before shields, which must not be
      // consumed by a burst that never reached their holder.
      if (sanctumShields(target) || lucidUntouchable(target) || dreamstepActive(target)) {
        const blocked = applyIncomingDamage(target, burst)
        if (blocked.message) msg += blocked.message + '\n'
        return
      }
      // The burst comes from the fallen summon, not its owner's player record.
      // Passing that live record as an attacker would let shield reflection
      // mutate it outside its own write lane.
      const instinct = absorbInstinctAttack(target, burst)
      const remaining = instinct.damage
      if (instinct.dodged) msg += '💨 *Ultra Instinct!* Attack dodged.\n'
      const applied = applyIncomingDamage(target, remaining, null, true, { ultraInstinctChecked: true })
      if (applied.message) msg += applied.message + '\n'
      msg += `💥 *Last Stand* deals *${applied.damage}* damage to *${target.name}*.\n`
      let defeated = applied.catFormDefeated
      if (!defeated && godMortalDown(target)) {
        const cat = checkYoriichiCatForm(target)
        if (cat) msg += cat
        else defeated = true
      }
      if (defeated && targetJid === actorJid) selfDefeated = true
      if (defeated && targetJid === opponentJid) opponentDefeated = true
    })
  }
  if (selfDefeated && !opponentDefeated) return pvpConclude(db, opponentJid, actorJid, ctx, msg.trim())

  if (opponentDefeated) {
    // Dragon ultimate — post the cinematic as its own short-delay message
    // sequence BEFORE the normal victory summary (pvpConclude's own reply),
    // so it reads as a scene rather than one wall of text. See
    // lib/dragon-engine.js's buildDragonUltimateSequence() doc comment. The
    // final beat goes out via sendImageTo (with the 'dragon-ultimate' art
    // key from lib/image.js) instead of a plain reply, so the kill lands
    // with art once a URL is registered there — missing art safely falls
    // back to plain text, same as every other sendImageTo call in this file.
    if (dragonUltimateSequence) {
      const last = dragonUltimateSequence.length - 1
      for (let i = 0; i < dragonUltimateSequence.length; i++) {
        const part = dragonUltimateSequence[i]
        if (i === last) {
          await sendImageTo(ctx, 'dragon-ultimate', part, ctx.sender)
        } else {
          await ctx.reply(part)
        }
        await sleep(1400)
      }
      // Fight-ending dragon kill — no next turn to pass to, so the normal
      // "TURN PASSES TO ..." status footer (built further down for the
      // non-ultimate path) doesn't apply here. Replace it with the dragon's
      // own rest note instead, folded into pvpConclude's reasonLine below.
      msg += buildDragonRestFooter(actorForCalc.name)
    }
    // A Coordinate that ends a duel is played rather than reported: the three
    // strikes as they were actually resolved, then the art with the turn text on
    // it, then the summary. Only on the kill path; when the duel continues, the
    // same scene travels as opts.cinematic on the turn frame below so one scene
    // stays in one message and no generic card is stacked under it.
    if (swordStrikes.length) {
      await showCoordinate(ctx, swordStrikes, msg.trim(), { participants: [actorJid, opponentJid] })
      // Settlement owns restoration and state cleanup in the same save as funds.
      // The scene above already carried the turn text, so the summary gets the
      // shortest honest reason line instead of the whole message twice.
      return pvpConclude(db, actorJid, opponentJid, ctx,
        `🎯 *THE COORDINATE* · three strikes, one ending. _She was already where they were going._`)
    }
    // Keep the battle token until atomic conclusion claims it.
    return pvpConclude(db, actorJid, opponentJid, ctx, msg.trim())
  }

  // A summon's own special follows an ordinary committed move too.
  if (await resolveSummonTurn()) return pvpConclude(db, actorJid, opponentJid, ctx, msg.trim())

  if (selfDefeated) return pvpConclude(db, opponentJid, actorJid, ctx, msg.trim())

  // Heart's third combatant follows a committed owner move. Keep the intent
  // on the owner's record and its application receipt on the opponent's;
  // neither record is mutated while the other player's writer is held.
  if (battleGodReady(getPlayer(db, actorJid), 'alenious')) {
    let plan = null
    await updatePlayer(db, actorJid, actor => {
      if (!inPvp(actor)) return actor
      const enemy = getPlayer(db, opponentJid)
      if (!inPvp(enemy)) return actor
      const bs = actor.battleState
      plan = bs.godPendingSummon ?? planGodSummonTurn({ player: actor, enemy, turnId: bs.turn, mode: bs.wager ? 'wager' : bs.league ? 'league' : bs.warId ? 'guild-war' : 'pvp' })
      if (plan) bs.godPendingSummon = plan
      return actor
    })
    if (plan && plan.opponentId === opponentJid) {
      let down = false
      let rebounds = []
      let tithe = null
      let accepted = false
      let applied = false
      await writeOpponent(opponent => {
        if (!inPvp(opponent) || opponent.battleState.opponentJid !== actorJid) return opponent
        const receipts = opponent.battleState.godSummonReceipts ??= {}
        if (receipts[plan.id]) { accepted = true; tithe = receipts[plan.id].tithe ?? null; rebounds = receipts[plan.id].rebounds ?? []; down = godMortalDown(opponent); return opponent }
        const result = applyGodTargetEffects(opponent, plan, { pvp: true })
        down = result.catFormDefeated
        rebounds = result.rebounds
        tithe = result.tithe
        accepted = true
        if (result.lines.length) msg += result.lines.join('\n') + '\n'
        if (!down && godMortalDown(opponent)) {
          const saved = plan.spade ? null : checkYoriichiCatForm(opponent) || checkTotemRevive(opponent)
          if (saved) msg += saved + '\n'
          else down = true
        }
        opponent.battleState.godSummonReceipts[plan.id] = { rebounds, tithe }
        applied = true
        return opponent
      })
      await updatePlayer(db, actorJid, actor => {
        if (!accepted) return actor
        const creditLines = creditSummonTithe(actor, plan, tithe)
        if (creditLines.length) msg += creditLines.join('\n') + '\n'
        const reboundLines = applyGodSummonRebounds(actor, plan, rebounds)
        if (reboundLines.length) msg += reboundLines.join('\n') + '\n'
        if (!plan.spade && actor.battleState?.godPendingSummon?.id === plan.id) delete actor.battleState.godPendingSummon
        return actor
      })
      if (applied && plan.lines.length) msg += plan.lines.join('\n') + '\n'
      if (down) return pvpConclude(db, actorJid, opponentJid, ctx, msg.trim(), { allowRewind: !plan.spade })
    }
  }

  // ── Flip the turn ──────────────────────────────────────────────────────
  // actor.battleState.turn tracks how many turns THIS player has taken —
  // used purely for ability cooldown math (readyAtTurn comparisons above),
  // same per-player counter model useability.js uses for PvE.
  // lastMoveAt is stamped on BOTH sides: the waiting player reads their own
  // battleState to decide whether `.pvp claim` is available yet, so a stamp
  // on only one record would leave the other's timer running from accept.
  const movedAt = Date.now()

  // ── Gambit engine: name the shape of the duel, chess-commentary style ────
  // The ply log lives identically on both battleStates (mirrored on every
  // flip), so detection sees the whole game no matter who moves next. We're
  // past all the early returns here, so `action` definitely executed this turn.
  const prevLog   = actorSnapshot.battleState.gambitLog ?? []
  const prevSeen  = actorSnapshot.battleState.gambitsSeen ?? []
  const gambitLog = [...prevLog, action]
  const newGambits = detectGambits(gambitLog, prevSeen)
  const gambitsSeen = newGambits.length
    ? [...prevSeen, ...newGambits.map(g => g.name)]
    : prevSeen

  let cardiaKeptTurn = false
  let cardiaExtraLeft = 0
  await updatePlayer(db, actorJid, (actor) => {
    // Sword Maiden's resource bar advances once after this player's completed
    // PvP turn, not merely because a sword command was submitted. The skill
    // itself still requires both stored charge and its MP cost. A sword
    // technique is therefore the one action in a duel that does NOT recharge:
    // it has already spent what it is asking to be refilled with.
    if (action !== 'sword') chargeSwordTurn(actor)
    if ((actor.battleState.cardia?.extraTurns ?? 0) > 0) {
      actor.battleState.cardia.extraTurns -= 1
      cardiaKeptTurn = true
      cardiaExtraLeft = actor.battleState.cardia.extraTurns
      actor.battleState.myTurn = true
    } else {
      actor.battleState.myTurn = false
    }
    actor.battleState.turn = (actor.battleState.turn ?? 1) + 1
    actor.battleState.lastMoveAt = movedAt
    actor.battleState.gambitLog = gambitLog
    actor.battleState.gambitsSeen = gambitsSeen
    // 🔥 Rengoku's Flame Breathing chain, advanced during the opponent's write
    // above and persisted here, in the actor's own lane.
    if (flameCarry) actor.battleState.rengoku = flameCarry
  })
  await writeOpponent((opp) => {
    opp.battleState.myTurn = !cardiaKeptTurn
    opp.battleState.lastMoveAt = movedAt
    opp.battleState.gambitLog = gambitLog
    opp.battleState.gambitsSeen = gambitsSeen
  })
  if (cardiaKeptTurn) {
    const holderName = getPlayer(db, actorJid)?.name ?? 'You'
    msg +=
      `⚙️🦋 *Cardia · Grand Escapement!* Brass butterfly gears hold the turn baton — *${holderName}* acts AGAIN immediately! ` +
      `_(${cardiaExtraLeft > 0 ? `${cardiaExtraLeft} more consecutive action queued after this` : 'final consecutive turn now'})_\n`
  }

  // ── The duel-wide turn boundary (Ronova's countdown, the shared ply id) ──
  // Runs after both per-player writes so it sees the same board the players do,
  // and BEFORE the frame is rendered so the countdown line, the phase-two flip
  // and a beam that ends the duel are all part of THIS turn's message rather
  // than a stray text nobody asked for. See resolveDuelTurnBoundary().
  const boundary = await resolveDuelTurnBoundary(db, actorJid, opponentJid)
  if (boundary.lines.length) msg += boundary.lines.join('\n') + '\n'
  if (boundary.kill) {
    // The End of the World is an ending, not a hit. The scene is played first
    // (vortex, the drawn sword, then the turn text glitched back into place) and
    // the duel then settles through pvpConclude, the only ending this file has,
    // with a SHORT reason line rather than the whole scene again: pvpConclude
    // prints its own summary underneath, and repeating the narration is how one
    // kill ends up reading as two. Both sides are healed and cleared by the
    // conclusion, so the loser of a beam never walks out of a duel at 0 HP.
    const winnerJid = boundary.kill === 'actor' ? opponentJid : actorJid
    const loserJid = boundary.kill === 'actor' ? actorJid : opponentJid
    const loserName = getPlayer(db, loserJid)?.name ?? 'They'
    await showEndworldClash(ctx, msg.trim(), { participants: [actorJid, opponentJid] })
    return pvpConclude(
      db, winnerJid, loserJid, ctx,
      `☠️🌑 *THE END OF THE WORLD* lands on *${loserName}*. _No save, no second life, no argument._`,
    )
  }

  // The baton just landed on the opponent. If Yoriichi is fighting for them, she
  // takes it immediately and hands it straight back — their owner is unconscious
  // and never gets a turn, so nothing here may leave the duel waiting on them.
  // This is also the ONLY place a cat form's turn comes from in a normal duel.
  //
  // Yu Miaoyi is the exception. Her driven turn renders its OWN frame, so
  // running her here, before this turn's frame went out, made the chat read
  // backwards: her answer first, then the move she was answering. When the
  // baton just landed on a possessed holder, this frame is sent first and her
  // loop runs after it (see the bottom of this function).
  const nextHolder = getPlayer(db, opponentJid)
  const lucidAnswersNext = Boolean(nextHolder?.battleState?.myTurn) && isLucidBattle(nextHolder)
  if (!lucidAnswersNext) {
    const catAuto = await autoResolveCatFormTurns(db, ctx, actorJid, opponentJid, { lead: msg })
    if (catAuto.concluded) return
    msg += catAuto.text
  }

  // Engine annotation goes at the very top of the turn text, like a caption.
  if (newGambits.length) msg = formatGambits(newGambits) + '\n' + msg

  const actorFinal = getPlayer(db, actorJid)
  const oppSnapshot = getPlayer(db, opponentJid)
  // Circe's board state — what's still armed and how many draws she has left.
  // Only shown on her own Wild Card turns; the rest of the duel reads normally.
  if (action === 'wildcard') {
    const g = circeGuardStatus(actorFinal)
    const armed = []
    if (g.finalDash) armed.push(`🃏 _Final Dash armed_`)
    if (g.lastLaugh > 0) armed.push(`🤡 _Last Laugh ${g.lastLaugh}t_`)
    if (g.butterfly > 0) armed.push(`🎪 _Copies ${g.butterfly}t_`)
    if (armed.length) msg += armed.join(' · ') + '\n'
    msg += `🎟️ _Draws left: ${wildCardUsesLeft(actorFinal)}/${WILD_CARD_MAX_USES}_\n`
  }
  msg += pvpStatusFooter(actorFinal, oppSnapshot)

  await sendWillowAdvisory(ctx, actorFinal, oppSnapshot, false, actorJid)
  await sendBattleTurnReply(ctx, {
    player: actorFinal, e: oppSnapshot, msg,
    hpBeforeTurn, eHpBeforeTurn,
    isPvp: true,
    isDefending: action === 'defend',
    // A resolved scene, never an intent: presentResolvedCinematic() renders
    // exactly the strikes this duel already settled, replaces the generic card
    // for that turn, and hands the whole turn text back as the final beat.
    cinematic: swordStrikes.length
      ? { type: 'coordinate', strikes: swordStrikes, finalText: msg, participants: [actorJid, opponentJid] }
      : null,
  })

  // ── Spectator Broadcast ───────────────────────────────────────────────
  // Send the turn update to all spectators watching this duel
  await broadcastSpectatorUpdate(actorJid, msg)

  // Now that this turn is on screen, the possessed holder answers it. Her
  // turns post their own frames; anything else the loop produced (a forced
  // pass, say) gets one short message with the board under it.
  if (lucidAnswersNext) {
    const yuAuto = await autoResolveCatFormTurns(db, ctx, actorJid, opponentJid, { lead: '' })
    if (!yuAuto.concluded && yuAuto.text.trim()) {
      const a = getPlayer(db, actorJid)
      const b = getPlayer(db, opponentJid)
      if (inPvp(a) && inPvp(b)) await ctx.reply(yuAuto.text.trim() + pvpStatusFooter(a, b)).catch(() => {})
    }
  }
}

/** Bare `.spectate` is Audrey's active only when she is in a duel. */
export async function pvpSpectate(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) return ctx.reply(`👁️ _Justice of the Mind answers in a duel._`)
  if (isWagerState(player.battleState)) return runPvpTurn(ctx, 'spectate', '')
  if (!hasAudrey(player)) return ctx.reply('👁️ *Justice of the Mind* belongs to Audrey Hall. Equip her first.')
  const opponent = getPlayer(ctx.db, player.battleState.opponentJid)
  if (player.battleState.justiceOfTheMind?.used && opponent) return ctx.reply(justiceReadout(opponent, player))
  return runPvpTurn(ctx, 'spectate', '')
}

/**
 * pvpCinderVerdict(ctx) — entry point for the top-level `.cinderverdict`
 * command (plugins/cinderverdict.js) when the caller is in a duel rather than
 * a PvE fight. plugins/cinderverdict.js only knows the PvE battleState shape
 * (bs.enemy), so it delegates here when battleState.type === 'pvp'. This just
 * routes into the normal PvP turn engine as the 'cinderverdict' action, which
 * gates on Wither being equipped and the once-per-battle charge.
 */
/**
 * pvpWall(ctx) — entry point for `.wall` (plugins/wall.js) inside a duel.
 * Routes into the turn engine as the 'wall' action (Kim Dokja equipped,
 * once per duel). A wager duel refuses it at runPvpTurn's wager guard,
 * like every other character power.
 */
export async function pvpWall(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  return runPvpTurn(ctx, 'wall', '')
}

export async function pvpCinderVerdict(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  return runPvpTurn(ctx, 'cinderverdict', '')
}

/**
 * pvpBlazeHeart(ctx) — entry point for the top-level `.blaze-heart` command
 * (plugins/blaze-heart.js) when the caller is in a duel. Same delegation as
 * pvpCinderVerdict above: the plugin only knows the PvE battleState shape, so
 * a duel routes into the turn engine as the 'blazeheart' action, which gates
 * on Rengoku being equipped, the once-per-battle charge and the 3rd-move
 * rule. A wager duel refuses it at runPvpTurn's wager guard, like every other
 * character power.
 */
export async function pvpBlazeHeart(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  return runPvpTurn(ctx, 'blazeheart', '')
}

export async function pvpWindup(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) return ctx.reply(`❌ You're not in a duel.`)
  return runPvpTurn(ctx, 'windup', '')
}

export async function pvpTrick(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) return ctx.reply(`❌ You're not in a duel.`)
  return runPvpTurn(ctx, 'trick', '')
}

export async function pvpHeartlock(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) return ctx.reply(`❌ You're not in a duel.`)
  return runPvpTurn(ctx, 'heartlock', '')
}

/**
 * pvpAtomic(ctx) — entry point for the top-level `.atomic` command
 * (plugins/atomic.js) when the caller is in a duel. Same delegation as
 * pvpCinderVerdict: plugins/atomic.js only knows the PvE battleState shape, so
 * a duel routes here as the 'atomic' action, which gates on Cid being equipped
 * and the once-per-battle charge. A wager duel refuses it in runPvpTurn (no
 * character powers there), and a League fixture never reaches it.
 */
export async function pvpAtomic(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  return runPvpTurn(ctx, 'atomic', '')
}

/**
 * pvpExcalibur(ctx) — entry point for the top-level `.excalibur` command
 * (plugins/excalibur.js) when the caller is in a duel or a live League fixture.
 * Same delegation shape as pvpAtomic(): plugins/excalibur.js only knows the PvE
 * battleState shape (bs.enemy), so a duel hands off here and routes into the
 * turn engine as the 'excalibur' action. That action runs lib/starfall-kits.js's
 * own armExcalibur() gate — Saber equipped, the sword in the weapon slot, once
 * per battle — and then lands the same flat 3000 PvE does, with DEF skipped and
 * every defender reaction in this file still able to answer it. A wager duel
 * refuses it at the top of runPvpTurn(), like every other character power.
 */
export async function pvpExcalibur(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  return runPvpTurn(ctx, 'excalibur', '')
}

/**
 * pvpVictory(ctx) — `.victory` (plugins/victory.js) in a duel. Routes into the
 * turn engine as the 'victory' action, which raises Victoria Minayoko's
 * Sanctum Victoriae (gate: equipped, from her turn 6, once per duel — see
 * lib/victoria.js). A League fixture reaches the same action through
 * playLeagueMove(), and a wager duel refuses it at the top of runPvpTurn().
 */
export async function pvpVictory(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  if (!player.battleState.myTurn) {
    return ctx.reply(`⏳ It's not your turn yet — wait for your opponent to move.`)
  }
  return runPvpTurn(ctx, 'victory', '')
}

/**
 * pvpKurama(ctx) — entry point for the top-level `.kurama` command
 * (plugins/kurama.js) when the caller is in a duel rather than a PvE fight.
 * plugins/kurama.js only knows the PvE battleState shape (bs.enemy), so it
 * delegates here when battleState.type === 'pvp'. This just routes into the
 * normal PvP turn engine as the 'kurama' action, which gates on Naruto being
 * equipped and burns the once-per-battle charge plus his Baryon self-cost.
 */
export async function pvpKurama(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  return runPvpTurn(ctx, 'kurama', '')
}

/**
 * pvpSurtr(ctx, skillId) — entry point for `.surtr` (plugins/surtr.js) when the
 * caller is in a duel. Same delegation as pvpBlazeHeart(): plugins/surtr.js only
 * knows the PvE battleState shape, so a duel hands off here and routes into the
 * turn engine as the 'surtr' action with the skill as skillQuery. NOTHING is
 * gated here — lib/surtr.js's own activate*() gates run inside runPvpTurn's
 * actor phase, where a refusal costs neither the turn nor the charge. A wager
 * duel refuses it at the top of runPvpTurn, like every other character power.
 */
export async function pvpSurtr(ctx, skillId = null) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  return runPvpTurn(ctx, 'surtr', String(skillId ?? '').trim().toLowerCase())
}

/**
 * pvpDomain(ctx) — entry point for the top-level `.domain-expansion` command
 * (plugins/domain-expansion.js) when the caller is in a duel rather than a PvE
 * fight. Same delegation shape as pvpCinderVerdict() above: the PvE plugin only
 * knows the PvE battleState shape (bs.enemy), so it hands off here when
 * battleState.type === 'pvp'. Routes into the normal PvP turn engine as the
 * 'domain' action, which gates on Megumi being equipped and on the Garden not
 * already being open (see activateChimeraDomain() in lib/megumi.js).
 */
export async function pvpDomain(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  return runPvpTurn(ctx, 'domain', '')
}

/**
 * inPvpDuel(player) — exported read-only check for plugins/ultimate.js so it
 * can give a friendly error without duplicating inPvp()'s logic. Same
 * definition as the private inPvp() above.
 */
export function inPvpDuel(player) {
  return inPvp(player)
}

/**
 * pvpUltimate(ctx) — entry point for the top-level `.ultimate` command
 * (plugins/ultimate.js). The dragon has no PvE path (see
 * lib/dragon-engine.js's doc comment), so unlike pvpCinderVerdict() above
 * this is the ONLY entry point — there's no PvE plugin delegating in.
 * Routes into the normal PvP turn engine as the 'ultimate' action, which
 * gates on owning the dragon, turn >= 4, and the once-per-battle charge
 * (see activateDragonUltimate() in lib/dragon-engine.js).
 */
export async function pvpUltimate(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  return runPvpTurn(ctx, 'ultimate', '')
}

/**
 * pvpWildCard(ctx) — entry point for the top-level `.wildcard` command
 * (plugins/wildcard.js) when the caller is in a duel rather than a PvE fight.
 * Same delegation shape as pvpCinderVerdict() above: plugins/wildcard.js only
 * knows the PvE battleState shape (bs.enemy), so it hands off here when
 * battleState.type === 'pvp'. Routes into the normal PvP turn engine as the
 * 'wildcard' action, which gates on Circe being equipped and on having draws
 * left, then resolves whichever of her six cards comes up.
 *
 * Two rules differ from PvE, both by design (see the 'wildcard' gate in
 * runPvpTurn): 🌟 Wishing Star does NOT execute here, and 🦋 Vanishing Act
 * ends the duel with no result recorded for either player.
 */
export async function pvpWildCard(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  return runPvpTurn(ctx, 'wildcard', '')
}

/**
 * pvpThiefsEye(ctx) — entry point for the top-level `.thiefseye` command
 * (plugins/thiefseye.js) when the caller is in a duel rather than a PvE fight.
 * Same delegation shape as pvpCinderVerdict() above: plugins/thiefseye.js only
 * knows the PvE battleState shape (bs.enemy), so it hands off here when
 * battleState.type === 'pvp'. Routes into the normal PvP turn engine as the
 * 'thiefseye' action, which gates on Xiao being equipped, on the
 * once-per-battle charge, and on the opponent having actually used a NAMED move
 * on her owner already — a plain `.pvp attack` is not stealable, so she has
 * nothing to take until they reach for a skill or a signature ability.
 */
export async function pvpThiefsEye(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  return runPvpTurn(ctx, 'thiefseye', '')
}

/**
 * pvpHollowExchange(ctx) — entry point for the top-level `.hollowexchange`
 * command (plugins/hollowexchange.js) when the caller is in a duel rather than a
 * PvE fight. Same delegation shape as pvpCinderVerdict() above:
 * plugins/hollowexchange.js only knows the PvE battleState shape (bs.enemy), so
 * it hands off here when battleState.type === 'pvp'. Routes into the normal PvP
 * turn engine as the 'hollowexchange' action.
 *
 * It gates on Minna being equipped, on the once-per-battle charge, on the caller
 * being at or below 40% HP, and on the OPPONENT being above 40% — so unlike every
 * other signature move in here, whether it is legal depends on the score. The
 * three-step swap it needs (dry run, opponent write, actor write) is documented at
 * the hollowRes declaration in runPvpTurn.
 *
 * A duel is the one place this is symmetric: two Minna owners can each hold their
 * exchange, and whoever is losing badly enough to use it hands the disadvantage
 * straight to the other. Neither can be finished by it — the floor holds on both
 * sides — so it lengthens duels rather than deciding them.
 */
export async function pvpHollowExchange(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  return runPvpTurn(ctx, 'hollowexchange', '')
}

/**
 * pvpHollowPurple(ctx) — entry point for the top-level `.hollowpurple` command
 * (plugins/purple.js) when the caller is in a duel rather than a PvE fight.
 * Same delegation shape as pvpCinderVerdict() above: plugins/purple.js only
 * knows the PvE battleState shape (bs.enemy), so it hands off here when
 * battleState.type === 'pvp'. Routes into the PvP turn engine as the
 * 'hollowpurple' action, which gates on Gojo being equipped and the
 * once-per-battle charge, then lands the 18x hit RAW: it bypasses DEF and never
 * misses, uncapped like the other signature ultimates (the fight-length hit cap
 * is gated to basic attack / skill only).
 */
export async function pvpHollowPurple(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  return runPvpTurn(ctx, 'hollowpurple', '')
}

/**
 * pvpUnlimitedVoid(ctx) — entry point for the top-level `.unlimitedvoid` command
 * (plugins/domain.js) when the caller is in a duel rather than a PvE fight. Same
 * delegation shape as pvpCinderVerdict() above: plugins/domain.js only knows the
 * PvE battleState shape (bs.enemy), so it hands off here when
 * battleState.type === 'pvp'. Routes into the PvP turn engine as the
 * 'unlimitedvoid' action, which gates on Gojo being equipped and the
 * once-per-battle charge, then locks the opponent down with a hard stun for
 * UNLIMITED_VOID_STUN_TURNS of their turns. It deals no damage.
 */
export async function pvpUnlimitedVoid(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  return runPvpTurn(ctx, 'unlimitedvoid', '')
}

/**
 * pvpKurohitsugi(ctx) — entry point for the top-level `.kurohitsugi` command
 * (plugins/kurohitsugi.js) when the caller is in a duel rather than a PvE
 * fight. Same delegation shape as pvpHollowPurple() above: plugins/kurohitsugi.js
 * only knows the PvE battleState shape (bs.enemy), so it hands off here when
 * battleState.type === 'pvp'. Routes into the PvP turn engine as the
 * 'kurohitsugi' action, which gates on Aizen being equipped and the
 * once-per-battle charge, then lands the coffin RAW: it bypasses DEF and never
 * misses, with the multiplier computed at hit time from his stolen senses and
 * how wounded the opponent already is (kurohitsugiMultiplier).
 */
export async function pvpKurohitsugi(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  return runPvpTurn(ctx, 'kurohitsugi', '')
}

/**
 * pvpHogyoku(ctx) — entry point for the top-level `.hougyoku` command
 * (plugins/hogyoku.js) when the caller is in a duel. Same delegation shape as
 * pvpUnlimitedVoid() above: the PvE plugin only knows the PvE battleState shape
 * (bs.enemy), so it hands off here on battleState.type === 'pvp'. Routes in as
 * the 'hougyoku' action, which gates on Aizen being equipped and the
 * once-per-battle latch, then evolves him on the spot — heal, all five senses,
 * rest-of-battle stat surge. It deals no damage and the opponent takes no hit.
 */
export async function pvpHogyoku(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  return runPvpTurn(ctx, 'hougyoku', '')
}

/**
 * pvpPuppetStrings(ctx) — entry point for the top-level `.puppet` command
 * (plugins/puppetry.js) when the caller is in a duel rather than a PvE fight.
 * Same delegation shape as pvpUnlimitedVoid() above: plugins/puppetry.js only
 * knows the PvE battleState shape (bs.enemy), so it hands off here when
 * battleState.type === 'pvp'. Routes into the PvP turn engine as the
 * 'puppetstrings' action, which gates on Red Rose being equipped and the
 * once-per-battle charge, then turns the opponent's own attack on themselves
 * (floored at 20% of their max HP, never lethal) and tangles them for
 * PUPPET_TANGLE_TURNS — one turn, companion and all.
 */
export async function pvpPuppetStrings(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  return runPvpTurn(ctx, 'puppetstrings', '')
}

/**
 * pvpSword(ctx, move) — entry point for the top-level `.sword <technique>`
 * command (plugins/witch-heroes-actions.js) inside a duel. Same delegation shape
 * as pvpCinderVerdict() above: the plugin only knows the PvE battleState shape
 * (bs.enemy), so it hands off here on battleState.type === 'pvp'.
 *
 * Routing it through runPvpTurn() is what makes the Absolute Sword real in a
 * duel rather than a decoration. It used to resolve in its own plugin, which
 * could write MP and charge on the caller's record and nothing else: the cut was
 * subtracted from a snapshot of the opponent (never their write), no turn was
 * handed over, no HP bar moved, and no battle message was rendered, so the whole
 * technique read as "870 damage" in a plain text nobody believed. In here it
 * spends the turn properly, lands on the far side's own updatePlayer(), shows up
 * in the turn frame with both bars, and is refused outright in a wager duel like
 * every other character power.
 */
export async function pvpSword(ctx, move) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`🗡️ You're not in a duel. In a dungeon, \`${config.prefix}sword ${move ?? '<technique>'}\` works as it always has.`)
  }
  return runPvpTurn(ctx, 'sword', String(move ?? '').trim().toLowerCase())
}

/**
 * pvpEndworld(ctx) — entry point for `.endworld` inside a duel. The countdown
 * itself is not a move: it advances on the duel-wide turn boundary in
 * resolveDuelTurnBoundary(), which is why Ronova could never reach five
 * completed turns in a duel before (bs.turn is per-player and the duel never
 * called completeTurn at all). This is the declaration, gated inside
 * activateEndworld() on the five turns and the once-per-duel latch, and it takes
 * the turn like anything else that does.
 */
export async function pvpEndworld(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`☠️ You're not in a duel. \`${config.prefix}endworld\` is called in a fight.`)
  }
  return runPvpTurn(ctx, 'endworld', '')
}

/**
 * pvpGreedTithe(ctx) - entry point for the top-level `.greed` command
 * (plugins/greed.js) when the caller is in a duel rather than a PvE fight.
 * Same delegation shape as pvpPuppetStrings() above: plugins/greed.js only
 * knows the PvE battleState shape (bs.enemy), so it hands off here when
 * battleState.type === 'pvp'. Routes into the PvP turn engine as the
 * 'greedtithe' action, which gates on Echidna being equipped and the
 * once-per-battle charge, then lifts a mood-shaped share of the OPPONENT'S
 * wallet (half when amused/capricious, a quarter when displeased - plus
 * gems stolen from them on a mood chance) into the caller's purse, and hangs
 * the opponent distracted for GREED_TANGLE_TURNS.
 */
export async function pvpGreedTithe(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  return runPvpTurn(ctx, 'greedtithe', '')
}

/**
 * pvpTimeStop(ctx) — entry point for the top-level `.tms` command
 * (plugins/timestop.js) when the caller is in a duel. Same delegation shape as
 * pvpPuppetStrings() above: the PvE plugin only knows the PvE battleState shape
 * (bs.enemy), so it hands off here on battleState.type === 'pvp'. Routes in as
 * the 'timestop' action, which gates on Reverie being equipped and the
 * once-per-battle latch, then freezes the opponent — unless they own Montana,
 * who negates it and counters (see the 'timestop' resolution branch above).
 */
export async function pvpTimeStop(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  return runPvpTurn(ctx, 'timestop', '')
}

/**
 * pvpSoulPunisher(ctx) — entry point for the top-level `.soulpunisher` command
 * (plugins/soulpunisher.js) when the caller is in a duel. Same delegation shape
 * as pvpCinderVerdict() above: the PvE plugin only knows the PvE battleState
 * shape (bs.enemy), so it hands off here on battleState.type === 'pvp'. Routes
 * in as the 'soulpunisher' action, which gates on Gogeta being equipped and on
 * the 2-turn cooldown (see activateSoulPunisher() in lib/gogeta.js).
 */
export async function pvpSoulPunisher(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  return runPvpTurn(ctx, 'soulpunisher', '')
}

/**
 * pvpKamehameha(ctx) — entry point for the top-level `.kamehameha` command
 * (plugins/kamehameha.js) in a duel. Routes in as the 'kamehameha' action,
 * which gates on Gogeta being equipped, on the fusion still holding, on a FULL
 * energy bar (and empties it), and on the 8-turn cooldown. The beam art is sent
 * from inside the turn, on the turn it fires.
 */
export async function pvpKamehameha(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  return runPvpTurn(ctx, 'kamehameha', '')
}

/* ══════════════════════════════════════════════════════════════════════════
 * WAGER MODE
 *
 * Everything below serves the stake-on-the-line duel. The rules that make it a
 * different game (no turn order, a 2 second cooldown, no using the same move
 * twice in a row, no character powers, loser pays the full stake) live in
 * lib/pvp-wager.js; this half owns command routing and persistence, because
 * updatePlayer() has to stay top-level — see runPvpTurn's header for the
 * deadlock a nested call causes.
 *
 * The one rule every function here obeys: a two-player write is TWO separate,
 * sequentially-awaited updatePlayer() calls. Never nested, never Promise.all.
 * ══════════════════════════════════════════════════════════════════════════ */

/**
 * The trailing token of a kit command, when it is a count: `stock potion 3`.
 * Returned as [query, amount] so the item name keeps its spaces.
 */
function splitKitArgs(args) {
  const parts = [...args]
  const last = parts[parts.length - 1]
  if (parts.length > 1 && /^\d+$/.test(last ?? '')) {
    parts.pop()
    return [parts.join(' '), Math.max(1, Number(last))]
  }
  return [parts.join(' '), 1]
}

/**
 * stockKit — move copies of an item from the main inventory (or the chest) into
 * the 15-slot PvP kit. Refused mid-duel: the kit is what you brought, and being
 * able to top it up from your inventory while HP is on the line would make the
 * 15 slots meaningless.
 */
async function stockKit(ctx, args) {
  const { player, db } = ctx
  const pr = config.prefix
  const [query, amount] = splitKitArgs(args)

  if (!query) {
    const space = kitSpace(player)
    return ctx.reply(
      `❓ Usage: *${pr}pvp stock <item> [amount]*\n` +
      `_Example:_ *${pr}pvp stock health potion 5*\n\n` +
      `🎒 Kit: *${PVP_KIT_SLOTS - space}/${PVP_KIT_SLOTS}* slots _(${space} free)_\n` +
      `_See what's packed: *${pr}pvp inv*_`,
    )
  }
  if (inPvp(player)) {
    return ctx.reply(
      `🚫 *Not mid-duel.* The kit is whatever you packed before the bell.\n` +
      `_Use what you brought: *${pr}pvp dr <potion>* · *${pr}pvp tot* · *${pr}pvp inv*_`,
    )
  }

  let res = null
  await updatePlayer(db, ctx.from, (p) => { res = moveToKit(p, query, amount) })

  if (!res?.moved) {
    if (res?.reason === 'full') {
      return ctx.reply(
        `🎒 *Kit is full* — all ${PVP_KIT_SLOTS} slots are taken.\n` +
        `_Make room first: *${pr}pvp unstock <item>*_`,
      )
    }
    if (res?.reason === 'type') {
      return ctx.reply(
        `❌ *${res.itemName}* can't go in a PvP kit.\n` +
        `_Kits hold consumables, weapons, armour and relics. Not ${res.itemType ?? 'that'}._`,
      )
    }
    return ctx.reply(
      `❌ No *${query}* in your inventory or chest.\n` +
      `_Check *${pr}inventory*, or buy one with *${pr}shop*._`,
    )
  }

  const from = res.source === 'chest' ? 'chest' : 'inventory'
  const used = PVP_KIT_SLOTS - kitSpace(getPlayer(db, ctx.from))
  return ctx.reply(
    `🎒 Packed *${res.moved}× ${res.itemName}* into your PvP kit _(from your ${from})_.\n` +
    (res.partial ? `_Only ${res.moved} fit._\n` : '') +
    `📦 *${used}/${PVP_KIT_SLOTS}* slots  ·  *${res.count}× ${res.itemName}* now stocked\n` +
    `_View the grid: *${pr}pvp inv*_`,
  )
}

/**
 * unstockKit — the return trip. Respects the main inventory cap rather than
 * overflowing it, since the shed machinery in lib/inventory-limits.js exists
 * precisely so nothing silently vanishes over the line.
 */
async function unstockKit(ctx, args) {
  const { player, db } = ctx
  const pr = config.prefix
  const [query, amount] = splitKitArgs(args)

  if (!query) {
    return ctx.reply(
      `❓ Usage: *${pr}pvp unstock <item> [amount]*\n` +
      `_Puts it back in your inventory._\n\n` +
      kitPanel(player, pr),
    )
  }
  if (inPvp(player)) {
    return ctx.reply(`🚫 *Not mid-duel.* You can't unpack your kit while fighting out of it.`)
  }

  const cap = getInventoryCap(player)
  let res = null
  await updatePlayer(db, ctx.from, (p) => { res = takeFromKit(p, query, amount, cap) })

  if (!res?.moved) {
    if (res?.reason === 'inv-full') {
      return ctx.reply(
        `🎒 *Your inventory is full* _(${player.inventory?.length ?? 0}/${cap})_.\n` +
        `_Sell or use something first, then unstock again._`,
      )
    }
    return ctx.reply(`❌ No *${query}* in your PvP kit.\n_See what's packed: *${pr}pvp inv*_`)
  }

  const used = PVP_KIT_SLOTS - kitSpace(getPlayer(db, ctx.from))
  return ctx.reply(
    `↩️ Pulled *${res.moved}× ${res.itemName}* back into your inventory.\n` +
    (res.partial ? `_Inventory space ran out at ${res.moved}._\n` : '') +
    `📦 Kit: *${used}/${PVP_KIT_SLOTS}* slots`,
  )
}

/**
 * showKit — the kit as a drawn 5×3 grid, with the real item art in each box.
 * Falls back to the text panel if the render fails for any reason: a duel is a
 * bad moment to find out the canvas stack is unhappy, so this can never be the
 * thing that stops you seeing your own potions.
 */
async function showKit(ctx) {
  const { player } = ctx
  const pr = config.prefix
  const used = PVP_KIT_SLOTS - kitSpace(player)
  const caption =
    `🎒 *PVP KIT* — ${used}/${PVP_KIT_SLOTS} slots\n` +
    `_A separate store from your inventory. Only what's in here can be used mid-duel._\n\n` +
    `📥 *${pr}pvp stock <item> [n]*  ·  📤 *${pr}pvp unstock <item> [n]*`

  try {
    const sent = await sendKitReply(ctx, player, caption)
    if (sent) return sent
  } catch (err) {
    console.error('[pvp] kit render failed:', err?.message ?? err)
  }
  return ctx.reply(kitPanel(player, pr))
}

/**
 * acceptWagerDuel — the opening bell, and the only place solars leave a wallet
 * to start a duel.
 *
 * Both stakes are escrowed here (see the ESCROW note in lib/pvp-wager.js: the
 * alternative loses to "spend your purse mid-duel and there's nothing to
 * collect"). That makes this the one function in the mode that can leave money
 * in a bad place, so the order is deliberate: charge the challenger first, and
 * if the accepter's own escrow then fails, refund the challenger before
 * returning. Nobody is ever charged for a duel that did not start.
 */
export async function acceptWagerDuel(ctx, challengerJid, amount) {
  const { player, db } = ctx
  const pr = config.prefix
  const challenger = getPlayer(db, challengerJid)
  // Read now: the challenge is cleared from the record further down.
  const arena = player.pvpChallenge?.arena ?? null

  // Re-checked at the point of the charge, not trusted from challenge time:
  // two minutes is plenty to spend the purse this whole duel is built on.
  const fundingRefusal = wagerFundingRefusal(player, challenger, amount)
  if (fundingRefusal) return ctx.reply(fundingRefusal)
  const myPurse = player.wallet?.solars ?? 0
  if (myPurse < amount) {
    await updatePlayer(db, ctx.from, (p) => { p.pvpChallenge = null })
    return ctx.reply(
      `☀️ *You can't cover that stake any more.*\n` +
      `Needed *${amount.toLocaleString()}*, you hold *${myPurse.toLocaleString()}*.\n` +
      `_Challenge declined automatically._`,
    )
  }
  if ((challenger.wallet?.solars ?? 0) < amount) {
    await updatePlayer(db, ctx.from, (p) => { p.pvpChallenge = null })
    return ctx.reply(
      `☀️ *${challenger.name}* has spent their stake money since challenging you.\n` +
      `_Wager cancelled. Nothing left your wallet._`,
    )
  }

  const wagerBgSeed = `bg${Date.now().toString(36)}${Math.floor(Math.random()*0xffffffff).toString(36)}`
  let refusal=null, accepted=false
  await updateAllPlayers(db,()=>{
    const c=getPlayer(db,challengerJid), p=getPlayer(db,ctx.from)
    refusal=wagerFundingRefusal(c,p,amount)
    if(refusal)return false
    if(c.inBattle||c.inDungeon||p.inBattle||p.inDungeon || (c.wallet?.solars??0)<amount || (p.wallet?.solars??0)<amount){refusal='Wager no longer available; nobody was charged.';return false}
    const challenge=p.pvpChallenge
    if(!challenge || challenge.fromJid !== challengerJid){refusal='The wager challenge is no longer available.';return false}
    if(challenge.expiresAt<=Date.now() || challenge.wagerAmount!==amount){refusal='The wager challenge expired or changed.';return false}
    escrowStake(c,amount);escrowStake(p,amount)
    for(const [who,opponent] of [[c,ctx.from],[p,challengerJid]]){
      who.inBattle=true;who.battleState={...makeWagerState(opponent,amount),arena,bgSeed:wagerBgSeed}
    }
    p.pvpChallenge=null;accepted=true;return true
  },{requireWrite:true})
  if(!accepted)return ctx.reply(refusal??'Wager could not start.')

    // ── GUILD WAR pairing? Isolate both fighters behind Preset 5 NOW ──
    // Same contract as the normal accept path: war id stamped onto both
    // battleStates, real inventories stashed, the war kit loaded. Null for an
    // ordinary wager between two random players.
    const beforeChallenger = getPlayer(db, challengerJid)
    const beforeMe = getPlayer(db, ctx.from)
    const warDuel = await beginWarDuel(db, challengerJid, ctx.from)
    const them = warDuel ? getPlayer(db, challengerJid) : beforeChallenger
    const me = warDuel ? getPlayer(db, ctx.from) : beforeMe

    return ctx.reply(
      (warDuel
        ? `⚔️🔥 *GUILD WAR PAIRING — WAGER RULES!* 🔥⚔️\n` +
          `${warDuelKitLine(warDuel)}\n` +
          `_Your real inventory is stored and returns intact the moment this duel ends._\n\n`
        : '') +
      `💰⚔️ *WAGER DUEL — LIVE!* ⚔️💰\n\n` +
      `☀️ *${(amount * 2).toLocaleString()}* solars in the pot. Winner takes it all.\n\n` +
      `🥊 *${them.name}* ${levelTag(them)}  vs  *${me.name}* ${levelTag(me)}\n` +
      `❤️ ${them.name}: ${them.hp}/${them.maxHp}   ❤️ ${me.name}: ${me.hp}/${me.maxHp}\n\n` +
      `⚡ *NO TURNS.* Swing the moment you can.\n` +
      `⏱️ 2 second cooldown  ·  🚫 no same move twice in a row\n` +
      `🎭 No character powers. Stats, skills and your kit only.\n\n` +
      `⚔️ *${pr}pvp atk*  ·  ✨ *${pr}pvp sk <name>*  ·  🛡️ *${pr}pvp def*\n` +
      `🧪 *${pr}pvp dr <potion>*  ·  🪬 *${pr}pvp tot*  ·  🔧 *${pr}pvp mnd wpn*\n` +
      `_Free to check anytime: *${pr}pvp status* · *${pr}pvp moves* · *${pr}pvp inv*_\n\n` +
      `🔔 *GO.*`,
    )
}

/**
 * runWagerAction — one attack / skill / defend in a wager duel.
 *
 * The shape mirrors runPvpTurn's (snapshot both sides, resolve, then write each
 * player with its own top-level updatePlayer) but is a fraction of its size,
 * because everything runPvpTurn is long for — cat form, Hypnosis, domains, wild
 * cards, beast interventions, the tear/sever passives — is switched off here.
 * resolveWagerAction mutates the two snapshots in memory; this function's whole
 * job is to gate, persist, and narrate.
 */
async function runWagerAction(ctx, action, query) {
  const { db } = ctx
  const pr = config.prefix
  const actorJid = ctx.from

  const actor = getPlayer(db, actorJid)
  if (!inPvp(actor) || !isWagerState(actor.battleState)) {
    return ctx.reply(`❌ You're not in a wager duel.`)
  }
  const opponentJid = actor.battleState.opponentJid
  const stake = actor.battleState.wagerAmount ?? 0

  if (!playerExists(db, opponentJid)) {
    return voidWagerDuel(db, ctx, actorJid, opponentJid, 'Opponent missing — wager voided.', 'Missing opponent')
  }

  // ── pacing ──
  // Read-only, so a refused command costs nothing: no cooldown bump, no entry
  // in the repeat window. Being told "too fast" must never cost you tempo.
  // hasUsableSkill is passed so the window can tell a player who is holding a
  // castable skill back from one who has no third move at all: refusing the
  // latter would leave them with nothing legal and hang the duel.
  const gate = checkPacing(actor.battleState, action, { hasUsableSkill: hasUsableSkill(actor) })
  if (!gate.ok) return ctx.reply(pacingMessage(gate, pr))

  const opp = getPlayer(db, opponentJid)
  const hpBeforeTurn = actor.hp
  const eHpBeforeTurn = opp.hp

  // resolveWagerAction mutates BOTH objects. These are the live db.data records
  // (getPlayer hands back the object itself, not a copy), so the updatePlayer
  // calls below persist the same mutations rather than reapplying them — they
  // exist to put the writes through the queue and trigger the flush.
  const res = resolveWagerAction(actor, opp, action, query)
  if (!res.ok) return ctx.reply(res.msg)

  // Two writes, sequential, top-level. See the note at the top of this section.
  await updatePlayer(db, actorJid, () => {})
  await updatePlayer(db, opponentJid, () => {})

  let msg = res.msg

  // The window let a repeat through because nothing else was playable. Say so on
  // the turn it happened, so the rule never looks like it silently broke.
  if (gate.forced) msg += PACING_FORCED_NOTE

  // ── the totem ate a killing blow ──
  // Its own message, sent before the turn's frame, because the whole point is
  // that the kill did not happen. Awaited so it cannot land after the board it is
  // supposed to precede. It can never throw, and a missing GIF is a no-op: the
  // narrative line is already inside res.msg either way.
  if (res.revived) {
    const saved = res.revived === 'actor' ? actor : opp
    await sendTotemReviveAnimation(ctx, saved.name, { isClasp: !!saved.lastReviveWasClasp })
  }

  // ── did anyone fall? ──
  if (res.oppDefeated) {
    return pvpConclude(
      db, actorJid, opponentJid, ctx,
      `${msg}\n\n_${opp.name} falls with the stake on the line!_`,
      { allowRewind: false },
    )
  }
  if (res.actorDefeated) {
    return pvpConclude(
      db, opponentJid, actorJid, ctx,
      `${msg}\n\n_${actor.name} drops from their own wounds!_`,
      { allowRewind: false },
    )
  }

  const actorFinal = getPlayer(db, actorJid)
  const oppFinal = getPlayer(db, opponentJid)
  msg +=
    `\n\n━━━━━━━━━━━━━━━━━━━━\n` +
    `💰 *WAGER* ☀️ ${stake.toLocaleString()}  ·  pot ${(stake * 2).toLocaleString()}\n` +
    `❤️ *${actorFinal.name}* ${hpBar(actorFinal.hp, actorFinal.maxHp)} ${actorFinal.hp}/${actorFinal.maxHp}\n` +
    `❤️ *${oppFinal.name}* ${hpBar(oppFinal.hp, oppFinal.maxHp)} ${oppFinal.hp}/${oppFinal.maxHp}\n` +
    `⏱️ _2s cooldown running. No turns: they can swing right now._`

  await sendBattleTurnReply(ctx, {
    player: actorFinal, e: oppFinal, msg,
    hpBeforeTurn, eHpBeforeTurn,
    isPvp: true,
    isDefending: action === 'defend',
  })
}

/**
 * runWagerItem — the free, parallel item actions: drink, totem, armour swap,
 * weapon swap, mend, PP refill.
 *
 * They bump the 2-second clock (so you cannot chain six of them in one breath)
 * but never enter the no-repeat window, because swapping a totem must never be
 * the reason you cannot attack next. They touch only the acting player, so this
 * is the one path in the mode with a single write.
 */
async function runWagerItem(ctx, kind, query) {
  const { db } = ctx
  const pr = config.prefix
  const actorJid = ctx.from

  const actor = getPlayer(db, actorJid)
  if (!inPvp(actor) || !isWagerState(actor.battleState)) {
    return ctx.reply(`❌ You're not in a wager duel.`)
  }

  const gate = checkPacing(actor.battleState, kind)
  if (!gate.ok) return ctx.reply(pacingMessage(gate, pr))

  if (kind === 'mend' && !query) {
    return ctx.reply(
      `❓ Mend what? *${pr}pvp mnd wpn* _(weapon)_ or *${pr}pvp mnd arm* _(armour)_.\n` +
      `_Restores half the durability already lost._`,
    )
  }

  let res = null
  await updatePlayer(db, actorJid, (p) => {
    switch (kind) {
      case 'drink':  res = drinkFromKit(p, query); break
      case 'totem':  res = swapTotemFromKit(p); break
      case 'armor':  res = swapArmorFromKit(p, (query.split(/\s+/)[0] ?? ''), query.split(/\s+/).slice(1).join(' ')); break
      case 'weapon': res = swapWeaponFromKit(p, query); break
      case 'mend':   res = mendFromKit(p, query); break
      case 'refill': res = refillPpFromKit(p); break
      default:       res = { ok: false, msg: `❌ Unknown item action.` }
    }
    // A refused action must not cost the cooldown either — the player got
    // nothing for it. Only a real one bumps the clock.
    if (res?.ok) notePacing(p.battleState, kind)
  })

  if (!res?.ok) return ctx.reply(res?.msg ?? `❌ That didn't work.`)

  const after = getPlayer(db, actorJid)
  return ctx.reply(
    `${res.msg}\n\n` +
    `❤️ ${after.hp}/${after.maxHp}  ·  💧 ${after.mp}/${after.maxMp}  ·  🎒 ${ensureKit(after).length}/${PVP_KIT_SLOTS}\n` +
    `_That cost you no move. Swing when the 2s clock clears._`,
  )
}

/**
 * showWagerMoves — the wager move list.
 *
 * Deliberately NOT moveOptions() from lib/pvp-engine.js: that list includes
 * equipped abilities and reads a turn flag, and in this mode both would be a
 * lie. What it shows instead is what actually decides a wager duel: PP left on
 * each skill, what the repeat rule is currently blocking, and the kit actions
 * that cost no move at all.
 */
async function showWagerMoves(ctx) {
  const { player } = ctx
  const pr = config.prefix
  const bs = player.battleState
  const cd = Math.max(0, 2000 - (Date.now() - (bs.lastCommandAt ?? 0)))
  const blocked = new Set(bs.lastActions ?? [])

  const known = (player.skills ?? [])
    .map((id) => allSkills.find((s) => s.id === id))
    .filter((s) => s && s.type !== 'passive')

  const skillLines = known.length
    ? known.slice(0, 12).map((s) => {
        const left = ppLeft(bs, s)
        const max = maxPpFor(s)
        const affordable = (player.mp ?? 0) >= (s.mpCost ?? 0)
        const usable = left > 0 && affordable && !blocked.has('skill')
        return `${usable ? '✅' : '⛔'} ✨ *${s.name}* — _${s.mpCost ?? 0} MP · PP ${left}/${max}_` +
          `\n    \`${pr}pvp sk ${s.name}\``
      })
    : [`_You know no active skills. Basic attacks only._`]

  const kit = ensureKit(player)
  return ctx.reply(
    `🎯 *WAGER MOVES* — ☀️ ${(bs.wagerAmount ?? 0).toLocaleString()} on the line\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `${blocked.has('attack') ? '⛔' : '✅'} ⚔️ *Attack* — _no cost_\n    \`${pr}pvp atk\`\n` +
    `${blocked.has('defend') ? '⛔' : '✅'} 🛡️ *Defend* — _halves the next hit, +10% MP_\n    \`${pr}pvp def\`\n` +
    `${skillLines.join('\n')}\n\n` +
    `🎒 *FROM YOUR KIT* _(free, costs no move)_ — ${kit.length}/${PVP_KIT_SLOTS} packed\n` +
    `🧪 \`${pr}pvp dr <potion>\`  ·  🪬 \`${pr}pvp tot\`\n` +
    `🛡️ \`${pr}pvp arm <slot>\`  ·  ⚔️ \`${pr}pvp wpn\`\n` +
    `🔧 \`${pr}pvp mnd wpn|arm\`  ·  🌀 \`${pr}pvp rf\`\n\n` +
    `🚫 *No character powers in this mode.*\n` +
    (blocked.size ? `🚫 Cannot repeat: ${[...blocked].join(' → ')}\n` : '') +
    (cd > 0 ? `⏱️ Cooldown: ${(cd / 1000).toFixed(1)}s\n` : `⏱️ *Ready.*\n`) +
    `_No turns. Whoever moves first, moves._`,
  )
}

/**
 * wagerStakeOf — the stake riding on a duel between these two, or 0.
 *
 * Read off battleState rather than a side ledger, which is why an interrupted
 * duel can always be refunded from the state itself. Either side is enough: a
 * duel where only one record still carries the flag (a half-applied write, a
 * record restored from backup) is still a wager as far as settlement goes, and
 * paying it out is safer than silently reverting to the 5% steal.
 */
function wagerStakeOf(db, winnerJid, loserJid) {
  const w = getPlayer(db, winnerJid)
  const l = getPlayer(db, loserJid)
  if (isWagerState(w?.battleState)) return w.battleState.wagerAmount ?? 0
  if (isWagerState(l?.battleState)) return l.battleState.wagerAmount ?? 0
  return 0
}

/**
 * pvpConcludeWager — settlement.
 *
 * Both stakes are already out of both wallets (escrowed at accept), so the
 * winner collects double and the loser collects nothing: net +stake / -stake,
 * which is what "the loser pays the full stake" means. The normal ending's 5%
 * seizure does NOT also apply — the stake replaces it, it is not stacked on top.
 *
 * The ladder still moves, because a wager duel is a real duel. Everything that
 * is a reward rather than a result is deliberately left out: no guild spoils, no
 * season points, no beast CP, no XP. Those are progression, and progression you
 * can buy with solars is a treadmill, not a duel.
 */
export async function pvpConcludeWager(db, winnerJid, loserJid, ctx, reasonLine, stake) {
  await flushPendingCriticalWrites(db)
  const pr = config.prefix
  const winnerSnapshot = getPlayer(db, winnerJid)
  const loserSnapshot = getPlayer(db, loserJid)

  // Same rule as pvpConclude: the swing is computed from both ratings as they
  // stand right now, before either side is written.
  ensurePvp(winnerSnapshot ?? {})
  ensurePvp(loserSnapshot ?? {})
  const delta = ratingDelta(ratingOf(winnerSnapshot), ratingOf(loserSnapshot))

  let winnerName = winnerSnapshot?.name ?? 'Winner'
  let loserName = loserSnapshot?.name ?? 'Loser'
  let winnerPurse = 0
  let loserPurse = 0

  const expectedWinnerState=winnerSnapshot?.battleState, expectedLoserState=loserSnapshot?.battleState
  let settled=false, refunded=false
  await updateAllPlayers(db,()=>{
    const winner=getPlayer(db,winnerJid),loser=getPlayer(db,loserJid)
    if(!winner||!loser||winner===loser||winner.battleState!==expectedWinnerState||loser.battleState!==expectedLoserState||!isWagerState(winner.battleState)||!isWagerState(loser.battleState))return false
    if(winner.battleState.opponentJid!==loserJid||loser.battleState.opponentJid!==winnerJid || winner.battleState.wagerAmount!==stake || loser.battleState.wagerAmount!==stake)return false
    if(wagerFundingRefusal(winner,loser,stake)){
      refundStake(winner,stake);refundStake(loser,stake);refunded=true
    }else{
      payWagerPot(winner,stake)
      recordLoss(loser,winnerName,delta,stake);loser.pvp.lastOpponentJid=winnerJid
      recordWin(winner,loserName,delta,stake);winner.pvp.lastOpponentJid=loserJid
    }
    winnerPurse=winner.wallet.solars;loserPurse=loser.wallet.solars
    clearWagerState(winner);clearWagerState(loser);settled=true;return true
  },{requireWrite:true})
  if(!settled)return
  if(refunded)return ctx.reply('Wager funding eligibility changed. Both original stakes were refunded; no player-funded winnings moved.')

  const winnerAfter = getPlayer(db, winnerJid)
  const loserAfter = getPlayer(db, loserJid)
  const winnerBand = rankFor(winnerAfter)
  const loserBand = rankFor(loserAfter)

  return ctx.reply(
    `💰🏆 *WAGER SETTLED!* 🏆💰\n\n` +
    reasonLine + `\n\n` +
    `👑 *${winnerName.toUpperCase()} TAKES THE POT!*\n` +
    `☀️ *+${(stake * 2).toLocaleString()}* solars collected _(their ${stake.toLocaleString()} stake back, plus ${loserName}'s)_\n` +
    `💸 *${loserName}* is down *${stake.toLocaleString()}* solars.\n\n` +
    `💼 *${winnerName}*: ☀️ ${winnerPurse.toLocaleString()}\n` +
    `💼 *${loserName}*: ☀️ ${loserPurse.toLocaleString()}\n\n` +
    `📈 *RATING*\n` +
    `${winnerBand.emoji} *${winnerName}*: ${ratingOf(winnerAfter)} _(+${delta})_  ·  streak ${streakLabel(winnerAfter)}\n` +
    `${loserBand.emoji} *${loserName}*: ${ratingOf(loserAfter)} _(-${delta})_  ·  streak ${streakLabel(loserAfter)}\n\n` +
    `❤️‍🩹 Both fighters are fully healed. No gear was lost.\n` +
    `🎒 _Whatever you didn't spend is still in your kit._\n\n` +
    `_Again: *${pr}pvp wager ${stake} @them* · Ladder: *${pr}pvptop*_`,
  )
}

/**
 * voidWagerDuel — end a wager duel with no winner and no ladder movement.
 *
 * Used when nothing anybody did decided it: a mutual timeout, or an opponent who
 * stopped existing. Refunding both sides is the only defensible outcome, since
 * awarding a stake off five minutes of shared silence would make walking away
 * from a duel you are losing a coin flip worth taking.
 */
export async function voidWagerDuel(db, ctx, aJid, bJid, headline, oppName) {
  await flushPendingCriticalWrites(db)
  const stake = wagerStakeOf(db, aJid, bJid)
  const pr = config.prefix

  let aBack=0,bBack=0,refunded=false
  await updateAllPlayers(db,()=>{
    for(const [jid,opponent] of [[aJid,bJid],[bJid,aJid]]){
      const p=getPlayer(db,jid)
      if(!p || !isWagerState(p.battleState) || p.battleState.opponentJid!==opponent)continue
      const amount=p.battleState.wagerAmount
      if(!Number.isSafeInteger(amount)||amount<=0)continue
      const back=refundStake(p,amount)
      if(jid===aJid)aBack=back;else bBack=back
      clearWagerState(p);if(hasWarKit(p))removeWarKitPublic(p)
      refunded=true
    }
    return refunded
  },{requireWrite:true})
  if(!refunded)return

  const me = getPlayer(db, aJid)
  return ctx.reply(
    `${headline}\n\n` +
    `☀️ Both stakes refunded in full: *${stake.toLocaleString()}* each.\n` +
    `💼 *${me.name}*: ☀️ ${aBack.toLocaleString()}\n` +
    (bBack ? `💼 *${oppName}*: ☀️ ${bBack.toLocaleString()}\n` : '') +
    `\n📊 No rating change. Nobody won this.\n` +
    `❤️‍🩹 Both fighters are healed and free.\n\n` +
    `_Try again: *${pr}pvp wager ${stake} @them*_`,
  )
}

/** Alpha's top-level command shares the duel turn engine with .pvp garden. */
/**
 * pvpQueenConst(ctx) — `.const` inside a duel.
 *
 * Queen Esta's sky, fired at the OTHER player while the caster only watches.
 * Deliberately NOT routed through runPvpTurn like the other signature moves:
 * the scene spends thirty seconds sending messages, and runPvpTurn's shape is
 * "compute one turn, then write it" — a long async play in the middle of that
 * would hold a duel open across every await in it. So this is its own turn
 * engine for one move, reusing the pieces that matter: the same once-per-battle
 * gate (lib/queen-esta.js), the same per-player sequential writes, the same
 * applyIncomingDamage() funnel so the victim's own passives still answer the
 * rain, the same turn flip, and pvpConclude() for an ending.
 *
 * The command lock has two halves on purpose: showCrownScene() owns both
 * participants in-process (the dispatcher refuses their commands, and
 * pvpGarden()'s isBattleCinematicActive() guard is what stops a duel action
 * landing in the middle of someone else's sky), and battleState.queenLock is
 * the same fact stored WITH AN EXPIRY, so a restart mid-scene ages the lock out
 * instead of leaving two players unable to act forever.
 */
export async function pvpQueenConst(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const { db } = ctx
  const actorJid = ctx.from
  let actor = getPlayer(db, actorJid)
  const bs = actor?.battleState
  if (!inPvp(actor) || !bs) return ctx.reply(`🌙 *The Queen answers inside a duel.*\n_Use *${config.prefix}const* while you are fighting._`)
  if (isWagerState(bs)) {
    return ctx.reply(
      `🚫 *No character powers in a wager duel.*\n` +
      `_Raw stats, skills and your kit decide this one._`,
    )
  }
  if (!bs.myTurn) return ctx.reply(`⏳ It's not your turn yet.`)
  const opponentJid = bs.opponentJid
  if (!playerExists(db, opponentJid)) {
    await updatePlayer(db, actorJid, (a) => {
      clearSurtrKit(a, a.battleState)
      a.inBattle = false
      a.battleState = null
    })
    return ctx.reply(`❌ Your opponent is no longer registered — duel cancelled.`)
  }
  if (queenLockActive(actor) || queenLockActive(getPlayer(db, opponentJid))) {
    return ctx.reply(`🌌 *The sky is already falling.*\n_Nobody gets a command until it lands._`)
  }
  const gate = constGate(actor, { bs, isPvp: true })
  if (!gate.ok) return ctx.reply(gate.message)

  const opponent0 = getPlayer(db, opponentJid)
  const maxHp = Math.max(1, Number(opponent0.maxHp) || 1)
  const hp = Math.max(1, Number(opponent0.hp) || maxHp)
  const agi = Math.max(0, Number(getEffectiveStat(opponent0, 'agi')) || 0)
  const plan = planConstellation({ maxHp, hp, agi })

  // ── Spend the charge and take the lock on BOTH records ────────────────────
  // Two sequential writes, never nested (the shared queue note at the top of
  // runPvpTurn applies here in full): the stamp has to be visible to the
  // victim too, because it is their commands the lock is refusing.
  await updatePlayer(db, actorJid, (a) => {
    if (!a.battleState) return
    a.battleState.queenConstUsed = true
    a.battleState.queenLock = queenLockStamp()
  })
  await updatePlayer(db, opponentJid, (o) => {
    if (!o.battleState) return
    o.battleState.queenLock = queenLockStamp()
  })

  let guardLine = ''
  let crownActorDown = false
  async function crownHit(amount, absolute = false) {
    if (crownActorDown) return 0
    let dealt = 0
    await updatePlayer(db, opponentJid, o => {
      if (!inPvp(o)) return
      const incoming = Math.max(0, Math.min(amount, o.hp ?? 0))
      const reaction = queueHeartReaction(o, getPlayer(db, actorJid), incoming)
      const applied = reaction ?? (absolute ? applyAbsoluteCut(o, incoming) : applyIncomingDamage(o, incoming))
      dealt = applied.damage
      if (applied.message) guardLine += applied.message + '\n'
    })
    const pending = getPlayer(db, opponentJid)?.battleState?.godReactionOutbox ?? []
    let ids = []
    if (pending.length) {
      await updatePlayer(db, actorJid, a => {
        ids = applyQueuedHeartReactions(a, opponentJid, pending)
        if (godMortalDown(a)) {
          const saved = checkYoriichiCatForm(a) || checkTotemRevive(a)
          if (saved) guardLine += saved + '\n'
          else crownActorDown = true
        }
      })
      await updatePlayer(db, opponentJid, o => acknowledgeHeartReactions(o, ids))
    }
    return dealt
  }
  try {
    await showCrownScene(ctx, () => playCrownScene(ctx, {
      plan,
      targetName: opponent0.name ?? 'your opponent',
      casterName: actor.name ?? 'Queen Esta',
      afterStars: async () => { plan.appliedStarDamage = await crownHit(plan.starDamage) },
      afterFall: async () => { plan.appliedFallDamage = await crownHit(plan.fallDamage, true) },
    }), { participants: [actorJid, opponentJid] })
  } finally {
    await updatePlayer(db, actorJid, (a) => { if (a.battleState) delete a.battleState.queenLock })
    if (playerExists(db, opponentJid)) {
      await updatePlayer(db, opponentJid, (o) => { if (o.battleState) delete o.battleState.queenLock })
    }
  }

  if (crownActorDown) return pvpConclude(db, opponentJid, actorJid, ctx, guardLine.trim())
  const after = getPlayer(db, opponentJid)
  const me = getPlayer(db, actorJid)
  const total = (plan.appliedStarDamage ?? 0) + (plan.appliedFallDamage ?? 0)
  const head =
    `🌠 *THE MOTHER OF CONSTELLATIONS* — *${me?.name ?? actor.name}* called the sky down on *${after?.name ?? opponent0.name}*.` +
    (guardLine ? `\n` + guardLine : '')

  if (!after || after.hp <= 0 || !after.battleState) {
    return pvpConclude(db, actorJid, opponentJid, ctx, `${head}\n\n💀 _They did not get up._`)
  }

  // ── The turn passes, exactly the way runPvpTurn's own flip does ───────────
  const movedAt = Date.now()
  await updatePlayer(db, actorJid, (a) => {
    if (!a.battleState) return
    a.battleState.myTurn = false
    a.battleState.turn = (a.battleState.turn ?? 1) + 1
    a.battleState.lastMoveAt = movedAt
  })
  await updatePlayer(db, opponentJid, (o) => {
    if (!o.battleState) return
    o.battleState.myTurn = true
    o.battleState.lastMoveAt = movedAt
  })
  return ctx.reply(
    `${head}\n` +
    `🩸 *${total.toLocaleString()}* total damage _(no DEF — a star is not armour's problem)_\n` +
    `❤️ *${after.name}*: ${after.hp}/${after.maxHp}\n` +
    pvpStatusFooter(getPlayer(db, actorJid), after),
  )
}

export async function pvpGarden(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) return ctx.reply('🌑 The Garden answers only in a fight.')
  return runPvpTurn(ctx, 'garden', '')
}

/**
 * pvpFairySpell(ctx, spellId) — the ten Creative Magic incantations in a duel.
 *
 * plugins/fairy-queen.js only knows the PvE battleState shape (bs.enemy), so it
 * hands off here when the fight is a duel. Routing into the normal turn engine
 * as the single 'fairyspell' action (with the spell id as skillQuery) is what
 * gives the spells the turn flip, the opponent's write, MP/cooldown handling
 * and pvpConclude for free. The once-per-battle charge is burned inside
 * runPvpTurn, not here, so a spell that is refused (sealed, already spoken,
 * wrong character) costs nothing.
 */
export async function pvpFairySpell(ctx, spellId) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  if (!player.battleState.myTurn) {
    return ctx.reply(`⏳ It's not your turn yet.`)
  }
  const spell = fairySpellById(spellId)
  if (!spell) return ctx.reply(`🧚‍♀️ _That is not one of the court's words._`)
  return runPvpTurn(ctx, 'fairyspell', spell.id)
}

/**
 * pvpFairyEncore(ctx) — `.encore` in a duel.
 *
 * The lock is written onto the OPPONENT's record in runPvpTurn's opponent
 * phase, so this is only the door: the gate (equipped, once per duel, is there
 * anything to echo) runs in the actor's own mutator like every other
 * signature move.
 */
export async function pvpFairyEncore(ctx) {
  if (isBattleCinematicActive(ctx)) return
  const player = getPlayer(ctx.db, ctx.from)
  if (!inPvp(player)) {
    return ctx.reply(`❌ You're not in a duel.`)
  }
  if (!player.battleState.myTurn) {
    return ctx.reply(`⏳ It's not your turn yet.`)
  }
  return runPvpTurn(ctx, 'encore', '')
}
