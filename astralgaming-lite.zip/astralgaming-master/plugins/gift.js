/**
 * gift.js — hand something to the person on your street.
 *
 *   .gift <person> <item>     food, a potion, or an everyday material
 *   .gift                     who is here, and how this works
 *
 * One gift a day to each person. A gift they like is worth three times as much
 * as one they do not, and it is gone for good, so it is a sink, never a faucet:
 * valuable things are refused. Favor and what it unlocks live in
 * lib/town-favor.js; `.favor <person>` shows what someone likes once they have
 * warmed to you.
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { spotOf, npcsAt, findNpc, townWalkBlock } from '../lib/town.js'
import { recordQuestEvent } from '../lib/quest-engine.js'
import { addSeason02TowerAction } from '../lib/season-event-engine.js'
import { findInBag, giveGift, claimTierPerks, giftReply, giftRefusal, hasFavorData } from '../lib/town-favor.js'

export default {
  name: 'gift',
  aliases: [],
  category: 'town',
  requiresPlayer: true,
  description: 'Give food, a potion or a raw material to the person on your street',
  subcommands: [
    { cmd: '<person> <item>', desc: 'one gift a day each. Liked gifts count triple. The item is used up' },
  ],

  async run(ctx) {
    const p = config.prefix
    const blocked = townWalkBlock(ctx.player)
    if (blocked === 'battle') return ctx.reply(`⚔️ Not in the middle of a fight.`)
    if (blocked === 'dungeon') {
      return ctx.reply(`🗺️ Nobody from town followed you down.\n_Come back, then *${p}town* and *${p}gift*._`)
    }

    const spot = spotOf(ctx.player.townSpot, ctx.player.location)
    if (!spot) {
      return ctx.reply(`🧭 You are not on a street yet.\n*${p}town* to walk somewhere, then *${p}gift <person> <item>*.`)
    }
    const here = npcsAt(spot.id).filter(n => hasFavorData(n.id))
    if (!here.length) return ctx.reply(`${spot.emoji} *${spot.name}* is empty right now.`)

    const who = here.map(n => `*${n.name}*`).join(', ')
    const usage =
      `🎁 *${p}gift <person> <item>*\n` +
      `${spot.emoji} Here: ${who}\n` +
      `_Food, potions and everyday materials. One gift a day each, and it is used up. ` +
      `*${p}favor <person>* shows what someone likes once they know you._`
    if (!ctx.args.length) return ctx.reply(usage)

    let npc = findNpc(ctx.args[0], spot.id)
    let itemQuery = ctx.args.slice(1).join(' ').trim()
    if (npc && !hasFavorData(npc.id)) npc = null
    if (!npc) {
      // One person on the street and a first word that is not a name: the whole line is the item.
      if (here.length === 1) { npc = here[0]; itemQuery = ctx.args.join(' ').trim() }
      else return ctx.reply(`❓ *${ctx.args[0]}* is not on ${spot.name}.\nHere: ${who}`)
    }
    if (!itemQuery) return ctx.reply(usage)

    const found = findInBag(ctx.player, itemQuery)
    if (found.many) {
      return ctx.reply(
        `❓ More than one thing matches *${itemQuery}*:\n` +
        found.many.map(i => `  • ${i.name}  \`${i.id}\``).join('\n') +
        `\n_Say which: *${p}gift ${npc.id} <id>*_`,
      )
    }
    if (!found.item) {
      return ctx.reply(`🎒 You are not carrying *${itemQuery}*. *${p}inventory* to see what you have.`)
    }

    let result = null
    let claims = []
    await updatePlayer(ctx.db, ctx.from, player => {
      if (player.townSpot !== spot.id) player.townSpot = spot.id
      result = giveGift(player, npc.id, found.item)
      if (result.ok) {
        recordQuestEvent(player, 'gift', 1)
        addSeason02TowerAction(player, 'gift', { db: ctx.db })
        claims = claimTierPerks(player, npc.id)
      }
      return player
    })

    if (!result.ok) return ctx.reply(giftRefusal(npc, result, p))
    return ctx.reply(giftReply(npc, result, claims, p))
  },
}
