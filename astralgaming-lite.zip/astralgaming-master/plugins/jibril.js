// <prefix>jibril - Rimuru, Ultimate Slime form. Once per fight, PvE.
import { config } from '../config.js'
import { activateJibril } from '../lib/regressor-form-commands.js'
import { runRegressorCommand } from '../lib/regressor-command-runner.js'

export default {
  name: 'jibril',
  aliases: ['killhistory'],
  category: 'combat',
  description: `${config.prefix}jibril - Ultimate Slime form. Replay the target's kill-history hits. Capped at 35% max HP.`,
  requiresPlayer: true,
  async run(ctx) { return runRegressorCommand(ctx, activateJibril) },
}
