/**
 * unlockspin.js — owner-only `.unlockspin <character>`.
 *
 * Opens a character that `.lockspin` (plugins/lockspin.js) froze, so players can
 * pull it on the banner or buy it with Monds again. There is one store and one
 * switch behind both doors — lib/spin-locks.js — so an unlock can't open the
 * spin while leaving the shop closed, or the other way round.
 *
 * Unlocking also FULFILLS any paid pre-orders (lib/premium-perks.js,
 * plugins/preorder.js): every player who pre-ordered this character while it
 * was in the showcase phase has it added to their roster BEFORE the banner
 * goes live, so Premium pre-order holders get it first as promised. One-of-one
 * exclusive pre-orders are claimed atomically here — a pre-order grant wins
 * the bot-wide exclusive lock the same way .givecharacter does.
 */
import { config } from '../config.js'
import { isOwnerJid, NOT_ALLOWED } from '../lib/group-helpers.js'
import { characters, characterMap } from '../lib/game-data.js'
import { unlockSpin, isSpinLocked } from '../lib/spin-locks.js'
import { updatePlayer } from '../lib/player-repo.js'
import { fulfillPreordersFor } from '../lib/premium-perks.js'
import { claimExclusiveSpinForPlayer } from '../lib/season-engine.js'

function findCharacter(query) {
  const q = (query ?? '').toLowerCase().trim()
  if (!q) return null
  if (characterMap[q]) return characterMap[q]
  return characters.find(c => c.name.toLowerCase() === q)
    ?? characters.find(c => c.name.toLowerCase().includes(q))
    ?? null
}

export default {
  name:        'unlockspin',
  aliases:     [],
  category:    'account',
  description: 'Owner only: open a frozen character so players can pull or buy it (.unlockspin <name>)',

  async run(ctx) {
    const pr = config.prefix
    if (!ctx.from || !isOwnerJid(ctx.from)) return ctx.reply(NOT_ALLOWED)

    const query = (ctx.args ?? []).join(' ').trim()
    if (!query) {
      return ctx.reply(`⚠️ Usage: *${pr}unlockspin <name>*. See what's locked with *${pr}lockspin*.`)
    }

    const character = findCharacter(query)
    if (!character) {
      return ctx.reply(`❌ *"${query}"* isn't a character. See *${pr}character* for the list.`)
    }

    if (!isSpinLocked(character.id)) {
      return ctx.reply(`🔓 *${character.name}* isn't locked — the spin and the buy price are both open already.`)
    }

    // Fulfill pre-orders FIRST (before unlocking the banner), so pre-order
    // holders literally get the character before everyone else can pull it.
    // The grant mutator adds ownedCharacters + (for exclusives) claims the
    // bot-wide one-of-one lock in the same serialized write, same as
    // giveCharacter in plugins/admin.js — that invariant must hold here too.
    let preorderSummary = null
    if (ctx.db?.data?.users) {
      const pendingGrants = []
      preorderSummary = fulfillPreordersFor('character', character.id, ctx.db.data.users, (jid) => {
        // Apply directly via updatePlayer so the change is persisted and
        // one-of-one claims are atomic. Collect every promise and await them
        // before unlocking the banner so pre-order grants truly land first.
        pendingGrants.push(updatePlayer(ctx.db, jid, p => {
          p.ownedCharacters = p.ownedCharacters ?? []
          if (!p.ownedCharacters.includes(character.id)) {
            p.ownedCharacters.push(character.id)
            if (character.exclusive) claimExclusiveSpinForPlayer(ctx.db, character.id, jid)
          }
          // Remove the pre-order key now that it's been delivered, so the
          // player's record doesn't accumulate delivered keys forever.
          if (Array.isArray(p.preorders)) {
            const key = `character:${character.id.toLowerCase()}`
            p.preorders = p.preorders.filter(k => k !== key)
          }
          return p
        }))
      })
      if (pendingGrants.length) await Promise.all(pendingGrants)
    }

    unlockSpin(character.id)

    // DM every pre-order grantee so they know the character is theirs.
    if (preorderSummary?.ok && preorderSummary.granted?.length) {
      const dmText =
        `🔖 *Pre-order delivered: ${character.emoji ? character.emoji + ' ' : ''}${character.name}*\n\n` +
        `You pre-ordered before release, so *${character.name}* is already in your roster — before the banner is open to everyone.\n\n` +
        `Equip it with *${pr}character equip ${character.id}*.`
      for (const jid of preorderSummary.granted) {
        ctx.sock.sendMessage(jid, { text: dmText }).catch(() => {})
      }
    }

    const preorderLine = preorderSummary?.ok && preorderSummary.granted?.length
      ? `\n\n🔖 *${preorderSummary.granted.length} pre-order(s)* delivered to their holders first.`
      : ''
    return ctx.reply(
      `🔓 *${character.emoji ? character.emoji + ' ' : ''}${character.name}* is now open.\n\n` +
      `_Players can pull ${character.name} on the banner or buy it with Monds again._` +
      preorderLine,
    )
  },
}
