/**
 * heavens.js — `.heavens`: the hidden heavens.
 *
 * Every rule is lib/sect-heavens.js's: a seek rests six hours and
 * tears a heaven open on the look's chance, one heaven is open at
 * a time for a window of hours, a walk pays spiritual Qi straight
 * into the cultivation bar once per window, and the guardian that
 * waits inside carries the heaven-grade technique the realm teaches
 * — won in a real fight, with the ordinary defeat rules on a loss.
 *
 *   .heavens                the three, as you have met them
 *   .heavens seek           look for a hidden heaven
 *   .heavens enter          walk the open one (Qi, then the guardian)
 */
import { config } from '../config.js'
import { sectDoorRefusal, missingSectRecordRefusal } from '../lib/world-guards.js'
import { heavensCommand, heavensScreen } from '../lib/sect-heavens.js'
import '../lib/sect-hooks.js'


export default {
  name: 'heavens',
  aliases: ['hiddenrealm', 'hidden', 'heaven'],
  category: 'event',
  requiresPlayer: true,
  description: `${config.prefix}heavens [seek|enter] — a realm no map names, sought and walked`,

  async run(ctx) {
    const player = ctx.player
    const wrongWorld = sectDoorRefusal(player, {
      emoji: '🌫️', title: '*The hidden heavens belong to the Sect Empire.*',
      here: { cmd: 'travel', label: 'see Astra’s regions instead' },
    })
    if (wrongWorld) return ctx.reply(wrongWorld)
    if (!player.sect) return ctx.reply(missingSectRecordRefusal())
    const first = String((ctx.args ?? [])[0] ?? '').toLowerCase()
    if (first === 'list' || first === 'where' || first === 'status') {
      return ctx.reply(heavensScreen(player, { prefix: config.prefix }).join('\n'))
    }
    return heavensCommand(ctx, { now: Date.now() })
  },
}
