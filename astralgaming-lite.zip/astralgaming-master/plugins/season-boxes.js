/**
 * season-boxes.js — 📦 Mystery & Starfall Box opener.
 *
 *   .openbox                            view all unopened boxes
 *   .openbox <iron|gold|silver|diamond|potion|all> [amount|all]
 *   .openiron [amount|all]
 *   .opengold [amount|all]
 *   .opensilver [amount|all]
 *   .opendiamond [amount|all]
 *   .openpotion [amount|all]
 *   .openmythic                         Season 1 mythic box
 */
import { config } from '../config.js'
import { allItems } from '../lib/game-data.js'
import { updatePlayer, getPlayer } from '../lib/player-repo.js'
import { getActiveSeason, getSeasonRuntime, isSeasonRunActive } from '../lib/season-engine.js'
import { hasInventoryRoom } from '../lib/inventory-limits.js'
import {
  STARFALL_BOX_IDS,
  STARFALL_BOX_META,
  MAX_BOX_OPEN_BATCH,
  resolveStarfallBoxId,
  starfallBoxCount,
  totalStarfallBoxes,
  openStarfallBoxes,
} from '../lib/starfall-engine.js'

const RULE = '━━━━━━━━━━━━━━━━━━━━'
const ITEM_MAP = Object.fromEntries(allItems.map((i) => [i.id, i]))

const DIRECT_CMD_BOX = Object.freeze({
  openiron:    'iron_box',
  opengold:    'gold_box',
  opensilver:  'silver_box',
  opendiamond: 'diamond_box',
  openpotion:  'potion_box',
})

function pickWeighted(pool) {
  const total = pool.reduce((sum, entry) => sum + Math.max(0, Number(entry.weight) || 0), 0)
  let roll = Math.random() * total
  for (const entry of pool) {
    roll -= Math.max(0, Number(entry.weight) || 0)
    if (roll <= 0) return entry
  }
  return pool[pool.length - 1]
}

function parseAmountArg(raw) {
  const s = String(raw ?? '').trim().toLowerCase()
  if (!s) return 1
  if (s === 'all' || s === 'max') return MAX_BOX_OPEN_BATCH
  const n = Math.floor(Number(s))
  return Number.isFinite(n) && n >= 1 ? Math.min(MAX_BOX_OPEN_BATCH, n) : null
}

function summarizeBoxRewards(rewards) {
  let solars = 0
  let gems = 0
  let overflowSolars = 0
  const items = new Map()

  for (const r of rewards) {
    if (r.rewardType === 'solars') solars += r.amount
    else if (r.rewardType === 'gems') gems += r.amount
    else if (r.itemId) {
      if (r.amount > 0) items.set(r.itemId, (items.get(r.itemId) ?? 0) + r.amount)
      if (r.overflowSolars > 0) overflowSolars += r.overflowSolars
    }
  }

  const lines = []
  if (solars > 0) lines.push(`  ☀️ *+${solars.toLocaleString()} Solars*`)
  if (gems > 0) lines.push(`  💎 *+${gems} Gems*`)
  for (const [id, qty] of items.entries()) {
    const name = ITEM_MAP[id]?.name ?? id
    lines.push(`  🎁 *${name}*${qty > 1 ? ` ×${qty}` : ''}`)
  }
  if (overflowSolars > 0) {
    lines.push(`  _Bag cap reached — extra stack sold for ☀️ ${overflowSolars.toLocaleString()} Solars._`)
  }
  return lines
}

export function renderBoxesMenu(player, pr = config.prefix) {
  const total = totalStarfallBoxes(player)
  const rows = STARFALL_BOX_IDS.map((id) => {
    const meta = STARFALL_BOX_META[id]
    const n = starfallBoxCount(player, id)
    return `  ${meta.emoji} *${meta.name}:* ${n}  _(${pr}${meta.cmd})_`
  })

  return [
    `📦 *MYSTERY BOXES*`,
    RULE,
    total > 0
      ? `_You have *${total}* unopened box${total === 1 ? '' : 'es'} ready._`
      : `_No unopened boxes right now. Spin *${pr}starfall* to earn boxes._`,
    ``,
    ...rows,
    ``,
    `✨ *Open*`,
    `  ▸ *${pr}openbox <type> [1-${MAX_BOX_OPEN_BATCH}|all]*`,
    `  ▸ *${pr}openbox all* — open up to ${MAX_BOX_OPEN_BATCH} boxes at once`,
  ].join('\n')
}

export async function runOpenStarfallBoxFlow(ctx, args = []) {
  const pr = config.prefix
  const a0 = String(args[0] ?? '').trim().toLowerCase()
  const a1 = String(args[1] ?? '').trim().toLowerCase()

  if (!a0 || a0 === 'list' || a0 === 'view') {
    const viewer = getPlayer(ctx.db, ctx.from) ?? ctx.player
    return ctx.reply(renderBoxesMenu(viewer, pr))
  }

  // `.openbox all` — open up to MAX_BOX_OPEN_BATCH across all Starfall box types
  if (a0 === 'all') {
    const cap = parseAmountArg(a1 || 'all') ?? MAX_BOX_OPEN_BATCH
    let outcome = null
    await updatePlayer(ctx.db, ctx.from, (player) => {
      if (totalStarfallBoxes(player) <= 0) {
        outcome = { reason: 'none' }
        return player
      }
      let left = cap
      let opened = 0
      let stoppedFull = false
      const openedByBox = []
      const rewards = []
      for (const boxId of STARFALL_BOX_IDS) {
        if (left <= 0) break
        const have = starfallBoxCount(player, boxId)
        if (have <= 0) continue
        const res = openStarfallBoxes(player, boxId, Math.min(left, have))
        if (res.opened > 0) {
          opened += res.opened
          left -= res.opened
          openedByBox.push(`${STARFALL_BOX_META[boxId].emoji} ${STARFALL_BOX_META[boxId].name} ×${res.opened}`)
          rewards.push(...res.rewards)
        }
        if (res.stoppedFull) {
          stoppedFull = true
        }
      }
      outcome = {
        reason: opened > 0 ? 'ok' : (stoppedFull ? 'full' : 'none'),
        opened,
        openedByBox,
        rewards,
        stoppedFull,
        remaining: totalStarfallBoxes(player),
      }
      return player
    })

    if (outcome.reason === 'none') return ctx.reply(`📦 You have no unopened boxes. Spin *${pr}starfall* to earn some!`)
    if (outcome.reason === 'full') return ctx.reply(`🎒 Inventory full! Sell, equip, or store gear before opening more item boxes.`)

    const lines = [
      `📦 *OPENED ${outcome.opened} BOX${outcome.opened === 1 ? '' : 'ES'}!*`,
      RULE,
      `_${outcome.openedByBox.join(' · ')}_`,
      ``,
      ...summarizeBoxRewards(outcome.rewards),
    ]
    if (outcome.stoppedFull) {
      lines.push(``, `⚠️ _Stopped early — bag reached capacity. Make room for the rest._`)
    }
    lines.push(``, `📦 Boxes left: *${outcome.remaining}*`)
    return ctx.reply(lines.join('\n'))
  }

  const boxId = resolveStarfallBoxId(a0)
  if (!boxId) {
    return ctx.reply(
      `❌ Unknown box *"${args[0]}"*.\n` +
      `Try *${pr}openbox iron*, *gold*, *silver*, *diamond*, *potion*, or *all*.`,
    )
  }

  const amount = parseAmountArg(a1)
  if (!amount) {
    return ctx.reply(`❌ Give a number between *1* and *${MAX_BOX_OPEN_BATCH}* (or *all*).`)
  }

  let outcome = null
  await updatePlayer(ctx.db, ctx.from, (player) => {
    outcome = openStarfallBoxes(player, boxId, amount)
    return player
  })

  const meta = STARFALL_BOX_META[boxId]
  if (outcome.reason === 'missing') {
    return ctx.reply(`❌ You don't have any *${meta.name}* right now. Check *${pr}openbox*.`)
  }
  if (outcome.reason === 'full') {
    return ctx.reply(`🎒 Inventory full! Sell, equip, or store gear before opening *${meta.name}*.`)
  }

  const lines = [
    `${meta.emoji} *${meta.name.toUpperCase()}${outcome.opened > 1 ? ` ×${outcome.opened}` : ''} OPENED!*`,
    RULE,
    ...summarizeBoxRewards(outcome.rewards),
  ]
  if (outcome.stoppedFull) {
    lines.push(``, `⚠️ _Stopped at ${outcome.opened} — bag is full._`)
  }
  lines.push(``, `${meta.emoji} Remaining: *${outcome.remaining}*`)
  return ctx.reply(lines.join('\n'))
}

async function runLegacyMythicBox(ctx) {
  const season = getActiveSeason(ctx.db)
  if (!season) return ctx.reply(`🌙 There is no active season right now.`)
  const seasonRunNumber = getSeasonRuntime(ctx.db).runNumber
  const boxId = 'mythic_box'
  const box = ITEM_MAP[boxId]
  if (box?.seasonId && box.seasonId !== season.id) {
    return ctx.reply(`🌙 This box belongs to a different season and cannot be opened right now.`)
  }
  let outcome = null
  await updatePlayer(ctx.db, ctx.from, (player) => {
    if (!isSeasonRunActive(ctx.db, season.id, seasonRunNumber)) {
      outcome = { reason: 'seasonClosed' }
      return player
    }
    const index = (player.inventory ?? []).indexOf(boxId)
    if (index < 0) {
      outcome = { reason: 'missing', boxId }
      return player
    }
    const reward = pickWeighted(season.mysteryBoxes?.mythic ?? [])
    if (!reward) {
      outcome = { reason: 'empty' }
      return player
    }
    const amount = Math.max(1, Number(reward.amount) || 1)
    const netExtra = Math.max(0, amount - 1)
    if ((reward.rewardType === 'item' || reward.rewardType === 'weapon') && netExtra > 0 && !hasInventoryRoom(player, netExtra)) {
      outcome = { reason: 'full' }
      return player
    }
    player.inventory.splice(index, 1)
    if (reward.rewardType === 'solars' || reward.rewardType === 'gems') {
      player.wallet = player.wallet ?? {}
      player.wallet[reward.rewardType] = (player.wallet[reward.rewardType] ?? 0) + amount
    } else {
      player.inventory.push(...Array.from({ length: amount }, () => reward.itemId))
    }
    outcome = { reason: 'ok', reward }
    return player
  })

  if (outcome.reason === 'seasonClosed') return ctx.reply(`🌙 The season ended or changed. Your box was not opened.`)
  if (outcome.reason === 'missing') return ctx.reply(`❌ You do not have a *Mythic Box*.`)
  if (outcome.reason === 'full') return ctx.reply(`🎒 Inventory full! Make room before opening this box.`)
  if (outcome.reason === 'empty') return ctx.reply(`❌ This box has no configured pull table.`)
  const label = outcome.reward.rewardType === 'solars'
    ? `☀️ ${outcome.reward.amount.toLocaleString()} Solars`
    : outcome.reward.rewardType === 'gems'
      ? `💎 ${outcome.reward.amount} Gems`
      : `🎁 ${outcome.reward.amount ?? 1} × ${ITEM_MAP[outcome.reward.itemId]?.name ?? outcome.reward.itemId}`
  return ctx.reply(`🎁 *MYTHIC BOX OPENED!*\n${RULE}\n  ${label}`)
}

export default {
  name: 'openbox',
  aliases: ['boxes', 'openboxes', 'openiron', 'opengold', 'opensilver', 'opendiamond', 'openpotion', 'openmythic'],
  category: 'character',
  requiresPlayer: true,
  description: 'View and open Starfall & Mystery boxes',
  subcommands: [
    { cmd: '', desc: 'list all unopened boxes' },
    { cmd: '<type> [amount|all]', desc: `open 1-${MAX_BOX_OPEN_BATCH} Iron, Gold, Silver, Diamond, or Potion boxes` },
    { cmd: 'all', desc: `open up to ${MAX_BOX_OPEN_BATCH} boxes across all types` },
  ],

  async run(ctx) {
    const cmd = String(ctx.cmd ?? '').toLowerCase()
    if (cmd === 'openmythic') return runLegacyMythicBox(ctx)
    if (DIRECT_CMD_BOX[cmd]) {
      const meta = STARFALL_BOX_META[DIRECT_CMD_BOX[cmd]]
      return runOpenStarfallBoxFlow(ctx, [meta.key, ctx.args?.[0] ?? '1'])
    }
    return runOpenStarfallBoxFlow(ctx, ctx.args ?? [])
  },
}
