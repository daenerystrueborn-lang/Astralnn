import { config } from '../config.js'
import { isInSectEmpire } from '../lib/worlds.js'
import { sectCombatCommand } from '../lib/sect-fight.js'
import { applyNighOmni } from '../lib/texas.js'
import { applyFlameCombo } from '../lib/rengoku.js'
import { playLeagueMove } from './league-battle.js'
import { tickShunShunRikka } from '../lib/orihime.js'
import { companionTurnStrike } from '../lib/companions.js'
import { updatePlayer, getPlayer } from '../lib/player-repo.js'
import { checkLucidOngoingTurn, lucidFloorDamage, lucidImmuneLine } from '../lib/yu-miaoyi.js'
import { swarmAttackNudge } from '../lib/swarm-combat.js'
// Combo system — track ability chains for bonus damage
import { recordAbilityUse as recordComboAbility, resetFightCombos, applyComboBonus, formatComboTrigger } from '../lib/combo-engine.js'
import { recordPvePly, formatPveGambits, resetPveGambits } from '../lib/pve-gambits.js'
import { enemyAwareness } from '../lib/enemy-policy.js'
import {
  playerHitLine,
  playerMissLine,
  playerAbsorbedLine,
  enemyHitLine,
  enemyMissLine,
} from '../lib/battle-flavor.js'
import {
  calcPlayerDamage,
  applyDefense,
  calcMonsterDamage,
  calcPlayerHitChance,
  calcMonsterHitChance,
  rollEchoStrike,
  hpBar,
} from '../lib/combat-engine.js'
import {
  handleVictory,
  processStatusTurn,
  resolvePlayerHpZero,
  checkCatFormOngoingTurn,
  resolveCatFormDefeat,
  applyBossStatDrain,
} from '../lib/combat-handlers.js'
import { getEffectiveStat, addStatusEffect, absorbDamage, absorbInstinctAttack } from '../lib/effects.js'
import { sendBattleTurnReply } from '../lib/battle-frame-render.mjs'
import { flushDoctrineLines, doctrineBattleLine } from '../lib/combat-doctrine.js'
import { sendCinematicBossTurn } from '../lib/boss-cinematic.js'
import { sendImageTo } from '../lib/image.js'
import {
  applyBossSpecial,
  checkBossPhase,
  buildEnemyAttack,
  getBossTaunt,
  getBossHitLine,
  getBossDodgeLine,
  incrementBossTurn,
  cleanupBossFight,
  EVENT,
} from '../lib/boss-engine.js'
import { addStagger, isStaggered, tickStagger, staggerDamageMult } from '../lib/stagger-bar.js'
import { noteDamageDealt } from '../lib/limit-meter.js'
import { applyAllNamedPassives, NP_EVENT } from '../lib/named-passives.js'
import { beastIntervention, BEAST_EVENT } from '../lib/beast-engine.js'
import {
  wearWeaponOnTurn,
  wearArmorOnHit,
  breakMessage,
} from '../lib/durability.js'
import {
  activateFinalForm,
  applyTearOnHit,
  sendFinalFormVideo,
  sendWillowAdvisory,
  tickPermanentSever,
  tickFrostbindAura,
  applyAbsoluteOneSiphon,
  tickClaneDrain,
  rollSerpentsGrace,
  isCatFormActive,
  resolveCatFormDamage,
  buildCatFormDefeatMessage,
  catFormAttackDamage,
  applyIncomingDamage,
  applyAlyaStatBreak,
  applyFrostlockGate,
  megumiTurnStart,
  resolveMegumiIncoming,
  sendWheelSpin,
  danceOfTheRainMultiplier,
  buildDanceOfTheRainMessage,
  hasSecondTranscendance,
  hasWitchOfEnvy,
  advanceWondersOfEnvy,
  bypassesWondersOfEnvy,
  tickBethMend,
  tickLioreiTurnStart,
} from '../lib/character-abilities.js'
import { isStreaming, rampStreamViewers } from './stream.js'
import { armMirror, mirrorOpenLine, mirrorTurnLines, hasAvessa } from '../lib/avessa-engine.js'
import { applyStruckReactions, applyPackLifestealOnDeal } from '../lib/premium-abilities.js'
import { sendImage } from '../lib/image.js'
import { heroesAnswerHit, heroesTurnBoundary } from '../lib/witch-heroes-pve.js'
// The Dreamlands: the Touch (sleep + decay on every landed hit) and the one
// monster ability resolver. Both are no-ops for every enemy without
// `nightmareTier`/`abilities`, i.e. for the entire rest of the roster.
import { applyNightmareMonsterTurn, isNightmare } from '../lib/dreamlands-monsters.js'
import { applyMonsterAbilityTurn } from '../lib/monster-abilities.js'
import { resolveTowerTactic } from '../lib/tower-combat.js'
import { regressorTurnStart, regressorTurnEnd, regressorBeforePlayerAttack, regressorOnPlayerHit, regressorHoldsEnemyTurn, noteRegressorFailedAction } from '../lib/regressor-passives.js'
import { dreamstepTurnLine } from '../lib/dreamstep.js'
import { graceHoldsEnemyTurn, graceEnemyHeldLine } from '../lib/king-yato.js'

/** True when the current fight is against an anime boss with active bossState. */
function isBossFight(player) {
  return !!(player.battleState?.enemy?.isBoss && player.battleState?.bossState)
}

/**
 * Convert a result.applyEffect spec (from applyBossSpecial) into a proper
 * status-effect object that addStatusEffect() accepts.
 */
function _buildBossEffect(player, spec) {
  if (!spec) return null
  const amount = spec.pctPerTurn
    ? Math.max(1, Math.round(player.maxHp * spec.pctPerTurn))
    : (spec.amount ?? 1)
  return {
    type: spec.type,
    duration: spec.turns ?? 2,
    amount,
    sourceId: spec.source ?? 'boss',
  }
}

// Boss "lifespan drain" stat cuts live in lib/combat-handlers.js as
// applyBossStatDrain() — one shared implementation instead of three near-
// identical copies, and a temporary weaken effect instead of a permanent
// subtraction from player.stats that nothing could ever give back.

// resolvePlayerHpZero (totem -> pearl -> Yoriichi cat form -> real death)
// now lives in lib/combat-handlers.js so every combat plugin shares the
// exact same checkpoint chain instead of re-implementing it inline. See
// that file's doc comment for the usage pattern used at every
// "if (player.hp <= 0)" site below.

export default {
  name: 'attack',
  aliases: ['atk', 'a'],
  category: 'combat',
  requiresPlayer: true,
  description: 'Basic attack in battle',

  async run(ctx) {
    // ── The Sect Empire fights through its own engine ──────────────────
    // A player in the sect world never reaches the Astral combat below:
    // their fight is lib/sect-combat.js, run by lib/sect-fight.js. Astra
    // Kingdom is untouched, because this is only true inside the sect.
    if (isInSectEmpire(ctx.player) && await sectCombatCommand(ctx, 'attack')) return
    // ── Astral League fixture ─────────────────────────────────────────
    // A player standing in a live fixture fights through the League path,
    // not the dungeon pipeline below. This has to run BEFORE updatePlayer():
    // playLeagueMove() sends and writes, and doing either from inside a
    // mutator deadlocks the shared write queue (see the note in plugins/pvp.js
    // about why PvP never nests updatePlayer calls).
    if (await playLeagueMove(ctx, 'attack', '')) return
    // Yu Miaoyi — the owner's battle commands are refused while she is
    // driving, and her auto-fight resumes. Runs BEFORE updatePlayer below:
    // the driver writes through updatePlayer itself and must never nest.
    {
      const lucid = await checkLucidOngoingTurn(getPlayer(ctx.db, ctx.from), ctx)
      if (lucid.intercepted) return
    }

    const p = config.prefix
    await updatePlayer(ctx.db, ctx.from, async (player) => {
      // Swarm floors run the multi-monster engine (swarm-combat.js), where the
      // basic attack is DIRECTIONAL: a plain .a no longer swings, it points the
      // player at .al / .ar and reprints the field (no turn spent). The 1v1
      // pipeline below is byte-identical for every floor-100 master fight.
      if (player.battleState?.mode === 'swarm') return swarmAttackNudge(player, ctx)
      if (player.battleState?.type === 'pvp') {
        await ctx.reply(`⚔️ *You're in a duel* — use *${p}pvp attack* instead.`)
        return player
      }
      if (!player.inBattle || !player.battleState) {
        await ctx.reply(`❌ *Not in battle.* _Use_ *${p}dungeon* _to find an enemy._`)
        return player
      }

      const bs = player.battleState
      const e = bs.enemy
      const boss = isBossFight(player)
      const hpBeforeTurn = player.hp
      const eHpBeforeTurn = e.hp

      // ── Combo System: reset per-fight tracking on turn 1 ────────────
      if ((bs.turn ?? 1) === 1) {
        resetFightCombos(player)
        // A new fight gets an empty commentary book, so the same named line can
        // be earned again next floor instead of being burned for good.
        resetPveGambits(player)
      }

      // ── Gambit engine: name the shape of the dungeon fight ──────────────
      // Same ply log and same detector plugins/pvp.js runs on a duel, so a
      // dungeon turn and a duel turn are announced in the same voice. HP is
      // read BEFORE the blow lands, which is what lets The Finish see the foe
      // it actually struck.
      const freshGambits = recordPvePly(player, 'attack', {
        foeHpFrac: (e.hp ?? 0) / Math.max(1, e.maxHp ?? 1),
        playerHpFrac: (player.hp ?? 0) / Math.max(1, player.maxHp ?? 1),
      })

      let msg = ''
      let texasHit = null
      let flameCombo = null

      // ── Urahara's permanent Tear (PvP-only debuff) — action-triggered tick.
      // Fires on the player's next action regardless of context, matching
      // the existing wearWeaponOnTurn/wearArmorOnHit "no real-time timer"
      // pattern. See lib/character-abilities.js's file doc comment.
      const permaSeverLine = tickPermanentSever(player)
      if (permaSeverLine) msg += permaSeverLine + '\n'
      if (player.hp <= 0) {
        const res = await resolvePlayerHpZero(player, ctx, msg, {})
        if (!res.fallThrough) return res.returnValue
        msg = res.msg
      }
      const catTurn = await checkCatFormOngoingTurn(player, ctx, { boss })
      if (catTurn.intercepted) return catTurn.returnValue
      bs.playerDefending = false

      // ── Named-weapon/item passives: fight-start effects (once) ───────────
      const npState = bs.namedPassive ?? (bs.namedPassive = {})
      if (!npState.fightInitDone) {
        npState.fightInitDone = true
        const initResult = applyAllNamedPassives(player, NP_EVENT.FIGHT_INIT, {
          enemy: e,
          bs,
        })
        if (initResult.modified) msg += initResult.lines.join('\n') + '\n'
      }

      // ── Named-weapon/item passives: turn-start effects (e.g. Gate of Babylon) ─
      const tsNamedResult = applyAllNamedPassives(player, NP_EVENT.TURN_START, {
        enemy: e,
        bs,
      })
      if (tsNamedResult.modified) msg += tsNamedResult.lines.join('\n') + '\n'
      if (e.hp <= 0) {
        if (boss) cleanupBossFight(player)
        return handleVictory(player, e, ctx)
      }

      // ── Boss: increment turn counter + TURN_START event ───────────────────
      if (boss) {
        incrementBossTurn(player)
        const tsResult = applyBossSpecial(player, EVENT.TURN_START, {})

        if (tsResult.narrativeLine) msg += `_${tsResult.narrativeLine}_\n`

        // Jotaro Time Stop — guaranteedHits is an array of per-hit damage values
        if (
          Array.isArray(tsResult.guaranteedHits) &&
          tsResult.guaranteedHits.length
        ) {
          msg += `🕐 *ZA WARUDO!* Time has stopped!\n`
          let totalTSD = 0
          for (const rawHit of tsResult.guaranteedHits) {
            let hitDmg = rawHit
            const beastHit = beastIntervention(player, BEAST_EVENT.ENEMY_DEAL_DAMAGE, {
              enemy: e, bs, damage: hitDmg,
            })
            if (beastHit.modified) {
              hitDmg = beastHit.damage ?? hitDmg
              msg += beastHit.lines.join('\n') + '\n'
            }
            const applied = applyIncomingDamage(player, hitDmg)
            totalTSD += applied.damage
            if (applied.message) msg += applied.message + '\n'
            if (applied.catFormDefeated) {
              return resolveCatFormDefeat(player, ctx, { boss })
            }
          }
          msg += `👊 *Star Platinum* delivers *${tsResult.guaranteedHits.length}* rapid strikes!\n`
          msg += `🩸 *${totalTSD}* total damage! _(ignores DEF)_\n`
          if (player.hp <= 0) {
            const res = await resolvePlayerHpZero(player, ctx, msg, { boss })
            if (!res.fallThrough) return res.returnValue
            msg = res.msg
          }
          if (e.hp <= 0) {
            await ctx.reply(msg.trim())
            cleanupBossFight(player)
            return handleVictory(player, e, ctx)
          }
        }

        // Whitebeard quake residue — true damage at turn start
        if (tsResult.playerTrueDamage) {
          const applied = applyIncomingDamage(player, tsResult.playerTrueDamage)
          if (applied.message) msg += applied.message + '\n'
          if (applied.catFormDefeated) {
            return resolveCatFormDefeat(player, ctx, { boss })
          }
          // A shockwave the funnel dodged outright (Minato's Flying Thunder God,
          // Ultra Instinct) took nothing; do not print the number it carried.
          msg += applied.dodged
            ? `🌊 *Quake shockwave* tears through the ground you just left.\n`
            : `🌊 *Quake shockwave* hits for *${tsResult.playerTrueDamage}* true damage!\n`
          if (player.hp <= 0) {
            const res = await resolvePlayerHpZero(player, ctx, msg, { boss })
            if (!res.fallThrough) return res.returnValue
            msg = res.msg
          }
        }
      }

      // ── Player's own status effects (DOT, CC) tick first ─────────────────
      const playerStatus = processStatusTurn(player)
      if (playerStatus.lines.length) msg += playerStatus.lines.join('\n') + '\n'
      if (player.hp <= 0) {
        const res = await resolvePlayerHpZero(player, ctx, msg, { boss })
        if (!res.fallThrough) return res.returnValue
        msg = res.msg
      }

      const towerChoice = resolveTowerTactic({ player, enemy: e, action: 'attack', turnId: bs.turn ?? 1, incapacitated: playerStatus.incapacitated })
      if (towerChoice.lines.length) msg += towerChoice.lines.join('\n') + '\n'

      // Season 2 cast: automatic turn-start passives. No command, no button.
      const rStart = regressorTurnStart(player, bs)
      if (rStart.lines.length) msg += rStart.lines.join('\n') + '\n'
      if (e.hp <= 0) {
        if (boss) cleanupBossFight(player)
        return handleVictory(player, e, ctx)
      }

      // ── Mei's Final Form — automatic trigger at <=70% HP.
      const finalForm = activateFinalForm(player)
      if (finalForm.ok) {
        msg += finalForm.message + '\n'
        void sendFinalFormVideo(ctx, finalForm.message).catch(() => {})
      }

      // ── Orihime — Shun Shun Rikka: turn-start heal, once-per-battle rejection
      // of a poison/burn/bleed. Same equipped-character passive slot as Final Form.
      const rikka = tickShunShunRikka(player, bs)
      if (rikka) msg += rikka.message + '\n'

      // ── Beth — Mend & Reinforce: turn-start armor repair + HP heal (Turn 2+)
      const bethMend = tickBethMend(player, bs)
      if (bethMend) msg += bethMend.message + '\n'

      // ── Liorei — Snapshot passive: automatic framing (opening frame on Turn 4,
      // then random re-frames never inside 5 moves) + flavor lapse check (Turn 3+)
      const lioreiTick = tickLioreiTurnStart(player, bs)
      if (lioreiTick) {
        msg += lioreiTick.message + '\n'
        if (ctx?.sock && ctx?.jid) {
          if (lioreiTick.snapImage && lioreiTick.autoSnapshot?.message) {
            void sendImageTo(ctx.sock, ctx.jid, lioreiTick.snapImage, lioreiTick.autoSnapshot.message).catch(() => {})
          }
          if (lioreiTick.lapseImage && lioreiTick.lapse?.message) {
            void sendImageTo(ctx.sock, ctx.jid, lioreiTick.lapseImage, lioreiTick.lapse.message).catch(() => {})
          }
        }
      }

      // ── Guardian of the Innocent — a Battle companion (Minna / Rune & Lica)
      // strikes beside the player at the start of every PvE turn.
      const compStrike = companionTurnStrike(player, e, bs)
      if (compStrike) {
        msg += compStrike.message + '\n'
        if (e.hp <= 0) {
          if (boss) cleanupBossFight(player)
          return handleVictory(player, e, ctx)
        }
      }

      // ── Miyashi's Frostbind aura — ambient drain + skill-lock roll on the
      // enemy, ticks every turn cycle regardless of whether the player's own
      // action lands. Mirrors Mei's Final Form slot (equipped-character
      // passive, resolved once per turn, before the player's attack).
      const frostbind = tickFrostbindAura(player, e, bs)
      if (frostbind) {
        msg += frostbind.message + '\n'
        if (e.hp <= 0) {
          if (boss) cleanupBossFight(player)
          return handleVictory(player, e, ctx)
        }
      }

      // ── Avessa, the Perfect Mirror — armed on the first turn of the fight
      // (armMirror is idempotent, so a lazy arm here is the same thing as arming
      // at the fight's start, and it cannot double-copy if the turn re-enters)
      // and then executed every turn from the same passive slot as Frostbind
      // above. A flagged enemy ability is copied at 70%; with nothing copyable,
      // she reflects the enemy's own numbers instead. Nothing it writes outlives
      // the battle: the record lives on bs.mirror and bs dies with the fight.
      if (hasAvessa(player)) {
        if (!bs.mirror) {
          const record = armMirror({ owner: player, opponent: null, enemy: e, battleState: bs })
          const open = mirrorOpenLine(record)
          if (open) msg += open + '\n'
        }
        const mirror = mirrorTurnLines({ record: bs.mirror, owner: player, target: e, battleState: bs })
        if (mirror.lines.length) msg += mirror.lines.join('\n') + '\n'
        if (e.hp <= 0) {
          if (boss) cleanupBossFight(player)
          return handleVictory(player, e, ctx)
        }
      }

      // ── Nisha's Absolute One — siphons HP from the enemy to the player
      // on Nisha's own turn cycle. Same slot as Frostbind above.
      const absoluteOne = applyAbsoluteOneSiphon(player, e)
      if (absoluteOne) {
        msg += absoluteOne.message + '\n'
        if (e.hp <= 0) {
          if (boss) cleanupBossFight(player)
          return handleVictory(player, e, ctx)
        }
      }

      // ── Clane's Crimson Hunger — she feeds on the enemy every turn and takes
      // her Toll out of the owner on the same tick. Same equipped-character
      // passive slot as Frostbind/Absolute One above. The enemy side can end
      // the fight; the owner side can end the OWNER, and that death runs the
      // normal death path (and therefore the Astral Town Hospital bill).
      const claneFeed = tickClaneDrain(player, e)
      if (claneFeed) {
        msg += claneFeed.message + '\n'
        // A bite that rebounded off Shunya's void (tickClaneDrain's rebounded
        // path) landed on the owner instead — settle it before the death checks.
        if (claneFeed.reboundDamage > 0) {
          player.hp = Math.max(0, (player.hp ?? 0) - claneFeed.reboundDamage)
        }
        if (e.hp <= 0) {
          if (boss) cleanupBossFight(player)
          return handleVictory(player, e, ctx)
        }
        if (player.hp <= 0) {
          const res = await resolvePlayerHpZero(player, ctx, msg, { boss })
          if (!res.fallThrough) return res.returnValue
          msg = res.msg
        }
      }

      // ── Alya's Stat Break — fires every 3rd turn, zeroes a random enemy
      // stat for 6 turns. Same turn-start slot as Frostbind/Absolute One
      // above (equipped-character passive, resolved once per turn before
      // the player's own attack).
      const alyaBreak = applyAlyaStatBreak(player, e, bs)
      if (alyaBreak.triggered) {
        msg += alyaBreak.message + '\n'
      }

      // ── Megumi's Thousand Shadows Swarm — a thousand cursed spirits drain
      // the enemy's life force (healing Megumi a share of it) and deepen a
      // cumulative ATK cut every turn; doubled once the Chimera Shadow Garden
      // is open, plus the Garden's shikigami and Mahoraga's blade if they're
      // out. Same turn-start slot as Frostbind / Absolute One / Stat Break
      // above, so it ticks in monster fights, dungeons and boss fights alike.
      const swarm = megumiTurnStart(player, e, bs)
      if (swarm) {
        msg += swarm.message + '\n'
        if (e.hp <= 0) {
          if (boss) cleanupBossFight(player)
          return handleVictory(player, e, ctx)
        }
      }

      // ── Tella's Wonders of You — the Witch of Envy escalates on a fixed
      // clock (see advanceWondersOfEnvy). Same turn-start slot as the passives
      // above, so she ticks in monster fights, dungeons and boss fights alike.
      // The two world-enders (The End, The Last Prayer) are immune; everything
      // else, bosses included, is fair game, which is the whole point of her.
      if (hasWitchOfEnvy(player)) {
        const envy = advanceWondersOfEnvy(bs, {
          context: boss ? 'boss' : 'dungeon',
          foeName: e?.name ?? 'the enemy',
          ownerName: player?.name ?? 'you',
          immune: bypassesWondersOfEnvy(e),
          oppDefendedLast: false, // a PvE foe has no defend action to read
        })
        if (envy) {
          if (envy.art) {
            void sendImage(ctx, envy.art, `🖤 ${player.name}'s Witch of Envy takes her final form.`).catch(() => {})
          }
          if (envy.halveFraction) e.hp = Math.max(1, Math.floor(e.hp * envy.halveFraction))
          if (envy.lines) msg += envy.lines + '\n'
          if (envy.forcedLoss) {
            if (envy.drainOwner) player.hp = 1
            e.hp = 0
            if (boss) cleanupBossFight(player)
            return handleVictory(player, e, ctx)
          }
        }
      }

      // ── Summon Beast: turn-start bonus attack chance ─────────────────────
      const beastTsResult = beastIntervention(player, BEAST_EVENT.TURN_START, { enemy: e, bs, turnId: bs.turn ?? 1 })
      if (beastTsResult.modified) {
        e.hp = Math.max(0, e.hp - beastTsResult.bonusDamage)
        msg += beastTsResult.lines.join('\n') + '\n'
        if (e.hp <= 0) {
          if (boss) cleanupBossFight(player)
          return handleVictory(player, e, ctx)
        }
      }

      let rAttackPlan = null
      if (!playerStatus.incapacitated) rAttackPlan = regressorBeforePlayerAttack(player, bs, e)
      if (playerStatus.incapacitated) {
        msg += `💫 *${player.name}* is unable to act this turn!\n`
      } else if (towerChoice.evade || Math.random() > calcPlayerHitChance(player, e)) {
        // ── MISS ─────────────────────────────────────────────────────────────
        // Boss misses keep the plain line (their cinematic voice follows below);
        // a generic monster miss draws from the flavor pool instead.
        msg += boss
          ? `💨 *${player.name}* attacks *${e.name}*... and *MISSES!*\n`
          : playerMissLine(player.name, e, player.equippedCharacter) + '\n'
        noteRegressorFailedAction(player, 'miss')
        if (boss) {
          const missResult = applyBossSpecial(player, EVENT.PLAYER_MISS, {
            isMiss: true,
          })
          msg += `💬 _"${getBossDodgeLine(player)}"_\n`
          if (missResult.narrativeLine) msg += `_${missResult.narrativeLine}_\n`
          if (missResult.applyEffect) {
            const fx = _buildBossEffect(player, missResult.applyEffect)
            if (fx) {
              const fxRes = addStatusEffect(player, fx)
              if (fxRes?.immune) msg += lucidImmuneLine(player, fx.type) + '\n'
            }
          }
        }
      } else {
        // ── HIT ──────────────────────────────────────────────────────────────
        // Cheat mods: Heavy Hand (damage_multiplier) / Lucky Edge
        // (crit_chance_boost) — PvE only, deliberately not applied in
        // pvp.js so cheat-mod power never affects player-vs-player fights.
        // Yoriichi's cat form (see lib/character-abilities.js) stacks
        // multiplicatively on top of the damage_multiplier cheat mod, same
        // way Premium/mods already stack rather than add — she is not a
        // mod, but the pipeline only exposes one multiplier slot here.
        const catFormMult = catFormAttackDamage(player)
        // Dance of the Rain — Tyla & Alya's automatic legendary twin strike,
        // fires exactly once the first turn battleState.turn reaches 10.
        // Same "just the multiplier" contract as catFormMult above; stacks
        // into the same slot since Tyla/Yoriichi are mutually exclusive
        // equips (one equippedCharacter id at a time).
        const danceMult = danceOfTheRainMultiplier(player, bs)
        const { rawDmg, isCrit } = calcPlayerDamage(
          player,
          null,
          catFormMult * danceMult,
          0,
        )

        // Named-weapon/item passives: pre-defense damage overrides (e.g.
        // Tensa Zangetsu's x1.5, One For All's stack bonus, Venuzdonoa's
        // DEF-bypass).
        const preNamedResult = applyAllNamedPassives(
          player,
          NP_EVENT.PRE_DAMAGE,
          {
            enemy: e,
            bs,
            damage: rawDmg,
            rawDmg,
            isCrit,
          },
        )
        const effectiveRawDmg =
          preNamedResult.modified && preNamedResult.damage !== undefined
            ? preNamedResult.damage
            : rawDmg
        if (preNamedResult.lines.length)
          msg += preNamedResult.lines.join('\n') + '\n'

        let finalDmg = preNamedResult.bypassDefense
          ? effectiveRawDmg
          : applyDefense(effectiveRawDmg, getEffectiveStat(e, 'def'), player, e)

        // ── Combo System Hook ──────────────────────────────────────────
        // Check if this basic attack triggers a combo
        const comboResult = recordComboAbility(player, 'basic_attack')
        if (comboResult.combo) {
          const baseDmg = finalDmg
          finalDmg = applyComboBonus(finalDmg, comboResult.combo)
          msg += `\n${formatComboTrigger(comboResult.combo, comboResult.isNew, baseDmg, finalDmg)}\n`
        }

        if (boss) {
          // PLAYER_BASIC_ATTACK — Eren's Path Foresight dodges first 2 basic attacks, etc.
          const basicResult = applyBossSpecial(
            player,
            EVENT.PLAYER_BASIC_ATTACK,
            {
              damage: finalDmg,
              element: 'physical',
              isCrit,
              isHit: true,
            },
          )
          if (basicResult.modified && basicResult.damage !== undefined)
            finalDmg = basicResult.damage
          if (basicResult.narrativeLine)
            msg += `_${basicResult.narrativeLine}_\n`

          // ENEMY_TAKE_DAMAGE — Gojo nullifies, Kaido halves, Mahoraga adapts, etc.
          const takeResult = applyBossSpecial(player, EVENT.ENEMY_TAKE_DAMAGE, {
            damage: finalDmg,
            element: 'physical',
            isCrit,
            isHit: true,
          })
          if (takeResult.modified && takeResult.damage !== undefined)
            finalDmg = takeResult.damage
          if (takeResult.narrativeLine) msg += `_${takeResult.narrativeLine}_\n`

          // Meliodas Full Counter — reflect damage back at player
          if (takeResult.reflectDamage) {
            const applied = applyIncomingDamage(player, takeResult.reflectDamage)
            if (applied.message) msg += applied.message + '\n'
            if (applied.catFormDefeated) {
              return resolveCatFormDefeat(player, ctx, { boss })
            }
            // A reflection the funnel dodged outright (Minato's Flying Thunder
            // God, Ultra Instinct) took nothing; do not print what it carried.
            msg += applied.dodged
              ? `🔁 *Full Counter!* Your attack is reflected, and it finds nobody there.\n`
              : `🔁 *Full Counter!* Your attack is reflected!\n🩸 *${takeResult.reflectDamage}* damage back at you!\n`
            if (player.hp <= 0) {
              const res = await resolvePlayerHpZero(player, ctx, msg, { boss: true })
              if (!res.fallThrough) return res.returnValue
              msg = res.msg
            }
          }
        }

        // Yu Miaoyi — her hits can never be reduced to 0 (§3.6): the floor is
        // a flag the damage code reads, applied AFTER every boss-side damage
        // modifier, right before the enemy takes it.
        finalDmg = lucidFloorDamage(player, e, finalDmg)

        // Season 2 outgoing riders: forced crit, true-damage deletion.
        if (rAttackPlan) {
          if (rAttackPlan.forceCrit && !isCrit) finalDmg = Math.floor(finalDmg * 1.5)
          if (rAttackPlan.bypassDefense) finalDmg = Math.max(finalDmg, effectiveRawDmg)
          if (rAttackPlan.bonusTrueDamage > 0) finalDmg += rAttackPlan.bonusTrueDamage
          if (rAttackPlan.lines.length) msg += rAttackPlan.lines.join('\n') + '\n'
        }

        // C1 stagger: a currently-broken enemy eats amplified damage. The gauge
        // charge below is what breaks it for the FOLLOWING turn, not this hit.
        if (finalDmg > 0 && isStaggered(e)) {
          finalDmg = Math.floor(finalDmg * staggerDamageMult(e))
        }

        // Tower barriers must absorb the hit before HP and on-hit rewards.
        if (e.tower && finalDmg > 0) {
          const incoming = finalDmg
          finalDmg = absorbDamage(e, finalDmg, player)
          if (incoming > finalDmg) msg += `🛡️ *${e.name}'s barrier* absorbs ${incoming - finalDmg} damage.\n`
        }
        // Apply damage to enemy
        e.hp = Math.max(0, e.hp - finalDmg)

        const rHit = regressorOnPlayerHit(player, bs, e, { damage: finalDmg })
        if (rHit.lines.length) msg += rHit.lines.join('\n') + '\n'
        if (e.hp <= 0) {
          if (boss) cleanupBossFight(player)
          return handleVictory(player, e, ctx)
        }

        // Gameplay-upgrade hooks (C1 stagger, C3 limit). Best-effort and fully
        // guarded: a hook error must never swallow or alter the landed hit.
        try {
          if (finalDmg > 0) {
            addStagger(e, { crit: isCrit })
            noteDamageDealt(bs, finalDmg)
          }
        } catch { /* hook telemetry is best-effort */ }

        // Boss hits keep the terse two-line stamp so the cinematic wrapper reads
        // clean; a generic monster hit gets a rotating flavor line instead.
        if (boss) {
          msg += `⚔️ *${player.name}* attacks *${e.name}*!${isCrit ? ' ⚡ *CRIT!*' : ''}\n`
          msg += finalDmg > 0
            ? `💥 *${finalDmg}* damage!\n`
            : `🛡️ _Attack absorbed, no damage dealt!_\n`
        } else {
          msg += (finalDmg > 0
            ? playerHitLine(player.name, e, finalDmg, isCrit, player.equippedCharacter)
            : playerAbsorbedLine(player.name, e, player.equippedCharacter)) + '\n'
        }
        msg += buildDanceOfTheRainMessage(bs, player)

        // Texas follows ONLY this final owner hit; her cut bypasses every
        // mitigation/hit hook and never changes finalDmg for owner effects.
        texasHit = applyNighOmni(player, e, finalDmg)
        if (texasHit.message) msg += texasHit.message + '\n'

        // 🔥 Rengoku — Flame Breathing. The combo follows this landed hit and
        // adds a form for every consecutive turn the owner keeps landing one
        // (lib/rengoku.js). Same commit point and the same contract as Texas's
        // cut above: fed the FINAL owner damage, written straight onto HP, and
        // never seen by the owner's own on-hit effects below.
        flameCombo = applyFlameCombo(player, e, finalDmg)
        if (flameCombo.message) msg += flameCombo.message + '\n'

        // Named-weapon/item passives: post-hit effects (lifesteal, bonus
        // strikes, elemental add-on damage, crit-triggered reflect, etc.)
        const hitNamedResult = applyAllNamedPassives(
          player,
          NP_EVENT.PLAYER_HIT,
          {
            enemy: e,
            bs,
            isHit: true,
            isCrit,
            rawDmg: effectiveRawDmg,
            finalDmg,
          },
        )
        if (hitNamedResult.lines.length)
          msg += hitNamedResult.lines.join('\n') + '\n'

        // Dark Monarch pack — Dread lifesteal: heal the wielder a share of the
        // damage they just dealt (the incoming-cut half lives in absorbDamage).
        if (finalDmg > 0) {
          const ls = applyPackLifestealOnDeal(player, finalDmg)
          if (ls.heal > 0) {
            player.hp = Math.min(player.maxHp, player.hp + ls.heal)
            msg += ls.lines.join('\n') + '\n'
          }
        }

        // Urahara — Tear/Reshape (spec §13.2): apply the in-battle 'sever'
        // bleed to the enemy on the player's own hit landing. Applied
        // after damage this hit dealt, before the e.hp<=0 victory check
        // below, so a lethal hit still short-circuits to victory without
        // wastefully applying a bleed to an enemy that's already dead.
        if (e.hp > 0) {
          const tearLine = applyTearOnHit(player, e, ctx)
          if (tearLine) msg += tearLine + '\n'
        }
        if (e.hp <= 0) {
          if (texasHit?.triggered || flameCombo?.triggered) await ctx.reply(msg.trimEnd())
          if (boss) cleanupBossFight(player)
          return handleVictory(player, e, ctx)
        }

        if (boss) {
          // PLAYER_HIT_ENEMY — after damage lands (Shanks hit-streak, Aizen hypnosis, etc.)
          const hitResult = applyBossSpecial(player, EVENT.PLAYER_HIT_ENEMY, {
            damage: finalDmg,
            isCrit,
            element: 'physical',
            isHit: true,
          })
          if (hitResult.narrativeLine) msg += `_${hitResult.narrativeLine}_\n`
          if (finalDmg > 0) msg += `💬 _"${getBossHitLine(player)}"_\n`
        }

        if (e.hp <= 0) {
          if (boss) cleanupBossFight(player)
          return handleVictory(player, e, ctx)
        }

        if (boss) {
          // Phase transition — announce narrative when HP crosses 75 / 50 / 25 %
          const phase = checkBossPhase(player)
          if (phase?.triggered && phase.lines?.length) {
            msg += `\n⚡ *— PHASE SHIFT —*\n` + phase.lines.join('\n') + '\n'
          }
        }
      }

      // ⚡ Second Transcendance — the equipped Transcendent acts a SECOND time
      // every turn. One extra, independent strike, inserted after the primary
      // hit/miss resolves and BEFORE the enemy's status tick + counter-attack,
      // so it's part of the same turn. It never advances bs.turn and never adds
      // a second retaliation, keeping every turn-counter-keyed ability (Alya,
      // Dance of the Rain, boss phases, cooldowns, durability) in lockstep. It
      // fires even when the first swing missed — the passive is "always twice."
      if (e.hp > 0 && hasSecondTranscendance(player)) {
        const echo = rollEchoStrike(player, e) // basic attack — no skill scaling
        if (echo?.missed) {
          msg += `⚡ *SECOND TRANSCENDANCE* — the echo swings and *misses!*\n`
        } else if (echo) {
          let echoDmg = applyDefense(echo.rawDmg, getEffectiveStat(e, 'def'), player, e)
          if (boss) {
            // Route the echo through the same nullify/halve/adapt hook the
            // primary hit uses, so Gojo/Kaido/Mahoraga still govern the 2nd hit.
            const echoTake = applyBossSpecial(player, EVENT.ENEMY_TAKE_DAMAGE, {
              damage: echoDmg, element: 'physical', isCrit: echo.isCrit, isHit: true,
            })
            if (echoTake.modified && echoTake.damage !== undefined) echoDmg = echoTake.damage
            if (echoTake.narrativeLine) msg += `_${echoTake.narrativeLine}_\n`
          }
          echoDmg = lucidFloorDamage(player, e, echoDmg)
          e.hp = Math.max(0, e.hp - echoDmg)
          msg += `⚡ *SECOND TRANSCENDANCE* — *${player.name}* moves again!${echo.isCrit ? ' ⚡ *CRIT!*' : ''}\n`
          msg += echoDmg > 0 ? `🩸 *${echoDmg}* damage!\n` : `🛡️ _The echo is absorbed — no damage._\n`
        }
        if (e.hp <= 0) {
          if (boss) cleanupBossFight(player)
          return handleVictory(player, e, ctx)
        }
      }

      // 📺 Streamer — a live crowd swells with every blow struck in the dungeon,
      // so .live-blast scales up the longer the streamer fights. No-op for
      // anyone not currently live (plugins/stream.js owns the viewer meter).
      //
      // The context is the whole point: the room is told WHICH boss, WHICH
      // floor and WHICH dungeon, so its callouts can name them instead of
      // saying "nice hit" at every fight in the game (lib/astratok/crowd.js).
      if (isStreaming(player.id)) {
        rampStreamViewers(player.id, {
          boss: boss ? (e.name ?? 'a boss') : null,
          target: e.name ?? null,
          // What is left of it, so chat can say "down to 400" about a real bar
          // instead of talking about the fight in general.
          hp: e.hp > 0 ? Math.round(e.hp) : null,
          floor: bs.floor ?? player.dungeonFloor ?? null,
          dungeon: player.dungeonName ?? player.dungeonId ?? null,
          action: 'swinging on the floor',
        })
      }

      // ── Enemy's own status effects tick before counter-attack ─────────────
      const enemyStatus = processStatusTurn(e, { bossState: player.battleState?.bossState })
      if (enemyStatus.lines.length) msg += enemyStatus.lines.join('\n') + '\n'
      if (!boss) bs.regressorIncomingInfo = { attackName: e.name, element: e.element ?? 'physical', isSpecial: false }
      // A boss reads the board. On its own turn it may shake one hostile status
      // off (league-ai.js's applyAdventurerAwareness, scoped to bosses so a burn
      // on a floor-3 bat still lands). Everything below runs regardless — a
      // cleansed boss still acts, it just acts clean.
      const foeRead = enemyAwareness(e, Math.random, { boss: Boolean(boss) })
      if (foeRead.lines.length) msg += foeRead.lines.join('\n') + '\n'
      if (e.hp <= 0) {
        if (boss) cleanupBossFight(player)
        return handleVictory(player, e, ctx)
      }

      // C1 stagger: a broken enemy skips its turn before every other enemy-turn
      // rule (grace, hard CC, boss/monster retaliation) gets to run.
      if (isStaggered(e)) {
        tickStagger(e)
        msg += `\n💫 *${e.name}* is staggered and cannot act!\n`
      // 👑 King Yato — Grace of the Crown: turns 1-5 the enemy does not act at all.
      } else if (graceHoldsEnemyTurn(player)) {
        msg += `\n${graceEnemyHeldLine(e, player)}\n`
      } else if (enemyStatus.incapacitated || regressorHoldsEnemyTurn(player, bs)) {
        msg += `💫 *${e.name}* is unable to attack this turn!\n`
      } else if (boss) {
        // ── BOSS counter-attack ───────────────────────────────────────────────
        const bossAtk = buildEnemyAttack(player)

        // Miyashi's frostlock — a locked enemy still ACTS, but only with a
        // basic attack: no named special, no barrage, no DEF-bypass, no
        // double strike (see lib/character-abilities.js applyFrostlockGate).
        // Bosses are the only PvE enemies that own specials to lose, so this
        // is exactly where the lockdown is supposed to bite. Suppressing the
        // ENEMY_DEAL_DAMAGE event is what drops guaranteedHits/multi-hit.
        const frostGate = applyFrostlockGate(e, 'skill')
        if (frostGate.blocked) {
          bossAtk.attackName   = 'a frost-numbed Strike'
          bossAtk.narrativeLines = []
          bossAtk.bypassDefense  = false
          bossAtk.doubleStrike   = false
          msg += `❄️ *${e.name}* is *frostlocked* — the technique dies in their throat.\n`
        }

        const dealResult = frostGate.blocked
          ? { modified: false, damage: bossAtk.damage }
          : applyBossSpecial(player, EVENT.ENEMY_DEAL_DAMAGE, {
              damage: bossAtk.damage,
              isHit: true,
            })
        const rawBossAtk =
          dealResult.modified && dealResult.damage !== undefined
            ? dealResult.damage
            : bossAtk.damage

        // guaranteedHits on ENEMY_DEAL_DAMAGE = array of damage values (future-proof)
        const hitList = Array.isArray(dealResult.guaranteedHits)
          ? dealResult.guaranteedHits
          : null
        let totalPlayerDmg = 0

        if (hitList) {
          // Multi-hit true-damage bursts (Jotaro-style) are intentionally not
          // run through named passives (flash_step_dodge et al. explicitly
          // don't apply to true-damage/%-HP effects — see named-passives.js).
          //
          // Mahoraga is the exception: the Wheel adapts to ANY move, true
          // damage included, so the whole volley is resolved as one exposure
          // to bossAtk.attackName. Once mastered the entire barrage lands for
          // 0 (the Garden's dodge still doesn't apply — trueDamage).
          const mega = resolveMegumiIncoming(player, {
            damage: 0, trueDamage: true,
            kind: 'boss', id: bossAtk.attackName, label: bossAtk.attackName, bs,
          })
          if (mega.wheelCaption) void sendWheelSpin(ctx, mega.wheelCaption).catch(() => {})
          if (mega.message) msg += mega.message + '\n'

          if (mega.nullified) {
            msg += `${e.emoji ?? '👾'} *${e.name}* unleashes *${bossAtk.attackName}*! _(${hitList.length} hits)_\n`
            msg += `🩸 *0* total damage — the Divine General has already mastered it.\n`
          } else {
          // A barrage is ONE swing for the purposes of the two defender-side
          // answers: My Desire turns the blow aimed at her (the whole flurry, not
          // one claw of it, and not four times over), and her Return Stroke is a
          // single riposte that cannot be spent twice on the same commit. Printed
          // before the loop so the player reads the answer, then what landed.
          const witchBarrage = heroesAnswerHit({ beastHandled: true,
            player, enemy: e, ctx, msg: '',
            damage: hitList.reduce((total, n) => total + (Number(n) || 0), 0),
            directAttack: true, boss,
          })
          if (witchBarrage.returnValue !== undefined) return witchBarrage.returnValue
          if (witchBarrage.lines.length) msg += witchBarrage.lines.map(l => l + '\n').join('')
          const barrageTurned = witchBarrage.damage <= 0 && hitList.length > 0
          for (const rawHit of hitList) {
            if (barrageTurned) break
            let hDmg = rawHit
            const beastHit = beastIntervention(player, BEAST_EVENT.ENEMY_DEAL_DAMAGE, {
              enemy: e, bs, damage: hDmg,
            })
            if (beastHit.modified) {
              hDmg = beastHit.damage ?? hDmg
              msg += beastHit.lines.join('\n') + '\n'
            }
            const applied = applyIncomingDamage(player, hDmg)
            totalPlayerDmg += applied.damage
            if (applied.message) msg += applied.message + '\n'
            if (applied.catFormDefeated) {
              return resolveCatFormDefeat(player, ctx, { boss })
            }
          }
          msg += `${e.emoji ?? '👾'} *${e.name}* unleashes *${bossAtk.attackName}*! _(${hitList.length} hits)_\n`
          if (!witchBarrage.turned) msg += `🩸 *${totalPlayerDmg}* total damage! _(ignores DEF)_\n`
          }
        } else {
          const defendSingle = (dmg) =>
            bossAtk.bypassDefense
              ? dmg
              : calcMonsterDamage(dmg, getEffectiveStat(player, 'def'), false)

          let primaryHit = defendSingle(rawBossAtk)

          // Named-weapon/item passives: incoming-damage overrides (dodge,
          // block, resolve reduction) and counter-hooks (full counter armor,
          // Lostvayne's crit-reflect tracking).
          const dmgNamedResult = applyAllNamedPassives(
            player,
            NP_EVENT.ENEMY_DEAL_DAMAGE,
            {
              enemy: e,
              bs,
              damage: primaryHit,
              trueDamage: bossAtk.bypassDefense,
            },
          )
          if (dmgNamedResult.modified) {
            if (dmgNamedResult.damage !== undefined)
              primaryHit = dmgNamedResult.damage
            msg += dmgNamedResult.lines.join('\n') + '\n'
          }

          // Nisha's Serpent's Grace — flat dodge chance, same shape/exemption
          // as named-passives.js's flash_step_dodge (skipped for true damage).
          const dodgeRoll = rollSerpentsGrace(player, { damage: primaryHit, trueDamage: bossAtk.bypassDefense })
          if (dodgeRoll.dodged) {
            primaryHit = 0
            msg += dodgeRoll.message + '\n'
          }

          // Megumi — Mahoraga's Wheel (adapts to this boss attack by name,
          // nullifying it outright once mastered) then the Chimera Shadow
          // Garden's shadow-travel dodge. No-op for any other character.
          const mega = resolveMegumiIncoming(player, {
            damage: primaryHit,
            trueDamage: !!bossAtk.bypassDefense,
            kind: 'boss', id: bossAtk.attackName, label: bossAtk.attackName, bs,
          })
          if (mega.wheelCaption) void sendWheelSpin(ctx, mega.wheelCaption).catch(() => {})
          if (mega.message) msg += mega.message + '\n'
          primaryHit = mega.damage
          const megumiVoided = mega.nullified || mega.dodged

          // Summon Beast: chance to redirect this hit onto the beast's HP.
          const beastDmgResult = beastIntervention(player, BEAST_EVENT.ENEMY_DEAL_DAMAGE, {
            enemy: e,
            bs,
            damage: primaryHit,
          })
          if (beastDmgResult.modified) {
            if (beastDmgResult.damage !== undefined) primaryHit = beastDmgResult.damage
            msg += beastDmgResult.lines.join('\n') + '\n'
          }

          const witchPrimary = heroesAnswerHit({ beastHandled: true, player, enemy: e, ctx, msg: '', damage: primaryHit, directAttack: true, boss })
          if (witchPrimary.returnValue !== undefined) return witchPrimary.returnValue
          if (witchPrimary.lines.length) msg += witchPrimary.lines.map(l => l + '\n').join('')
          primaryHit = witchPrimary.damage

          const instinctPrimary = absorbInstinctAttack(player, primaryHit, e)
          const absorbedPrimary = instinctPrimary.damage
          if (instinctPrimary.dodged) msg += '\n💨 *Ultra Instinct!* Attack dodged.\n'
          const shieldBlockedPrimary = (instinctPrimary.dodged ? 0 : primaryHit - absorbedPrimary)
          const appliedPrimary = applyIncomingDamage(player, absorbedPrimary, null, true, { ultraInstinctChecked: true })
          totalPlayerDmg += appliedPrimary.damage
          if (appliedPrimary.message) msg += appliedPrimary.message + '\n'
          if (appliedPrimary.catFormDefeated) {
            return resolveCatFormDefeat(player, ctx, { boss })
          }
          if (shieldBlockedPrimary > 0) msg += `🛡️ Shield absorbed *${shieldBlockedPrimary}* damage!\n`

          if (bossAtk.doubleStrike) {
            // Deku Gear Shift — second hit. Nullified/evaded alongside the
            // first when Mahoraga has mastered the move or Megumi slipped
            // into the shadows: it's the same attack, twice.
            let hit2 = megumiVoided ? 0 : defendSingle(rawBossAtk)
            const beastHit2 = beastIntervention(player, BEAST_EVENT.ENEMY_DEAL_DAMAGE, {
              enemy: e, bs, damage: hit2,
            })
            if (beastHit2.modified) {
              if (beastHit2.damage !== undefined) hit2 = beastHit2.damage
              msg += beastHit2.lines.join('\n') + '\n'
            }
            const instinctHit2 = absorbInstinctAttack(player, hit2, e)
            const absorbedHit2 = instinctHit2.damage
            if (instinctHit2.dodged) msg += '\n💨 *Ultra Instinct!* Attack dodged.\n'
            const shieldBlockedHit2 = (instinctHit2.dodged ? 0 : hit2 - absorbedHit2)
            const appliedHit2 = applyIncomingDamage(player, absorbedHit2, null, true, { ultraInstinctChecked: true })
            totalPlayerDmg += appliedHit2.damage
            if (appliedHit2.message) msg += appliedHit2.message + '\n'
            if (appliedHit2.catFormDefeated) {
              return resolveCatFormDefeat(player, ctx, { boss })
            }
            if (shieldBlockedHit2 > 0) msg += `🛡️ Shield absorbed *${shieldBlockedHit2}* damage!\n`
            msg += `${e.emoji ?? '👾'} *${e.name}* uses *${bossAtk.attackName}*! ⚡ *DOUBLE STRIKE!*\n`
            if (!witchPrimary.turned || totalPlayerDmg > 0) msg += `🩸 *${totalPlayerDmg}* total damage!\n`
          } else {
            msg += `${e.emoji ?? '👾'} *${e.name}* uses *${bossAtk.attackName}*!\n`
            // The number printed here is the blow as it was THROWN. A blow the
            // funnel reports as dodged outright (Minato's Flying Thunder God)
            // took nothing, and printing the thrown number under its own
            // "dodged" line reads as the dodge having failed.
            if (!witchPrimary.turned) msg += `🩸 *${instinctPrimary.dodged || appliedPrimary.dodged ? 0 : primaryHit}* damage!${bossAtk.bypassDefense ? ' _(bypasses DEF)_' : ''}\n`
          }
        }

        if (bossAtk.narrativeLines?.length)
          msg += bossAtk.narrativeLines.map(l => `_${l}_`).join('\n') + '\n'
        if (dealResult.narrativeLine) msg += `_${dealResult.narrativeLine}_\n`

        // Side-effects: Naruto Baryon lifespan drain reduces player stats
        msg = applyBossStatDrain(player, dealResult, msg)

        if (dealResult.playerMpDrain) {
          const drained = Math.min(
            player.mp ?? 0,
            Math.floor(dealResult.playerMpDrain),
          )
          player.mp = Math.max(0, (player.mp ?? 0) - drained)
          if (drained > 0) msg += `💧 *${drained}* MP drained!\n`
        }

        msg += `\n💬 _"${getBossTaunt(player)}"_\n`

        if (player.hp <= 0) {
          const res = await resolvePlayerHpZero(player, ctx, msg, { boss: true })
          if (!res.fallThrough) return res.returnValue
          msg = res.msg
        }
      } else if (Math.random() > calcMonsterHitChance(e, player)) {
        // ── Regular enemy misses ──────────────────────────────────────────────
        msg += '\n' + enemyMissLine(e, player.equippedCharacter)
        // The tower's clock and separately telegraphed abilities belong to an
        // enemy turn, not just to a landed basic hit.
        if (e.tower || e.survival) {
          const monLines = []
          applyMonsterAbilityTurn({ player, enemy: e, state: bs, lines: monLines, baseDamage: 0, isDefending: false })
          if (monLines.length) msg += '\n' + monLines.join('\n')
          if (player.hp <= 0) {
            const res = await resolvePlayerHpZero(player, ctx, msg, {})
            if (!res.fallThrough) return res.returnValue
            msg = res.msg
          }
        }
      } else {
        // ── Regular enemy hits ────────────────────────────────────────────────
        let enemyDmg = calcMonsterDamage(
          getEffectiveStat(e, 'atk'),
          getEffectiveStat(player, 'def'),
          false,
        )

        // Named-weapon/item passives: incoming-damage overrides.
        const dmgNamedResult = applyAllNamedPassives(
          player,
          NP_EVENT.ENEMY_DEAL_DAMAGE,
          {
            enemy: e,
            bs,
            damage: enemyDmg,
          },
        )
        let dmgNamedLines = ''
        if (dmgNamedResult.modified) {
          if (dmgNamedResult.damage !== undefined)
            enemyDmg = dmgNamedResult.damage
          dmgNamedLines = '\n' + dmgNamedResult.lines.join('\n')
        }

        // Nisha's Serpent's Grace — flat dodge chance against regular
        // (non-boss) enemy hits too.
        const dodgeRoll = rollSerpentsGrace(player, { damage: enemyDmg, trueDamage: false })
        if (dodgeRoll.dodged) {
          enemyDmg = 0
          dmgNamedLines += '\n' + dodgeRoll.message
        }

        // Megumi — Mahoraga's Wheel + the Garden's shadow dodge. A plain
        // enemy's basic attack is one move identity ('enemy:basic'), so three
        // straight swings from the same monster get mastered and then land
        // for 0 for the rest of the fight.
        const mega = resolveMegumiIncoming(player, {
          damage: enemyDmg, trueDamage: false,
          kind: 'enemy', label: `${e.name}'s attack`, bs,
        })
        if (mega.wheelCaption) void sendWheelSpin(ctx, mega.wheelCaption).catch(() => {})
        if (mega.message) dmgNamedLines += '\n' + mega.message
        enemyDmg = mega.damage

        // Summon Beast: chance to redirect this hit onto the beast's HP.
        const beastDmgResult = beastIntervention(player, BEAST_EVENT.ENEMY_DEAL_DAMAGE, {
          enemy: e,
          bs,
          damage: enemyDmg,
        })
        if (beastDmgResult.modified) {
          if (beastDmgResult.damage !== undefined) enemyDmg = beastDmgResult.damage
          dmgNamedLines += '\n' + beastDmgResult.lines.join('\n')
        }

        // Both defender-side answers, in the slot lib/witch-heroes-pve.js pins
        // for every PvE entry point: after the mitigations, before shields and
        // HP, so a blow Scarlett turns is never absorbed by a shield, never
        // counted as a hit she took, and never feeds the lifesteal or the
        // riposte bookkeeping below. Going through the shared helper is the point:
        // written inline here it only ever existed on this one path, which is how
        // "her skill does nothing against a boss" got reported.
        const witchAnswer = heroesAnswerHit({ beastHandled: true, player, enemy: e, ctx, msg: '', damage: enemyDmg, directAttack: true, boss })
        if (witchAnswer.lines.length) msg += '\n' + witchAnswer.lines.join('\n')
        enemyDmg = witchAnswer.damage
        if (witchAnswer.returnValue !== undefined) return witchAnswer.returnValue

        const instinctEnemyDmg = absorbInstinctAttack(player, enemyDmg, e)
        const absorbedEnemyDmg = instinctEnemyDmg.damage
        if (instinctEnemyDmg.dodged) msg += '\n💨 *Ultra Instinct!* Attack dodged.\n'
        const shieldBlockedEnemy = (instinctEnemyDmg.dodged ? 0 : enemyDmg - absorbedEnemyDmg)
        const appliedEnemy = applyIncomingDamage(player, absorbedEnemyDmg, null, true, { ultraInstinctChecked: true })
        if (appliedEnemy.message) msg += appliedEnemy.message + '\n'
        if (appliedEnemy.catFormDefeated) {
          return resolveCatFormDefeat(player, ctx, { boss })
        }
        // enemyHitLine() is drawn from a pool of LANDED-blow lines ("catches you
        // clean", "lands it hard"). A blow the funnel reports as dodged outright
        // (Minato's Flying Thunder God, whose own line is already above) did
        // not land, so it gets no landed-blow line with a 0 in it.
        if (appliedEnemy.dodged) {
          // Leave the message exactly where a landed-hit line would have left
          // it (no trailing newline), so the screen below is spaced the same.
          msg = msg.replace(/\n+$/, '') + dmgNamedLines
        } else if (!witchAnswer.turned) {
          msg += '\n' + enemyHitLine(e, appliedEnemy.damage, player.equippedCharacter) + dmgNamedLines
        }
        if (shieldBlockedEnemy > 0) msg += `\n🛡️ Shield absorbed *${shieldBlockedEnemy}* damage!`

        // ── The Dreamlands: the Touch, then the nightmare's own ability ─────
        // A landed hit from a nightmare always sleeps you (unless warded) and
        // always leaves a decay stack; then it may use one of its abilities.
        // This is the 1v1 half of the ONE resolver (§8.2) — swarm floors use
        // lib/swarm-combat.js and journey ambushes use
        // lib/dreamlands-journey.js, both calling exactly these two functions.
        if (appliedEnemy.damage > 0 && isNightmare(e)) {
          const dreamLines = []
          const dreamTurn = applyNightmareMonsterTurn({ player, enemy: e, state: bs, lines: dreamLines })
          if (dreamLines.length) msg += '\n' + dreamLines.join('\n')
          if (dreamTurn.damage > 0) msg += `\n🩸 *${e.name}* takes *${dreamTurn.damage}* from you.`
        } else if (!instinctEnemyDmg.dodged && !boss && e.hp > 0) {
          const monLines = []
          applyMonsterAbilityTurn({ player, enemy: e, state: bs, lines: monLines, baseDamage: appliedEnemy.damage, isDefending: false })
          if (monLines.length) msg += '\n' + monLines.join('\n')
        }

        if (player.hp <= 0) {
          const res = await resolvePlayerHpZero(player, ctx, msg, {})
          if (!res.fallThrough) return res.returnValue
          msg = res.msg
        }
      }

      // ── TURN_END event ────────────────────────────────────────────────────
      if (boss) {
        const teResult = applyBossSpecial(player, EVENT.TURN_END, {})
        if (teResult.narrativeLine) msg += `\n_${teResult.narrativeLine}_`
      }

      // Named-weapon/item passives: end-of-turn effects (stacking buffs,
      // periodic shockwaves, lifespan drain).
      const teNamedResult = applyAllNamedPassives(player, NP_EVENT.TURN_END, {
        enemy: e,
        bs,
      })
      if (teNamedResult.modified) msg += '\n' + teNamedResult.lines.join('\n')
      if (e.hp <= 0) {
        if (boss) cleanupBossFight(player)
        return handleVictory(player, e, ctx)
      }

      // Premium ability passive + pack thorns: the player was struck this turn,
      // so punish the attacker (freeze/burn/sleep chance, Gemstone flame-thorns
      // burn, Sicilian riposte reflect). Runs after the TURN_END victory check
      // and before the status bar so any riposte chip — and a possible KO from
      // it — land on the same HP the bar then renders.
      if (player.hp < hpBeforeTurn && e.hp > 0) {
        const struck = applyStruckReactions(player, e, hpBeforeTurn - player.hp)
        if (struck.lines.length) msg += '\n' + struck.lines.join('\n')
        if (struck.counterDamage > 0) {
          e.hp = Math.max(0, e.hp - struck.counterDamage)
          if (e.hp <= 0) {
            if (boss) cleanupBossFight(player)
            return handleVictory(player, e, ctx)
          }
        }
      }

      if (!boss) {
        msg +=
          `\n\n👤 *${player.name}*\n❤️ ${hpBar(player.hp, player.maxHp)}  💧 ${player.mp}/${player.maxMp} MP${dreamstepTurnLine(player)}\n` +
          `${e.emoji ?? '👾'} *${e.name}*\n❤️ ${hpBar(e.hp, e.maxHp)}\n\n` +
          `*${p}attack* · *${p}skill <name>* · *${p}defend* · *${p}flee*`
      }

      // The shared completed-turn clock: Ronova's count, Maiden's charge, the
      // countdown's narration, and the settle for a beam that ends the fight. A
      // turn that never reached here (a victory above, a death below) is not a
      // completed turn, which is what keeps the count honest with the bar.
      const witchTurn = await heroesTurnBoundary({ player, enemy: e, ctx, msg, turnId: bs.turn ?? 1, boss })
      if (witchTurn.returnValue !== undefined) return await witchTurn.returnValue
      msg = witchTurn.msg

      const rEnd = regressorTurnEnd(player, bs)
      if (rEnd.lines.length) msg += rEnd.lines.join('\n') + '\n'
      if (e.hp <= 0) {
        if (boss) cleanupBossFight(player)
        return handleVictory(player, e, ctx)
      }

      bs.turn = (bs.turn ?? 1) + 1
      player.battleState = bs

      // Durability — weapon wears every turn it's used; armor wears only
      // if the player actually took damage this turn.
      const wWear = wearWeaponOnTurn(player)
      msg += breakMessage(wWear)
      if (player.hp < hpBeforeTurn) {
        const aWear = wearArmorOnHit(player, hpBeforeTurn - player.hp)
        msg += breakMessage(aWear)
      }

      await sendWillowAdvisory(ctx, player, e, boss)
      // Engine annotation rides at the very top of the turn text, the same place
      // plugins/pvp.js puts it — it is a caption on the fight, not a result.
      if (freshGambits.length) msg = formatPveGambits(freshGambits) + '\n' + msg
      if (boss) await sendCinematicBossTurn(ctx, { player, e, body: msg, hpBeforeTurn, eHpBeforeTurn })
      // No cinematic payload here any more: a terminal scene is presented inside
      // heroesTurnBoundary(), which is the only way the 17 other PvE turn shapes
      // get it too. The countdown's own background art still rides on
      // bs.cinematicBackground, which lib/witch-heroes.js sets as it ticks.
      else {
        const doctrinePending = flushDoctrineLines(bs)
        if (doctrinePending) msg += `\n${doctrinePending}`
        const doctrineLine = doctrineBattleLine(player, bs)
        if (doctrineLine) msg += `\n${doctrineLine}`
        await sendBattleTurnReply(ctx, { bs, player, e, msg, hpBeforeTurn, eHpBeforeTurn, boss })
      }
      return player
    })
  },
}
