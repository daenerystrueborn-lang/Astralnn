/**
 * <prefix>clane-spin <amount>
 *
 * Clane's banner. 300 spins at 1.5 Gems each; spins 1-257 are a true dead zone,
 * and from 258 every roll is a flat 50% sustained to the cap. One-of-one
 * bot-wide, the same ownership model as Gogeta/Cid/Victoria/Queen of Fairies:
 * the first player anywhere to land her takes the lock through
 * claimExclusiveSpinForPlayer() and the banner closes for everyone, in chat and
 * on the website alike.
 *
 * Odds, caps and the pull loop live in lib/spin-banners.js, NOT here, so the
 * website's POST /api/characters/clane/spin plays the exact same banner. This
 * file owns art and copy only.
 *
 * Never prints deadZoneUntil or plateauChance. Only the pity bar (progress
 * toward the 300-spin ceiling) is player-facing.
 *
 * Everything she does once owned lives in lib/clane.js (the feed, the thirst)
 * and plugins/clane.js (talking to her). This file only hands her over.
 */
import { config } from '../config.js'
import { getExclusiveSpinWinner } from '../lib/season-engine.js'
import { characterMap } from '../lib/game-data.js'
import { getPlayer, updatePlayer } from '../lib/player-repo.js'
import { roundGems, fmtGems } from '../lib/format.js'
import { characterStars } from '../lib/rarity.js'
import { spinLockGate } from '../lib/spin-locks.js'
import { getSpinBanner, runSpinBatch } from '../lib/spin-banners.js'
import { CLANE_ID, CLANE_ART } from '../lib/clane.js'

const CHARACTER_ID = CLANE_ID
const BANNER = getSpinBanner(CHARACTER_ID)
const RULE = '━━━━━━━━━━━━━━━━━━━━'

const MISS_LINES = [
  'The candle goes out. Something breathes in the dark, decides against you, and leaves.',
  'A bat crosses the window and does not stop.',
  'The room goes cold enough to see your own breath. Nobody is standing in it.',
  'You hear a small, patient laugh from the next room. The door is locked.',
  'The wine in the glass has gone still. Whatever was drinking from it is done with you.',
  'She was here. She is not here now. That is the whole answer.',
]

function missLine(spin) {
  return `🩸 _${MISS_LINES[spin % MISS_LINES.length]}_`
}

/** Progress toward the spin cap. Never reveals the plateau. */
function pityBar(spin, width = 10) {
  const filled = Math.max(0, Math.min(width, Math.round((spin / BANNER.maxSpinsPerPlayer) * width)))
  return `${'▰'.repeat(filled)}${'▱'.repeat(width - filled)}`
}

function reel(results) {
  const MAX_ROWS = 5
  const marks = results.map(r => (r.won ? '✦' : '·'))
  const rows = []
  for (let i = 0; i < marks.length; i += 10) rows.push(marks.slice(i, i + 10).join(' '))
  if (rows.length <= MAX_ROWS) return rows.join('\n')
  return [`_…${(rows.length - MAX_ROWS) * 10} earlier spins_`, ...rows.slice(-MAX_ROWS)].join('\n')
}

async function replyOverArt(ctx, character, text) {
  const art = character?.spinImage ?? CLANE_ART.spin ?? character?.image
  if (!art) return ctx.reply(text)
  try {
    return await ctx.replyImage(art, text)
  } catch {
    return ctx.reply(text)
  }
}

function holderName(ctx, jid) {
  try {
    return getPlayer(ctx.db, jid)?.name ?? null
  } catch {
    return null
  }
}

export default {
  name: 'clane-spin',
  aliases: ['clanespin', 'vampire-spin', 'vampirespin', 'clane-banner'],
  category: 'character',
  requiresPlayer: true,
  description: 'Spin for Clane, the vampire, at 1.5 Gems per spin. One-of-one, bot-wide, never for sale',

  async run(ctx) {
    const p = config.prefix
    if (!ctx.player) return ctx.reply(`⚠️ Register first with *${p}register*.`)

    const character = characterMap[CHARACTER_ID]
    if (!character) return ctx.reply(`⚠️ Clane isn't configured yet.`)

    if (spinLockGate(ctx, CHARACTER_ID, character.name)) return

    const existingWinner = getExclusiveSpinWinner(ctx.db, CHARACTER_ID)
    if (existingWinner) {
      if (existingWinner === ctx.from) {
        return replyOverArt(ctx, character,
          `🩸 *Clane is already yours.*\n${RULE}\n` +
          `_She is fed, and she is patient. There is nothing left to spin for._\n` +
          `_Equip her with *${p}character equip ${CHARACTER_ID}*, then speak to her with *${p}clane <anything>*._`)
      }
      const who = holderName(ctx, existingWinner)
      return replyOverArt(ctx, character,
        `🔒 *THE HOUSE HAS A MASTER*\n${RULE}\n` +
        `_Clane has chosen ${who ? `*${who}*` : 'another player'}._\n\n` +
        `Only one player, bot-wide, could ever win her, and someone got there first. ` +
        `No gems were spent.`)
    }

    const isFirstEverAttempt = (ctx.player[BANNER.spinField] ?? 0) === 0
    const requested = Math.floor(Number(ctx.args[0]) || 1)

    let outcome = null
    await updatePlayer(ctx.db, ctx.from, (player) => {
      outcome = runSpinBatch(ctx.db, player, BANNER, ctx.from, requested)
    })

    if (outcome?.reason === 'owned') {
      return replyOverArt(ctx, character,
        `🩸 *Clane is already yours.*\n${RULE}\n` +
        `_Equip her with *${p}character equip ${CHARACTER_ID}*._`)
    }
    if (outcome?.reason === 'claimed') {
      return replyOverArt(ctx, character,
        `🔒 *THE HOUSE HAS A MASTER*\n${RULE}\n` +
        `_Clane was claimed while you were still reaching._\n\n` +
        `Another player got there first this very moment. No gems were spent.`)
    }
    if (outcome?.reason === 'gems') {
      return ctx.reply(
        `💎 *Not enough Gems.*\n${RULE}\n` +
        `One spin costs 💎*${BANNER.costPerSpin}*. You hold 💎*${fmtGems(outcome.gems)}*.\n\n` +
        `_Come back with more._`,
      )
    }
    if (outcome?.reason === 'exhausted_lifetime') {
      return ctx.reply(
        `🩸 *No spins left.*\n${RULE}\n` +
        `_You have used all *${BANNER.maxSpinsPerPlayer}* of your spins for Clane. ` +
        `She never turned her head once._`,
      )
    }

    const last = outcome.results[outcome.results.length - 1]
    const spent = roundGems(outcome.spinsUsed * BANNER.costPerSpin)
    const range = outcome.spinsUsed === 1
      ? `Spin *${last.spin}*`
      : `Spins *${outcome.results[0].spin}* → *${last.spin}*`

    if (outcome.reason === 'won') {
      const ability = character.ability
      return replyOverArt(ctx, character,
        `🩸✨ *SHE HAS CHOSEN* ✨🩸\n${RULE}\n` +
        `_Spin ${last.spin}. The room is warm, then it is not. You feel the bite before you see her, ` +
        `and you already know you will not be the one who lets go._\n\n` +

        `🏆 *${character.name.toUpperCase()} OBTAINED*\n` +
        `${character.emoji ?? '🩸'} *${characterStars(character.stars)}*` +
        (ability?.name ? `  ·  *${ability.name}*` : '') + `\n` +
        (character.description ? `\n_${character.description}_\n` : '') +

        `\n🔒 *GLOBALLY LOCKED.* No other player can ever obtain her.\n` +
        `_Taken on spin ${last.spin}, for 💎${spent} this pull._\n` +
        `💎 Remaining: 💎*${fmtGems(outcome.remaining)}*\n\n` +
        `*What you are now:*\n` +
        `1️⃣ *${p}character equip ${CHARACTER_ID}* — equip her, and every turn of every fight she takes *30%* of the enemy's maximum HP.\n` +
        `2️⃣ *The Toll* — the same turn takes *5%* of your maximum HP. She does not give it back.\n` +
        `3️⃣ *${p}clane <anything>* — talk to her. Her adult form answers. Every conversation raises her thirst.\n` +
        `4️⃣ *Thirst* — the more you talk, the more she takes. At *thirst 100* her Toll is *10%* of your HP per turn.\n` +
        `5️⃣ *Careful* — if she empties your HP, you die. All deaths wake in the *Astral Town Hospital*, and the door opens when the bill is paid.\n`,
      )
    }

    const lines = [
      `🩸 *SHE SAYS NOTHING*`,
      RULE,
      `_You spent 💎${spent}. The room stays empty._`,
      ``,
      range,
      reel(outcome.results),
      ``,
      missLine(last.spin),
      ``,
      `📿 Pity  ${pityBar(last.spin)}  *${last.spin}*/${BANNER.maxSpinsPerPlayer}`,
      `💎 Remaining: 💎*${fmtGems(outcome.remaining)}*`,
    ]

    if (requested > BANNER.maxSpinsPerCommand) {
      lines.push(``, `_Capped at *${BANNER.maxSpinsPerCommand}* spins per command. Run it again for more._`)
    } else if (outcome.spinsUsed < outcome.count) {
      lines.push(``, `_Gems ran out after *${outcome.spinsUsed}* of *${outcome.count}* requested spins._`)
    }

    const lossText = lines.join('\n')
    return isFirstEverAttempt ? replyOverArt(ctx, character, lossText) : ctx.reply(lossText)
  },
}
