import { config } from '../config.js'
import { isInSectEmpire } from '../lib/worlds.js'
import { sectCombatCommand } from '../lib/sect-fight.js'
import { updatePlayer, getPlayer } from '../lib/player-repo.js'
import { checkLucidOngoingTurn } from '../lib/yu-miaoyi.js'
import { calcMonsterDamage, hpBar } from '../lib/combat-engine.js'
import {
  processStatusTurn,
  resolvePlayerHpZero,
  checkCatFormOngoingTurn,
  handleVictory,
} from '../lib/combat-handlers.js'
import { getEffectiveStat, hasEffect } from '../lib/effects.js'
import { cleanupBossFight } from '../lib/boss-engine.js'
import { clearDungeonToolEffects } from '../lib/dungeon-tools.js'
import { beastIntervention, clearBeastEffects, BEAST_EVENT } from '../lib/beast-engine.js'
import { applyIncomingDamage, clearHypnosis, clearSnapshot } from '../lib/character-abilities.js'
import { resolveCatFormDefeat } from '../lib/combat-handlers.js'
import { resolveSwarmFlee } from '../lib/swarm-combat.js'
import { heroesAnswerHit } from '../lib/witch-heroes-pve.js'
import { addSeason02TowerAction } from '../lib/season-event-engine.js'
import { graceHoldsEnemyTurn, graceEnemyHeldLine } from '../lib/king-yato.js'
import { cathedralUp } from '../lib/starfall-champion.js'

export default {
  name: 'flee', aliases: ['run', 'escape'],
  category: 'combat', requiresPlayer: true,
  description: 'Attempt to flee from the current battle',

  async run(ctx) {
    // ── The Sect Empire fights through its own engine ──────────────────
    // A player in the sect world never reaches the Astral combat below:
    // their fight is lib/sect-combat.js, run by lib/sect-fight.js. Astra
    // Kingdom is untouched, because this is only true inside the sect.
    if (isInSectEmpire(ctx.player) && await sectCombatCommand(ctx, 'flee')) return
    const p = config.prefix
    // Yu Miaoyi — the owner's battle commands are refused while she is
    // driving, and her auto-fight resumes. Runs BEFORE updatePlayer below:
    // the driver writes through updatePlayer itself and must never nest.
    {
      const lucid = await checkLucidOngoingTurn(getPlayer(ctx.db, ctx.from), ctx)
      if (lucid.intercepted) return
    }
    await updatePlayer(ctx.db, ctx.from, async player => {
      // Swarm floors (Entry Tower prototype) run the multi-monster engine in
      // lib/swarm-combat.js; the 1v1 flee below is untouched everywhere else.
      if (player.battleState?.mode === 'swarm') return resolveSwarmFlee(player, ctx)
      // Party (.dparty) combat is a separate state machine (see
      // plugins/party.js's header comment) — it sets player.inBattle=true
      // but deliberately never populates player.battleState (party fights
      // are multi-actor and don't map onto the solo battleState shape).
      // That combination (inBattle true, battleState falsy) is unique to
      // party combat — dungeon.js and pvp.js both always set a full
      // battleState alongside inBattle — so it's a safe, unambiguous
      // signal to catch here, BEFORE the generic "not in battle" check
      // below wrongly tells an actively-fighting party member the
      // opposite of what's true. Real flee logic for party fights lives
      // in battleFlee() in plugins/party.js (via .pflee / .dparty flee).
      if (player.inBattle && !player.battleState) {
        await ctx.reply(
          `👥 *You're in a party battle — use *${p}pflee* instead.*\n_(alias for *${p}dparty flee*)_`,
        )
        return player
      }
      if (!player.inBattle || !player.battleState) {
        await ctx.reply(`❌ *Not in battle.*`)
        return player
      }
      // ⛪ Sealed Doors — while the Burning Cathedral stands, nothing leaves.
      // The gate sits ahead of every other flee rule, exactly where the
      // battle's own geometry is asserted, so no roll can open what the
      // domain shut. It does not consume the turn; it simply never happens.
      if (cathedralUp(player)) {
        await ctx.reply('⛪ *The doors are sealed.* Nothing leaves the cathedral while it stands.')
        return player
      }
      const e = player.battleState.enemy
      if (!e) {
        // battleState exists but has no `enemy` (e.g. a PvP duel, or a
        // corrupted/stale state) — flee doesn't apply here. Tell the
        // player how to actually get unstuck instead of crashing.
        await ctx.reply(
          player.battleState.type === 'pvp'
            ? `⚔️ *You're in a PvP duel — flee doesn't work here.* _Keep fighting, or use *${p}cb* to forfeit and clear your battle state._`
            : `⚠️ *No enemy found in your battle state.* _Use *${p}cb* to clear it and try again._`,
        )
        return player
      }
      const catTurn = await checkCatFormOngoingTurn(player, ctx, {
        boss: !!e.isBoss,
      })
      if (catTurn.intercepted) return catTurn.returnValue
      if (e.isBoss) {
        await ctx.reply(`⚠️ *You cannot flee from a boss!* _Defeat it or fall trying._`)
        return player
      }

      const chance = 0.35 + (player.stats.lck ?? 0) * 0.003
      if (Math.random() < chance) {
        // Successful flee — cleanupBossFight is a no-op for non-boss fights,
        // but ensures bossState is always explicitly cleared before nulling battleState.
        // The beastkin rescue event is gone; a rescue-typed fight left over from
        // it flees like any other fight (the generic cleanup below handles it).
        // The Dreamlands' guardian wall: read the bookkeeping before it is
        // nulled, so the way back can be named.
        const dreamBs = player.battleState?.type === 'dreamlands_rescue' ? player.battleState.rescue : null
        const fromTower = player.battleState?.locationId === 'season_02_tower'
        addSeason02TowerAction(player, 'retreat', { db: ctx.db })
        if (fromTower) addSeason02TowerAction(player, 'safe_flee', { db: ctx.db, context: { floor: player.battleState?.floor ?? player.dungeonFloor } })
        clearHypnosis(player)
        clearSnapshot(player)
        cleanupBossFight(player)
        clearDungeonToolEffects(player)
        clearBeastEffects(player)
        player.inBattle    = false
        player.battleState = null
        if (dreamBs) {
          // Running from the wall is allowed and costs nothing but the walk
          // back — the count is shared and persistent, so the next
          // .rescue <name> picks up exactly where this one stopped. The fight
          // state is already cleared above, exactly like the pen raid's flee.
          await ctx.reply(
            `🏃 *${player.name}* breaks away from *${e.name}*.\n\n` +
            `_The cold does not chase. It does not have to. The ones still standing over the body ` +
            `stay exactly where they are._\n` +
            `_Go back with_ *${p}rescue ${dreamBs.bodyName ?? '<name>'}* _when you are ready._`,
          )
          return player
        }
        await ctx.reply(
          `🏃 *${player.name}* escapes from *${e.name}*!\n\n` +
          `📍 _Still on Floor_ *${player.dungeonFloor}*.\n` +
          `_Type_ *${p}dungeon* _to try again._`,
        )
      } else {
        // A failed escape spends the enemy's turn: tick its control and DoTs
        // just like an attack/defend turn, so a summon's stun cannot last forever.
        const enemyStatus = processStatusTurn(e, { bossState: player.battleState?.bossState })
        const statusBlock = enemyStatus.lines.length ? enemyStatus.lines.join('\n') + '\n' : ''
        if (e.hp <= 0) {
          if (statusBlock) await ctx.reply(statusBlock.trim())
          return handleVictory(player, e, ctx)
        }
        if (graceHoldsEnemyTurn(player)) {
          // 👑 King Yato — Grace of the Crown: turns 1-5 the enemy does not act
          // at all, so a failed escape costs nothing but the turn.
          await ctx.reply(
            statusBlock + `❌ *Escape failed!*\n${graceEnemyHeldLine(e, player)}\n\n` +
            `❤️ ${hpBar(player.hp, player.maxHp)}\n\n` +
            `*${p}attack* · *${p}skill <name>* · *${p}defend* · *${p}flee*`,
          )
        } else if (enemyStatus.incapacitated) {
          await ctx.reply(
            statusBlock + `❌ *Escape failed!*\n💫 *${e.name}* is unable to act this turn!\n\n` +
            `❤️ ${hpBar(player.hp, player.maxHp)}\n\n` +
            `*${p}attack* · *${p}skill <name>* · *${p}defend* · *${p}flee*`,
          )
        } else if (hasEffect(e, 'blind') && Math.random() < 0.30) {
          await ctx.reply(
            statusBlock + `❌ *Escape failed!*\n💨 *${e.name}* swings blindly and misses!\n\n` +
            `❤️ ${hpBar(player.hp, player.maxHp)}\n\n` +
            `*${p}attack* · *${p}skill <name>* · *${p}defend* · *${p}flee*`,
          )
        } else {
          let dmg = calcMonsterDamage(e.atk, getEffectiveStat(player, 'def'), false)
          const beast = beastIntervention(player, BEAST_EVENT.ENEMY_DEAL_DAMAGE, {
            enemy: e, bs: player.battleState, damage: dmg,
          })
          if (beast.modified && beast.damage !== undefined) dmg = beast.damage
          const beastBlock = beast.lines?.length ? '\n' + beast.lines.join('\n') : ''
          // Being caught is a DIRECT hit, which is precisely the kind of blow
          // Scarlett turns and the Maiden answers, so the shared hook runs here
          // too. Flee was the one turn shape with no Heroes call at all, and the
          // report wrote itself: "her skill does nothing, I tried it while
          // running". The turn is spent either way — this only decides who pays
          // for it — which is why there is no boundary call in this plugin.
          const witchHit = heroesAnswerHit({ beastHandled: true, player, enemy: e, ctx, msg: '', damage: dmg, directAttack: true })
          if (witchHit.returnValue !== undefined) return witchHit.returnValue
          const witchBlock = witchHit.lines.length ? '\n' + witchHit.lines.join('\n') : ''
          const applied = applyIncomingDamage(player, witchHit.damage)

          if (applied.catFormDefeated) {
            return resolveCatFormDefeat(player, ctx)
          }
          if (player.hp <= 0) {
            // Dying on a failed flee — resolvePlayerHpZero() covers pearl,
            // totem, and Yoriichi's cat form before falling to real death.
            const res = await resolvePlayerHpZero(player, ctx, `${applied.message ?? ''}${witchBlock}`, {})
            if (!res.fallThrough) return res.returnValue
            // A totem fired — flee still failed this turn but the player
            // is alive again; fall through to the normal failed-flee reply
            // below, carrying the totem's line forward via sustain.message.
            applied.message = res.msg
          }
          if (e.hp <= 0) {
            if (statusBlock || beastBlock) await ctx.reply((statusBlock + beastBlock).trim())
            return handleVictory(player, e, ctx)
          }

          await ctx.reply(
            statusBlock + (applied.message ?? '') +
            `❌ *Escape failed!*\n${e.emoji ?? '👾'} *${e.name}* catches you!` +
            // A turned blow has no number left to report, and "🩸 *0* damage!"
            // under MY DESIRE reads like two messages arguing about the same swing.
            (witchHit.turned ? '' : `\n🩸 *${applied.damage}* damage!`) +
            beastBlock + witchBlock + '\n\n' +
            `❤️ ${hpBar(player.hp, player.maxHp)}\n\n` +
            `*${p}attack* · *${p}skill <name>* · *${p}defend* · *${p}flee*`,
          )
        }
      }
      return player
    })
  },
}
