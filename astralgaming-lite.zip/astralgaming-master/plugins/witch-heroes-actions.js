/**
 * witch-heroes-actions.js — the combat commands for the three Heroes:
 * `.ss` (read-only board), `.endworld` (Ronova) and `.sword <technique>` (Sword
 * Maiden).
 *
 * Both actions have TWO drivers, and that split is the whole design:
 *
 *   • A dungeon, hunt or boss fight is a REAL TURN, resolved here against
 *     `bs.enemy`: the technique lands, the enemy answers it, the HP bar renders,
 *     the boss clock advances, Ronova's countdown ticks, and a kill settles
 *     through `handleVictory()` exactly once. It is shaped like
 *     plugins/cinderverdict.js (the house pattern for a signature combat command)
 *     rather than like `.attack` because an Absolute cut has no accuracy roll, no
 *     DEF and no mitigation to run — the stock pipeline would only water it down.
 *     A refused technique (no charge, no MP, already armed, not her) is NOT a
 *     turn: nothing is spent and the enemy does not get a free swing.
 *   • A duel hands the turn to plugins/pvp.js (pvpSword / pvpEndworld). It has to:
 *     two players are two records, and the second one needs its own
 *     updatePlayer() (see runPvpTurn's header for the deadlock a nested call
 *     causes). Going through the duel's turn engine is also what makes a sword
 *     technique appear in the same battle message as every other move with both
 *     HP bars under it, and get refused in a wager duel, where no character power
 *     is allowed at all.
 *
 * `.ss` never touches state in either mode: lib/witch-heroes.js keeps every
 * status function pure for exactly that reason.
 */
import { config } from '../config.js'
import { updatePlayer, getPlayer } from '../lib/player-repo.js'
import {
  calcMonsterDamage,
  calcMonsterHitChance,
  hpBar,
} from '../lib/combat-engine.js'
import {
  handleVictory,
  processStatusTurn,
  resolvePlayerHpZero,
  resolveCatFormDefeat,
} from '../lib/combat-handlers.js'
import { getEffectiveStat } from '../lib/effects.js'
import {
  applyBossSpecial, checkBossPhase, buildEnemyAttack, getBossTaunt,
  incrementBossTurn, cleanupBossFight, EVENT,
} from '../lib/boss-engine.js'
import { applyIncomingDamage, tickPermanentSever } from '../lib/character-abilities.js'
import { sendBattleTurnReply } from '../lib/battle-frame-render.mjs'
import {
  activateEndworld,
  useSword,
  swordStatus,
  heroesBoard,
  absoluteSlash,
} from '../lib/witch-heroes.js'
import { heroesAnswerHit, heroesTurnBoundary } from '../lib/witch-heroes-pve.js'
import { showCoordinate } from '../lib/witch-heroes-cinematic.js'
import { pvpSword, pvpEndworld, pvpGarden } from './pvp.js'
import { playLeagueMove } from './league-battle.js'
import { battleGarden, findPartyForPlayer } from './party.js'
import { canCallGarden, callGarden } from '../lib/garden.js'
import { graceHoldsEnemyTurn, graceEnemyHeldLine } from '../lib/king-yato.js'

const p = config.prefix

function targetFor(db, player) {
  return player?.battleState?.enemy ?? getPlayer(db, player?.battleState?.opponentJid) ?? null
}
function inDuel(player) {
  return player?.battleState?.type === 'pvp'
}
function isBossFight(player) {
  return !!(player.battleState?.enemy?.isBoss && player.battleState?.bossState)
}

export default {
  name: 'endworld',
  aliases: ['end-world', 'ss', 'swordstatus', 'sword-status', 'sword', 'absolute-sword', 'garden'],
  category: 'combat',
  requiresPlayer: true,
  description: 'Combat actions: .ss (board) · .endworld · .sword <technique> · .garden (Alpha after two turns)',

  async run(ctx) {
    const cmd = ctx.cmd
    if (cmd === 'ss' || cmd === 'swordstatus' || cmd === 'sword-status') {
      // Read-only, and equipped-character aware: a Scarlett holder asking for the
      // board gets her mirror, not a sword panel she cannot use.
      return ctx.reply(heroesBoard(ctx.player))
    }

    // ── Astral League fixture ─────────────────────────────────────────
    // A fixture plays these three through the League path: the same
    // runPvpTurn() actions as the duel handoff below, plus the turn limit, the
    // stand in answer and the table. BEFORE the duel handoff and before
    // updatePlayer(): playLeagueMove() sends and writes, and neither is safe
    // inside a mutator (see the note in plugins/pvp.js). `.sword` with no
    // technique stays a question in a fixture too, so it falls through.
    const swordMove = ctx.args?.[0]?.toLowerCase() ?? null
    if (cmd === 'endworld' || cmd === 'end-world') {
      if (await playLeagueMove(ctx, 'endworld', '')) return
    } else if (cmd === 'garden') {
      if (await playLeagueMove(ctx, 'garden', '')) return
    } else if (swordMove) {
      if (await playLeagueMove(ctx, 'sword', swordMove)) return
    }

    // ── A duel drives both of these through the PvP turn engine ──────────
    // Checked before anything else, because in there these two commands are a
    // turn: they flip ownership, they settle on the opponent's own record, and
    // they land in the battle frame. Re-implementing any of that down here is how
    // a sword that works in a dungeon stops working in a duel.
    if (inDuel(ctx.player)) {
      if (cmd === 'endworld' || cmd === 'end-world') return pvpEndworld(ctx)
      if (cmd === 'garden') return pvpGarden(ctx)
      const move = ctx.args?.[0]?.toLowerCase()
      // `.sword` with no technique in a duel is a question, not a wasted turn.
      if (!move) return ctx.reply(swordStatus(ctx.player))
      return pvpSword(ctx, move)
    }

    // ── Everything below is PvE: a dungeon, a hunt, a boss floor ──────────
    if (cmd === 'endworld' || cmd === 'end-world') return pveTurn(ctx, { kind: 'endworld' })
    if (cmd === 'garden') {
      if (ctx.player?.inBattle && !ctx.player.battleState && findPartyForPlayer(ctx.db, ctx.from)?.battle) return battleGarden(ctx)
      return pveTurn(ctx, { kind: 'garden' })
    }
    return pveTurn(ctx, { kind: 'sword', move: ctx.args?.[0]?.toLowerCase() ?? null })
  },
}

/**
 * pveTurn(ctx, { kind, move }) — one Heroes action as a full player turn.
 *
 * The whole point is that this function looks like the other combat plugins:
 * status ticks, the action, the enemy's answer, the bar, the turn clock, one
 * settle path. A Heroes command that only replied with a line of text was the
 * original complaint, so the reply is the last thing it does, through the same
 * battle frame every other turn uses.
 */
async function pveTurn(ctx, { kind, move }) {
  let scene = null

  await updatePlayer(ctx.db, ctx.from, async player => {
    const bs = player.battleState
    const e = bs?.enemy
    if (!bs || !e) {
      await ctx.reply(`🗡️❌ _No fight to spend this on._\n⚔️ These commands are battle actions: \`${p}attack\` starts one.`)
      return player
    }
    const boss = isBossFight(player)
    let msg = ''

    // ── The action, with its own gate ──────────────────────────────────────
    // The gate runs inside this mutator so a refusal (no charge, no MP, already
    // armed, wrong character) costs nothing at all: no MP, no charge, no turn,
    // and no counter from the enemy for the trouble of asking.
    let strikes = []
    let gate
    if (kind === 'endworld') {
      gate = activateEndworld(player)
    } else if (kind === 'garden') {
      gate = canCallGarden(player, bs)
    } else {
      gate = useSword(player, e, move)
    }
    if (!gate?.ok) {
      await ctx.reply(gate?.message
        ?? `🗡️❌ Choose a sword technique: \`${p}sword sever\`, \`wrongfoot\`, \`return\`, \`transcended\`, \`coordinate\`.\n📜 \`${p}ss\` shows the live board.`)
      return player
    }
    if (boss) {
      // The boss clock advances on this turn too: specials, cooldowns and the
      // phase engine read it, and a command that skipped it would leave a boss
      // frozen for as long as someone kept cutting instead of swinging.
      incrementBossTurn(player)
      const tsResult = applyBossSpecial(player, EVENT.TURN_START, {})
      if (tsResult.narrativeLine) msg += `_${tsResult.narrativeLine}_\n`
    }
    if (gate.message) msg += gate.message + '\n'
    if (kind === 'sword' && gate.cinematic === 'coordinate') {
      // Three strikes, resolved one at a time against the real body, and never
      // past a target that is already down: an invented fourth death would be a
      // fourth reward, and the finisher is the point, not the arithmetic.
      for (let i = 0; i < (gate.strikes ?? 3); i++) {
        if (e.hp <= 0) break
        strikes.push({ damage: absoluteSlash(player, e, 1), revived: false })
      }
    }

    // ── Her own turn costs her the usual upkeep ────────────────────────────
    const permaSeverLine = tickPermanentSever(player)
    if (permaSeverLine) msg += permaSeverLine + '\n'
    if (player.hp <= 0) {
      const res = await resolvePlayerHpZero(player, ctx, msg, { boss })
      if (!res.fallThrough) return res.returnValue
      msg = res.msg
    }
    const playerStatus = processStatusTurn(player)
    if (playerStatus.incapacitated && player.battleState?.enemy?.tower) player.battleState.towerTacticIncapacitatedTurn = player.battleState.turn ?? 1
    if (!playerStatus.incapacitated && player.hp > 0 && player.battleState?.bossState?._def?.orv) applyBossSpecial(player, EVENT.PLAYER_ABILITY, {})
    if (playerStatus.lines.length) msg += playerStatus.lines.join('\n') + '\n'
    if (player.hp <= 0) {
      const res = await resolvePlayerHpZero(player, ctx, msg, { boss })
      if (!res.fallThrough) return res.returnValue
      msg = res.msg
    }

    if (kind === 'garden') {
      if (playerStatus.incapacitated) {
        msg += `💫 *${player.name}* cannot call the Garden this turn.\n`
      } else {
        const call = callGarden(player, e, bs)
        msg += call.message + '\n'
      }
    }

    // The technique itself may be what ends the fight (Sever, Wrong Foot, the
    // Coordinate, a released blade). Settle it here, before the enemy gets an
    // answer out of a corpse.
    if (e.hp <= 0) {
      if (boss) cleanupBossFight(player)
      scene = { kill: true }
      if (kind === 'garden') await ctx.reply(msg.trim())
      return handleVictory(player, e, ctx)
    }
    if (boss) {
      const phase = checkBossPhase(player)
      if (phase?.triggered && phase.lines?.length) {
        msg += `\n⚡ *— PHASE SHIFT —*\n` + phase.lines.map(l => `_${l}_`).join('\n') + '\n'
      }
    }

    // ── The enemy answers ──────────────────────────────────────────────────
    const enemyStatus = processStatusTurn(e, { bossState: player.battleState?.bossState })
    if (enemyStatus.lines.length) msg += enemyStatus.lines.join('\n') + '\n'
    if (e.hp <= 0) {
      if (boss) cleanupBossFight(player)
      scene = { kill: true }
      return handleVictory(player, e, ctx)
    }

    const hpBefore = player.hp
    // 👑 King Yato — Grace of the Crown: turns 1-5 the enemy does not act at all.
    if (graceHoldsEnemyTurn(player)) {
      msg += `\n${graceEnemyHeldLine(e, player)}\n`
    } else if (enemyStatus.incapacitated) {
      msg += `💫 *${e.name}* is unable to attack this turn!\n`
    } else if (boss) {
      const bossAtk = buildEnemyAttack(player)
      const dealResult = applyBossSpecial(player, EVENT.ENEMY_DEAL_DAMAGE, { damage: bossAtk.damage, isHit: true })
      const raw = dealResult.modified && dealResult.damage !== undefined ? dealResult.damage : bossAtk.damage
      const incoming = bossAtk.bypassDefense ? raw : calcMonsterDamage(raw, getEffectiveStat(player, 'def'), false)
      const witchHit = heroesAnswerHit({ player, enemy: e, ctx, msg: '', damage: incoming, directAttack: true, boss })
      if (witchHit.returnValue !== undefined) return witchHit.returnValue
      if (witchHit.lines.length) msg += witchHit.lines.map(l => l + '\n').join('')
      const applied = applyIncomingDamage(player, witchHit.damage)
      if (applied.message) msg += applied.message + '\n'
      if (!witchHit.turned) msg += `\n${e.emoji ?? '👾'} *${e.name}* uses *${bossAtk.attackName}*!\n🩸 *${applied.damage}* damage!${bossAtk.bypassDefense ? ' _(bypasses DEF)_' : ''}\n`
      if (dealResult.narrativeLine) msg += `_${dealResult.narrativeLine}_\n`
      msg += `\n💬 _"${getBossTaunt(player)}"_\n`
      if (applied.catFormDefeated) return resolveCatFormDefeat(player, ctx, { boss: true })
    } else if (Math.random() > calcMonsterHitChance(e, player)) {
      msg += `\n${e.emoji ?? '👾'} *${e.name}* retaliates... and *MISSES!*`
    } else {
      const enemyDmg = calcMonsterDamage(e.atk, getEffectiveStat(player, 'def'), false)
      const witchHit = heroesAnswerHit({ player, enemy: e, ctx, msg: '', damage: enemyDmg, directAttack: true, boss })
      if (witchHit.returnValue !== undefined) return witchHit.returnValue
      if (witchHit.lines.length) msg += witchHit.lines.map(l => l + '\n').join('')
      const applied = applyIncomingDamage(player, witchHit.damage)
      if (applied.message) msg += applied.message + '\n'
      if (!witchHit.turned) msg += `\n${e.emoji ?? '👾'} *${e.name}* retaliates!\n🩸 *${applied.damage}* damage!`
      if (applied.catFormDefeated) return resolveCatFormDefeat(player, ctx)
    }
    if (player.hp <= 0) {
      const res = await resolvePlayerHpZero(player, ctx, msg, { boss })
      if (!res.fallThrough) return res.returnValue
      msg = res.msg
    }
    if (e.hp <= 0) {
      if (boss) cleanupBossFight(player)
      scene = { kill: true }
      await ctx.reply(msg.trim())
      return handleVictory(player, e, ctx)
    }
    if (boss) {
      const teResult = applyBossSpecial(player, EVENT.TURN_END, {})
      if (teResult.narrativeLine) msg += `\n_${teResult.narrativeLine}_`
    }

    // ── The bar, the clock, the settle ─────────────────────────────────────
    if (!boss) {
      msg += `\n\n👤 *${player.name}*\n❤️ ${hpBar(player.hp, player.maxHp)}  💧 ${player.mp}/${player.maxMp} MP\n` +
             `${e.emoji ?? '👾'} *${e.name}*\n❤️ ${hpBar(e.hp, e.maxHp)}\n\n` +
             `*${p}attack* · *${p}skill <name>* · *${p}defend* · *${p}flee*`
    }

    const witchTurn = await heroesTurnBoundary({
      player, enemy: e, ctx, msg, turnId: bs.turn ?? 1, boss,
      // A technique spends the charge it is asking for more of, so the completed
      // turn must not refill it. `.endworld` is not a sword move and charges
      // normally, exactly like `.attack` does.
      chargeSword: kind !== 'sword',
    })
    if (witchTurn.returnValue !== undefined) return await witchTurn.returnValue
    msg = witchTurn.msg

    bs.turn = (bs.turn ?? 1) + 1
    player.battleState = bs
    scene = {
      msg, bs, player, e, boss, hpBefore,
      cinematic: kind === 'sword' && gate.cinematic === 'coordinate' && strikes.length
        ? { type: 'coordinate', strikes, finalText: msg, participants: [player, e] }
        : witchTurn.terminal
          ? { type: 'endworld-clash', finalText: msg, participants: [player, e] }
          : null,
    }
    return player
  })

  if (scene?.kill || !scene?.msg) return
  if (scene.boss) {
    const { sendCinematicBossTurn } = await import('../lib/boss-cinematic.js')
    return sendCinematicBossTurn(ctx, { player: scene.player, e: scene.e, body: scene.msg })
  }
  return sendBattleTurnReply(ctx, {
    bs: scene.bs, player: scene.player, e: scene.e, msg: scene.msg,
    hpBeforeTurn: scene.hpBefore, boss: scene.boss, cinematic: scene.cinematic,
  })
}
