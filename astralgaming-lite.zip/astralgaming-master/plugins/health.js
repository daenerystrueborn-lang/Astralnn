/**
 * health.js — owner-only readout of the two things that make the bot look
 * frozen while it is still "online".
 *
 * Written for a specific bug report: "the bot is online, we're all sending
 * messages and it won't answer, but the hourly card and the Pokémon spawns
 * still arrive normally." Both halves of that are possible at once, and there
 * are two very different causes:
 *
 *   1. OUTBOUND. Commands are received and run fine, but the replies are
 *      sitting in lib/send-rate-limiter.js's queue behind a hard sends-per-
 *      minute cap. Spawn sweeps only send once an hour, so their single
 *      message still gets out looking normal. Tell-tale: `pending` is high
 *      and `oldest` is tens of seconds or minutes.
 *
 *   2. INBOUND. The socket is open and can send, but WhatsApp messages have
 *      stopped arriving at all (usually Baileys failing to decrypt them —
 *      those errors are filtered out of the logs by main.js's SPAM_PATTERNS).
 *      Tell-tale: `last inbound` keeps climbing while people are actively
 *      messaging the bot. Genuine socket closes still use the normal reconnect
 *      path; this readout helps distinguish delivery trouble from a work queue.
 *
 * Everything here is read from live counters — no network calls, no database
 * reads — so it answers even when the bot is busy or backed up.
 */
import { getHealthSnapshot } from '../lib/bot-health.js'
import { queueStats } from '../lib/player-repo.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import { ffmpegStatus } from '../lib/ffmpeg-bin.js'
import { saveLatencyReport } from '../lib/save-stats.js'
import { getDbSyncState, describeDbTarget, isMongoOnly, isRemoteDb } from '../lib/db-adapter.js'
import { stateStoreSnapshot } from '../lib/state-store.js'
import { config } from '../config.js'

function ago(ts) {
  if (!ts) return 'never'
  const sec = Math.round((Date.now() - ts) / 1000)
  if (sec < 60) return `${sec}s ago`
  const min = Math.floor(sec / 60)
  if (min < 60) return `${min}m ${sec % 60}s ago`
  const hr = Math.floor(min / 60)
  return `${hr}h ${min % 60}m ago`
}

export default {
  name:           'health',
  aliases:        ['diag', 'queues'],
  category:       'admin',
  platforms:      ['whatsapp'],
  requiresPlayer: false,
  description:    'Owner-only: inbound/outbound queue diagnostics for "bot is online but not answering"',

  async run(ctx) {
    if (!ctx.from || !isOwnerJid(ctx.from)) {
      return ctx.reply(`❌ This command is restricted to the bot owner.`)
    }

    const snap = getHealthSnapshot()
    if (!snap) {
      return ctx.reply('⚠️ No WhatsApp health data — main.js has not registered its instances yet.')
    }

    const lines = [`🩺 *Bot Health*`, `⏱️ Uptime: *${Math.floor(snap.uptimeSec / 60)}m*`, '']

    for (const inst of snap.instances) {
      lines.push(`*${inst.botName}* — ${inst.online ? '🟢 online' : '🔴 offline'}`)
      lines.push(`  connected: ${ago(inst.openedAt)}`)
      lines.push(`  last inbound msg: ${ago(inst.lastInboundAt)} (${inst.inboundCount} this session)`)
      // Delivery ≠ readability: an undecryptable message still arrives as a
      // CIPHERTEXT stub whose `.message` is empty, and those stubs used to
      // keep "last inbound" looking healthy while every real command was
      // being dropped. This is the pair that tells those apart.
      lines.push(`  last DECRYPTED msg: ${ago(inst.lastDecryptOkAt)}`)
      if (inst.stubCount) {
        lines.push(`  ⚠️ ${inst.stubCount} undecryptable msg(s) this session (last ${ago(inst.lastStubAt)}) — those senders got no reply`)
      }
      const dec = inst.decrypt
      if (dec && dec.total) {
        lines.push(`  🔓 ${dec.total} decrypt failure(s) in the last ${Math.round(dec.windowMs / 1000)}s across ${dec.distinctSenders} sender(s)`)
        if (dec.topSenders) lines.push(`     senders: ${dec.topSenders}`)
        for (const s of dec.sample ?? []) {
          lines.push(`     · ${s.sender}${s.device ? `:${s.device}` : ''} — ${s.reason} (${Math.round(s.agoMs / 1000)}s ago)`)
        }
      }
      // Baileys' own receive side (lib/inbound-guard.js): raw WhatsApp
      // stanzas in vs. messages actually handed to the bot. "In" climbing while
      // "delivered" stands still is the "ignores commands, spawns still post"
      // outage; the watchdog reconnects on it by itself.
      const rx = inst.receive
      if (rx) {
        lines.push(`  receive pipeline: ${rx.summary}`)
        if (rx.pulse?.waiting) {
          lines.push(`  ⚠️ ${rx.pulse.waiting} message(s) waiting ${Math.round(rx.pulse.waitingMs / 1000)}s for whatsmeow — ` +
            `auto-reconnect at ${Math.round(rx.pulse.stallMs / 1000)}s`)
        }
        if (rx.guard?.runningForMs > 10_000) {
          lines.push(`  ⏱️ current receive task running ${Math.round(rx.guard.runningForMs / 1000)}s — skipped at ${Math.round(rx.guard.timeoutMs / 1000)}s`)
        }
      }
      if (inst.sessionResets) {
        lines.push(`  🩹 ${inst.sessionResets} broken Signal session(s) reset this run (last ${ago(inst.lastSessionResetAt)}) — those senders re-key on their next message`)
      }
      if (inst.sessionConflictAt && Date.now() - inst.sessionConflictAt < 30 * 60_000) {
        lines.push(`  🚩 statusCode 440 (session conflict) ${ago(inst.sessionConflictAt)} — this number is logged in somewhere else; that alone causes Bad-MAC decryption failures`)
      }
      if (inst.lastForcedReconnectAt) {
        lines.push(`  watchdog reconnect: ${ago(inst.lastForcedReconnectAt)}`)
      }
      if (inst.reconnectPending) lines.push(`  reconnect pending ⏳`)
      if (inst.transientCloseStreak) {
        lines.push(`  ⚠️ ${inst.transientCloseStreak} transient close(s) in a row — the link is flapping or the loop is too busy to answer the keepalive`)
      }

      const inbound = inst.inbound
      if (inbound) {
        lines.push(`  inbound work: *${inbound.active}* active, ${inbound.pending} waiting, ${inbound.lanes} sender lanes`)
        lines.push(`  inbound handled ${inbound.stats.completed} · dropped ${inbound.stats.dropped} · failed ${inbound.stats.failed}`)
      }

      const s = inst.send
      if (s) {
        lines.push(`  send queue: *${s.pending}* waiting` +
          (s.pending ? ` (${s.pendingReplies ?? 0} replies, ${s.pendingBulk ?? 0} bulk, oldest ${Math.round(s.oldestPendingMs / 1000)}s)` : '') +
          (s.pendingReactions ? ` (+${s.pendingReactions} reactions)` : ''))
        if (s.trend) {
          const t = s.trend
          const trendLabel = t.growing
            ? `⚠️ *GROWING* (${t.rateFormatted}${t.durationMs ? `, for ${Math.round(t.durationMs / 1000)}s` : ''})`
            : t.ratePerMinute < -0.5
            ? `🟢 draining (${t.rateFormatted})`
            : `🟢 stable (${t.rateFormatted})`
          lines.push(`  send trend: ${trendLabel}`)
        }
        const eff = s.effectiveLimits
        lines.push(`  rate: ${s.sentLastMinute}/${s.limits.maxPerMinute} per min, ` +
          `min gap ${s.limits.minGapMs}ms` +
          (eff && (eff.minGapMs !== s.limits.minGapMs || eff.maxPerMinute !== s.limits.maxPerMinute)
            ? ` (throttled to ${eff.minGapMs}ms / ${eff.maxPerMinute} per min${s.throttledForMs ? `, extra pause ${Math.round(s.throttledForMs / 1000)}s` : ''})`
            : '') +
          `, burst ${s.burstReady ? 'ready' : 'spent'} of ${s.limits.burstMax ?? 0}`)
        const c = s.counters
        lines.push(`  sent ${c.sent} · failed ${c.failed} · timeouts ${c.timeouts}`)
        lines.push(`  dropped: ${c.dropStale} stale, ${c.dropOverflow} overflow, ${c.dropReact} reactions`)
        if (!s.draining && s.pending) lines.push(`  ⚠️ queue not draining!`)
      } else {
        lines.push(`  send queue: (socket down)`)
      }
      lines.push('')
    }

    const q = queueStats
    lines.push(`💾 *DB write queue*`)
    lines.push(`  depth: ${q.currentQueueDepth}`)
    lines.push(`  running: ${q.lastTaskStartedAt ? `${q.lastTaskLabel} (${ago(q.lastTaskStartedAt)})` : 'idle'}`)
    lines.push(`  last task: ${q.lastTaskLabel ?? '—'} took ${q.lastTaskDurationMs ?? '—'}ms`)
    lines.push(`  slow tasks (>3s): ${q.slowTaskCount}`)

    // ── Real save latency: debounce wait + the persist round trip ─────────
    // The number "how long after a command is the world actually durable" —
    // measured per save (lib/save-stats.js), never estimated. In mongo-only
    // this is the ONLY durability line there is (no db.json), so the sync
    // state goes here too: pending pushes and how long since the last one.
    {
      const rep = saveLatencyReport()
      const dbL = rep.db
      const stL = rep.state
      const sync = getDbSyncState()
      const stores = stateStoreSnapshot()
      lines.push('')
      lines.push(`🗄️ *Storage* — ${config.dbMode === 'mongo-only' ? 'MongoDB only (no local file)' : isRemoteDb() ? 'db.json + Mongo backup' : 'local file'}`)
      lines.push(`  target: ${describeDbTarget()}`)
      const fmt = (ms) => ms == null ? '—' : `${Math.round(ms)}ms`
      const save = (label, s) => {
        const last = s.last
          ? `last: wait ${fmt(s.last.waitMs)} + save ${fmt(s.last.ioMs)} = ${fmt(s.last.totalMs)}` +
            (s.last.players ? ` (${s.last.players} player(s), ${s.last.keys} key(s))` : (s.last.keys ? ` (${s.last.keys} store(s))` : ''))
          : 'no saves yet this run'
        lines.push(`  ${label}: ${last} · p50 ${fmt(s.p50Ms)} · p95 ${fmt(s.p95Ms)} · max ${fmt(s.maxMs)} · ${s.saves} save(s)`)
      }
      save('db save', dbL)
      if (stores.mode === 'mongo') {
        save('state stores', stL)
        lines.push(`  pending store pushes: ${stores.pending}${stores.pendingIds.length ? ` (${stores.pendingIds.join(', ')})` : ''} · debounce ${stores.debounceMs}ms`)
      }
      if (sync) {
        const lag = sync.lastSyncedAt ? ago(sync.lastSyncedAt) : 'never'
        lines.push(sync.synced
          ? `  mongo: 🟢 writing · last save landed ${lag}${sync.pushPending ? ' · push in flight' : ''}`
          : `  mongo: 🔴 NOT saving (${sync.failures} failure(s))${sync.mode === 'mongo-only' ? ' — RAM is the only copy, exit loses the backlog' : ' — backup paused, file still durable'}`)
      } else if (config.dbMode === 'mongo-only') {
        lines.push('  mongo: no adapter open (this process is not the live db)')
      }
      if (isMongoOnly() && config.clusterMode) {
        lines.push('  cluster: per-player rev CAS active (multi-node writes share one database)')
      }
    }

    const lag = snap.loopLag
    lines.push('')
    lines.push(`🐌 *Event loop*`)
    if (lag) {
      lines.push(`  p99 delay: ${Math.round(lag.p99Ms)}ms (worst ${Math.round(lag.worstMs)}ms ever, in ${lag.windows} windows)`)
      lines.push(lag.starved
        ? `  🔴 BLOCKED NOW — the process cannot service the socket this fast; whatsmeow reads that as a dead link and self-kills it. Not a whatsmeow bug.`
        : lag.starvedRecently
          ? `  🟠 was blocked ${Math.round((lag.lastStarvedAgoMs ?? 0) / 1000)}s ago (threshold ${lag.starveThresholdMs}ms, ${lag.starvedWindows} starved window(s))`
          : `  🟢 responsive (starves above ${lag.starveThresholdMs}ms)`)
    } else {
      lines.push(`  (not sampling — started by main.js only in the WhatsApp process)`)
    }

    // Memory — the answer to "the bot just stops working, is it RAM?". Live
    // counters only, so this line answers even when everything else is wedged;
    // and logs/system/memory.log keeps the timeline for after a crash, which
    // is the case this readout cannot cover by definition.
    const mem = snap.memory
    const mb = (bytes) => Math.round((bytes || 0) / 1024 / 1024)
    lines.push('')
    lines.push(`🧠 *Memory*`)
    if (mem) {
      lines.push(`  heap: *${mb(mem.heapUsed)}/${mb(mem.heapLimit)}MB* (${Math.round(mem.heapUsedPct * 100)}%) · peak this run ${Math.round(mem.peakHeapPct * 100)}%`)
      lines.push(`  rss: ${mb(mem.rss)}MB` +
        (mem.containerLimit ? `/${mb(mem.containerLimit)}MB (${Math.round(mem.rssPct * 100)}% of the container)` : ' (no container limit visible)'))
      if (mem.external) {
        lines.push(`  buffers/external: ${mb(mem.external)}MB — outside the V8 heap, and what gets a container OOM-killed while the heap looks fine`)
      }
      // Say what WILL happen, not what could: the interventions are opt-in, so
      // a red line in monitor-only mode means "look at this", not "act now".
      const willAct = mem.restartEnabled ? 'flushes its writes and restarts itself on purpose' : 'logs it and carries on (MEMORY_GUARD_RESTART=1 to opt in)'
      lines.push(mem.level === 'critical'
        ? `  🔴 CRITICAL — ${mem.consecutiveCritical}/${mem.criticalTicks} strike(s); at ${mem.criticalTicks} the bot ${willAct}`
        : mem.level === 'high'
          ? `  🟠 high — ${mem.shedEnabled ? 'caches are being shed to make room' : 'above the shed line, nothing dropped (monitor only)'} (line: ${Math.round(mem.thresholds.highPct * 100)}%)`
          : `  🟢 ok (shed line ${Math.round(mem.thresholds.highPct * 100)}%, restart line ${Math.round(mem.thresholds.criticalPct * 100)}%)`)
      lines.push(`  mode: ${mem.shedEnabled || mem.restartEnabled ? `${mem.shedEnabled ? 'shed' : ''}${mem.shedEnabled && mem.restartEnabled ? '+' : ''}${mem.restartEnabled ? 'restart' : ''} enabled` : 'monitor only — measures and logs, changes nothing'}`)
      if (mem.shedCount) lines.push(`  sheds so far: ${mem.shedCount} (last ${ago(mem.lastShedAt)})`)
      lines.push(`  timeline: logs/system/memory.log (${mem.samples} sample(s) held)`)
    } else {
      lines.push(`  (guard off — set MEMORY_GUARD_ENABLED=1 to watch the heap and restart before it crashes)`)
    }

    // Conversion binary status — the other "the bot looks fine but one feature
    // is silently broken" case. A player reported a raw shell error from
    // `.sticker` (`/bin/sh: 1: ffmpeg: not found`) while every other command
    // worked; without this line the only evidence lived in one throttled log
    // entry. See lib/ffmpeg-bin.js.
    const ff = ffmpegStatus()
    lines.push('')
    lines.push(`🎞️ *Media conversion (ffmpeg)*`)
    if (ff.ok) {
      lines.push(`  🟢 ${ff.source} → ${ff.bin}`)
    } else {
      lines.push(`  🔴 not found — *stickers* (.sticker) and gif→video conversion will fail`)
      lines.push(`  fix: npm rebuild ffmpeg-static, or set FFMPEG_PATH to a system ffmpeg, then restart`)
    }

    lines.push('')
    lines.push(`_High "send queue"/"oldest" = replies are rate-limited (bot is behind)._`)
    lines.push(`_Climbing "inbound waiting" = command work is backed up; different senders still run concurrently, and the queue is bounded._`)
    lines.push(`_"last inbound msg" counts DELIVERY; "last DECRYPTED msg" is the one that matters — if the first is fresh and the second is stale, messages are arriving but whatsmeow cannot open them (those senders get no reply)._`)
    lines.push(`_"receive pipeline" = WhatsApp messages IN vs. messages DELIVERED to the bot. If "in" climbs and "delivered" doesn't, whatsmeow's receive queue is stuck — the bot skips a stuck task after 60s and reconnects by itself at 2 min._`)
    lines.push(`_A 440 line means the number is connected twice; one socket being closed there is enough to break the Signal session and produce the Bad MAC failures._`)
    lines.push(`_A red "Event loop" line means the bot is starved by its own work — reconnecting would only discard the queued commands._`)
    lines.push(`_A red "Memory" line means the heap is near its ceiling: the bot sheds caches first, then flushes and restarts itself on purpose — which beats being killed mid-write. If this readout is the thing that stops answering, read logs/system/memory.log for the timeline leading up to it._`)

    return ctx.reply(lines.join('\n'))
  },
}
