/**
 * double.js — the doubles walking Astral Town (The World That Never Ends).
 *
 *   <prefix>double                     list every double in town
 *   <prefix>double inspect <name|#>    look at one
 *   <prefix>double talk <name|#>       it answers (template lines only)
 *   <prefix>double duel <name|#>       fight it for nothing
 *   <prefix>double hunt <name|#>       fight it for a small bounty (daily limits)
 *   <prefix>double attack | defend | skill <n> | forfeit   your move in that fight
 *
 * A double is READ-ONLY: it is built from the lock snapshot and never touches
 * the locked player's wallet, items or characters. Beating it frees nobody.
 * The locked player is told when someone fights their double.
 */

import { config } from '../config.js'
import { updatePlayer, getPlayer, updateWorldState } from '../lib/player-repo.js'
import { resolveLinkedId } from '../lib/account-link.js'
import { INVERTED } from '../lib/inverted-core.js'
import { isLocked } from '../lib/inverted-usurp.js'
import { getRun } from '../lib/inverted-run.js'
import {
  listDoubles, findDouble, lastSeenLine, doubleTaunt, activeDuel, startDuel, duelScreen, forfeitDuel,
} from '../lib/inverted-doubles.js'
import { huntRefusal, countHunt } from '../lib/inverted-world.js'
import { parseMove, handleDuelMove, notifyPlayer, sendLines } from '../lib/inverted-actions.js'
import { levelTag } from '../lib/level-display.js'

const p = () => config.prefix

function linked(db, a, b) {
  try { return resolveLinkedId(db, a) === resolveLinkedId(db, b) } catch { return a === b }
}

function listText(db) {
  const list = listDoubles(db.data?.users ?? {})
  if (!list.length) return `🎭 *No doubles in Astral Town.* Everyone is wearing their own face. For now.`
  return [
    `🎭 *DOUBLES IN ASTRAL TOWN* (${list.length})`,
    list.map((d, i) => `${i + 1}. *${d.name}* · ${levelTag(d, { prefix: 'Lv ' })} · _${lastSeenLine(d.lastSeenAt)}_`).join('\n'),
    `*${p()}double inspect <name|#>* · *${p()}double talk* · *${p()}double duel* · *${p()}double hunt*`,
  ].join('\n\n')
}

function inspectText(db, d) {
  const locked = getPlayer(db, d.id)
  const snap = locked?.inverted?.usurped?.snapshot ?? {}
  const s = snap.stats ?? {}
  return [
    `🎭 *${d.name}* (a double)`,
    `_It walks like them. It laughs a beat too late._`,
    `${snap.level ? levelTag(snap, { prefix: 'Lv ' }) : 'Lv ?'} · ❤️ ${snap.maxHp ?? '?'} · 💧 ${snap.maxMp ?? '?'}`,
    `STR ${s.str ?? 0} · AGI ${s.agi ?? 0} · INT ${s.int ?? 0} · DEF ${s.def ?? 0} · LCK ${s.lck ?? 0}`,
    `Skills: ${(snap.kit ?? []).map(k => k.name).join(', ') || 'none'}`,
    `_${lastSeenLine(d.lastSeenAt)}_ · beaten ${locked?.inverted?.usurped?.double?.losses ?? 0}× · won ${locked?.inverted?.usurped?.double?.wins ?? 0}×`,
  ].join('\n')
}

async function begin(ctx, d, kind) {
  const me = ctx.player
  if (me.inBattle || me.battleState) return ctx.reply('⚔️ Finish your current fight first.')
  if (activeDuel(me)) return ctx.reply(`🎭 You are already fighting a double. *${p()}double forfeit* to walk away.`)
  if (d.id === ctx.from) return ctx.reply('🪞 You cannot reach your own double from in here.')
  const locked = getPlayer(ctx.db, d.id)
  if (!isLocked(locked)) return ctx.reply('That double is gone.')

  let bountyEligible = false
  let note = ''
  if (kind === 'hunt') {
    let refusal = null
    await updateWorldState(ctx.db, 'inverted', (data) => {
      refusal = huntRefusal(data, ctx.from, d.id)
      if (!refusal) countHunt(data, ctx.from, d.id)
    })
    if (refusal === 'fighter') return ctx.reply(`🏹 You have hunted ${INVERTED.doubles.huntPerFighterPerDay} doubles today. Tomorrow (UTC).`)
    if (refusal === 'double') return ctx.reply(`🏹 *${d.name}* has been hunted ${INVERTED.doubles.huntPerDoublePerDay} times today. Let it be.`)
    bountyEligible = !linked(ctx.db, ctx.from, d.id)
    if (!bountyEligible) note = '\n_No bounty: that double wears a face linked to your own account._'
  }

  let duel = null
  await updatePlayer(ctx.db, ctx.from, (pl) => {
    duel = startDuel(pl, locked, kind, { now: Date.now(), bountyEligible })
    return pl
  })
  ctx.player = getPlayer(ctx.db, ctx.from)
  await updatePlayer(ctx.db, d.id, (lp) => {
    // cosmetic tallies on the lock record only; never the locked player's assets
    const rec = lp?.inverted?.usurped?.double
    if (rec) { rec[kind === 'hunt' ? 'hunts' : 'duels'] = (rec[kind === 'hunt' ? 'hunts' : 'duels'] ?? 0) + 1; rec.lastSeenAt = Date.now() }
    return lp
  }).catch(() => {})
  await notifyPlayer(ctx, d.id, `🪞 _Through the glass you see *${me.name}* ${kind === 'hunt' ? 'hunting' : 'challenging'} your double in the square._`)
  return sendLines(ctx, [
    `🎭 _"${doubleTaunt(me.name, `${d.id}:${Date.now()}`)}"_`,
    kind === 'hunt'
      ? `🏹 *HUNT.* Win and it pays ☀️ *${INVERTED.doubles.huntBountySolars.toLocaleString()}*. Lose and you lose nothing.${note}`
      : `🤺 *DUEL.* Nothing at stake on either side.`,
    duelScreen(duel),
  ], 'battle')
}

export default {
  name: 'double',
  aliases: ['doubles'],
  category: 'dungeon',
  requiresPlayer: true,
  description: `${p()}double [list|inspect|talk|duel|hunt] — the doubles of the replaced walk Astral Town (The World That Never Ends).`,
  subcommands: [
    { cmd: 'list', desc: 'every double in town' },
    { cmd: 'inspect <name|#>', desc: 'look at one' },
    { cmd: 'talk <name|#>', desc: 'it answers' },
    { cmd: 'duel <name|#>', desc: 'fight it, nothing at stake' },
    { cmd: 'hunt <name|#>', desc: `fight it for a bounty (${INVERTED.doubles.huntPerFighterPerDay}/day)` },
    { cmd: 'attack | defend | skill <n> | forfeit', desc: 'your move in that fight' },
  ],

  async run(ctx) {
    const sub = String(ctx.args?.[0] ?? 'list').toLowerCase()
    const rest = ctx.args.slice(1).join(' ')
    if (isLocked(ctx.player)) return ctx.reply('🔒 You are behind the glass. You can only watch.')
    if (getRun(ctx.player)) return ctx.reply('⬜ Not from inside the white.')

    if (['attack', 'defend', 'skill', 'a', 'd', 'atk', 'def', 'sk'].includes(sub)) {
      const d = activeDuel(ctx.player)
      if (!d) return ctx.reply(`🎭 You are not fighting a double. *${p()}double* lists them.`)
      const verb = sub.startsWith('a') ? 'attack' : sub.startsWith('d') ? 'defend' : 'skill'
      const m = parseMove(d.fight.P, verb, ctx.args.slice(1))
      if (typeof m === 'object') return ctx.reply(m.error)
      return handleDuelMove(ctx, m)
    }
    if (sub === 'forfeit' || sub === 'leave') {
      let res = null
      await updatePlayer(ctx.db, ctx.from, (pl) => { res = forfeitDuel(pl); return pl })
      ctx.player = getPlayer(ctx.db, ctx.from)
      if (!res) return ctx.reply('🎭 You are not fighting a double.')
      return sendLines(ctx, res.lines)
    }
    if (sub === 'list' || sub === 'ls') return ctx.reply(listText(ctx.db))

    const d = findDouble(ctx.db.data?.users ?? {}, rest)
    if (['inspect', 'view', 'talk', 'duel', 'fight', 'hunt'].includes(sub) && !d) {
      return ctx.reply(`🎭 No double by that name. *${p()}double* lists them.`)
    }
    if (sub === 'inspect' || sub === 'view') return ctx.reply(inspectText(ctx.db, d))
    if (sub === 'talk') return ctx.reply(`🎭 *${d.name}:* _"${doubleTaunt(ctx.player.name, `${d.id}:${ctx.from}:${Math.floor(Date.now() / 60000)}`)}"_`)
    if (sub === 'duel' || sub === 'fight') return begin(ctx, d, 'duel')
    if (sub === 'hunt') return begin(ctx, d, 'hunt')
    return ctx.reply(listText(ctx.db))
  },
}
