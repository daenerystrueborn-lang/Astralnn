/**
 * skillslot.js — view and manage your 4 equipped battle skills.
 *
 * player.skills is every active/passive skill ever unlocked (grows on
 * level-up, never shrinks). player.equippedSkills is the subset usable
 * in battle via .skill, capped at MAX_SKILL_SLOTS.
 *
 * Usage:
 *   <prefix>skillslot                      — view equipped slots + page 1 of pool (ready skills first!)
 *   <prefix>skillslot 2 / page 2           — browse pool pages (global # numbering stays consistent)
 *   <prefix>skillslot ready|bending|fire.. — filter unlocked pool by usability or element
 *   <prefix>skillslot <search>             — fuzzy-search your unlocked pool
 *   <prefix>skillslot set <name or #>      — equip an owned skill into an open slot
 *   <prefix>skillslot clear <name or #>    — unequip a skill (stays in your pool)
 *   <prefix>skillslot auto                 — auto-fill slots with your strongest usable skills
 */
import { config } from '../config.js'
import { skills as allSkills, skillTierMap, skillTierOrder } from '../lib/game-data.js'
import { updatePlayer } from '../lib/player-repo.js'
import {
  MAX_SKILL_SLOTS,
  getEquippedSkills,
  ensureUniversalNeutralSkills,
  ensureAffinityBendingSkills,
  skillSlotsFullMessage,
} from '../lib/skill-slots.js'
import { affinityOfSkill, AFFINITY_BADGE } from '../lib/skill-element.js'
import { hasAffinity, MIN_AWAKEN_LEVEL, skillAffinityProfile } from '../lib/affinity-engine.js'
import {
  formatSkillElementTag,
  formatSkillCompatTag,
  formatSkillCompactBadge,
} from '../lib/skill-info.js'
import { fuzzyMatchScore } from '../lib/fuzzy.js'

const POOL_PAGE_SIZE = 15
const skillMap = Object.fromEntries(allSkills.map(s => [s.id, s]))

const FILTER_ALIASES = Object.freeze({
  ready: 'ready', usable: 'ready', active: 'ready', best: 'ready',
  dominant: 'dominant', domain: 'dominant', matched: 'dominant',
  bending: 'bending', avatar: 'bending', bend: 'bending',
  fire: 'fire', firebending: 'fire',
  water: 'water', waterbending: 'water',
  earth: 'earth', earthbending: 'earth',
  air: 'air', airbending: 'air', wind: 'air',
  neutral: 'neutral', martial: 'neutral',
  sealed: 'sealed', locked: 'sealed',
})

const ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X']
function toRoman(n) {
  return ROMAN[n - 1] ?? `#${n}`
}

function idSuffixNumber(id) {
  const m = /_(\d+)$/.exec(id ?? '')
  return m ? Number(m[1]) : 1
}

function rankSkillsByName(skillList) {
  const byName = new Map()
  for (const s of skillList) {
    if (!byName.has(s.name)) byName.set(s.name, [])
    byName.get(s.name).push(s)
  }

  const displayName = new Map()
  for (const [name, group] of byName) {
    if (group.length === 1) {
      displayName.set(group[0].id, name)
      continue
    }
    const sorted = [...group].sort((a, b) => {
      const tierDiff = skillTierOrder.indexOf(a.tier) - skillTierOrder.indexOf(b.tier)
      if (tierDiff !== 0) return tierDiff
      return idSuffixNumber(a.id) - idSuffixNumber(b.id)
    })
    sorted.reverse()
    sorted.forEach((s, i) => displayName.set(s.id, `${name} ${toRoman(i + 1)}`))
  }
  return displayName
}

function findSkillDef(query) {
  const q = (query ?? '').toLowerCase().trim().replace(/\s+/g, '_')
  if (!q) return null
  if (skillMap[q]) return skillMap[q]
  const exactOrSub = allSkills.find(s => s.name.toLowerCase().replace(/\s+/g, '_') === q)
    ?? allSkills.find(s => s.name.toLowerCase().includes(query.toLowerCase().trim()))
  if (exactOrSub) return exactOrSub

  let best = null
  let bestScore = 0
  for (const s of allSkills) {
    const sc = Math.max(fuzzyMatchScore(query, s.name), fuzzyMatchScore(query, s.id))
    if (sc >= 0.78 && sc > bestScore) {
      bestScore = sc
      best = s
    }
  }
  return best
}

function findSkillForPlayer(query, rankedNames) {
  const qNorm = (query ?? '').toLowerCase().trim().replace(/\s+/g, ' ')
  if (!qNorm) return null

  for (const [id, display] of rankedNames) {
    if (display.toLowerCase() === qNorm) return skillMap[id]
  }

  const bareMatches = [...rankedNames.entries()]
    .filter(([id]) => skillMap[id]?.name.toLowerCase() === qNorm)
  if (bareMatches.length > 1) {
    return { ambiguous: true, options: bareMatches.map(([, display]) => display) }
  }
  if (bareMatches.length === 1) return skillMap[bareMatches[0][0]]

  // Fuzzy match against player's owned ranked names before global fallback
  let bestId = null
  let bestScore = 0
  for (const [id, display] of rankedNames) {
    const s = skillMap[id]
    if (!s) continue
    const sc = Math.max(fuzzyMatchScore(query, display), fuzzyMatchScore(query, s.name))
    if (sc >= 0.76 && sc > bestScore) {
      bestScore = sc
      bestId = id
    }
  }
  if (bestId) return skillMap[bestId]

  return findSkillDef(query)
}

function findSkillByNumber(query, orderedIds) {
  const n = Number((query ?? '').trim())
  if (!Number.isInteger(n) || n < 1 || n > orderedIds.length) return null
  const id = orderedIds[n - 1]
  return id ? skillMap[id] : null
}

function tierEmoji(tierId) {
  return skillTierMap[tierId]?.emoji ?? '⚪'
}

/**
 * Usability priority bucket for pool ordering:
 *   0 = Dominant / Sub-Bending match (strongest full-power skills)
 *   1 = Usable Neutral Martial skills (100% power, zero element requirement)
 *   2 = Off-Affinity Mismatch (12% power) or Sealed (requires .affinity)
 */
function skillReadinessBucket(player, skill) {
  const prof = skillAffinityProfile(player, skill)
  if (prof.relation === 'dominant' || prof.relation === 'sub_bridge') return 0
  if (prof.relation === 'neutral') return 1
  return 2
}

function isSkillReady(player, skill) {
  return skillReadinessBucket(player, skill) <= 1
}

/**
 * Deterministic canonical pool order shared by `renderOwned()` AND
 * `findSkillByNumber()` (`.skillslot set <#>`):
 *   1. Readiness bucket (Dominant -> Usable Neutral -> Sealed/Mismatch)
 *   2. Tier impact (Mythic -> Legendary -> Epic -> Rare -> Uncommon -> Common)
 *   3. Alphabetical ranked display name
 */
function orderPoolSmart(skillList, rankedNames, player) {
  return [...skillList].sort((a, b) => {
    const bDiff = skillReadinessBucket(player, a) - skillReadinessBucket(player, b)
    if (bDiff !== 0) return bDiff
    const tA = skillTierOrder.indexOf(a.tier)
    const tB = skillTierOrder.indexOf(b.tier)
    const tierDiff = (tA === -1 ? 99 : tA) - (tB === -1 ? 99 : tB)
    if (tierDiff !== 0) return tierDiff
    return (rankedNames.get(a.id) ?? a.name).localeCompare(rankedNames.get(b.id) ?? b.name)
  })
}

function summarizeEquipped(s, rankedNames, player) {
  const name = rankedNames?.get(s.id) ?? s.name
  const tag  = s.type === 'active' ? `\`${s.mpCost} MP\`` : '`passive`'
  const elem = formatSkillCompactBadge(s)
  const compat = formatSkillCompatTag(player, s)
  return `${tierEmoji(s.tier)} *${name}* · ${tag} · ${elem}${compat ? ` · ${compat}` : ''}`
}

function formatPoolRow(num, s, rankedNames, player) {
  const name = rankedNames?.get(s.id) ?? s.name
  const prof = skillAffinityProfile(player, s)
  const statusTag = prof.relation === 'dominant'
    ? `👑 ×${prof.pveMult.toFixed(2)}`
    : prof.relation === 'sub_bridge'
      ? `⚡ ×${prof.pveMult.toFixed(2)}`
      : prof.relation === 'mismatch'
        ? `⚠️ 12%`
        : prof.relation === 'sealed'
          ? `🔒`
          : `✅`
  const bendTag = s.classId === 'bending' ? ' 🌀' : ''
  return ` \`#${String(num).padStart(2, ' ')}\` ${tierEmoji(s.tier)} *${name}*${bendTag} · \`${s.mpCost} MP\` · ${formatSkillCompactBadge(s)} ${statusTag}`
}

function parseViewArgs(args = []) {
  const parts = (args ?? []).map(a => String(a ?? '').trim()).filter(Boolean)
  if (!parts.length) return { filter: null, search: null, page: 1 }

  const first = parts[0].toLowerCase()
  if (/^\d+$/.test(first) && parts.length === 1) {
    return { filter: null, search: null, page: Math.max(1, parseInt(first, 10)) }
  }
  if (first === 'page' && parts[1] && /^\d+$/.test(parts[1])) {
    return { filter: null, search: null, page: Math.max(1, parseInt(parts[1], 10)) }
  }

  // Fuzzy-resolve filter aliases (e.g. "benidng" -> "bending", "usble" -> "ready")
  let resolvedFilter = FILTER_ALIASES[first] ?? null
  if (!resolvedFilter && parts.length <= 2) {
    let bestKey = null
    let bestSc = 0
    for (const [alias, target] of Object.entries(FILTER_ALIASES)) {
      const sc = fuzzyMatchScore(first, alias)
      if (sc >= 0.85 && sc > bestSc) {
        bestSc = sc
        bestKey = target
      }
    }
    if (bestKey && (parts.length === 1 || /^\d+$/.test(parts[1]) || parts[1]?.toLowerCase() === 'page')) {
      resolvedFilter = bestKey
    }
  }

  if (resolvedFilter) {
    let page = 1
    if (parts[1] && /^\d+$/.test(parts[1])) page = Math.max(1, parseInt(parts[1], 10))
    else if (parts[1]?.toLowerCase() === 'page' && parts[2] && /^\d+$/.test(parts[2])) page = Math.max(1, parseInt(parts[2], 10))
    return { filter: resolvedFilter, search: null, page }
  }

  // Otherwise treat as a fuzzy skill search inside the unlocked pool (optional trailing page number)
  let page = 1
  let queryParts = parts
  if (parts.length >= 2 && /^\d+$/.test(parts[parts.length - 1])) {
    page = Math.max(1, parseInt(parts[parts.length - 1], 10))
    queryParts = parts.slice(0, -1)
  }
  return { filter: null, search: queryParts.join(' '), page }
}

function applyPoolFilter(pooled, filter, search, rankedNames, player) {
  if (filter === 'ready') return pooled.filter(s => isSkillReady(player, s))
  if (filter === 'dominant') {
    return pooled.filter(s => {
      const r = skillAffinityProfile(player, s).relation
      return r === 'dominant' || r === 'sub_bridge'
    })
  }
  if (filter === 'bending') return pooled.filter(s => s.classId === 'bending')
  if (filter === 'sealed') return pooled.filter(s => !isSkillReady(player, s))
  if (['fire', 'water', 'earth', 'air', 'neutral'].includes(filter)) {
    return pooled.filter(s => affinityOfSkill(s) === filter)
  }
  if (search) {
    const qLower = search.toLowerCase()
    const scored = []
    for (const s of pooled) {
      const disp = rankedNames.get(s.id) ?? s.name
      const subHit = disp.toLowerCase().includes(qLower) || s.id.toLowerCase().includes(qLower) ? 0.95 : 0
      const sc = Math.max(
        subHit,
        fuzzyMatchScore(search, disp),
        fuzzyMatchScore(search, s.name),
        fuzzyMatchScore(search, affinityOfSkill(s)),
      )
      if (sc >= 0.74) scored.push({ s, sc })
    }
    scored.sort((a, b) => b.sc - a.sc)
    return scored.map(x => x.s)
  }
  return pooled
}

function renderOwned(player, viewOpts = { filter: null, search: null, page: 1 }) {
  const pr       = config.prefix
  ensureUniversalNeutralSkills(player)
  ensureAffinityBendingSkills(player)

  const equipped = getEquippedSkills(player)
  const owned    = (player.skills ?? []).filter(id => id !== undefined)
  const ownedSkillObjs = owned.map(id => skillMap[id]).filter(Boolean)
  const unequippedActive = owned
    .filter(id => !equipped.includes(id))
    .map(id => skillMap[id])
    .filter(s => s && s.type === 'active')

  const rankedNames = rankSkillsByName(ownedSkillObjs)
  const pooled = orderPoolSmart(unequippedActive, rankedNames, player)
  // Global #1..#N stays tied to `orderPoolSmart` so `.skillslot set <#>` ALWAYS matches!
  const numberOf = new Map(pooled.map((s, i) => [s.id, i + 1]))

  const lines = ['『 ✦ *Skill Slots* ✦ 』']
  if (!hasAffinity(player)) {
    lines.push(`✅ Usable Neutral · 🔒 Needs *${pr}affinity* _(Lv. ${MIN_AWAKEN_LEVEL}+)_`)
  } else {
    lines.push(`👑 Dominant · ⚡ Sub-Bending · ⚪ Neutral · ⚠️ Mismatch _(12%)_`)
  }
  lines.push('')

  // ── equipped ──────────────────────────────────────────────────────────
  lines.push(`✦ ── [ equipped: \`${equipped.length}/${MAX_SKILL_SLOTS}\` ] ── ✦`)
  let badSlots = 0
  for (let i = 0; i < MAX_SKILL_SLOTS; i++) {
    const s = skillMap[equipped[i]]
    if (s && !isSkillReady(player, s)) badSlots++
    lines.push(s ? `▹ ${i + 1}. ${summarizeEquipped(s, rankedNames, player)}` : `▹ ${i + 1}. ☆☆☆☆☆ _— empty slot —_`)
  }

  const readyTotal = pooled.filter(s => isSkillReady(player, s)).length
  const lockedTotal = pooled.length - readyTotal
  if ((badSlots > 0 || equipped.length < MAX_SKILL_SLOTS) && readyTotal > 0) {
    lines.push(`💡 _Tip: Run \`${pr}skillslot auto\` to fill your slots with your strongest usable skills!_`)
  }

  // ── unlocked pool (sorted, clean 1-per-line, paginated) ───────────────
  if (pooled.length) {
    const filtered = applyPoolFilter(pooled, viewOpts.filter, viewOpts.search, rankedNames, player)
    const filterTitle = viewOpts.filter
      ? ` · filter: ${viewOpts.filter}`
      : viewOpts.search
        ? ` · search: "${viewOpts.search}"`
        : ''

    lines.push(
      '',
      `✦ ── [ unlocked pool: \`${readyTotal} ready\` · \`${lockedTotal} ${hasAffinity(player) ? 'mismatch' : 'sealed'}\`${filterTitle} ] ── ✦`,
    )

    if (!filtered.length) {
      lines.push(`_No unequipped skills matched ${viewOpts.search ? `*"${viewOpts.search}"*` : `*${viewOpts.filter}*`}. Run \`${pr}skillslot\` to view all._`)
    } else {
      const totalPages = Math.max(1, Math.ceil(filtered.length / POOL_PAGE_SIZE))
      const page = Math.min(Math.max(1, viewOpts.page || 1), totalPages)
      const slice = filtered.slice((page - 1) * POOL_PAGE_SIZE, page * POOL_PAGE_SIZE)

      let lastReadyState = null
      for (const s of slice) {
        const ready = isSkillReady(player, s)
        if (ready !== lastReadyState) {
          if (lastReadyState !== null) lines.push('')
          lines.push(
            ready
              ? (hasAffinity(player) ? `👑 *Ready & Full-Power Skills:*` : `✅ *Ready to Use Now (No Element Needed):*`)
              : (hasAffinity(player) ? `⚠️ *Off-Affinity Skills (12% Power):*` : `🔒 *Sealed Elemental Skills (Unlock via ${pr}affinity):*`),
          )
          lastReadyState = ready
        }
        lines.push(formatPoolRow(numberOf.get(s.id), s, rankedNames, player))
      }

      if (totalPages > 1) {
        const navArg = viewOpts.filter ? ` ${viewOpts.filter}` : viewOpts.search ? ` ${viewOpts.search}` : ''
        const prev = page > 1 ? `◀️ \`${pr}skillslot${navArg} ${page - 1}\`` : null
        const next = page < totalPages ? `\`${pr}skillslot${navArg} ${page + 1}\` ▶️` : null
        lines.push('', `📄 _Page ${page}/${totalPages}_  ${[prev, next].filter(Boolean).join('  ·  ')}`)
      }
    }
  }

  lines.push(
    '',
    `↳ Equip: \`${pr}skillslot set <# or name>\` · Auto-best: \`${pr}skillslot auto\``,
    `↳ Unequip: \`${pr}skillslot clear <# or name>\` · Filter: \`${pr}skillslot ready|bending|fire|<name>\``,
  )
  return lines.join('\n')
}

export default {
  name: 'skillslot',
  aliases: ['skillslots', 'slots'],
  category: 'account',
  requiresPlayer: true,
  description: `${config.prefix}skillslot — view, filter & equip your 4 battle skills`,
  subcommands: [
    { cmd: 'set <# or name>', desc: 'equip an unlocked skill into an open slot' },
    { cmd: 'clear <# or name>', desc: 'unequip a skill from your slots' },
    { cmd: 'auto', desc: 'auto-equip your 4 strongest usable/dominant skills' },
    { cmd: 'ready | bending | fire | <search>', desc: 'filter or fuzzy-search your skill pool' },
  ],

  async run(ctx) {
    const { player, args, db } = ctx
    const pr  = config.prefix
    const sub = (args[0] ?? '').toLowerCase()

    // ── auto: replace sealed/mismatch/empty slots with top usable skills ─
    if (sub === 'auto' || sub === 'best' || sub === 'optimize') {
      let nextSlots = []
      await updatePlayer(db, ctx.from, (p) => {
        ensureUniversalNeutralSkills(p)
        ensureAffinityBendingSkills(p)
        const owned = (p.skills ?? []).filter(id => id !== undefined)
        const activeObjs = owned.map(id => skillMap[id]).filter(s => s && s.type === 'active')
        const ranked = rankSkillsByName(owned.map(id => skillMap[id]).filter(Boolean))
        const best = orderPoolSmart(activeObjs, ranked, p)
          .filter(s => isSkillReady(p, s))
          .slice(0, MAX_SKILL_SLOTS)
        if (best.length) {
          p.equippedSkills = best.map(s => s.id)
          nextSlots = best
        }
        return p
      })
      if (!nextSlots.length) {
        return ctx.reply(`⚠️ You don't have any ready active skills yet. Keep leveling up or check *${pr}skills*!`)
      }
      const list = nextSlots.map((s, i) => `   ${i + 1}. ${tierEmoji(s.tier)} *${s.name}* · \`${s.mpCost} MP\` · ${formatSkillCompactBadge(s)}`).join('\n')
      return ctx.reply(`⚡ *Skill Slots Optimized!*\nEquipped your *${nextSlots.length}* strongest battle-ready skills:\n${list}`)
    }

    // ── set ─────────────────────────────────────────────────────────────
    if (sub === 'set' || sub === 'equip') {
      const query = args.slice(1).join(' ')
      if (!query) return ctx.reply(`Usage: *${pr}skillslot set <skill name or #>*`)

      ensureUniversalNeutralSkills(player)
      ensureAffinityBendingSkills(player)
      const owned = (player.skills ?? []).filter(id => id !== undefined)
      const equippedNow = getEquippedSkills(player)
      const unequippedActive = owned
        .filter(id => !equippedNow.includes(id))
        .map(id => skillMap[id])
        .filter(s => s && s.type === 'active')

      const ownedSkillObjs = owned.map(id => skillMap[id]).filter(Boolean)
      const rankedNames = rankSkillsByName(ownedSkillObjs)

      const unequippedIds = orderPoolSmart(unequippedActive, rankedNames, player).map(s => s.id)

      const skill = findSkillByNumber(query, unequippedIds) ?? findSkillForPlayer(query, rankedNames)
      if (!skill) return ctx.reply(`❌ No skill found matching *"${query}"*.`)
      if (skill.ambiguous) {
        return ctx.reply(
          `❓ You have multiple versions of *"${query}"*. Specify which one:\n` +
          skill.options.map(o => `   • *${o}*`).join('\n'),
        )
      }

      let outcome = null
      await updatePlayer(db, ctx.from, (p) => {
        ensureUniversalNeutralSkills(p)
        ensureAffinityBendingSkills(p)
        const ownedIds = p.skills ?? []
        const equipped = getEquippedSkills(p)
        if (!ownedIds.includes(skill.id))  { outcome = 'not_owned'; return }
        if (skill.type !== 'active')       { outcome = 'passive'; return }
        if (equipped.includes(skill.id))   { outcome = 'already'; return }
        if (equipped.length >= MAX_SKILL_SLOTS) { outcome = 'full'; return }
        equipped.push(skill.id)
        p.equippedSkills = equipped
        outcome = 'ok'
      })

      if (outcome === 'not_owned') return ctx.reply(`❌ You haven't unlocked *${skill.name}* yet.`)
      if (outcome === 'passive')   return ctx.reply(`⚠️ *${skill.name}* is passive — it applies automatically, no slot needed.`)
      if (outcome === 'already')   return ctx.reply(`⚠️ *${skill.name}* is already equipped.`)
      if (outcome === 'full')      return ctx.reply(skillSlotsFullMessage())
      const prof = skillAffinityProfile(player, skill)
      let extraNote = ''
      if (prof.relation === 'sealed') {
        extraNote = `\n🔒 _Note: *${skill.name}* requires an *Elemental Affinity* (*${pr}affinity*, Lv. ${MIN_AWAKEN_LEVEL}+). Equip *⚪ Neutral* skills (*${pr}skillslot ready*) to cast skills before Awakening!_`
      } else if (prof.relation === 'mismatch') {
        extraNote = `\n⚠️ *Chakra Mismatch Warning:* *${skill.name}* is \`${formatSkillElementTag(skill)}\`, which clashes with your Affinity and will fizzle at *${Math.round(prof.pveMult * 100)}% power* in battle!`
      } else if (prof.relation === 'dominant' || prof.relation === 'sub_bridge') {
        extraNote = `\n👑 *Dominant Affinity Match!* *${skill.name}* scales at *×${prof.pveMult.toFixed(2)}* PvE power!`
      } else if (!hasAffinity(player)) {
        extraNote = `\n✅ *Universal Neutral Skill:* Ready to use in battle right now — no element required!`
      }
      return ctx.reply(`✅ *${skill.name}* \`${formatSkillElementTag(skill)}\` equipped! Use it in battle with *${pr}skill ${skill.name}*.${extraNote}`)
    }

    // ── clear ───────────────────────────────────────────────────────────
    if (sub === 'clear' || sub === 'unequip') {
      const query = args.slice(1).join(' ')
      if (!query) return ctx.reply(`Usage: *${pr}skillslot clear <skill name or #>*`)

      const equippedIds = getEquippedSkills(player)
      const owned = (player.skills ?? []).filter(id => id !== undefined)
      const ownedSkillObjs = owned.map(id => skillMap[id]).filter(Boolean)
      const rankedNames = rankSkillsByName(ownedSkillObjs)

      const skill = findSkillByNumber(query, equippedIds) ?? findSkillForPlayer(query, rankedNames)
      if (!skill) return ctx.reply(`❌ No skill found matching *"${query}"*.`)
      if (skill.ambiguous) {
        return ctx.reply(
          `❓ You have multiple versions of *"${query}"*. Specify which one:\n` +
          skill.options.map(o => `   • *${o}*`).join('\n'),
        )
      }

      let outcome = null
      await updatePlayer(db, ctx.from, (p) => {
        const equipped = getEquippedSkills(p)
        if (!equipped.includes(skill.id)) { outcome = 'not_equipped'; return }
        p.equippedSkills = equipped.filter(id => id !== skill.id)
        outcome = 'ok'
      })

      if (outcome === 'not_equipped') return ctx.reply(`❌ *${skill.name}* isn't equipped.`)
      return ctx.reply(`✅ *${skill.name}* unequipped — it stays in your unlocked skills.`)
    }

    // ── default: view / paginate / filter / fuzzy search ───────────────
    return ctx.reply(renderOwned(player, parseViewArgs(args)))
  },
}
