import { selectProfileCosmeticCommand } from './profile-cosmetics.js'
export default {
  name: 'pickbanner', aliases: ['equipbanner'], category: 'account', requiresPlayer: true,
  description: 'Select an unlocked profile banner',
  async run(ctx) { return selectProfileCosmeticCommand(ctx, 'banner') },
}
