/**
 * tokens — boss token wallet and deterministic reward exchange (R6).
 * Usage:
 *   .tokens                            — token balances
 *   .tokens exchange <boss id or name> — trade tokens for the boss's reward bundle
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import {
  formatTokenWallet, exchangeTokens, exchangeQuote, tokenBalance,
} from '../lib/boss-tokens.js'
import { recordFaucet } from '../lib/economy-ledger.js'
import { settlePlayerXp, xpLevelLine } from '../lib/player-xp.js'

export default {
  name: 'tokens',
  aliases: ['bosstoken', 'bosstokens'],
  category: 'economy',
  requiresPlayer: true,
  description: 'View boss tokens or exchange them for reward bundles',

  async run(ctx) {
    const p = config.prefix
    const sub = (ctx.args?.[0] ?? '').toLowerCase().trim()

    if (sub === 'exchange') {
      const bossQuery = (ctx.args?.slice(1) ?? []).join(' ').trim()
      if (!bossQuery) return ctx.reply(`Usage: \`${p}tokens exchange <boss id or name>\``)
      let reply
      await updatePlayer(ctx.db, ctx.from, (player) => {
        const quote = exchangeQuote(bossQuery)
        if (!quote) { reply = `❌ I couldn't find that boss. Check the id shown by *${p}tokens*.`; return player }
        const before = tokenBalance(player, quote.bossId)
        const r = exchangeTokens(player, quote.bossId)
        if (!r.ok) {
          reply = `❌ Need ${r.need ?? quote.cost} *${quote.name}* tokens (you have ${before}).`
          return player
        }
        recordFaucet(ctx.db, 'token_exchange', { solars: quote.solars, gems: quote.gems })
        reply = `🎟️ Exchanged ${r.spent} *${quote.name}* tokens:\n☀️ ${quote.solars.toLocaleString()} Solars · 💎 ${quote.gems} Gems · 📖 ${quote.xp.toLocaleString()} XP${xpLevelLine(settlePlayerXp(player))}`
        return player
      })
      return ctx.reply(reply)
    }

    let text = ''
    await updatePlayer(ctx.db, ctx.from, (player) => {
      text = formatTokenWallet(player)
      text += `\n\n_Exchange with \`${p}tokens exchange <boss id or name>\`._`
      return player
    })
    return ctx.reply(text)
  },
}
