import eventCommand from './event.js'
import { config } from '../config.js'
// 👑 The crown pair's roster view: which of the two a given player can still
// see, and the fused row that replaces both of them.
import { crownDef, crownHoldings, FUSED_ID } from '../lib/queen-king.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import {
  getActiveSeason,
  getSeasonRuntime,
  isSeasonRunActive,
  seasonStatus,
  formatDuration,
  seasons,
  getSeasonCatalog,
  getSeasonShopPages,
  findSeasonCatalogEntry,
  describeSeasonEntry,
  getSeasonReward,
  ensurePlayerSeasonState,
  deliverPendingSeasonPoints,
  takeLateSeasonNote,
  applySeasonPoints,
  addOwnedSeasonContent,
  addSeasonPokemon,
  hasOwnedSeasonContent,
  hasOwnedSeasonPokemon,
  rewardLabel,
  seasonContentMap,
  seasonTierProgress,
  seasonXpForTier,
  grantSeasonPassXp,
  consumeSeasonTierSkip,
} from '../lib/season-engine.js'
import { locationsMap, characterMap, seasonOffers as offerData, levelsData, classes, races, getTotalStats } from '../lib/game-data.js'
import { travelTollFor } from '../lib/travel-price.js'
import { TOWER_STAGING_LOCATION_ID } from '../lib/orv-tower.js'
import { placeName } from '../lib/orv-map.js'
import { applyLevelUps } from '../lib/combat-engine.js'

// Banner shown on `.season offer` — purely cosmetic, swap freely without
// touching offer logic. Now the shared top-up plans art (2026-09-21 drop):
// season offers are a top-up format, same visual family as .topup/.monds.
const SEASON_OFFER_BANNER = 'https://i.ibb.co/rG4dKqLS/top-up.jpg'
// A member who reads "no active season" and nothing else has no idea whether
// the feature is broken, unreleased, or simply between runs. Say what the run
// is and when its events land, so the answer is also the explanation.
const NO_ACTIVE_SEASON =
  '🌙 *There is no active season running right now.*\n\n' +
  '_A season is a timed event, not a permanent feature. When one opens, its\n' +
  'scheduled events unlock one per week: week 1 is the opening, then one\n' +
  'event a week for six weeks. Everything else in the bot works normally\n' +
  'in the meantime._\n\n' +
  '📢 _Season news is posted in the announcement group. Ask an officer to run\n' +
  '*{prefix}astral-ann on* here if you never see it._'
const SEASON_CHANGED = '🌙 The season ended or changed before that action completed. Nothing was spent; try again if a season is active.'
import { updatePlayer, getPlayer } from '../lib/player-repo.js'
import { noteSeasonOpen, noteSeasonShopBuy } from '../lib/scenario-metrics.js'
import { getSeason02QuestBoard } from '../lib/season-02-quest-engine.js'
import {
  seasonEventControl, currentEvent, nextEvent, eventCardText, eventScheduleText, eventTiming, eventActionText, EVENTS, seasonWeek,
  EVENT_WEEK_MS, EVENT_DAY_MS,
} from '../lib/season-events.js'
import {
  acceptSponsorshipOffer, addSeason02TowerAction, castSeasonEventVote, claimDemonKingReward,
  claimLastScenarioReward, claimOuterGodTitle, demonKingSummary,
  ensureSponsorshipRound, finalizeSeasonEventVote, getSeasonEventWindow,
  lastScenarioStatus, outerGodStatus, seasonEventHelpText,
  seasonEventVoteSummary, setDemonKingRole, settleSponsorshipContract,
} from '../lib/season-event-engine.js'
import { roundGems, fmtGems } from '../lib/format.js'
import { getSpinBanner, spinCurrency } from '../lib/spin-banners.js'
import { mondPriceFor } from '../lib/monds.js'
import { hasInventoryRoom, inventoryFullMessage } from '../lib/inventory-limits.js'
import { BEAST_MAX_OWNED } from '../lib/beast-engine.js'
import { skinById, ownsBaseCharacter } from '../lib/character-skins.js'
import { fetchPokemonById } from '../lib/pokemon-engine.js'
import { sendImage, sendImageTo } from '../lib/image.js'
import {
  findPendingForOwner, pendingFailureText, pendingKinds, PURCHASE_KINDS,
} from '../lib/pending-confirm.js'
import { renderSeasonShopPage } from '../lib/season-shop-render.mjs'
import { renderSeasonPass } from '../lib/season-pass-render.mjs'
import { orvPanel, orvField, orvBar, orvCommands } from '../lib/orv-style.js'

export default {
  name: 'season',
  // `.regressor` is the Season 2 System Window name the story docs use ("First
  // 15 minutes: .regressor shows the opening scene and a clear next action").
  // It was never wired, so the first command a player was told to type answered
  // "unknown command". It lands on the same status card as `.season`.
  aliases: ['seasons', 'seasoninfo', 'regressor', 'regressors'],
  category: 'season',
  requiresPlayer: false,
  description: 'View the active season, Battle Pass progress, and season currency',
  subcommands: [
    { cmd: 'status', desc: 'view the active season and your progress' },
    { cmd: 'hub', desc: 'season progress, events, quests, and reward shortcuts' },
    { cmd: 'shop [page]', desc: 'browse the Season Shop, one themed page at a time' },
    { cmd: 'shop buy <id>', desc: 'buy a Season Shop entry with its listed currency' },
    { cmd: 'offer', desc: 'view Season money offers — gems/solars for Naira _(DM only)_' },
    { cmd: 'offer buy <id>', desc: 'buy a Season offer — DM only' },
    { cmd: 'info <name>', desc: 'full details and artwork for any shop entry' },
    { cmd: 'pass [tier]', desc: 'view the free and premium Battle Pass tracks' },
    { cmd: 'dungeon', desc: 'brief on the season dungeon — does NOT enter it' },
    { cmd: 'event [list|name]', desc: 'the Season 2 event card, progress and actions' },
    { cmd: 'event sponsor|vote|demon|outer|last', desc: 'take part in the active event mechanics' },
    { cmd: 'help', desc: 'show the season system guide' },
  ],

  async run(ctx) {
    // The normal mountain-road return delivers immediately. Also cover owner
    // relocations/legacy saves on the first season command after a return.
    if (ctx.player?.pendingSeasonPoints && getActiveSeason(ctx.db)) {
      await updatePlayer(ctx.db, ctx.from, player => {
        deliverPendingSeasonPoints(ctx.db, player)
        return player
      })
      ctx = { ...ctx, player: getPlayer(ctx.db, ctx.from) }
    }
    // A season that ended while this player was in the Sect Empire is paid when
    // their record rolls over (lib/season-engine.js settleUnpaidSeasonPoints).
    // If that happened anywhere but the mountain road itself, say so here, once.
    if (ctx.player?.lateSeasonSettlement) {
      let note = null
      await updatePlayer(ctx.db, ctx.from, player => {
        note = takeLateSeasonNote(player)
        return player
      })
      ctx = { ...ctx, player: getPlayer(ctx.db, ctx.from) }
      if (note) await ctx.reply(note)
    }
    const action = (ctx.args[0] ?? 'status').toLowerCase()
    if (action === 'help' || action === 'how') {
      if (!activeSeasonOrReply(ctx)) return
      return sendHelp(ctx)
    }
    if (action === 'lore' || action === 'story') {
      if (!activeSeasonOrReply(ctx)) return
      return sendLore(ctx)
    }
    if (action === 'hub') return handleSeasonHub(ctx)
    if (action === 'shop') return handleShop(ctx)
    if (action === 'offer' || action === 'offers') return handleOffer(ctx)
    if (action === 'dungeon' || action === 'ruins') return handleSeasonDungeon(ctx)
    if (action === 'event' || action === 'events') return handleSeasonEvent(ctx)
    if (action === 'pass' || action === 'battlepass' || action === 'bp') return handlePass(ctx)
    if (action === 'premium' || action === 'unlock') return handlePremium(ctx)
    // `.season info` with a name is the item lookup; bare `.season info` keeps
    // its old meaning as an alias of `.season status`.
    if ((action === 'info' || action === 'item') && ctx.args.length > 1) return handleItemInfo(ctx)
    if (action !== 'status' && action !== 'info') {
      return ctx.reply(
        `Usage: *${config.prefix}season status* or *${config.prefix}season help*\n` +
        `_Looking for the season dungeon? *${config.prefix}season dungeon* briefs you on it; ` +
        `*${config.prefix}enter ${getActiveSeason(ctx.db)?.dungeon ?? 'season_01_ruins'}* actually goes in._`,
      )
    }

    const status = seasonStatus(ctx.db, ctx.player)
    if (!status.active) {
      const runtime = getSeasonRuntime(ctx.db)
      const handover = status.handover
      const lastEndedSeason = seasons.find((season) => season.id === runtime.lastEndedSeasonId)
      const lastEndedCurrency = lastEndedSeason?.currencyLabel
        ?? (runtime.lastEndedSeasonId === 'season_02' ? 'Stars' : 'Season Points')
      // During the gap the honest screen is a countdown, not "nothing here":
      // the next season is already queued and will open by itself, so telling
      // a player the owner has to start it would be wrong twice over.
      if (handover?.season) {
        const startsAt = handover.startsAt ? new Date(handover.startsAt) : null
        return ctx.reply(
          `🌙 *Between seasons*\n\n` +
          `*Season ${handover.season.number}: ${handover.season.name}* begins on its own in ` +
          `*${formatDuration(handover.startsInMs ?? 0)}*.\n` +
          (startsAt ? `🕒 Opening: *${startsAt.toISOString().replace('T', ' ').slice(0, 16)} UTC*\n` : '') +
          `\n_${lastEndedCurrency} from ${runtime.lastEndedSeasonId ?? 'the last season'} were already converted to Solars. ` +
          `Nothing you own is lost._`,
        )
      }
      return ctx.reply(
        `🌙 *No active season*\n\n` +
        `Season features are closed until the owner starts the next season.\n` +
        (runtime.lastEndedSeasonId ? `Last completed: *${runtime.lastEndedSeasonId}*` : ''),
      )
    }

    // The first open also feeds the legacy lifetime record; every `.season`
    // open feeds the separate WAT daily quest counter.
    if (ctx.player) {
      await updatePlayer(ctx.db, ctx.from, player => {
        if (!((player.quests?.lifetime?.season_open ?? 0) >= 1)) noteSeasonOpen(player, { db: ctx.db })
        else addSeason02TowerAction(player, 'season_open', { db: ctx.db })
        return player
      })
    }

    const s = status.season
    const p = status.player
    const prog = ctx.player ? seasonTierProgress(ctx.player, s) : null
    const floors = locationsMap[s.dungeon]?.floors ?? s.floorCount ?? 50
    const isSeasonTwo = s.id === 'season_02'
    const seasonCurrency = s.currencyLabel ?? (isSeasonTwo ? 'Stars' : 'Season Points')
    const seasonCurrencyEmoji = isSeasonTwo ? '⭐' : '✨'
    const spinLine = p?.minorSpins != null
      ? `🎰 Character spins: *${characterName(s, 'major')}: ${p.spins ?? 0}* · *${characterName(s, 'minor')}: ${p.minorSpins}*`
      : `🎰 Major spins: *${p?.spins ?? 0}*`
    const majorSpinType = isSeasonTwo ? 'Gem Spin (or buy for 🪙25 Monds)' : 'Gem Spin'
    const minorSpinType = isSeasonTwo ? 'Gem Spin (or buy for 🪙17 Monds)' : 'Final Battle Pass tier'

    // Season 2 wears the System window, not the Season 1 bulletin board.
    if (isSeasonTwo) {
      const tierCount = p?.tierCount ?? s.battlePass.tierCount
      const tier = p?.tier ?? 0
      const panel = orvPanel({
        emoji: '📖',
        title: `Season ${s.number} System`,
        subtitle: s.name,
        blocks: [
          [
            orvField('⏳', formatDuration(status.remainingMs), 'left'),
            orvField('📅', `${s.durationDays} days`, 'rotation'),
          ],
          [
            orvField(seasonCurrencyEmoji, p?.points ?? 0, seasonCurrency),
            orvField('🌙', `Level ${p?.seasonLevel ?? 0}`, `· floor ${p?.currentFloor ?? 1}/${floors}`),
          ],
          [
            `🎫 Tier *${tier}/${tierCount}* ${orvBar(tier, tierCount)}`,
            prog
              ? `📈 *${prog.into.toLocaleString()}/${prog.span.toLocaleString()}* Pass XP · *${prog.toNext.toLocaleString()}* to next tier`
              : `📈 Pass XP comes from Scenarios, boxes and a share of regular XP.`,
            orvField('💎', p?.premiumPass ? 'Unlocked' : `Locked · ${s.battlePass.premiumCost} Gems`, 'Premium Pass'),
          ],
          [
            `🎰 *${characterName(s, 'major')}* ${p?.spins ?? 0} spins · *${characterName(s, 'minor')}* ${p?.minorSpins ?? 0} spins`,
            `🧙 *${characterName(s, 'major')}* · ${majorSpinType}`,
            `⚔️ *${characterName(s, 'peak')}* · Season Shop`,
            `🎁 *${characterName(s, 'minor')}* · ${minorSpinType}`,
            ...secondHalfLines(s, ctx.player),
          ],
          [
            `🗺️ *${dungeonName(s)}* · +${s.dungeonBoostPercent ?? 10}% XP/Fame/Solars`,
            `🌌 *Endless Dungeon* · enter with *${config.prefix}enter endless_dungeon* · rank: *${config.prefix}srank*`,
            `🔒 _The Dreamlands and the Mirror remain sealed._`,
          ],
        ],
        footer: ['season pass', 'season dungeon', 'season help'],
      })
      return sendImage(ctx, 'season-banner.jpg', panel)
    }

    const lines = [
      `🌞 *SEASON ${s.number}: ${s.name.toUpperCase()}*`,
      `_${s.description}_`,
      `────────────────────`,
      `⏳ Time remaining: *${formatDuration(status.remainingMs)}*`,
      `📅 Rotation: *${s.durationDays} days*`,
      ``,
      `${seasonCurrencyEmoji} ${seasonCurrency}: *${p?.points ?? 0}*`,
      `🌙 Season Level: *${p?.seasonLevel ?? 0}* · Current floor: *${p?.currentFloor ?? 1}/${floors}*`,
      `🎫 Battle Pass: *Tier ${p?.tier ?? 0}/${p?.tierCount ?? s.battlePass.tierCount}* (${p?.progressPercent ?? 0}% of the pass)`,
      prog
        ? `📈 Next tier in *${prog.toNext.toLocaleString()}* Pass XP _(${prog.into.toLocaleString()}/${prog.span.toLocaleString()})_`
        : `📈 Pass XP comes from ${isSeasonTwo ? 'daily quest claims, weekly Personal Scenario clears and boxes' : 'cleared season floors and earned Season Points'}.`,
      `💎 Premium Pass: *${p?.premiumPass ? 'Unlocked' : `Locked · ${s.battlePass.premiumCost} Gems`}*`,
      spinLine,
      ``,
      `🧙 Major: *${characterName(s, 'major')}* · ${majorSpinType}`,
      `⚔️ Peak: *${characterName(s, 'peak')}* · Season Shop`,
      `🎁 Minor: *${characterName(s, 'minor')}* · ${minorSpinType}`,
      // 👑 The second half of this season. Listed here so the roster is the
      // whole season, but the pair is NOT season content in the way the three
      // above are: no spin, no gate, no battle pass — they are bought directly
      // from the Game Shop by anyone at any time. A fused player sees one line
      // for the Queen-King instead of the two parents, because after the
      // fusion there is one character, not two (lib/queen-king.js).
      ...secondHalfLines(s, ctx.player),
      `🗺️ Dungeon: *${dungeonName(s)}* · +${s.dungeonBoostPercent ?? 10}% XP/Fame/Solars · *${config.prefix}season dungeon*`,
      ``,
      `_Use ${config.prefix}season help for the full roadmap._`,
    ]
    return sendImage(ctx, 'season-banner.jpg', lines.join('\n'))
  },
}

/**
 * One name for the roster rows.
 *
 * `characters.major` is an ID, and printing it raw turned "mei" into "mei" —
 * fine for a lowercase id, wrong for "Kim Dokja". The order is: the season's
 * own `characters.display` label (what the owner wrote in the JSON), then the
 * character record if the character exists yet, then the id as a last resort.
 * Season 2's three leads are story NPCs before their playable kits exist, so
 * the display map is the only correct source for them.
 */
/**
 * The dungeon row. Seasons name their dungeon with the season's own title in
 * front ("Life of a Regressor: Grand Tower of Gates"), which is too long for a
 * one-line status card, so the season's name is trimmed off the front and the
 * rest is used. An unknown or missing location falls back to the id, which is
 * at least true.
 */
function dungeonName(season) {
  const id = season?.dungeon
  if (!id) return '—'
  const name = locationsMap[id]?.name
  if (!name) return id
  const prefix = `${season.name}: `
  return name.startsWith(prefix) ? name.slice(prefix.length) : name
}

/** "Kim Dokja, Klein Moretti and Rimuru" — for prose, not for a roster row. */
function leadNames(season) {
  const names = ['major', 'peak', 'minor'].map((slot) => characterName(season, slot)).filter((n) => n && n !== '—')
  if (names.length <= 1) return names.join('')
  return `${names.slice(0, -1).join(', ')} and ${names[names.length - 1]}`
}

function characterName(season, slot) {
  const id = season?.characters?.[slot]
  if (!id) return '—'
  return season?.characters?.display?.[slot]
    ?? characterMap[id]?.name
    ?? id
}

/**
 * The `.season status` roster rows for the second-half crowns.
 *
 * Returns one line for a fused player (Queen-King, which is what they hold) and
 * one for everyone else (the pair, with where to buy them). Never two lines for
 * someone who owns the fusion — the roster shows one character, not two.
 */
function secondHalfLines(season, player) {
  const pr = config.prefix
  const list = season?.characters?.secondHalf
  if (!list?.length) return []
  const held = crownHoldings(player)
  if (held.fused) {
    const fused = crownDef(FUSED_ID)
    return [`👑 Second half: *${fused?.name ?? 'Queen-King'}* ${'★'.repeat(fused?.stars ?? 7)} — _yours, fused from both crowns_`]
  }
  const names = list.map((id) => crownDef(id)?.name ?? id)
  // The data comment on season_01.characters._secondHalfNote, printed as the
  // fine print. Kept in data/seasons.json so the "not season-locked" promise is
  // part of the season's own record, not a string only this file knows.
  const note = season?.characters?._secondHalfNote ?? ''
  // These two are no longer SOLD — they are the Astral Pass Elite prizes now, so
  // this line points at the pass instead of a shop command that refuses.
  return [
    `👑 Second half: *${names.join('* + *')}* — _🌠 *Astral Pass Elite*: she is tier 50, he is tier 100. Not for sale: *${pr}ap*_`,
    `_Hold both and they fuse into *${crownDef(FUSED_ID)?.name ?? 'Queen-King'}*._${note ? `\n_${note}_` : ''}`,
  ]
}

// ── Season 2 events ────────────────────────────────────────────────────────
// `.season event` exposes the six optional weekly mechanics documented in
// docs/season-02-events.md. Schedule/cards live in lib/season-events.js; mutable
// state and gameplay hooks live in lib/season-event-engine.js. This is distinct
// from `.event`, the world event hub (Guardian / The End) in plugins/event.js.
// Event rewards are optional and do not replace the live Tower, map, staging,
// or basic gate-pillar rules.
function findSeasonEventByName(word) {
  const w = word.toLowerCase()
  return EVENTS.find(e => e.id === w)
    ?? EVENTS.find(e => e.name.toLowerCase() === w)
    ?? EVENTS.find(e => e.name.toLowerCase().includes(w))
    ?? null
}

function voteCountsText(summary, choices) {
  const counts = summary?.counts ?? {}
  const rows = choices.map(([id, label]) => `${label}: ${counts[id] ?? 0}`).join(' · ')
  return `${rows} · ${summary?.total ?? 0} vote${summary?.total === 1 ? '' : 's'}${summary?.result ? ` · Result: *${summary.result.choice}*` : ''}`
}

async function seasonEventProgressText(ctx, event) {
  const now = Date.now()
  if (ctx.player) await updatePlayer(ctx.db, ctx.from, player => {
    addSeason02TowerAction(player, 'event_card_read', { db: ctx.db, now })
    return player
  })
  const runtime = getSeasonRuntime(ctx.db)
  const runNumber = Number(runtime.runNumber) || 0
  const p = config.prefix
  if (event.id === 'first_broadcast') {
    return `📡 Your audience: *${Number(ctx.player?.scenarioViewers?.count) || 0}* Viewers · peak: *${Number(ctx.player?.scenarioViewers?.peak) || 0}*.`
  }
  if (event.id === 'sponsorship') {
    await ensureSponsorshipRound(ctx.db, now)
    if (ctx.player) await updatePlayer(ctx.db, ctx.from, player => {
      settleSponsorshipContract(player, { runNumber, now })
      return player
    })
    const player = ctx.player ? getPlayer(ctx.db, ctx.from) : null
    const state = player?.season02Events?.sponsorship
    const contract = state?.contract
    const offer = Object.values(state?.offers ?? {}).filter(x => Number(x.expiresAt) > now).sort((a, b) => b.offeredAt - a.offeredAt)[0]
    const contractLine = contract?.status === 'active'
      ? `📜 *${contract.sponsor}*: ${contract.condition} · ${contract.progress}/${contract.goal} · ${formatDuration(Math.max(0, contract.endsAt - now))} left.`
      : contract?.status ? `📜 Last contract: *${contract.status}*${contract.reward ? ` · ⭐ ${contract.reward}` : ''}.` : ''
    const offerLine = offer
      ? `🎁 Current offer: *${offer.sponsor}* · ${offer.condition} · expires in ${formatDuration(offer.expiresAt - now)}.`
      : `No current offer. The next top-50 round is at 11:00 or 20:00 WAT.`
    return `${offerLine}${contractLine ? `\n${contractLine}` : ''}\n_${p}season event sponsor [accept]_ to inspect or accept.`
  }
  if (event.id === 'returnee') {
    await finalizeSeasonEventVote(ctx.db, 'returnee', now)
    const summary = seasonEventVoteSummary(ctx.db, 'returnee')
    const timing = eventTiming(ctx.db, event, now)
    const startAt = timing?.startAt ?? Infinity
    const closesAt = Math.min(startAt + 2 * EVENT_DAY_MS, timing?.endsAt ?? Infinity)
    const windowLine = timing?.state === 'waiting' ? 'Waiting for the owner to start this event.' : now < startAt
      ? `Vote opens in ${formatDuration(startAt - now)}.`
      : now < closesAt ? `Vote closes in ${formatDuration(closesAt - now)}.` : 'The vote is closed.'
    return `🗳️ ${voteCountsText(summary, [['keep', 'Keep the relic'], ['take', 'Take it back']])}\n${windowLine}\n_${p}season event vote <keep|take>_`
  }
  if (event.id === 'demon_king') {
    const summary = await demonKingSummary(ctx.db, now)
    const own = ctx.player?.season02Events?.runNumber === runNumber ? ctx.player.season02Events.demonKing : null
    const role = own ? Object.values(own.rolesByDay ?? {}).at(-1) : null
    const ownLine = `Your contribution: *${Number(own?.contribution) || 0}* · today's role: *${role ?? 'Striker (default)'}*.`
    const state = summary.defeated ? 'defeated' : summary.ended ? 'time expired' : summary.live ? 'live' : 'not started'
    const barLine = summary.ok
      ? `👹 Shared bar: *${summary.hp}/${summary.maxHp} HP* · *${summary.participants}* contributors · ${state}.${!summary.live && !summary.ended ? ` Opens in ${formatDuration(Math.max(0, summary.startsAt - now))}.` : ''}`
      : 'The shared bar has not opened.'
    const checkpoints = summary.checkpoints?.length ? `Checkpoints passed: ${summary.checkpoints.join('% · ')}%.` : 'No checkpoint has fallen yet.'
    const reader = summary.readerSignal ? `Reader signal: the next checkpoint is *${summary.readerSignal}%*.` : ''
    return `${barLine}\n${ownLine}\n${checkpoints}${reader ? `\n${reader}` : ''}\n_${p}season event demon [status|role striker|role binder|role reader|claim]_`
  }
  if (event.id === 'outer_god') {
    let state = null
    if (ctx.player) await updatePlayer(ctx.db, ctx.from, player => {
      state = outerGodStatus(player, { runNumber })
      return player
    })
    return state
      ? `☄️ Corruption: *${state.corruption}/100* · gates cleared: *${state.clears}* · failures: *${state.failures}* · fragments: *${state.fragments}*.\n${state.cleanWeek ? 'Your clean-week record is intact.' : 'A fail or a gate clear above zero has broken the clean-week record.'}\n_${p}season event outer [status|claim]_\n_Existing gate spawns, rank, and claim rules are unchanged._`
      : `Close a Season 2 gate to track your Corruption and fragments.`
  }
  if (event.id === 'last_scenario') {
    let state = null
    if (ctx.player) await updatePlayer(ctx.db, ctx.from, player => {
      state = lastScenarioStatus(player, { runNumber })
      return player
    })
    await finalizeSeasonEventVote(ctx.db, 'last_scenario', now)
    const summary = seasonEventVoteSummary(ctx.db, 'last_scenario')
    const voteLine = voteCountsText(summary, [['regress', 'Begin Again'], ['stay', 'Keep the Record'], ['break', 'Break the Stream']])
    return `${state ? `Your final floors: *${state.floors}/7* · ${state.claimed ? 'ending claimed' : 'not claimed yet'}.\n` : ''}🗳️ ${voteLine}\n_Final-floor progress counts one clear per WAT day, floors 494–500._\n_${p}season event last [status|vote <regress|stay|break>|claim]_`
  }
  return ''
}

async function handleSeasonEventAction(ctx, action) {
  const p = config.prefix
  const season = getActiveSeason(ctx.db)
  if (!season || season.id !== 'season_02') {
    return ctx.reply('🌙 Season 2 event mechanics are closed. The normal Tower and gate systems remain available.')
  }
  const runtime = getSeasonRuntime(ctx.db)
  const runNumber = Number(runtime.runNumber) || 0
  const now = Date.now()
  const id = ctx.player?.id ?? ctx.from
  const requirePlayer = () => ctx.player ? null : ctx.reply(`⚠️ Register first with *${p}register* to take part in event actions.`)

  if (action === 'help') return ctx.reply(seasonEventHelpText(p))

  if (action === 'sponsor') {
    const sub = String(ctx.args[2] ?? 'status').toLowerCase()
    const window = getSeasonEventWindow(ctx.db, 'sponsorship', now)
    if (!window?.live && (sub === 'accept' || sub === 'sign')) {
      return ctx.reply(`📡 Offers can only be accepted during Sponsorship Week. Use *${p}season event sponsorship* to review an existing contract.`)
    }
    const round = window?.live ? await ensureSponsorshipRound(ctx.db, now) : { ok: false, reason: 'not-open' }
    if (ctx.player) {
      let accepted = null
      let settled = null
      let currentOffer = null
      let contract = null
      await updatePlayer(ctx.db, ctx.from, player => {
        settled = settleSponsorshipContract(player, { runNumber, now })
        const offers = Object.values(player.season02Events?.sponsorship?.offers ?? {})
          .filter(offer => Number(offer.expiresAt) > now)
          .sort((a, b) => b.offeredAt - a.offeredAt)
        currentOffer = offers[0] ?? null
        if (sub === 'accept' || sub === 'sign') {
          accepted = acceptSponsorshipOffer(player, { runNumber, now, roundKey: currentOffer?.roundKey ?? round.round?.key ?? null })
        }
        contract = player.season02Events?.sponsorship?.contract ?? null
        return player
      })
      if (sub === 'accept' || sub === 'sign') {
        if (!accepted?.ok) {
          const messages = {
            active: 'You already have an active sponsor contract.',
            none: 'No unexpired offer is available for you. Only today’s active top-50 offers can be accepted.',
            used: 'That offer has already been accepted.',
          }
          return ctx.reply(`📡 ${messages[accepted?.reason] ?? 'No sponsor offer could be accepted.'}`)
        }
        return ctx.reply(`「 📜 SPONSOR CONTRACT 」\n\n*${accepted.contract.sponsor}*\n${accepted.contract.condition}\n\n_The 24-hour clock starts now. Keep the condition to earn up to 200 capped Stars._`)
      }
      const offerLine = currentOffer
        ? `🎁 Offer: *${currentOffer.sponsor}*\n${currentOffer.condition}\n_Expires in ${formatDuration(currentOffer.expiresAt - now)}._`
        : `No offer is currently assigned to you. The top 50 eligible Viewers receive offers at 11:00 and 20:00 WAT.`
      const contractLine = contract?.status === 'active'
        ? `\n\n📜 Active: *${contract.sponsor}* · ${contract.condition}\nProgress ${contract.progress}/${contract.goal} · ${formatDuration(contract.endsAt - now)} remaining.`
        : contract?.status ? `\n\nLast contract: *${contract.status}*${contract.reward ? ` · ⭐ ${contract.reward}` : ''}.` : ''
      const settleLine = settled ? `\n${settled.status === 'complete' ? `✅ Contract settled · ⭐ ${settled.paid}.` : '❌ The contract expired without its condition.'}` : ''
      return ctx.reply(`「 📡 SPONSORSHIP 」\n\n${offerLine}${contractLine}${settleLine}\n\n_${p}season event sponsor accept_`)
    }
    return requirePlayer()
  }

  if (action === 'vote') {
    const event = currentEvent(ctx.db, now)
    const choices = String(ctx.args[2] ?? '').toLowerCase()
    const eventId = event?.id === 'returnee' ? 'returnee' : event?.id === 'last_scenario' ? 'last_scenario' : null
    if (!eventId) return ctx.reply(`🗳️ No server vote is open right now. Use *${p}season event* to see the live mechanic.`)
    if (!ctx.player) return requirePlayer()
    const valid = eventId === 'returnee' ? ['keep', 'take'] : ['regress', 'stay', 'break']
    if (!valid.includes(choices)) return ctx.reply(`Usage: *${p}season event vote <${valid.join('|')}>*`)
    const result = await castSeasonEventVote(ctx.db, id, eventId, choices, now)
    if (!result.ok) {
      if (result.reason === 'closed') await finalizeSeasonEventVote(ctx.db, eventId, now)
      const explanation = result.reason === 'already-voted'
        ? `Your vote is already recorded as *${result.choice}*.`
        : result.reason === 'not-open' ? `The vote opens in ${formatDuration(result.opensAt - now)}.`
          : result.reason === 'closed' ? 'The vote is closed; its result is final.'
            : 'That vote could not be recorded.'
      return ctx.reply(`🗳️ ${explanation}`)
    }
    const names = eventId === 'returnee'
      ? { keep: 'Keep the relic', take: 'Take it back' }
      : { regress: 'Begin Again', stay: 'Keep the Record', break: 'Break the Stream' }
    return ctx.reply(`🗳️ Your vote is recorded: *${names[choices]}*. One vote per player; the result is server-wide.`)
  }

  if (action === 'demon') {
    const sub = String(ctx.args[2] ?? 'status').toLowerCase()
    const role = String(ctx.args[3] ?? '').toLowerCase()
    if (sub === 'role') {
      if (!ctx.player) return requirePlayer()
      const active = Boolean(getSeasonEventWindow(ctx.db, 'demon_king', now)?.live)
      let result = null
      await updatePlayer(ctx.db, ctx.from, player => {
        result = setDemonKingRole(player, role, { runNumber, now, active })
        return player
      })
      if (!result.ok) return ctx.reply(result.reason === 'chosen'
        ? `👹 Today's role is already *${result.role}*. Choose a new role after the WAT reset.`
        : `Usage: *${p}season event demon role <striker|binder|reader>*${result.reason === 'closed' ? '\n_The Demon King role desk is closed._' : ''}`)
      return ctx.reply(`👹 Role set: *${result.role}*. It lasts for today's WAT day.`)
    }
    if (sub === 'claim') {
      if (!ctx.player) return requirePlayer()
      const summary = await demonKingSummary(ctx.db, now)
      let reward = null
      await updatePlayer(ctx.db, ctx.from, player => {
        reward = claimDemonKingReward(player, { playerId: id, runNumber, summary, now })
        return player
      })
      if (!reward?.ok) return ctx.reply(reward?.reason === 'live'
        ? '👹 The shared scenario is still live. Rewards settle after the bar breaks or its 72-hour timer ends.'
        : reward?.reason === 'no-contribution' ? '👹 No Tower contribution was recorded for you.' : '👹 Your Demon King reward has already been claimed.')
      return ctx.reply(`👹 Scenario reward claimed: ⭐ *${reward.stars}* · *${reward.contribution}* contribution · ${reward.sigil} sigil${reward.top100 ? ' · 🏅 top-100 title: Demon King Slayer' : ''}.`)
    }
    const extra = await seasonEventProgressText(ctx, EVENTS.find(e => e.id === 'demon_king'))
    return ctx.reply(extra)
  }

  if (action === 'outer') {
    const sub = String(ctx.args[2] ?? 'status').toLowerCase()
    if (!ctx.player) return requirePlayer()
    const timing = eventTiming(ctx.db, EVENTS.find(e => e.id === 'outer_god'), now)
    const eventStart = timing?.startAt ?? Infinity
    const eventEnd = timing?.endsAt ?? Infinity
    if (sub === 'claim') {
      let result = null
      await updatePlayer(ctx.db, ctx.from, player => {
        result = claimOuterGodTitle(player, { runNumber, eventEnded: now >= eventEnd, now })
        return player
      })
      const text = result.ok ? `☄️ Gatekeeper title claimed. Your clean-week record remains on the season card.`
        : result.reason === 'live' ? `☄️ The Outer God week has not ended yet.`
          : result.reason === 'claimed' ? `☄️ Gatekeeper has already been claimed.`
            : `☄️ Not qualified: clear at least one gate, keep corruption at zero, and do not fail or clear above zero during the event week.`
      return ctx.reply(text)
    }
    return ctx.reply(await seasonEventProgressText(ctx, EVENTS.find(e => e.id === 'outer_god')))
  }

  if (action === 'last') {
    const sub = String(ctx.args[2] ?? 'status').toLowerCase()
    if (sub === 'vote') {
      const choice = String(ctx.args[3] ?? '').toLowerCase()
      if (!ctx.player) return requirePlayer()
      const valid = ['regress', 'stay', 'break']
      if (!valid.includes(choice)) return ctx.reply(`Usage: *${p}season event last vote <${valid.join('|')}>*`)
      const result = await castSeasonEventVote(ctx.db, id, 'last_scenario', choice, now)
      if (!result.ok) {
        if (result.reason === 'closed') await finalizeSeasonEventVote(ctx.db, 'last_scenario', now)
        return ctx.reply(result.reason === 'already-voted'
          ? `🗳️ Your vote is already recorded as *${result.choice}*.`
          : result.reason === 'not-open' ? `🗳️ The finale vote opens in ${formatDuration(result.opensAt - now)}.`
            : `🗳️ The finale vote is closed.`)
      }
      return ctx.reply(`🗳️ Your ending vote is recorded: *${choice}*. One vote per player.`)
    }
    if (sub === 'claim') {
      if (!ctx.player) return requirePlayer()
      let reward = null
      await updatePlayer(ctx.db, ctx.from, async player => {
        reward = await claimLastScenarioReward(ctx.db, player, { now })
        return player
      })
      if (!reward?.ok) return ctx.reply(reward?.reason === 'floors'
        ? `📖 Finish all seven final floors first. Progress: *${reward.floors}/7*.`
        : reward?.reason === 'live' || reward?.reason === 'open'
          ? `📖 The finale is still open. Claim after the seven-day scenario and vote window close.`
          : reward?.reason === 'claimed' ? `📖 Your ending is already written into the season record.`
            : `📖 The finale reward could not be claimed.`)
      return ctx.reply(`「 📖 THE LAST SCENARIO 」\n\n*${reward.label}*\n_${reward.ending}_\n\n⭐ *${reward.stars}* · Title: *${reward.title}*`)
    }
    if (sub === 'status') return ctx.reply(await seasonEventProgressText(ctx, EVENTS.find(e => e.id === 'last_scenario')))
    return ctx.reply(`Usage: *${p}season event last [status|vote <regress|stay|break>|claim]*`)
  }

  return ctx.reply(seasonEventHelpText(p))
}

async function handleSeasonEvent(ctx) {
  const sub = (ctx.args[1] ?? 'current').toLowerCase()
  if (['start','end','auto'].includes(sub)) return eventCommand.run({...ctx, args:ctx.args.slice(1)})
  const p = config.prefix
  const season = getActiveSeason(ctx.db)
  if (!season || season.id !== 'season_02') {
    // "There is no event right now" was the wrong answer to a much more
    // specific question. A member with a season RUNNING reads that as "the
    // events are broken", because from their side the season is plainly live
    // and nothing has happened for two weeks. Name the season that is actually
    // running, say where Season 2 is, and stop implying a fault.
    if (!season) {
      return ctx.reply(
        `🌙 *No season is running right now.*\n` +
        `_The six scheduled events run inside Season 2, Life of a Regressor. ` +
        `Nothing is wrong: there is no run for them to open in._`,
      )
    }
    // Manual event controls require an active Season 2 run; never reset
    // or replace an active season from an event/menu command.
    const runtime = getSeasonRuntime(ctx.db)
    const pending = runtime.pendingSeasonId
    const seasonTwo = seasons.find(x => x.id === 'season_02')
    const daysLeftHere = runtime.endsAt
      ? Math.max(0, Math.ceil((Number(runtime.endsAt) - Date.now()) / 86400000))
      : null
    const timeline = pending === 'season_02'
      ? `⏳ _Season 2 is already queued and opens by itself, about an hour after this one settles._`
      : `⏳ _Season 2 opens when this one settles` +
        (daysLeftHere != null ? ` (about *${daysLeftHere} days*)` : '') + `.`
    return ctx.reply(
      `📺 *${season.name}* is the season running right now.\n` +
      `_Its six scheduled events belong to *Season 2${seasonTwo ? `, ${seasonTwo.name}` : ''}*, which has not started yet._\n\n` +
      `${timeline}\n` +
      `🔒 _Once Season 2 is active, the owner can use .event start <event-id>. Otherwise each opens on its own ` +
      `week of Season 2: day 8 for the first, then one a week through week 7._\n\n` +
      `▶️ *${p}season* : this season's own progress and pass\n` +
      `_${p}season lore_ : what this season is about`,
    )
  }
  if (sub === 'help' || sub === 'mechanics') return ctx.reply(seasonEventHelpText(p))
  if (['sponsor', 'sponsorship'].includes(sub)) return handleSeasonEventAction(ctx, 'sponsor')
  if (sub === 'vote') return handleSeasonEventAction(ctx, 'vote')
  if (['demon', 'demon_king'].includes(sub)) return handleSeasonEventAction(ctx, 'demon')
  if (['outer', 'outer_god'].includes(sub)) return handleSeasonEventAction(ctx, 'outer')
  if (['last', 'finale', 'last_scenario'].includes(sub)) return handleSeasonEventAction(ctx, 'last')
  if (sub === 'status') {
    const live = currentEvent(ctx.db)
    if (!live) return ctx.reply(`No scheduled event is live.\n${eventScheduleText(ctx.db)}`)
    const progress = await seasonEventProgressText(ctx, live)
    return sendImage(ctx, live.plate, `${eventCardText(ctx.player, live, ctx.db, Date.now(), p)}\n\n${progress}`)
  }
  if (sub === 'list' || sub === 'schedule' || sub === 'all') {
    return ctx.reply(eventScheduleText(ctx.db))
  }
  // A named lookup wins over "current" so `.season event sponsorship` always works.
  if (sub !== 'current' && sub !== 'now') {
    const named = findSeasonEventByName(ctx.args.slice(1).join(' '))
    if (named) {
      const progress = await seasonEventProgressText(ctx, named)
      return sendImage(ctx, named.plate, `${eventCardText(ctx.player, named, ctx.db, Date.now(), p)}${progress ? `\n\n${progress}` : ''}`)
    }
    return ctx.reply(
      `「 🗓 SEASON EVENT 」\n\n` +
      `⌁ _${p}season event_ · this week's event\n` +
      `⌁ _${p}season event list_ · the whole schedule\n` +
      `⌁ _${p}season event <name>_ · look up one event`,
    )
  }
  const ev = currentEvent(ctx.db)
  if (!ev) {
    const week = seasonWeek(ctx.db)
    const next = nextEvent(ctx.db)
    const head = seasonEventControl(ctx.db)?.manual
      ? `No manual event is live. Owner: ${p}event start <event-id>.`
      : week <= 1
      ? 'The broadcast has not started yet. Week 1 is for climbing.'
      : 'The events are over for this season. What they left behind stays.'
    const tail = next ? `\n\nNext: *${next.name}* in week ${next.week}.` : ''
    return ctx.reply(`${head}${tail}\n\n_${p}season event list_ shows the schedule.`)
  }
  const progress = await seasonEventProgressText(ctx, ev)
  return sendImage(ctx, ev.plate, `${eventCardText(ctx.player, ev, ctx.db, Date.now(), p)}${progress ? `\n\n${progress}` : ''}`)
}

/**
 * The Season 2 one-of-one chases, in the order the help card lists them: the
 * spin command that opens each banner. Everything else on their help lines
 * (the per-spin price and its currency, the guarantee, the Monds price) is read
 * from the banner in lib/spin-banners.js and the character in
 * data/characters.json, so a retune there cannot leave this card quoting an old
 * number. Minato spins with Gems like the first two; Rengoku spins with Solars.
 */
const SEASON_TWO_SPINS = [
  ['kim_dokja', 'kim-spin'],
  ['rimuru', 'rimuru-spin'],
  ['minato', 'minato-spin'],
  ['rengoku', 'rengoku-spin'],
]

/** "5 Gems" / "50,000 Solars": a banner's per-spin price in its own currency. */
function spinPriceWords(banner) {
  return spinCurrency(banner) === 'solars'
    ? `${Math.floor(Number(banner.costPerSpin) || 0).toLocaleString('en-US')} Solars`
    : `${banner.costPerSpin} Gems`
}

/** One help line per Season 2 chase. Skips an id with no banner or character. */
function seasonTwoSpinLines(prefix) {
  return SEASON_TWO_SPINS.map(([id, command]) => {
    const banner = getSpinBanner(id)
    const character = characterMap[id]
    if (!banner || !character) return null
    const monds = mondPriceFor(character)
    return (
      `*${prefix}${command} <amount>* — ${spinPriceWords(banner)} per spin; guaranteed by spin ${banner.pityAt}.` +
      (monds !== null ? ` Or buy outright for 🪙${monds} Monds.` : '') +
      ` ⚡ One-of-one: the first winner or buyer, bot-wide, takes him for good.`
    )
  }).filter(Boolean)
}

async function sendHelp(ctx) {
  const active = getActiveSeason(ctx.db)
  const days = active?.durationDays ?? 90
  const tiers = active?.battlePass?.tierCount ?? 50
  const dungeon = active?.dungeon ?? 'season_01_ruins'
  const catalog = getSeasonCatalog(active ?? {})
  const pages = getSeasonShopPages(catalog).length || 0
  const entries = catalog.length
  // The Mei paragraph is about Mei, not about "the season". Season 2 has its
  // own open banners (three charge Gems, Rengoku's charges Solars; each is also
  // buyable outright for Monds — the two doors are alternatives, never charged
  // together), so the help text follows the active season instead of treating
  // every non-Mei season as spinless.
  const meiSeason = active?.characters?.major === 'mei'
  const seasonTwo = active?.id === 'season_02'
  const spinLines = seasonTwo
    ? [
        `🎰 *Character spins*`,
        ...seasonTwoSpinLines(config.prefix),
      ]
    : meiSeason
      ? [
          `🎰 *Mei Spin*`,
          `${config.prefix}mei-spin <amount> uses 0.5 Gems per spin.`,
          `Odds ramp up between spin 50 and spin 100, guaranteed by spin 100.`,
          `Mei can only ever be won by ONE player bot-wide — once claimed, spinning locks for everyone else.`,
        ]
      : [
          `🎰 *Character spins*`,
          `No spin is open this season yet. The leads (${leadNames(active)}) appear in the story as NPCs whether or not a spin ever opens; if one does, it is announced in the group first.`,
        ]
  const gemEntries = catalog.filter(entry => entry.currency === 'gems')
  const seasonPointEntries = Math.max(0, entries - gemEntries.length)
  const seasonCurrency = active?.currencyLabel ?? (seasonTwo ? 'Stars' : 'Season Points')
  const seasonCurrencyEmoji = seasonTwo ? '⭐' : '✨'
  const gemEntryNotes = gemEntries.map(entry =>
    `${describeSeasonEntry(entry).name} costs ${Number(entry.price ?? 0).toLocaleString()} Gems`,
  )
  const shopSummary = entries
    ? `${entries} entries across ${pages} themed ${pages === 1 ? 'page' : 'pages'} — ${seasonPointEntries} priced in ${seasonCurrencyEmoji} ${seasonCurrency}${gemEntryNotes.length ? `; ${gemEntryNotes.join('; ')}` : ''}.`
    : `No shop entries are configured for this season yet.`
  const lines = [
    `📖 *SEASON SYSTEM*`,
    `────────────────────`,
    active
      ? `*Season ${active.number}: ${active.name}* — ${days}-day cycle.`
      : `Seasons are ${days}-day content cycles with three ways to earn exclusive rewards.`,
    ``,
    `${seasonCurrencyEmoji} *${seasonCurrency}*`,
    seasonTwo
      ? `Stars are spendable in the Season Shop; they are separate from Battle Pass XP.`
      : `Earned from season gameplay. They buy items in the Season Shop.`,
    seasonTwo
      ? `At season end, leftover Stars convert to Solars at the configured rate.`
      : `Spending them never costs Battle Pass progress — the pass counts points earned, not points held. Leftover points convert to Solars at season end.`,
    ``,
    `🎫 *Battle Pass*`,
    seasonTwo
      ? `${tiers} tiers in four 10-tier Arcs, with separate Free and Premium claim tracks.`
      : `${tiers} tiers with a free track and a Gem-unlocked premium track.`,
    seasonTwo
      ? `Pass XP: ${active?.battlePass?.dailyScenarioXp ?? 45} per daily quest claim, ${active?.battlePass?.dailyClearConditionBonusXp ?? 60} for completing all daily clear conditions, and ${active?.battlePass?.weeklyScenarioXp ?? 350} + ${active?.battlePass?.weeklyClearConditionBonusXp ?? 100} for a weekly Personal Scenario clear. Boxes also grant Pass XP, and ${active?.battlePass?.regularXpPassPercent ?? 5}% of regular player XP feeds the pass.`
      : `Both tracks climb on the same Season XP: every cleared season dungeon floor is worth ${active?.battlePass?.xpPerSeasonLevel ?? 100} XP, and every Season Point you earn is worth 1.`,
    seasonTwo
      ? `Clear the daily and weekly conditions to earn Pass XP. Constellation Sponsor adds 10%; box boosts add 25% while active.`
      : `Tiers get more expensive the higher you go, so the pass is built to take most of the ${days} days — clearing the whole dungeon gets you roughly a third of the way.`,
    ...(seasonTwo
      ? [`Free character rewards: Evelyn Ling (tier 10), Yoo Joonghyuk (tier 25), and Han Sooyoung (tier 40). Pass-track characters are earned on the pass only — Monds cannot buy them.`, `Kim Dokja and Rimuru are the paid chases: spin with Gems, or buy outright with *${config.prefix}character buy <name>* (🪙25 / 🪙17 Monds). Klein Moretti is 💎1,999 Gems.`, `Minato Namikaze and Kyojuro Rengoku are one-of-one chases too: Minato spins with Gems, Rengoku spins with Solars, and either can be bought outright instead (🪙${mondPriceFor(characterMap.minato) ?? 7} / 🪙${mondPriceFor(characterMap.rengoku) ?? 4} Monds).`]
      : []),
    `Premium (💎${active?.battlePass?.premiumCost ?? 5}) unlocks the second reward column. It never adds XP or auto-claims rewards.`,
    ...(seasonTwo ? [`Claim tracks separately: *${config.prefix}season pass claim free all* / *claim premium all*. Use *${config.prefix}season pass prev/next*, *page <n>* or *arc <1-4>* to browse.`] : []),
    ``,
    ...spinLines,
    ``,
    `🛒 *Season Shop*`,
    shopSummary,
    `${config.prefix}season shop <page> to browse; ${config.prefix}season info <name> for artwork and full stats on any of them.`,
    ``,
    `🗺️ *Season Dungeon*`,
    seasonTwo
      ? `The Grand Tower grants its combat rewards; Pass XP comes from daily/weekly Scenarios, Dokkaebi Boxes and a share of regular XP, not floor clears.`
      : `The active season dungeon grants +${active?.dungeonBoostPercent ?? 10}% XP, Fame, and Solars, and every floor you clear is a Season Level.`,

    `${config.prefix}season dungeon briefs you on it; ${config.prefix}enter ${dungeon} is what actually takes you in.`,
    ``,
    `Commands:`,
    `• ${config.prefix}season shop [page] · [buy <id>]`,
    `• ${config.prefix}season info <name>`,
    `• ${config.prefix}season pass [tier|next|prev|page <n>|arc <1-4>]`,
    `• ${config.prefix}season pass claim [free|premium|all] [tier|all]`,
    ...(seasonTwo ? [`• ${config.prefix}season pass skip · ${config.prefix}dokkaebi boxes/open/cards`] : []),
    `• ${config.prefix}season premium`,
    `• ${config.prefix}season dungeon`,
    `• ${config.prefix}scenario [list|accept|confirm|decline|status|retry]`,
    `• ${config.prefix}season event [list|sponsor|vote|demon|outer|last]`,
    `• ${config.prefix}quest season [claim <id|all>]`,
    `• ${config.prefix}scavenge · ${config.prefix}memory [list|read|hint]`,
    `• ${config.prefix}hiddenscenario [investigate|evelyn]`,
    ...(meiSeason ? [`• ${config.prefix}mei-spin <amount>`] : []),
    ...(seasonTwo ? SEASON_TWO_SPINS.map(([, command]) => `• ${config.prefix}${command} <amount>`) : []),
    `• ${config.prefix}season lore`,
    `• ${config.prefix}setpearl`,
    `• ${config.prefix}openiron · ${config.prefix}opendiamond · ${config.prefix}openmythic`,
  ]
  return ctx.reply(lines.join('\n'))
}

async function sendLore(ctx) {
  const season = getActiveSeason(ctx.db)
  if (ctx.player && season?.id === 'season_02') await updatePlayer(ctx.db, ctx.from, player => {
    addSeason02TowerAction(player, 'lore_read', { db: ctx.db })
    return player
  })
  // A configured season with its own `lore.story` (season_02) reads from the
  // data the owner edits; season_01's prose stays here because it predates it.
  const story = season?.lore?.story
  if (Array.isArray(story) && story.length) {
    return ctx.reply(
      `📖 *${String(season.name).toUpperCase()}*\n\n` + story.join('\n\n'),
    )
  }
  return ctx.reply(
    `📖 *THE BEGINNING OF THE END*\n\n` +
    `Astral was at peace — fountains flowing and rivers singing — until the End arrived, a monster so violent that nothing could kill it. It could only be contained. ` +
    `The goddess Mei sealed herself to it, becoming the prison rather than guarding one, and paid the cost for generations.\n\n` +
    `The seal held until an unnamed bar patron accidentally activated the Ender Pearl anchoring it. It broke by accident, not sabotage. Mei and the End were released together, still bound to each other's fate. Mei remembers everything and guides the players: help her seal the End for good.\n\n` +
    `Willow is native to Astral, a strong fighter who reads enemy weaknesses. She was recruited specifically to fight the End, and her Battle Advisor is the gift that made her essential.\n\n` +
    `Urahara is a crossover character present in Astral without an in-world role. He has no plot tie to the seal — he is simply here, and his skill is available to those who equip him.`,
  )
}

/**
 * `.season dungeon` — a briefing, deliberately NOT an entry point.
 *
 * `.dungeon`/`.enter` (plugins/dungeon.js) is the only thing that walks a
 * player into a dungeon, season one included. This subcommand exists because
 * "season dungeon" is the obvious thing to type, and it would be worse to
 * either silently do nothing or quietly start a run from a menu command. It
 * reports your standing in the ruins and hands you the command that enters.
 */
async function handleSeasonDungeon(ctx) {
  const season = activeSeasonOrReply(ctx)
  if (!season) return
  const p = config.prefix
  const locId = season.dungeon
  const loc = locationsMap[locId]
  const dungeonDisplayName = season.id === 'season_02'
    ? placeName(loc ?? locId, ctx.db)
    : loc?.name ?? locId
  const floors = loc?.floors ?? season.floorCount ?? 50
  const bossFloor = season.partyBossFloor ?? floors
  const stagingTown = season.id === 'season_02' ? locationsMap[TOWER_STAGING_LOCATION_ID] : null
  const stagingCost = stagingTown && ctx.player?.location !== TOWER_STAGING_LOCATION_ID
    ? travelTollFor(stagingTown, ctx.player)
    : 0
  const travelLine = season.id === 'season_02'
    ? `☣️ Toxic air outside sealed hubs · stage at *Wardgate*${stagingCost ? ` · ☀️ ${stagingCost.toLocaleString('en-US')} Solars to reach` : ''} · 📍 Checkpoints every *${loc?.checkpointInterval ?? 25}*`
    : `☀️ Travel cost: *${loc?.travelCost ?? 0} Solars*  ·  📍 Checkpoints every *${loc?.checkpointInterval ?? 25}*`

  const lines = [
    `🗺️ *SEASON DUNGEON*`,
    `*${dungeonDisplayName}*`,
    `────────────────────`,
    loc?.description ? `_${loc.description}_` : '',
    ``,
    `🏰 Floors: *${floors}*  ·  💀 Boss: *Floor ${bossFloor}*`,
    `🎯 Level range: *${loc?.levelRange?.[0] ?? '?'}–${loc?.levelRange?.[1] ?? '?'}*  ·  Entry: *Lv ${loc?.entryLevel ?? '?'}*`,
    travelLine,
    `🌞 Bonus: *+${season.dungeonBoostPercent ?? 10}%* XP, Fame and Solars while the season runs`,
  ]

  if (ctx.player) {
    ensurePlayerSeasonState(ctx.player, season.id)
    const sp = ctx.player.seasonProgress
    const prog = seasonTierProgress(ctx.player, season)
    const best = ctx.player.dungeonProgress?.[locId]?.highestFloor ?? 0
    lines.push(
      ``,
      `📍 Your next floor: *${sp.currentFloor ?? 1}/${floors}*  ·  Best reached: *${best}*`,
      ...(season.id === 'season_02' ? [] : [`🌙 Season Level: *${sp.seasonLevel ?? 0}* — each cleared floor is one level`]),
      `🎫 Battle Pass: *Tier ${prog.tier}/${prog.tierCount}*  ·  next tier in *${prog.toNext.toLocaleString()}* ${season.id === 'season_02' ? 'Pass XP' : 'Season XP'}`,
    )
  }

  lines.push('', `⚔️ *How to actually go in*`)
  if (season.id === 'season_02') {
    lines.push(
      `*${p}travel ${TOWER_STAGING_LOCATION_ID}* — reach Wardgate’s filtered airlock first`,
      `*${p}enter ${locId}* — start or resume the 500-floor climb from Wardgate`,
      `*${p}dungeon* — fight the next floor once you're inside`,
      `*${p}dungeon leave* — save and return to Wardgate’s safe side`,
      `🤝 Floor *${bossFloor}* is party-gated; every member must stage at Wardgate before *${p}dparty enter ${locId}*.`,
      '',
      `_This command only briefs you — it never enters the dungeon._`,
    )
  } else {
    lines.push(
      `*${p}enter ${locId}* — start or resume your run`,
      `*${p}dungeon* — fight the next floor once you're inside`,
      `*${p}dungeon leave* — save and walk out`,
      `🤝 Floor *${bossFloor}* is party-gated: *${p}dparty create*, invite your allies, then *${p}dparty enter ${locId}*.`,
      '',
      `_This command only briefs you — it never enters the dungeon._`,
    )
  }

  return ctx.reply(lines.filter((line) => line !== '').join('\n'))
}

function activeSeasonOrReply(ctx) {
  const season = getActiveSeason(ctx.db)
  if (!season) {
    ctx.reply(NO_ACTIVE_SEASON.replace('{prefix}', config.prefix))
    return null
  }
  return season
}

function entryName(entry) {
  return describeSeasonEntry(entry).name
}

/**
 * Resolves the `[page]` argument of `.season shop`. Accepts a 1-based number
 * ("3"), a category id ("mega"), or a word from the page label ("stones"), so
 * a player who saw "💠 Mega Stones" in a caption can type either what they
 * read or the number next to it. Returns a 0-based index, or 0 if nothing
 * matched — an unrecognised page shows the first shelf rather than an error,
 * since the render itself names the page the player landed on.
 */
function resolvePageIndex(pages, raw) {
  if (raw == null || raw === '') return 0
  const asNumber = Number(raw)
  if (Number.isFinite(asNumber) && asNumber >= 1) {
    return Math.min(pages.length - 1, Math.floor(asNumber) - 1)
  }
  const q = String(raw).toLowerCase().trim()
  const byCategory = pages.findIndex((page) => page.category.toLowerCase() === q)
  if (byCategory >= 0) return byCategory
  const byLabel = pages.findIndex((page) => page.label.toLowerCase().includes(q))
  return byLabel >= 0 ? byLabel : 0
}

/** Resolve one-use Season Shop coupons without mutating the player. */
function seasonShopPrice(player, entry) {
  const basePrice = Math.max(0, Math.floor(Number(entry?.price) || 0))
  const coupon = entry?.currency === 'gems'
    ? null
    : (player?.seasonProgress?.shopCoupons ?? []).find((item) => Number(item?.uses) > 0)
  const discountPercent = Math.max(0, Math.min(100, Number(coupon?.percent) || 0))
  return {
    basePrice,
    discountPercent,
    price: Math.max(0, Math.ceil(basePrice * (100 - discountPercent) / 100)),
  }
}

/**
 * Per-entry purchase state, shared by the shop render (stamps) and the text
 * listing so the two can never disagree about what a player already owns.
 */
function shopEntryState(player, entry) {
  if (!player) return { owned: false, soldOut: false, left: null, affordable: true }
  const purchases = player.seasonPurchases?.[entry.id] ?? 0
  const limit = entry.purchaseLimit
  const owned = entry.rewardType === 'pokemon'
    ? hasOwnedSeasonPokemon(player, entry.dexId)
    : hasOwnedSeasonContent(player, entry.rewardType, entry.id)
  const soldOut = limit != null && purchases >= limit
  const pricing = seasonShopPrice(player, entry)
  return {
    owned: owned || (soldOut && limit === 1),
    soldOut,
    left: limit == null ? null : Math.max(0, limit - purchases),
    price: pricing.price,
    basePrice: pricing.basePrice,
    discountPercent: pricing.discountPercent,
    affordable: (entry.currency === 'gems' ? (player.wallet?.gems ?? 0) : (player.seasonPoints ?? 0)) >= pricing.price,
  }
}

/**
 * `.season offer` — themed, limited-time money packages (gems/solars for
 * Naira). Distinct from `.season shop`, which spends in-game Season Points
 * and stays usable in groups. This is a real-money purchase, so it follows
 * premium.js/topup.js exactly: DM-only, screenshot-confirmed via the shared
 * lib/pending-purchase.js flow (extended with a 'seasonoffer' kind).
 */
function offerList(pr) {
  return offerData.packages
    .map(pkg => {
      const reward = pkg.gems ? `💎${pkg.gems} gems` : `☀️${pkg.solars.toLocaleString()} solars`
      return `  • *${pkg.id}* — ${reward} for ₦${pkg.priceNaira.toLocaleString()}`
    })
    .join('\n') + `\n\nBuy with *${pr}season offer buy <id>* _(DM only)_.`
}

async function handleOffer(ctx) {
  const pr = config.prefix
  const sub = (ctx.args[1] ?? '').toLowerCase()

  // Already-paid orders must still be resolved after the season closes.
  if (sub === 'confirm') return handleOfferConfirm(ctx)
  if (sub === 'reject') return handleOfferReject(ctx)

  const season = getActiveSeason(ctx.db)
  if (!season) return ctx.reply(NO_ACTIVE_SEASON.replace('{prefix}', config.prefix))
  const seasonRunNumber = getSeasonRuntime(ctx.db).runNumber

  if (ctx.isGroup) {
    return ctx.reply(`💬 DM me *${pr}season offer* to see this season's money offers.`)
  }

  if (sub !== 'buy') {
    const caption = `🎁 *SEASON OFFERS:*\n${offerList(pr)}`
    try {
      return await ctx.replyImage(SEASON_OFFER_BANNER, caption)
    } catch {
      return ctx.reply(caption)
    }
  }

  if (!ctx.player) return ctx.reply(`⚠️ Register first with *${pr}register*.`)
  const pkgId = (ctx.args[2] ?? '').toUpperCase()
  const pkg = offerData.packages.find(p => p.id.toUpperCase() === pkgId)
  if (!pkg) return ctx.reply(`❌ Unknown offer *"${ctx.args[2] ?? ''}"*.\n\n🎁 *Season Offers:*\n${offerList(pr)}`)

  let closed = false
  await updatePlayer(ctx.db, ctx.from, p => {
    if (!isSeasonRunActive(ctx.db, season.id, seasonRunNumber)) {
      closed = true
      return
    }
    p.seasonOfferPending = { packageId: pkg.id, gems: pkg.gems || 0, solars: pkg.solars || 0, state: 'awaiting_screenshot', at: Date.now() }
  })
  if (closed) return ctx.reply(SEASON_CHANGED)

  const pay = config.payment
  const reward = pkg.gems ? `💎${pkg.gems} Gems` : `☀️${pkg.solars.toLocaleString()} Solars`
  return ctx.reply(
    `🎁 *${reward}* — ₦${pkg.priceNaira.toLocaleString()}\n\n` +
    `💳 *Payment Details:*\n` +
    `  🏦 Bank: *${pay.bankName || '(not configured)'}*\n` +
    `  🔢 Account: *${pay.accountNumber || '(not configured)'}*\n` +
    `  👤 Name: *${pay.accountName || '(not configured)'}*\n\n` +
    `📸 Once paid, send a screenshot of the transfer *right here in this DM* to confirm.`,
  )
}

/* Buyer resolution for `.season offer confirm|reject` is lib/pending-confirm.js's
 * job, shared with .topup/.monds/.premium: it finds the record that actually
 * HOLDS the pending rather than the first record whose display name matches.
 */

async function handleOfferConfirm(ctx) {
  if (!isOwnerJid(ctx.from)) return ctx.reply(`❌ Owner only.`)

  // The buyer's number or their name — see lib/pending-confirm.js. No
  // `await ctx.db.read()` here: that read is what used to erase a pending the
  // screenshot hook had only just applied in RAM.
  const query = ctx.args.slice(2).join(' ')
  const found = findPendingForOwner(ctx.db, query, 'seasonoffer')
  if (!found.ok) return ctx.reply(pendingFailureText(ctx.db, { prefix: config.prefix, result: found }))

  const target = found.target
  const { gems, solars, packageId } = found.pending
  await updatePlayer(ctx.db, found.key, p => {
    p.wallet = p.wallet ?? {}
    if (gems)   p.wallet.gems   = roundGems((p.wallet.gems ?? 0) + gems)
    if (solars) p.wallet.solars = (p.wallet.solars ?? 0) + solars
    p.seasonOfferPending = null
  })

  const fresh = getPlayer(ctx.db, found.key)
  const rewardText = gems ? `💎${gems} gems` : `☀️${solars.toLocaleString()} solars`
  // Payment-completion image on the confirmation DM (degrades to text).
  await sendImageTo(ctx, 'payment_done.jpg',
    `🎉 *Season offer confirmed!* ${rewardText} credited (offer: *${packageId}*).\nBalance: 💎${fmtGems(fresh.wallet.gems)} · ☀️${fresh.wallet.solars ?? 0}.`,
    found.key,
  ).catch(() => {})

  return ctx.reply(`✅ Credited ${rewardText} to *${target.name}* (offer: *${packageId}*).`)
}

async function handleOfferReject(ctx) {
  if (!isOwnerJid(ctx.from)) return ctx.reply(`❌ Owner only.`)

  const query = ctx.args.slice(2).join(' ')
  const found = findPendingForOwner(ctx.db, query, 'seasonoffer', { anyKind: true })
  if (!found.ok) return ctx.reply(pendingFailureText(ctx.db, { prefix: config.prefix, result: found }))

  await updatePlayer(ctx.db, found.key, p => { p[PURCHASE_KINDS[found.kind].field] = null })

  await ctx.sock.sendMessage(found.key, {
    text: `❌ Your season offer couldn't be confirmed. Please double-check the payment and try *${config.prefix}season offer buy <id>* again, or contact support.`,
  }).catch(() => {})

  const other = pendingKinds(getPlayer(ctx.db, found.key))
  return ctx.reply(`✅ Cleared *${found.target.name}*'s ${PURCHASE_KINDS[found.kind].noun}.` +
    (other.length
      ? `\n\n⚠️ They still have ${other.length} other pending purchase(s) on the same record — *${config.prefix}${PURCHASE_KINDS[other[0]].command} ${found.key}*.`
      : ''))
}

async function handleShop(ctx) {
  const season = activeSeasonOrReply(ctx)
  if (!season) return
  const [sub, ...rest] = ctx.args.slice(1)
  const catalog = getSeasonCatalog(season)
  if (sub?.toLowerCase() === 'buy') {
    if (!ctx.player) return ctx.reply(`⚠️ Register first with *${config.prefix}register*.`)
    const entry = findSeasonCatalogEntry(catalog, rest.join(' '))
    if (!entry) return ctx.reply(`❌ Unknown Season Shop item. Use *${config.prefix}season shop*.`)
    return buyShopEntry(ctx, season, entry)
  }

  const pages = getSeasonShopPages(catalog)
  const pageIndex = resolvePageIndex(pages, sub)
  const page = pages[pageIndex]

  const entryState = {}
  for (const entry of page.entries) entryState[entry.id] = shopEntryState(ctx.player, entry)

  const currencyLabel = season.currencyLabel ?? (season.id === 'season_02' ? 'Stars' : 'Season Points')
  const currencyEmoji = season.id === 'season_02' ? '⭐' : '✨'
  const lines = [
    `🛒 *SEASON SHOP* — page ${pageIndex + 1}/${pages.length}`,
    `${page.emoji} *${page.label}*`,
    `${currencyEmoji} Your ${currencyLabel}: *${ctx.player?.seasonPoints ?? 0}*`,
    ``,
  ]
  for (const entry of page.entries) {
    const info = describeSeasonEntry(entry)
    const state = entryState[entry.id]
    const tag = state.owned ? ' ✅' : state.soldOut ? ' ⛔' : state.left != null ? ` _(${state.left} left)_` : ''
    const shownPrice = state.discountPercent ? `${entry.price} → ${state.price} (${state.discountPercent}% off)` : `${entry.price}`
    lines.push(`${info.emoji} *${info.name}* — ${entry.currency === 'gems' ? '💎' : currencyEmoji}${shownPrice}${tag}`)
    lines.push(`   \`${entry.id}\``)
  }
  lines.push(
    ``,
    `📖 *${config.prefix}season info <name>* — full details + artwork`,
    `🛒 *${config.prefix}season shop buy <id>*`,
    `📄 *${config.prefix}season shop <1-${pages.length}>* — other shelves:`,
    pages.map((p, i) => `${i + 1}. ${p.emoji} ${p.label}`).join('\n'),
  )
  const caption = lines.join('\n')

  try {
    const buf = await renderSeasonShopPage({
      season, page, pageIndex, pageCount: pages.length,
      player: ctx.player, entryState, prefix: config.prefix,
    })
    return ctx.replyImage(buf, caption)
  } catch {
    return ctx.reply(caption)
  }
}

/**
 * `.season info <name>` — the full card for any catalog entry, of any reward
 * type. Falls back to a text sheet built from the same describeSeasonEntry()
 * data if the render throws, so the command never dead-ends on a canvas or
 * network problem.
 */
async function handleItemInfo(ctx) {
  const season = activeSeasonOrReply(ctx)
  if (!season) return
  const catalog = getSeasonCatalog(season)
  const query = ctx.args.slice(1).join(' ')
  const entry = findSeasonCatalogEntry(catalog, query)
  if (!entry) {
    return ctx.reply(
      `❌ No Season Shop entry matches *${query}*.\n` +
      `Browse the shelves with *${config.prefix}season shop*.`,
    )
  }

  const info = describeSeasonEntry(entry)
  const pages = getSeasonShopPages(catalog)
  const pageIndex = pages.findIndex((page) => page.entries.some((e) => e.id === entry.id))
  const page = pages[pageIndex] ?? null
  const state = shopEntryState(ctx.player, entry)

  const stats = Object.entries(info.stats ?? {}).filter(([, v]) => v != null && v !== 0)
  const lines = [
    `${info.emoji} *${info.name.toUpperCase()}*`,
    `_${info.kind}${info.rarity ? ` · ${info.rarity}` : ''}_`,
    `────────────────────`,
    info.description ? `${info.description}\n` : '',
    stats.length ? `📊 *Stats*\n${stats.map(([k, v]) => `• ${k}: ${v > 0 ? '+' : ''}${v}`).join('\n')}\n` : '',
    info.extra?.length ? `${info.extra.filter(Boolean).map((line) => `• ${line}`).join('\n')}\n` : '',
    entry.currency === 'gems'
      ? `💎 Price: *${entry.price}* Gems`
      : `${season.id === 'season_02' ? '⭐' : '✨'} Price: *${state.price ?? entry.price}* ${season.currencyLabel ?? (season.id === 'season_02' ? 'Stars' : 'Season Points')}${state.discountPercent ? ` _(coupon: ${state.discountPercent}% off ${entry.price})_` : ''}`,

    entry.purchaseLimit == null ? `🔁 Unlimited purchases` : `🎟️ Limit ${entry.purchaseLimit} per season${state.left != null ? ` · ${state.left} left for you` : ''}`,
    state.owned ? `✅ You already own this.` : `🛒 *${config.prefix}season shop buy ${entry.id}*`,
    page ? `📄 Found on shop page ${pageIndex + 1} — ${page.emoji} ${page.label}` : '',
  ].filter((line) => line !== '')
  const caption = lines.join('\n')

  // Deliberately NOT a composed render. Only the shop grid
  // (renderSeasonShopPage) draws cards; an item lookup should show the
  // entry's own artwork plainly, unobstructed by a frame, stat block or
  // price panel — all of which are already in the caption above. Entries
  // whose artwork is null (describeSeasonEntry returns a best-effort URL)
  // fall back to the text sheet alone.
  if (!info.image) return ctx.reply(caption)
  try {
    return await ctx.replyImage(info.image, caption)
  } catch {
    return ctx.reply(caption)
  }
}

async function buyShopEntry(ctx, season, entry) {
  const seasonRunNumber = getSeasonRuntime(ctx.db).runNumber
  // A live Pokémon needs its species data from PokéAPI, and updatePlayer's
  // mutator is synchronous (lib/player-repo.js's single-writer invariant), so
  // the fetch has to finish BEFORE the transaction opens. Doing it here also
  // means a PokéAPI outage refuses the sale instead of taking the points and
  // handing back nothing.
  let rawPokemon = null
  if (entry.rewardType === 'pokemon') {
    if (hasOwnedSeasonPokemon(ctx.player, entry.dexId)) {
      return ctx.reply(`✅ You already own *${entryName(entry)}*.`)
    }
    const quote = seasonShopPrice(ctx.player, entry)
    if ((ctx.player?.seasonPoints ?? 0) < quote.price) {
      const currencyLabel = season.currencyLabel ?? (season.id === 'season_02' ? 'Stars' : 'Season Points')
      const currencyEmoji = season.id === 'season_02' ? '⭐' : '✨'
      return ctx.reply(`❌ You need ${currencyEmoji}${quote.price} ${currencyLabel} for *${entryName(entry)}*. You have ${currencyEmoji}${ctx.player?.seasonPoints ?? 0}.`)
    }
    rawPokemon = await fetchPokemonById(entry.dexId ?? entry.id)
    if (!rawPokemon) {
      return ctx.reply(`⚠️ Couldn't reach the Pokémon archive just now — nothing was charged. Try again in a moment.`)
    }
  }

  let outcome = null
  await updatePlayer(ctx.db, ctx.from, (player) => {
    if (!isSeasonRunActive(ctx.db, season.id, seasonRunNumber)) {
      outcome = { reason: 'seasonClosed' }
      return
    }
    ensurePlayerSeasonState(player, season.id)
    player.seasonPurchases = player.seasonPurchases ?? {}
    const count = player.seasonPurchases[entry.id] ?? 0
    if (entry.purchaseLimit != null && count >= entry.purchaseLimit) {
      outcome = { reason: 'limit' }
      return
    }
    if (entry.rewardType === 'pokemon'
      ? hasOwnedSeasonPokemon(player, entry.dexId)
      : hasOwnedSeasonContent(player, entry.rewardType, entry.id) && entry.purchaseLimit === 1) {
      outcome = { reason: 'owned' }
      return
    }
    // A form skin needs its base character first, the same rule the gem .skin
    // shop keeps. Refuse before charging so nobody spends Stars on a form they
    // cannot equip yet.
    if (entry.rewardType === 'skin') {
      const sk = skinById(entry.id)
      if (!sk || !ownsBaseCharacter(player, sk.characterId)) {
        outcome = { reason: 'skinNeedsChar', characterId: sk?.characterId }
        return
      }
    }
    // Season 2: Klein Moretti is priced in Gems, not Stars. An entry with
    // currency:'gems' charges the gem wallet; every legacy entry (no currency)
    // still spends Season Points exactly as before.
    const useGems = entry.currency === 'gems'
    const coupon = useGems ? null : player.seasonProgress.shopCoupons.find((item) => Number(item?.uses) > 0)
    const couponPercent = Math.max(0, Math.min(100, Number(coupon?.percent) || 0))
    const price = Math.max(0, Math.ceil(Number(entry.price) * (100 - couponPercent) / 100))
    const points = useGems ? (player.wallet?.gems ?? 0) : (player.seasonPoints ?? 0)
    if (points < price) {
      outcome = { reason: useGems ? 'gems' : 'points', points, price }
      return
    }
    // Mega stones and held items land in the same player.inventory as gear
    // (plugins/pokeshop.js's convention), so they need a free slot too.
    const needsInventory = entry.rewardType === 'item' || entry.rewardType === 'weapon' || entry.rewardType === 'pokemonItem'
    if (needsInventory && !hasInventoryRoom(player, 1)) {
      outcome = { reason: 'full', player }
      return
    }
    // The 4-beast roster cap is enforced on acquisition, so refuse the sale
    // before charging rather than silently dropping the beast.
    if (entry.rewardType === 'beast' && (player.summonedBeasts ?? []).length >= BEAST_MAX_OWNED) {
      outcome = { reason: 'beastsFull' }
      return
    }
    if (useGems) {
      player.wallet = player.wallet ?? {}
      player.wallet.gems = roundGems(points - price)
    } else {
      player.seasonPoints = points - price
      if (couponPercent > 0) {
        coupon.uses = Math.max(0, Number(coupon.uses) - 1)
        player.seasonProgress.shopCoupons = player.seasonProgress.shopCoupons.filter((item) => Number(item?.uses) > 0)
      }
    }
    player.seasonPurchases[entry.id] = count + 1
    if (entry.rewardType === 'gems' || entry.rewardType === 'solars' || entry.rewardType === 'seasonPoints') {
      player.wallet = player.wallet ?? {}
      player.wallet[entry.rewardType] = (player.wallet[entry.rewardType] ?? 0) + (entry.amount ?? 0)
    } else if (entry.rewardType === 'character') {
      addOwnedSeasonContent(player, 'character', entry.id)
    } else if (entry.rewardType === 'title') {
      addOwnedSeasonContent(player, 'title', entry.itemId ?? entry.id.replace(/^title:/, ''))
    } else if (entry.rewardType === 'pokemon') {
      const owned = addSeasonPokemon(player, rawPokemon, { level: entry.level ?? 5 })
      outcome = { pokemon: owned }
    } else {
      addOwnedSeasonContent(player, entry.rewardType, entry.id)
    }
    // Season 2 scenario 9, Spend It: a completed season shop purchase.
    noteSeasonShopBuy(player, { db: ctx.db, starsSpent: useGems ? 0 : price })
    outcome = { ...(outcome ?? {}), reason: 'ok', remaining: useGems ? (player.wallet?.gems ?? 0) : player.seasonPoints, currency: useGems ? 'gems' : 'seasonPoints', price, basePrice: entry.price, couponPercent, amount: entry.amount }
  })

  if (outcome.reason === 'seasonClosed') return ctx.reply(SEASON_CHANGED)
  if (outcome.reason === 'limit' || outcome.reason === 'owned') {
    return ctx.reply(`✅ You already reached the purchase limit for *${entryName(entry)}*.`)
  }
  if (outcome.reason === 'skinNeedsChar') {
    const ch = characterMap[outcome.characterId]
    return ctx.reply(`❌ This form belongs to *${ch?.name ?? 'its character'}*. Recruit them first, then the form can be yours.`)
  }
  if (outcome.reason === 'points') {
    const currencyLabel = season.currencyLabel ?? (season.id === 'season_02' ? 'Stars' : 'Season Points')
    const currencyEmoji = season.id === 'season_02' ? '⭐' : '✨'
    return ctx.reply(`❌ You need ${currencyEmoji}${outcome.price ?? entry.price} ${currencyLabel} for *${entryName(entry)}*. You have ${currencyEmoji}${outcome.points}.`)
  }
  if (outcome.reason === 'gems') {
    return ctx.reply(`❌ You need 💎${outcome.price ?? entry.price} Gems for *${entryName(entry)}*. You have 💎${outcome.points}.`)
  }
  if (outcome.reason === 'beastsFull') {
    return ctx.reply(`❌ Your beast roster is full (${BEAST_MAX_OWNED}/${BEAST_MAX_OWNED}). Nothing was charged — release one with *${config.prefix}summon* first.`)
  }
  if (outcome.reason === 'full') return ctx.reply(`❌ ${inventoryFullMessage(outcome.player)}`)

  const mon = outcome.pokemon
  const spent = outcome.couponPercent
    ? `${outcome.basePrice} → ${outcome.price} (${outcome.couponPercent}% coupon)`
    : `${outcome.price}`
  const remainingLabel = outcome.currency === 'gems'
    ? `💎 Remaining Gems: *${outcome.remaining}*`
    : `${season.id === 'season_02' ? '⭐' : '✨'} Remaining ${season.currencyLabel ?? (season.id === 'season_02' ? 'Stars' : 'Season Points')}: *${outcome.remaining}*`
  return ctx.reply(
    `✅ *Season Shop purchase complete!*\n` +
    `${entryName(entry)} is now yours.\n` +
    `Paid: *${spent}*${outcome.currency === 'gems' ? ' Gems' : ` ${season.currencyLabel ?? (season.id === 'season_02' ? 'Stars' : 'Season Points')}`}\n` +
    (mon ? `🔱 Level ${mon.level} · ${mon.nature ?? 'rolled'} nature — see it with *${config.prefix}party dex*\n` : '') +
    remainingLabel,
  )
}

async function handlePass(ctx) {
  const season = activeSeasonOrReply(ctx)
  if (!season) return
  if (!ctx.player) return ctx.reply(`⚠️ Register first with *${config.prefix}register*.`)
  let player = ctx.player
  ensurePlayerSeasonState(player, season.id)
  const sub = (ctx.args[1] ?? 'status').toLowerCase()
  if (sub === 'claim') return claimPassRewards(ctx, season, ctx.args[2], ctx.args[3])
  if (sub === 'skip') return useSeasonTierSkip(ctx, season)

  const rewards = Array.from(
    { length: season.battlePass.tierCount },
    (_, i) => getSeasonReward(season.id, i + 1),
  ).filter(Boolean)
  const perPage = Math.max(5, Math.min(10, Math.floor(Number(season.battlePass.perPage ?? 10))))
  const pageCount = Math.max(1, Math.ceil(season.battlePass.tierCount / perPage))
  const savedPage = Number(player.seasonProgress.passPage) || Math.floor(Math.max(0, player.seasonProgress.battlePassTier - 1) / perPage) + 1
  let page = Math.min(pageCount, Math.max(1, savedPage))
  let savePage = false

  if (sub === 'next') {
    page = Math.min(pageCount, page + 1)
    savePage = true
  } else if (sub === 'prev' || sub === 'previous') {
    page = Math.max(1, page - 1)
    savePage = true
  } else if (sub === 'page') {
    const target = Number(ctx.args[2])
    if (!Number.isInteger(target) || target < 1) return ctx.reply(`Usage: *${config.prefix}season pass page <1-${pageCount}>*.`)
    page = Math.min(pageCount, target)
    savePage = true
  } else if (sub === 'arc') {
    const arc = Number(ctx.args[2])
    if (!Number.isInteger(arc) || arc < 1 || arc > 4) return ctx.reply(`Usage: *${config.prefix}season pass arc <1-4>*.`)
    page = Math.min(pageCount, Math.floor(((arc - 1) * 10) / perPage) + 1)
    savePage = true
  } else if (/^\d+$/.test(sub)) {
    const targetTier = Number(sub)
    if (targetTier < 1 || targetTier > season.battlePass.tierCount) {
      return ctx.reply(`Choose a tier from 1 to ${season.battlePass.tierCount}.`)
    }
    page = Math.floor((targetTier - 1) / perPage) + 1
    savePage = true
  } else if (!['status', ''].includes(sub)) {
    return ctx.reply(
      `Usage: *${config.prefix}season pass [status|next|prev|page <n>|arc <1-4>]*\n` +
      `Claim tracks separately with *${config.prefix}season pass claim free all* or *claim premium all*; ` +
      `spend a stored skip with *${config.prefix}season pass skip*.`,
    )
  }

  if (savePage) {
    const runNumber = getSeasonRuntime(ctx.db).runNumber
    let navigationClosed = false
    await updatePlayer(ctx.db, ctx.from, (current) => {
      if (!isSeasonRunActive(ctx.db, season.id, runNumber)) {
        navigationClosed = true
        return
      }
      ensurePlayerSeasonState(current, season.id)
      current.seasonProgress.passPage = page
    })
    if (navigationClosed) return ctx.reply(SEASON_CHANGED)
    player = getPlayer(ctx.db, ctx.from) ?? player
    ensurePlayerSeasonState(player, season.id)
  }

  const start = (page - 1) * perPage + 1
  const progress = player.seasonProgress
  const freeClaims = new Set(progress.claimedFreeTiers ?? progress.claimedTiers ?? [])
  const premiumClaims = new Set(progress.claimedPremiumTiers ?? [])
  const freeReady = rewards.filter((r) => r.tier <= progress.battlePassTier && !freeClaims.has(r.tier))
  const premiumReady = progress.premiumPass
    ? rewards.filter((r) => r.tier <= progress.battlePassTier && !premiumClaims.has(r.tier))
    : []
  const prog = seasonTierProgress(player, season)
  const arc = Math.min(4, Math.floor((start - 1) / 10) + 1)
  const arcName = season.battlePass.arcs?.[arc - 1] ?? `Arc ${arc}`
  const currencyLabel = season.currencyLabel ?? (season.id === 'season_02' ? 'Stars' : 'Season Points')
  const currencyEmoji = season.id === 'season_02' ? '⭐' : '✨'
  const skips = progress.tierSkips?.length ?? 0
  const lines = [
    `🎫 *BATTLE PASS* — ${season.name}`,
    `*Arc ${arc}: ${arcName}* · Page *${page}/${pageCount}* · Tiers *${start}-${Math.min(season.battlePass.tierCount, start + perPage - 1)}*`,
    `Progress: *Tier ${prog.tier}/${prog.tierCount}* _(${prog.pct}% into this tier)_ · *${prog.xp.toLocaleString()} Pass XP*`,
    `Next tier in *${prog.toNext.toLocaleString()} XP* · ${currencyEmoji} *${player.seasonPoints.toLocaleString()} ${currencyLabel}*`,
    `Free rewards ready: *${freeReady.length}* · Premium ready: *${progress.premiumPass ? premiumReady.length : 'locked'}*`,
    `Premium: *${progress.premiumPass ? 'Unlocked' : `Locked · ${season.battlePass.premiumCost} Gems`}* · Tier skips: *${skips}*${progress.constellationSponsor ? ' · Constellation Sponsor +10% XP' : ''}`,
    ``,
    `Claim: *${config.prefix}season pass claim free all* · *claim premium all* · or *claim <tier> free|premium*`,
    `Navigate: *${config.prefix}season pass prev/next* · *page <n>* · *arc <1-4>*`,
    `Open boxes: *${config.prefix}dokkaebi open* · select cosmetics with *${config.prefix}pickpfp <id> / ${config.prefix}pickbanner <id> / ${config.prefix}pickframe <id> / ${config.prefix}pickbadge <id>*.`,
  ]
  const caption = lines.join('\n')

  try {
    const buf = await renderSeasonPass({
      season, player, rewards, start, count: perPage, prefix: config.prefix,
    })
    return ctx.replyImage(buf, caption)
  } catch {
    const window = rewards.filter((r) => r.tier >= start && r.tier < start + perPage)
    const rows = window.map((reward) => {
      const freeStatus = freeClaims.has(reward.tier) ? '✅' : reward.tier <= progress.battlePassTier ? '🟡' : '🔒'
      const premiumStatus = !progress.premiumPass ? '🔒' : premiumClaims.has(reward.tier) ? '✅' : reward.tier <= progress.battlePassTier ? '🟡' : '🔒'
      return `*${reward.tier}.* F ${freeStatus} ${rewardLabel(reward.free, season)}\n    P ${premiumStatus} ${rewardLabel(reward.premium, season)}`
    })
    return ctx.reply(`${caption}\n\n${rows.join('\n')}`)
  }
}

async function useSeasonTierSkip(ctx, season) {
  const runNumber = getSeasonRuntime(ctx.db).runNumber
  let result = null
  await updatePlayer(ctx.db, ctx.from, (player) => {
    if (!isSeasonRunActive(ctx.db, season.id, runNumber)) {
      result = { ok: false, reason: 'seasonClosed' }
      return
    }
    ensurePlayerSeasonState(player, season.id)
    result = consumeSeasonTierSkip(player, season)
  })
  if (result?.reason === 'seasonClosed') return ctx.reply(SEASON_CHANGED)
  if (result?.reason === 'none') return ctx.reply(`You have no stored Premium tier skips. Earn one in an Arc, then use *${config.prefix}season pass skip*.`)
  if (result?.reason === 'maxed') return ctx.reply('Your Battle Pass is already at its final tier; a tier skip cannot be used.')
  return ctx.reply(`⏭️ Arc skip used. You advanced to *Tier ${result.tier}* without receiving its reward yet — claim it with *${config.prefix}season pass claim free ${result.tier}*${ctx.player?.seasonProgress?.premiumPass ? ` or *claim premium ${result.tier}*` : ''}.`)
}

async function claimPassRewards(ctx, season, rawTarget, rawTrack) {
  const seasonRunNumber = getSeasonRuntime(ctx.db).runNumber
  const targetToken = String(rawTarget ?? '').toLowerCase()
  const trackToken = String(rawTrack ?? '').toLowerCase()
  const trackNames = new Set(['free', 'premium', 'all', 'both'])
  let track = 'all'
  let target = 'all'
  if (trackNames.has(targetToken)) {
    track = targetToken === 'both' ? 'all' : targetToken
    target = trackToken || 'all'
  } else {
    target = targetToken || 'all'
    if (trackNames.has(trackToken)) track = trackToken === 'both' ? 'all' : trackToken
  }
  const requestedTier = target === 'all' ? null : Number(target)
  if (target !== 'all' && (!Number.isInteger(requestedTier) || requestedTier < 1)) {
    return ctx.reply(`Usage: *${config.prefix}season pass claim [free|premium|all] [tier|all]*.`)
  }

  let outcome = null
  await updatePlayer(ctx.db, ctx.from, (player) => {
    if (!isSeasonRunActive(ctx.db, season.id, seasonRunNumber)) {
      outcome = { reason: 'seasonClosed' }
      return
    }
    ensurePlayerSeasonState(player, season.id)
    const progress = player.seasonProgress
    if (track === 'premium' && !progress.premiumPass) {
      outcome = { reason: 'premiumLocked' }
      return
    }
    const tracks = track === 'all'
      ? (progress.premiumPass ? ['free', 'premium'] : ['free'])
      : [track]
    if (tracks.includes('premium') && !progress.premiumPass) {
      outcome = { reason: 'premiumLocked' }
      return
    }
    const tiers = requestedTier == null
      ? Array.from({ length: progress.battlePassTier }, (_, i) => i + 1)
      : [requestedTier]
    const freeClaims = new Set(progress.claimedFreeTiers ?? progress.claimedTiers ?? [])
    const premiumClaims = new Set(progress.claimedPremiumTiers ?? [])
    const grants = []
    const toClaim = []
    for (const tier of tiers) {
      if (tier < 1 || tier > progress.battlePassTier || tier > season.battlePass.tierCount) continue
      const tierReward = getSeasonReward(season.id, tier)
      if (!tierReward) continue
      if (tracks.includes('free') && !freeClaims.has(tier)) {
        grants.push({ tier, track: 'free', reward: tierReward.free })
        toClaim.push(tier)
      }
      if (tracks.includes('premium') && !premiumClaims.has(tier)) {
        grants.push({ tier, track: 'premium', reward: tierReward.premium })
        toClaim.push(tier)
      }
    }
    if (!grants.length) {
      outcome = { reason: 'none', tier: progress.battlePassTier }
      return
    }
    const inventoryNeed = grants.reduce((sum, grant) => {
      const type = grant.reward?.rewardType
      return sum + (['item', 'weapon', 'pokemonItem'].includes(type)
        ? Math.max(1, Math.floor(Number(grant.reward?.amount) || 1))
        : 0)
    }, 0)
    if (inventoryNeed && !hasInventoryRoom(player, inventoryNeed)) {
      outcome = { reason: 'full', player }
      return
    }

    const rewardLabels = []
    for (const grant of grants) {
      grantPassReward(player, season, grant.reward, grant.tier)
      rewardLabels.push(`${grant.track === 'free' ? 'Free' : 'Premium'}: ${rewardLabel(grant.reward, season)}`)
      if (grant.track === 'free') freeClaims.add(grant.tier)
      else premiumClaims.add(grant.tier)
    }
    progress.claimedFreeTiers = [...freeClaims].sort((a, b) => a - b)
    progress.claimedPremiumTiers = [...premiumClaims].sort((a, b) => a - b)
    progress.claimedTiers = [...new Set([...freeClaims, ...premiumClaims])].sort((a, b) => a - b)
    const lvl = applyLevelUps(player, levelsData, classes, races, getTotalStats)
    outcome = {
      reason: 'ok',
      tiers: [...new Set(toClaim)].sort((a, b) => a - b),
      rewards: rewardLabels,
      lvlMsgs: lvl.msgs,
    }
  })
  if (outcome.reason === 'seasonClosed') return ctx.reply(SEASON_CHANGED)
  if (outcome.reason === 'premiumLocked') {
    return ctx.reply(`🔒 Premium track is locked. Unlock it with *${config.prefix}season premium*; it will not auto-claim rewards.`)
  }
  if (outcome.reason === 'none') {
    return ctx.reply(`ℹ️ No unclaimed ${track === 'premium' ? 'Premium' : track === 'free' ? 'Free' : 'available'} Battle Pass rewards at or below Tier ${outcome.tier}.`)
  }
  if (outcome.reason === 'full') return ctx.reply(`❌ ${inventoryFullMessage(outcome.player)}\nMake room before claiming these rewards.`)
  return ctx.reply(
    `🎁 *Battle Pass rewards claimed!*\nTiers: *${outcome.tiers.join(', ')}*\n${outcome.rewards.map((r) => `• ${r}`).join('\n')}` +
    `\n\nProfile cosmetics are unlocked, not equipped. Use *${config.prefix}pickpfp <id>*, *${config.prefix}pickbanner <id>*, *${config.prefix}pickframe <id>*, or *${config.prefix}pickbadge <id>* to choose one.` +
    (outcome.lvlMsgs?.length ? `\n\n${outcome.lvlMsgs.join('\n')}` : ''),
  )
}

function grantPassReward(player, season, reward, tier = 0) {
  if (!reward) return
  const progress = player.seasonProgress
  if (reward.rewardType === 'bundle') {
    for (const child of reward.rewards ?? []) grantPassReward(player, season, child, tier)
    return
  }
  if (reward.rewardType === 'seasonPoints') {
    // Stars are spendable; granting them never creates Pass XP by itself.
    applySeasonPoints(player, season, reward.amount, { fromPass: true })
  } else if (reward.rewardType === 'passXp') {
    grantSeasonPassXp(player, season, reward.amount, { source: 'passReward' })
  } else if (reward.rewardType === 'solars' || reward.rewardType === 'gems' || reward.rewardType === 'xp') {
    player.wallet = player.wallet ?? {}
    if (reward.rewardType === 'xp') player.xp = (player.xp ?? 0) + reward.amount
    else player.wallet[reward.rewardType] = (player.wallet[reward.rewardType] ?? 0) + reward.amount
  } else if (reward.rewardType === 'tierSkip') {
    const arc = String(reward.itemId ?? `arc${Math.ceil(Math.max(1, tier) / 10)}`).toLowerCase()
    if (/^arc[1-4]$/.test(arc) && !progress.tierSkips.includes(arc)) progress.tierSkips.push(arc)
  } else if (reward.rewardType === 'constellationSponsor') {
    progress.constellationSponsor = true
  } else if (reward.rewardType === 'scenarioRerollToken') {
    progress.scenarioRerollTokens = (progress.scenarioRerollTokens ?? 0) + Math.max(1, Number(reward.amount) || 1)
  } else if (reward.rewardType === 'xpBooster') {
    const durationMs = Math.max(1, Number(reward.hours) || 24) * 60 * 60 * 1000
    progress.passXpBoostUntil = Math.max(Date.now(), Number(progress.passXpBoostUntil) || 0) + durationMs
  } else if (reward.rewardType === 'shopCoupon') {
    progress.shopCoupons.push({
      percent: Math.max(1, Math.min(100, Number(reward.percent) || 5)),
      uses: Math.max(1, Math.floor(Number(reward.uses) || 1)),
      earnedAt: Date.now(),
    })
  } else {
    addOwnedSeasonContent(player, reward.rewardType, reward.itemId, reward.amount)
  }
}

async function handlePremium(ctx) {
  const season = activeSeasonOrReply(ctx)
  if (!season) return
  if (!ctx.player) return ctx.reply(`⚠️ Register first with *${config.prefix}register*.`)
  const seasonRunNumber = getSeasonRuntime(ctx.db).runNumber
  let outcome = null
  await updatePlayer(ctx.db, ctx.from, (player) => {
    if (!isSeasonRunActive(ctx.db, season.id, seasonRunNumber)) {
      outcome = { reason: 'seasonClosed' }
      return
    }
    ensurePlayerSeasonState(player, season.id)
    if (player.seasonProgress.premiumPass) {
      outcome = { reason: 'owned' }
      return
    }
    const gems = player.wallet?.gems ?? 0
    if (gems < season.battlePass.premiumCost) {
      outcome = { reason: 'gems', gems }
      return
    }
    player.wallet.gems = roundGems(gems - season.battlePass.premiumCost)
    player.seasonProgress.premiumPass = true
    // Premium is an entitlement only. Even a late buyer must explicitly claim
    // each unclaimed Premium reward; a purchase never grants a tier reward.
    outcome = { reason: 'ok', remaining: player.wallet.gems }
  })
  if (outcome.reason === 'seasonClosed') return ctx.reply(SEASON_CHANGED)
  if (outcome.reason === 'owned') return ctx.reply(`✅ Your Premium Battle Pass is already unlocked.`)
  if (outcome.reason === 'gems') return ctx.reply(`❌ Premium costs 💎${season.battlePass.premiumCost}. You have 💎${fmtGems(outcome.gems)}.`)
  return ctx.reply(`✅ *Premium Battle Pass unlocked!*\n💎 Remaining Gems: *${fmtGems(outcome.remaining)}*\nNo rewards were auto-claimed. Claim every unclaimed Premium reward up to your current tier with *${config.prefix}season pass claim premium all*.`)
}


// A read-only overview. The quest board initializes periods, so work on a copy
// instead of mutating a live player outside the player repository's lane.
export function seasonHubText(db, player, { prefix = '.', now = Date.now() } = {}) {
  const copy = player ? structuredClone(player) : null
  const status = seasonStatus(db, copy, now)
  if (!status.active) return '🌙 No active season. Check again when the next season begins.'
  const season = status.season
  if (season.id !== 'season_02') return `📖 Season ${season.number}: ${season.name}\nUse *${prefix}season* for your progress.`
  const active = currentEvent(db, now)
  const next = nextEvent(db, now)
  const timing = active ? eventTiming(db, active, now) : null
  const lines = [
    `📖 *SEASON 2 HUB*`,
    `⏳ ${formatDuration(status.remainingMs)} remaining`,
    active ? `📣 ${timing?.state === 'live' ? 'Live event' : 'This week’s event (activity window ended)'}: *${active.name}*\n${active.premise}\n🎁 ${active.leaves}${timing?.state === 'live' ? `\n⏳ Activity window: ${formatDuration(timing.endsAt - now)} left.` : ''}\n⌁ ${eventActionText(active, prefix, { db, now })}`
      : next ? `📣 No event live now. Next: *${next.name}* in season week ${next.week}.`
        : '📣 No scheduled event is live or upcoming.',
  ]
  if (copy) {
    const prog = seasonTierProgress(copy, season)
    const nextXp = status.player.tier < status.player.tierCount
      ? Math.max(0, seasonXpForTier(season, status.player.tier + 1) - prog.xp) : null
    lines.push(`🎫 Pass: tier *${status.player.tier}/${status.player.tierCount}*${nextXp == null ? ' (complete)' : `, ${nextXp.toLocaleString()} Pass XP to next tier`}.`,
      `⭐ Stars: *${Number(status.player.points || 0).toLocaleString()}* (shop currency, separate from Pass XP).`)
    const board = getSeason02QuestBoard(copy, { runNumber: status.runtime.runNumber, now })
    const ready = [...board.main, ...board.daily, ...board.weekly, ...board.milestone, ...board.gate, ...board.hidden].filter(q => q.done && !q.claimed && !q.locked).length
    lines.push(`📜 Daily quests: ${board.daily.filter(q => q.done).length}/${board.daily.length} complete. ${ready} seasonal quest${ready === 1 ? '' : 's'} ready to claim.`)
  } else lines.push('Register to track your pass and quest progress.')
  lines.push('', `*${prefix}season event* for event actions and rewards`,
    `*${prefix}quest season* and *${prefix}quest season claim* for objectives and rewards`,
    `*${prefix}scenario status* for your personal scenario`,
    `*${prefix}rush* for short encounters and catch-up rewards`,
    `*${prefix}season pass* for tier rewards and *${prefix}season shop* to spend Stars`,
    `*${prefix}seasonpvp* for optional equal-stat seasonal duels`,
    `*${prefix}guild scenario* for the shared weekly objective`,
    `*${prefix}guild clash* for your guild's current matchup`)
  return lines.join('\n')
}

async function handleSeasonHub(ctx) {
  return ctx.reply(seasonHubText(ctx.db, ctx.player, { prefix: config.prefix }))
}
