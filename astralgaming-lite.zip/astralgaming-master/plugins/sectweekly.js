/**
 * sectweekly.js — `.weekly` : the week's goals.
 *
 * Four goals, dealt every Monday 00:00 WAT, the same four for every cultivator
 * (lib/sect-weekly.js). `.weekly` shows them and how far along you are;
 * `.weekly claim` pays whatever is finished, and the chest when all four are
 * (lib/sect-weekly-pay.js). They are a sect's goals: the rewards are
 * contribution and stones scaled by rank, so they are posted for members.
 */
import { config } from '../config.js'
import { settlePendingSectHook } from '../lib/sect-commands.js'
import { sectDoorRefusal } from '../lib/world-guards.js'
import { memberSect } from '../lib/sect-sects.js'
import { withGrowthLock } from '../lib/sect-progress.js'
import { BUSY } from '../lib/sect-fight.js'
import { claimWeekly, weeklyLines } from '../lib/sect-weekly-pay.js'
import { updatePlayer, getPlayer } from '../lib/player-repo.js'

export default {
  name: 'weekly',
  aliases: ['week', 'goals'],
  category: 'sect',
  requiresPlayer: true,
  description: `${config.prefix}weekly — this week's four goals and how far along you are; ${config.prefix}weekly claim takes what is finished`,
  subcommands: [
    { cmd: 'claim', desc: 'take the reward for every finished goal, and the chest when all four are done' },
  ],
  async run(ctx) {
    const p = config.prefix
    const wrongWorld = sectDoorRefusal(ctx.player, {
      emoji: '🗓️', title: '*The week\'s goals are posted in the Sect Empire.*',
      here: { cmd: 'quests', label: 'Astra keeps its own' },
    })
    if (wrongWorld) return ctx.reply(wrongWorld)
    const pending = await settlePendingSectHook(ctx)
    if (pending) return ctx.reply(pending.join('\n'))

    if (!memberSect(ctx.player?.sect)) {
      return ctx.reply([
        '🗓️ *THE WEEK\'S GOALS*',
        '_They are posted in a sect\'s Mission Hall, and paid in that sect\'s contribution. A cultivator with no sect has no board to read._',
        `🏛️ *${p}sect* — see the sects, and what each one asks of you.`,
      ].join('\n'))
    }

    const word = String(ctx.args?.[0] ?? '').trim().toLowerCase()
    const now = Date.now()
    if (['claim', 'collect', 'take'].includes(word)) {
      let out = null
      const ran = await withGrowthLock(ctx.from, async () => {
        await updatePlayer(ctx.db, ctx.from, fresh => {
          out = claimWeekly(fresh, { now, prefix: p })
          return fresh
        })
      })
      if (!ran) return ctx.reply(BUSY)
      if (!out?.ok) {
        return ctx.reply([
          '🗓️ *Nothing is finished yet.*',
          '',
          ...weeklyLines(getPlayer(ctx.db, ctx.from) ?? ctx.player, { now, prefix: p }).slice(3),
        ].join('\n'))
      }
      const fresh = getPlayer(ctx.db, ctx.from) ?? ctx.player
      return ctx.reply([
        '🎉 *CLAIMED*',
        ...out.lines,
        '',
        `💠 *Contribution:* ${Math.max(0, Math.round(Number(fresh?.sect?.contribution) || 0))}  ·  💎 *Spirit Stones:* ${Math.max(0, Math.round(Number(fresh?.sect?.spiritStones) || 0))}`,
      ].join('\n'))
    }

    return ctx.reply(weeklyLines(ctx.player, { now, prefix: p }).join('\n'))
  },
}
