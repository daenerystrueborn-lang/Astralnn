import { noteCombatVictory } from '../lib/ultra-instinct.js'
import { updatePlayer } from '../lib/player-repo.js'
import { config } from '../config.js'
import { getActiveSeason, getSeasonRuntime } from '../lib/season-engine.js'
import { updateWorldState } from '../lib/player-repo.js'
import { resolveTargetJid } from '../lib/transfer-guards.js'
import { extractTarget } from '../lib/group-helpers.js'
import { resolvePlayerId } from '../lib/identity-resolver.js'
import { pushNotification } from '../lib/notification-repo.js'
import { seasonDuelAction, DUEL_HP } from '../lib/season-duel.js'

function targetFor(ctx, raw) {
  if (raw && ctx.db.data.users?.[raw]) return raw
  const picked = extractTarget(ctx)
  if (picked) return picked
  const query = String(raw ?? '').replace(/^@/, '').toLowerCase()
  const named = Object.entries(ctx.db.data.users ?? {}).filter(([, p]) => String(p?.name ?? '').toLowerCase() === query)
  if (query && named.length === 1) return named[0][0]
  return ctx.platform && ctx.platform !== 'whatsapp' ? null : resolveTargetJid(ctx, raw)
}
function describe(db, result, actor, prefix) {
  if (result.error) return `❌ ${result.error}`
  if (result.rows) return ['🏆 *SEASON FAIR-PLAY LADDER*',
    ...(result.rows.length ? result.rows.map((r, i) => `${i + 1}. ${r.name}: ${r.rating} (${r.wins}W ${r.losses}L ${r.draws}D)`) : ['No ranked matches yet.']),
    '_Only the first completed match against the same opponent each WAT day affects the ladder._'].join('\n')
  const lines = ['⚔️ *SEASON FAIR-PLAY ARENA*']
  if (result.message) lines.push(result.message)
  if (result.game) {
    const g = result.game
    const name = id => db.data.users?.[id]?.name ?? id
    if (g.status === 'pending') lines.push(`Invitation: ${name(g.a)} vs ${name(g.b)}.`, `*${prefix}seasonpvp accept* · *${prefix}seasonpvp decline* · *${prefix}seasonpvp cancel*`)
    else lines.push(`${name(g.a)}: ${g.hp[g.a]}/${DUEL_HP} HP · ${name(g.b)}: ${g.hp[g.b]}/${DUEL_HP} HP`,
      `${name(g.a)}: ${g.focus[g.a] ? 'focused' : 'no focus'}, ${g.guard[g.a] ? 'guarding' : 'unguarded'} · ${name(g.b)}: ${g.focus[g.b] ? 'focused' : 'no focus'}, ${g.guard[g.b] ? 'guarding' : 'unguarded'}`,
      `Turn: *${name(g.turn)}* · ${g.moves}/40 moves`,
      `*${prefix}seasonpvp strike* · *${prefix}seasonpvp guard* · *${prefix}seasonpvp read*`,
      '_Strike deals 2 damage, or 4 after Read. Guard blocks 2 damage from the next strike._')
  } else if (result.rating) lines.push(`Your rating: ${result.rating.rating} · ${result.rating.wins}W ${result.rating.losses}L ${result.rating.draws}D`,
    `*${prefix}seasonpvp challenge @player* to invite someone.`)
  if (result.result) lines.push(result.result.winner ? `Winner: *${db.data.users?.[result.result.winner]?.name ?? result.result.winner}*.` : 'Draw.',
    result.result.ranked ? 'This result counted on the seasonal ladder.' : 'Exhibition result: this pair already played a ranked match today.')
  lines.push(`_Both players use identical arena stats. No inventory, real HP, Solars or ordinary PvP rating is changed. First match against an opponent each WAT day is ranked._`,
    `*${prefix}seasonpvp top* · *${prefix}seasonpvp forfeit* · *${prefix}seasonpvp claim* after 24 hours of the opponent's inactivity.`)
  return lines.join('\n')
}

export default {
  name: 'seasonpvp', category: 'season', requiresPlayer: true,
  description: 'Optional equal-stat Season 2 duel ladder',
  subcommands: [
    { cmd: 'challenge @player', desc: 'invite a player to a fair-play match' },
    { cmd: 'accept / decline / cancel', desc: 'answer or cancel an invitation' },
    { cmd: 'strike / guard / read', desc: 'take your turn in a match' },
    { cmd: 'forfeit / claim', desc: 'concede or claim after an opponent is idle for 24 hours' },
    { cmd: 'top', desc: 'show the seasonal fair-play ladder' },
  ],
  async run(ctx) {
    const season = getActiveSeason(ctx.db)
    if (season?.id !== 'season_02') return ctx.reply('🌙 The fair-play arena is available only during Season 2.')
    const action = String(ctx.args[0] ?? 'status').toLowerCase()
    const runNumber = getSeasonRuntime(ctx.db).runNumber
    const targetId = action === 'challenge' ? targetFor(ctx, ctx.args[1]) : null
    const actor = resolvePlayerId(ctx.db, ctx.from)
    const result = await updateWorldState(ctx.db, 'season-duel', () =>
      seasonDuelAction(ctx.db, actor, action, { targetId, runNumber }))
    if (result.result?.winner) {
      await updatePlayer(ctx.db, result.result.winner, player => { noteCombatVictory(player); return player })
    }
    const recipient = result.target ?? result.notify
    if (recipient) await pushNotification(ctx.db, recipient, {
      kind: 'battle', title: result.target ? 'Season fair-play challenge' : 'Season fair-play update',
      body: result.target
        ? `${ctx.player?.name ?? 'A player'} challenged you. Send ${config.prefix}seasonpvp accept within 30 minutes.`
        : `${result.message} Send ${config.prefix}seasonpvp to check the match.`,
    })
    return ctx.reply(describe(ctx.db, result, actor, config.prefix))
  },
}
