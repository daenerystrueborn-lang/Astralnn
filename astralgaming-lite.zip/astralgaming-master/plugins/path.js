/**
 * path — the Sect Empire's answer to the kingdom's class choice.
 *
 * Usage:
 *   .path                 the five cultivation paths (while deciding) or yours
 *   .path <id|name>       walk one of the ways: martial_monk, sword_saint,
 *                         spirit_scholar, jade_apothecary, hollow_fiend
 *
 * Disciples born on the mountain arrive path-pending (see lib/faction-choice.js)
 * and cannot start a fight, hunt or secret realm until they choose. Road
 * crossers from the Astra Kingdom carry no such flag; they may stay unclassed
 * or opt into a path here, once. The choice itself is one-shot — the mountain
 * does not let a cultivator change what they are.
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { sectDoorRefusal, missingSectRecordRefusal } from '../lib/world-guards.js'
import { rebuildSectStats } from '../lib/sect-cultivation.js'
import { refillPools } from '../lib/sect-progress.js'
import {
  SECT_CLASSES, commitClass, isClassPending, profileClass,
  classChoiceCard, classStatusLine, classKitLines,
} from '../lib/sect-class.js'
import { nextOrientationStep } from '../lib/sect-orientation.js'
import { sendButtons, interactiveSupported } from '../lib/interactive-buttons.js'


export default {
  name: 'path',
  aliases: ['sectclass', 'daolu', 'cultivationpath'],
  category: 'sect',
  requiresPlayer: true,
  description: 'Choose your Sect Empire cultivation path (monk, sword, scholar, apothecary, fiend)',

  async run(ctx) {
    const p = config.prefix
    const wrongWorld = sectDoorRefusal(ctx.player, {
      emoji: '🧭', title: '*The five cultivation paths belong to the Sect Empire.*',
    })
    if (wrongWorld) return ctx.reply(wrongWorld)

    const word = (ctx.args?.[0] ?? '').toLowerCase().trim()

    // ── Read-only: the card while deciding, the standing afterwards ─────────
    if (!word) {
      let text = ''
      let pending = false
      await updatePlayer(ctx.db, ctx.from, (player) => {
        pending = isClassPending(player.sect)
        if (pending) {
          text = classChoiceCard(p)
        } else {
          const cls = profileClass(player.sect)
          text = [
            classStatusLine(player.sect),
            '',
            ...(cls ? classKitLines(cls) : ['_You walk no school; the mountain lets wanderers stay wanderers._']),
            '',
            `_A path is chosen once and kept. The five ways remain on view with_ *${p}help*_._`,
          ].join('\n')
        }
        return player
      })
      if (!pending) return ctx.reply(text)
      // whatsmeow renders no card: `classChoiceCard()`'s text already names every
      // path and its id, so that is what goes out (lib/interactive-buttons.js).
      if (!interactiveSupported(ctx.sock)) return ctx.reply(text)
      try {
        return await sendButtons({ ...ctx, jid: ctx.sender }, {
          body: text,
          footer: 'Tap a path, or type the command yourself.',
          buttons: SECT_CLASSES.map((c) => ({ id: `${p}path ${c.id}`, label: `${c.emoji} ${c.name}` })),
        })
      } catch {
        return ctx.reply(text)
      }
    }

    // ── Commit ──────────────────────────────────────────────────────────────
    let outcome = null
    await updatePlayer(ctx.db, ctx.from, (player) => {
      if (!player.sect) { outcome = { ok: false, reason: 'noRecord' }; return player }
      outcome = commitClass(player.sect, word, { now: Date.now() })
      if (outcome.ok) {
        // Fold the path's multipliers into the ladder maxima now, then top the
        // pools up to them so the disciple immediately feels the difference.
        rebuildSectStats(player.sect)
        refillPools(player.sect, Date.now())
      }
      return player
    })

    if (outcome.reason === 'noRecord') return ctx.reply(missingSectRecordRefusal())
    if (outcome.reason === 'chosen') {
      return ctx.reply(`🧭 A cultivator cannot walk two ways.\n\n${classStatusLine(ctx.player.sect)}`)
    }
    if (outcome.reason === 'unknown' || !outcome.ok) {
      return ctx.reply(
        `❓ That is not one of the five paths.\n\n` +
        SECT_CLASSES.map((c) => `${c.emoji} *${c.name}* — \`${p}path ${c.id}\``).join('\n'),
      )
    }

    const cls = outcome.cls
    let nextStep = null
    await updatePlayer(ctx.db, ctx.from, (player) => {
      nextStep = nextOrientationStep(player, p)
      return player
    })
    const lines = [
      `${cls.emoji} *The mountain accepts you, ${ctx.player.name}: ${cls.name}* _(${cls.nameZh})_`,
      '',
      `_${cls.description}_`,
      '',
      `*Passive — ${cls.passive.kind}:* ${passiveLine(cls)}`,
      ...classKitLines(cls),
      '',
      `_Sect affinity: your path naturally leads to the_ *${cls.sectId}* _school when you are ready to join (${p}sect join)._`,
      `_Your stat maxima have been rebuilt around this path and your pools are full._`,
      '',
      '🧭 *WHAT NOW*',
      nextStep ? `1. *${nextStep.command}* — ${nextStep.hint}` : `1. *${p}todo* — the day board holds your next moves.`,
      nextStep ? `2. *${p}todo* — today's board: every clock, counter and rung, live.` : null,
      nextStep ? `3. *${p}help* — every word this world answers.` : `2. *${p}help* — every word this world answers.`,
    ].filter(Boolean)
    return ctx.reply(lines.join('\n'))
  },
}

function passiveLine(cls) {
  const p = cls.passive
  switch (p.kind) {
    case 'ironBody': return `takes ${Math.round((1 - p.damageTakenMult) * 100)}% less damage from every hit`
    case 'flawlessEdge': return `+${Math.round(p.critBonus * 100)}% critical chance in every fight`
    case 'deepWell': return `techniques cost ${Math.round((1 - p.qiCostMult) * 100)}% less Qi`
    case 'secondWind': return `HP and Qi regenerate ${p.regenMult}× faster while resting`
    case 'bloodQi': return `heals ${Math.round(p.lifesteal * 100)}% of every hit's damage as HP`
    default: return ''
  }
}
