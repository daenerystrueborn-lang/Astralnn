// <prefix>killer - Han Sooyoung's Killer of Kings. Once per battle, only below
// 25% HP. A 2.0x strike that ignores defence. docs/season-02-characters/han-sooyoung.md
import { config } from '../config.js'
import { activateKiller } from '../lib/regressor-characters.js'
import { runRegressorCommand } from '../lib/regressor-command-runner.js'

export default {
  name: 'killer',
  aliases: ['killerofkings'],
  category: 'combat',
  description: `${config.prefix}killer - Han Sooyoung's Killer of Kings. Below 25% HP, once per battle, defence ignored.`,
  requiresPlayer: true,
  async run(ctx) { return runRegressorCommand(ctx, activateKiller) },
}
