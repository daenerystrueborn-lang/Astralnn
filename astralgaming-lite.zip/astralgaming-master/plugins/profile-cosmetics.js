import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import {
  ensureProfileCosmetics,
  hasProfileCosmetic,
  profileCosmeticDefinition,
  profileCosmeticList,
  profileCosmeticVariants,
  selectProfileCosmetic,
} from '../lib/profile-cosmetics.js'

const COMMANDS = {
  pfp: { name: 'pickpfp', kind: 'profilePfp', selected: 'profilePfpId', label: 'profile picture', selectKind: 'pfp', reset: 'default' },
  banner: { name: 'pickbanner', kind: 'profileBanner', selected: 'profileBannerId', label: 'banner', selectKind: 'banner', reset: 'default' },
  frame: { name: 'pickframe', kind: 'profileFrame', selected: 'profileFrameId', label: 'Fluid Frame', selectKind: 'frame', reset: 'off' },
  effect: { name: 'pickeffect', kind: 'profileEffect', selected: 'profileEffectId', label: 'GIF effect', selectKind: 'effect', reset: 'off' },
  badge: { name: 'pickbadge', kind: 'profileBadge', selected: 'profileBadgeId', label: 'badge', selectKind: 'badge', reset: 'off' },
}

function currentLabel(player, command) {
  const id = player?.[command.selected]
  if (!id) return command.reset === 'default' ? 'Default' : 'Off'
  return profileCosmeticDefinition(command.kind, id)?.name ?? (id === 'default' ? 'Default' : id)
}

function findOwned(player, command, query) {
  const q = String(query ?? '').trim().toLowerCase()
  if (!q) return null
  const entries = ownedSearchSpace(command)
  return entries.find((entry) => entry.id.toLowerCase() === q)
    ?? entries.find((entry) => entry.name.toLowerCase() === q)
    ?? entries.find((entry) => entry.name.toLowerCase().includes(q))
    ?? null
}

/**
 * Every definition for this kind, pass stock first.
 *
 * profileCosmeticList() is the pass's own table on purpose (the pass render and
 * the free-cosmetic box pool iterate it, and shop stock must never leak into
 * those). Lookups, though, have to resolve ANY id a player can own — including
 * the PFP & Banner Store's League portraits, which .pickpfp must be able to
 * find after they are bought.
 */
function ownedSearchSpace(command) {
  const variants = profileCosmeticVariants(command.kind)
  const passList = profileCosmeticList(command.kind)
  return variants.length ? variants : passList
}

function ownedLines(player, command, prefix) {
  const bucketKey = command.kind === 'profilePfp' ? 'pfps'
    : command.kind === 'profileBanner' ? 'banners'
      : command.kind === 'profileFrame' ? 'frames'
        : command.kind === 'profileEffect' ? 'effects'
          : 'badges'
  const ids = ensureProfileCosmetics(player)[bucketKey]
  if (!ids.length) return ['_None unlocked yet._']
  return ids.map((id) => {
    const item = profileCosmeticDefinition(command.kind, id)
    const selected = player?.[command.selected] === id
    return `${selected ? '✅' : '▫️'} *${item?.name ?? id}*\n   ID: \`${id}\` · _${prefix}${command.name} ${id}_`
  })
}

export async function selectProfileCosmeticCommand(ctx, type) {
  const command = COMMANDS[type]
  const raw = ctx.args.join(' ').trim()
  const value = raw.toLowerCase()
  if (!value || value === 'list') return showOwnedProfileCosmetics(ctx)

  const resetValues = command.selectKind === 'pfp' || command.selectKind === 'banner'
    ? ['default', 'reset', 'none']
    : ['off', 'none', 'default']
  if (resetValues.includes(value)) {
    await updatePlayer(ctx.db, ctx.from, (player) => {
      selectProfileCosmetic(player, command.selectKind, command.reset)
    })
    return ctx.reply(`✅ ${command.label} set to ${command.reset === 'default' ? 'the Season 2 default' : 'off'}.`)
  }

  let definition = findOwned(ctx.player, command, raw)
  if (!definition) {
    const all = ownedSearchSpace(command)
    definition = all.find((entry) => entry.id.toLowerCase() === value) ?? null
    if (definition && !hasProfileCosmetic(ctx.player, command.kind, definition.id)) {
      return ctx.reply(`🔒 *${definition.name}* is not unlocked on your account. Open *${config.prefix}cosmetics* to see what you own.`)
    }
  }
  if (!definition || !hasProfileCosmetic(ctx.player, command.kind, definition.id)) {
    return ctx.reply(`❌ You don't own a ${command.label} matching *${raw}*. Use *${config.prefix}cosmetics* to see your unlocked options.`)
  }

  let outcome = null
  await updatePlayer(ctx.db, ctx.from, (player) => {
    outcome = selectProfileCosmetic(player, command.selectKind, definition.id)
  })
  if (!outcome?.ok) return ctx.reply(`❌ That ${command.label} could not be selected.`)
  return ctx.reply(`✅ *${definition.name}* selected as your ${command.label}. Check it with *${config.prefix}me*.`)
}

export async function showOwnedProfileCosmetics(ctx) {
  const player = ctx.player
  const prefix = config.prefix
  const groups = [
    ['Profile pictures', COMMANDS.pfp],
    ['Banners', COMMANDS.banner],
    ['Fluid Frames', COMMANDS.frame],
    ['GIF Effects', COMMANDS.effect],
    ['Badges', COMMANDS.badge],
  ]
  const lines = ['「 ✦ PROFILE COSMETICS 」', 'New pass and shop cosmetics are unlocked, not auto-equipped.', '']
  for (const [label, command] of groups) {
    lines.push(`*${label}* · Current: _${currentLabel(player, command)}_`)
    lines.push(...ownedLines(player, command, prefix))
    lines.push('')
  }
  lines.push(
    `⌁ _${prefix}pickpfp <id|default>_ · _${prefix}pickbanner <id|default>_`,
    `⌁ _${prefix}pickframe <id|off>_ · _${prefix}pickeffect <id|off>_ · _${prefix}pickbadge <id|off>_`,
    `💎 _${prefix}store_ — buy PFPs, banners, Fluid Frames & GIF effects`,
  )
  return ctx.reply(lines.join('\n'))
}

export default {
  name: 'cosmetics',
  aliases: ['profilecosmetics', 'mycosmetics'],
  category: 'account',
  requiresPlayer: true,
  description: 'List unlocked profile pictures, banners, Fluid Frames and badges',
  async run(ctx) { return showOwnedProfileCosmetics(ctx) },
}
