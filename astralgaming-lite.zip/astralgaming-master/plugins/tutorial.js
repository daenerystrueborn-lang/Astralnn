/**
 * tutorial — guided onboarding for new players.
 *
 * Usage:
 *   .tutorial          — view your current step and progress
 *   .tutorial skip     — skip the tutorial entirely
 *   .tutorial reset    — (owner) reset your tutorial to step 1
 *   .tutorial step <n> — view a specific step
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import {
  ensureTutorial,
  syncTutorialProgress,
  tutorialNotice,
  tutorialProgress,
  formatTutorialStatus,
  skipTutorial,
  resetTutorial,
  rewardLabel,
  GRADUATION_REWARD,
  TUTORIAL_STEPS,
} from '../lib/tutorial-engine.js'

export default {
  name: 'tutorial',
  aliases: ['tut', 'onboard'],
  category: 'town',
  requiresPlayer: true,
  description: 'View or manage your guided tutorial',
  subcommands: [
    { cmd: '', desc: 'view your current tutorial step and progress' },
    { cmd: 'skip', desc: 'skip the tutorial entirely' },
    { cmd: 'step <n>', desc: 'view details of a specific step' },
  ],

  async run(ctx) {
    const p = config.prefix
    const sub = (ctx.args[0] ?? '').toLowerCase().trim()

    // ── .tutorial skip ──────────────────────────────────────────────────
    if (sub === 'skip') {
      let result = null
      await updatePlayer(ctx.db, ctx.from, player => {
        const tut = ensureTutorial(player)
        if (tut.graduated) {
          result = { status: 'already_done' }
          return player
        }
        skipTutorial(player)
        result = { status: 'skipped' }
        return player
      })

      if (result.status === 'already_done') {
        return ctx.reply('🎓 You\'ve already completed the tutorial!')
      }
      return ctx.reply(
        `📖 *Tutorial Skipped*\n\n` +
        `You chose to skip the guided tutorial.\n` +
        `⚠️ The graduation gift _(${rewardLabel(GRADUATION_REWARD)})_ is only for players who finish — it's forfeited.\n\n` +
        `_Use ${p}help or ${p}allcmds to explore all 200+ commands._\n\n` +
        `_Stuck? Type ${p}tutorial to restart._`,
      )
    }

    // ── .tutorial reset (owner only) ────────────────────────────────────
    if (sub === 'reset') {
      const { isOwnerJid } = await import('../lib/group-helpers.js')
      if (!isOwnerJid(ctx.sender)) {
        return ctx.reply('🔒 Only the bot owner can reset tutorials.')
      }
      await updatePlayer(ctx.db, ctx.from, player => {
        resetTutorial(player)
        return player
      })
      return ctx.reply('🔄 Tutorial reset to step 1.')
    }

    // ── .tutorial step <n> ──────────────────────────────────────────────
    if (sub === 'step') {
      const n = parseInt(ctx.args[1], 10)
      if (!n || n < 1 || n > TUTORIAL_STEPS.length) {
        return ctx.reply(
          `Usage: *${p}tutorial step <1-${TUTORIAL_STEPS.length}>*\n` +
          `_View details of a specific tutorial step._`,
        )
      }
      const step = TUTORIAL_STEPS[n - 1]
      const lines = [
        `📖 *Step ${n}/${TUTORIAL_STEPS.length}: ${step.title}*`,
        ``,
        step.instruction,
        ``,
        `_💡 ${step.hint}_`,
      ]
      if (step.reward) {
        const parts = []
        if (step.reward.solars) parts.push(`☀️ ${step.reward.solars} Solars`)
        if (step.reward.xp) parts.push(`✨ ${step.reward.xp} XP`)
        if (step.reward.gems) parts.push(`💎 ${step.reward.gems} Gems`)
        if (parts.length) lines.push(``, `🎁 Reward: ${parts.join(', ')}`)
      }
      return ctx.reply(lines.join('\n'))
    }

    // ── .tutorial (default — show status) ───────────────────────────────
    // Conditional by design: sync against the player's record FIRST, so any
    // step their own state already proves done (a claimed daily, a weapon
    // equipped, a dungeon entered...) ticks over — reward and all — before
    // the card renders. Nobody is ever told to do something they already did.
    let statusText = ''
    let syncResult = null
    await updatePlayer(ctx.db, ctx.from, player => {
      ensureTutorial(player)
      syncResult = syncTutorialProgress(player)
      statusText = formatTutorialStatus(player, p)
      return player
    })
    const notice = tutorialNotice(syncResult, p)
    return ctx.reply(notice ? `${notice}\n\n${statusText}` : statusText)
  },
}
