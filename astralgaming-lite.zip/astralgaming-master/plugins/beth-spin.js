/**
 * <prefix>beth-spin [count] — Exclusive Character Spin for Beth (3★ Support).
 *
 *   - 5,000 Solars per spin (up to 20 per command, 270 lifetime cap)
 *   - Spins 1–256 are a dead zone (0% win chance)
 *   - Spins 257–270 carry the plateau win rate (PLATEAU_CHANCE = 0.80, PITY_AT = 9999)
 *   - One-of-one bot-wide (EXCLUSIVE = true)
 *   - Never prints dead-zone numbers, win chances, or thresholds in player-facing text.
 */
import { config } from '../config.js'
import { characterStars } from '../lib/rarity.js'
import { updatePlayer, getPlayer } from '../lib/player-repo.js'
import { characterMap } from '../lib/game-data.js'
import { sendImage } from '../lib/image.js'
import {
  chanceForExclusiveSpin,
  getExclusiveSpinWinner,
  claimExclusiveSpinForPlayer,
} from '../lib/season-engine.js'
import { spinLockGate } from '../lib/spin-locks.js'

export const CHARACTER_ID = 'beth'
export const COST_PER_SPIN = 5_000
export const DEAD_ZONE_UNTIL = 256
export const PLATEAU_CHANCE = 0.80
export const PITY_AT = 9999
export const MAX_SPINS_PER_PLAYER = 270
export const MAX_SPINS_PER_COMMAND = 20
export const EXCLUSIVE = true

const fmtSolars = n => (Number(n) || 0).toLocaleString()

function parseCount(arg) {
  const n = Math.floor(Number(arg) || 1)
  return Math.min(MAX_SPINS_PER_COMMAND, Math.max(1, n))
}

function renderReel(results) {
  const cells = results.map(r => (r.won ? '🪡' : '▫️'))
  const rows = []
  for (let i = 0; i < cells.length; i += 5) {
    rows.push('  ' + cells.slice(i, i + 5).join(' '))
  }
  return rows.join('\n')
}

function progressBar(current, total, width = 12) {
  const filled = Math.min(width, Math.round((current / total) * width))
  return '█'.repeat(filled) + '░'.repeat(width - filled)
}

export default {
  name: 'beth-spin',
  aliases: ['bethspin', 'bspin'],
  category: 'shop',
  requiresPlayer: true,
  description: `${config.prefix}beth-spin [count] — Spin for Beth (${COST_PER_SPIN.toLocaleString()} Solars/spin)`,

  async run(ctx) {
    if (spinLockGate(ctx, CHARACTER_ID)) return
    const p = config.prefix
    const { args } = ctx
    const character = characterMap[CHARACTER_ID]
    if (!character) return ctx.reply('❌ Exclusive character not found in game data.')

    const sub = (args[0] ?? '').toLowerCase()
    const currentWinner = EXCLUSIVE ? getExclusiveSpinWinner(ctx.db, CHARACTER_ID) : null
    const winnerPlayer = currentWinner ? getPlayer(ctx.db, currentWinner) : null

    if (sub === 'info' || sub === 'status' || sub === 'help') {
      const done = ctx.player.bethSpins ?? 0
      const left = Math.max(0, MAX_SPINS_PER_PLAYER - done)
      const owned = (ctx.player.ownedCharacters ?? []).includes(CHARACTER_ID)
      const statusLine = owned
        ? `✅ *You own ${character.name}!* Equip with *${p}character equip ${CHARACTER_ID}*.`
        : currentWinner
          ? `🔒 *Already claimed* by *${winnerPlayer?.name ?? 'another player'}*.`
          : left === 0
            ? `🚫 *All ${MAX_SPINS_PER_PLAYER} of your spins are used.*`
            : `🎯 Your spins: *${done}/${MAX_SPINS_PER_PLAYER}* _(${left} remaining)_`
      const caption =
        `🪡 *Exclusive Character Spin — ${character.name}*\n` +
        `${characterStars(character.stars)}  ·  _${character.ability.name}_\n` +
        `_${character.description}_\n\n` +
        `✨ *Ability:* _${character.ability.flavor}_\n\n` +
        `☀️ *Cost:* ${fmtSolars(COST_PER_SPIN)} Solars / spin _(up to ${MAX_SPINS_PER_COMMAND} at once)_\n` +
        `🔒 *Exclusivity:* One-of-one across the entire bot\n` +
        `📊 ${progressBar(done, MAX_SPINS_PER_PLAYER)} ${done}/${MAX_SPINS_PER_PLAYER}\n\n` +
        `${statusLine}\n\n` +
        `_Spin: *${p}beth-spin* or *${p}beth-spin <1-${MAX_SPINS_PER_COMMAND}>*_`
      return sendImage(ctx, character.image, caption)
    }

    if (EXCLUSIVE && currentWinner) {
      if (currentWinner === ctx.from) {
        return ctx.reply(
          `✅ You already hold *${character.name}*!\n` +
          `_Equip her with *${p}character equip ${CHARACTER_ID}*._`,
        )
      }
      return ctx.reply(
        `🔒 *${character.name}* has already been claimed by *${winnerPlayer?.name ?? 'another player'}*.\n` +
        `_Only one copy of this character exists across the entire bot._`,
      )
    }

    const count = parseCount(args[0])
    let outcome = null

    await updatePlayer(ctx.db, ctx.from, player => {
      player.ownedCharacters = player.ownedCharacters ?? []
      player.wallet = player.wallet ?? {}

      if (EXCLUSIVE) {
        const winner = getExclusiveSpinWinner(ctx.db, CHARACTER_ID)
        if (winner) {
          outcome = { reason: winner === ctx.from ? 'owned' : 'claimed', winnerJid: winner }
          return
        }
      }
      if (player.ownedCharacters.includes(CHARACTER_ID)) {
        outcome = { reason: 'owned' }
        return
      }

      let solars = Math.floor(player.wallet.solars ?? 0)
      const results = []
      let won = false
      let spinsUsed = 0

      for (let i = 0; i < count; i++) {
        if (EXCLUSIVE && getExclusiveSpinWinner(ctx.db, CHARACTER_ID)) break
        if (solars < COST_PER_SPIN) break
        if ((player.bethSpins ?? 0) >= MAX_SPINS_PER_PLAYER) break

        const nextSpin = (player.bethSpins ?? 0) + 1
        const chance = chanceForExclusiveSpin(nextSpin, {
          deadZoneUntil: DEAD_ZONE_UNTIL,
          plateauChance: PLATEAU_CHANCE,
          pityAt: PITY_AT,
        })
        const rolledWin = nextSpin >= PITY_AT || Math.random() < chance

        solars -= COST_PER_SPIN
        player.wallet.solars = solars
        player.bethSpins = nextSpin
        spinsUsed++

        if (!rolledWin) {
          results.push({ spin: nextSpin, won: false })
          continue
        }

        const claimed = !EXCLUSIVE || claimExclusiveSpinForPlayer(ctx.db, CHARACTER_ID, ctx.from)
        results.push({ spin: nextSpin, won: claimed })
        if (claimed) {
          if (!player.ownedCharacters.includes(CHARACTER_ID)) {
            player.ownedCharacters.push(CHARACTER_ID)
          }
          won = true
        }
        break
      }

      if (!results.length) {
        const cappedOut = (player.bethSpins ?? 0) >= MAX_SPINS_PER_PLAYER
        outcome = { reason: cappedOut ? 'exhausted_lifetime' : 'solars', solars }
        return
      }

      outcome = {
        reason: won ? 'won' : 'exhausted',
        results,
        spinsUsed,
        remaining: player.wallet.solars ?? 0,
        totalSpins: player.bethSpins ?? 0,
      }
    })

    if (outcome.reason === 'owned') {
      return ctx.reply(
        `✅ You already own *${character.name}*!\n` +
        `_Equip her with *${p}character equip ${CHARACTER_ID}*._`,
      )
    }
    if (outcome.reason === 'claimed') {
      const holder = outcome.winnerJid ? getPlayer(ctx.db, outcome.winnerJid) : null
      return ctx.reply(
        `🔒 *${character.name}* was already claimed by *${holder?.name ?? 'another player'}*!\n` +
        `_No Solars were spent._`,
      )
    }
    if (outcome.reason === 'exhausted_lifetime') {
      return ctx.reply(
        `🚫 *You have used all ${MAX_SPINS_PER_PLAYER} of your spins on ${character.name}.*\n` +
        `_Your lifetime spin cap for this banner has been reached. No Solars were spent._`,
      )
    }
    if (outcome.reason === 'solars') {
      return ctx.reply(
        `❌ Not enough Solars! One spin costs *☀️ ${fmtSolars(COST_PER_SPIN)} Solars* ` +
        `(you have *☀️ ${fmtSolars(outcome.solars)}*).\n` +
        `_Earn Solars in dungeons, quests, and daily activities._`,
      )
    }

    const { results, spinsUsed, remaining, totalSpins } = outcome
    const totalPaid = spinsUsed * COST_PER_SPIN
    const reel = renderReel(results)
    const left = Math.max(0, MAX_SPINS_PER_PLAYER - totalSpins)

    if (outcome.reason === 'won') {
      const winSpin = results[results.length - 1].spin
      const caption =
        `🪡✨ *MEND & REINFORCE — YOU PULLED ${character.name.toUpperCase()}!* ✨🪡\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `${reel}\n` +
        `━━━━━━━━━━━━━━━━━━━━\n` +
        `${character.emoji} *${character.name}* ${characterStars(character.stars)}\n` +
        `✨ *Ability: ${character.ability.name}*\n` +
        `_${character.ability.flavor}_\n\n` +
        `🎯 Won on spin *#${winSpin}* _(${spinsUsed} spun · -☀️ ${fmtSolars(totalPaid)} Solars)_\n` +
        `☀️ Solars left: *${fmtSolars(remaining)}*\n` +
        `🔒 *She is now locked to you across the entire bot.*\n\n` +
        `▶ Equip her now: *${p}character equip ${CHARACTER_ID}*`
      return sendImage(ctx, character.image, caption)
    }

    const cappedNow = left === 0
    return ctx.reply(
      `🪡 *${character.name} Spin* — ${spinsUsed} spin${spinsUsed === 1 ? '' : 's'} (-☀️ ${fmtSolars(totalPaid)} Solars)\n` +
      `${reel}\n\n` +
      `💭 _Not this time. Her needle keeps its rhythm._\n` +
      `📊 Progress: ${progressBar(totalSpins, MAX_SPINS_PER_PLAYER)} *${totalSpins}/${MAX_SPINS_PER_PLAYER}* ` +
      `_(${left} spin${left === 1 ? '' : 's'} left)_\n` +
      `☀️ Solars left: *${fmtSolars(remaining)}*\n\n` +
      (cappedNow
        ? `🚫 _You have used all ${MAX_SPINS_PER_PLAYER} of your spins on this banner._`
        : `_Spin again: *${p}beth-spin* or *${p}beth-spin <count>*_`),
    )
  },
}
