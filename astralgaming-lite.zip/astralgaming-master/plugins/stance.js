/**
 * stance — pick a battle risk posture (C4).
 * Usage:
 *   .stance                 — view current stance and options
 *   .stance aggro|balanced|guard
 * Balanced is the default and changes nothing; the other two shift outgoing
 * and incoming damage by small, visible amounts.
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { setStance, formatStance, STANCES } from '../lib/battle-stances.js'

export default {
  name: 'stance',
  aliases: ['posture'],
  category: 'combat',
  requiresPlayer: true,
  description: 'Set your battle stance: aggro, balanced, or guard',

  async run(ctx) {
    const p = config.prefix
    const choice = (ctx.args?.[0] ?? '').toLowerCase().trim()
    if (!choice) {
      let text = ''
      await updatePlayer(ctx.db, ctx.from, (player) => { text = formatStance(player, p); return player })
      return ctx.reply(text)
    }
    let result
    await updatePlayer(ctx.db, ctx.from, (player) => {
      result = setStance(player, choice)
      return player
    })
    if (!result.ok) {
      return ctx.reply(`❌ Unknown stance. Pick: ${Object.keys(STANCES).join(', ')}`)
    }
    return ctx.reply(`${result.stance.emoji} Stance set to *${result.stance.label}* — ${result.stance.desc}`)
  },
}
