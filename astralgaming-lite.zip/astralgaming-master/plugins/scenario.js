/**
 * scenario — the Season 2 Personal Scenario window (Phases C, D and E).
 *
 *   .scenario             list your Personal Scenario (alias of status)
 *   .scenario list        same
 *   .scenario status      same, with live progress
 *   .scenario accept [n]  accept, optionally wagering n Stars on the clear
 *   .scenario confirm     the second press a reset scenario needs
 *   .scenario decline     decline silently, before accepting, for free
 *   .scenario retry       spend a Regression Token to retry a failed scenario
 *
 * The static ladder (tiers 1-7) lives on .quest; this command is the dynamic
 * Personal layer of docs/season-02-scenarios.md §15. A scenario is issued from
 * the player's two strongest play traits, accepted before it counts, and only an
 * accepted one can fail. The generator, lifecycle, §12 punishment, §14 wagers and
 * Regression Tokens live in lib/scenario-personal.js; the audience and sponsorship
 * live in lib/scenario-viewers.js. This plugin only mutates through updatePlayer
 * and renders.
 *
 * The window is drawn as an ORV plate (lib/orv-window-render.mjs), the same frame
 * as the death report. The plate draws no emoji; the words on it are plain. A
 * failed render never costs the message: the text window goes out instead. Copy
 * follows docs/season-02-style.md.
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { getActiveSeason, getSeasonRuntime, isSeasonRunActive, ensurePlayerSeasonState, grantSeasonPassXp } from '../lib/season-engine.js'
import { payReward } from '../lib/quest-engine.js'
import { settlePlayerXp } from '../lib/player-xp.js'
import {
  generatePersonalScenario, evaluatePersonalScenario, acceptPersonalScenario,
  confirmPersonalScenario, declinePersonalScenario, timeLeftMs,
  wagerRange, retryWithToken, regressionState,
} from '../lib/scenario-personal.js'
import {
  settleViewers, settleSponsorship, viewerCount, drainPendingGifts,
} from '../lib/scenario-viewers.js'

function fmtLeft(ms) {
  if (ms <= 0) return '0h'
  const totalMin = Math.floor(ms / 60000)
  const d = Math.floor(totalMin / 1440)
  const h = Math.floor((totalMin % 1440) / 60)
  const m = totalMin % 60
  if (d > 0) return `${d}d ${String(h).padStart(2, '0')}h`
  if (h > 0) return `${h}h ${String(m).padStart(2, '0')}m`
  return `${m}m`
}

function rewardLine(sc) {
  const lines = [`🏆 *${sc.stars} ⭐*`]
  if (sc.failPenalty > 0) lines.push(`⚠️ *-${sc.failPenalty} ⭐* if it breaks`)
  if (sc.reset) lines.push(`🔁 *${sc.reset} clear resets*`)
  return lines
}

/** The failed-window punishment lines, shared by text and plate. */
function failedOutcome(sc, punishment) {
  const pu = punishment ?? sc.punishment
  if (!pu || pu.none) return { lines: [], forgiven: false }
  if (pu.forgiven) return { lines: [`_Penalty waived._`], forgiven: true }
  const lines = []
  if (pu.starsLost > 0) lines.push(`⚠️ *-${pu.starsLost} ⭐*${pu.wager ? ' stake' : ''}`)
  if (pu.reset) lines.push(`🔁 *${pu.reset.kind} clear resets*`)
  return { lines, forgiven: false }
}

/** Sponsorship flavour lines, shown once when a gift lands (§13). */
function giftLines(gifts) {
  return (gifts ?? []).map(g => `🎁 *+${g.stars} ⭐* · _${g.line}${g.title ? ` · 🎖️ ${g.title}` : ''}_`)
}

/** The compact text window. The fallback when a plate cannot be drawn. */
function renderWindow(sc, now, punishment, extra = {}) {
  const p = config.prefix
  const viewers = extra.viewers ?? 0
  const gifts = giftLines(extra.gifts)
  const lead = gifts.length ? gifts.join('\n') + '\n\n' : ''
  if (!sc) {
    return (
      lead +
      `「 📡 PERSONAL SCENARIO 」\n\n` +
      `_No scenario is watching you yet._\n\n` +
      `Play the tower. Once a week the System reads your habits and issues one\n` +
      `scenario aimed at your weakest. Accept it before it counts.\n\n` +
      `👁️ *${viewers}* constellations watching\n\n` +
      `⌁ _${p}quest_ for the main ladder`
    )
  }
  if (sc.status === 'cleared') {
    return (
      lead +
      `「 ✅ SCENARIO CLEARED 」\n*${sc.name}*\n\n` +
      `🏆 *+${sc.stars} ⭐*${sc.wager ? ` · 🎲 stake back + bonus` : ''}\n` +
      (extra.passXp ? `✨ *+${extra.passXp.earned} Pass XP* _(includes Clear Condition bonus)_\n` : '') +
      (sc.waivedPenalty > 0 ? `🎫 *+${sc.waivedPenalty} ⭐* penalty waived\n` : '') +
      `\n_❝ A constellation is pleased with you. ❞_`
    )
  }
  if (sc.status === 'failed') {
    const { lines } = failedOutcome(sc, punishment)
    const tok = extra.tokens
    const retry = tok?.retryable
      ? `\n\n🎫 *${tok.tokens}* token${tok.tokens === 1 ? '' : 's'} · ⌁ _${p}scenario retry_ within 24h`
      : ''
    return (
      lead +
      `「 ✖ SCENARIO FAILED 」\n*${sc.name}*\n\n` +
      (lines.length ? lines.join('\n') + '\n\n' : '') +
      `_❝ A constellation has looked away. ❞_` + retry
    )
  }
  if (sc.status === 'expired' || sc.status === 'declined') {
    return (
      lead +
      `「 📡 PERSONAL SCENARIO 」\n\n` +
      `_The last scenario passed quietly. A new one arrives with the week._\n\n` +
      `👁️ *${viewers}* constellations watching\n\n` +
      `⌁ _${p}quest_ for the main ladder`
    )
  }
  if (sc.status === 'pending') {
    return (
      `「 ⚠ CONFIRM RESET 」\n*${sc.name}*\n\n` +
      `🔁 *${sc.reset} clear resets*\n` +
      (sc.pendingStake > 0 ? `🎲 *${sc.pendingStake} ⭐* staked on confirm\n` : '') +
      `_Progress, titles and every other floor stay._\n\n` +
      `⌁ _${p}scenario confirm_ · _${p}scenario decline_`
    )
  }
  // issued / accepted
  const accepted = sc.status === 'accepted'
  const lines = [
    `「 ⚠ PERSONAL SCENARIO 」`,
    `_${accepted ? 'Accepted' : 'Issued'}_`,
    ``,
    `*${sc.name}*`,
    `_${sc.desc}_`,
    ``,
    `⏳ *${fmtLeft(timeLeftMs(sc, now))}*${accepted ? ' left' : ''}`,
  ]
  if (accepted) lines.push(`📊 *${sc.progress ?? 0}/${sc.goal}*`)
  lines.push(...rewardLine(sc))
  if (accepted && sc.wager) lines.push(`🎲 *${sc.wager.stake} ⭐* staked`)
  if (!accepted && extra.wager) lines.push(`🎲 Wager *${extra.wager.min} to ${extra.wager.max} ⭐* · _${p}scenario accept <stars>_`)
  lines.push(`👁️ *${viewers}* constellations watching`)
  lines.push(``)
  lines.push(accepted ? `⌁ _${p}scenario status_` : `⌁ _${p}scenario accept_ · _${p}scenario decline_`)
  return lead + lines.join('\n')
}

/**
 * The ORV plate shape for a scenario, or null when the moment is better served
 * by plain text. The plate draws no emoji, so its rows say "Stars" in words; the
 * caption keeps the symbols.
 */
function buildPlate(sc, now, punishment, currentFloor = 0, extra = {}) {
  if (!sc) return null
  const rows = []
  let header, node, command, stampLine, caption, desc = sc.desc
  const viewers = extra.viewers ?? 0
  if (sc.status === 'cleared') {
    header = '[ SCENARIO CLEARED ]'
    rows.push(['Reward', `+${sc.stars} Stars`])
    if (extra.passXp) rows.push(['Pass XP', `+${extra.passXp.earned} (includes Clear Condition)`])
    if (sc.waivedPenalty > 0) rows.push(['Penalty waived', `+${sc.waivedPenalty} Stars`])
    node = 'A constellation is pleased with you.'
    caption = `✅ Scenario cleared · ${sc.name}`
  } else if (sc.status === 'failed') {
    header = '[ SCENARIO FAILED ]'
    const pu = punishment ?? sc.punishment
    if (pu && !pu.none && !pu.forgiven) {
      if (pu.starsLost > 0) rows.push([pu.wager ? 'Stake lost' : 'Stars lost', `-${pu.starsLost} Stars`])
      if (pu.reset) rows.push(['Reset', `${pu.reset.kind} clear`])
    } else if (pu?.forgiven) {
      rows.push(['Penalty', 'forgiven'])
    }
    if (extra.tokens?.retryable) {
      rows.push(['Regression', `${extra.tokens.tokens} token · retry 24h`])
      command = `${config.prefix}scenario retry`
    }
    node = 'A constellation has looked away.'
    caption = `✖ Scenario failed · ${sc.name}`
  } else if (sc.status === 'pending') {
    header = '[ CONFIRM RESET ]'
    desc = 'A reset takes back an attempt, never a record.'
    if (currentFloor > 0) rows.push(['Floor', currentFloor])
    rows.push(['Reset', `${sc.reset} clear`])
    if (sc.pendingStake > 0) rows.push(['Stake', `${sc.pendingStake} Stars`])
    stampLine = `[ RESET: ${String(sc.reset).toUpperCase()} CLEAR ]`
    node = 'Progress, titles and every other floor stay.'
    command = `${config.prefix}scenario confirm`
    caption = `⚠ Confirm reset · ${sc.name}`
  } else if (sc.status === 'issued' || sc.status === 'accepted') {
    const accepted = sc.status === 'accepted'
    header = '[ PERSONAL SCENARIO ]'
    rows.push([accepted ? 'Time left' : 'Time', fmtLeft(timeLeftMs(sc, now))])
    if (accepted) rows.push(['Progress', `${sc.progress ?? 0} / ${sc.goal}`])
    rows.push(['Reward', `${sc.stars} Stars`])
    if (sc.failPenalty > 0) rows.push(['Penalty', `-${sc.failPenalty} Stars`])
    if (accepted && sc.wager) rows.push(['Stake', `${sc.wager.stake} Stars`])
    if (!accepted && extra.wager) rows.push(['Wager', `${extra.wager.min} to ${extra.wager.max} Stars`])
    rows.push(['Viewers', `${viewers} constellations`])
    if (sc.reset) stampLine = `[ RESET: ${String(sc.reset).toUpperCase()} CLEAR ]`
    node = accepted ? 'The clock is running.' : 'The dokkaebi is watching.'
    command = accepted ? `${config.prefix}scenario status` : `${config.prefix}scenario accept`
    caption = `⚠ Personal Scenario · ${sc.name}`
  } else {
    return null
  }
  return { plate: { name: sc.name, desc, rows, header, node, command, stampLine }, caption }
}

/** Draw the plate if the host can; a failed render never costs the message. */
async function sendWindow(ctx, text, plateInfo) {
  if (plateInfo && typeof ctx.replyImage === 'function') {
    try {
      const { renderScenarioWindow } = await import('../lib/orv-window-render.mjs')
      const buf = await renderScenarioWindow(plateInfo.plate)
      await ctx.replyImage(buf, plateInfo.caption)
      return
    } catch {
      // No canvas on this host, or a font failed. The text still says it all.
    }
  }
  await ctx.reply(text)
}

export default {
  name: 'scenario',
  aliases: ['scenarios'],
  category: 'season',
  requiresPlayer: true,
  description: `${config.prefix}scenario [list|accept|confirm|decline|status|retry] · your weekly Personal Scenario`,
  subcommands: [
    { cmd: 'list', desc: 'show your Personal Scenario' },
    { cmd: 'status', desc: 'show it with live progress' },
    { cmd: 'accept', desc: 'accept, optionally wagering Stars on the clear' },
    { cmd: 'confirm', desc: 'the second press a reset scenario needs' },
    { cmd: 'decline', desc: 'decline before accepting, silently and free' },
    { cmd: 'retry', desc: 'spend a Regression Token to retry a failed scenario' },
  ],

  async run(ctx) {
    const sub = (ctx.args[0] ?? 'list').toLowerCase()
    const stake = Math.max(0, parseInt(ctx.args[1], 10) || 0)
    const now = Date.now()
    const activeSeason = getActiveSeason(ctx.db)
    const activeSeasonRun = activeSeason ? getSeasonRuntime(ctx.db).runNumber : null
    const p = config.prefix

    if (!['list', 'status', 'accept', 'confirm', 'decline', 'retry'].includes(sub)) {
      return ctx.reply(
        `「 📡 PERSONAL SCENARIO 」\n\n` +
        `⌁ _${p}scenario list_ · _${p}scenario status_\n` +
        `⌁ _${p}scenario accept [stars]_ · _${p}scenario confirm_\n` +
        `⌁ _${p}scenario decline_ · _${p}scenario retry_`,
      )
    }

    let result = null
    await updatePlayer(ctx.db, ctx.from, player => {
      if (sub === 'accept') {
        result = { kind: 'accept', ...acceptPersonalScenario(player, null, now, stake), currentFloor: Number(player.dungeonFloor) || 0 }
        return player
      }
      if (sub === 'confirm') {
        result = { kind: 'confirm', ...confirmPersonalScenario(player, null, now, stake) }
        return player
      }
      if (sub === 'decline') {
        result = { kind: 'decline', ...declinePersonalScenario(player, null) }
        return player
      }
      if (sub === 'retry') {
        result = { kind: 'retry', ...retryWithToken(player, now) }
        return player
      }
      // list / status: issue this week's if due, settle the audience, evaluate,
      // pay a clear and enforce a failure's punishment exactly once.
      if (activeSeason) generatePersonalScenario(player, now)
      settleViewers(player, now)
      const { scenario, reward, punishment } = evaluatePersonalScenario(player, now)
      let paid = null
      let passXp = null
      if (reward) {
        paid = payReward(player, reward)
        settlePlayerXp(player)
        if (activeSeason?.id === 'season_02' && isSeasonRunActive(ctx.db, activeSeason.id, activeSeasonRun)) {
          ensurePlayerSeasonState(player, activeSeason.id)
          const baseXp = Number(activeSeason.battlePass?.weeklyScenarioXp ?? 350)
          const clearConditionBonus = Number(activeSeason.battlePass?.weeklyClearConditionBonusXp ?? 100)
          passXp = grantSeasonPassXp(player, activeSeason, baseXp + clearConditionBonus, { source: 'weeklyPersonalScenarioClear' })
        }
      }
      settleSponsorship(player, now)
      const gifts = drainPendingGifts(player)
      result = {
        kind: 'view', scenario, paid, passXp, punishment, gifts,
        viewers: viewerCount(player), tokens: regressionState(player, now),
        wager: scenario && scenario.status === 'issued' ? wagerRange(player, scenario) : null,
      }
      return player
    })

    if (result.kind === 'view') {
      const sc = result.scenario
      const extra = { viewers: result.viewers, gifts: result.gifts, tokens: result.tokens, wager: result.wager, passXp: result.passXp }
      return sendWindow(ctx, renderWindow(sc, now, result.punishment, extra), buildPlate(sc, now, result.punishment, 0, extra))
    }

    if (result.kind === 'decline') {
      if (!result.ok) return ctx.reply(`_Nothing to decline._`)
      return ctx.reply(`_Declined. The System notes it and looks away._`)
    }

    if (result.kind === 'retry') {
      if (!result.ok) {
        if (result.reason === 'noToken') return ctx.reply(`_No Regression Token to spend._`)
        if (result.reason === 'noFailure') return ctx.reply(`_Nothing to retry._`)
        if (result.reason === 'expired') return ctx.reply(`_The retry window has closed._`)
        return ctx.reply(`_Cannot retry._`)
      }
      return sendWindow(ctx, `_The token is spent. The scenario returns._\n\n` + renderWindow(result.scenario, now), buildPlate(result.scenario, now))
    }

    if (result.kind === 'accept' || result.kind === 'confirm') {
      if (!result.ok) {
        if (result.reason === 'none') return ctx.reply(`_No scenario is waiting. Open _${p}scenario list_._`)
        if (result.reason === 'already') {
          return sendWindow(ctx, renderWindow(result.scenario, now), buildPlate(result.scenario, now))
        }
        if (result.reason === 'expired') return ctx.reply(`_That scenario already expired._`)
        if (result.reason === 'notPending') return ctx.reply(`_Nothing needs confirming._`)
        if (result.reason === 'noWager') return ctx.reply(`_No wager is offered on this scenario._`)
        if (result.reason === 'stakeRange') return ctx.reply(`_The stake must be between *${result.range.min}* and *${result.range.max} ⭐*._`)
        return ctx.reply(`_That scenario is closed._`)
      }
      if (result.status === 'pending') {
        const text = renderWindow(result.scenario, now)
        return sendWindow(ctx, text, buildPlate(result.scenario, now, null, result.currentFloor))
      }
      return sendWindow(ctx, renderWindow(result.scenario, now), buildPlate(result.scenario, now))
    }

    return ctx.reply(renderWindow(null, now))
  },
}
