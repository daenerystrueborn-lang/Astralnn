/**
 * herrscher.js — the Celestriel Retriever's active, and the first move a PET
 * has ever had in this bot.
 *
 * `<prefix>herrscher`. 2500 damage that DEF does not touch, plus three
 * statuses at once, once per battle. It needs the dog, and nothing else: no
 * equip slot, no level gate beyond the pet's own, no sword.
 *
 * Why a command and not a passive: the owner's spec is a reveal. The dog is
 * the disguise and the reveal is the whole trick, which is why the art is a
 * different image from the pet's card (lib/image.js's 'celestriel-herrscher'
 * is the true form; 'spin-pet' is the golden retriever). A passive would fire
 * inside someone else's turn with no room to show it. So the player points at
 * the dog and says the word.
 *
 * The three statuses are the lore names wearing real mechanics — Void-Torn is
 * `shred_res` 30% for 3 turns, Held is a 1-turn `stun`, Unseen is 2 turns of
 * `blind`. They go through lib/effects.js's addStatusEffect, so a target that
 * refuses hostile statuses (Shunya's empty vessel, Yu Miaoyi's keeper) refuses
 * these too, and the fight says so instead of pretending.
 *
 * Duels: refused before anything is charged, for the same reason Excalibur
 * is — the duel engine has its own turn loop and no handler for a pet's
 * once-per-battle active yet.
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import {
  armHerrscher, runSignatureTurn, isBossFight, applyMoveStatuses,
  HERRSCHE_R_DAMAGE, HERRSCHE_R_STATUSES, HERRSCHE_R_ART, HERRSCHE_R_NAME,
  CELESTRIEL_ID,
} from '../lib/starfall-kits.js'

export default {
  name: 'herrscher',
  aliases: ['goldenvessel', 'celestriel'],
  category: 'combat',
  requiresPlayer: true,
  description: `${config.prefix}herrscher — Celestriel Retriever's once-per-battle true form (2500, DEF does not apply)`,

  async run(ctx) {
    if (ctx.player?.battleState?.type === 'pvp') {
      return ctx.reply(
        `⚠️ *The Golden Vessel* is not available in duels yet.\n` +
        `_The dog waits for a fight it can see all the way through. Dungeons and boss battles only, for now._`,
      )
    }

    await updatePlayer(ctx.db, ctx.from, async player => {
      const gate = armHerrscher(player)
      if (!gate.ok) {
        if (gate.message) await ctx.reply(gate.message)
        return player
      }

      const move = {
        name: HERRSCHE_R_NAME,
        damage: HERRSCHE_R_DAMAGE,
        openings: [
          `🐕🦺 *Celestriel Retriever* sits. It has been sitting the whole fight, the way a good dog does — and then it stops pretending.`,
          `_The air above it cracks along a line that was always there. Something enormous looks out through the dog's eyes, and the dog is not surprised at all._`,
          `*HERRSCHE R OF THE VOID.*`,
        ],
        landedLine: e => `Void pours through *${e.name}* — not fire, not force, just the absence of anything that could have stopped it.`,
        missLine: e => `💨 The tear opens a stride to the side of *${e.name}* — *MISSED!*\n_The dog is only a dog again, and it does not offer twice._`,
        afterHit: (e) => {
          const { lines } = applyMoveStatuses(e, HERRSCHE_R_STATUSES, { sourceId: CELESTRIEL_ID })
          const out = [`🕳️ *${e.name}* is left **Void-Torn** — its armour is not where it was.`]
          out.push(`⛓️ *Held* — it cannot answer this turn.`)
          out.push(`🌫️ *Unseen* — you are nowhere it can find.`)
          return out.concat(lines)
        },
      }

      return runSignatureTurn({
        player, ctx, move, boss: isBossFight(player), art: HERRSCHE_R_ART,
      })
    })
  },
}
