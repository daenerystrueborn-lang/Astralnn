/**
 * me.js — .me
 * The player's compact PvP card. The rendered card is intentionally built
 * from PvP-only performance data and the selected profile banner; a selected
 * Fluid Frame is the only reason this command sends animation.
 */
import { config } from '../config.js'
import { getActiveSeason } from '../lib/season-engine.js'
import { equippedProfileEffect, equippedProfileFrame, profileImageUrl, selectedProfileImage } from '../lib/profile-cosmetics.js'
import { renderAnimatedProfileCard, renderProfileCard } from '../lib/profile-card-render.mjs'
import { duelsPlayed, rankFor, ratingOf, streakLabel, winRate } from '../lib/pvp-engine.js'
import { getGuildTag } from '../lib/guild-repo.js'
import { isInSectEmpire } from '../lib/worlds.js'
import { sectCultivatorCard } from '../lib/sect-profile.js'
import { formatAffinityBadgeLine } from '../lib/affinity-engine.js'

export default {
  name: 'me',
  aliases: [],
  category: 'account',
  requiresPlayer: true,
  description: 'View your PvP record and profile banner',

  async run(ctx) {
    // The Sect Empire keeps its own profile, separate from the Astral PvP card.
    if (isInSectEmpire(ctx.player)) return ctx.reply(sectCultivatorCard(ctx.player))

    const player = ctx.player
    const pvp = player.pvp ?? {}
    const played = duelsPlayed(player)
    const wins = Math.max(0, Number(pvp.wins) || 0)
    const losses = Math.max(0, Number(pvp.losses) || 0)
    const rating = ratingOf(player)
    const band = rankFor(player)
    const bestStreak = Math.max(0, Number(pvp.bestStreak) || 0)
    const guildTag = getGuildTag(player)
    const displayName = guildTag ? `${guildTag} ${player.name}` : player.name
    const pvpStatus = played < 5 ? `Provisional · ${5 - played} placement duels to go` : 'Placed'
    const affBadge = formatAffinityBadgeLine(player)?.replace(/\*/g, '')
    const shortText = '```\n' + [
      `★ Name: ${displayName}`,
      ...(affBadge ? [`★ Affinity: ${affBadge}`] : []),
      `★ PvP Rank: ${band.emoji} ${band.name} · ${pvpStatus}`,
      `★ Rating: ${rating} · peak ${Math.max(rating, Number(pvp.peak) || rating)}`,
      `★ Record: ${wins}W / ${losses}L · ${winRate(player)}% over ${played} duels`,
      `★ Streak: ${streakLabel(player)} · best W${bestStreak}`,
    ].join('\n') + '\n```'

    const season = getActiveSeason(ctx.db)
    const rawPfp = selectedProfileImage(player, 'pfp', season) ?? player?.pfp
    const rawBanner = selectedProfileImage(player, 'banner', season) ?? player?.banner
    const pfp = profileImageUrl(rawPfp, config.publicApiUrl) ?? rawPfp
    const banner = profileImageUrl(rawBanner, config.publicApiUrl) ?? rawBanner
    const frame = equippedProfileFrame(player)
    const effect = equippedProfileEffect(player)
    const renderOptions = { pvpOnly: true, bannerOnly: false, pfpUrl: pfp, bannerUrl: banner }

    try {
      if (frame || effect) {
        const animated = await renderAnimatedProfileCard(player, {
          ...renderOptions,
          frameStyle: frame?.style ?? null,
          effectStyle: effect?.style ?? null,
        })
        if (typeof ctx.replyGif === 'function') {
          try { return await ctx.replyGif(animated, shortText) }
          catch { /* A platform without animation support gets a framed still. */ }
        }
        const still = await renderProfileCard(player, {
          ...renderOptions,
          frameStyle: frame?.style ?? null,
          effectStyle: effect?.style ?? null,
          framePhase: 0,
        })
        return await ctx.replyImage(still, shortText)
      }

      // Without an equipped Fluid Frame or GIF Effect, .me sends a static PNG.
      const card = await renderProfileCard(player, renderOptions)
      return await ctx.replyImage(card, shortText)
    } catch {
      // Rendering or media delivery failing must never hide the PvP record.
      return ctx.reply(shortText)
    }
  },
}
