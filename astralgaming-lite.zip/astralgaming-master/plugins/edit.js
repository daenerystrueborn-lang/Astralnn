// <prefix>edit - Han Sooyoung's Final Draft control. Once per battle. Erases
// every enemy buff (not overdrive shields) and applies shred_res 12% for 2
// turns. No damage. docs/season-02-characters/han-sooyoung.md
import { config } from '../config.js'
import { activateEdit } from '../lib/regressor-characters.js'
import { runRegressorCommand } from '../lib/regressor-command-runner.js'

export default {
  name: 'edit',
  aliases: ['finaldraft'],
  category: 'combat',
  description: `${config.prefix}edit - Han Sooyoung crosses out every enemy buff and shreds resistance. Once per battle.`,
  requiresPlayer: true,
  async run(ctx) { return runRegressorCommand(ctx, activateEdit) },
}
