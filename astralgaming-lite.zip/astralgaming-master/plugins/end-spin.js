/**
 * end-spin.js — The End's season-finale banner.
 *
 * Odds/caps/pull loop live in lib/spin-banners.js so chat and the website play
 * the same banner. Player-facing copy shows cost, progress and the guarantee,
 * never the dead-zone/plateau internals.
 */
import { config } from '../config.js'
import { getExclusiveSpinWinner } from '../lib/season-engine.js'
import { characterMap } from '../lib/game-data.js'
import { getPlayer, updatePlayer } from '../lib/player-repo.js'
import { fmtGems, roundGems } from '../lib/format.js'
import { characterStars } from '../lib/rarity.js'
import { spinLockGate } from '../lib/spin-locks.js'
import { getSpinBanner, runSpinBatch } from '../lib/spin-banners.js'
import { END_CHARACTER_ID, END_DIMENSION_ID, END_MONSTER_NAME } from '../lib/the-end.js'

const BANNER = getSpinBanner(END_CHARACTER_ID)
const RULE = '━━━━━━━━━━━━━━━━━━━━'
const MISS_LINES = [
  'The seal holds. Something on the other side breathes once, then stops.',
  'A door appears in the dark, but there is no handle on your side.',
  'The season turns a page. The ending is not written yet.',
  'You hear a voice say, "Not yet," and the rift closes.',
  'The last light bends toward you, then looks away.',
]

function pityBar(spin, width = 10) {
  const filled = Math.max(0, Math.min(width, Math.round((spin / BANNER.maxSpinsPerPlayer) * width)))
  return `${'▰'.repeat(filled)}${'▱'.repeat(width - filled)}`
}
function reel(results) {
  const marks = results.map(r => r.won ? '✦' : '·')
  const rows = []
  for (let i = 0; i < marks.length; i += 10) rows.push(marks.slice(i, i + 10).join(' '))
  return rows.slice(-5).join('\n')
}
async function replyOverArt(ctx, character, text) {
  const art = character?.spinImage ?? character?.image
  if (!art) return ctx.reply(text)
  try { return await ctx.replyImage(art, text) } catch { return ctx.reply(text) }
}

export default {
  name: 'end-spin',
  aliases: ['endspin', 'the-end-spin', 'endbanner'],
  category: 'character',
  requiresPlayer: true,
  description: 'Spin for The End — 1.5 Gems per spin, one-of-one, guaranteed by spin 250',
  async run(ctx) {
    const p = config.prefix
    const character = characterMap[END_CHARACTER_ID]
    if (!character) return ctx.reply('⚠️ The End is not configured yet.')
    if (spinLockGate(ctx, END_CHARACTER_ID, character.name)) return

    const existingWinner = getExclusiveSpinWinner(ctx.db, END_CHARACTER_ID)
    if (existingWinner) {
      if (existingWinner === ctx.from) {
        return replyOverArt(ctx, character,
          `🌑 *The End already stands with you.*\n${RULE}\n` +
          `_The dimension is yours: *${p}travel ${END_DIMENSION_ID}*._\n` +
          `_Equip her: *${p}character equip ${END_CHARACTER_ID}*._`)
      }
      const who = getPlayer(ctx.db, existingWinner)?.name ?? 'another player'
      return replyOverArt(ctx, character,
        `🔒 *THE END HAS BEEN CLAIMED*\n${RULE}\n_The ending chose *${who}*. No gems were spent._`)
    }

    const isFirstEverAttempt = (ctx.player[BANNER.spinField] ?? 0) === 0
    const requested = Math.floor(Number(ctx.args[0]) || 1)
    let outcome = null
    await updatePlayer(ctx.db, ctx.from, player => {
      outcome = runSpinBatch(ctx.db, player, BANNER, ctx.from, requested)
    })

    if (outcome?.reason === 'owned') return replyOverArt(ctx, character, `🌑 *The End is already yours.* Equip: *${p}character equip ${END_CHARACTER_ID}*.`)
    if (outcome?.reason === 'claimed') return replyOverArt(ctx, character, `🔒 *The End was claimed while you were reaching.* No gems were spent.`)
    if (outcome?.reason === 'gems') return ctx.reply(`💎 *Not enough Gems.* One spin costs 💎*${BANNER.costPerSpin}*. You hold 💎*${fmtGems(outcome.gems)}*.`)
    if (outcome?.reason === 'exhausted_lifetime') return ctx.reply(`🌑 *No spins left.* You have used all *${BANNER.maxSpinsPerPlayer}* spins.`)

    const last = outcome.results[outcome.results.length - 1]
    const spent = roundGems(outcome.spinsUsed * BANNER.costPerSpin)
    const range = outcome.spinsUsed === 1 ? `Spin *${last.spin}*` : `Spins *${outcome.results[0].spin}* → *${last.spin}*`
    if (outcome.reason === 'won') {
      return replyOverArt(ctx, character,
        `🌑✨ *THE END HAS OPENED HER EYES* ✨🌑\n${RULE}\n` +
        `_Spin ${last.spin}. The seal breaks, and the ending steps out of the season._\n\n` +
        `🏆 *${character.name.toUpperCase()} OBTAINED*\n` +
        `${character.emoji} *${characterStars(character.stars)}* · *${character.ability.name}*\n` +
        `🗣️ _“${character.quote}”_\n\n` +
        `🔒 *GLOBALLY LOCKED.* No other player can ever obtain her.\n` +
        `🌀 *Private dimension unlocked:* *${p}travel ${END_DIMENSION_ID}*\n` +
        `🌑 *Summon:* ${END_MONSTER_NAME} attacks each completed turn while she is equipped.\n` +
        `💎 Remaining: 💎*${fmtGems(outcome.remaining)}*\n\n` +
        `_Equip her: *${p}character equip ${END_CHARACTER_ID}*. Status: *${p}end-domain*._`)
    }
    const lines = [
      `🌑 *THE SEAL HOLDS*`, RULE,
      `_You spent 💎${spent}. The ending does not step out._`, '',
      range, reel(outcome.results), '',
      `_${MISS_LINES[last.spin % MISS_LINES.length]}_`, '',
      `📿 Pity  ${pityBar(last.spin)}  *${last.spin}*/${BANNER.maxSpinsPerPlayer}`,
      `🌑 _Guaranteed by spin ${BANNER.pityAt}._`,
      `💎 Remaining: 💎*${fmtGems(outcome.remaining)}*`,
    ]
    if (requested > BANNER.maxSpinsPerCommand) lines.push('', `_Capped at *${BANNER.maxSpinsPerCommand}* spins per command._`)
    else if (outcome.spinsUsed < outcome.count) lines.push('', `_Gems ran out after *${outcome.spinsUsed}* of *${outcome.count}* requested spins._`)
    const lossText = lines.join('\n')
    return isFirstEverAttempt ? replyOverArt(ctx, character, lossText) : ctx.reply(lossText)
  },
}
