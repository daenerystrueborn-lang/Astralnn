/**
 * tube.js — ASTRALTUBE, the realm's video platform.
 *
 * USAGE
 *   .tube                       the front page: trending, new, your channel
 *   .tube upload                start a video (needs a stream's unlock)
 *   .tube title <text>          name it (required, censored)
 *   .tube thumb                 use the image you replied to / sent, cropped 16:9
 *   .tube publish               put it out there; views start
 *   .tube watch [id]            watch one, see views move
 *   .tube my                    your channel
 *   .tube channel <@player>     someone else's
 *   .tube top                   the leaderboard
 *   .tube like <id>             one like per video, ever
 *   .tube cpm                   how the money works, spelled out
 *   .tube delete <id>           take one down (the unlock is not refunded)
 *
 * ─────────────────────────── THE ONE RULE ────────────────────────────────
 * A VIDEO CAN ONLY EXIST BECAUSE A STREAM DID.
 *
 * Uploading is not a command anyone can run at any time: it spends a receipt
 * issued when a stream settles (lib/astraltube/store.js `unlocks`). No stream,
 * no video. One stream, one video.
 *
 * ─────────────────────────── WHY SO MUCH IS PRECOMPUTED ──────────────────
 * Every video rolls its luck and its final view total ONCE, at publish, and
 * stores both. Views afterwards are a function of elapsed time against a number
 * that never changes, which is what makes the platform honest: a restart cannot
 * re-roll a flop into a phenomenon, and two ticks cannot disagree.
 *
 * ─────────────────────────── THE EDIT BUDGET ─────────────────────────────
 * Telegram and WhatsApp both throttle message edits. A view counter must never
 * drive an edit on its own: the tick is the clock, and the number changes what
 * the NEXT tick's card says (see docs/astraltube.md).
 */
import { config } from '../config.js'
import { updatePlayer, getPlayer } from '../lib/player-repo.js'
import { formatFame } from '../lib/fame-engine.js'

import {
  createVideo, tickVideo, videoSnapshot, rankVideos, leaderboardRows, thumbStyle,
} from '../lib/astraltube/video.js'
import {
  checkTitle, viewPayout, payoutRate, count, CPM_SOLARS, CPM_VIEWS,
  LUCK_TIERS, SOLARS_PER_VIEW, MAX_VIDEO_EARNINGS, TITLE_MAX,
} from '../lib/astraltube/economy.js'
import {
  getUnlock, consumeUnlock, getVideo, saveVideo, deleteVideo, listVideos,
  videosFor, getChannel, recordPublish, applyTick, channelBoard, UNLOCK_TTL_MS,
} from '../lib/astraltube/store.js'

const p = () => config.prefix
const pr = () => p() + 'tube'

/** How often a video's views are folded in. One card per tick, never per view. */
export const TUBE_TICK_MS = 5 * 60 * 1000

const RULE = '━━━━━━━━━━━━━━━━━━━━'

/** Money, spelled out: a payout is never abbreviated. */
function cash(value) {
  const v = Math.round(Number(value) || 0)
  if (v < 1_000_000) return v.toLocaleString('en-US')
  return count(v)
}

/** Rolling timers for videos this process is watching. */
const timers = new Map()

/** Drafts in progress, keyed by player id. In-memory: a draft is not durable. */
const drafts = new Map()

/**
 * Where each unfinished video should be announced, so a restart can pick it up.
 *
 * In-memory on purpose: this is a delivery address, not money. On boot the
 * runner falls back to the channel the video was published into, which
 * store.js already persists, so losing this map costs nothing but the exact
 * message being replied to.
 */
const announceTo = new Map()

function rememberChannel(videoId, playerId, chatId) {
  announceTo.set(videoId, { playerId, chatId, at: Date.now() })
}

/**
 * A minimal ctx for the timer: enough to reply, nothing else.
 *
 * The socket is fetched at send time rather than captured, because the timer
 * outlives any one connection (Baileys reconnects) and a captured socket would
 * be a socket that closed hours ago.
 */
function timerCtx(chatId) {
  const reply = async (text) => {
    if (!chatId) return null
    try {
      const { getBotInstances } = await import('../main.js')
      for (const inst of getBotInstances()) {
        const sock = inst?.currentSock
        if (sock?.sendMessage) return await sock.sendMessage(chatId, { text: String(text) })
      }
    } catch { /* no socket left; the number is already saved, so nothing is lost */ }
    return null
  }
  return { sender: chatId, chatId, reply }
}

/**
 * Restart the tick for every video still earning.
 *
 * Views are stored state, so a process that dies mid-run does not lose them:
 * the next tick reads the gap from `lastTickAt` and folds in everything since.
 * But SOMETHING has to do the folding. Without this, every video published
 * before a deploy froze at whatever count it had, forever, while looking
 * perfectly healthy. Called once at boot by main.js.
 */
export async function resumeVideoTimers() {
  let live = 0
  try {
    const all = await listVideos()
    for (const video of all) {
      if (video.settled) continue
      const slot = announceTo.get(video.id)
      const channel = await getChannel(video.playerId).catch(() => null)
      const chatId = slot?.chatId ?? channel?.chatId ?? video.fromStream?.chatId ?? null
      startTimer(timerCtx(chatId), video.id)
      live++
    }
  } catch {
    return 0
  }
  return live
}

/* ─────────────────────────────── pictures ───────────────────────────────── */

/**
 * Send a card as a PICTURE, falling back to the text it already built.
 *
 * ASTRALTUBE answered every command with markdown while `.league`, `.top`,
 * `.stats` and the battle screens all handed back a rendered card. The owner
 * asked why, and the answer was that no renderer had been written. This is the
 * wiring: the text card is built first because it is both the source of truth
 * and the fallback, then the drawn version is tried.
 *
 * A picture must never cost a player their command: any failure here lands the
 * text card exactly as before.
 */
async function sendCard(ctx, text, render) {
  try {
    const buf = await render()
    if (buf?.length && typeof ctx.replyImage === 'function') {
      return await ctx.replyImage(buf, text)
    }
  } catch { /* fall through to the text card */ }
  return ctx.reply(text)
}

/** Emoji and the flag characters the canvas fonts cannot draw, removed. */
function bare(text) {
  return String(text ?? '').replace(/[\p{Extended_Pictographic}\uFE0F\u200D]/gu, '').trim()
}

/** "6h ago" · how long a video has been out, for a card that has no clock. */
function ageLabel(minutes) {
  const m = Math.max(0, Math.round(Number(minutes) || 0))
  if (m < 60) return `${Math.max(1, m)}m ago`
  if (m < 60 * 24) return `${Math.round(m / 60)}h ago`
  return `${Math.round(m / (60 * 24))}d ago`
}

/** The leaderboard row a renderer wants, from a video snapshot. */
function boardRow(snap, rank) {
  return {
    rank,
    title: bare(snap.title),
    playerName: bare(snap.playerName),
    viewsLabel: count(snap.views ?? 0),
    likesLabel: cash(snap.likes ?? 0),
    earnedLabel: cash(snap.earned ?? 0),
    luckLabel: bare(snap.luckLabel),
    ageLabel: ageLabel(snap.ageMinutes),
    thumbnailUrl: snap.thumbnailUrl ?? null,
  }
}

/* ─────────────────────────────── cards ──────────────────────────────────── */

function frontCard({ trending, mine, unlocked, prefix }) {
  const out = [`📺 *A S T R A L T U B E*`, RULE]
  if (unlocked) {
    out.push(`🎬 *You have an upload ready.* _It expires in ${Math.round(UNLOCK_TTL_MS / 3_600_000)} hours._`)
    out.push(`👉 *${prefix}tube upload*`)
    out.push('')
  }
  out.push(`🔥 *TRENDING*`)
  if (trending.length) {
    for (const v of trending.slice(0, 5)) {
      out.push(`  ${v.luckEmoji} *${v.title}*`)
      out.push(`     ${v.playerName} · 👁 ${v.viewsLabel} · ▶ ${v.lengthLabel}`)
    }
  } else {
    out.push(`  _Nothing published yet. Stream once and you can be the first._`)
  }
  out.push('')
  out.push(`🆕 *NEW*`)
  const fresh = rankVideos(mine.all ?? [], { by: 'new' }).slice(0, 3)
  if (fresh.length) for (const v of fresh) out.push(`  • *${v.title}* · 👁 ${count(v.views ?? 0)}`)
  else out.push(`  _Quiet._`)
  out.push('')
  out.push(`👤 *YOUR CHANNEL*`)
  if (mine.videos) {
    out.push(`  ${count(mine.views)} views · ${count(mine.likes)} likes · ${cash(mine.earned)} ☀️ earned`)
  } else {
    out.push(`  _No channel yet. The unlock comes from finishing a stream._`)
  }
  out.push(RULE)
  out.push(`📺 *${prefix}tube top* · *${prefix}tube my* · *${prefix}tube cpm*`)
  return out.join('\n')
}

function videoCard(v, { prefix, own = false } = {}) {
  const out = [
    `🎬 *${v.title}*`,
    RULE,
    `${v.luckEmoji} ${v.playerName} · ▶ ${v.lengthLabel}`,
    `👁 *${v.viewsLabel}* views · 🧑‍🤝‍🧑 *${count(v.concurrent)}* watching now`,
    `👍 ${count(v.likes)} · 📈 ${v.progressPct}% of its run`,
    '',
    `☀️ *${cash(v.earned)}* earned so far`,
    `📊 ${count(v.targetViews)} views once it is done`,
  ]
  if (v.fromStream) {
    out.push(`🎥 _From a ${v.fromStream.minutes} minute stream with ${count(v.fromStream.peak)} watching._`)
  }
  out.push('')
  out.push(`👉 *${prefix}tube watch ${v.id.slice(0, 8)}*` + (own ? ` · *${prefix}tube delete ${v.id.slice(0, 8)}*` : ''))
  return out.join('\n')
}

function channelCard(channel, videos, { name, prefix, own = false } = {}) {
  const out = [
    `📺 *${name}'s CHANNEL*`,
    RULE,
    `👁 ${count(channel.views)} total views`,
    `🎬 ${count(channel.videos)} videos · 👍 ${count(channel.likes)} likes`,
    `☀️ ${cash(channel.earned)} earned`,
    '',
    videos.length ? `*VIDEOS*` : `_Nothing uploaded yet._`,
  ]
  for (const v of videos.slice(0, 8)) {
    out.push(`  ${v.luckEmoji} *${v.title}*`)
    out.push(`     👁 ${count(v.views ?? 0)} · ▶ ${v.minutes}:00`)
  }
  if (!own) out.push('')
  return out.join('\n')
}

function uploadPrompt({ unlock, prefix }) {
  const mins = Math.round((unlock.expiresAt - Date.now()) / 3_600_000)
  return [
    `🎬 *UPLOAD TO ASTRALTUBE*`,
    RULE,
    `This receipt came from your last stream:`,
    `  🎥 ${unlock.streamMinutes} minutes · 👁 peak ${count(unlock.streamPeak)} · ⭐ ${count(unlock.followers)} followers`,
    `  ⏳ _It is good for ${mins} more hours. One stream, one video._`,
    '',
    `*1.* Name it`,
    `👉 *${prefix}tube title your title here*`,
    '',
    `*2.* Add a thumbnail _(optional)_`,
    `_Reply to a picture and send_ *${prefix}tube thumb* _— it gets cropped to 16:9 and marked._`,
    '',
    `*3.* Publish`,
    `👉 *${prefix}tube publish*`,
    '',
    `_Titles are censored. ${TITLE_MAX} characters, no swearing._`,
  ].join('\n')
}

function cpmCard() {
  return [
    `💰 *HOW ASTRALTUBE PAYS*`,
    RULE,
    `☀️ *${cash(CPM_SOLARS)}* solars per *${count(CPM_VIEWS)}* views`,
    `That is *${SOLARS_PER_VIEW}* solars a view, or ${Math.round(SOLARS_PER_VIEW * 1000)} a thousand.`,
    '',
    `*THE FIVE KINDS OF VIDEO*`,
    ...LUCK_TIERS.map(t => `  ${t.emoji} *${t.label}* · ${t.multiplier}x reach · ${t.weight}% of videos`),
    '',
    `_Your followers raise the floor: about one in twenty watches whatever you post. ` +
    `Luck decides how far above that floor it goes, so a small channel can out-view a big one._`,
    '',
    `🛑 One video is capped at *${cash(MAX_VIDEO_EARNINGS)}* ☀️`,
    `📈 Views land over hours, not instantly. Check back.`,
    RULE,
    `📺 *${pr()} upload* once you have streamed`,
  ].join('\n')
}

/* ────────────────────────────── the ticker ──────────────────────────────── */

/**
 * Fold a video's views in and announce it if it moved enough to matter.
 *
 * Deliberately quiet by default: a card every five minutes for every video in
 * the realm would be spam. The owner gets the update; the realm gets nothing
 * until the video is finished or it crosses something worth saying.
 */
async function tickOne(ctx, videoId, { announce = true } = {}) {
  const video = await getVideo(videoId)
  if (!video || video.settled) {
    clearTimer(videoId)
    return null
  }
  const delta = tickVideo(video)
  const wasSettled = video.settled
  await applyTick(video, delta)
  // Slot the message we replied to, so the boot-time runner can come back and
  // say "finished" even after a deploy. Without this the video still earns, but
  // the player is never told it landed, which looks like the payout broke.
  if (wasSettled && ctx?.sender) rememberChannel(videoId, video.playerId, ctx.sender)

  if (wasSettled) clearTimer(videoId)

  if (announce && ctx && (delta.views > 0 || wasSettled)) {
    // Only tell the owner, and only when the number is worth a message.
    const snap = videoSnapshot(video)
    if (wasSettled) {
      await ctx.reply([
        `🏁 *${snap.title}* has finished its run.`,
        `👁 *${snap.viewsLabel}* views · 👍 ${count(snap.likes)} · ☀️ *${cash(snap.earned)}*`,
        `_Payout lands the next time you are around._`,
      ].join('\n')).catch(() => null)
    }
  }
  return { video, delta }
}

function clearTimer(videoId) {
  const t = timers.get(videoId)
  if (t) { clearInterval(t); timers.delete(videoId) }
}

function startTimer(ctx, videoId) {
  if (timers.has(videoId)) return
  const t = setInterval(() => {
    tickOne(ctx, videoId).catch(() => clearTimer(videoId))
  }, TUBE_TICK_MS)
  t.unref?.()
  timers.set(videoId, t)
}

/* ─────────────────────────────── helpers ────────────────────────────────── */

/** Find one of the caller's videos by id prefix, or null. */
async function findOwnVideo(playerId, token) {
  const mine = await videosFor(playerId)
  if (!token) return mine[0] ?? null
  const key = String(token).toLowerCase()
  return mine.find(v => v.id.toLowerCase().startsWith(key)) ?? null
}

/** Find ANY video by id prefix. */
async function findAnyVideo(token) {
  const key = String(token ?? '').toLowerCase()
  if (!key) return null
  const all = await listVideos()
  return all.find(v => v.id.toLowerCase().startsWith(key)) ?? null
}

/**
 * The picture the player attached or replied to, cropped and marked.
 *
 * Returns the finished PNG Buffer, or null when there is no image. Never throws:
 * a thumbnail is optional and a bad image must not stop a publish.
 */
async function buildThumbnail(ctx, { title, seed, badge }) {
  let buffer = null
  try {
    const { readProfilePictureBuffer } = await import('../lib/pfp.js')
    buffer = await readProfilePictureBuffer(ctx)
  } catch {
    buffer = null
  }
  try {
    const { renderThumbnail } = await import('../lib/astraltube/thumb.mjs')
    return await renderThumbnail({ image: buffer, title, seed, badge })
  } catch {
    return null
  }
}

/**
 * Put a finished thumbnail somewhere the app can reach it.
 *
 * Returns the hosted URL, or null. NOT fatal on failure, deliberately: the crop
 * is already done and the video can still be published. It just renders as a
 * colour plate in the app instead of the picture. Blocking a player over an
 * imgbb outage would be trading the whole feature for the garnish.
 */
export async function hostThumbnail(buffer, playerId = 'anon') {
  if (!buffer) return null
  try {
    const { uploadToImgbb } = await import('../lib/imgbb.js')
    return (await uploadToImgbb(buffer, `tube-${playerId}-${Date.now()}`)) ?? null
  } catch {
    return null
  }
}

/* ───────────────────────────── the command ──────────────────────────────── */

export default {
  name: 'tube',
  aliases: ['astraltube', 'atube'],
  category: 'astraltube',
  requiresPlayer: true,
  description: `${config.prefix}tube — ASTRALTUBE, videos earned by streaming`,
  subcommands: [
    { cmd: '', desc: 'the front page: trending, new, your channel' },
    { cmd: 'upload', desc: 'start a video (needs a stream receipt)' },
    { cmd: 'title <text>', desc: 'name the video (censored)' },
    { cmd: 'thumb', desc: 'reply to a picture to use it as the thumbnail' },
    { cmd: 'publish', desc: 'publish the draft; views start' },
    { cmd: 'watch [id]', desc: 'watch one, see the count move' },
    { cmd: 'my', desc: 'your channel' },
    { cmd: 'channel <@player>', desc: "someone else's channel" },
    { cmd: 'top', desc: 'the leaderboard' },
    { cmd: 'like <id>', desc: 'one like per video, ever' },
    { cmd: 'cpm', desc: 'how the money works' },
    { cmd: 'delete <id>', desc: 'remove one of yours' },
  ],

  async run(ctx) {
    const { player, args } = ctx
    const sub = String(args[0] ?? '').toLowerCase()
    const rest = args.slice(1)

    switch (sub) {
      case '': case 'home': case 'browse': return cmdHome(ctx)
      case 'upload': case 'new': return cmdUpload(ctx)
      case 'title': case 'name': return cmdTitle(ctx, rest.join(' '))
      case 'thumb': case 'thumbnail': return cmdThumb(ctx)
      case 'publish': case 'post': return cmdPublish(ctx)
      case 'watch': case 'play': return cmdWatch(ctx, rest[0])
      case 'my': case 'channel': return cmdMy(ctx, rest[0])
      case 'top': case 'leaderboard': return cmdTop(ctx)
      case 'like': return cmdLike(ctx, rest[0])
      case 'cpm': case 'money': return ctx.reply(cpmCard())
      case 'delete': case 'remove': return cmdDelete(ctx, rest[0])
      default:
        // Anything else is a video id, so `.tube 1a2b3c` works like `.tube watch`.
        return cmdWatch(ctx, sub)
    }
  },
}

/* ──────────────────────────── the front page ────────────────────────────── */

async function cmdHome(ctx) {
  const { player } = ctx
  const all = await listVideos()
  const snapshots = all.map(v => videoSnapshot(v))
  const trending = rankVideos(snapshots, { by: 'trending' })
  const mine = await videosFor(player.id)
  const channel = await getChannel(player.id)
  const unlock = await getUnlock(player.id)
  let rankedChannels = null
  try { rankedChannels = await channelBoard({ limit: 4 }) } catch { rankedChannels = [] }

  const text = frontCard({
    trending,
    mine: { ...channel, all: mine.map(v => videoSnapshot(v)), videos: mine.length },
    unlocked: !!unlock,
    prefix: p(),
  })

  // The homepage draws with the same renderer `.tube top` uses, because a front
  // page IS a board: the trending list, ranked, with the channels under it.
  // Nothing is invented for it — if the realm has published nothing, it says so.
  return sendCard(ctx, text, async () => {
    const { renderTubeLeaderboard } = await import('../lib/astraltube/leaderboard-render.mjs')
    const top = rankVideos(snapshots, { by: 'views' }).slice(0, 6)
    const rated = rankedChannels ?? (await channelBoard({ limit: 4 }))
    const maxViews = Math.max(1, ...rated.map(c => c.views ?? 0))
    return renderTubeLeaderboard(
      top.map((v, i) => boardRow(v, i + 1)),
      rated.map(c => ({
        playerName: bare(c.playerName) || String(c.playerId ?? '').split('@')[0],
        viewsLabel: count(c.views ?? 0),
        earnedLabel: cash(c.earned ?? 0),
        share: (c.views ?? 0) / maxViews,
      })),
      {
        eyebrow: 'ASTRALTUBE',
        title: 'FRONT PAGE',
        subtitle: unlock
          ? 'You have an upload ready'
          : count(snapshots.length) + ' videos on the platform',
        badgeTop: 'YOUR CHANNEL',
        badgeBottom: mine.length ? `${count(channel.views ?? 0)} VIEWS` : 'NO VIDEOS',
        footer: unlock ? `${pr()} upload` : `${pr()} top`,
        footerRight: 'ASTRALTUBE',
        emptyNote: 'Nothing published yet.',
        maxRows: 6,
      },
    )
  })
}

/* ──────────────────────────────── upload ────────────────────────────────── */

async function cmdUpload(ctx) {
  const { player } = ctx
  const unlock = await getUnlock(player.id)
  if (!unlock) {
    return ctx.reply([
      `🔒 *No upload available.*`,
      '',
      `_A ASTRALTUBE video is earned, not made. Finish a stream and the receipt is yours._`,
      '',
      `👉 *${p()}stream start*`,
    ].join('\n'))
  }
  drafts.set(player.id, { unlockId: unlock.id, title: null, thumbSeed: Math.floor(Math.random() * 1e9), thumbnailUrl: null, thumbBuffer: null })
  return ctx.reply(uploadPrompt({ unlock, prefix: p() }))
}

async function cmdTitle(ctx, text) {
  const { player } = ctx
  const draft = drafts.get(player.id)
  if (!draft) return ctx.reply(`🎬 _Start an upload first:_ *${pr()} upload*`)
  if (!text) return ctx.reply(`✏️ *${pr()} title <your title>*

_Up to ${TITLE_MAX} characters. Swearing is refused._`)

  const checked = checkTitle(text)
  if (!checked.ok) {
    const why = {
      language: `🚫 *That title has a word we do not allow.*\n\n_Try again without it._`,
      'too short': `✏️ *Too short.* _Give it at least a few words._`,
      'too long': `✏️ *Too long.* _${TITLE_MAX} characters maximum, that one was ${checked.title.length}._`,
      'no words': `✏️ *That is not a title.* _Use letters._`,
    }[checked.reason] ?? `🚫 *That title will not work.*`
    return ctx.reply(why)
  }

  draft.title = checked.title
  drafts.set(player.id, draft)
  return ctx.reply([
    `✅ *Title set:* ${checked.title}`,
    '',
    `*Next:*`,
    `  🖼 ${pr()} thumb   _optional: reply to a picture_`,
    `  🚀 ${pr()} publish`,
  ].join('\n'))
}

async function cmdThumb(ctx) {
  const { player } = ctx
  const draft = drafts.get(player.id)
  if (!draft) return ctx.reply(`🎬 _Start an upload first:_ *${pr()} upload*`)
  if (!draft.title) return ctx.reply(`✏️ _Name it first:_ *${pr()} title <text>*`)

  const buffer = await buildThumbnail(ctx, {
    title: draft.title,
    seed: draft.thumbSeed,
    badge: 'NEW',
  })
  if (!buffer) return ctx.reply(`🖼 _That thumbnail could not be drawn. Try again, or publish without one._`)

  draft.thumbBuffer = buffer
  drafts.set(player.id, draft)

  draft.thumbnailUrl = await hostThumbnail(buffer, player.id)
  const hosted = !!draft.thumbnailUrl
  drafts.set(player.id, draft)

  await ctx.reply(
    `🖼 *Thumbnail ready* — cropped to 16:9 and marked.` +
    (hosted ? '' : '\n_I could not put it on the shelf, so the app will show a colour plate instead. The video still plays._'),
  )
  // Send it so the player can see what they are publishing.
  try {
    const { sendImageTo } = await import('../lib/image.js')
    await sendImageTo(ctx.sock ?? ctx, buffer, `🖼 *${draft.title}*`)
  } catch {
    // Sending is a nicety; the buffer is already stored on the draft.
  }
  return null
}

async function cmdPublish(ctx) {
  const { player } = ctx
  const draft = drafts.get(player.id)
  if (!draft) return ctx.reply(`🎬 _Start an upload first:_ *${pr()} upload*`)
  if (!draft.title) return ctx.reply(`✏️ _Name it first:_ *${pr()} title <text>*`)

  const unlock = await getUnlock(player.id)
  if (!unlock || unlock.id !== draft.unlockId) {
    drafts.delete(player.id)
    return ctx.reply(`⌛ *That receipt expired.* _Stream again to earn another._`)
  }
  // Spend the receipt FIRST: if this fails, nothing is published and the player
  // still has their upload.
  if (!(await consumeUnlock(player.id))) {
    drafts.delete(player.id)
    return ctx.reply(`⌛ *That receipt was already used.*`)
  }

  let video
  try {
    video = createVideo({
      unlock: {
        ...unlock,
        playerId: player.id,
        playerName: player.name,
      },
      title: draft.title,
      thumbnailUrl: draft.thumbnailUrl,
      now: Date.now(),
    })
  } catch (err) {
    // Put the receipt back: a failed publish must not eat it.
    const { grantUnlock } = await import('../lib/astraltube/store.js')
    await grantUnlock(player.id, unlock).catch(() => null)
    return ctx.reply(`❌ *Could not publish:* ${err.message}`)
  }

  await saveVideo(video)
  await recordPublish(player.id, { chatId: ctx.sender ?? null, playerName: player.name ?? null })
  drafts.delete(player.id)
  startTimer(ctx, video.id)

  const snap = videoSnapshot(video)
  await ctx.reply([
    `🚀 *PUBLISHED*`,
    RULE,
    `🎬 *${snap.title}*`,
    `▶ ${snap.lengthLabel} · ${snap.luckEmoji} ${snap.luckLabel}`,
    '',
    `_Views are landing now. They come in over the next few hours — a video is never ` +
    `finished the moment it goes up._`,
    '',
    `👉 *${pr()} my* · *${pr()} watch ${video.id.slice(0, 8)}*`,
  ].join('\n'))

  // The thumbnail, if there is one, as the visual for the post.
  if (draft.thumbBuffer) {
    try {
      const { sendImageTo } = await import('../lib/image.js')
      await sendImageTo(ctx.sock ?? ctx, draft.thumbBuffer, `🎬 *${snap.title}*`)
    } catch { /* the text card already went out */ }
  }
  return null
}

/* ──────────────────────────────── watching ──────────────────────────────── */

async function cmdWatch(ctx, token) {
  const video = token ? await findAnyVideo(token) : (await videosFor(ctx.player.id))[0]
  if (!video) {
    return ctx.reply([
      `🔍 *No video there.*`,
      `👉 *${pr()}* for the front page`,
    ].join('\n'))
  }
  // Watching a video actually ticks it: the count moves because someone looked.
  const delta = tickVideo(video)
  await applyTick(video, delta)
  const snap = videoSnapshot(video)
  const own = video.playerId === ctx.player.id
  const text = videoCard(snap, { prefix: p(), own })

  return sendCard(ctx, text, async () => {
    const { renderTubeVideo } = await import('../lib/astraltube/leaderboard-render.mjs')
    return renderTubeVideo({
      title: bare(snap.title),
      playerName: bare(snap.playerName),
      thumbnailUrl: snap.thumbnailUrl ?? null,
      viewsLabel: count(snap.views ?? 0),
      likesLabel: cash(snap.likes ?? 0),
      earnedLabel: `${cash(snap.earned ?? 0)}`,
      luckLabel: bare(snap.luckLabel),
      lengthLabel: snap.lengthLabel,
      ageLabel: ageLabel(snap.ageMinutes),
      progressPct: snap.progressPct,
      concurrentLabel: snap.settled ? null : count(snap.concurrent ?? 0),
    }, {
      eyebrow: 'ASTRALTUBE',
      title: 'VIDEO',
      subtitle: snap.fromStream
        ? `from a ${snap.fromStream.minutes} minute stream with ${count(snap.fromStream.peak)} watching`
        : 'a video on ASTRALTUBE',
      badgeTop: 'LENGTH',
      badgeBottom: snap.lengthLabel,
      footer: own ? `${pr()} my  ·  ${pr()} delete ${snap.id.slice(0, 8)}` : `${pr()} like ${snap.id.slice(0, 8)}  ·  ${pr()} my`,
      footerRight: 'ASTRALTUBE',
    })
  })
}

/* ─────────────────────────────── channels ───────────────────────────────── */

async function cmdMy(ctx, who) {
  const { player } = ctx
  // `.tube channel @them` reuses the same card for someone else.
  if (who) {
    const { extractTarget } = await import('../lib/group-helpers.js')
    const targetId = extractTarget(ctx)
    if (!targetId) {
      return ctx.reply(`👤 _Tag someone to see their channel, or just_ *${pr()} my* _for yours._`)
    }
    const other = getPlayer(ctx.db, targetId)
    if (!other) return ctx.reply(`❌ _That player isn't registered._`)
    const channel = await getChannel(targetId)
    const videos = (await videosFor(targetId)).map(v => videoSnapshot(v))
    return ctx.reply(channelCard(channel, videos, { name: other.name, prefix: p() }))
  }
  const channel = await getChannel(player.id)
  const videos = (await videosFor(player.id)).map(v => videoSnapshot(v))
  return ctx.reply(channelCard(channel, videos, { name: player.name, prefix: p(), own: true }))
}

async function cmdTop(ctx) {
  const all = (await listVideos()).map(v => videoSnapshot(v))
  const rows = leaderboardRows(all, { limit: 10 })
  const channels = await channelBoard({ limit: 5 })
  const out = [`🏆 *ASTRALTUBE TOP*`, RULE]
  if (!rows.length) out.push(`_Nobody has published yet._`)
  for (const r of rows) {
    const medal = ['🥇', '🥈', '🥉'][r.rank - 1] ?? `${r.rank}.`
    out.push(`${medal} *${r.title}*`)
    out.push(`   ${r.playerName} · 👁 ${r.viewsLabel} · ☀️ ${cash(r.earned)}`)
  }
  if (channels.length) {
    out.push('', `📺 *CHANNELS*`)
    for (const c of channels) out.push(`  • ${c.playerId} · 👁 ${count(c.views)} · ☀️ ${cash(c.earned)}`)
  }
  out.push(RULE)
  out.push(`👉 *${pr()}* to watch something`)

  const text = out.join('\n')
  // The picture is the point: this is the board people screenshot, and it was
  // the command in the owner's own screenshot that came back as plain text.
  return sendCard(ctx, text, async () => {
    const { renderTubeLeaderboard } = await import('../lib/astraltube/leaderboard-render.mjs')
    const top = all.slice().sort((a, b) => (b.views ?? 0) - (a.views ?? 0))
    const rated = (await channelBoard({ limit: 5 }))
    const maxViews = Math.max(1, ...rated.map(c => c.views ?? 0))
    return renderTubeLeaderboard(
      top.slice(0, 8).map((v, i) => boardRow(v, i + 1)),
      rated.map(c => ({
        playerName: bare(c.playerName) || String(c.playerId ?? '').split('@')[0],
        viewsLabel: count(c.views ?? 0),
        earnedLabel: cash(c.earned ?? 0),
        share: (c.views ?? 0) / maxViews,
      })),
      {
        eyebrow: 'ASTRALTUBE',
        title: 'TOP VIDEOS',
        subtitle: top.length ? 'The realm is watching' : 'Nobody has published yet',
        badgeTop: 'MOST WATCHED',
        badgeBottom: top.length ? `${count(top[0].views ?? 0)} VIEWS` : '-',
        footer: `${pr()} to watch something`,
        footerRight: 'ASTRALTUBE',
        emptyNote: 'Nobody has published yet.',
        maxRows: 8,
      },
    )
  })
}

async function cmdLike(ctx, token) {
  const { player } = ctx
  const video = token ? await findAnyVideo(token) : (await videosFor(player.id))[0]
  if (!video) return ctx.reply(`🔍 _No video there._`)
  if (video.playerId === player.id) {
    return ctx.reply(`😅 _You cannot like your own video. Let the realm decide._`)
  }
  const liked = (video.likedBy ??= [])
  if (liked.includes(player.id)) return ctx.reply(`👍 _You already liked that one._`)
  liked.push(player.id)
  video.likes = (video.likes ?? 0) + 1
  await saveVideo(video)
  return ctx.reply(`👍 *Liked.* _${count(video.likes)} likes._`)
}

async function cmdDelete(ctx, token) {
  const { player } = ctx
  const video = await findOwnVideo(player.id, token)
  if (!video) return ctx.reply(`🔍 _You have no video like that._`)
  await deleteVideo(video.id)
  clearTimer(video.id)
  return ctx.reply([
    `🗑 *Taken down:* _${video.title}_`,
    '',
    `_The receipt from that stream is gone with it. A video is earned once._`,
  ].join('\n'))
}

/* ───────────────────────── boot: resume the ticker ──────────────────────── */

/**
 * Nothing to restore on boot, deliberately.
 *
 * Views are a pure function of elapsed time, so a video that was live when the
 * process died catches up on its next tick with no special handling. There is
 * no "unclaimed earnings" ledger to repair: `viewPayout` is recomputed from the
 * stored view count, which is idempotent.
 */

export { viewPayout, payoutRate, checkTitle }
