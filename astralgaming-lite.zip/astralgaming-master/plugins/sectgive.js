/**
 * sectgive.js — `.sectgive` : the owner's hand on the cultivation side.
 *
 * OWNER ONLY, like every other give/take tool, and it touches nothing on the
 * Astral record: progress goes in through the same add every fight and pill
 * will use (lib/sect-progress.js's giveProgress), time is skipped rather than
 * simulated, and the forced roll is consumed by the very next attempt.
 *
 *   .sectgive <player> progress <n>          progress, by the hand
 *   .sectgive <player> time <hours>          skip time: a session, a cooldown, a deviation
 *   .sectgive <player> breakthrough <what>   success | fail | critical | clear
 *   .sectgive <player> stones <n>            Spirit Stones into their purse
 *   .sectgive <player> item <id> <count>     an item into their bag
 *
 * PROMPT 7 added four more, all of them owner only and all of them going
 * through the same functions a player's own commands do:
 *
 *   .sectgive <player> material <id> <count>    materials into the bag
 *   .sectgive <player> profession <name> <lvl>  set a trade's level outright
 *   .sectgive <player> monster <id> [stage]     start that exact fight
 *   .sectgive <player> reset                    clear the day's entries and caps
 *
 * Targets the way every admin tool does: a reply, an @mention, or a typed name
 * (the same resolver .resetsect uses, so a player is found the same way twice).
 */
import { config } from '../config.js'
import { isOwnerJid, NOT_ALLOWED } from '../lib/group-helpers.js'
import { updatePlayer, getPlayer } from '../lib/player-repo.js'
import { addItemToDb, giveStones, itemById } from '../lib/sect-items.js'
import { currencyWords } from '../lib/sect-items-screen.js'
import { ensureSectProfile } from '../lib/sect-cultivation.js'
import { learnTechnique, techniqueById, techniqueSlots } from '../lib/sect-techniques.js'
import { formatDuration, giveProgress, isDeviating, onCooldown } from '../lib/sect-progress.js'
import { resolveSectTarget } from './resetsect.js'
import { sectGiveSectRow } from '../lib/sect-commands.js'
// Prompt 7's owner tools: materials, a trade's level, a named monster, and the
// day's own bookkeeping.
import { materialById, materialName, materialProblems } from '../lib/sect-materials.js'
import { matchProfession, ensureProfessions, levelForPoints, MAX_LEVEL, professionProblems } from '../lib/sect-professions.js'
import { matchMonster, monsterStage, monsterEnemy, monsterProblems } from '../lib/sect-monsters.js'
import { startSectFight, startRefusal, fightOpeningLines, BUSY } from '../lib/sect-fight.js'
import { withGrowthLock } from '../lib/sect-progress.js'
import { areaById } from '../lib/sect-areas.js'

const FORCED = { success: 'success', fail: 'fail', failure: 'fail', critical: 'critical', deviation: 'critical' }

/** The record as it stands now, falling back to what the resolver handed us. */
function fresh0(target, ctx, jid) {
  return getPlayer(ctx.db, jid) ?? target
}

/** Fill the {blanks} in a line of data. */
const fill = (text, values = {}) => String(text ?? '')
  .replace(/\{(\w+)\}/g, (_, key) => String(values[key] ?? ''))

const USAGE = (p) => [
  `🛠️ *${p}sectgive <player> <what>*`,
  `*progress <n>*  _add that much progress (it carries over and can move several stages)_`,
  `*time <hours>*  _skip time for a session, a cooldown or a Qi deviation_`,
  `*technique <id>*  _teach them one (the ids in data/sect-techniques.json)_`,
  `*breakthrough success|fail|critical|clear*  _call the next roll_`,
  `*stones <n>*  _Spirit Stones into their purse (never negative)_`,
  `*item <id> [count]*  _an item into their bag: a pill, or an artifact record_`,
  `*sect <sect id> [rank]*  _put them on a mountain: walks them there if they are still in the kingdom_`,
  `*rank <rank>*  _move them up or down the sect ladder_`,
  `*contribution <n>*  _hand out contribution points_`,
  `*clear*  _take the whole sect record away (they keep their Astra record)_`,
  ``,
  `🌿 *material <id> <count>*  _materials into their bag (the wilds' own goods)_`,
  `🛠️ *profession <name> <level>*  _set a trade's level outright (1 to ${MAX_LEVEL})_`,
  `🗡️ *monster <id> [stage]*  _start that exact fight for them_`,
  `♻️ *reset*  _clear today's entries and caps: realms, hunts, gathers, trade points_`,
]

export default {
  name: 'sectgive',
  aliases: ['givesect'],
  category: 'admin',
  requiresPlayer: false,
  description: `${config.prefix}sectgive <player> progress|time|breakthrough — owner tools for the Sect Empire`,

  async run(ctx) {
    const p = config.prefix
    if (!isOwnerJid(ctx.from)) return ctx.reply(NOT_ALLOWED)

    const words = (ctx.args ?? []).map(a => String(a))
    if (!words.length) return ctx.reply(USAGE(p).join('\n'))

    // The player comes first, UNLESS the first word is already one of the modes:
    // an owner who replied to (or mentioned) the player does not have to type
    // their name twice.
    const MODES = new Set(['progress', 'xp', 'time', 'skip', 'technique', 'breakthrough', 'roll',
      'stones', 'item', 'give',
      'sect', 'rank', 'contribution', 'clear', 'wipe',
      'material', 'mat', 'profession', 'trade', 'monster', 'fight', 'reset'])
    const modeFirst = MODES.has(String(words[0]).toLowerCase())
    const name = modeFirst ? '' : String(words[0])
    const what = String(modeFirst ? words[0] : words[1] ?? '').toLowerCase()
    const value = modeFirst ? words[1] : words[2]
    const { player: target, jid } = resolveSectTarget(ctx.db, ctx, name)
    if (!target || !jid) {
      return ctx.reply(`❓ *Nobody called "${name || '?'}" is playing.*\n_${p}sectgive <player> <what>_`)
    }

    // ── The sect itself ─────────────────────────────────────────────────────
    // Membership, rank, contribution and the wipe. These go through the SAME
    // functions a player's own commands use (lib/sect-commands.js), so an owner
    // cannot write a record the game itself would never write.
    if (['sect', 'rank', 'contribution', 'clear', 'wipe'].includes(what)) {
      const rest = modeFirst ? words.slice(1) : words.slice(2)
      return sectGiveSectRow(ctx, { target: { ...target, jid }, sub: what, args: rest })
    }

    // ── Progress ────────────────────────────────────────────────────────────
    if (what === 'progress' || what === 'xp') {
      const amount = Number(value)
      if (!Number.isFinite(amount) || amount === 0) {
        return ctx.reply(`❓ *How much?* _*${p}sectgive ${target.name} progress 2500*_`)
      }
      const out = await giveProgress(ctx.db, jid, amount, { source: 'owner', now: Date.now() })
      if (!out.ok) {
        const why = {
          'not-in-sect': 'they are not in the Sect Empire',
          'no-record': 'they have no cultivation record',
          mortal: 'they are still a Mortal: their hours go to the Awakening instead',
          deviation: 'their Qi is deviating: no progress until it clears',
          busy: 'another add is already in flight for them',
        }[out.reason] ?? 'that did not land'
        return ctx.reply(`⚠️ *Nothing added:* ${why}.`)
      }
      const lines = [`🛠️ *${target.name}* gets *${amount}* progress.`]
      if (out.stages.length) lines.push('', ...out.lines)
      if (out.bottleneck) {
        lines.push('', `🔒 _They are at the bottleneck now: *${out.stageName}*, ready to try a breakthrough._`)
      } else {
        lines.push(`📊 _Bar: *${out.progress}/${out.need}* at *${out.stageName}*._`)
      }
      return ctx.reply(lines.join('\n'))
    }

    // ── Time ────────────────────────────────────────────────────────────────
    if (what === 'time' || what === 'skip') {
      const hours = Number(value)
      if (!Number.isFinite(hours) || hours === 0) {
        return ctx.reply(`❓ *How many hours?* _*${p}sectgive ${target.name} time 24*_`)
      }
      const ms = hours * 3_600_000
      let skipped = null
      await updatePlayer(ctx.db, jid, pl => {
        const profile = pl.sect
        if (!profile) return pl
        ensureSectProfile(pl, { now: Date.now() })
        const parts = []
        if (profile.session?.startedAt) {
          profile.session.startedAt -= ms
          parts.push('session')
        }
        if (Number(profile.failure?.until)) { profile.failure.until -= ms; parts.push('cooldown') }
        if (Number(profile.deviation?.until)) { profile.deviation.until -= ms; parts.push('deviation') }
        if (Number(profile.injury?.until)) { profile.injury.until -= ms; parts.push('injury') }
        if (Number(profile.trialUntil)) { profile.trialUntil -= ms; parts.push('trial wait') }
        if (Number(profile.sectTask?.dueAt)) { profile.sectTask.dueAt -= ms; parts.push('chore') }
        if (Number(profile.gather?.dueAt)) { profile.gather.dueAt -= ms; parts.push('gather') }
        if (Number(profile.bench?.dueAt)) { profile.bench.dueAt -= ms; parts.push('bench') }
        if (Number(profile.lesson?.dueAt)) { profile.lesson.dueAt -= ms; parts.push('lesson') }
        skipped = parts
        return pl
      })
      const fresh = getPlayer(ctx.db, jid) ?? target
      if (!skipped) return ctx.reply(`ℹ️ *${fresh.name}* has no sect record, so there is no time to skip.`)
      if (!skipped.length) {
        return ctx.reply(`ℹ️ *${fresh.name}* had no session, cooldown or deviation running. _Nothing was skipped._`)
      }
      const profile = fresh.sect ?? {}
      return ctx.reply([
        `🛠️ *${fresh.name}* skipped *${hours}h* of ${skipped.join(' and ')}.`,
        profile.session ? `🧘 _Session now at *${((Date.now() - profile.session.startedAt) / 3_600_000).toFixed(1)}h*._` : '',
        isDeviating(profile, Date.now()) ? `🌪️ _Still deviating: *${formatDuration(profile.deviation.until - Date.now())}* left._` : '',
        onCooldown(profile, Date.now()) ? `⏳ _Still cooling: *${formatDuration(profile.failure.until - Date.now())}* left._` : '',
        !isDeviating(profile, Date.now()) && !onCooldown(profile, Date.now()) ? `✅ _Cooldown and deviation are clear._` : '',
      ].filter(Boolean).join('\n'))
    }

    // ── Spirit Stones into a purse ──────────────────────────────────────────
    if (what === 'stones') {
      const amount = Number(value)
      if (!Number.isFinite(amount) || amount === 0) {
        return ctx.reply(`❓ *How many?* _*${p}sectgive ${target.name} stones 500*_`)
      }
      const out = await giveStones(ctx.db, jid, amount, { source: 'owner' })
      if (!out.ok) {
        const why = {
          'no-record': 'they have no cultivation record',
          'no-player': 'they are not playing',
          busy: 'another change is already in flight for them',
        }[out.reason] ?? 'that did not land'
        return ctx.reply(`⚠️ *Nothing given:* ${why}.`)
      }
      return ctx.reply(fill(currencyWords.given ?? '', {
        player: target.name,
        amount: out.added,
        total: out.total,
      }) || `🛠️ *${target.name}* is given *${out.added}* Spirit Stones. _They hold *${out.total}*._`)
    }

    // ── An item into a bag ──────────────────────────────────────────────────
    if (what === 'item' || what === 'give') {
      const word = String(value ?? '').trim()
      const count = Number(modeFirst ? words[2] : words[3]) || 1
      if (!word) return ctx.reply(`❓ *Which item?* _*${p}sectgive ${target.name} item healing_pill 3*_`)
      const entry = itemById(word)
      if (!entry) {
        return ctx.reply(`❓ *No item called \"${word}".* _Pills are in data/sect-pills.json, artifacts in data/sect-artifacts.json._`)
      }
      const out = await addItemToDb(ctx.db, jid, entry.id, count)
      if (!out.ok) {
        const why = {
          'no-record': 'they have no cultivation record',
          'no-player': 'they are not playing',
          busy: 'another change is already in flight for them',
          full: `their bag is full (${out.capacity} slots)`,
          unknown: 'that item does not exist',
        }[out.reason] ?? 'that did not land'
        return ctx.reply(`⚠️ *Nothing given:* ${why}.`)
      }
      return ctx.reply(
        `🛠️ *${target.name}* is given *${out.added}× ${entry.name}*.` +
        (out.artifact ? `\n⚔️ _${out.added} artifact record${out.added === 1 ? '' : 's'}, each its own._` : `\n🎒 _They now hold *${out.total}*._`),
      )
    }

    // ── Materials into a bag ────────────────────────────────────────────────
    if (what === 'material' || what === 'mat') {
      const word = String(value ?? '').trim().toLowerCase()
      const count = Number(modeFirst ? words[2] : words[3]) || 1
      if (!word) return ctx.reply(`❓ *Which material?* _*${p}sectgive ${target.name} material whisperleaf 5*_`)
      const entry = materialById(word)
      if (!entry) {
        return ctx.reply(`❓ *No material called \"${word}\".* _The list is data/sect-materials.json._` +
          (materialProblems.length ? `\n⚠️ _(${materialProblems.length} problems in the file.)_` : ''))
      }
      const out = await addItemToDb(ctx.db, jid, entry.id, count)
      if (!out.ok) {
        const why = {
          'no-record': 'they have no cultivation record',
          'no-player': 'they are not playing',
          busy: 'another change is already in flight for them',
          full: `their bag is full (${out.capacity} slots)`,
          unknown: 'that material does not exist',
        }[out.reason] ?? 'that did not land'
        return ctx.reply(`⚠️ *Nothing given:* ${why}.`)
      }
      return ctx.reply(
        `🌿 *${target.name}* is given *${out.added}× ${materialName(entry.id)}*.` +
        `\n🎒 _They now hold *${out.total}*.  ·  tier ${entry.tier}, ${entry.kind}._`,
      )
    }

    // ── A trade's level, set outright ───────────────────────────────────────
    if (what === 'profession' || what === 'trade') {
      const word = String(value ?? '').trim().toLowerCase()
      const level = Math.max(0, Math.min(MAX_LEVEL, Math.round(Number(modeFirst ? words[2] : words[3]) || 0)))
      const record = matchProfession(word)
      if (!record) {
        return ctx.reply(`❓ *No trade called \"${word}\".* _There are four: alchemy, forging, formations, talismans._` +
          (professionProblems.length ? `\n⚠️ _(${professionProblems.length} problems in the file.)_` : ''))
      }
      let out = null
      await updatePlayer(ctx.db, jid, pl => {
        if (!pl.sect) return pl
        ensureSectProfile(pl, { now: Date.now() })
        const book = ensureProfessions(pl.sect)
        const row = book[String(record.id)] ?? (book[String(record.id)] = { points: 0, level: 0 })
        row.level = level
        // The points are set to the foot of that level, so the next craft's
        // points still move the bar honestly rather than skipping levels.
        row.points = Math.max(levelForPoints(level), level > 0 ? levelForPoints(level) : 0)
        out = { level, points: row.points }
        return pl
      })
      const fresh = getPlayer(ctx.db, jid) ?? target
      if (!fresh.sect || !out) return ctx.reply(`⚠️ *${fresh.name}* has no cultivation record.`)
      return ctx.reply(
        `🛠️ *${fresh.name}* — *${record.name}* is set to *level ${out.level}*.` +
        (level > 0 ? `\n📖 _They know it now; the bench will take_ *${p}craft*_._` : `\n_Level zero: not learned._`),
      )
    }

    // ── That exact fight, on demand ─────────────────────────────────────────
    if (what === 'monster' || what === 'fight') {
      const word = String(value ?? '').trim().toLowerCase()
      const monster = matchMonster(word)
      if (!monster) {
        return ctx.reply(`❓ *No monster called \"${word}\".* _The list is data/sect-monsters.json._` +
          (monsterProblems.length ? `\n⚠️ _(${monsterProblems.length} problems in the file.)_` : ''))
      }
      const rawStage = Number(modeFirst ? words[2] : words[3])
      const explicit = Number.isFinite(rawStage) ? Math.max(0, Math.round(rawStage)) : null
      const refusal = startRefusal(target, { now: Date.now() })
      if (refusal) return ctx.reply(refusal)
      let state = null
      let failed = null
      const ran = await withGrowthLock(jid, async () => {
        await updatePlayer(ctx.db, jid, pl => {
          const again = startRefusal(pl, { now: Date.now() })
          if (again) { failed = again; return pl }
          ensureSectProfile(pl, { now: Date.now() })
          const mine = Number(pl.sect.stage) || 0
          const enemy = monsterEnemy(monster, { playerStage: explicit ?? mine, now: Date.now() })
          if (explicit != null) {
            enemy.stage = explicit
            enemy.playerStage = mine
          }
          state = startSectFight(pl, enemy, {
            now: Date.now(),
            real: true,
            canFlee: true,
            source: 'sect_owner',
            // The hunt's own settlement, so the drops and the day's progress
            // land exactly as they would from the wilds — this is a test of
            // that path, not a private one.
            hook: {
              kind: 'sect_hunt',
              areaId: areaById(pl.location)?.id ?? null,
              monsterId: monster.id,
              tier: monster.tier,
              role: monster.role,
              event: null,
              seed: 7,
            },
          })
          return pl
        })
      })
      if (!ran) return ctx.reply(BUSY)
      if (failed) return ctx.reply(failed)
      if (!state) return ctx.reply(`⚠️ *The fight did not start.*`)
      return ctx.reply([
        `🗡️ *${fresh0(target, ctx, jid).name}* is put up against *${monster.name}*  _(${monster.role}, tier ${monster.tier}, ${monsterStage(monster, state.a.stage)})._`,
        '',
        ...fightOpeningLines(state),
      ].join('\n'))
    }

    // ── The day's own bookkeeping, cleared ──────────────────────────────────
    if (what === 'reset') {
      let cleared = []
      await updatePlayer(ctx.db, jid, pl => {
        if (!pl.sect) return pl
        ensureSectProfile(pl, { now: Date.now() })
        const profile = pl.sect
        const had = []
        if (profile.ruinsDays && Object.keys(profile.ruinsDays).length) { profile.ruinsDays = {}; had.push('realm entries') }
        if (profile.ruins) { profile.ruins = null; had.push('the open run') }
        if (profile.huntDays) { profile.huntDays = { day: null, points: 0, kills: 0 }; had.push('the hunt cap') }
        if (profile.huntAt) { profile.huntAt = null; had.push('the hunt cooldown') }
        if (profile.gatherDays) { profile.gatherDays = { day: null, count: 0 }; had.push('the gather count') }
        if (profile.gather) { profile.gather = null; had.push('the gather in progress') }
        if (profile.professionDays) { profile.professionDays = { day: null, byProfession: {} }; had.push('trade points') }
        if (profile.plate) { profile.plate = null; had.push('the plate standing') }
        if (profile.bench) { profile.bench = null; had.push('the bench') }
        if (profile.pillDays) { profile.pillDays = { day: null, byPill: {} }; had.push('pill counts') }
        if (profile.shopDays) { profile.shopDays = {}; had.push('shop limits') }
        if (profile.taskDays) { profile.taskDays = { day: null, count: 0 }; had.push('task counts') }
        cleared = had
        return pl
      })
      const fresh = getPlayer(ctx.db, jid) ?? target
      if (!fresh.sect) return ctx.reply(`⚠️ *${fresh.name}* has no cultivation record.`)
      return ctx.reply(cleared.length
        ? `♻️ *${fresh.name}*'s day is cleared: ${cleared.join(', ')}.\n_First-clear bounties are NOT touched: those are once per account, for ever._`
        : `ℹ️ *${fresh.name}* had nothing to clear today.`)
    }

    // ── A technique handed over ─────────────────────────────────────────────
    if (what === 'technique' || what === 'teach') {
      const id = String(value ?? '').trim().toLowerCase()
      if (!id) return ctx.reply(`❓ *Which technique?* _*${p}sectgive ${target.name} technique <id>*_`)
      if (!techniqueById(id)) return ctx.reply(`❓ *No technique called "${id}".* _Techniques are written in data/sect-techniques.json._`)

      let taught = null
      await updatePlayer(ctx.db, jid, pl => {
        if (!pl.sect) return pl
        ensureSectProfile(pl, { now: Date.now() })
        taught = learnTechnique(pl.sect, id, { now: Date.now() })
        return pl
      })
      const fresh = getPlayer(ctx.db, jid) ?? target
      if (!fresh.sect) return ctx.reply(`⚠️ *${fresh.name}* has no cultivation record.`)
      if (!taught?.ok) {
        const why = {
          known: 'they already know it',
          mortal: 'they are still a Mortal: the Awakening comes first',
          tooLowRealm: `it wants *${taught?.need}*, and they are not there yet`,
          unknown: 'no technique is written under that id',
        }[taught?.reason] ?? 'that did not land'
        return ctx.reply(`⚠️ *Not taught:* ${why}.`)
      }
      const technique = taught.technique
      return ctx.reply([
        `🛠️ *${fresh.name}* learns *${technique.name}*  _(${technique.grade}, ${technique.type})._`,
        `📜 _${technique.description}_`,
        `_Slots: *${techniqueSlots(fresh.sect.stage)}* at *${fresh.sect.stageName}*. Equip it with_ *${p}skills equip ${technique.name}*_._`,
      ].join('\n'))
    }

    // ── The next roll ───────────────────────────────────────────────────────
    if (what === 'breakthrough' || what === 'roll') {
      const key = String(value ?? '').toLowerCase()
      if (key === 'clear' || key === 'none') {
        await updatePlayer(ctx.db, jid, pl => { if (pl.sect) ensureSectProfile(pl).ownerRoll = null; return pl })
        return ctx.reply(`🛠️ *${target.name}*'s next breakthrough roll is back in the mountain's hands.`)
      }
      const forced = FORCED[key]
      if (!forced) {
        return ctx.reply(`❓ *Call it how?* _*success*, *fail*, *critical* or *clear*._`)
      }
      await updatePlayer(ctx.db, jid, pl => {
        if (!pl.sect) return pl
        ensureSectProfile(pl).ownerRoll = forced
        return pl
      })
      const fresh = getPlayer(ctx.db, jid) ?? target
      if (!fresh.sect) return ctx.reply(`⚠️ *${fresh.name}* has no cultivation record.`)
      return ctx.reply(`🛠️ *${fresh.name}*'s next breakthrough will *${forced}*.`)
    }

    // ── The crossing cooldown (Prompt 8) ─────────────────────────────────
    // Owner only, like everything in this file: forget the last crossing so
    // the road will carry the target again at once, in either direction.
    if (what === 'crossing') {
      const { clearCrossingCooldown } = await import('../lib/sect-wayback.js')
      await updatePlayer(ctx.db, jid, pl => { clearCrossingCooldown(pl); return pl })
      return ctx.reply(`🛠️ *${target.name}*'s crossing cooldown is cleared. _The road will carry them now._`)
    }

    return ctx.reply(USAGE(p).join('\n'))
  },
}
