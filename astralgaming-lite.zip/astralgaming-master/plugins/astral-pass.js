/**
 * plugins/astral-pass.js — the ASTRAL PASS.
 *
 *   <prefix>astral-pass                      status + progress
 *   <prefix>astral-pass view [tier]          the ladder around you (or a tier)
 *   <prefix>astral-pass claim <tier|all>     take what tier you've reached
 *   <prefix>astral-pass buy elite [1|2]      DM ONLY — starts a Naira purchase
 *   <prefix>astral-pass confirm <who>        owner only
 *   <prefix>astral-pass reject <who>         owner only
 *   <prefix>astral-pass help
 *
 * ── The one rule that matters ───────────────────────────────────────────────
 * THE BUY PATH IS DM-ONLY, and that is not decoration. Elite is ₦5,000 a stage,
 * the flow is a private conversation with a bank transfer and a payment
 * screenshot in it, and the owner confirms it by name. Buying from a group chat
 * would post a player's payment details into a room full of people. In a group
 * every buy replies with a redirect and nothing else ever happens — no pending
 * is written, no payment details are printed.
 *
 * ── Why the purchase rides the existing flow ────────────────────────────────
 * lib/pending-purchase.js already owns "player pays, sends a screenshot, the
 * owner confirms, the grant happens" for Premium, top-ups, Mond packs and
 * season offers. `astralpass` is registered in lib/pending-confirm.js's
 * PURCHASE_KINDS like the rest, so the DM screenshot hook picks this up with no
 * new code at all: the image is saved, forwarded to the owner with the buyer's
 * JID, and flipped to pending_confirmation. This plugin only has to write the
 * pending and grant on confirm.
 *
 * ── The two stages ─────────────────────────────────────────────────────────
 *   stage 1 — ₦5,000 — `elite`     — milestones at tiers 10/20/30/40/50
 *   stage 2 — ₦5,000 — `elitePlus` — milestones at tiers 60/70/80/90/100
 * Stage 2 requires stage 1. Buying the back half on its own is refused, because
 * the pass is one ladder and the second half is meaningless without the first.
 */
import { config } from '../config.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import { updatePlayer, getPlayer } from '../lib/player-repo.js'
import { roundGems, fmtGems } from '../lib/format.js'
import { sendImage } from '../lib/image.js'
import {
  ensureAstralPassState,
  astralTierProgress,
  astralProgressPercent,
  astralRewards,
  getAstralReward,
  canClaimAstralTier,
  claimableAstralTiers,
  grantAstralReward,
  astralRewardLabel,
  eliteNeedsStageTwo,
  TIER_COUNT,
  DAILY_CAP,
  POINT_VALUES,
} from '../lib/astral-pass-engine.js'
import {
  getPending, pendingHelp, PURCHASE_KINDS, resolvePurchaseTarget,
} from '../lib/pending-confirm.js'
import { settlePlayerXp } from '../lib/player-xp.js'

const ELITE_PRICE_NAIRA = 5000

/** How many tiers one `view` shows. Wide enough to see a milestone coming. */
const VIEW_SPAN = 10

const RULE = '━━━━━━━━━━━━━━━━━━━━'

function elitePrice(pr) {
  return (
    `💠 *ELITE — ₦${ELITE_PRICE_NAIRA.toLocaleString()} per stage*\n\n` +
    `  *Stage 1* — opens *tiers 1-50*'s Elite column\n` +
    `    _milestones at 10, 20, 30, 40, 50_\n` +
    `  *Stage 2* — opens *tiers 51-100*'s Elite column\n` +
    `    _milestones at 60, 70, 80, 90, 100 · needs Stage 1 first_\n\n` +
    `Buy in DM: *${pr}astral-pass buy elite* then *${pr}astral-pass buy elite 2*.\n` +
    `_Stage 2 is a separate ₦${ELITE_PRICE_NAIRA.toLocaleString()} — the first half is yours to keep either way._`
  )
}

function helpText(pr) {
  return (
    `🌠 *THE ASTRAL PASS*\n${RULE}\n` +
    `A pass that *never resets*. ${TIER_COUNT} tiers, two columns — one for\n` +
    `everyone, one for Elite. Season ends mean nothing here.\n\n` +
    `*Earning points* _(all capped together at ${DAILY_CAP}/day)_\n` +
    `  ⚔️ Monster kill — ${POINT_VALUES.kill}\n` +
    `  💀 Boss kill — ${POINT_VALUES.boss}\n` +
    `  🕳️ Dungeon floor — ${POINT_VALUES.floor}\n` +
    `  🥊 Duel won — ${POINT_VALUES.pvp}\n` +
    `  📜 Quest — ${POINT_VALUES.quest}\n` +
    `  🎁 Daily — ${POINT_VALUES.daily}\n\n` +
    `*Commands*\n` +
    `  *${pr}astral-pass* — where you are\n` +
    `  *${pr}astral-pass view [tier]* — the ladder around you\n` +
    `  *${pr}astral-pass claim <tier|all>* — take what you've reached\n` +
    `  *${pr}astral-pass buy elite [1|2]* — _DM only_\n\n` +
    elitePrice(pr)
  )
}

/** The status card. */
function statusText(player, pr) {
  const prog = astralTierProgress(player)
  const pct = astralProgressPercent(player)
  const p = ensureAstralPassState(player)
  const claimable = claimableAstralTiers(player)

  const nextMilestone = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100].find((t) => t > prog.tier)
  const lines = [
    `🌠 *THE ASTRAL PASS*`,
    RULE,
    `*Tier ${prog.tier}/${prog.tierCount}* — ${pct}% of the pass`,
    `_${prog.into.toLocaleString()} / ${prog.span.toLocaleString()} into this tier · ${prog.toNext.toLocaleString()} to the next_`,
    ``,
    `⭐ Points: *${prog.points.toLocaleString()}*`,
    `📈 Today: *${prog.dailyUsed}/${prog.dailyCap}* _(${prog.dailyLeft} left before the cap)_`,
    ``,
    p.elitePlus
      ? `💠 Elite *complete* — every milestone is open`
      : p.elite
        ? `💠 Elite *1-50* held · Stage 2 (51-100) not bought`
        : `🔒 Elite *not unlocked*`,
  ]

  if (claimable.length) {
    lines.push(``, `🎁 *${claimable.length} reward${claimable.length === 1 ? '' : 's'} ready* — *${pr}astral-pass claim all*`)
  } else if (nextMilestone) {
    lines.push(``, `🎯 Next milestone: *tier ${nextMilestone}*`)
  }

  lines.push(``, `*${pr}astral-pass view* · *${pr}astral-pass help*`)
  return lines.join('\n')
}

/** A window of the ladder, free column and Elite column side by side. */
function viewText(player, rawTier, pr) {
  const p = ensureAstralPassState(player)
  const all = astralRewards()
  const explicit = Number(rawTier)
  const from = Number.isFinite(explicit) && explicit >= 1
    ? Math.max(1, Math.min(Math.floor(explicit), TIER_COUNT - VIEW_SPAN + 1))
    : Math.max(1, Math.min(p.tier - 2, TIER_COUNT - VIEW_SPAN + 1))
  const rows = all.filter((r) => r.tier >= from && r.tier < from + VIEW_SPAN)

  const lines = [`🌠 *ASTRAL PASS — tiers ${from}-${from + VIEW_SPAN - 1}*`, RULE]
  for (const row of rows) {
    const reached = row.tier <= p.tier
    const freeDone = p.claimed.includes(row.tier)
    const eliteDone = p.claimedElite.includes(row.tier)
    const mark = reached ? '🔓' : '🔒'
    const freeLine = `${freeDone ? '✅' : reached ? '🎁' : '·'} ${astralRewardLabel(row.free)}`
    lines.push(`${mark} *${row.tier}*  ${freeLine}`)
    if (row.elite) {
      const stageTwo = eliteNeedsStageTwo(row.tier)
      const owned = stageTwo ? p.elitePlus : p.elite
      const gate = owned ? (eliteDone ? '✅' : reached ? '💠' : '💠') : '🔐'
      lines.push(`      ${gate} _Elite:_ *${astralRewardLabel(row.elite)}*`)
    }
  }
  lines.push(``, `_🎁 ready · ✅ claimed · 🔒 not reached · 🔐 Elite not bought_`)
  const claimable = claimableAstralTiers(player)
  if (claimable.length) lines.push(``, `*${claimable.length} ready* — *${pr}astral-pass claim all*`)
  return lines.join('\n')
}

/**
 * claimAstral(ctx, player, query) -> message
 *
 * Runs the WHOLE claim inside one updatePlayer mutator so a player cannot fire
 * two claims at once and take the same tier twice — the same reasoning
 * plugins/season.js's claimPassRewards uses. Inventory room is re-checked per
 * reward inside the mutator because a multi-tier claim can run out mid-way, and
 * the tiers it did manage are kept rather than rolled back: a partial claim that
 * reports exactly what it took is better than a refusal that loses the rest.
 */
async function claimAstral(ctx, player, query) {
  const raw = String(query ?? '').toLowerCase()
  const outcome = { kind: null }

  await updatePlayer(ctx.db, ctx.from, (p) => {
    // `p` is the PLAYER; the pass is `state`. Discarding this return value was a
    // live bug — the claim loop below writes `state.claimed`/`state.claimedElite`
    // but was writing them onto the player, where `push` is undefined, so every
    // single claim threw inside the mutator and no reward was ever paid.
    const state = ensureAstralPassState(p)

    let targets
    if (raw === 'all' || raw === '') {
      targets = claimableAstralTiers(p)
      if (!targets.length) {
        outcome.kind = 'none'
        return
      }
    } else {
      const tier = Number(raw)
      if (!Number.isFinite(tier)) { outcome.kind = 'bad'; return }
      targets = []
      for (const column of ['free', 'elite']) {
        const check = canClaimAstralTier(p, tier, column)
        if (check.ok) targets.push({ tier, column })
        else if (column === 'elite' && check.reason === 'noelite') {
          // The player asked for THIS tier by number, so a half-claim must say
          // why the other half did not come. Silently paying the free column
          // reads as the Elite item having gone missing.
          outcome.eliteLocked = tier
        }
      }
      if (!targets.length) {
        // Nothing claimable at that tier — report the FIRST reason, which is
        // the one the player actually needs to act on.
        const free = canClaimAstralTier(p, tier, 'free')
        const elite = canClaimAstralTier(p, tier, 'elite')
        outcome.kind = 'refused'
        outcome.message = (!free.ok ? free.message : elite.message)
        return
      }
    }

    const taken = []
    const labels = []
    let fused = null
    let full = null

    for (const { tier, column } of targets) {
      const check = canClaimAstralTier(p, tier, column)
      if (!check.ok) {
        if (check.reason === 'full') { full = check.message; break }
        continue
      }
      const out = grantAstralReward(p, check.reward)
      if (out.refused) { full = `❌ *${out.refused}* cannot be granted from the pass.`; break }
      if (column === 'elite') state.claimedElite.push(tier)
      else state.claimed.push(tier)
      taken.push(column === 'elite' ? `${tier}💠` : `${tier}`)
      labels.push(...out.granted)
      if (out.fused) fused = out.fused
    }

    if (!taken.length) {
      outcome.kind = 'none'
      return
    }
    outcome.kind = 'ok'
    outcome.taken = taken
    outcome.labels = labels
    outcome.fused = fused
    outcome.full = full
    outcome.tier = state.tier
    outcome.lvlMsgs = settlePlayerXp(p).msgs ?? []
  })

  if (outcome.kind === 'bad') return ctx.reply(`❌ Usage: *${config.prefix}astral-pass claim <tier|all>*`)
  if (outcome.kind === 'refused') return ctx.reply(outcome.message)
  if (outcome.kind === 'none') {
    const prog = astralTierProgress(player)
    return ctx.reply(
      `ℹ️ Nothing to claim right now.\n` +
      `You are at *tier ${prog.tier}* — ${prog.toNext.toLocaleString()} points to the next one.`,
    )
  }

  const lines = [
    `🎁 *ASTRAL PASS REWARDS CLAIMED*`,
    RULE,
    `Tiers: *${outcome.taken.join(', ')}*`,
    ``,
    ...outcome.labels.map((l) => `• ${l}`),
  ]
  if (outcome.fused) {
    lines.push(
      ``,
      `👑 *The crowns have fused.*`,
      `_Owning both Queen Esta and King Yato replaces the pair with **Queen-King** — one character, two crowns. Neither half comes back, and that includes the second one you just claimed._`,
    )
  }
  if (outcome.full) lines.push(``, outcome.full)
  if (outcome.eliteLocked && !outcome.taken.some((t) => t.endsWith('💠'))) {
    lines.push(
      ``,
      `💠 *Tier ${outcome.eliteLocked}'s Elite reward is still locked.*`,
      `_Your points already cover it — the Elite column opens when you buy a stage._`,
    )
  }
  lines.push(``, `_Now at tier *${outcome.tier}*._`)
  if (outcome.lvlMsgs?.length) lines.push(``, ...outcome.lvlMsgs)
  return ctx.reply(lines.join('\n'))
}

// ── Buying Elite ────────────────────────────────────────────────────────────

async function handleBuy(ctx) {
  const pr = config.prefix

  // THE DM-ONLY RULE. Before anything else, before the player is even read —
  // a group must not learn whether this player could afford it, and nothing
  // may be written.
  if (ctx.isGroup) {
    return ctx.reply(
      `💬 *I'll DM you the details.*\n\n` +
      `Elite is a paid unlock, so the payment side happens privately:\n` +
      `open my DM and send *${pr}astral-pass buy elite*.\n\n` +
      `_This command does nothing in a group._`,
    )
  }

  // A DM that cannot be matched to an account (never registered, or a number
  // not linked yet) used to crash inside updatePlayer and answer nothing.
  if (!ctx.player) {
    return ctx.reply(`⚠️ I can't find your account from this chat. Register or link it first (*${pr}register*, or *${pr}code* to link), then send *${pr}elite buy* again.`)
  }

  const stageArg = String(ctx.args[2] ?? '1').trim()
  const stage = stageArg === '2' ? 2 : stageArg === '1' ? 1 : null
  if (!stage) {
    return ctx.reply(
      `❌ Unknown stage *"${stageArg}"*.\n\n` +
      `*${pr}astral-pass buy elite*  — stage 1, tiers 1-50\n` +
      `*${pr}astral-pass buy elite 2* — stage 2, tiers 51-100`,
    )
  }

  let refusal = null
  await updatePlayer(ctx.db, ctx.from, (p) => {
    const state = ensureAstralPassState(p)
    if (stage === 1 && state.elite) { refusal = `✅ You already hold *Elite 1-50*. Use *${pr}astral-pass buy elite 2* for the second half.`; return }
    if (stage === 2 && state.elitePlus) { refusal = `✅ You already hold *Elite 51-100*. Your pass is complete.`; return }
    // Stage 2 is meaningless without stage 1 — the ladder is one climb and the
    // back half grants nothing a player can claim. Refused rather than sold.
    if (stage === 2 && !state.elite) {
      refusal = `💠 *Stage 1 first.*\n\nTiers 51-100 sit on top of tiers 1-50 — buy *${pr}astral-pass buy elite* first, then come back for the second half.`
      return
    }
    // A receipt already sent and waiting for the owner is never overwritten.
    if (p.astralPassPending?.state === 'pending_confirmation') {
      refusal = `⏳ Your Elite payment is already with the owner, waiting to be confirmed. It will unlock as soon as it is checked.`
      return
    }
    p.astralPassPending = { stage, priceNaira: ELITE_PRICE_NAIRA, state: 'awaiting_screenshot', at: Date.now() }
  })

  if (refusal) return ctx.reply(refusal)

  const pay = config.payment
  const scope = stage === 1 ? 'Tiers 1-50' : 'Tiers 51-100'
  return ctx.reply(
    `💠 *ASTRAL PASS ELITE — Stage ${stage}*\n${RULE}\n` +
    `Opens: *${scope}*'s Elite column\n` +
    `Price: *₦${ELITE_PRICE_NAIRA.toLocaleString()}*\n\n` +
    `💳 *Payment details:*\n` +
    `  🏦 Bank: *${pay.bankName || '(not configured)'}*\n` +
    `  🔢 Account: *${pay.accountNumber || '(not configured)'}*\n` +
    `  👤 Name: *${pay.accountName || '(not configured)'}*\n\n` +
    `📸 Once paid, send a screenshot of the transfer *right here in this DM*.\n` +
    `_Nothing is unlocked until the transfer is confirmed — your progress keeps counting in the meantime, and tiers you have already passed stay claimable._`,
  )
}

async function handleConfirm(ctx) {
  if (!isOwnerJid(ctx.from)) return ctx.reply(`❌ Owner only.`)
  const pr = config.prefix
  const query = ctx.args.slice(1).join(' ').trim()
  if (!query) return ctx.reply(`Usage: *${pr}astral-pass confirm <player name or number>*`)

  const found = resolvePurchaseTarget(ctx.db, query)
  if (!found) {
    return ctx.reply(`❌ No player found matching *"${query}"*.` + pendingHelp(ctx.db, { prefix: pr }))
  }

  const kind = PURCHASE_KINDS.astralpass
  const pending = getPlayer(ctx.db, found.key)?.[kind.field]
  if (!pending) {
    return ctx.reply(`❌ *${found.name}* has no Astral Pass purchase waiting.` + pendingHelp(ctx.db, { prefix: pr }))
  }

  const stage = pending.stage === 2 ? 2 : 1
  await updatePlayer(ctx.db, found.key, (p) => {
    const state = ensureAstralPassState(p)
    if (stage === 1) state.elite = true
    else { state.elitePlus = true; state.elite = true }
    p[kind.field] = null
  })

  const fresh = getPlayer(ctx.db, found.key)
  return ctx.reply(
    `✅ *Astral Pass Elite${stage === 2 ? ' 51-100' : ' 1-50'}* unlocked for *${found.name}*.\n` +
    `_Stage ${stage} · ₦${ELITE_PRICE_NAIRA.toLocaleString()} · tier ${ensureAstralPassState(fresh)?.tier ?? 0}/100_\n` +
    (stage === 2
      ? `The pass is complete — every milestone is now open.`
      : `Tiers 10-50's Elite rewards are open. Stage 2 (51-100) is a separate ₦${ELITE_PRICE_NAIRA.toLocaleString()}.`),
  )
}

async function handleReject(ctx) {
  if (!isOwnerJid(ctx.from)) return ctx.reply(`❌ Owner only.`)
  const pr = config.prefix
  const query = ctx.args.slice(1).join(' ').trim()
  if (!query) return ctx.reply(`Usage: *${pr}astral-pass reject <player name or number>*`)

  const found = resolvePurchaseTarget(ctx.db, query)
  if (!found) {
    return ctx.reply(`❌ No player found matching *"${query}"*.` + pendingHelp(ctx.db, { prefix: pr }))
  }
  const kind = PURCHASE_KINDS.astralpass
  const pending = getPlayer(ctx.db, found.key)?.[kind.field]
  if (!pending) {
    return ctx.reply(`❌ *${found.name}* has no Astral Pass purchase waiting.` + pendingHelp(ctx.db, { prefix: pr }))
  }
  await updatePlayer(ctx.db, found.key, (p) => { p[kind.field] = null })
  return ctx.reply(`🚫 Astral Pass purchase for *${found.name}* rejected and cleared.`)
}

export default {
  name: 'astral-pass',
  aliases: ['astralpass', 'apass', 'ap'],
  category: 'season',
  requiresPlayer: false,
  description: 'The permanent Astral Pass — 100 tiers that never reset',
  subcommands: [
    { cmd: '', desc: 'your Astral Pass progress' },
    { cmd: 'view [tier]', desc: 'the ladder around you, or around a tier' },
    { cmd: 'claim <tier|all>', desc: 'claim the rewards you have reached' },
    { cmd: 'buy elite [1|2]', desc: 'unlock Elite — DM only, ₦5,000 per stage' },
    { cmd: 'help', desc: 'how the pass works and how points are earned' },
  ],

  async run(ctx) {
    const pr = config.prefix
    const action = String(ctx.args[0] ?? '').toLowerCase()

    if (action === 'help' || action === 'how') return ctx.reply(helpText(pr))

    // The purchase path is readable without a player record (a group redirect
    // must reach an unregistered member too), so it is answered before the
    // player gate below.
    if (action === 'buy') return handleBuy(ctx)
    if (action === 'confirm') return handleConfirm(ctx)
    if (action === 'reject') return handleReject(ctx)

    if (!ctx.player) return ctx.reply(`⚠️ Register first with *${pr}register*.`)
    const player = ctx.player

    if (action === 'view' || action === 'ladder' || action === 'tiers') {
      return ctx.reply(viewText(player, ctx.args[1], pr))
    }
    if (action === 'claim' || action === 'collect') {
      return claimAstral(ctx, player, ctx.args[1])
    }
    if (action === 'elite' || action === 'price') {
      return ctx.reply(elitePrice(pr))
    }
    if (action === '' || action === 'status' || action === 'info') {
      return sendImage(ctx, 'astral-pass', statusText(player, pr))
    }
    if (action === 'points' || action === 'how-points') {
      return ctx.reply(helpText(pr))
    }

    return ctx.reply(
      `Usage: *${pr}astral-pass* · *${pr}astral-pass view* · *${pr}astral-pass claim all*\n` +
      `_Full guide: *${pr}astral-pass help*_`,
    )
  },
}
