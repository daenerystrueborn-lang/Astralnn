/**
 * gate.js — the gate pillar's command surface.
 *
 *   .gate                 the board: what is open here, who took the last one,
 *                         and when the next gate opens. Inside a gate it shows
 *                         the fight instead.
 *   .gate enter [code]    claim a gate (the same thing `.enter <code>` does)
 *   .gate attack|skill|defend|flee
 *                         the fight verbs, also reachable as plain .attack /
 *                         .skill / .defend / .flee while a gate run is live
 *   .gate me              your gate record (clears, failures, Red Gates)
 *   .gate ranks           the difficulty ladder and what each rank pays
 *   .gate on|off          group staff: let gates open here, or stop them
 *   .gate spawn           owner only: open a gate in this group right now
 *
 * The mechanics live in lib/gate-engine.js (pure), lib/gate-state.js (the claim
 * lock) and lib/gate-actions.js (the command side). This file is routing and the
 * two admin toggles, so there is exactly one copy of every rule.
 */
import { config } from '../config.js'
import { isOwnerJid, NOT_GROUP, NOT_STAFF } from '../lib/group-helpers.js'
import { isPlatformOwner } from '../lib/platform/permissions.js'
import { isBotStaff, saveGroupSettings, saveFailedMessage } from '../lib/group-settings.js'
import { gateStatus, enterGate, gateTurn, gateRanksText } from '../lib/gate-actions.js'
import { gateRecordCard, buildGate, gateSpawnCard, GATES } from '../lib/gate-engine.js'
import { putGate } from '../lib/gate-state.js'
import { gateSeason, invalidateGateGroupCache, groupAcceptsGates } from '../lib/gate-spawns.js'
import { sendImage } from '../lib/image.js'

export default {
  name: 'gate',
  aliases: ['gates', 'gateboard'],
  category: 'dungeon',
  requiresPlayer: false,
  description: `${config.prefix}gate — the gates open in this chat, and the fight inside one`,

  async run(ctx) {
    const sub = String(ctx.args?.[0] ?? '').toLowerCase()
    const p = ctx.platform === 'telegram' ? config.telegramPrefix : config.prefix
    const season = gateSeason(ctx.db)

    // The whole pillar is dormant until Season 2 is the active season: no
    // board, no ranks, no entry, no owner spawn, no toggles. Nothing about it
    // activates early.
    if (!season) {
      return ctx.reply('🚪 Gates open when Season 2 begins. Nothing is open yet.')
    }

    // ── group staff: gates on/off ───────────────────────────────────────────
    if (sub === 'on' || sub === 'off') {
      if (!ctx.isGroup) return ctx.reply(NOT_GROUP)
      if (!(await isBotStaff(ctx))) return ctx.reply(NOT_STAFF)
      const want = sub === 'on'
      const res = await saveGroupSettings(ctx.sender, s => { s.gatesEnabled = want })
      if (!res.ok) return ctx.reply(saveFailedMessage('gates', res.error))
      invalidateGateGroupCache()
      return ctx.reply(
        want
          ? `🚪 Gates will open in this group. *${GATES.spawnsPerDay}* a day, first *${p}enter* owns one.`
          : `🚪 Gates are *off* in this group. Nothing will open here until a mod runs *${p}gate on*.`,
      )
    }

    // ── owner: open one right now ───────────────────────────────────────────
    if (sub === 'spawn' || sub === 'open') {
      // The OWNER is the sender, not the group jid. Checking ctx.sender here
      // refused the owner in every group because a group jid is never an owner.
      if (!isPlatformOwner(ctx.from) && !isOwnerJid(ctx.from)) return ctx.reply('🔒 That is an owner command.')
      if (!ctx.isGroup) return ctx.reply(NOT_GROUP)
      let meta = null
      try { meta = await ctx.sock?.groupMetadata?.(ctx.sender) } catch { meta = null }
      if (!(await groupAcceptsGates(ctx.sender, meta))) {
        return ctx.reply(`🚪 This group does not accept gates. A mod must run *${p}gate on* first (and it cannot be an announcement or another game's room).`)
      }
      const gate = buildGate({ groupId: ctx.sender, now: Date.now(), seed: `${ctx.sender}:manual:${Date.now()}` })
      const caption = gateSpawnCard(gate, { prefix: p })
      try {
        await sendImage(ctx, gate.art, caption)
      } catch {
        await ctx.reply(caption)
      }
      await putGate(gate)
      invalidateGateGroupCache()
      return
    }

    if (sub === 'ranks' || sub === 'rank' || sub === 'tiers') return ctx.reply(gateRanksText())

    if (sub === 'me' || sub === 'record' || sub === 'stats') {
      return ctx.reply(gateRecordCard(ctx.player, { prefix: p }))
    }

    if (sub === 'enter' || sub === 'claim' || sub === 'join') {
      const code = ctx.args?.[1] ?? null
      await enterGate(ctx, { code, explicit: true })
      return
    }

    if (['attack', 'skill', 'defend', 'flee', 'run'].includes(sub)) {
      const kind = sub === 'run' ? 'flee' : sub
      const target = Number.parseInt(ctx.args?.[1], 10)
      const handled = await gateTurn(ctx, { kind, target: Number.isInteger(target) && target > 0 ? target - 1 : 0 })
      if (!handled) await ctx.reply(`🚪 You are not inside a gate. *${p}gate* shows what is open.`)
      return
    }

    if (sub === 'help' || sub === '?') {
      return ctx.reply(
        `「 🚪 𝐆𝐀𝐓𝐄 」\n\n` +
        `*${p}gate* — the board in this chat\n` +
        `*${p}enter <code>* — claim the open gate (first in owns it)\n` +
        `*${p}attack* · *${p}skill* · *${p}defend* · *${p}flee* — inside the gate\n` +
        `*${p}gate me* — your record · *${p}gate ranks* — the ladder\n` +
        `*${p}gate on/off* — staff: opt this group in or out of gates\n\n` +
        (season
          ? `_Gates open ${GATES.spawnsPerDay} times a day while ${season.name} runs, but only in groups that run ${p}gate on._`
          : `_Gates open with the season that carries them. None is running right now._`),
      )
    }

    // A bare code (`.gate G-7KQ4`) is an entry, because that is what a player
    // holding a code means by it.
    if (/^g-?[a-z0-9]{4}$/i.test(sub)) {
      await enterGate(ctx, { code: sub, explicit: true })
      return
    }

    await gateStatus(ctx)
  },
}
