/**
 * plugins/payorders.js — the owner's side of the Mini App's Pay page.
 *
 *   .payoutbox / .paybox        what is waiting (id, who, what, how long)
 *   .payverify <id>             money arrived → grant the goods, tell the player
 *   .payreject <id> <reason>    money did not arrive / does not match
 *
 * All three are OWNER ONLY, on every platform: the order book is money, and a
 * mod is not the owner. `isPlatformOwner()` understands the namespaced ids
 * (tg:…, wa:…) so the same check works in a Telegram DM and in WhatsApp;
 * `isOwnerJid()` is added for the WhatsApp spelling of the owner's own number.
 *
 * The work itself — the write, the grant, the player's notification, the
 * idempotence — is lib/pay-orders.js. This file is routing and wording only,
 * so a tap on the Telegram keyboard (adapters/telegram/adapter.js) and a typed
 * command end in exactly the same function.
 *
 * WHY REJECT NEEDS A REASON: the whole point of the DM is that a player who
 * paid can be told why their proof was refused ("the screenshot is cut off",
 * "that was the weekly price, not monthly"). A bare rejection is the thing the
 * user asked to stop. Empty reasons are refused here and the command is
 * re-asked rather than stored as "rejected".
 */
import { config } from '../config.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import { isPlatformOwner } from '../lib/platform/permissions.js'
import {
  askRejectionReason,
  clearRejection,
  decidePayOrder,
  decisionText,
  getPayOrder,
  pendingOrderLines,
  rejectionReason,
} from '../lib/pay-orders.js'

/** The owner, whichever id this platform handed us. */
function isDesk(ctx) {
  return isPlatformOwner(ctx.platformId) || isPlatformOwner(ctx.from) || isOwnerJid(ctx.from)
}

function keyFor(ctx) {
  return String(ctx.platformId || ctx.from || '')
}

/** `.payverify AP-7K3M9Q` — one order, verified. */
async function verify(ctx) {
  const { reply, db, args } = ctx
  const id = String(args[0] ?? '').trim()
  if (!id) {
    return reply(
      `*Usage:* ${config.prefix}payverify <order id>\n` +
      `*See what is waiting:* ${config.prefix}payoutbox`,
    )
  }
  const known = getPayOrder(db, id)
  if (!known) return reply(`❌ No order with that id. ${config.prefix}payoutbox lists the open ones.`)

  // An open "why?" from a previous tap is answered by this decision instead.
  clearRejection(keyFor(ctx))
  const result = await decidePayOrder(db, id, { status: 'verified', decidedBy: keyFor(ctx) })
  return reply(decisionText(result))
}

/** `.payreject AP-7K3M9Q <reason>` — one order, refused, with words. */
async function reject(ctx) {
  const { reply, db, args } = ctx
  const id = String(args[0] ?? '').trim()
  const reason = args.slice(1).join(' ').trim()
  if (!id) {
    return reply(
      `*Usage:* ${config.prefix}payreject <order id> <reason>\n` +
      `*See what is waiting:* ${config.prefix}payoutbox`,
    )
  }
  const known = getPayOrder(db, id)
  if (!known) return reply(`❌ No order with that id. ${config.prefix}payoutbox lists the open ones.`)

  if (!reason) {
    // Ask for the words. On Telegram the next plain message from the owner is
    // taken as the reason (adapters/telegram/adapter.js); on WhatsApp they
    // simply send the command again with the reason on the end.
    askRejectionReason(keyFor(ctx), id)
    return reply(
      `✍️ *Why is ${known.id} being rejected?*\n\n` +
      `The player is shown this line in the app, so make it useful — ` +
      `"the screenshot is cut off" or "that is the weekly price".\n\n` +
      `Reply with the reason, or send:\n` +
      `${config.prefix}payreject ${known.id} <reason>`,
    )
  }

  clearRejection(keyFor(ctx))
  const result = await decidePayOrder(db, id, {
    status: 'rejected',
    reason: rejectionReason({ reason }),
    decidedBy: keyFor(ctx),
  })
  return reply(decisionText(result))
}

export default {
  name:        'payverify',
  aliases:     ['payreject', 'payoutbox', 'paybox'],
  category:    'admin',
  description: 'Verify or reject a Mini App payment proof (owner only)',

  async run(ctx) {
    if (!isDesk(ctx)) {
      return ctx.reply('🔒 Owner only — this is the payment desk.')
    }

    const cmd = String(ctx.cmd || '').toLowerCase()
    if (cmd === 'payoutbox' || cmd === 'paybox') {
      return ctx.reply(pendingOrderLines(ctx.db))
    }
    if (cmd === 'payreject') return reject(ctx)
    return verify(ctx)
  },
}
