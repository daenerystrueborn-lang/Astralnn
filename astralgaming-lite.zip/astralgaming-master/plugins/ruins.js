/**
 * ruins.js — `.ruins`: the three secret realms, walked one room at a time.
 *
 * Every rule is lib/sect-ruins.js's: one entry a realm a day (midnight WAT,
 * the mountain's own day),
 * the run saved between rooms, the recovery, the special rooms, the boss at the
 * end, the half-kept hoard on a loss, and the first-clear bounty that is paid
 * once per account for ever.
 *
 *   .ruins                      the realms, and the run you have open
 *   .ruins <realm>              go in (spends the day's entry)
 *   .ruins next                 the next room of an open run
 *   .ruins leave                walk out between rooms, keeping everything
 */
import { config } from '../config.js'
import { sectDoorRefusal, missingSectRecordRefusal } from '../lib/world-guards.js'
import { ruinsCommand, ruinsScreen } from '../lib/sect-ruins.js'
import '../lib/sect-hooks.js'


export default {
  name: 'ruins',
  aliases: ['realm', 'realms', 'secretrealm'],
  category: 'event',
  requiresPlayer: true,
  description: `${config.prefix}ruins [realm|next|leave] — one room at a time into a secret realm`,

  async run(ctx) {
    const player = ctx.player
    const wrongWorld = sectDoorRefusal(player, {
      emoji: '🗝️', title: '*Secret realms belong to the Sect Empire.*',
      here: { cmd: 'dungeon', label: 'raid an Astra dungeon instead' },
    })
    if (wrongWorld) return ctx.reply(wrongWorld)
    if (!player.sect) return ctx.reply(missingSectRecordRefusal())
    const first = String((ctx.args ?? [])[0] ?? '').toLowerCase()
    if (first === 'list' || first === 'where') {
      return ctx.reply(ruinsScreen(player, { prefix: config.prefix }).join('\n'))
    }
    return ruinsCommand(ctx, { now: Date.now() })
  },
}
