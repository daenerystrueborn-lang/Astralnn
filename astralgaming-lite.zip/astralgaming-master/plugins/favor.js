/**
 * favor.js — how the people of Astral Town feel about you.
 *
 *   .favor              everyone, one line each
 *   .favor <person>     one person up close: where they are, what they like,
 *                       and what each tier gives
 *
 * Read only. Favor grows with `.talk` (once a day each) and `.gift` (once a day
 * each); see lib/town-favor.js.
 */
import { config } from '../config.js'
import { findNpc } from '../lib/town.js'
import { favorListView, favorCardView, hasFavorData } from '../lib/town-favor.js'

export default {
  name: 'favor',
  aliases: ['favour', 'bonds'],
  category: 'town',
  requiresPlayer: true,
  description: 'How the people of Astral Town feel about you',
  subcommands: [
    { cmd: '<person>', desc: 'one person up close: where they are, what they like, what each tier gives' },
  ],

  async run(ctx) {
    const p = config.prefix
    const query = ctx.args.join(' ').trim()
    if (!query) return ctx.reply(favorListView(ctx.player, p))
    const npc = findNpc(query)
    if (!npc || !hasFavorData(npc.id)) {
      return ctx.reply(`❓ Nobody in town goes by *${query}*. *${p}favor* lists everyone.`)
    }
    return ctx.reply(favorCardView(ctx.player, npc, p))
  },
}
