import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { kitxCapacity } from '../lib/starter-pack-engine.js'
import {
  clearKitxLoadout,
  listKitxLoadouts,
  restoreKitxLoadout,
  saveKitxLoadout,
} from '../lib/kitx-engine.js'

const inBattle = (player) => !!(player?.inBattle || player?.battleState)

function helpText() {
  const p = config.prefix
  return (
    `🧰 *KITX LOADOUTS*\n\n` +
    `Save and restore your owned gear and item positions. Loading never creates items.\n\n` +
    `*${p}kitx save <name>* — save your current loadout\n` +
    `*${p}kitx load <name>* — restore a saved loadout (not during battle)\n` +
    `*${p}kitx list* — show saved loadouts\n` +
    `*${p}kitx clear <name|all>* — delete a saved loadout\n\n` +
    `_Capacity comes from the highest Starter Pack tier you own._`
  )
}

function listText(player) {
  const p = config.prefix
  const capacity = kitxCapacity(player)
  const entries = listKitxLoadouts(player)
  if (!capacity) return `🔒 KitX is locked. Buy a Starter Pack to save loadouts.`
  if (!entries.length) {
    return `🧰 *KITX* _(${entries.length}/${capacity})_\n\n_No saved loadouts yet._\nUse *${p}kitx save <name>* to create one.`
  }
  const lines = entries.map(({ name, savedAt }) => {
    const when = savedAt ? new Date(savedAt).toLocaleDateString('en-GB') : 'unknown date'
    return `• *${name}* _saved ${when}_`
  })
  return `🧰 *KITX LOADOUTS* _(${entries.length}/${capacity})_\n\n${lines.join('\n')}\n\nUse *${p}kitx load <name>* to restore one.`
}

export default {
  name: 'kitx',
  aliases: [],
  category: 'inventory',
  requiresPlayer: true,
  description: `${config.prefix}kitx save/load/list/clear loadouts.`,

  async run(ctx) {
    const sub = String(ctx.args[0] ?? '').toLowerCase()
    const name = ctx.args.slice(1).join(' ').trim()

    if (sub === 'list') return ctx.reply(listText(ctx.player))
    if (sub === 'save') {
      if (!name) return ctx.reply(`❌ Usage: *${config.prefix}kitx save <name>*`)
      let result
      await updatePlayer(ctx.db, ctx.from, (player) => {
        result = saveKitxLoadout(player, name)
        return player
      })
      if (result.reason === 'locked') return ctx.reply(`🔒 Buy a Starter Pack before saving KitX loadouts.`)
      if (result.reason === 'name') return ctx.reply(`❌ Use a name of 1–30 letters, numbers, spaces, hyphens, or underscores.`)
      if (result.reason === 'full') {
        return ctx.reply(`❌ Your KitX is full (${result.capacity} loadouts). Clear one with *${config.prefix}kitx clear <name>* first.`)
      }
      return ctx.reply(`✅ *${result.overwritten ? 'Updated' : 'Saved'} KitX loadout:* _${result.name}_\n${result.count}/${result.capacity} slots used.`)
    }

    if (sub === 'load') {
      if (!name) return ctx.reply(`❌ Usage: *${config.prefix}kitx load <name>*`)
      if (inBattle(ctx.player)) return ctx.reply(`⚔️ You can't load a KitX loadout during battle.`)
      let result
      await updatePlayer(ctx.db, ctx.from, (player) => {
        if (inBattle(player)) {
          result = { ok: false, reason: 'battle' }
          return player
        }
        result = restoreKitxLoadout(player, name)
        return player
      })
      if (result.reason === 'battle') return ctx.reply(`⚔️ You can't load a KitX loadout during battle.`)
      if (result.reason === 'missing') return ctx.reply(`❌ No KitX loadout named _${name}_. Use *${config.prefix}kitx list* to see your saves.`)
      if (result.reason === 'capacity') {
        const notices = (result.notices ?? []).slice(0, 4).join('\n')
        return ctx.reply(`❌ There isn't enough free bag/storage space to load that without losing items. Nothing changed.${notices ? `\n\n${notices}` : ''}`)
      }
      const lines = [`✅ *Loaded KitX loadout:* _${result.name}_`]
      if (result.fallbacks.length) {
        lines.push('', `Closest owned matches used:`, ...result.fallbacks.slice(0, 8).map((line) => `• ${line}`))
      }
      if (result.notices.length) {
        lines.push('', ...result.notices.slice(0, 8).map((line) => `ℹ️ ${line}`))
      }
      if (result.fallbacks.length + result.notices.length > 8) lines.push(`…and more unmatched/relocated positions.`)
      return ctx.reply(lines.join('\n'))
    }

    if (sub === 'clear') {
      if (!name) return ctx.reply(`❌ Usage: *${config.prefix}kitx clear <name|all>*`)
      let result
      await updatePlayer(ctx.db, ctx.from, (player) => {
        result = clearKitxLoadout(player, name)
        return player
      })
      if (!result.ok) return ctx.reply(`❌ No saved KitX loadout named _${name}_.`)
      return ctx.reply(result.all
        ? `🗑️ Cleared ${result.cleared} KitX loadout${result.cleared === 1 ? '' : 's'}.`
        : `🗑️ Cleared KitX loadout _${result.name}_.`)
    }

    if (!sub) return ctx.reply(helpText())
    return ctx.reply(`❌ Unknown KitX action.\n\n${helpText()}`)
  },
}
