/**
 * <prefix>yu-miaoyi-spin <amount>
 *
 * Yu Miaoyi — global-exclusive gem spin. A direct copy of
 * plugins/envy-spin.js's shape (same global-lock pattern via
 * getExclusiveSpinWinner()/claimExclusiveSpinForPlayer() in
 * lib/season-engine.js, same batch/pity-bar presentation, same flat-plateau
 * odds curve). Only ONE player, bot-wide, can ever obtain her — and the Mond
 * shop purchase (.character buy yu_miaoyi) claims THE SAME one-of-one lock,
 * so spin and shop can never both succeed. First claim wins; the loser is
 * charged nothing (the lock is checked before gems move, and again before
 * every single spin in a batch).
 *
 * Odds curve (via chanceForExclusiveSpin):
 *   spins 1-200   -> 0%     (DEAD_ZONE_UNTIL = 200, a true dead zone: nobody
 *                            can win her in the first 200 spins no matter how
 *                            many gems burn)
 *   spins 201-240 -> 80%    (PLATEAU_CHANCE = 0.80, flat, per spin)
 *   PITY_AT = 9999: there is deliberately NO guaranteed spin inside the cap —
 *                            240 spins is the lifetime ceiling, and the pity
 *                            bar shows progress toward that ceiling only.
 * These numbers are never printed in player-facing copy — not the dead zone,
 * not the chance, not any threshold — only the pity bar (progress toward the
 * spin cap) is shown, matching every other exclusive spin's "never reveals
 * the plateau" rule.
 *
 * 0.8 Gems per spin (fractional cost — every read/write/display goes through
 * roundGems()/fmtGems() so 240 pulls can never drift past 192 gems). Max 240
 * spins per player. Or skip the grind entirely: 5 Monds buys her outright
 * with .character buy yu_miaoyi — same lock, first claim wins.
 *
 * ART: character.image is her info portrait (a .webp still), so
 * replyOverArt below sends it through the normal image path. Shown on the
 * win message and on a player's very first-ever attempt as a one-time
 * preview; every losing spin after that is text-only.
 */
import { config } from '../config.js'
import { characterStars } from '../lib/rarity.js'
import {
  getActiveSeason,
  ensurePlayerSeasonState,
  chanceForExclusiveSpin,
  getExclusiveSpinWinner,
  claimExclusiveSpinForPlayer,
  addOwnedSeasonContent,
} from '../lib/season-engine.js'
import { characterMap } from '../lib/game-data.js'
import { updatePlayer } from '../lib/player-repo.js'
import { roundGems, fmtGems } from '../lib/format.js'
import { spinLockGate } from '../lib/spin-locks.js'

export const CHARACTER_ID = 'yu_miaoyi'
export const SPIN_FIELD = 'yuMiaoyiSpins'
export const COST_PER_SPIN = 0.8
export const DEAD_ZONE_UNTIL = 200  // spins 1-200: 0%, a true dead zone
export const PLATEAU_CHANCE = 0.80  // spins 201-240: 80% per spin, flat
export const PITY_AT = 9999         // no guaranteed win inside the cap, on purpose
export const MAX_SPINS_PER_PLAYER = 240 // hard lifetime cap
export const MAX_SPINS_PER_COMMAND = 5  // hard per-command cap, spam-proofs one giant pull
export const EXCLUSIVE = true

const RULE = '━━━━━━━━━━━━━━━━━━━━'

// Miss and win lines in HER voice (§10): teasing, pet-names, Dreamlands
// brags. Nothing about odds, thresholds or the dead zone — ever.
const MISS_LINES = [
  `"Mm, not yet, pet. The fog says you're close though. Isn't that nice of me to relay?"`,
  `"Almost. Keep spinning, sleepy — I enjoy watching you try for me."`,
  `"The Dreamlands keep their doors locked a little longer. I'd pout if I were you."`,
  `"So close I felt you reaching. Try again — I'm worth the gems, obviously."`,
  `"Patience, kitten. I've waited out whole nights in the fog; you can wait out a spin."`,
  `"Not this pull. But you know I only ever go to one person in this whole bot."`,
]

function missLine(spin) {
  return `🌙 ${MISS_LINES[spin % MISS_LINES.length]}`
}

/** Progress toward the spin cap — never reveals anything else. */
function pityBar(spin, width = 10) {
  const filled = Math.max(0, Math.min(width, Math.round((spin / MAX_SPINS_PER_PLAYER) * width)))
  return `${'▰'.repeat(filled)}${'▱'.repeat(width - filled)}`
}

function reel(results) {
  const MAX_ROWS = 5
  const marks = results.map(r => (r.won ? '✦' : '·'))
  const rows = []
  for (let i = 0; i < marks.length; i += 10) rows.push(marks.slice(i, i + 10).join(' '))
  if (rows.length <= MAX_ROWS) return rows.join('\n')
  return [`_…${(rows.length - MAX_ROWS) * 10} earlier spins_`, ...rows.slice(-MAX_ROWS)].join('\n')
}

// No entry gate on an active season: she is spin-able whenever her independent
// banner is unlocked. Look up any active season inside the player write.
async function replyOverArt(ctx, character, text) {
  if (!character?.image) return ctx.reply(text)
  try {
    // Her reveal art is a STILL .webp (data/characters.json's yu_miaoyi.image),
    // so it rides the normal image path — never replyGif's animated route.
    // Falls back to plain text if the media send fails, same as every other
    // exclusive spin.
    if (typeof ctx.replyImage === 'function') {
      return await ctx.replyImage(character.image, text)
    }
    return await ctx.reply(text)
  } catch {
    return ctx.reply(text)
  }
}

export default {
  name: 'yu-miaoyi-spin',
  aliases: ['yumiaoyi-spin', 'miaoyi-spin'],
  category: 'season',
  requiresPlayer: true,
  description: `Spin for Yu Miaoyi. ${fmtGems(COST_PER_SPIN)} Gems per spin, globally exclusive to one winner bot-wide`,

  async run(ctx) {
    // Owner freeze (.lockspin / .unlockspin, lib/spin-locks.js). Checked
    // before anything is read or spent, so a locked banner costs nothing.
    if (spinLockGate(ctx, CHARACTER_ID)) return

    if (!ctx.player) return ctx.reply(`⚠️ Register first with *${config.prefix}register*.`)

    const character = characterMap[CHARACTER_ID]
    if (!character) return ctx.reply(`⚠️ Yu Miaoyi isn't configured yet.`)

    // Was this the player's very first spin attempt ever, before this command
    // mutates their spin count? Read once, up front, and used only to decide
    // whether the portrait rides along on an otherwise text-only loss reply.
    const isFirstEverAttempt = (ctx.player[SPIN_FIELD] ?? 0) === 0

    const requested = Math.floor(Number(ctx.args[0]) || 1)
    const spinCount = Math.min(MAX_SPINS_PER_COMMAND, MAX_SPINS_PER_PLAYER, Math.max(1, requested))

    // Refuse BEFORE charging (§9.2): the one-of-one lock is checked up front,
    // before any gem moves, and again inside the loop before every single
    // spin of a batch — first claim wins, losers are never charged.
    const existingWinner = getExclusiveSpinWinner(ctx.db, CHARACTER_ID)
    if (existingWinner) {
      const isSelf = existingWinner === ctx.from
      return replyOverArt(ctx, character, isSelf
        ? `🌙 *She is already yours.*\n${RULE}\n_"Silly pet. You already own me. Stop feeding the fog your gems — come equip me instead."_\n\n*${config.prefix}character equip yu_miaoyi*`
        : `🔒 *SHE IS ALREADY CLAIMED*\n${RULE}\n_"Shh. I only ever go to one person in this whole bot — and it wasn't you."_\n\nOnly one player, bot-wide, could ever claim Yu Miaoyi, and someone got there first. No gems were spent.`)
    }

    let outcome = null
    await updatePlayer(ctx.db, ctx.from, (player) => {
      const season = getActiveSeason(ctx.db)
      if (season) ensurePlayerSeasonState(player, season.id)

      if (getExclusiveSpinWinner(ctx.db, CHARACTER_ID)) {
        outcome = { reason: 'claimed' }
        return
      }

      const results = []
      let won = false
      let spinsUsed = 0
      let gems = roundGems(player.wallet?.gems ?? 0)

      for (let i = 0; i < spinCount; i++) {
        // Per-spin lock check: another player's claim landing mid-batch stops
        // the reel BEFORE this spin is charged.
        if (getExclusiveSpinWinner(ctx.db, CHARACTER_ID)) break
        if (gems < COST_PER_SPIN) break
        if ((player[SPIN_FIELD] ?? 0) >= MAX_SPINS_PER_PLAYER) break

        const nextSpin = (player[SPIN_FIELD] ?? 0) + 1
        const chance = chanceForExclusiveSpin(nextSpin, { deadZoneUntil: DEAD_ZONE_UNTIL, plateauChance: PLATEAU_CHANCE, pityAt: PITY_AT })
        const thisWon = nextSpin >= PITY_AT || Math.random() < chance

        gems = roundGems(gems - COST_PER_SPIN)
        player.wallet.gems = gems
        player[SPIN_FIELD] = nextSpin
        spinsUsed++
        results.push({ spin: nextSpin, won: thisWon })

        if (thisWon) {
          // Atomic claim inside the serialized write: if another player's
          // claim lands in the same instant, ours fails and the character is
          // NOT granted — the loop breaks and nothing more is charged.
          const claimed = claimExclusiveSpinForPlayer(ctx.db, CHARACTER_ID, ctx.from)
          if (claimed) {
            player.ownedCharacters = player.ownedCharacters ?? []
            if (!player.ownedCharacters.includes(character.id)) player.ownedCharacters.push(character.id)
            addOwnedSeasonContent(player, 'character', character.id)
            won = true
          }
          break
        }
      }

      if (!results.length) {
        outcome = { reason: (player[SPIN_FIELD] ?? 0) >= MAX_SPINS_PER_PLAYER ? 'exhausted_lifetime' : 'gems', gems, cost: COST_PER_SPIN }
        return
      }

      outcome = {
        reason: won ? 'won' : 'exhausted',
        results,
        spinsUsed,
        remaining: roundGems(player.wallet.gems),
      }
    })

    if (outcome?.reason === 'claimed') {
      return replyOverArt(ctx, character,
        `🔒 *SHE IS ALREADY CLAIMED*\n${RULE}\n_"Tsk. Someone tucked me away while you were reaching. Nothing spent, pet — I'd never let you pay for nothing."_\n\nAnother player claimed her this very moment. No gems were spent.`)
    }
    if (outcome?.reason === 'gems') {
      return ctx.reply(
        `💎 *Not enough Gems.*\n${RULE}\n` +
        `One spin costs *${fmtGems(outcome.cost)}*. You hold *${fmtGems(outcome.gems)}*.\n\n` +
        `_\"Come back when your pockets jingle, sleepy. I'll be in the fog either way.\"_`,
      )
    }
    if (outcome?.reason === 'exhausted_lifetime') {
      return ctx.reply(
        `🌙 *No spins left.*\n${RULE}\n` +
        `_You've spent all *${MAX_SPINS_PER_PLAYER}* of your spins reaching for me. \"Adorable effort, pet. Truly. There's a shop, you know — five Monds and I'm yours.\"_\n\n` +
        `🌕 *${config.prefix}character buy yu_miaoyi*`,
      )
    }

    const last = outcome.results[outcome.results.length - 1]
    const spent = fmtGems(roundGems(outcome.spinsUsed * COST_PER_SPIN))
    const range = outcome.spinsUsed === 1
      ? `Spin *${last.spin}*`
      : `Spins *${outcome.results[0].spin}* → *${last.spin}*`

    if (outcome.reason === 'won') {
      const ability = character.ability
      return replyOverArt(ctx, character,
        `🌙✨ *SHE TUCKS YOU IN.* ✨🌙\n${RULE}\n` +
        `_Spin ${last.spin}. Her hands settle over the whole bot's dreams, and they stop on YOU._\n\"There we go. I was wondering when you'd catch me, pet.\"_\n\n` +
        `🏆 *${character.name.toUpperCase()} OBTAINED*\n` +
        `${character.emoji ?? '🌙'} *${characterStars(character.stars)}*` +
        (ability?.name ? `  ·  *${ability.name}*` : '') + `\n` +
        (ability?.flavor ? `_${ability.flavor}_\n` : '') +
        (character.description ? `\n_${character.description}_\n` : '') +

        `\n🔒 *GLOBALLY LOCKED.* No other player can ever claim her.\n` +
        `_Taken on spin ${last.spin}, for ${spent} gems this pull._\n\n` +
        `💎 Remaining: *${fmtGems(outcome.remaining)}*\n\n` +
        `_Equip her with *${config.prefix}character equip yu_miaoyi*._`,
      )
    }

    const lines = [
      `🌙 *THE DREAMLANDS' NOTICE*`,
      RULE,
      `_You lay 💎${spent} at the edge of the fog. She hasn't decided to be caught yet._`,
      ``,
      range,
      reel(outcome.results),
      ``,
      missLine(last.spin),
      ``,
      `📿 Pity  ${pityBar(last.spin)}  *${last.spin}*/${MAX_SPINS_PER_PLAYER}`,
      `💎 Remaining: *${fmtGems(outcome.remaining)}*`,
    ]

    if (requested > MAX_SPINS_PER_COMMAND) {
      lines.push(``, `_Capped at *${MAX_SPINS_PER_COMMAND}* spins per command, run it again for more._`)
    } else if (outcome.spinsUsed < spinCount) {
      lines.push(``, `_Gems ran out after *${outcome.spinsUsed}* of *${spinCount}* requested spins._`)
    }

    const lossText = lines.join('\n')
    // Portrait preview only on a player's very first-ever spin attempt; every
    // losing spin after that is text-only (matches every other exclusive
    // spin's plain ctx.reply() on loss).
    return isFirstEverAttempt ? replyOverArt(ctx, character, lossText) : ctx.reply(lossText)
  },
}
