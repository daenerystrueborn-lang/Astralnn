/**
 * victoria-spin.js — Victoria Minayoko's one-of-one gem banner.
 *
 * Spins 1-276 are a true dead zone; the first live pull, spin 277, is a
 * guaranteed win. Each pull costs 1.4 Gems and the per-player lifetime cap is
 * 300. Her Mond shop purchase uses the same bot-wide claim, so only the first
 * buyer or spinner can ever take her. The shared curve and serialized pull loop
 * live in lib/spin-banners.js, which also exposes this banner to the website.
 */
import { config } from '../config.js'
import { characterStars } from '../lib/rarity.js'
import { getExclusiveSpinWinner } from '../lib/season-engine.js'
import { characterMap } from '../lib/game-data.js'
import { getPlayer, updatePlayer } from '../lib/player-repo.js'
import { fmtGems, roundGems } from '../lib/format.js'
import { spinLockGate } from '../lib/spin-locks.js'
import { getSpinBanner, runSpinBatch } from '../lib/spin-banners.js'

const CHARACTER_ID = 'victoria_minayoko'
const BANNER = getSpinBanner(CHARACTER_ID)
const RULE = '━━━━━━━━━━━━━━━━━━━━'

const MISS_LINES = [
  'The ground is quiet. No territory has opened for you yet.',
  'A palm touches the earth, then lifts. The Sanctum stays asleep.',
  'The walls hold, but they have not learned your name.',
  'A breath passes through the hall. Nothing answers it.',
  'The door stays shut for one more moment.',
  'The stones are still. The light has not found its way in.',
]

function missLine(spin) {
  return `🏛️ _${MISS_LINES[spin % MISS_LINES.length]}_`
}

function pityBar(spin, width = 10) {
  const filled = Math.max(0, Math.min(width, Math.round((spin / BANNER.maxSpinsPerPlayer) * width)))
  return `${'▰'.repeat(filled)}${'▱'.repeat(width - filled)}`
}

function reel(results) {
  const marks = results.map(result => result.won ? '✦' : '·')
  const rows = []
  for (let i = 0; i < marks.length; i += 10) rows.push(marks.slice(i, i + 10).join(' '))
  return rows.join('\n')
}

async function replyOverArt(ctx, character, text) {
  if (!character?.image || typeof ctx.replyImage !== 'function') return ctx.reply(text)
  try {
    return await ctx.replyImage(character.image, text)
  } catch {
    return ctx.reply(text)
  }
}

function holderName(ctx, jid) {
  try { return getPlayer(ctx.db, jid)?.name ?? null } catch { return null }
}

export default {
  name: 'victoria-spin',
  aliases: ['victoriaspin', 'minayoko-spin'],
  category: 'character',
  requiresPlayer: true,
  description: 'Spin for Victoria Minayoko at 1.4 Gems per pull — one-of-one, bot-wide',

  async run(ctx) {
    const pr = config.prefix
    if (!ctx.player) return ctx.reply(`⚠️ Register first with *${pr}register*.`)

    const character = characterMap[CHARACTER_ID]
    if (!character || !BANNER) return ctx.reply(`⚠️ Victoria Minayoko's banner isn't configured yet.`)

    // Owner freeze: checked before inspecting the claim or charging a Gem.
    if (spinLockGate(ctx, CHARACTER_ID, character.name)) return

    const existingWinner = getExclusiveSpinWinner(ctx.db, CHARACTER_ID)
    if (existingWinner) {
      const isSelf = existingWinner === ctx.from
      const holder = isSelf ? null : holderName(ctx, existingWinner)
      return replyOverArt(ctx, character, isSelf
        ? `🏛️ *${character.name} is already yours.*\n${RULE}\n_The Sanctum answers to you. Equip her with *${pr}character equip ${CHARACTER_ID}*._`
        : `🔒 *THE SANCTUM IS CLAIMED*\n${RULE}\n_${character.name} has been claimed by ${holder ? `*${holder}*` : 'another player'}._\n\nOnly one player, bot-wide, can ever obtain her. No Gems were spent.`)
    }

    const firstAttempt = (ctx.player[BANNER.spinField] ?? 0) === 0
    const requested = Math.floor(Number(ctx.args[0]) || 1)
    let outcome = null

    // Shared with the Mond-buy path: the exclusive claim and the player update
    // run through the same serialized mutation queue, so only one door can win.
    await updatePlayer(ctx.db, ctx.from, player => {
      outcome = runSpinBatch(ctx.db, player, BANNER, ctx.from, requested)
    })

    if (outcome?.reason === 'owned') {
      return replyOverArt(ctx, character,
        `🏛️ *${character.name} is already yours.*\nEquip her with *${pr}character equip ${CHARACTER_ID}*.`)
    }
    if (outcome?.reason === 'claimed') {
      const winner = getExclusiveSpinWinner(ctx.db, CHARACTER_ID)
      const holder = winner ? holderName(ctx, winner) : null
      return replyOverArt(ctx, character,
        `🔒 *THE SANCTUM IS CLAIMED*\n${RULE}\n_${holder ? `*${holder}*` : 'Another player'} reached her first. No Gems were spent._`)
    }
    if (outcome?.reason === 'gems') {
      return ctx.reply(
        `💎 *Not enough Gems.*\n${RULE}\n` +
        `One pull costs *${BANNER.costPerSpin} Gems*. You hold *${fmtGems(outcome.gems)}*. No spins were used.`,
      )
    }
    if (outcome?.reason === 'exhausted_lifetime') {
      return ctx.reply(
        `🏛️ *No spins left.*\n${RULE}\n` +
        `_You have used all *${BANNER.maxSpinsPerPlayer}* pulls on Victoria's banner. No Gems were spent._`,
      )
    }

    const last = outcome.results.at(-1)
    const spent = roundGems(outcome.spinsUsed * BANNER.costPerSpin)
    const range = outcome.spinsUsed === 1
      ? `Spin *${last.spin}*`
      : `Spins *${outcome.results[0].spin}* → *${last.spin}*`

    if (outcome.reason === 'won') {
      const ability = character.ability
      return replyOverArt(ctx, character,
        `🏛️✨ *THE SANCTUM OPENS.* ✨🏛️\n${RULE}\n` +
        `_Spin ${last.spin}. Victoria puts her palm to the ground, and the whole room goes quiet._\n\n` +
        `🏆 *${character.name.toUpperCase()} OBTAINED*\n` +
        `${character.emoji ?? '🏛️'} *${characterStars(character.stars)}*` +
        (ability?.name ? `  ·  *${ability.name}*` : '') + `\n` +
        (ability?.flavor ? `_${ability.flavor}_\n` : '') +
        `\n🔒 *ONE-OF-ONE.* She is now claimed bot-wide; no other player can obtain her.\n` +
        `_Taken on spin ${last.spin}, for 💎${fmtGems(spent)} this pull._\n` +
        `💎 Remaining: *${fmtGems(outcome.remaining)}*\n\n` +
        `Equip her with *${pr}character equip ${CHARACTER_ID}* and raise the Sanctum with *${pr}victory*.`)
    }

    const lines = [
      `🏛️ *THE SANCTUM IS STILL QUIET*`,
      RULE,
      `_You spent 💎${fmtGems(spent)}. Nothing opened this time._`,
      ``,
      range,
      reel(outcome.results),
      ``,
      missLine(last.spin),
      ``,
      `📿 Pity  ${pityBar(last.spin)}  *${last.spin}*/${BANNER.maxSpinsPerPlayer}`,
      `💎 Remaining: *${fmtGems(outcome.remaining)}*`,
    ]
    if (requested > BANNER.maxSpinsPerCommand) {
      lines.push(``, `_Capped at *${BANNER.maxSpinsPerCommand}* pulls per command — run it again for more._`)
    } else if (outcome.spinsUsed < outcome.count) {
      lines.push(``, `_Gems ran out after *${outcome.spinsUsed}* of *${outcome.count}* requested pulls._`)
    }

    const text = lines.join('\n')
    return firstAttempt ? replyOverArt(ctx, character, text) : ctx.reply(text)
  },
}
