/**
 * purse — the dungeon run purse and extract decision (R1) + insurance (R8).
 * Usage:
 *   .purse            — status
 *   .purse start      — open a purse (dungeon kill Solars accrue in it)
 *   .purse extract    — bank the purse and close the run
 *   .purse insure     — spend Gems so death cannot take the purse
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import {
  ensurePurse, startPurse, extractPurse, buyInsurance,
  formatPurseStatus, INSURANCE_GEM_COST,
} from '../lib/run-purse.js'
import { recordFaucet, recordSink } from '../lib/economy-ledger.js'

export default {
  name: 'purse',
  aliases: ['runpurse'],
  category: 'economy',
  requiresPlayer: true,
  description: 'Build a run purse in dungeons, then extract or insure it',

  async run(ctx) {
    const p = config.prefix
    const sub = (ctx.args?.[0] ?? '').toLowerCase().trim()

    if (sub === 'start') {
      let reply
      await updatePlayer(ctx.db, ctx.from, (player) => {
        if (player.inBattle || player.inDungeon) {
          reply = '❌ Start a purse *before* entering a dungeon, so the whole run counts.'
          return player
        }
        const r = startPurse(player)
        reply = r.started
          ? '👜 *Run purse opened.* Dungeon kill Solars will build up here. Extract safely with `.purse extract` — dying costs a slice of what is un-banked.'
          : '👜 You already have an open purse.'
        return player
      })
      return ctx.reply(reply)
    }

    if (sub === 'extract') {
      let reply
      await updatePlayer(ctx.db, ctx.from, (player) => {
        const purse = ensurePurse(player)
        if (!purse.active) { reply = formatPurseStatus(player, p); return player }
        const { amount } = extractPurse(player)
        recordFaucet(ctx.db, 'purse_extract', { solars: amount })
        reply = amount > 0
          ? `🏦 *Purse extracted!* ☀️ ${amount.toLocaleString()} Solars banked safely.`
          : '🏦 Purse closed — it was empty.'
        return player
      })
      return ctx.reply(reply)
    }

    if (sub === 'insure') {
      let reply
      await updatePlayer(ctx.db, ctx.from, (player) => {
        const r = buyInsurance(player)
        if (r.ok) recordSink(ctx.db, 'purse_insurance', { gems: INSURANCE_GEM_COST })
        reply = r.ok
          ? `🛡️ *Insured.* The next death takes nothing from your purse. (${INSURANCE_GEM_COST} Gems spent)`
          : r.reason === 'inactive' ? '❌ No open purse to insure. Use `.purse start` first.'
          : r.reason === 'already_insured' ? '❌ This purse is already insured.'
          : `❌ You need ${INSURANCE_GEM_COST} Gems to insure a purse.`
        return player
      })
      return ctx.reply(reply)
    }

    let text = ''
    await updatePlayer(ctx.db, ctx.from, (player) => { text = formatPurseStatus(player, p); return player })
    return ctx.reply(text)
  },
}
