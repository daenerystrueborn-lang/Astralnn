/**
 * ladmin.js — the owner's League controls.
 *
 * Category 'admin', which is what keeps it out of the player command list
 * (lib/command-list.js's isOwnerCommand). Every subcommand is owner only.
 *
 * This is the Phase 1 set: seating, the draw, the season start, the manual
 * result and no show fixes, the forced rollover and the feature switch. Prize
 * payout, Astral TV and script tools are stubbed here and land in their own
 * phases, so the command shape does not move later.
 */
import { config } from '../config.js'
import { getPlayer, playerExists, updateWorldState } from '../lib/player-repo.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import {
  getLeague,
  ensureLeague,
  ensureNpcs,
  ensureAdventurerRecord,
  leagueOn,
  envFlagOn,
  leagueGate,
  leagueUnderConstruction,
  seatPlayers,
  seatAdventurers,
  seatQualifiedPlayers,
  drawSeason,
  isFullySeated,
  seatingProblems,
  applyMatchResult,
  resultShapes,
  getMatch,
  leagueDayOf,
  matchesDueOn,
  openMatches,
} from '../lib/league/league-repo.js'
import { buildTable } from '../lib/league/league-table.js'
// The mod side of a live fixture: verify a challenge, restart one that hit a
// bug, or move one that cannot be played today. All three are recorded on the
// match and on league.modLog.
import { verifyMatch, rematchMatch, rescheduleMatch, restoreArenaSnapshot } from '../lib/league/league-match.js'

/** Owner readable reasons. No dashes and no internal codes in the reply. */
const PROBLEMS = {
  no_such_match: 'there is no match with that id',
  not_waiting_on_a_mod: 'that match is not waiting on a mod',
  wrong_group: 'that match belongs to a different group',
  already_settled: 'that match is already settled',
  already_live: 'that match is already live',
  not_your_match: 'that match does not involve that seat',
  already_in_a_match: 'that seat is already in a live match',
}
import {
  LEAGUE_SEATS,
  LEAGUE_ADVENTURER_SEATS,
  LEAGUE_PLAYER_SEATS,
  LEAGUE_ROUNDS,
  LEAGUE_CATCHUP_DAYS,
  MOD_REMATCH_LIMIT,
  dayKeyWAT,
  dayStartMsWAT,
  wallClockWAT,
  dateLabelWAT,
} from '../lib/league/league-rules.js'
import { seatLabel, seasonCloseCard } from '../lib/league/league-copy.js'
import { sealedRows } from '../lib/league/league-trial.js'
import {
  planSeasonClose,
  applySeasonClose,
  paySeasonPrizes,
  startNewSeason,
} from '../lib/league/league-close.js'
import { listAdventurers, validationProblems } from '../lib/league/adventurer-repo.js'
import { tvPrice } from '../lib/league/league-tv.js'
import { runLeagueTick, broadcastAstralTv, announceGroups } from '../lib/league/league-scheduler.js'

const NOT_OWNER = '🔒 That is an owner command.'

/**
 * The subcommands the owner keeps while the League cannot answer. Without these
 * there is no way to read the state or open the build gate from inside the bot,
 * which would leave the feature reachable only by editing the database.
 */
const OWNER_WHEN_DARK = new Set(['', 'status', 'qualifiers', 'trials', 'sealed', 'waitlist', 'on', 'off', 'open', 'close'])
const LATER_PHASE = '🚧 That arrives in a later phase.'

/** Pull every mentioned or typed player JID out of the argument list. */
function collectJids(ctx, args) {
  const contextInfo = ctx.msg?.message?.extendedTextMessage?.contextInfo
  const mentioned = contextInfo?.mentionedJid ?? []
  const typed = args
    .map(a => String(a).replace(/^@/, ''))
    .filter(a => /^\d+$/.test(a))
    .map(digits => `${digits}@s.whatsapp.net`)
  return [...new Set([...mentioned, ...typed])]
}

function helpText() {
  const p = config.prefix
  return [
    '🛡️👑 *LEAGUE ADMIN · CONTROL PANEL* 👑🛡️',
    '━━━━━━━━━━━━━━━━━━━━',
    `📊 *${p}ladmin status*  ·  *where the season is*`,
    `🏅 *${p}ladmin qualifiers*  ·  *sealed players, top seven seats & waitlist*`,
    `🪑 *${p}ladmin seats*  ·  *the twenty seats*`,
    `🎮 *${p}ladmin qualify @p1 ... @p7*  ·  *seat the qualified players*`,
    `🎲 *${p}ladmin draw*  ·  *draw the schedule, once*`,
    `🏟️ *${p}ladmin start [date]*  ·  *open the season*`,
    `⏸️ *${p}ladmin pause* / *resume*  ·  *pause or resume scheduler*`,
    `🧾 *${p}ladmin verify <matchId>*  ·  *let a live player match start*`,
    `🔁 *${p}ladmin rematch <matchId>*  ·  *restart one that hit a bug*`,
    `📅 *${p}ladmin reschedule <matchId>*  ·  *move one that cannot be played today*`,
    `📝 *${p}ladmin result <matchId> <seat> <reason>*  ·  *fix a result*`,
    `🚪 *${p}ladmin noshow <matchId> <seat>*  ·  *record a no show*`,
    `🌙 *${p}ladmin rollover*  ·  *force the midnight step*`,
    `🏁 *${p}ladmin finish*  ·  *close season & pay purse*`,
    `🌱 *${p}ladmin newseason*  ·  *prepare next season*`,
    `⭐ *${p}ladmin feature <matchId>*  ·  *pick the featured match*`,
    `📺 *${p}ladmin tv*  ·  *go live on Astral TV right now, any hour*`,
    `🔁 *${p}ladmin tv replay [day]* / *tv featured [day]*  ·  *re-air a day, or its featured match*`,
    `📺 *${p}ladmin tvprice <gems> <solars>*  ·  *set the Astral TV pass prices*`,
    `🚦 *${p}ladmin on* / *off*  ·  *the runtime feature flag*`,
    `🚧 *${p}ladmin open* / *close*  ·  *the build gate*`,
  ].join('\n')
}

export default {
  name: 'ladmin',
  aliases: ['leagueadmin'],
  category: 'admin',
  requiresPlayer: false,
  description: 'Owner only: run the Astral League season.',
  subcommands: ['status', 'qualifiers', 'seats', 'qualify', 'draw', 'start', 'pause', 'resume',
    'verify', 'rematch', 'reschedule',
    'result', 'noshow', 'rollover', 'finish', 'newseason', 'feature', 'tv', 'tvprice', 'on', 'off', 'open', 'close'],

  async run(ctx) {
    const { db, from, args, reply } = ctx
    if (!isOwnerJid(from)) return reply(NOT_OWNER)

    const sub = String(args[0] ?? '').toLowerCase()
    const now = Date.now()
    const league = ensureLeague(db)

    // A few subcommands must survive the dark, otherwise the owner cannot read
    // the state or open the build gate from inside the bot.
    if (!OWNER_WHEN_DARK.has(sub) && !leagueOn(db)) {
      const gate = leagueGate(db)
      const hint = leagueUnderConstruction(db)
        ? '\nThe build gate is shut. Open it with *.ladmin open* once the season is ready.'
        : `\nThe runtime flag is off. Turn it on with *.ladmin on*${envFlagOn() ? '' : ', and note the env flag ASTRAL_PROS_ENABLED is also off.'}`
      return reply(`${gate.message}${hint}`)
    }

    switch (sub) {
      case '':
      case 'status': {
        const day = leagueDayOf(league, now)
        const clock = wallClockWAT(now)
        const content = validationProblems()
        const lines = [
          '🛡️👑 *LEAGUE STATUS · ADMIN DASHBOARD* 👑🛡️',
          '━━━━━━━━━━━━━━━━━━━━',
        ]
        lines.push(`🚧 *Build gate: ${leagueUnderConstruction(db) ? 'SHUT, players cannot use the League' : 'open'}*`)
        lines.push(`🚦 *Feature:* *${leagueOn(db) ? 'on' : 'off'}* (env ${envFlagOn() ? 'on' : 'off'}, runtime ${league.featureOn ? 'on' : 'off'})`)
        lines.push(`📅 *Season ${league.season.id}*, status *${league.season.status}*, seed *${league.season.seed}*`)
        lines.push(`🕐 *Now:* ${dateLabelWAT(now)}, *${clock.hhmm}* West Africa Time, day key *${dayKeyWAT(now)}*`)
        lines.push(`🗓️ *Season day:* *${day ?? 'not started'}*`)
        const playerSeatsFilled = league.seats.filter(s => s.kind === 'player').length
        const openPlayerSeats = Math.max(0, LEAGUE_PLAYER_SEATS - playerSeatsFilled)
        const sealed = sealedRows(league, LEAGUE_PLAYER_SEATS)
        const totalSealed = sealed.seated.length + sealed.waiting.length
        const totalTrials = Object.keys(league.trials ?? {}).length
        lines.push(`🪑 *Seats:* *${league.seats.filter(s => s.kind === 'adventurer').length}* Adventurers, *${playerSeatsFilled}* players, of *${LEAGUE_SEATS}* (*${openPlayerSeats}* open player seats)`)
        lines.push(`🏅 *Qualifiers:* *${totalSealed}* passed (*${sealed.seated.length}/${LEAGUE_PLAYER_SEATS}* in seat zone, *${sealed.waiting.length}* waitlisted, *${totalTrials}* total challengers)`)
        lines.push(`📋 *Fixtures:* *${league.fixtures.length}* days, *${Object.keys(league.matches).length}* matches, *${openMatches(league).length}* still open`)
        lines.push(`📝 *Results applied:* *${league.results.length}*`)
        lines.push('')
        lines.push('🔁 *Rollover markers:*')
        for (const [key, value] of Object.entries(league.rollover)) lines.push(`   ▫️ *${key}:* ${value}`)
        if (content.length) {
          lines.push('')
          lines.push(`⛔ *Content problems:* ${content.length}`)
          for (const problem of content.slice(0, 10)) lines.push(`   • ${problem}`)
        }
        if (league.modLog.length) {
          lines.push('')
          lines.push(`🛡️ *Mod log:* *${league.modLog.length}* entries, latest *${league.modLog[league.modLog.length - 1].action ?? 'unknown'}*`)
        }
        return reply(lines.join('\n'))
      }

      case 'qualifiers':
      case 'trials':
      case 'sealed':
      case 'waitlist': {
        const sealed = sealedRows(league, LEAGUE_PLAYER_SEATS)
        const totalSealed = sealed.seated.length + sealed.waiting.length
        const allTrials = Object.values(league.trials ?? {})
        const inProgress = allTrials.filter(t => t?.verdict !== 'sealed')
        const playerSeatsFilled = league.seats.filter(s => s.kind === 'player').length
        const openPlayerSeats = Math.max(0, LEAGUE_PLAYER_SEATS - playerSeatsFilled)
        const openQualifierSpots = Math.max(0, LEAGUE_PLAYER_SEATS - sealed.seated.length)

        const lines = [
          '🏅👑 *LEAGUE QUALIFIERS · SEALED & SEAT ALLOCATION* 👑🏅',
          '━━━━━━━━━━━━━━━━━━━━',
          `✅ *Total Passed Qualifiers (Sealed):* *${totalSealed}*`,
          `🪑 *Challenger Seat Zone (#14 to #20):* *${sealed.seated.length}/${LEAGUE_PLAYER_SEATS}* filled (*${openQualifierSpots}* qualifier spot${openQualifierSpots === 1 ? '' : 's'} still open)`,
          `⏳ *Waitlist (Overflow > ${LEAGUE_PLAYER_SEATS}):* *${sealed.waiting.length}*`,
          `⚔️ *In-Progress Trial Challengers:* *${inProgress.length}*`,
          `🏟️ *Roster Player Seats Currently Assigned:* *${playerSeatsFilled}/${LEAGUE_PLAYER_SEATS}* (*${openPlayerSeats}* open on table)`,
        ]

        lines.push('')
        lines.push(`🪑 *TOP ${LEAGUE_PLAYER_SEATS} QUALIFIED FOR SEATS #14 TO #20*`)
        if (!sealed.seated.length) {
          lines.push('   _No players have earned Master Del Astra\'s seal yet._')
        } else {
          sealed.seated.forEach((row, idx) => {
            const seatNo = LEAGUE_ADVENTURER_SEATS + idx + 1
            const name = row.name || getPlayer(db, row.jid)?.name || row.jid?.split('@')[0] || 'Unknown'
            const dmg = Number(row.best?.damage ?? 0).toLocaleString()
            const turns = Number(row.best?.turns ?? 0)
            lines.push(`   *#${seatNo}*  🎮 *${name}*  ·  💥 *${dmg} DMG*  ·  🔄 *${turns} turn${turns === 1 ? '' : 's'}*`)
          })
        }

        if (sealed.waiting.length) {
          lines.push('')
          lines.push('⏳ *WAITLIST (RANKED BY DAMAGE → TURNS → EARLIEST SEAL)*')
          sealed.waiting.forEach((row, idx) => {
            const name = row.name || getPlayer(db, row.jid)?.name || row.jid?.split('@')[0] || 'Unknown'
            const dmg = Number(row.best?.damage ?? 0).toLocaleString()
            const turns = Number(row.best?.turns ?? 0)
            lines.push(`   *W${idx + 1}*  🎮 *${name}*  ·  💥 *${dmg} DMG*  ·  🔄 *${turns} turn${turns === 1 ? '' : 's'}*`)
          })
        }

        if (inProgress.length) {
          lines.push('')
          lines.push('⚔️ *CHALLENGERS STILL ATTEMPTING THE TRIAL*')
          inProgress.slice(0, 10).forEach((row) => {
            const name = row.name || getPlayer(db, row.jid)?.name || row.jid?.split('@')[0] || 'Unknown'
            const dmg = Number(row.best?.damage ?? 0).toLocaleString()
            const turns = Number(row.best?.turns ?? 0)
            lines.push(`   ▫️ *${name}*  ·  best 💥 *${dmg} DMG* / 🔄 *${turns}t*  (${row.attempts ?? 0} tries)`)
          })
        }

        return reply(lines.join('\n'))
      }

      case 'seats': {
        if (!league.seats.length) return reply('🪑⏳ *No seats are filled yet.* Run *.ladmin qualify @p1 ... @p7*.')
        const lines = [
          '🪑👑 *THE SEATS · ROSTER TABLE* 👑🪑',
          '━━━━━━━━━━━━━━━━━━━━',
        ]
        for (const seat of league.seats) {
          const row = buildTable(league).find(r => r.seat === seat.seat)
          lines.push(`*#${String(seat.seat).padStart(2, ' ')}*  ${seat.kind === 'adventurer' ? '🌟' : '🎮'} *${seat.name}*  ·  🏅 *${row?.points ?? 0} pts*`)
        }
        return reply(lines.join('\n'))
      }

      case 'qualify': {
        const jids = collectJids(ctx, args.slice(1))
        if (!jids.length) {
          const sealed = sealedRows(league, LEAGUE_PLAYER_SEATS)
          const totalSealed = sealed.seated.length + sealed.waiting.length
          return reply([
            `🎮 Mention the qualified players: *.ladmin qualify @p1 @p2 ... @p${LEAGUE_PLAYER_SEATS}*`,
            `🏅 Currently *${totalSealed}* player${totalSealed === 1 ? ' has' : 's have'} passed qualifiers (*${sealed.seated.length}/${LEAGUE_PLAYER_SEATS}* in seat zone, *${sealed.waiting.length}* waitlisted).`,
            `📖 Run *.ladmin qualifiers* to inspect all qualified players and open seats, or *.ladmin start* to auto-seat the top ${LEAGUE_PLAYER_SEATS} sealed players.`,
          ].join('\n'))
        }
        const missing = jids.filter(jid => !playerExists(db, jid))
        if (missing.length) {
          return reply(['⛔ These players have no record here:', ...missing.map(j => `   • ${j}`), '', 'They must be registered before they can hold a seat.'].join('\n'))
        }
        let problems = []
        await updateWorldState(db, 'league', (data) => {
          // ensureNpcs takes a db shape; the mutator holds the data object.
          ensureNpcs({ data })
          const target = data.league
          const seated = seatPlayers(target, jids, jid => getPlayer(db, jid)?.name ?? null)
          problems = seated.problems
          if (!problems.length) {
            for (const npc of listAdventurers()) ensureAdventurerRecord(data.npcs, npc.id)
            if (target.seats.filter(s => s.kind === 'adventurer').length !== listAdventurers().length) {
              seatAdventurers(target, listAdventurers())
            }
          }
        })
        if (problems.length) {
          return reply(['⛔ Those players cannot be seated:', ...problems.map(p => `   • ${p}`)].join('\n'))
        }
        const names = jids.map(jid => getPlayer(db, jid)?.name ?? jid.split('@')[0])
        return reply([
          '🎮 *THE PLAYER SEATS ARE FILLED*',
          ...names.map((n, i) => `   #${LEAGUE_ADVENTURER_SEATS + i + 1}  ${n}`),
          '',
          isFullySeated(league)
            ? `All ${LEAGUE_SEATS} seats are full. Draw the schedule with *.ladmin draw*.`
            : 'Some seats are still empty.',
        ].join('\n'))
      }

      case 'draw': {
        let problems = []
        await updateWorldState(db, 'league', (data) => {
          const drawn = drawSeason(data.league, { now })
          problems = drawn.problems
        })
        if (problems.length) {
          return reply(['⛔ The draw cannot happen:', ...problems.map(p => `   • ${p}`)].join('\n'))
        }
        return reply(`🎲 The schedule is drawn. ${Object.keys(league.matches).length} matches over ${LEAGUE_ROUNDS} days, seed ${league.season.seed}. It will not be drawn again.`)
      }

      case 'start': {
        if (['running', 'catchup'].includes(league.season.status)) {
          return reply(`🏟️ Already running, day ${leagueDayOf(league, now) ?? 1}.`)
        }
        // An explicit start date is read as a WAT day key offset in days.
        const offsetDays = parseInt(args[1], 10)
        const startMs = Number.isInteger(offsetDays) ? now + offsetDays * 86_400_000 : now
        let problems = []
        let waiting = []
        await updateWorldState(db, 'league', (data) => {
          const target = data.league
          if (!isFullySeated(target)) {
            // The draw of the player seats: the players Master Del Astra
            // acknowledged fill them, strongest attempt first. More seals than
            // seats leaves a waitlist, which is reported below rather than
            // dropped. The manual *.ladmin qualify* still overrides.
            const seated = seatQualifiedPlayers(target, jid => getPlayer(db, jid)?.name ?? null)
            waiting = seated?.waiting ?? []
          }
          if (!isFullySeated(target)) { problems = seatingProblems(target); return }
          if (!target.fixtures.length) {
            const drawn = drawSeason(target, { now })
            if (!drawn.ok) { problems = drawn.problems; return }
          }
          target.season.startDay = dayKeyWAT(startMs)
          target.season.startedAt = startMs
          target.season.status = 'running'
          target.rollover.lastDayDone = 0
        })
        if (problems.length) {
          return reply(['⛔ The season cannot open:', ...problems.map(p => `   • ${p}`)].join('\n'))
        }
        return reply([
          '🏟️🔥 *THE SEASON IS OPEN* 🔥🏟️',
          '━━━━━━━━━━━━━━━━━━━━',
          `📅 *Day 1 is ${dateLabelWAT(startMs)}.*`,
          `🏁 *The last round is day ${LEAGUE_ROUNDS}*, with *${LEAGUE_CATCHUP_DAYS} catch up days* after it.`,
          '',
          '🔔 The scheduler posts the fixtures card at *00:05*, the morning DMs at *08:00*, the warning at *21:00* and the end of day post at *23:55*, all West Africa Time.',
          ...(waiting.length ? ['', `⏳ *${waiting.length} acknowledged player(s) did not fit.* They are on the waitlist and go in first next season.`] : []),
        ].join('\n'))
      }

      case 'pause':
      case 'resume': {
        const status = sub === 'pause' ? 'paused' : 'running'
        if (league.season.status === 'idle') return reply('⛔ The season has not started.')
        if (league.season.status === 'closed') return reply('⛔ The season is closed.')
        await updateWorldState(db, 'league', (data) => { data.league.season.status = status })
        // A paused season keeps its clock: the scheduler checks this status
        // before posting, so nothing goes out until it is resumed.
        return reply(`🛡️ The season is ${sub === 'pause' ? 'paused. Nothing posts until it is resumed.' : 'running again.'}`)
      }

      case 'result': {
        const matchId = args[1]
        const winnerSeat = parseInt(args[2], 10)
        const reason = args.slice(3).join(' ').trim()
        if (!matchId || !Number.isInteger(winnerSeat)) {
          return reply('📝 *.ladmin result <matchId> <winner seat> <reason>*. The reason is required and is logged.')
        }
        if (!reason) return reply('📝 A reason is required. It goes in the log next to your name.')
        const match = getMatch(league, matchId)
        if (!match) return reply(`⛔ No match ${matchId}.`)
        if (match.seatA !== winnerSeat && match.seatB !== winnerSeat) {
          return reply(`⛔ Seat ${winnerSeat} is not in ${matchId}. It is ${seatLabel(league, match.seatA)} against ${seatLabel(league, match.seatB)}.`)
        }
        if (match.result?.applied) return reply(`⛔ ${matchId} is already settled and the result stands.`)
        const loserSeat = match.seatA === winnerSeat ? match.seatB : match.seatA
        // Applied inside the mutator, once. The outcome is read back out so the
        // reply can say where the winner landed.
        let outcome = { changed: false }
        await updateWorldState(db, 'league', (data) => {
          outcome = applyMatchResult(data.league, matchId, resultShapes.admin(winnerSeat, loserSeat, now, from, reason))
          if (outcome.changed) {
            data.league.modLog.push({ at: now, mod: from, action: 'result', matchId, reason })
          }
        })
        return reply(outcome.changed
          ? `🛡️ Recorded. ${seatLabel(league, winnerSeat)} takes it over ${seatLabel(league, loserSeat)}. Rank ${outcome.after?.[winnerSeat]} now.`
          : `⛔ ${matchId} did not change.`)
      }

      case 'noshow': {
        const matchId = args[1]
        const seat = parseInt(args[2], 10)
        if (!matchId || !Number.isInteger(seat)) return reply('🚪 *.ladmin noshow <matchId> <seat>*')
        const match = getMatch(league, matchId)
        if (!match) return reply(`⛔ No match ${matchId}.`)
        if (match.result?.applied) return reply(`⛔ ${matchId} is already settled.`)
        const other = match.seatA === seat ? match.seatB : match.seatA
        const shape = match.type === 'PvA'
          ? resultShapes.byDefault(match.seatA === seat ? match.seatB : match.seatA, seat, now)
          : resultShapes.walkover(other, seat, now)
        await updateWorldState(db, 'league', (data) => {
          applyMatchResult(data.league, matchId, shape)
          data.league.modLog.push({ at: now, mod: from, action: 'noshow', matchId, seat })
        })
        return reply(`🚪 Recorded. ${seatLabel(league, seat)} did not show, ${seatLabel(league, other)} takes the ten.`)
      }

      case 'rollover': {
        const tick = await runLeagueTick(db, null, now, { log: null, send: false })
        return reply(tick.due.length
          ? `🔁 Forced the rollover. Tasks: ${tick.due.join(', ')} on day ${tick.day}.`
          : '🔁 Nothing was due at this moment.')
      }

      case 'finish': {
        // Close the season now. The scheduler would close it on its own once
        // the record is complete; this is the owner's hand on the same books,
        // and it holds the same line: no open match is ever closed over.
        if (league.season.status === 'closed' || league.payouts?.done) {
          return reply('🏁 That season is already closed. The next one opens with *.ladmin newseason* once the break is over.')
        }
        const openMatches = Object.values(league.matches ?? {}).filter(m => !m.result?.applied)
        if (openMatches.length) {
          return reply([
            `🏁 The books cannot close with ${openMatches.length} match(es) still open.`,
            'Settle them with *.ladmin result* or *.ladmin noshow*, then finish again.',
          ].join('\n'))
        }
        const plan = planSeasonClose(league, now, { requireDaysPast: false })
        if (!plan) return reply('🏁 The season has nothing on the card to close.')
        let applied = null
        await updateWorldState(db, 'league', (data) => {
          applied = applySeasonClose(data.league, data.npcs, plan, now)
          data.league.modLog.push({ at: now, mod: from, action: 'finish', honors: plan.honors.seasonId })
        })
        const received = await paySeasonPrizes(db, applied.paid)
        return reply([
          seasonCloseCard(league, applied, { now }),
          '',
          `💰 ${received.length} purse payment(s) made.`,
        ].join('\n'))
      }

      case 'newseason': {
        let res = null
        await updateWorldState(db, 'league', (data) => {
          res = startNewSeason(data.league, now)
          if (res.ok) data.league.modLog.push({ at: now, mod: from, action: 'newseason', season: res.season.id })
        })
        if (!res?.ok) {
          if (res?.problem === 'on_break') {
            return reply([
              '🌙 The season break is still running.',
              `It ends on ${dateLabelWAT(dayStartMsWAT(res.breakUntil))}. The next season can open after that.`,
            ].join('\n'))
          }
          return reply('🏁 The current season has to be closed first. Finish it with *.ladmin finish*.')
        }
        return reply([
          `🌱 *${res.season.id} IS READY.*`,
          'The table is clean and the player seats are open.',
          '',
          `Players now face Master Del Astra for their seat. Open with *.ladmin start* once they have,`,
          `and it seats the acknowledged ones and draws the schedule for you.`,
        ].join('\n'))
      }

      case 'feature': {
        const matchId = args[1]
        if (!matchId) return reply('⭐ *.ladmin feature <matchId>*')
        const match = getMatch(league, matchId)
        if (!match) return reply(`⛔ No match ${matchId}.`)
        await updateWorldState(db, 'league', (data) => {
          const target = data.league.matches[matchId]
          // Only one featured match a day, so clear the rest of that day first.
          for (const m of Object.values(data.league.matches)) {
            if (m.dueDay === target.dueDay) m.broadcast.featured = false
          }
          target.broadcast.featured = true
        })
        return reply(`⭐ ${matchId} is today's featured match. It is posted in the update groups at the featured time.`)
      }

      case 'on':
      case 'off': {
        const want = sub === 'on'
        // Turning the runtime flag on while the build gate is shut would change
        // nothing and read as if the doors were open, so say no instead.
        if (want && leagueUnderConstruction(db)) {
          return reply('🚧 The build gate is shut, so the runtime flag has nothing to switch on. ' +
            'Open the gate with *.ladmin open* first, then *.ladmin on*.')
        }
        await updateWorldState(db, 'league', (data) => { data.league.featureOn = want })
        return reply(want
          ? `🚦 The League is on. ${envFlagOn() ? '' : 'Note the env flag ASTRAL_PROS_ENABLED is off, so nothing will run until it is set and the bot restarts.'}`
          : '🚦 The League is off. Data is kept, timers do no work, and every League command says the League is away.')
      }

      case 'open':
      case 'close': {
        const open = sub === 'open'
        if (open && !envFlagOn()) {
          return reply('🚧 The env flag ASTRAL_PROS_ENABLED is off, so opening the build gate would do nothing. ' +
            'Set it and restart the bot first.')
        }
        await updateWorldState(db, 'league', (data) => { data.league.construction = !open })
        return reply(open
          ? '🚧 Build gate open. League commands now answer, and *.ladmin on* will take effect. ' +
            'Nothing runs for players until the flag is on and a season is drawn.'
          : '🚧 Build gate shut. Every League command tells players the League is under construction, ' +
            'the scheduler does no work, and no state is lost.')
      }

      case 'verify': {
        const matchId = args[1]
        if (!matchId) return reply('🧾 *.ladmin verify <matchId>*')
        let res = null
        await updateWorldState(db, 'league', (data) => {
          res = verifyMatch(data.league, matchId, from, { now, groupJid: ctx.sender })
        })
        if (!res?.ok) return reply(`⛔ ${PROBLEMS[res?.problem] ?? res?.problem ?? 'that match cannot be verified'}.`)
        return reply(`🧾 Verified. ${matchId} is live, and you are recorded as the mod who checked it.`)
      }

      case 'rematch': {
        const matchId = args[1]
        const reason = args.slice(2).join(' ') || null
        if (!matchId) return reply('🔁 *.ladmin rematch <matchId> [reason]*')
        let res = null
        await updateWorldState(db, 'league', (data) => {
          res = rematchMatch(data.league, matchId, from, { now, reason })
        })
        if (!res?.ok) {
          return reply(res?.problem === 'rematch_limit'
            ? `⛔ ${matchId} has been rematched ${res.limit} times. Settle it with *${config.prefix}ladmin result* instead.`
            : `⛔ ${PROBLEMS[res?.problem] ?? res?.problem ?? 'that match cannot be rematched'}.`)
        }
        // Restore both fighters from the snapshot taken when the fight opened.
        // A rematch that only reset the match would resume a fight already half
        // spent, which is not the fight the bug interrupted.
        const restored = await restoreArenaSnapshot(league, matchId, db)
        if (!restored.length) {
          return reply(
            `🔁 ${matchId} restarted, but there was no snapshot to restore, so both fighters start as they are now. ` +
            `Nothing was scored. Rematch ${res.rematches} of ${MOD_REMATCH_LIMIT}.`,
          )
        }
        return reply(
          `🔁 ${matchId} restarted and both fighters restored to where the fight began. ` +
          `Nothing was scored. Rematch ${res.rematches} of ${MOD_REMATCH_LIMIT}.`,
        )
      }

      case 'reschedule': {
        const matchId = args[1]
        const reason = args.slice(2).join(' ') || null
        if (!matchId) return reply('📅 *.ladmin reschedule <matchId> [reason]*')
        let res = null
        await updateWorldState(db, 'league', (data) => {
          res = rescheduleMatch(data.league, matchId, from, {
            now,
            reason,
            dayKeyNow: leagueDayOf(data.league),
            startDay: 1,
          })
        })
        if (!res?.ok) return reply(`⛔ ${PROBLEMS[res?.problem] ?? res?.problem ?? 'that match cannot be moved'}.`)
        if (res.outOfDays) {
          return reply(
            `📅 ${matchId} has nowhere left to go. It sits on the last day of the season and only you can settle it.\n\n` +
            `_${config.prefix}ladmin result ${matchId} <seat> <reason>_, or leave it unresolved and it is recorded as such._`,
          )
        }
        return reply(`📅 ${matchId} moved to day ${res.dueDay}. Nothing was scored and nobody is penalised.`)
      }

      case 'tvprice': {
        const gems = parseInt(args[1], 10)
        const solars = parseInt(args[2], 10)
        const current = tvPrice(league)
        if (!Number.isInteger(gems) || !Number.isInteger(solars) || gems < 0 || solars < 0) {
          return reply([
            '🏟️ *ASTRAL TV PRICES*',
            '',
            `Now: ${current.gems} gems or ${current.solars} solars for ${config.tvDays} days.`,
            '',
            `Set: *${config.prefix}ladmin tvprice <gems> <solars>*`,
          ].join('\n'))
        }
        await updateWorldState(db, 'league', (data) => {
          data.league.tvPrice = { gems, solars }
        })
        return reply(`🏟️ Astral TV now costs ${gems} gems or ${solars} solars for ${config.tvDays} days.`)
      }

      case 'tv':
      case 'stream': {
        // Astral TV on demand, any hour. One message per group that edits
        // itself every few seconds until the winner line.
        const first = String(args[1] ?? '').toLowerCase()
        const mode = ['replay', 'featured'].includes(first) ? first : 'now'
        const dayArg = parseInt(mode === 'now' ? args[1] : args[2], 10)
        const groups = announceGroups()
        const target = groups.length ? groups : (ctx.isGroup ? [ctx.sender] : [])
        const res = await broadcastAstralTv(db, [{ activeSock: ctx.sock }], now, {
          mode,
          day: Number.isInteger(dayArg) ? dayArg : null,
          announce: target,
          log: (m) => console.error(m),
        })
        if (!res.ok) {
          const why = {
            no_season: 'There is no drawn season to broadcast yet. Use *.ladmin draw* and *.ladmin start* first.',
            not_started: 'The season has not started, so there is no match day to air.',
            no_socket: 'The bot has no live connection to broadcast on right now.',
            no_groups: `No update group is set. Run *${config.prefix}astral-ann* in the group, or send this command inside the group itself.`,
            not_today: 'A fresh play out only runs for today. Use *replay <day>* for an earlier day.',
            nothing_to_air: `Nothing has been played for day ${res.day ?? ''} yet, and there are no Adventurer fights to play.`,
            bad_mode: 'Use *.ladmin tv*, *.ladmin tv replay [day]* or *.ladmin tv featured [day]*.',
          }[res.problem] ?? 'That did not start.'
          return reply(`📺⚠️ ${why}`)
        }
        return reply([
          '📺🔴 *ASTRAL TV IS ON AIR*',
          '━━━━━━━━━━━━━━━━━━━━',
          `🎬 *${res.matches}* ${mode === 'featured' ? 'featured match' : 'match'}${res.matches === 1 ? '' : 'es'} for day *${res.day}*, in *${res.groups}* group${res.groups === 1 ? '' : 's'}.`,
          res.played ? `⚔️ *${res.played}* fight${res.played === 1 ? '' : 's'} played out now and settled on the table.` : '🔁 These were already played, so this is a replay and no result changes.',
          '✏️ One message per group, edited every 3 seconds until the winner.',
        ].join('\n'))
      }

      case 'prizes':
      case 'payout':
      case 'close':
      case 'script':
        return reply(LATER_PHASE)

      default:
        return reply(helpText())
    }
  },
}
