/**
 * dm.js — the ASTRATOK dashboard, as its own command.
 *
 * `.dm` for your own numbers. `.dm <player>` to look someone up.
 *
 * ── why this is not just a subcommand ─────────────────────────────────────
 * `.stream dm` works too, but nobody types `.stream dm` when they want their
 * numbers; they think "I want my dashboard". The whole point of this feature is
 * that a creator can check their night privately, and a command nobody finds is
 * not private, it is missing.
 *
 * ── why it whispers in groups ─────────────────────────────────────────────
 * The same card in a group is a performance: nobody wants to show a room that
 * their last stream peaked at four viewers. In a group this sends the card to
 * the caller's DM and says only that it did.
 */
import { config } from '../config.js'
import { getProfile, getLastStream, listHalls } from '../lib/astratok/store.js'
import { listLiveStreams, cmdDashboard } from './stream.js'

const p = () => config.prefix

/** Look up somebody else, by the name their stream is using. */
async function lookup(ctx, token) {
  const raw = String(token ?? '').trim().toLowerCase().replace(/^@/, '')
  const live = listLiveStreams()
  const onAir = live.find(s =>
    String(s.playerName ?? '').toLowerCase() === raw ||
    String(s.playerName ?? '').toLowerCase().split(' ')[0] === raw)

  if (!onAir) {
    return ctx.reply(
      `🔍 *Nobody called "${token}" is live.*\n\n` +
      (live.length
        ? `Live right now: ${live.map(s => `*${s.playerName.split(' ')[0]}*`).join(', ')}`
        : `_Nobody is streaming._`) +
      `\n\n_Use *${p()}stream board* to see the room._`,
    )
  }

  const { liveCard } = await import('../lib/astratok/cards.js')
  const { getStreamRoom } = await import('./stream.js')
  const room = getStreamRoom(onAir.playerId)
  if (room) return ctx.reply(liveCard(room, { prefix: p() }))

  return ctx.reply(
    `📺 *${onAir.playerName}* is live\n` +
    `👁 *${onAir.viewers}* watching · ⚡ ${Math.round(onAir.hype ?? 0)}% hype\n\n` +
    `⭐ *${p()}stream sub ${onAir.playerName.split(' ')[0].toLowerCase()}* · 🎁 *${p()}stream gift ${onAir.playerName.split(' ')[0].toLowerCase()} <gift>*`,
  )
}

export default {
  name: 'dm',
  aliases: ['dashboard', 'astratok-dm'],
  category: 'astratok',
  requiresPlayer: true,
  description: `${config.prefix}dm — your ASTRATOK dashboard, privately`,
  subcommands: [
    { cmd: '', desc: 'your numbers: followers, subs, career, what is next' },
    { cmd: '<player>', desc: 'look up whoever is live right now' },
  ],

  async run(ctx) {
    const { args } = ctx
    const target = args[0]
    if (target) return lookup(ctx, target)
    return cmdDashboard(ctx)
  },
}
