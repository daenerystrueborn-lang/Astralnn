/**
 * buy.js — `.buy <number or name> [count]`: buying from the Sect Empire's cart.
 *
 * `buy` was a FREE command name (Astra Kingdom buys through a SUBCOMMAND of
 * `.shop`), so this is a standalone plugin and Astra's `.shop buy` is left
 * exactly as it was. It only answers inside the Sect Empire, and only at the
 * cart itself — the peddler stands at the Foot of the Mountain Road.
 */
import { config } from '../config.js'
import { sectDoorRefusal } from '../lib/world-guards.js'
import { runSectBuy } from '../lib/sect-item-commands.js'

export default {
  name: 'buy',
  category: 'inventory',
  requiresPlayer: true,
  description: `${config.prefix}buy <number or name> [count] — buy from the roadside peddler (Sect Empire).`,

  async run(ctx) {
    const wrongWorld = sectDoorRefusal(ctx.player, {
      emoji: '🛖', title: '*The roadside peddler trades in the Sect Empire.*',
      here: { cmd: 'shop', label: 'the Astra shops take Solars instead' },
    })
    if (wrongWorld) return ctx.reply(wrongWorld)
    return runSectBuy(ctx)
  },
}
