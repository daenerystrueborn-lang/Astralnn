import { gearRefusal } from '../lib/survival-progression.js'
/**
 * character.js — Free Fire-style characters.
 *
 * Each character (data/characters.json) has exactly one named ability. Equip
 * one at a time, the same one-at-a-time pattern as plugins/pet.js's active pet
 * and plugins/equipbeast.js's active beast.
 *
 * HOW THEY ARE OBTAINED. Routes and shop eligibility are data-driven:
 *   - season content (`seasonId`) is routed to `.season spin` / `.season shop`
 *     / the battle pass, and nothing else can touch it. Monds cannot buy it.
 *   - spin characters normally have a gem banner and a Mond price; a character
 *     can opt out of Mond sales with `mondBuyable: false` (Saber, a Starfall
 *     reward) or use a custom price (`mondPrice`, as Victoria does at 7 Monds).
 *     See lib/monds.js for the currency split and price resolver.
 *
 * A dedicated character banner and its Mond-shop route answer to the owner
 * freeze in lib/spin-locks.js (`.lockspin <name>` / `.unlockspin <name>`): a
 * frozen character can be neither pulled nor bought, and the buy path refuses
 * before any Mond is charged. The price route used to ignore the freeze, making
 * `.lockspin` a lock on one of two doors — see shopLockGate().
 *
 * A one-of-one is still a one-of-one. Buying it with Monds moves the bot-wide
 * lock (claimExclusiveSpinForPlayer) to the buyer, so the purchase wins the race
 * rather than bypassing it, and every later buyer is refused at any price.
 *
 * Gems buy spin ATTEMPTS by default, not characters — that split is the product.
 * The one exception is data-driven: a character carrying `gemPrice` is sold
 * outright in Gems (Klein Moretti, 1,999) through `.character buy <name> gems`.
 *
 * The bot owner can also hand one over directly with `.givecharacter <name>
 * [@user]` (plugins/givecharacter.js → giveCharacter in plugins/admin.js), which
 * bypasses all of the above and, for a one-of-one, moves the bot-wide claim too.
 * `.character info` names whoever holds a character, granted or not.
 *
 * Abilities ARE battle-wired now, in lib/character-abilities.js and the combat
 * plugins that call into it. `statBonuses` is applied and reversed here through
 * applyEquipmentBonus() on equip/unequip.
 *
 * Usage:
 *   <prefix>character                  browse all characters, ownership state
 *   <prefix>character info <name>      full detail view for one character
 *   <prefix>character buy <name>       buy a character outright with Monds
 *   <prefix>character equip <name>     set your active character
 *   <prefix>character unequip          clear your active character
 */
import { config } from '../config.js'
import { characterStars, rarityStars, rarityLabel } from '../lib/rarity.js'
import { isCharacterSlain, slainEquipRefusal } from '../lib/yelan-engine.js'
import { updatePlayer } from '../lib/player-repo.js'
import { fraktur, fmtGems, roundGems } from '../lib/format.js'
// Tutorial hook — fires when a character is first equipped
import { recordTutorialEvent, tutorialNotice } from '../lib/tutorial-engine.js'
import { characters, characterMap } from '../lib/game-data.js'
import { applyEquipmentBonus, attackStatKey } from '../lib/combat-engine.js'
import { repairCharacterBonus, markCharacterBonusFixed } from '../lib/character-bonus-fix.js'
import { syncEmptyVesselFlag, syncLucidImmunityFlag, hasYatoTrueForm } from '../lib/character-abilities.js'
import { sendImage, sendGif } from '../lib/image.js'
import { getExclusiveSpinWinner, claimExclusiveSpinForPlayer, getActiveSeason, seasonPassTierForCharacter, seasons } from '../lib/season-engine.js'
import { getPlayer } from '../lib/player-repo.js'
import { MOND, fmtMonds, getMonds, roundMonds, isMondBuyable, mondPriceFor } from '../lib/monds.js'
import { getSpinBanner, spinCurrency } from '../lib/spin-banners.js'
import { isSpinLocked, shopLockGate } from '../lib/spin-locks.js'
import { characterRefusalInDreamlands } from '../lib/dreamlands-characters.js'
// 👑 The crown pair — ownership, the atomic purchase (the ONE writer) and the
// fused player's view of the roster (lib/queen-king.js).
import { isCrownCharacter, purchaseCrown, visibleCharactersFor } from '../lib/queen-king.js'
import { crownEquipSwap } from '../lib/queen-king-equip.js'
import { noteFairyObtained, syncFairyQueenMp } from '../lib/fairy-queen.js'
import { activeSkin, characterFormName, characterFormImage } from '../lib/character-skins.js'
import { regressorReturnGate } from '../lib/regressor-passives.js'
import { S2_IDS } from '../lib/regressor-state.js'
import { AMIYA_ID, describeAmiyaResonance } from '../lib/amiya-star.js'
import {
  getCharacterPreorderDef,
  getCharacterPreorderRemainingMs,
  isCharacterPreorderReleased,
  formatPreorderCountdown,
  formatPreorderPrice,
  formatPreorderPriceShort,
  hasCharacterPreorderReceipt,
  getExclusivePreorderHolder,
  materializeUnlockedPreorders,
  materializeAllUnlockedPreorders,
  purchaseCharacterPreorder,
} from '../lib/character-preorders.js'

function findCharacter(query) {
  const q = (query ?? '').toLowerCase().trim()
  if (!q) return null
  if (characterMap[q]) return characterMap[q]
  return characters.find(c => c.name.toLowerCase() === q)
    ?? characters.find(c => c.name.toLowerCase().includes(q))
    ?? null
}

function isCharacterRevealed(character, db, player) {
  if (!character?.seasonId || character.seasonId !== 'season_02') return true
  if ((player?.ownedCharacters ?? []).includes(character.id)) return true
  return getActiveSeason(db)?.id === 'season_02'
}

/**
 * Detects whether a character's art is an animated GIF (Tyla & Alya's Twin
 * Bond reveal and Anastasia's Hypnosis clock — see data/characters.json) so
 * callers route through sendGif() instead of sendImage(). sendImage's static
 * { image: { url } } message shape renders a .gif URL as a single still
 * frame with no animation; sendGif uses each platform's real
 * animated-media mechanism (WhatsApp: video+gifPlayback, Discord: raw
 * .gif attachment, Telegram: sendAnimation).
 */
function isAnimatedArt(character) {
  return /\.gif(\?|$)/i.test(character?.image ?? '')
}

/**
 * Renders a character's *display* name/ability heading in whatever script
 * their `fontStyle` field asks for (data/characters.json). Only Anastasia
 * sets one today ("fraktur"), which is why this is a data field rather than
 * an id check — the next character who wants a distinct script needs one
 * JSON line, not an edit here.
 *
 * Deliberately applied to headings ONLY, never to the prose description or
 * ability flavor: those run several lines and Fraktur is much slower to read
 * at that length. Also never applied to a value used for LOOKUP —
 * findCharacter() matches against the plain `c.name`, so styling the stored
 * name would break `.character equip demon lord anastasia`.
 */
function styled(character, text) {
  return character?.fontStyle === 'fraktur' ? fraktur(text) : text
}

/**
 * An ability's bold lines (data/characters.json → ability.quote), one per line
 * because WhatsApp bold does not reach across a line break. '' when none.
 * Victoria Minayoko's card carries hers in bold by the owner's request.
 */
function abilityQuoteBlock(ability) {
  const lines = Array.isArray(ability?.quote) ? ability.quote.filter(Boolean) : []
  return lines.length ? lines.map(l => `*${l}*`).join('\n') + '\n' : ''
}

/**
 * The tier line on a character card.
 *
 * Until the ladder was named (lib/rarity.js CHARACTER_TIERS) only Divinity
 * printed here, because every other character was "boundless" and the line was
 * therefore the same word on 32 of 57 cards. Now every rung has its own name,
 * so the card says which one it is standing on — "★★★★★☄️ Tier: Radiant",
 * "★★★★★🌌 Tier: Boundless", "★★★★★🕊️ Tier: Divinity".
 */
function tierLine(character) {
  const label = rarityLabel(character?.rarity)
  if (!label || label === 'Unknown') return ''
  return `${rarityStars(character.rarity)} *Tier: ${label}*\n`
}

/**
 * renderStory(character, pr) -> string | null
 *
 * A character's story (data/characters.json → `story`, stanzas of lines), every
 * line in italics, then the ability in full. Sent as its own text message: a
 * 42-line poem is far past WhatsApp's 1,024-character image caption.
 */
export function renderStory(character, pr = config.prefix) {
  if (!Array.isArray(character?.story) || !character.story.length) return null
  const stanzas = character.story
    .map(stanza => (Array.isArray(stanza) ? stanza : [stanza]).map(line => `_${line}_`).join('\n'))
    .join('\n\n')
  const a = character.ability ?? {}
  const how = Array.isArray(a.howItWorks) && a.howItWorks.length
    ? `\n\n*How it works*\n${a.howItWorks.map(l => `• ${l}`).join('\n')}`
    : ''
  return (
    `📖 *${character.emoji ?? ''} ${character.name}* ${characterStars(character.stars)}\n` +
    tierLine(character) + `\n` +
    `${stanzas}\n\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `✨ *${a.name ?? 'Ability'}*\n` +
    abilityQuoteBlock(a) +
    (a.description ? `\n${a.description}` : '') +
    how
  )
}

async function sendCharacterArt(ctx, character, caption) {
  return isAnimatedArt(character)
    ? sendGif(ctx, character.image, caption)
    : sendImage(ctx, character.image, caption)
}

/**
 * The art to show for a character, which for exactly one character depends on
 * who is looking: an ascended Yato owner sees his true form instead of the boy
 * (data/characters.json → yato.trueForm.image).
 *
 * Returns a SHALLOW CLONE rather than mutating, because `character` here is the
 * live object out of characterMap — writing `image` onto it would swap the art
 * for every player in the bot, permanently, until restart.
 *
 * Falls back to the normal portrait while trueForm.image is empty, so this
 * never sends a blank card.
 */
function artFor(character, player, surface = 'card') {
  const skin = activeSkin(player, character?.id)
  if (skin) {
    return { ...character, image: characterFormImage(player, character, surface), name: characterFormName(player, character) }
  }
  const trueImage = character?.trueForm?.image
  if (character?.id === 'yato' && trueImage && hasYatoTrueForm(player)) {
    return { ...character, image: trueImage }
  }
  if (surface === 'info' && character?.infoImage) {
    return { ...character, image: character.infoImage }
  }
  return character
}

/**
 * Which spin command obtains a given one-of-one exclusive. A table rather
 * than an inline ternary because the same mapping is needed in three places
 * (overview line, info status line, buy refusal) and the chained-ternary
 * version had to be edited in all three every time an exclusive was added —
 * exactly the kind of drift that leaves one call site pointing at nothing.
 * Returns null for an exclusive with no spin command, which every call site
 * already falls back on by pointing at `.character info <id>`.
 */
const SPIN_ROUTES = {
  miyashi:   'miya-spin',
  nisha:     'ni-spin',
  yoriichi:  'yo-spin',
  tyla_alya: 'tyla-alya-spin',
  anastasia: 'anastasia-spin',
  namidrek: 'namidrek-spin',
  alenious: 'alenious-spin',
  circe:     'circe-spin',
  megumi:    'megumi-spin',
  xiao:      'xiao-spin',
  minna:     'minna-spin',
  shunya:    'shunya-spin',
  ariel:     'ariel-spin',
  yato:      'yato-spin',
  gojo:      'gojo-spin',
  aizen:     'aizen-spin',
  alexa:     'alexa-spin',
  gogeta:    'gogeta-spin',
  cid:       'cid-spin',
  naruto:    'naruto-spin',
  witch_of_envy: 'envy-spin',
  echidna: 'echidna-spin',
  orihime: 'orihime-spin',
  scarlett: 'scarlett-spin',
  ronova: 'ronova-spin',
  sword_maiden: 'sword-spin',
  alpha: 'alpha-spin',
  delta: 'delta-spin',
  yelan: 'yelan-spin',
  avessa: 'avessa-spin',
  beth: 'beth-spin',
  liorei: 'liorei-spin',
  yu_miaoyi: 'yu-miaoyi-spin',
  texas: 'texas-spin',
  saber: 'starfall',
  victoria_minayoko: 'victoria-spin',
  queen_of_fairies: 'queen-spin',
  clane:     'clane-spin',
  the_end:   'end-spin',
  kim_dokja: 'kim-spin',
  rimuru:    'rimuru-spin',
  minato:    'minato-spin',
  rengoku:   'rengoku-spin',
  mei:       'mei-spin',
  surtr:     'surtr-spin',
  remi:      'remi-spin',
  cardia:    'cardia-spin',
  aimiya:    'aimiya-spin',
}

function spinRouteFor(characterId, pr) {
  const cmd = SPIN_ROUTES[characterId]
  return cmd ? `${pr}${cmd}` : null
}

/**
 * The real route to a season character, read from the data that grants it.
 *
 * This used to be hardcoded off `characterTier` (major → `.season spin`, peak →
 * `.season shop buy <id>`, minor → `.season pass claim 40`). None of those were
 * real for Season 2: there is no `.season spin` subcommand, no character in the
 * Season Shop, and tier 40's free reward was a title. So every Season 2 card
 * pointed at a door that is not there. Order now matches what can actually pay
 * out: a spin banner, then the Battle Pass tier whose FREE column awards the
 * character, then a Season Shop character entry, then Monds.
 */
function seasonRouteFor(character, pr) {
  const spin = spinRouteFor(character.id, pr)
  if (spin) return spin
  const passTier = seasonPassTierForCharacter(character.seasonId, character.id)
  if (passTier) return `${pr}season pass claim ${passTier}`
  // The character's OWN season catalog, not the active one: a Season 1 cast
  // member still names the Season 1 shop entry while Season 2 is running.
  const season = seasons.find(s => s.id === character.seasonId)
  const inShop = (season?.shop?.catalog ?? [])
    .some(entry => entry.rewardType === 'character' && entry.id === character.id)
  if (inShop) return `${pr}season shop buy ${character.id}`
  // A Gem-priced character is its own route: `.character buy` charges Gem
  // price when data sets one (Klein Moretti, 1,999).
  if (gemPriceFor(character) !== null) return `${pr}character buy ${character.id}`
  return null
}

/** The Battle Pass tier whose free column awards this season character. */
function passTierFor(character) {
  if (!character?.seasonId) return null
  return seasonPassTierForCharacter(character.seasonId, character.id)
}

/**
 * A banner's per-spin price WITH its currency symbol, e.g. `💎3` or
 * `☀️50,000`, or null when the character has no banner in
 * lib/spin-banners.js. Every roster and info line that quotes a spin price
 * goes through this instead of hardcoding 💎: Rengoku's banner charges Solars,
 * and a card that printed his 50,000 with a Gem on it would be quoting a price
 * nobody can pay.
 */
function spinPriceLabel(characterId) {
  const banner = getSpinBanner(characterId)
  if (!banner) return null
  return spinCurrency(banner) === 'solars'
    ? `☀️${Math.floor(Number(banner.costPerSpin) || 0).toLocaleString('en-US')}`
    : `💎${banner.costPerSpin}`
}

/** The word for what a character's spin is paid in: "Solars" or "gems". */
function spinCurrencyWord(characterId) {
  return spinCurrency(getSpinBanner(characterId)) === 'solars' ? 'Solars' : 'gems'
}

/**
 * A character's Gems price, or null when it has none.
 *
 * Gems buy spin ATTEMPTS by default — that difference (a Gem holder rolls against
 * a dead zone, a Mond holder walks out with the character) is the product. A
 * character can still be sold outright in Gems by carrying `gemPrice` in
 * data/characters.json, which is how Klein Moretti is priced (1,999 Gems) and
 * why he is not in the Mond shop.
 */
function gemPriceFor(character) {
  const price = Math.floor(Number(character?.gemPrice) || 0)
  return price > 0 ? price : null
}

/** fmtGems() with thousands separators — a 4-digit price reads 1,999, not 1999. */
function fmtGemAmount(amount) {
  return fmtGems(amount).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
}

/**
 * True when a character is obtained from a spin. Two different data flags both
 * mean that, and they are NOT the same thing:
 *
 *   exclusive   one-of-one bot-wide, locked to a single holder forever (see
 *               getExclusiveSpinWinner in lib/season-engine.js). The lock is
 *               what makes it one-of-one, not the spin: buying it with Monds
 *               takes the lock too, so there is still only ever one holder.
 *   spinOnly    by itself not one-of-one. Yato and Gojo: no global lock and no fame wall,
 *               so every player who clears the dead zone gets their own copy.
 *
 * This used to mean "cannot be bought at any price" and gated the gem-buy line.
 * It no longer does: most characters with either flag are Mond-buyable
 * (isMondBuyable in lib/monds.js), unless data explicitly opts them out.
 * What these flags still mark is that a SPIN route exists, which is why the
 * remaining callers use them to offer one. Only `exclusive` gets the
 * "claimed by X" treatment.
 */
function isSpinOnly(c) {
  return c?.exclusive === true || c?.spinOnly === true
}

/**
 * Everyone who holds a character right now, newest-registered last, as
 * { names, count, youOwn }. Derived by scanning ownedCharacters rather than kept
 * as its own record, so it cannot drift away from actual ownership the way a
 * separate ledger would: `.admin givecharacter`, the spin plugins and the season
 * shop all write the same one array, and this reads it.
 *
 * Cheap enough to do on demand (one array `includes` per registered player) and
 * it only runs for `.character info`, never in a battle path.
 */
function ownersOf(db, characterId, viewerJid) {
  const users = db?.data?.users ?? {}
  const names = []
  let count = 0
  let youOwn = false
  for (const [jid, pl] of Object.entries(users)) {
    if (!(pl?.ownedCharacters ?? []).includes(characterId)) continue
    count++
    if (jid === viewerJid) { youOwn = true; continue }
    names.push(pl.name ?? 'someone')
  }
  return { names, count, youOwn }
}

/**
 * The "claimed by" line for a character card. Names the holders, because the
 * only way to find out used to be asking in the group, and a granted character
 * had no visible owner at all unless it happened to be a one-of-one.
 *
 * Caps at four names so a widely-owned character cannot push the ability text
 * off a phone screen.
 *
 * Stays quiet when the status line at the bottom of the card is already going to
 * say the same thing: a one-of-one whose bot-wide lock is set renders as
 * "🔒 One-of-one, already claimed by X" down there, and printing both read as a
 * stutter. The line still appears for a one-of-one that somebody owns while the
 * lock sits empty, because that is the case where the status line would
 * otherwise advertise it as unclaimed and still up for grabs.
 */
function claimedLine(db, character, viewerJid) {
  if (character.exclusive && getExclusiveSpinWinner(db, character.id)) return ''
  const { names, count, youOwn } = ownersOf(db, character.id, viewerJid)
  if (!count) return ''
  const shown = names.slice(0, 4)
  const more = names.length - shown.length
  const parts = []
  if (youOwn) parts.push('*you*')
  if (shown.length) parts.push(shown.map(n => `*${n}*`).join(', '))
  const tail = more > 0 ? ` _+${more} more_` : ''
  const label = character.exclusive || count === 1 ? 'Claimed by' : `Claimed by ${count} players:`
  return `👥 *${label}* ${parts.join(', ')}${tail}\n\n`
}

function renderOverview(player, pr, db) {
  materializeAllUnlockedPreorders(db)
  materializeUnlockedPreorders(player)
  const owned = player.ownedCharacters ?? []
  const equippedId = player.equippedCharacter ?? null

  // Future Season 2 characters are withheld until the season goes live; owned
  // characters remain visible at all times. The fused-player filter still runs
  // first so the two crown parents stay hidden for their owner.
  const listedCharacters = visibleCharactersFor(player, characters)
    .filter((character) => isCharacterRevealed(character, db, player))
  const visibleOwnedCount = listedCharacters.filter((character) => owned.includes(character.id)).length
  const lines = listedCharacters.map(c => {
    const isOwned = owned.includes(c.id)
    const isEquipped = equippedId === c.id
    const mondPrice = mondPriceFor(c)
    // Ownership is checked first, because a freeze is not a revocation: someone
    // who already holds the character keeps using it while the door is shut.
    if (isEquipped) return `  ⭐ *${c.emoji} ${characterFormName(player, c)}* ${characterStars(c.stars)} · _equipped_`
    // Slain outranks the ordinary owned line: a dead character is still owned,
    // so without this row it looks equippable and the equip command is the only
    // place that says otherwise.
    if (isOwned && isCharacterSlain(player, c.id)) {
      return `  💀 *${c.emoji} ${c.name}* ${characterStars(c.stars)} · _slain — bring them back with a Revival Stone (${pr}revive ${c.id})_`
    }
    if (isOwned)     return `  ✅ *${c.emoji} ${c.name}* ${characterStars(c.stars)} · _owned (${pr}character equip ${c.id})_`
    // An owner freeze outranks every route line below it, season rows included.
    // The point of the row is to tell a player how to obtain the character, and
    // while it is frozen the honest answer is "you can't" — quoting a price or
    // a season route just sends them at a command that will refuse them.
    if (isSpinLocked(c.id)) {
      return `  🧊 *${c.emoji} ${c.name}* ${characterStars(c.stars)} · _frozen by the owner · not obtainable yet_`
    }
    if (c.seasonId && mondPrice === null) {
      const tier = passTierFor(c)
      const route = seasonRouteFor(c, pr) ?? `${pr}character info ${c.id}`
      const seasonNumber = c.seasonId.match(/season_(\d+)/)?.[1] ?? '?'
      const where = tier ? `free Battle Pass tier ${tier}` : route
      return `  🌞 *${c.emoji} ${c.name}* ${characterStars(c.stars)} · _Season ${seasonNumber} ${c.characterTier}; ${where}_`
    }
    // How many other players hold it, shown on the locked lines only. A granted
    // character used to look identical to one nobody had ever obtained, so there
    // was no way to tell "unobtainable" from "someone already has this".
    const held = ownersOf(db, c.id, null).count
    const heldTag = held > 0 ? ` · 👥${held}` : ''
    // Most spin-obtained characters have TWO ways in, and the line shows both:
    // the spin (gems, attempts) and the Mond price (guaranteed). Data can opt a
    // character out of the Mond route (Saber, who comes from Starfall) — see
    // lib/monds.js. Claim status still reads the same exclusiveSpinWinners lock
    // the spin commands write to.
    if (mondPrice !== null) {
      const spinRoute = spinRouteFor(c.id, pr)
      const spinPrice = spinPriceLabel(c.id)
      const buyRoute = `${pr}character buy ${c.id}`
      const spinLabel = spinRoute ? (spinPrice === null ? spinRoute : `${spinRoute} · ${spinPrice}/spin`) : null
      const obtainLine = spinLabel ? `${MOND}${mondPrice} _or ${spinLabel}_` : `${MOND}${mondPrice} _· ${buyRoute}_`
      if (c.exclusive) {
        const winnerId = getExclusiveSpinWinner(db, c.id)
        if (winnerId) {
          const winner = getPlayer(db, winnerId)
          return `  🔒 *${c.emoji} ${c.name}* ${characterStars(c.stars)} · _claimed by ${winner?.name ?? 'another player'}_`
        }
        return `  🔒 *${c.emoji} ${c.name}* ${characterStars(c.stars)} · ⚡_one-of-one_ · ${obtainLine}`
      }
      return `  🔒 *${c.emoji} ${c.name}* ${characterStars(c.stars)} · ${obtainLine}${heldTag}`
    }
    if (c.mondBuyable === false) {
      const preorderDef = getCharacterPreorderDef(c.id)
      if (preorderDef) {
        const released = isCharacterPreorderReleased(c.id)
        const left = formatPreorderCountdown(getCharacterPreorderRemainingMs(c.id))
        if (!released && hasCharacterPreorderReceipt(player, c.id)) {
          return `  🔖 *${c.emoji} ${c.name}* ${characterStars(c.stars)} · _pre-ordered · releases in ${left}_`
        }
        if (c.exclusive) {
          const holderId = getExclusivePreorderHolder(db, c.id)
          if (holderId) {
            const holder = getPlayer(db, holderId)
            return `  🔒 *${c.emoji} ${c.name}* ${characterStars(c.stars)} · _claimed by ${holder?.name ?? 'another player'}_`
          }
        }
        const oneOfOneTag = c.exclusive ? '⚡_one-of-one_ · ' : ''
        if (!released) {
          return `  🔖 *${c.emoji} ${c.name}* ${characterStars(c.stars)} · ${oneOfOneTag}_Pre-Order: ${formatPreorderPriceShort(preorderDef)} · releases in ${left} (${pr}preorder ${c.id}) · not for sale with Monds_`
        }
        const liveSpinRoute = spinRouteFor(c.id, pr)
        const liveSpinPrice = spinPriceLabel(c.id)
        return `  🎡 *${c.emoji} ${c.name}* ${characterStars(c.stars)} · ${oneOfOneTag}_not for sale with Monds · ${liveSpinRoute}${liveSpinPrice === null ? '' : ` · ${liveSpinPrice}/spin`}_`
      }
      if (c.storyVolume) {
        return `  📖 *${c.emoji} ${c.name}* ${characterStars(c.stars)} · _Story reward: ${c.storyVolume} (${pr}story) · not for sale with Monds_${heldTag}`
      }
      const spinRoute = spinRouteFor(c.id, pr)
      const spinPrice = spinPriceLabel(c.id)
      const routeLine = spinRoute
        ? `${spinRoute}${spinPrice === null ? '' : ` · ${spinPrice}/spin`}`
        : 'another reward route'
      return `  🎡 *${c.emoji} ${c.name}* ${characterStars(c.stars)} · _not for sale with Monds · ${routeLine}_${heldTag}`
    }
    // Owner-granted only: no price or spin, and one holder when exclusive.
    if (c.grantOnly) {
      const winner = c.exclusive ? getExclusiveSpinWinner(db, c.id) : null
      return `  🔒 *${c.emoji} ${c.name}* ${characterStars(c.stars)} · ${winner ? `_claimed by ${getPlayer(db, winner)?.name ?? 'another player'}_` : '⚡_one-of-one_ · _granted by the owner only_'}`
    }
    if (c.spinExclusiveOnly) {
      const winner = getExclusiveSpinWinner(db, c.id)
      return `  🔒 *${c.emoji} ${c.name}* ${characterStars(c.stars)} · ${winner ? '_claimed_' : `⚡_one-of-one_ · ${spinRouteFor(c.id, pr)}`}`
    }
    return `  🔒 *${c.emoji} ${c.name}* ${characterStars(c.stars)} · _no way in yet_${heldTag}`
  })

  return (
    `👤 *Characters* _(${visibleOwnedCount}/${listedCharacters.length} owned)_\n\n` +
    `${lines.join('\n')}\n\n` +
    `_Details: *${pr}character info <name>*_\n` +
    `_Buy eligible characters outright: *${pr}character buy <name>*, paid in ${MOND} Monds (*${pr}monds*)_\n` +
    `_Equip: *${pr}character equip <name>* · Unequip: *${pr}character unequip*_`
  )
}

function renderInfo(character, player, pr, db, viewerJid) {
  materializeAllUnlockedPreorders(db)
  materializeUnlockedPreorders(player)
  const owned = (player.ownedCharacters ?? []).includes(character.id)
  const equipped = player.equippedCharacter === character.id
  const preorderDef = getCharacterPreorderDef(character.id)
  const preorderReleased = preorderDef ? isCharacterPreorderReleased(character.id) : true
  const preorderLeft = preorderDef ? formatPreorderCountdown(getCharacterPreorderRemainingMs(character.id)) : ''
  const preorderedByViewer = preorderDef ? hasCharacterPreorderReceipt(player, character.id) : false
  const winnerId = character.exclusive
    ? (preorderDef ? getExclusivePreorderHolder(db, character.id) : getExclusiveSpinWinner(db, character.id))
    : null
  const winner = winnerId ? getPlayer(db, winnerId) : null
  const spinRoute = spinRouteFor(character.id, pr)
  const route = spinRoute ?? `${pr}character info ${character.id}`
  const mondPrice = mondPriceFor(character)
  // Season route, so a season character's card stops reading "no way in yet"
  // while the overview list is pointing at a perfectly good route for it.
  // seasonRouteFor() reads the ladder/spin/shop data, so it cannot drift from
  // what the season actually pays out (it used to say `.season spin` and
  // `.season pass claim 40`, neither of which existed for Season 2).
  const passTier = passTierFor(character)
  const gemPrice = gemPriceFor(character)
  const seasonRoute = !character.seasonId || mondPrice !== null || gemPrice !== null ? null
    : seasonRouteFor(character, pr)
  const slain = owned && isCharacterSlain(player, character.id)
  const frozenRouteText = mondPrice !== null || gemPrice !== null
    ? `The spin banner, the ${MOND} price and the 💎 price are all closed`
    : 'Its acquisition route is closed'
  const status = equipped
    ? '⭐ _Equipped_'
    : slain
      ? `💀 _Slain by Yelan in a duel. Still yours — equip is locked until a Revival Stone brings them back: ` +
        `*${pr}revival buy* (50 gems), then *${pr}revive ${character.id}*._`
    : owned
      ? `✅ _Owned. Equip with *${pr}character equip ${character.id}*_`
      : isSpinLocked(character.id)
        ? `🧊 _Frozen by the owner. ${frozenRouteText}, so ${character.name} cannot be obtained right now — by anyone, at any price._\n⏳ _Nothing to spend in the meantime; it will go live soon._`
        : preorderDef && !preorderReleased && preorderedByViewer
          ? `🔖 *Pre-Order Secured* · Paid ${formatPreorderPrice(preorderDef)}\n⏳ _Releases in *${preorderLeft}* · unlocks automatically in your roster_\n🔒 _One-of-one exclusive · cannot be bought with Monds_`
        : winnerId && winnerId !== viewerJid
          ? `🔒 _One-of-one, already claimed by *${winner?.name ?? 'another player'}*. Not for sale at any price._`
          : character.grantOnly
            ? `👑 _One-of-one, bot-wide. There is no spin and no price: only the bot owner can grant ${character.name}._`
          : gemPrice !== null
            ? `💎 _Buy outright for 💎*${fmtGemAmount(gemPrice)}*: *${pr}character buy ${character.id}*_\n` +
              (passTier ? `🏅 _Or free on the Battle Pass: *${pr}season pass claim ${passTier}* (free track)._\n` : '') +
              (spinRoute ? `🎡 _Or spin for it with ${spinCurrencyWord(character.id)}${spinPriceLabel(character.id) === null ? '' : ` (${spinPriceLabel(character.id)} per spin)`}: *${spinRoute}*_\n` : '') +
              `_Gems are charged from your wallet once; the character is permanent._`
          : seasonRoute
            ? `🌞 _Not owned. Season ${character.seasonId.match(/season_(\d+)/)?.[1] ?? '?'} ${character.characterTier}: obtain via *${seasonRoute}*._`
            : preorderDef
              ? (!preorderReleased
                  ? `⚡ _One-of-one, bot-wide · the first buyer claims her for good_\n` +
                    `🔖 *Pre-Order Open (${preorderLeft} until release)*\n` +
                    `💰 _Buy in advance for ${formatPreorderPrice(preorderDef)}: *${pr}preorder ${character.id}* (or *${pr}character buy ${character.id}*)._\n` +
                    `⏳ _Unlocks automatically in 1 day (${preorderLeft} remaining)._\n` +
                    `🔒 _Cannot be bought with Monds._`
                  : `⚡ _One-of-one, bot-wide · the first winner claims her for good_\n` +
                    `🎡 _Out now on spin${spinPriceLabel(character.id) === null ? '' : ` (${spinPriceLabel(character.id)} per spin)`}: *${route}*_\n🔒 _Cannot be bought with Monds._`)
            : character.mondBuyable === false && character.storyVolume
              ? `📖 _Story Mode completion reward — cannot be bought with Monds. Complete *${character.storyVolume}* via *${pr}story* to unlock her._`
            : character.mondBuyable === false
              ? `🎡 _Cannot be bought with Monds. Obtain through *${route}*${spinPriceLabel(character.id) === null ? '' : ` (${spinPriceLabel(character.id)} per spin)`}._`
              : character.spinExclusiveOnly
                ? `🎡 _One-of-one, bot-wide. Spin with Solars: *${route}*._`
            : mondPrice !== null
              ? (character.exclusive ? `⚡ _One-of-one, bot-wide. The first buyer takes it for good._\n` : '') +
                `${MOND} _Buy outright for ${MOND}*${mondPrice} Monds*: *${pr}character buy ${character.id}*_\n` +
                (passTier ? `🏅 _Or free on the Battle Pass: *${pr}season pass claim ${passTier}* (free track)._\n` : '') +
                (spinRoute ? `🎡 _Or spin for it with ${spinCurrencyWord(character.id)}${spinPriceLabel(character.id) === null ? '' : ` (${spinPriceLabel(character.id)} per spin)`}: *${spinRoute}*_\n` : '') +
                `_Monds are the only currency a character can be bought with. Get them with *${pr}monds*._`
              : `🔒 _Not owned, and there is no way in yet._`

  // ATK lands on whichever stat the viewer's class attacks with (attackStatKey),
  // so the card says which one instead of leaving "ATK" to guesswork.
  const STAT_LABEL = {
    str: 'STR', agi: 'AGI', int: 'INT', def: 'DEF', lck: 'LCK', maxHp: 'Max HP', maxMp: 'Max MP',
    atk: player?.classId ? `ATK (your ${attackStatKey(player).toUpperCase()})` : 'ATK',
  }
  const bonusLine = Object.entries(character.statBonuses ?? {})
    .filter(([, v]) => v)
    .map(([k, v]) => `${v > 0 ? '+' : ''}${v} ${STAT_LABEL[k] ?? k.toUpperCase()}`)
    .join(' · ')

  // Character blurbs and ability summaries come from data/characters.json.
  // Yato's ascension replaces his base ability, so his card switches to the
  // true-form summary when Live Blast is replaced (see awakenYatoTrueForm()).
  const ascended = character.id === 'yato' && character.trueForm && hasYatoTrueForm(player)
  const skin = activeSkin(player, character.id)
  const shownAbility = ascended ? character.trueForm : {
    ...character.ability,
    name: skin?.def?.abilityName ?? character.ability?.name,
  }
  const shownName = characterFormName(player, character)

  const caption =
    `${character.emoji} *${styled(character, shownName)}*\n${characterStars(character.stars)}\n` +
    tierLine(character) +
    `_${character.description}_\n\n` +
    (character.personality?.tagline ? `🧠 _${character.personality.tagline}_\n\n` : '') +
    `✨ *Ability: ${styled(character, shownAbility.name)}*\n` +
    abilityQuoteBlock(shownAbility) +
    `_${shownAbility.flavor}_\n\n` +
    (character.id === AMIYA_ID ? `${describeAmiyaResonance(player)}\n\n` : '') +
    (bonusLine ? `📊 *While equipped:* ${bonusLine}\n\n` : '') +
    (Array.isArray(character.story) && character.story.length
      ? `📖 _Her story: *${pr}${character.storyCommand ?? `character story ${character.id}`}*_\n\n`
      : '') +
    claimedLine(db, character, viewerJid) +
    status

  return caption
}

/**
 * `.character buy <name>` — the Mond path.
 *
 * Monds (lib/monds.js) buy a character outright. Gems normally buy spin
 * ATTEMPTS in the per-character *-spin.js plugins — a Gem holder rolls against a
 * dead zone, a Mond holder pays the configured price and walks out with the
 * character. A character that carries `gemPrice` is the deliberate exception and
 * is sold in Gems by buyCharacterWithGems() below (Klein Moretti, 1,999).
 *
 * A one-of-one exclusive stays one-of-one. Monds are a way to WIN the race for
 * an unclaimed one, not a way around the lock: the bot-wide claim moves to the
 * buyer, and every later buyer is refused no matter how many Monds they hold.
 *
 * The owner freeze is a different lock and it applies here too. `.lockspin
 * <name>` closes the Mond shop along with the banner (shopLockGate below), which
 * is the whole point of a freeze: the owner uses it to hold a character back for
 * a staged reveal, and a purchase route that ignored it would spoil the reveal
 * the moment a player with enough Monds typed `.character buy`. Checking it
 * FIRST, ahead of the season routing and the one-of-one claim, also means a
 * frozen character reads as frozen rather than as a routing problem or a price
 * problem, and nothing is spent on the way to that answer.
 *
 * Season characters are refused and routed, same as before. Monds deliberately
 * cannot skip a battle pass.
 */
/**
 * `.character buy <name> gems` — the Gem door.
 *
 * Only characters that carry a `gemPrice` reach this (data/characters.json):
 * Gems normally buy spin ATTEMPTS, and this path is the documented exception for
 * a character sold outright in Gems. Ownership, the one-of-one claim and the
 * wallet write all happen inside ONE updatePlayer pass, so a crash can never
 * charge for a character the player does not own.
 */
async function buyCharacterWithGems(ctx, character, price) {
  const pr = config.prefix
  let outcome = null
  await updatePlayer(ctx.db, ctx.from, player => {
    player.ownedCharacters = player.ownedCharacters ?? []
    if (player.ownedCharacters.includes(character.id)) {
      outcome = { reason: 'owned' }
      return
    }
    player.wallet = player.wallet ?? {}
    const gems = Math.max(0, Number(player.wallet.gems) || 0)
    if (gems < price) {
      outcome = { reason: 'gems', gems }
      return
    }
    // A one-of-one still only has one holder: claim before charging, and only
    // charge when the claim was won.
    if (character.exclusive && !claimExclusiveSpinForPlayer(ctx.db, character.id, ctx.from)) {
      const heldBy = getExclusiveSpinWinner(ctx.db, character.id)
      outcome = { reason: 'claimed', claimedBy: getPlayer(ctx.db, heldBy)?.name ?? 'another player' }
      return
    }
    player.wallet.gems = roundGems(gems - price)
    player.ownedCharacters.push(character.id)
    noteFairyObtained(player, character.id)
    outcome = { reason: 'ok', remaining: player.wallet.gems }
  })

  if (outcome.reason === 'owned') {
    return ctx.reply(`✅ You already own *${character.name}*. Equip with *${pr}character equip ${character.id}*.`)
  }
  if (outcome.reason === 'claimed') {
    return ctx.reply(`🔒 *${character.name}* was just claimed by *${outcome.claimedBy}*. Nothing was spent.`)
  }
  if (outcome.reason === 'gems') {
    return ctx.reply(
      `💎 *Not enough Gems.*\n` +
      `*${character.name}* costs 💎*${fmtGemAmount(price)}*. You hold 💎*${fmtGemAmount(outcome.gems)}*. Nothing was spent.\n` +
      `_Top up with *${pr}topup*._`,
    )
  }
  return ctx.reply(
    `🛒 *Purchase complete!*\n━━━━━━━━━━━━━━━━━━━━\n` +
    `${character.emoji ?? '👤'} *${character.name}* ${characterStars(character.stars)} is yours.\n\n` +
    `💰 Paid: 💎*${fmtGemAmount(price)}*  ·  Left: 💎*${fmtGemAmount(outcome.remaining)}*\n\n` +
    `_Equip with *${pr}character equip ${character.id}*._`,
  )
}

async function handleBuy(ctx, character, payToken = null) {
  const pr = config.prefix
  // First line on purpose: a frozen character must be refused before the season
  // routing, the price lookup and the one-of-one claim, so the refusal is free.
  if (shopLockGate(ctx, character.id)) return
  // ── 🔖 In-Game Wallet Character Pre-Orders (Cardia: 70M Solars, Aimiya: 900 Gems, 1-day release, no Monds)
  if (getCharacterPreorderDef(character.id)) {
    return purchaseCharacterPreorder(ctx, character, payToken)
  }
  // ── 👑 Queen Esta and King Yato: the Game Shop owns these two.
  // `.character buy` still answers, because refusing a player who typed the
  // obvious command would be a worse shop than the one they asked for — but it
  // answers by delegating to purchaseCrown(), which is the ONLY writer of crown
  // ownership. That is what keeps the fusion atomic from either doorway: two
  // separate Monds buys through this function would each have to remember to
  // fuse, and a remembered rule is a rule that gets missed.
  if (isCrownCharacter(character.id)) {
    const currency = payToken && !['mond', 'monds'].includes(payToken) ? payToken : 'monds'
    const outcome = await purchaseCrown({
      db: ctx.db,
      from: ctx.from,
      id: character.id,
      currency,
      // The same shared swap the Game Shop hands the purchase: the fusion moves
      // the equipped slot and its bonus bookkeeping in one place, so this door
      // cannot drift from that one.
      onEquip: crownEquipSwap,
    })
    if (!outcome.ok) return ctx.reply(outcome.message ?? `❌ *That purchase could not be completed.*`)
    const fused = outcome.fused
      ? `\n\n👑🌙☀️ *THE CROWNS FUSED*\n_${(outcome.fusionLines ?? []).join(' ')}_`
      : ''
    return ctx.reply(
      `🛒 *Purchase complete!*\n━━━━━━━━━━━━━━━━━━━━\n` +
      `${character.emoji ?? '👤'} *${character.name}* ${characterStars(character.stars)} is yours.\n\n` +
      `💰 Paid: ${MOND}*${outcome.price}*  ·  Left: ${MOND}*${fmtMonds(outcome.remaining)}*${fused}\n\n` +
      `_Equip with *${pr}character equip ${character.id}*._`,
    )
  }
  if (!isCharacterRevealed(character, ctx.db, ctx.player)) {
    return ctx.reply('🌙 Season 2 characters will be revealed when Season 2 goes live. No Monds were spent.')
  }
  // ── 💎 The Gem price. Gems normally buy spin attempts, but a character that
  // carries `gemPrice` is sold outright (Klein Moretti, 1,999). An explicit
  // `gems` token asks for this door; with no token, a character the Mond shop
  // cannot sell defaults to its Gem price instead of a refusal that names no
  // route.
  const gemPrice = gemPriceFor(character)
  const wantsGems = payToken !== null && ['gem', 'gems', '💎'].includes(String(payToken).toLowerCase())
  if (gemPrice !== null && (wantsGems || mondPriceFor(character) === null)) {
    return buyCharacterWithGems(ctx, character, gemPrice)
  }
  if (character.seasonId && mondPriceFor(character) === null) {
    const route = seasonRouteFor(character, pr) ?? `${pr}character info ${character.id}`
    return ctx.reply(`🌞 *${character.name}* is Season content.\nUse *${route}* to obtain this character.`)
  }
  // Read before the mutator so a refusal can name the holder. The authoritative
  // check is claimExclusiveSpinForPlayer() inside the mutator below, which is
  // the only thing that can settle two buyers racing for the same one-of-one.
  if (character.exclusive) {
    const heldBy = getExclusiveSpinWinner(ctx.db, character.id)
    if (heldBy && heldBy !== ctx.from) {
      const holder = getPlayer(ctx.db, heldBy)
      return ctx.reply(
        `🔒 *${character.name}* is a one-of-one exclusive, already claimed by *${holder?.name ?? 'another player'}*.\n` +
        `_Only one player can ever own this character, at any price._`,
      )
    }
  }

  const price = mondPriceFor(character)
  if (price === null) {
    if (character.grantOnly) return ctx.reply(`👑 *${character.name}* is one-of-one and cannot be bought or spun for. Only the bot owner can grant her. No Monds were spent.`)
    if (character.spinExclusiveOnly) {
      const route = spinRouteFor(character.id, pr)
      return ctx.reply(`🔒 *${character.name}* is only obtainable through *${route ?? `${pr}character info ${character.id}`}*. No Monds were spent.`)
    }
    if (character.mondBuyable === false) {
      if (character.storyVolume) {
        return ctx.reply(
          `🔒 *${character.name}* cannot be bought with Monds.\n` +
          `📖 Complete Story Mode: *${character.storyVolume}* (*${pr}story*) to earn her. No Monds were spent.`,
        )
      }
      const route = spinRouteFor(character.id, pr)
      return ctx.reply(
        `🔒 *${character.name}* cannot be bought with Monds.\n` +
        (route ? `🎡 Obtain ${character.name} through *${route}*. ` : '') +
        `No Monds were spent.`,
      )
    }
    return ctx.reply(`🔒 *${character.name}* has no way in yet. Nothing has been spent.`)
  }

  if (payToken && !['mond', 'monds'].includes(String(payToken).toLowerCase())) {
    const gemPrice = gemPriceFor(character)
    return ctx.reply(
      `❌ *${character.name}* cannot be bought with *${payToken}*.\n` +
      `${MOND} *Monds* buy it outright (*${MOND}${price}*): *${pr}character buy ${character.id}*\n` +
      (gemPrice !== null ? `💎 _Or pay 💎*${fmtGemAmount(gemPrice)}*: *${pr}character buy ${character.id} gems*_\n` : '') +
      (spinRouteFor(character.id, pr) ? `🎡 _Or spin for it via *${spinRouteFor(character.id, pr)}*._` : ''),
    )
  }

  let outcome = null
  await updatePlayer(ctx.db, ctx.from, player => {
    player.ownedCharacters = player.ownedCharacters ?? []
    if (player.ownedCharacters.includes(character.id)) {
      outcome = { reason: 'owned' }
      return
    }

    player.wallet = player.wallet ?? {}
    const monds = getMonds(player)
    if (monds < price) {
      outcome = { reason: 'monds', monds }
      return
    }

    // Claim before charging. claimExclusiveSpinForPlayer() only mutates when it
    // wins, so a buyer who lost the race by milliseconds pays nothing.
    if (character.exclusive && !claimExclusiveSpinForPlayer(ctx.db, character.id, ctx.from)) {
      const heldBy = getExclusiveSpinWinner(ctx.db, character.id)
      outcome = { reason: 'claimed', claimedBy: getPlayer(ctx.db, heldBy)?.name ?? 'another player' }
      return
    }

    player.wallet.monds = roundMonds(monds - price)
    player.ownedCharacters.push(character.id)
    noteFairyObtained(player, character.id)
    outcome = { reason: 'ok', remaining: player.wallet.monds }
  })

  if (outcome.reason === 'owned') {
    return ctx.reply(`✅ You already own *${character.name}*. Equip with *${pr}character equip ${character.id}*.`)
  }
  if (outcome.reason === 'claimed') {
    return ctx.reply(
      `🔒 *${character.name}* was claimed by *${outcome.claimedBy}* a moment before you.\n` +
      `_One-of-one, so that is final. Nothing has been spent._`,
    )
  }
  if (outcome.reason === 'monds') {
    const short = price - outcome.monds
    return ctx.reply(
      `${MOND} *Not enough Monds.*\n` +
      `*${character.name}* costs ${MOND}*${price}*. You hold ${MOND}*${fmtMonds(outcome.monds)}*, ` +
      `so you are ${MOND}*${fmtMonds(short)}* short.\n\n` +
      `_Monds are the only currency that buys a character. Get some with *${pr}monds*._` +
      (spinRouteFor(character.id, pr) ? `\n_Or spin for this one instead: ${spinRouteFor(character.id, pr)}_` : ''),
    )
  }

  const claimNote = character.exclusive
    ? `\n⚡ _One-of-one. It is locked to you bot-wide now, and nobody else can ever buy or spin it._`
    : ''
  return ctx.reply(
    `🛒 *Purchase complete!*\n━━━━━━━━━━━━━━━━━━━━\n` +
    `${character.emoji} *${character.name}* ${characterStars(character.stars)} is yours.\n` +
    `✨ *${character.ability?.name ?? 'Ability'}*\n\n` +
    `💰 Paid: ${MOND}*${price}*  ·  Left: ${MOND}*${fmtMonds(outcome.remaining)}*${claimNote}\n\n` +
    `_Equip with *${pr}character equip ${character.id}*._`,
  )
}

async function handleEquip(ctx, character) {
  const pr = config.prefix
  const required = Math.max(character.levelReq ?? 1, character.stars >= 5 ? 60 : character.stars >= 4 ? 30 : character.stars >= 3 ? 15 : 1)
  const gateItem = { ...character, levelReq: required }
  let outcome = null

  await updatePlayer(ctx.db, ctx.from, player => {
    materializeUnlockedPreorders(player)
    const owned = player.ownedCharacters ?? []
    if (!owned.includes(character.id)) {
      if (hasCharacterPreorderReceipt(player, character.id) && !isCharacterPreorderReleased(character.id)) {
        outcome = { reason: 'preordered', remainingMs: getCharacterPreorderRemainingMs(character.id) }
        return
      }
      outcome = { reason: 'not_owned' }
      return
    }
    if (gearRefusal(player, gateItem)) { outcome = { reason: 'attunement' }; return }
    // Slain is checked BEFORE the already-equipped shortcut and re-checked here
    // against the live record: the death lands inside a PvP turn, so this is the
    // one place that can still be holding a stale copy of the flag.
    if (isCharacterSlain(player, character.id)) { outcome = { reason: 'slain' }; return }
    if (character.id === S2_IDS.kim) {
      const returnMs = regressorReturnGate(player)
      if (returnMs > 0) { outcome = { reason: 'away', hours: Math.ceil(returnMs / 3600000) }; return }
    }
    if (player.equippedCharacter === character.id) { outcome = { reason: 'already' }; return }

    // Swap stat bonuses the same way plugins/pet.js swaps an active pet:
    // strip the outgoing character's bonuses, then add the incoming one's.
    // Characters without a statBonuses block are a no-op here.
    const oldDef = player.equippedCharacter ? characterMap[player.equippedCharacter] : null
    // A Beth or Liorei worn since before their bonus keys were fixed is made
    // whole BEFORE it is subtracted, or the swap would take back HP the player
    // never got (lib/character-bonus-fix.js). A no-op for everyone else.
    repairCharacterBonus(player)
    if (oldDef?.statBonuses) applyEquipmentBonus(player, oldDef, -1)
    if (character.statBonuses) applyEquipmentBonus(player, character, +1)

    player.equippedCharacter = character.id
    markCharacterBonusFixed(player) // the full bonus went on, so the boot repair must never add to it
    syncEmptyVesselFlag(player) // Shunya ⇒ statusImmune; equipping anyone else clears it
    syncLucidImmunityFlag(player) // Yu Miaoyi ⇒ statusImmuneSilent; equipping anyone else clears it
    // 🧚‍♀️ Queen of Fairies — the 10,000 MP floor. Idempotent: it lifts the pool
    // when she goes on and gives the borrowed points back when she comes off.
    syncFairyQueenMp(player)

    // ── Tutorial hook: character claimed (first time equipping) ──────
    outcome = { reason: 'ok', tutorial: recordTutorialEvent(player, 'character_claimed') }
  })

  if (outcome.reason === 'attunement') return ctx.reply(gearRefusal(ctx.player, gateItem) ?? 'Attunement changed; try again.')
  if (outcome.reason === 'preordered') {
    const left = formatPreorderCountdown(outcome.remainingMs)
    return ctx.reply(
      `🔖 *${character.name} is on Pre-Order!*\n` +
      `⏳ *Releases in:* *${left}*\n` +
      `_Your receipt is locked — she unlocks in your roster automatically the instant the 1-day countdown finishes!_`,
    )
  }
  if (outcome.reason === 'not_owned') {
    const preorderDef = getCharacterPreorderDef(character.id)
    if (preorderDef) {
      const released = isCharacterPreorderReleased(character.id)
      const left = formatPreorderCountdown(getCharacterPreorderRemainingMs(character.id))
      return ctx.reply(
        `❌ You don't own *${character.name}*.\n` +
        (!released
          ? `🔖 _Pre-Order now for ${formatPreorderPrice(preorderDef)} (releases in *${left}*): *${pr}preorder ${character.id}*_\n🔒 _Cannot be bought with Monds._`
          : `🎡 _Spin for her now${spinPriceLabel(character.id) === null ? '' : ` (${spinPriceLabel(character.id)} per spin)`}: *${spinRouteFor(character.id, pr)}*_\n🔒 _Cannot be bought with Monds._`),
      )
    }
    // A frozen character gets the freeze, not a shop window: this reply used to
    // hand out *both* routes it can no longer use, which reads as the bot
    // lying. No charge is implied here, so it is the plain notice rather than
    // shopLockGate()'s "nothing was charged" refusal.
    if (isSpinLocked(character.id)) {
      return ctx.reply(
        `🧊 *${character.name} is frozen.* You don't own it, and there is no way to get it right now — ` +
        `the spin banner and the ${MOND} price are both closed until the owner unlocks it.`,
      )
    }
    // Route-aware, and there are now two routes for most of the roster: the
    // Mond buy (guaranteed) and the character's own spin (gems, attempts).
    // Season characters have neither and fall through to the info card.
    const mondPrice = mondPriceFor(character)
    const spinRoute = isSpinOnly(character) ? spinRouteFor(character.id, pr) : null
    if (mondPrice !== null) {
      return ctx.reply(
        `❌ You don't own *${character.name}*.\n` +
        `${MOND} _Buy it outright for ${MOND}*${mondPrice}*: *${pr}character buy ${character.id}*_` +
        (spinRoute ? `\n🎡 _Or spin for it with ${spinCurrencyWord(character.id)}: *${spinRoute}*_` : ''),
      )
    }
    if (character.mondBuyable === false && character.storyVolume) {
      return ctx.reply(
        `❌ You don't own *${character.name}*.\n` +
        `📖 _She cannot be bought with Monds — complete Story Mode: *${character.storyVolume}* (*${pr}story*) to unlock her._`,
      )
    }
    return ctx.reply(`❌ You don't own *${character.name}*. See *${pr}character info ${character.id}*.`)
  }
  if (outcome.reason === 'slain') {
    return ctx.reply(slainEquipRefusal(character, pr))
  }
  if (outcome.reason === 'away') {
    return ctx.reply(`⏳ *Kim Dokja is away.* Eight Lives returns him in about ${outcome.hours} hour${outcome.hours === 1 ? '' : 's'}.`)
  }
  if (outcome.reason === 'already') {
    return ctx.reply(`⚠️ *${character.name}* is already equipped.`)
  }
  // Ascension never changes on equip, so reading the flag off ctx.player is safe
  // here even though the mutator above has already run. Without this, re-equipping
  // an ascended Yato would announce Live Blast, a move he can no longer use.
  const equipSkin = activeSkin(ctx.player, character.id)
  const shown = (character.id === 'yato' && character.trueForm && hasYatoTrueForm(ctx.player))
    ? character.trueForm
    : { ...character.ability, name: equipSkin?.def?.abilityName ?? character.ability?.name }
  const caption =
    `✅ *${character.emoji} ${characterFormName(ctx.player, character)}* equipped!\n\n` +
    `✨ *Ability: ${shown.name}*\n` + abilityQuoteBlock(shown) + `_${shown.flavor}_` +
    (outcome.tutorial ? `\n\n${tutorialNotice(outcome.tutorial, pr)}` : '')
  return sendCharacterArt(ctx, artFor(character, ctx.player), caption)
}

async function handleUnequip(ctx, player) {
  if (!player.equippedCharacter) return ctx.reply(`❌ You don't have an equipped character.`)

  const oldDef = characterMap[player.equippedCharacter]
  await updatePlayer(ctx.db, ctx.from, p => {
    const def = p.equippedCharacter ? characterMap[p.equippedCharacter] : null
    repairCharacterBonus(p) // see handleEquip: never subtract a bonus that was never added
    if (def?.statBonuses) applyEquipmentBonus(p, def, -1)
    p.equippedCharacter = null
    syncEmptyVesselFlag(p) // clears statusImmune when Shunya is removed
    syncLucidImmunityFlag(p) // clears statusImmuneSilent when Yu Miaoyi is removed
    syncFairyQueenMp(p) // 🧚‍♀️ hands the borrowed 10,000 MP back
  })
  return ctx.reply(`✅ *${oldDef?.name ?? 'Character'}* is no longer equipped.`)
}

export default {
  name: 'character',
  // `.victoria` opens Victoria Minayoko's story directly (owner's request:
  // "if ppl want to see her story").
  aliases: ['characters', 'char', 'victoria'],
  category: 'account',
  requiresPlayer: true,
  description: `${config.prefix}character · browse, equip, and read up on characters`,

  async run(ctx) {
    const { player, args, db } = ctx
    const pr = config.prefix
    const sub = (args[0] ?? '').toLowerCase()

    // `.character story <name>`, and `.victoria` for hers.
    if (sub === 'story' || sub === 'lore' || ctx.cmd === 'victoria') {
      const query = ctx.cmd === 'victoria' && sub !== 'story' && sub !== 'lore' ? 'victoria_minayoko' : args.slice(1).join(' ')
      const character = findCharacter(query)
      if (!character) return ctx.reply(`❌ *"${query}"* isn't a character. See *${pr}character* for the list.`)
      if (!isCharacterRevealed(character, db, player)) return ctx.reply('🌙 Season 2 characters will be revealed when Season 2 goes live.')
      const story = renderStory(character, pr)
      if (!story) return ctx.reply(`📖 *${character.name}* has no story written yet. See *${pr}character info ${character.id}*.`)
      return ctx.reply(story)
    }

    if (sub === 'info') {
      const query = args.slice(1).join(' ')
      const character = findCharacter(query)
      if (!character) return ctx.reply(`❌ *"${query}"* isn't a character. See *${pr}character* for the list.`)
      if (!isCharacterRevealed(character, db, player)) return ctx.reply('🌙 Season 2 characters will be revealed when Season 2 goes live.')
      return sendCharacterArt(ctx, artFor(character, player, 'info'), renderInfo(character, player, pr, ctx.db, ctx.from))
    }

    if (sub === 'buy' || sub === 'preorder' || sub === 'pre-order') {
      const rawArgs = args.slice(1)
      const lastArg = (rawArgs[rawArgs.length - 1] ?? '').toLowerCase()
      const CURRENCY_TOKENS = new Set(['mond', 'monds', 'gem', 'gems', 'solar', 'solars', 'gold', 'coin', 'coins'])
      let payToken = null
      let query = rawArgs.join(' ')
      let character = findCharacter(query)
      if (rawArgs.length >= 2 && CURRENCY_TOKENS.has(lastArg)) {
        const strippedQuery = rawArgs.slice(0, -1).join(' ')
        const strippedChar = findCharacter(strippedQuery)
        if (strippedChar) {
          character = strippedChar
          query = strippedQuery
          payToken = lastArg
        }
      }
      if (!character) return ctx.reply(`❌ *"${query}"* isn't a character. See *${pr}character* for the list.`)
      return handleBuy(ctx, character, payToken)
    }

    if (sub === 'equip') {
      const query = args.slice(1).join(' ')
      const character = findCharacter(query)
      if (!character) return ctx.reply(`❌ *"${query}"* isn't a character. See *${pr}character* for the list.`)
      if (!isCharacterRevealed(character, db, player)) return ctx.reply('🌙 Season 2 characters will be revealed when Season 2 goes live.')
      // The Dreamlands' cold (the owner's amendment): a character that cannot
      // withstand it is stowed while its player is in the realm, and neither
      // door of the equip swap works out there — equipping would stack a second
      // character beside the stowed one, unequipping would double-strip a bonus
      // that is already stripped. See lib/dreamlands-characters.js.
      const coldRefusal = characterRefusalInDreamlands(player, pr)
      if (coldRefusal) return ctx.reply(coldRefusal)
      return handleEquip(ctx, character)
    }

    if (sub === 'unequip') {
      const coldRefusal = characterRefusalInDreamlands(player, pr)
      if (coldRefusal) return ctx.reply(coldRefusal)
      return handleUnequip(ctx, player)
    }

    return ctx.reply(renderOverview(player, pr, ctx.db))
  },
}
