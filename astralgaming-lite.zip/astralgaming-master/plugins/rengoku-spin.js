// <prefix>rengoku-spin [amount] - Kyojuro Rengoku's Season 2 Solars chase.
// 50,000 Solars per spin, 400 spins, guaranteed by spin 400. One-of-one
// bot-wide. The OTHER door is .character buy rengoku for 4 Monds — a spin
// never charges Monds, and this one never charges Gems either: the banner's
// currency is Solars (lib/spin-banners.js), and the shared runner reads it
// from there. docs/season-02-characters/rengoku.md. Copy shows
// count/cost/guarantee only.
import { runRegressorSpin } from '../lib/regressor-spin-runner.js'

export default {
  name: 'rengoku-spin',
  aliases: ['rengokuspin', 'flame-spin', 'hashira-spin'],
  category: 'character',
  requiresPlayer: true,
  description: 'Spin for Kyojuro Rengoku - 50,000 Solars per spin, one-of-one, guaranteed by spin 400',
  async run(ctx) { return runRegressorSpin(ctx, 'rengoku') },
}
