/**
 * mirroradmin.js — owner tools for The World That Never Ends.
 *
 *   <prefix>mirroradmin release @player|name           free release from the glass
 *   <prefix>mirroradmin restore @player|name [id]      reverse an offering (last one by default)
 *   <prefix>mirroradmin audit [@player|name]           the offering/release audit log
 *   <prefix>mirroradmin close @player|name             close a stuck run quietly, no reward, no lock
 */

import { config } from '../config.js'
import { updatePlayer, getPlayer, updateWorldState, findPlayerByName } from '../lib/player-repo.js'
import { extractTarget, isOwnerJid } from '../lib/group-helpers.js'
import { adminRelease, reverseOffering, isLocked } from '../lib/inverted-usurp.js'
import { getRun } from '../lib/inverted-run.js'
import { audit, auditFor } from '../lib/inverted-world.js'
import { OFFERING_DEPS } from './offering.js'

function resolveTarget(ctx, tokens) {
  const jid = extractTarget(ctx)
  if (jid && getPlayer(ctx.db, jid)) return jid
  const q = tokens.join(' ').trim()
  if (!q) return null
  const users = ctx.db.data?.users ?? {}
  const digits = q.replace(/\D/g, '')
  if (digits.length >= 7) {
    const key = Object.keys(users).find(k => k.startsWith(digits))
    if (key) return key
  }
  const u = findPlayerByName(users, q)
  if (!u) return null
  return Object.keys(users).find(k => users[k] === u) ?? u.id ?? null
}

export default {
  name: 'mirroradmin',
  aliases: ['invadmin'],
  category: 'admin',
  requiresPlayer: false,
  description: 'Owner only: The World That Never Ends — release, restore offerings, audit, close runs',
  subcommands: [
    { cmd: 'release @player', desc: 'free release from the glass' },
    { cmd: 'restore @player [id]', desc: 'reverse an offering' },
    { cmd: 'audit [@player]', desc: 'audit log' },
    { cmd: 'close @player', desc: 'close a stuck run quietly' },
  ],

  async run(ctx) {
    if (!ctx.from || !isOwnerJid(ctx.from)) return ctx.reply('❌ This command is restricted to the bot owner.')
    const p = config.prefix
    const sub = String(ctx.args?.[0] ?? '').toLowerCase()
    const rest = ctx.args.slice(1)

    if (sub === 'audit') {
      const id = rest.length || extractTarget(ctx) ? resolveTarget(ctx, rest) : null
      const rows = auditFor(ctx.db.data, id, 20)
      if (!rows.length) return ctx.reply('📜 The audit log is empty.')
      return ctx.reply(`📜 *Inverted audit*${id ? ` · ${getPlayer(ctx.db, id)?.name ?? id}` : ''}\n\n` + rows.map(r => {
        const o = r.offering ?? {}
        const what = o.kind === 'solars' ? `${o.amount} Solars` : o.kind === 'gems' ? `${o.amount} Gems` : o.kind === 'character' ? `character ${o.characterId}` : ''
        return `• ${new Date(r.at).toISOString().slice(0, 16)} · ${getPlayer(ctx.db, r.playerId)?.name ?? r.playerId} · *${r.kind}* ${what}${o.id ? ` _(${o.id})_` : ''}`
      }).join('\n'))
    }

    if (!['release', 'restore', 'reverse', 'close'].includes(sub)) {
      return ctx.reply(`Usage: *${p}mirroradmin release|restore|audit|close @player*`)
    }
    const offeringId = sub === 'restore' || sub === 'reverse'
      ? rest.find(t => /^off_/.test(t)) ?? null
      : null
    const id = resolveTarget(ctx, rest.filter(t => t !== offeringId))
    if (!id) return ctx.reply('Who? Mention, reply to, or name the player.')

    let res = null
    await updatePlayer(ctx.db, id, (pl) => {
      if (sub === 'release') res = isLocked(pl) ? adminRelease(pl, Date.now(), ctx.from) : null
      else if (sub === 'close') {
        const run = getRun(pl)
        if (run) { run.closed = true; run.result = 'admin_closed'; run.closedAt = Date.now(); run.fight = null; pl.inverted.pendingAction = null; res = { id: run.id } }
      } else res = reverseOffering(pl, offeringId, OFFERING_DEPS, Date.now())
      return pl
    })
    const name = getPlayer(ctx.db, id)?.name ?? id
    if (sub === 'release') {
      if (!res) return ctx.reply(`${name} is not locked.`)
      await updateWorldState(ctx.db, 'inverted', (data) => audit(data, { playerId: id, kind: 'admin_release', by: ctx.from }))
      return ctx.reply(`🔓 ${name} has been released from the glass (free). Their double is gone.`)
    }
    if (sub === 'close') {
      if (!res) return ctx.reply(`${name} has no open run.`)
      await updateWorldState(ctx.db, 'inverted', (data) => audit(data, { playerId: id, kind: 'admin_close', runId: res.id, by: ctx.from }))
      return ctx.reply(`⬜ ${name}'s run was closed quietly. No reward, no lock.`)
    }
    if (!res?.ok) return ctx.reply(`Nothing to restore for ${name}${offeringId ? ` with id ${offeringId}` : ''}.`)
    if (res.duplicate) return ctx.reply(`That offering was already restored.`)
    await updateWorldState(ctx.db, 'inverted', (data) => audit(data, { playerId: id, kind: 'admin_restore', offering: { ...res.entry }, by: ctx.from }))
    return ctx.reply(`↩️ Restored ${name}'s offering (${res.entry.kind}${res.entry.amount ? ` ${res.entry.amount}` : ''}${res.entry.characterId ? ` ${res.entry.characterId}` : ''}). The lock was not re-applied.`)
  },
}
