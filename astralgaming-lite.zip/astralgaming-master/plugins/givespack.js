/**
 * givespack.js — .givespack <tier> <player>
 *
 * Owner only. Gifts a Starter Pack tier (silver, diamond or core) to a player
 * for free: no gems are taken from anybody. It runs as ONE serialized
 * updatePlayer mutation through the same room check and the same grant that
 * `.starterpack buy` uses (checkPackRoom / commitPackGrant), so a gift lands
 * exactly like a purchase would: the 18 bag items, the pet, the summon, and
 * the tier marker (which is what drives KitX capacity).
 *
 * Tiers are NOT forced in order for a gift: `.givespack core Name` hands over
 * Core straight away. Any LOWER tier the player does not own yet is marked
 * owned, with no extra items, so the sequential `.starterpack buy` rule can
 * never ask them to pay gems for a tier that Core already covers.
 *
 * Owner authority beats prior ownership: gifting a tier the player ALREADY
 * owns goes through anyway — the bag items land again (pets and summons are
 * never duplicated, and the ownership marker is kept single). Only battle
 * state and bag/beast room can stop a gift. Nothing is written if the bag or
 * beast roster has no room or the player is mid battle.
 */
import { config } from '../config.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import { findPlayerByName, getPlayer, updatePlayer } from '../lib/player-repo.js'
import { pushNotificationSync } from '../lib/notification-repo.js'
import { starterPacks } from '../lib/game-data.js'
import { findStarterPack, kitxCapacity } from '../lib/starter-pack-engine.js'
import { inventoryFullMessage } from '../lib/inventory-limits.js'
import { BEAST_MAX_OWNED } from '../lib/beast-engine.js'
import { checkPackRoom, commitPackGrant } from './starterpack.js'

const usage = () => `🎁 *Usage:* *${config.prefix}givespack <silver|diamond|core> <player name>*\n_You can also @mention the player, reply to them, or give their number._`

/** @mention, reply, a typed number, then a name. Returns { jid, player } or null. */
function resolveTarget(ctx, text) {
  const info = ctx.msg?.message?.extendedTextMessage?.contextInfo
  const users = ctx.db?.data?.users ?? {}
  const direct = info?.mentionedJid?.[0] ?? info?.participant ?? null
  if (direct && users[direct]) return { jid: direct, player: users[direct] }

  const raw = String(text ?? '').trim().replace(/^@/, '')
  if (!raw) return null
  if (/^\+?[\d\s-]{6,}$/.test(raw)) {
    const jid = `${raw.replace(/\D/g, '')}@s.whatsapp.net`
    if (users[jid]) return { jid, player: users[jid] }
  }
  const byName = findPlayerByName(users, raw)
  if (!byName) return null
  const jid = Object.keys(users).find((id) => users[id] === byName)
  return jid ? { jid, player: byName } : null
}

export default {
  name: 'givespack',
  aliases: ['givestarterpack', 'givepack'],
  category: 'admin',
  requiresPlayer: false,
  description: 'Owner-only: gift a Starter Pack tier (silver, diamond, core) to a player',

  async run(ctx) {
    if (!ctx.from || !isOwnerJid(ctx.from)) {
      return ctx.reply('❌ This command is restricted to the bot owner.')
    }
    const args = Array.isArray(ctx.args) ? ctx.args : []
    const pack = findStarterPack(args[0])
    if (!pack) return ctx.reply(`❌ Pick a tier: *silver*, *diamond* or *core*.\n\n${usage()}`)

    const target = resolveTarget(ctx, args.slice(1).join(' '))
    if (!target) {
      return ctx.reply(`❌ I could not find that registered player.\n\n${usage()}`)
    }

    let outcome = null
    await updatePlayer(ctx.db, target.jid, (player) => {
      if (player.inBattle || player.battleState) { outcome = { reason: 'battle' }; return player }
      // Owner authority: an already-owned tier is NOT a barrier. The gift is
      // simply issued again — the bag items land a second time, while pets and
      // summons stay single. Only real room limits can refuse it.
      const reissued = (player.ownedStarterPacks ?? []).includes(pack.id)
      const room = checkPackRoom(player, pack)
      if (room) { outcome = { ...room, player }; return player }

      const inventoryIds = commitPackGrant(player, pack)
      // Cover the tiers below, so a gift of Core is never followed by a paid Silver.
      const covered = []
      for (const lower of starterPacks.filter((entry) => entry.tier < pack.tier)) {
        if ((player.ownedStarterPacks ?? []).includes(lower.id)) continue
        player.ownedStarterPacks.push(lower.id)
        covered.push(lower.name)
      }
      outcome = { reason: 'ok', inventoryIds, covered, reissued, kitx: kitxCapacity(player) }
      return player
    })

    const name = getPlayer(ctx.db, target.jid)?.name ?? target.player?.name ?? 'that player'
    switch (outcome?.reason) {
      case 'ok': break
      case 'battle': return ctx.reply(`⚔️ *${name}* is in a battle. Gift it after the fight; nothing was changed.`)
      case 'full': return ctx.reply(`❌ *${name}*'s bag is full.\n${inventoryFullMessage(outcome.player)}\n_Nothing was changed._`)
      case 'beasts': return ctx.reply(`❌ *${name}*'s summoned-beast roster is full (${BEAST_MAX_OWNED}/${BEAST_MAX_OWNED}). Nothing was changed.`)
      default: return ctx.reply('❌ The gift did not go through. Nothing was changed.')
    }

    try {
      pushNotificationSync(ctx.db, target.jid, {
        kind: 'gift',
        title: `You were gifted the ${pack.name}`,
        body: `The owner gifted you the ${pack.name}. ${outcome.inventoryIds.length} items are in your bag. Open it with ${config.prefix}use ${pack.id}_chest.`,
      })
    } catch {}

    return ctx.reply(
      `🎁✅ *${pack.name} gifted to ${name}!*\n\n` +
      (outcome.reissued
        ? `♻️ They already had this tier — owner authority issued it again, no questions asked. Pet/summon are not duplicated.\n`
        : '') +
      `🎒 *${outcome.inventoryIds.length}* items added to their bag, plus the pack's pet and summon.\n` +
      `🧰 KitX capacity is now *${outcome.kitx}* loadout${outcome.kitx === 1 ? '' : 's'}.\n` +
      (outcome.covered.length ? `🔓 Marked as owned (no extra items): *${outcome.covered.join(', ')}*.\n` : '') +
      `💎 No gems were charged.`,
    )
  },
}
