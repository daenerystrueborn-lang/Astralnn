/**
 * instruct.js — a senior disciple gives you a line on your breathing.
 *
 *   .instruct           the seniors who will instruct you here
 *   .instruct <name>    ask one of them
 *
 * The instruction is spent by your next cave session: it runs 15% faster.
 * One instruction a WAT day. See lib/sect-instruct.js.
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { sectDoorRefusal } from '../lib/world-guards.js'
import { hereSect } from '../lib/sect-town.js'
import { instructorsOf, instructRefusal, giveInstruction, INSTRUCT_BOOST } from '../lib/sect-instruct.js'

export default {
  name: 'instruct',
  aliases: ['teach', 'coach'],
  category: 'town',
  requiresPlayer: true,
  description: 'Ask a senior disciple for instruction before your next cave session',
  subcommands: [
    { cmd: '', desc: 'list the seniors who will instruct you' },
    { cmd: '<name>', desc: 'ask one of them for instruction' },
  ],

  async run(ctx) {
    const p = config.prefix
    const wrongWorld = sectDoorRefusal(ctx.player, {
      emoji: '📚', title: '*Instructors teach in the Sect Empire.*',
      here: { cmd: 'menu', label: 'see everything Astra offers instead' },
    })
    if (wrongWorld) return ctx.reply(wrongWorld)
    const sect = hereSect(ctx.player)
    if (!sect) return ctx.reply(`📚 *Nobody to learn from here.* _Walk to a sect hall first: *${p}travel* or *${p}town*._`)
    if (!ctx.player.sect) return ctx.reply(`📚 *You have not joined a sect yet.* _Read the five mountains with *${p}sect*, then join one at its Outer Gate._`)

    const seniors = instructorsOf(sect)
    const query = ctx.args.join(' ').trim().toLowerCase()
    if (!query) {
      const lines = seniors.map(n => `  • *${n.name}* _(${n.title})_ · *${p}instruct ${n.id}*`)
      return ctx.reply([`*Seniors of ${sect.name}*`, ...lines,
        `*One instruction a day. The next cave session runs ${Math.round(INSTRUCT_BOOST * 100)}% faster.*`].join('\n'))
    }
    const npc = seniors.find(n => n.id === query || n.name.toLowerCase() === query)
      ?? seniors.find(n => n.name.toLowerCase().includes(query))
    if (!npc) return ctx.reply(`*No senior called ${ctx.args.join(' ')} here.*`)

    const pre = instructRefusal(ctx.player.sect, npc, Date.now())
    if (pre?.reason === 'favor') return ctx.reply(`*${npc.name} does not teach a stranger. Talk with them more first.*`)
    if (pre?.reason === 'daily') return ctx.reply(`*You have had your instruction for today.*`)
    if (pre?.reason === 'pending') return ctx.reply(`*You still carry an instruction. Use it in a cave session first.*`)

    let given = null
    await updatePlayer(ctx.db, ctx.from, fresh => {
      if (!fresh.sect || instructRefusal(fresh.sect, npc, Date.now())) return fresh
      given = giveInstruction(fresh.sect, npc, Date.now())
      return fresh
    })
    if (!given) return ctx.reply(`*The lesson could not be given. Try again in a moment.*`)
    return ctx.reply(`*${npc.name} corrects your breathing.* ` +
      `*Your next cave session runs ${Math.round(INSTRUCT_BOOST * 100)}% faster.*`)
  },
}
