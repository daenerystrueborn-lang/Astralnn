/**
 * bond.js — `.bond <weapon>` in the Sect Empire: tying a weapon to a cultivator.
 *
 * A NEW command name (nothing in Astra Kingdom answered to `bond`), and it only
 * means anything inside the Sect Empire: outside it, the world lock refuses it
 * the way it refuses everything the mountain does not answer. All of the work
 * is in lib/sect-artifacts.js; this is the door.
 *
 *   .bond <weapon>   tie the weapon to you, and wear it
 *   .bond off        cut the bond — the weapon keeps half of what it grew
 */
import { config } from '../config.js'
import { sectDoorRefusal } from '../lib/world-guards.js'
import { runSectBond } from '../lib/sect-item-commands.js'

export default {
  name: 'bond',
  category: 'inventory',
  requiresPlayer: true,
  description: `${config.prefix}bond <weapon> — bond a weapon to you (it grows in real fights).`,

  async run(ctx) {
    const wrongWorld = sectDoorRefusal(ctx.player, {
      emoji: '🔗', title: '*Artifact bonding belongs to the Sect Empire.*',
      here: { cmd: 'enchant', label: 'work Astra gear at the enchant table instead' },
    })
    if (wrongWorld) return ctx.reply(wrongWorld)
    return runSectBond(ctx)
  },
}
