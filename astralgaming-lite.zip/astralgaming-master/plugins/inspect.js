/**
 * <prefix>inspect <item id or partial name>
 * Shows full details for an item the player owns.
 * Only items in the player's inventory can be inspected.
 */

import { createRequire } from 'module'
import { config } from '../config.js'
import { allItems } from '../lib/game-data.js'
import { rarityBadge } from '../lib/rarity.js'
import { sendImage } from '../lib/image.js'

const require = createRequire(import.meta.url)
const itemMap = Object.fromEntries(allItems.map((i) => [i.id, i]))

/**
 * PassiveId -> { description }. An item's passive is the whole reason a named
 * boss item is worth its trophy set, and this screen used to print only stats
 * and price: a player could hold Star Platinum Knuckles and never learn it
 * strikes twice every fourth hit. Same source file .iteminfo's sibling card
 * (plugins/info.js) already reads.
 */
const passivesById = Object.fromEntries(
  require('../data/named-weapon-passives.json').map((p) => [p.id, p]),
)

const STAT_LABEL = {
  str: 'STR', agi: 'AGI', int: 'INT', def: 'DEF', lck: 'LCK',
  maxHp: 'Max HP', maxMp: 'Max MP',
}

/**
 * Defensive effect formatter — handles every effect shape lib/effects.js supports
 * so that future consumables with non-heal shapes don't throw on display.
 */
function formatEffectLine(effect) {
  if (!effect || !effect.type) return '⚗️ *Effect:* (unknown)'

  const stat     = effect.stat     ?? '?'
  const amount   = effect.amount   ?? 0
  const duration = effect.duration ?? 0
  const value    = effect.value    ?? 0

  switch (effect.type) {
    case 'heal':
      return `⚗️ *Effect:* ❤️ Restores ${amount} ${String(stat).toUpperCase()}`

    case 'regen': {
      const durPart = duration ? ` for ${duration} turn(s)` : ''
      return `⚗️ *Effect:* 💚 Regenerate ${amount} ${String(stat).toUpperCase()} per turn${durPart}`
    }

    case 'burn':
      return `⚗️ *Effect:* 🔥 ${amount} damage per turn for ${duration} turn(s)`

    case 'poison':
      return `⚗️ *Effect:* 🟢 ${amount} damage per turn for ${duration} turn(s)`

    case 'freeze':
      return `⚗️ *Effect:* ❄️ Target cannot act for ${duration} turn(s)`

    case 'stun':
      return `⚗️ *Effect:* 💫 Target cannot act for ${duration} turn(s)`

    case 'shield':
      return `⚗️ *Effect:* 🛡️ Absorbs up to ${amount} damage for ${duration} turn(s)`

    case 'weaken':
      return `⚗️ *Effect:* ⬇️ ${String(stat).toUpperCase()} −${value} for ${duration} turn(s)`

    case 'strengthen':
      return `⚗️ *Effect:* ⬆️ ${String(stat).toUpperCase()} +${value} for ${duration} turn(s)`

    case 'blind':
      return `⚗️ *Effect:* 🌑 Accuracy reduced for ${duration} turn(s)`

    default:
      // Unknown future effect type — show type name without assuming any fields.
      return `⚗️ *Effect:* ${effect.type}`
  }
}

export default {
  name: 'inspect',
  aliases: ['item', 'iteminfo'],
  category: 'inventory',
  description: `${config.prefix}inspect <item> — view details of an item in your inventory.`,
  requiresPlayer: true,

  async run(ctx) {
    const { player, args } = ctx

    if (!args || args.length === 0) {
      return ctx.reply(`Usage: *${config.prefix}inspect <item id or name>*`)
    }

    const query = args.join(' ').toLowerCase()
    const { inventory = [] } = player
    const equippedIds = Object.values(player.equipped ?? {}).filter(Boolean)
    const ownedPool = [...new Set([...inventory, ...equippedIds])]

    // Find a matching item id the player actually owns (or equipped).
    // Priority: exact id match, then partial name match.
    let foundId = null

    // Exact id match first.
    if (ownedPool.includes(query)) {
      foundId = query
    }

    // Partial name match against items the player owns or has equipped.
    if (!foundId) {
      for (const id of ownedPool) {
        const item = itemMap[id]
        if (item && item.name.toLowerCase().includes(query)) {
          foundId = id
          break
        }
      }
    }

    // Allow inspecting mythic shop/reborn items (like Black Armor of Napoleon) by name/id too.
    if (!foundId) {
      const idForm = query.replace(/\s+/g, '_')
      const catalogMatch = itemMap[idForm]
        ?? allItems.find((i) => i.reborn && i.name.toLowerCase().includes(query))
      if (catalogMatch?.reborn) foundId = catalogMatch.id
    }

    if (!foundId) {
      return ctx.reply(
        `❌ You don't have *"${args.join(' ')}"* in your inventory.\n` +
        `Use *${config.prefix}inventory* to see what you're carrying.`,
      )
    }

    const item = itemMap[foundId]
    if (!item) {
      return ctx.reply(`❌ Item data for *${foundId}* not found. This is a bug — please report it.`)
    }

    // Build stat bonus lines (skip zero values).
    const bonusLines = Object.entries(item.statBonuses ?? {})
      .filter(([, v]) => v !== 0)
      .map(([k, v]) => `  ${STAT_LABEL[k] ?? k}: ${v > 0 ? '+' : ''}${v}`)

    // Build effect line for consumables.
    const effectLine = item.effect ? `\n${formatEffectLine(item.effect)}` : ''

    const slotTag = item.fullArmorSuit
      ? `Full Armor Suit (helmet, chestplate, boots)`
      : item.slot ? `${item.type.charAt(0).toUpperCase() + item.type.slice(1)} (${item.slot})` : item.type.charAt(0).toUpperCase() + item.type.slice(1)

    const lines = [
      `📦 *${item.name}*`,
      `${rarityBadge(item.rarity)}  •  ${slotTag}`,
      item.unbreakable ? `🛡️ Unbreakable (never breaks)` : '',
      item.levelReq > 1 ? `🔒 Requires level ${item.levelReq}` : `🔓 No level requirement`,
      '',
      item.description,
    ].filter(s => s !== '')

    if (bonusLines.length > 0) {
      lines.push('', '📊 *Stat Bonuses:*', ...bonusLines)
    }

    const passive = item.passiveId ? passivesById[item.passiveId] : null
    if (passive?.description) {
      lines.push('', `✨ *Passive:* ${passive.description}`)
    }

    if (effectLine) lines.push(effectLine)

    if (item.auctionOnly) lines.push(`\n🏛️ _Auction House exclusive — cannot be bought, sold, or crafted in the shop._`)

    if (item.gemPrice != null) {
      lines.push(`\n💎 Price: ${item.gemPrice} Gems`)
    } else {
      lines.push(`\n💰 Sell price: ${item.sellPrice} solars`)
    }

    return sendImage(ctx, item.image || `https://play.astral.qzz.io/assets/items/${item.id}.jpg`,
      `*${item.name}*\n${rarityBadge(item.rarity)} ${slotTag}${item.levelReq > 1 ? ` · Lv.${item.levelReq}` : ''}\n\n${lines.join('\n')}`)
  },
}
