/**
 * mod-here.js — a mod opens a League fixture that is waiting on one.
 *
 * Why this is its own command rather than `.ladmin verify`: `.ladmin` is owner
 * only, and a League season is run by mods in the groups they oversee. If
 * verification sat behind the owner check, every PvP fixture in the game would
 * need the owner personally present to start, which is not how the thing is
 * meant to be staffed.
 *
 * Group scoped on purpose. A mod verifies a match in the group they are standing
 * in, not by hunting match ids from another community's schedule. The owner can
 * still verify anything by id with `.ladmin verify`.
 *
 * Verifying does three things and no more: it moves the match to live, records
 * who checked it, and starts the idle clock. It scores nothing.
 */
import { config } from '../config.js'
import { updateWorldState } from '../lib/player-repo.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import { isMod } from '../lib/mod-repo.js'
import { getLeague, leagueGate, seatByNumber } from '../lib/league/league-repo.js'
import { verifyMatch, saveArenaSnapshot, noteMatchActivity } from '../lib/league/league-match.js'
import { renderMatchVsCard } from '../lib/league-matchday-render.mjs'

/**
 * Older .battle builds accidentally saved the challenger's personal JID as
 * `groupJid`. We can recognize that exact shape (it equals the starter's seat
 * JID) but cannot recover the original group from it. Let a mod in a group
 * claim that legacy pending match once, and bind it to the group where they
 * verify it. New matches always have the actual chat JID and remain strictly
 * group-scoped.
 */
function hasLegacyGroupBinding(league, match, groupJid) {
  if (typeof groupJid !== 'string' || !groupJid.endsWith('@g.us')) return false
  if (typeof match?.groupJid !== 'string') return false
  // A real group id stays scoped. Anything else (player JID, LID, a DM) was
  // written by an older .battle path and cannot be used to find the chat.
  if (match.groupJid.endsWith('@g.us')) return match.groupJid === groupJid
  return true
}

function allWaiting(league) {
  return Object.values(league.matches ?? {})
    .filter(m => m.status === 'awaiting_mod')
    .sort((a, b) => (a.dueDay - b.dueDay) || (a.id < b.id ? -1 : 1))
}

/** The chat this command was typed in, when that chat is a group. */
function groupChatOf(ctx) {
  for (const jid of [ctx.sender, ctx.from, ctx.groupJid, ctx.chat]) {
    if (typeof jid === 'string' && jid.endsWith('@g.us')) return jid
  }
  return null
}

/** Every fixture in this group that is waiting on a mod. */
function waitingInGroup(league, groupJid) {
  return allWaiting(league).filter(m =>
    !m.groupJid
    || m.groupJid === groupJid
    || hasLegacyGroupBinding(league, m, groupJid),
  )
}

export default {
  name: 'mod-here',
  aliases: ['modhere', 'leagueverify'],
  category: 'admin',
  requiresPlayer: false,
  hidden: true,
  description: 'Mods: verify a League match waiting in this group and let it start.',
  // Shown by .allcommands to mods (and to the owner): it is the command staff
  // are told to run for a queued League fixture. See lib/command-list.js.
  modTool: true,

  async run(ctx) {
    const { db, from, sender, args, reply } = ctx

    const gate = leagueGate(db)
    if (!gate.open) return reply(gate.message)
    if (!isMod(db, from) && !isOwnerJid(from)) {
      return reply('🔒 That one is for the mods who run this group.')
    }

    const league = getLeague(db)
    const wanted = String(args[0] ?? '').trim()
    const groupJid = groupChatOf(ctx)

    // Oldest fixture waiting in this group. Owner can still pick up a pairing
    // saved against the wrong chat so `.mod-here` is not a no-op in the group
    // that just said it is waiting on a mod.
    let queued = waitingInGroup(league, groupJid)
    if (!queued.length && isOwnerJid(from)) queued = allWaiting(league)
    const matchId = wanted || queued[0]?.id
    if (!matchId) {
      return reply('🧾 *Nothing in this group is waiting on a mod.*\n\n_A player match sits here after both seats accept._')
    }

    const now = Date.now()
    let res = null
    await updateWorldState(db, 'league', (data) => {
      const match = data.league?.matches?.[matchId]
      if (match?.status === 'awaiting_mod' && groupJid && hasLegacyGroupBinding(data.league, match, groupJid)) {
        match.groupJid = groupJid
      }
      if (!isOwnerJid(from) && match?.groupJid?.endsWith('@g.us') && match.groupJid !== groupJid) {
        res = { ok: false, problem: 'wrong_group' }
        return
      }
      const lock = groupJid && match?.groupJid === groupJid ? groupJid : null
      res = verifyMatch(data.league, matchId, from, { now, groupJid: lock })
    })

    if (!res?.ok) {
      const problems = {
        no_such_match: `there is no match ${matchId}`,
        not_waiting_on_a_mod: `${matchId} is not waiting on a mod`,
        wrong_group: `${matchId} belongs to a different group`,
      }
      return reply(`⛔ ${problems[res?.problem] ?? res?.problem ?? 'that match cannot be verified'}.`)
    }

    const match = res.match
    const nameA = seatByNumber(league, match.seatA)?.name ?? `seat ${match.seatA}`
    const nameB = seatByNumber(league, match.seatB)?.name ?? `seat ${match.seatB}`
    const accepterSeat = match.accepterSeat
      ?? (match.seatA === match.starterSeat ? match.seatB : match.seatA)
    const firstMover = seatByNumber(league, accepterSeat)?.name ?? nameB

    // The snapshot is taken now, while both fighters are fresh, so a mod who
    // later calls rematch has something real to restore.
    await updateWorldState(db, 'league', (data) => {
      saveArenaSnapshot(data.league, matchId, db, now)
      noteMatchActivity(data.league, matchId, now)
    })

    const caption = [
      `🧾🔥 *Verified by a mod. ${matchId} is live.* 🔥🧾`,
      '━━━━━━━━━━━━━━━━━━━━',
      `⚔️ *${nameA}* versus *${nameB}*.`,
      `⚡ *${firstMover}* moves first.`,
      '',
      `🗡️ *${config.prefix}battle atk* · 🛡️ *${config.prefix}battle def* · ✨ *${config.prefix}battle sk <name>*`,
      '',
      '⏳ _Thirty turns. Leave it idle and it is settled against whoever stopped._',
    ].join('\n')

    if (typeof ctx.replyImage === 'function') {
      try {
        const png = await renderMatchVsCard(db, league, match)
        if (png) return ctx.replyImage(png, caption)
      } catch {}
    }
    return reply(caption)
  },
}
