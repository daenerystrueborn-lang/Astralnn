/**
 * hunt.js — `.hunt`: fight whatever the ground you are standing on deals.
 *
 * The rules are lib/sect-hunt.js's (the seeded deal, the elite and boss chance,
 * the cooldown, what a kill pays and the day's cap), the fight is Prompt 4's own
 * engine, and the drops are the monster's table. This file is the command: where
 * you are, whether you may, and starting it.
 *
 *   .hunt              fight what walks this ground (or the screen, elsewhere)
 *   .hunt <area>       the same, and it says which grounds exist
 */
import { config } from '../config.js'
import { sectDoorRefusal, missingSectRecordRefusal } from '../lib/world-guards.js'
import { huntCommand, huntScreen } from '../lib/sect-hunt.js'
import { AREAS, areaById } from '../lib/sect-areas.js'
import { sectPicture, replyWithSectPicture } from '../lib/sect-images.js'
import '../lib/sect-hooks.js'


export default {
  name: 'hunt',
  aliases: ['hunting'],
  category: 'event',
  requiresPlayer: true,
  description: `${config.prefix}hunt — fight what walks the ground you are standing on`,

  async run(ctx) {
    const player = ctx.player
    const wrongWorld = sectDoorRefusal(player, {
      emoji: '🗡️', title: '*The wilds belong to the Sect Empire.*',
      here: { cmd: 'dungeon', label: 'find a fight in Astra instead' },
    })
    if (wrongWorld) return ctx.reply(wrongWorld)
    if (!player.sect) return ctx.reply(missingSectRecordRefusal())

    const first = String((ctx.args ?? [])[0] ?? '').toLowerCase()
    if (first === 'areas' || first === 'map' || first === 'where') {
      const pic = sectPicture('areas', areaById(player.location)?.id ?? 'whispering_forest')
      return replyWithSectPicture(ctx, pic, huntScreen(player, { prefix: config.prefix }).join('\n'))
    }
    if (first && !AREAS.some(area => area.id === first || area.name.toLowerCase().startsWith(first))) {
      return ctx.reply([
        `❓ *There is no ground called that.*`,
        '',
        huntScreen(player, { prefix: config.prefix }).join('\n'),
      ].join('\n'))
    }
    return huntCommand(ctx, { now: Date.now() })
  },
}
