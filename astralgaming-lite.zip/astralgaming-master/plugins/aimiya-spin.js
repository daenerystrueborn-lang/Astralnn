// <prefix>aimiya-spin [amount] — Aimiya's banner.
// 3 Gems a spin, 300 spins per player, guaranteed by spin 300.
// One-of-one bot-wide once released from pre-order.
import { runRegressorSpin } from '../lib/regressor-spin-runner.js'

export default {
  name: 'aimiya-spin',
  aliases: ['aimiyaspin', 'carnival-spin', 'trick-spin'],
  category: 'character',
  requiresPlayer: true,
  description: 'Spin for Aimiya: 3 Gems per spin, one-of-one, 300 spins, guaranteed by spin 300',
  async run(ctx) { return runRegressorSpin(ctx, 'aimiya') },
}
