/**
 * shop.js — Item and weapon shop.
 *
 * Every browse/info screen is sent with the shop.jpg banner image
 * (see lib/image.js's sendImage) — drop shop.jpg into ./images/.
 * Falls back to plain text automatically if the file isn't there.
 *
 * Commands:
 *   .shop                        — show categories + your balance
 *   .shop weapons [all]          — browse weapons (filtered to your level by default)
 *   .shop armor [all]            — browse armor (helmets, chestplates, boots)
 *   .shop potions                — browse consumables
 *   .shop buy <item> [qty]       — buy one or more items
 *   .shop sell <item> [qty]      — sell items from your inventory
 *   .shop info <item>            — view full details for any shop item
 */
import { config } from '../config.js'
import { allItems } from '../lib/game-data.js'
import { updatePlayer } from '../lib/player-repo.js'
import { roundGems, fmtGems } from '../lib/format.js'
import { hasInventoryRoom, inventoryFullMessage } from '../lib/inventory-limits.js'
import { recordSink } from '../lib/economy-ledger.js'
import { townDiscount } from '../lib/town-favor.js'
import { sendImage } from '../lib/image.js'
import { rarityStars, rarityLabel } from '../lib/rarity.js'
import { findPack } from '../lib/skill-pack-engine.js'
// Dynamic market — prices shift based on supply/demand
import { getCurrentPrice, recordPurchase } from '../lib/market-engine.js'
// The End event's old woman — `.shop buy blue band` is a riddle, not a sale
// (blue_band has no buyPrice, so it can never reach the catalog path below).
import {
  isEventActive, hasBlueBand, BLUE_BAND_ID, ASTRAL_TOWN_ID,
  RIDDLE_QUESTION, RIDDLE_WRONG, RIDDLE_ALREADY_BANDED,
} from '../lib/end-event.js'
// What's for sale and how the shelves are divided — shared with the website's
// Shop page (lib/api-server.js's /api/shop) so the two can't drift.
// The Ender Chest is storage, not a catalog item (no allItems id, like
// ability_slot and blue_band below), so `.shop buy ender chest` intercepts
// before findInCatalog() and hands off to the command that owns it.
import { ENDER_CHEST_QUERIES, ENDER_PRICE_SOLARS, hasEnderChest } from '../lib/ender-chest.js'
// The Enchanting Book is the same shape of purchase as the Ender Chest —
// a one-time unlock with no catalog entry — so it intercepts right beside it
// and hands off to plugins/enchant.js's exported buyEnchantingBook().
import { ENCHANT_BOOK_QUERIES, ENCHANT_BOOK_SOLARS, hasEnchantingBook } from '../lib/enchantments.js'
import {
  shopWeapons, shopItems, shopTools, findInCatalog,
  groupByRarity, groupBySlot, groupPotions, potionBlurb,
  RARITY_GROUP_ORDER, ARMOR_SLOT_ORDER,
  ABILITY_SLOT_GEM_PRICE, ABILITY_SLOT_ALIASES,
} from '../lib/shop-catalog.js'

// Banner shown behind every .shop reply — direct URL now (previously a
// filename resolved via lib/image.js's map).
const SHOP_BANNER = 'https://i.ibb.co/CpS1wXM9/astral-shop.jpg'
// Dedicated art for the ARMOR shelf — `.shop armor` is the one category that
// gets its own image (see the 2026-09-21 art drop, lib/image.js).
const ARMOR_SHOP_BANNER = 'https://i.ibb.co/6RgWqj7f/armor-shop.jpg'

// ── Rarity display ────────────────────────────────────────────────────

function rarityEmoji(r) { return rarityStars(r) }

// ── Shelf labels ──────────────────────────────────────────────────────
// The grouping itself lives in lib/shop-catalog.js (shared with the site);
// only the WhatsApp-markup labels are local.

const POTION_GROUP_DISPLAY = {
  // Just "Healing": mana got its own shelf below, and the old "Healing & Mana"
  // label is what made `.shop potions mana` open THIS shelf (see
  // findPotionGroup), so the label can never claim mana again.
  healing:  { label: '❤️ *Healing*',          emoji: '🧪' },
  mana:     { label: '💙 *Mana Restore*',     emoji: '🔮' },
  stamina:  { label: '🏃 *Stamina Restore*',  emoji: '🏃' },
  elixirs:  { label: '✨ *Elixirs & Revival*', emoji: '🌟' },
  cures:    { label: '💚 *Status Cures*',     emoji: '🩹' },
  buffs:    { label: '⚡ *Buffs & Shields*',  emoji: '🛡️' },
  other:    { label: '📦 *Other*',            emoji: '📦' },
}

const RARITY_LABEL = Object.fromEntries(
  RARITY_GROUP_ORDER.map((r) => [r, `${rarityStars(r)} *${rarityLabel(r)}*`]),
)

const ARMOR_SLOT_LABEL = {
  helmet:     '🪖 *Helmets*',
  chestplate: '👕 *Chestplates*',
  boots:      '👢 *Boots*',
  offhand:    '🎗️ *Offhand*',
}

/** Attaches the WhatsApp label/emoji to each shelf returned by the shared grouper. */
function labelled(groups, labels, fallbackEmoji) {
  return groups.map(g => {
    const display = labels[g.key]
    return {
      ...g,
      label: typeof display === 'string' ? display : (display?.label ?? `📦 *${g.key}*`),
      emoji: display?.emoji ?? fallbackEmoji,
    }
  })
}

// ── Pagination ──────────────────────────────────────────────────────────
const PAGE_SIZE = 10

function paginate(list, page) {
  const totalPages = Math.max(1, Math.ceil(list.length / PAGE_SIZE))
  const clamped    = Math.min(Math.max(1, page), totalPages)
  const start      = (clamped - 1) * PAGE_SIZE
  return { pageItems: list.slice(start, start + PAGE_SIZE), page: clamped, totalPages }
}

/** Pulls a trailing "page N" or bare number off args, returns { page, rest }. */
function extractPage(args) {
  const parts = [...args]
  let page = 1
  const pageIdx = parts.findIndex((a) => a?.toLowerCase() === 'page')
  if (pageIdx !== -1 && parts[pageIdx + 1] && /^\d+$/.test(parts[pageIdx + 1])) {
    page = parseInt(parts[pageIdx + 1], 10)
    parts.splice(pageIdx, 2)
  } else if (/^\d+$/.test(parts[parts.length - 1] ?? '')) {
    page = parseInt(parts[parts.length - 1], 10)
    parts.pop()
  }
  return { page, rest: parts }
}

// ── Catalog helpers ───────────────────────────────────────────────────
// shopWeapons / shopItems / shopTools / findInCatalog now come from
// lib/shop-catalog.js — see the import block at the top.

/** Returns items available for a player's level, with optional overflow. */
function filteredByLevel(list, playerLevel, showAll = false) {
  if (showAll) return list
  const LEVEL_BUFFER = 10
  return list.filter(i => i.levelReq <= playerLevel + LEVEL_BUFFER)
}

// ── Formatters ────────────────────────────────────────────────────────

function fmtWeaponLine(w) {
  const lvl = w.levelReq > 1 ? `Lv.${w.levelReq}` : `Lv.1`
  return `${rarityEmoji(w.rarity)} *${w.name}*\n     _${lvl} · ☀️ ${w.buyPrice} Solars_`
}

function fmtItemLine(i) {
  const lvl = i.levelReq > 1 ? `Lv.${wOrLvl(i)}` : `Lv.1`
  const price = i.gemPrice != null && i.buyPrice == null
    ? `💎 ${i.gemPrice} Gems`
    : `☀️ ${i.buyPrice} Solars`
  const suitTag = i.fullArmorSuit ? ' · 🖤 Full Armor Suit (Unbreakable)' : ''
  return `${rarityEmoji(i.rarity)} *${i.name}*\n     _${lvl} · ${price}${suitTag}_`
}

function wOrLvl(i) { return i.levelReq ?? 1 }

function fmtPotionLine(i) {
  const lvl = i.levelReq > 1 ? `Lv.${i.levelReq}` : `Lv.1`
  const blurb = potionBlurb(i)
  return `${rarityEmoji(i.rarity)} *${i.name}* — ${blurb}\n     _${lvl} · ☀️ ${i.buyPrice}_`
}

/** One-line effect summary shown inline next to each potion in the shop list.
 *  (potionBlurb itself is shared — see lib/shop-catalog.js.) */

function pageFooter(p, page, totalPages, cmd) {
  if (totalPages <= 1) return ''
  const nav = []
  if (page > 1) nav.push(`*${p}shop ${cmd} page ${page - 1}* ◀️`)
  if (page < totalPages) nav.push(`▶️ *${p}shop ${cmd} page ${page + 1}*`)
  return `\n\n📄 _Page ${page}/${totalPages}_${nav.length ? '   ' + nav.join('   ') : ''}`
}

/**
 * The shop's screen sender: picture + text, plus the buttons that make a shop
 * feel like a shop on Telegram.
 *
 *   • a paginated listing gets ◀️ Prev / Next ▶️, each `c:shop <section> page N`
 *     — the exact command the footer already prints, so a button can never do
 *     something typing cannot;
 *   • the main menu gets its sections as buttons (`c:shop weapons` etc.);
 *   • anything else (an item card, a receipt) stays a plain picture + caption.
 *
 * Everything degrades: a platform without inline keyboards, or a text with no
 * page footer, falls straight through to sendImage().
 */
const SHOP_SECTIONS = [
  ['⚔️ Weapons', 'weapons'], ['🛡️ Armor', 'armor'], ['🔮 Relics', 'relics'],
  ['🧰 Tools', 'tools'], ['🧪 Potions', 'potions'], ['✨ Cosmetics', 'cosmetics'],
]

function sendShopScreen(ctx, banner, text, { sections = false, buttons = [], fallbackImage } = {}) {
  const body = String(text ?? '')
  const withButtons = typeof ctx?.replyImageButtons === 'function'
  // Caller-supplied rows (the item card's ×1/×5, a potion's own row) sit ABOVE
  // the navigation so the thing being bought is the first thing under the text.
  const extra = buttons.filter((row) => Array.isArray(row) && row.length)

  // The commands behind the buttons, printed. A tap is only a shortcut for
  // something a player could type, so when the taps cannot be delivered —
  // a platform with no inline keyboards, or a photo send that failed — the
  // purchase stays reachable instead of vanishing with the keyboard.
  const asText = (rows) =>
    '\n\n' + rows.flat()
      .map((b) => `${b.text} → *${config.prefix}${String(b.data ?? '').replace(/^c:/, '')}*`)
      .join('\n')

  // A picture that cannot be fetched must never swallow the text — the same
  // ladder sendImage() has always had. This matters most for an item card,
  // whose art is served from our own origin and used to take the whole reply
  // down with it when that origin was unreachable.
  const send = async (rows) => {
    try {
      return await ctx.replyImageButtons(banner, body, rows)
    } catch (err) {
      console.error(`[shop] picture+buttons failed, retrying without art: ${err?.message ?? err}`)
      const fallbackText = extra.length ? body + asText(rows) : body
      return sendImage(ctx, banner, fallbackText, fallbackImage ? { fallbackImage } : undefined)
    }
  }

  if (sections && withButtons) {
    const rows = []
    for (let i = 0; i < SHOP_SECTIONS.length; i += 2) {
      rows.push(SHOP_SECTIONS.slice(i, i + 2).map(([label, key]) => ({ text: label, data: `c:shop ${key}` })))
    }
    return send([...extra, ...rows])
  }

  // "📄 _Page 2/5_" is pageFooter's own line, and it is the only place a page
  // number appears in a shop reply — so it is what decides whether navigation
  // buttons belong here.
  const footer = /_Page (\d+)\/(\d+)_/.exec(body)
  if (footer && withButtons) {
    const page = Number(footer[1])
    const total = Number(footer[2])
    const { rest } = extractPage(ctx?.args ?? [])
    const base = ['shop', ...rest].join(' ').trim()
    const nav = []
    if (page > 1) nav.push({ text: '◀️ Prev', data: `c:${base} page ${page - 1}` })
    if (page < total) nav.push({ text: 'Next ▶️', data: `c:${base} page ${page + 1}` })
    if (nav.length || extra.length) return send([...extra, ...(nav.length ? [nav] : [])])
  }

  if (extra.length && withButtons) return send(extra)

  // No inline keyboard on this platform (or in this ctx): the buttons become
  // the lines a player types.
  const plain = extra.length ? body + asText(extra) : body
  return sendImage(ctx, banner, plain, fallbackImage ? { fallbackImage } : undefined)
}

/**
 * Telegram rejects a button whose callback data is over 64 BYTES, and it
 * rejects it at send time — i.e. the whole shop screen would fail to arrive
 * because of one long item id. Every id in the catalog fits today (the longest,
 * `black_armor_of_napoleon`, makes a 37-byte `c:shop buy … 10`), but the guard
 * is what keeps a future item from breaking the screen, so it stays.
 */
const MAX_CALLBACK_BYTES = 64

function fitsCallback(data) {
  return typeof data === 'string' && data.length > 0 && Buffer.byteLength(data, 'utf8') <= MAX_CALLBACK_BYTES
}

/** How many of a thing one tap can buy. Solars-priced only — a gem item is a one-off. */
export const BUY_QUANTITIES = [1, 5, 10]

/**
 * 🛒 Buy 1 · Buy 5 · Buy 10 for one catalog entry.
 *
 * Each button is the command a player would type (`c:shop buy <id> 5`), so the
 * tap and the typed purchase go through the same handleBuy() — the quantity is
 * the only thing a button adds. Returns [] when there is nothing to buy (an
 * item with no Solars price) or when the id would overflow the callback budget.
 */
export function buyQuantityRows(entry) {
  if (!entry || entry.id == null) return []
  const gemOnly = entry.buyPrice == null && entry.gemPrice != null
  // A Solars shelf sells in fives; a gem item is a one-off, so it gets one button.
  if (entry.buyPrice == null && !gemOnly) return []
  const row = []
  for (const qty of gemOnly ? [1] : BUY_QUANTITIES) {
    const data = `c:shop buy ${entry.id} ${qty}`
    if (!fitsCallback(data)) continue
    row.push({ text: gemOnly ? '🛒 Buy' : qty === 1 ? '🛒 Buy 1' : `🛒 Buy ${qty}`, data })
  }
  return row.length ? [row] : []
}

/** A tappable row that opens one item's card — where the buy buttons live. */
function itemCardRow(item, { label } = {}) {
  const data = `c:shop info ${item?.id ?? ''}`.trim()
  if (!item?.id || !fitsCallback(data)) return []
  return [{ text: label ?? `🔍 ${item.name}`, data }]
}

function fmtDetails(entry) {
  const slotLabel = entry.fullArmorSuit
    ? 'Full Armor Suit (helmet, chestplate, boots)'
    : entry.slot
  const priceLine = entry.gemPrice != null && entry.buyPrice == null
    ? `💰 Buy: 💎 ${entry.gemPrice} Gems${entry.unbreakable ? '  · 🛡️ Unbreakable' : ''}`
    : `💰 Buy: ${entry.buyPrice != null ? `☀️ ${entry.buyPrice}` : '—'}  · Sell: ☀️ ${entry.sellPrice ?? 0}`
  const lines = [
    `${rarityEmoji(entry.rarity)} *${entry.name}* _(${entry.rarity})_`,
    `📖 ${entry.description}`,
    `⚔️ Type: ${entry.type}${slotLabel ? ` · Slot: ${slotLabel}` : ''}`,
    `📊 Level Req: ${entry.levelReq ?? 1}`,
    priceLine,
  ]
  if (entry.unbreakable) lines.push(`🛡️ Durability: Unbreakable (never breaks)`)
  if (entry.damage) lines.push(`⚔️ Damage: ${entry.damage}`)
  if (entry.statBonuses) {
    const bonuses = Object.entries(entry.statBonuses)
      .filter(([, v]) => v !== 0)
      .map(([k, v]) => `${k.toUpperCase()} +${v}`)
      .join('  ')
    if (bonuses) lines.push(`✨ Bonuses: ${bonuses}`)
  }
  if (entry.effect) {
    const effects = Array.isArray(entry.effect) ? entry.effect : [entry.effect]
    for (const e of effects) {
      if (e.type === 'heal') {
        const amt = e.amount >= 99999 ? 'FULL' : `+${e.amount ?? ''}`
        lines.push(`💊 Effect: heal ${e.stat?.toUpperCase() ?? ''} ${amt}`)
      } else if (e.type === 'cure') {
        const targets = e.targets === 'all' ? 'all ailments' : (e.targets ?? []).join(', ')
        lines.push(`💊 Effect: cures ${targets}`)
      } else if (e.type === 'regen') {
        lines.push(`💊 Effect: regen ${e.stat?.toUpperCase() ?? ''} +${e.amount} for ${e.duration} turns`)
      } else if (e.type === 'strengthen') {
        lines.push(`💊 Effect: +${e.value} ${e.stat?.toUpperCase() ?? ''} for ${e.duration} turns`)
      } else if (e.type === 'shield') {
        lines.push(`💊 Effect: shield ${e.amount} for ${e.duration} turns`)
      } else {
        lines.push(`💊 Effect: ${e.type}`)
      }
    }
  }
  return lines.join('\n')
}

// ── Sub-command handlers ──────────────────────────────────────────────

function handleWeapons(player, args) {
  const showAll = args.includes('all')
  const filteredArgs = args.filter((a) => a.toLowerCase() !== 'all')
  const { page: reqPage, rest } = extractPage(filteredArgs)
  const groupFilter = rest[1]?.toLowerCase() // .shop weapons legendary / epic / rare / uncommon / common

  const list = filteredByLevel(shopWeapons, player.level, showAll)
    .sort((a, b) => a.levelReq - b.levelReq)

  if (!list.length) return `❌ *No weapons available for your level yet.*`

  const groups = labelled(groupByRarity(list), RARITY_LABEL, '⚔️')
  const cmdBase = showAll ? 'weapons all' : 'weapons'

  // ── Single rarity drill-down: .shop weapons epic ─────────────────────
  if (groupFilter) {
    const g = groups.find((gr) => gr.key === groupFilter || gr.label.toLowerCase().includes(groupFilter))
    if (!g) {
      return `❌ *No weapon rarity* "_${groupFilter}_" *found.*\n` +
        `✨ Try: ${groups.map((gr) => `*${gr.key}*`).join(', ')}`
    }
    const { pageItems, page, totalPages } = paginate(g.items, reqPage)
    return (
      `┏━━━━━━━━━━━━━━┓\n` +
      `┃  ⚔️ *${g.label.replace(/\*/g, '').trim().toUpperCase()} WEAPONS* ⚔️\n` +
      `┗━━━━━━━━━━━━━━┛\n\n` +
      pageItems.map(fmtWeaponLine).join('\n\n') +
      pageFooter(config.prefix, page, totalPages, `${cmdBase} ${g.key}`) +
      `\n\n🛒 _Buy with_ *${config.prefix}shop buy <name> [qty]*`
    )
  }

  // ── Grouped overview — preview per rarity tier, drill in for the full list ──
  const lines = [
    `┏━━━━━━━━━━━━━━┓`,
    `┃  🗡️ *WEAPONS SHOP* 🗡️`,
    `┗━━━━━━━━━━━━━━┛`,
    `${showAll ? '_✨ Full catalog ✨_' : `_📊 Levels 1–${player.level + 10}_`}`,
    '',
  ]

  for (const g of groups) {
    lines.push(`${g.label}`)
    const preview = g.items.slice(0, 3)
    for (const item of preview) {
      const lvl = item.levelReq > 1 ? `Lv.${item.levelReq}` : `Lv.1`
      lines.push(`   *${item.name}* — _${lvl} · ☀️${item.buyPrice}_`)
    }
    if (g.items.length > preview.length) {
      lines.push(`   _…and ${g.items.length - preview.length} more — *${config.prefix}shop ${cmdBase} ${g.key}*_`)
    }
    lines.push('')
  }

  lines.push(`🔎 _Drill into a rarity:_ *${config.prefix}shop weapons <rarity>*`)
  if (!showAll) lines.push(`🌐 _Type_ *${config.prefix}shop weapons all* _to see the full catalog._`)
  lines.push(`🛒 _Buy with_ *${config.prefix}shop buy <name> [qty]*`)
  return lines.join('\n')
}

// Relics (type: 'relic') previously had no browsing category anywhere in
// the shop — handleArmor only ever matched type === 'armor', so relics
// like Totem of Undying and Gambler's Relic were buyable via `.shop buy
// <name>` if you already knew the id, but invisible in every menu. This
// fixes that gap and also surfaces the Chest here, since thematically
// it's the closest fit — the Chest itself is NOT bought through
// `.shop buy` (see plugins/chest.js), it has its own `.chest buy` command.
function handleRelics(player, args) {
  const showAll = args.includes('all')
  const filteredArgs = args.filter((a) => a.toLowerCase() !== 'all')
  const { page: reqPage, rest } = extractPage(filteredArgs)

  const relicItems = shopItems.filter(i => i.type === 'relic')
  const list = filteredByLevel(relicItems, player.level, showAll)
    .sort((a, b) => a.levelReq - b.levelReq)

  const { pageItems, page, totalPages } = paginate(list, reqPage)
  const p = config.prefix

  const chestLine =
    `\n🧰 *Chest* — safe storage immune to death loss\n` +
    `     _☀️ 50,000 Solars or 💎 10 Gems · buy with *${p}chest buy solars|gems*_\n`

  if (!list.length) {
    return (
      `┏━━━━━━━━━━━━━━┓\n` +
      `┃  🔮 *RELICS* 🔮\n` +
      `┗━━━━━━━━━━━━━━┓\n\n` +
      `_No relics available for your level yet._\n` +
      chestLine
    )
  }

  return (
    `┏━━━━━━━━━━━━━━┓\n` +
    `┃  🔮 *RELICS SHOP* 🔮\n` +
    `┗━━━━━━━━━━━━━━┛\n` +
    `${showAll ? '_✨ Full catalog ✨_' : `_📊 Levels 1–${player.level + 10}_`}\n\n` +
    pageItems.map(fmtItemLine).join('\n\n') +
    pageFooter(p, page, totalPages, showAll ? 'relics all' : 'relics') +
    `\n\n🛒 _Buy with_ *${p}shop buy <name> [qty]*\n` +
    chestLine
  )
}

function handleArmor(player, args) {
  const showAll = args.includes('all')
  const filteredArgs = args.filter((a) => a.toLowerCase() !== 'all')
  const { page: reqPage, rest } = extractPage(filteredArgs)
  const groupFilter = rest[1]?.toLowerCase() // .shop armor helmets / chestplates / boots / offhand

  const armorItems = shopItems.filter(i => i.type === 'armor')
  const list = filteredByLevel(armorItems, player.level, showAll)
    .sort((a, b) => a.levelReq - b.levelReq)

  if (!list.length) return `❌ *No armor available for your level yet.*`

  const groups = labelled(groupBySlot(list), ARMOR_SLOT_LABEL, '🛡️')
  const cmdBase = showAll ? 'armor all' : 'armor'

  // ── Single slot drill-down: .shop armor boots ────────────────────────
  if (groupFilter) {
    const g = groups.find((gr) => gr.key === groupFilter || gr.label.toLowerCase().includes(groupFilter))
    if (!g) {
      return `❌ *No armor slot* "_${groupFilter}_" *found.*\n` +
        `✨ Try: ${groups.map((gr) => `*${gr.key}*`).join(', ')}`
    }
    const { pageItems, page, totalPages } = paginate(g.items, reqPage)
    return (
      `┏━━━━━━━━━━━━━━┓\n` +
      `┃  🛡️ *${g.label.replace(/\*/g, '').trim().toUpperCase()}* 🛡️\n` +
      `┗━━━━━━━━━━━━━━┛\n\n` +
      pageItems.map(fmtItemLine).join('\n\n') +
      pageFooter(config.prefix, page, totalPages, `${cmdBase} ${g.key}`) +
      `\n\n🛒 _Buy with_ *${config.prefix}shop buy <name> [qty]*`
    )
  }

  // ── Grouped overview — preview per slot, drill in for the full list ──
  const lines = [
    `┏━━━━━━━━━━━━━━┓`,
    `┃  🛡️ *ARMOR SHOP* 🛡️`,
    `┗━━━━━━━━━━━━━━┛`,
    `${showAll ? '_✨ Full catalog ✨_' : `_📊 Levels 1–${player.level + 10}_`}`,
    '',
  ]

  for (const g of groups) {
    lines.push(`${g.label}`)
    const preview = g.items.slice(0, 3)
    for (const item of preview) {
      const lvl = item.levelReq > 1 ? `Lv.${item.levelReq}` : `Lv.1`
      const price = item.gemPrice != null && item.buyPrice == null
        ? `💎${item.gemPrice} Gems`
        : `☀️${item.buyPrice}`
      lines.push(`   ${rarityEmoji(item.rarity)} *${item.name}* — _${lvl} · ${price}_`)
    }
    if (g.items.length > preview.length) {
      lines.push(`   _…and ${g.items.length - preview.length} more — *${config.prefix}shop ${cmdBase} ${g.key}*_`)
    }
    lines.push('')
  }

  lines.push(`🔎 _Drill into a slot:_ *${config.prefix}shop armor <slot>*`)
  if (!showAll) lines.push(`🌐 _Type_ *${config.prefix}shop armor all* _to see the full catalog._`)
  lines.push(`🛒 _Buy with_ *${config.prefix}shop buy <name> [qty]*`)
  return lines.join('\n')
}

function handleTools(player, args) {
  const showAll = args.includes('all')
  const filteredArgs = args.filter((a) => a.toLowerCase() !== 'all')
  const { page: reqPage } = extractPage(filteredArgs)

  const list = filteredByLevel(shopTools, player.level, showAll)
    .sort((a, b) => a.levelReq - b.levelReq)

  if (!list.length) return `❌ *No tools available for your level yet.*`

  const { pageItems, page, totalPages } = paginate(list, reqPage)
  const allLine = !showAll
    ? `\n🌐 _Type_ *${config.prefix}shop tools all* _to see the full catalog._`
    : ''

  return (
    `┏━━━━━━━━━━━━━━┓\n` +
    `┃  ⛏️ *TOOLS SHOP* ⛏️\n` +
    `┗━━━━━━━━━━━━━━┛\n` +
    `${showAll ? '_✨ Full catalog ✨_' : `_📊 Levels 1–${player.level + 10}_`}\n\n` +
    pageItems.map(fmtItemLine).join('\n\n') +
    pageFooter(config.prefix, page, totalPages, showAll ? 'tools all' : 'tools') +
    allLine +
    `\n\n⛏️ _A pickaxe is required to_ *${config.prefix}mine* _— only works inside dungeons._\n` +
    `🛒 _Buy with_ *${config.prefix}shop buy <name> [qty]*`
  )
}

/**
 * What players actually type after `.shop potions`, mapped to a shelf key.
 * Singular, short and stat-name forms all land where they obviously mean.
 */
const POTION_GROUP_ALIASES = {
  heal: 'healing', heals: 'healing', health: 'healing', hp: 'healing', healing: 'healing',
  mana: 'mana', mp: 'mana', ether: 'mana', ethers: 'mana',
  stamina: 'stamina', sp: 'stamina', energy: 'stamina',
  elixir: 'elixirs', elixirs: 'elixirs', revive: 'elixirs', revival: 'elixirs',
  cure: 'cures', cures: 'cures', remedy: 'cures', remedies: 'cures',
  buff: 'buffs', buffs: 'buffs', shield: 'buffs', shields: 'buffs',
}

/**
 * Resolve `.shop potions <filter>` to one shelf.
 *
 * An exact key or alias always wins, and only then a label substring. This
 * used to be a single find() that accepted either a key match OR a label
 * substring, so the FIRST shelf whose label merely contained the word won.
 * The healing shelf comes first and was labelled "Healing & Mana", so
 * `.shop potions mana` opened the health potions and the real Mana shelf
 * could never be reached by name.
 */
export function findPotionGroup(groups, filter) {
  const q = String(filter ?? '').toLowerCase().trim()
  if (!q) return null
  const key = POTION_GROUP_ALIASES[q] ?? q
  return groups.find((gr) => gr.key === key)
    ?? groups.find((gr) => gr.label.replace(/\*/g, '').toLowerCase().includes(q))
    ?? null
}

/**
 * The potion shelves. Returns `{ text, buttons }` rather than a bare string
 * because the drill-down carries one tappable row per potion: potions are the
 * thing players buy in fives and tens, and reaching the item card (where the
 * ×1/×5/×10 buttons live) used to mean typing the name back at the bot.
 */
function potionsScreen(args) {
  const { page: reqPage, rest } = extractPage(args ?? [])
  const groupFilter = rest[1]?.toLowerCase() // .shop potions healing / cures / buffs / elixirs / mana

  const list = shopItems
    .filter(i => i.type === 'consumable')
    .sort((a, b) => a.levelReq - b.levelReq)

  if (!list.length) return { text: `❌ *No potions in stock.*`, buttons: [] }

  const groups = labelled(groupPotions(list), POTION_GROUP_DISPLAY, '🧪')

  // ── Single group drill-down: .shop potions cures ─────────────────────
  if (groupFilter) {
    const g = findPotionGroup(groups, groupFilter)
    if (!g) {
      return {
        text:
          `❌ *No potion category* "_${groupFilter}_" *found.*\n` +
          `✨ Try: ${groups.map((gr) => `*${gr.key}*`).join(', ')}`,
        buttons: [],
      }
    }
    const { pageItems, page, totalPages } = paginate(g.items, reqPage)
    return {
      text:
        `┏━━━━━━━━━━━━━━┓\n` +
        `┃  ${g.emoji} *${g.label.replace(/\*/g, '').replace(/^[^\s]+\s/, '').trim().toUpperCase()}* ${g.emoji}\n` +
        `┗━━━━━━━━━━━━━━┛\n\n` +
        pageItems.map(fmtPotionLine).join('\n\n') +
        pageFooter(config.prefix, page, totalPages, `potions ${g.key}`) +
        `\n\n🧪 _Buy with_ *${config.prefix}shop buy <name> [qty]*\n` +
        `🛒 _Tap a potion for_ *×1 · ×5 · ×10*`,
      // One row per potion on this page, opening its card.
      buttons: pageItems.map((item) => itemCardRow(item, { label: `🛒 ${item.name}` })).filter((r) => r.length),
    }
  }

  // ── Grouped overview — preview per section, drill in for the full list ──
  const lines = [
    `┏━━━━━━━━━━━━━━┓`,
    `┃  🧪 *POTIONS SHOP* 🧪`,
    `┗━━━━━━━━━━━━━━┛`,
    '',
  ]

  for (const g of groups) {
    lines.push(`${g.label}`)
    const preview = g.items.slice(0, 3)
    for (const item of preview) {
      lines.push(`   ${rarityEmoji(item.rarity)} *${item.name}* — _${potionBlurb(item)}_ · ☀️${item.buyPrice}`)
    }
    if (g.items.length > preview.length) {
      lines.push(`   _…and ${g.items.length - preview.length} more — *${config.prefix}shop potions ${g.key}*_`)
    }
    lines.push('')
  }

  lines.push(`🔎 _Drill into a category:_ *${config.prefix}shop potions <category>*`)
  lines.push(`🛒 _Buy with_ *${config.prefix}shop buy <name> [qty]*`)
  return { text: lines.join('\n'), buttons: [] }
}

// ── Buy ───────────────────────────────────────────────────────────────

async function handleBuy(ctx, args) {
  const p = config.prefix
  if (!args[1]) {
    return ctx.reply(
      `❌ *Usage:* *${p}shop buy <item name or id> [quantity]*\n` +
      `_Example:_ *${p}shop buy health_potion 5*`,
    )
  }

  // Last arg is quantity if it's a number; everything before is the item query
  const lastArg = args[args.length - 1]
  let qty       = 1
  let queryParts = args.slice(1)
  if (/^\d+$/.test(lastArg) && args.length > 2) {
    qty        = Math.max(1, Math.min(99, parseInt(lastArg, 10)))
    queryParts = args.slice(1, -1)
  }
  const query = queryParts.join(' ').toLowerCase()

  // Ability Slot — gem-only, not part of the weapons/items catalog.
  if (ABILITY_SLOT_ALIASES.includes(query) || ABILITY_SLOT_ALIASES.includes(queryParts.join(' ').toLowerCase())) {
    return handleBuyAbilitySlot(ctx, qty)
  }

  // Ender Chest — the 100-slot vault from plugins/ender.js. Storage rather
  // than an item, so it has no catalog entry; the purchase itself lives in
  // lib/ender-chest.js and the message set in plugins/ender.js's
  // buyEnderChest(), which this calls so `.shop` and `.ender` cannot drift.
  if (ENDER_CHEST_QUERIES.includes(query)) {
    const { buyEnderChest } = await import('./ender.js')
    return buyEnderChest(ctx)
  }

  // Enchanting Book — the one-time unlock behind `.enchant`, sold here rather
  // than in the item catalog for the same reason the Ender Chest is: it is a
  // permanent ability, not something that sits in a bag slot. The purchase
  // lives in lib/enchanting-book.js and the copy in plugins/enchant.js's
  // buyEnchantingBook(), which this calls so `.shop` and `.enchant` cannot drift.
  if (ENCHANT_BOOK_QUERIES.includes(query)) {
    const { buyEnchantingBook } = await import('./enchant.js')
    return buyEnchantingBook(ctx)
  }

  // Skill Pack — gem-only gacha pull, also not part of the weapons/items
  // catalog. Delegates to plugins/skillpack.js so both `.shop buy <pack>`
  // and the dedicated `.skillpack buy <pack>` command share one purchase
  // path. Quantity is ignored here — a pack purchase is always
  // `pullsPerPurchase` pulls, there's no "buy N packs at once" concept.
  if (findPack(query)) {
    const { handleBuy: handleBuySkillPack } = await import('./skillpack.js')
    return handleBuySkillPack(ctx, args)
  }

  // Blue Band — the old woman's, not the shop's. She hands one over for an
  // honest answer, never for Solars, so this must intercept before
  // findInCatalog()/the buyPrice==null guard below.
  if (BLUE_BAND_QUERIES.has(query)) {
    return startBlueBandRiddle(ctx)
  }

  const entry = findInCatalog(query)
  if (!entry) {
    const { listStoreItems } = await import('../lib/cosmetic-store.js')
    const underscored = query.replace(/\s+/g, '_')
    const cosMatch = listStoreItems().find((c) =>
      c.id.toLowerCase() === query ||
      c.id.toLowerCase() === underscored ||
      c.name.toLowerCase() === query ||
      c.name.toLowerCase().includes(query)
    )
    if (cosMatch) {
      const { default: storePlugin } = await import('./store.js')
      return storePlugin.run({ ...ctx, args: ['buy', cosMatch.id] })
    }
    return ctx.reply(
      `❌ *Item* "_${queryParts.join(' ')}_" *not found in the shop.*\n` +
      `🔎 Browse with *${p}shop weapons*, *${p}shop armor*, *${p}shop tools*, or *${p}shop potions*.`,
    )
  }

  // Guild-bound exclusives are not sold at the town stall — only in your guild hall.
  if (entry.guildBound || entry.guildId) {
    const pretty = entry.guildId ? entry.guildId.replace(/_/g,' ').replace(/\b\w/g,c=>c.toUpperCase()) : 'your guild'
    return ctx.reply(
      `🏰 *Guild-bound — not sold here.*\n` +
      `*${entry.name}* is an exclusive of *${pretty}*. Buy it in your guild hall with *${p}guild shop buy ${entry.id}*.\n` +
      `_You must be a member of that guild to purchase it. It cannot be gifted or traded._`
    )
  }

  // Mid-battle: only consumables (potions) can be bought. Gear purchases
  // are blocked so a player can't shop for a full new loadout mid-fight,
  // but they can still restock health/mana potions to keep fighting.
  if (ctx.player?.inBattle && entry.type !== 'consumable') {
    return ctx.reply(
      `⚔️ *You're mid-battle* — only potions can be bought right now.\n` +
      `🧪 Browse with *${p}shop potions*.`,
    )
  }

  // Gem-priced mythic gear in the shop (e.g. Black Armor of Napoleon — 100 Gems)
  if (entry.gemPrice != null && entry.buyPrice == null) {
    const totalGems = roundGems(entry.gemPrice * qty)
    let gemOutcome = null
    await updatePlayer(ctx.db, ctx.from, (player) => {
      if (player.level < (entry.levelReq ?? 1)) {
        gemOutcome = { ok: false, reason: 'level' }
        return player
      }
      const gems = player.wallet?.gems ?? 0
      if (gems < totalGems) {
        gemOutcome = { ok: false, reason: 'gems', gems }
        return player
      }
      if (!hasInventoryRoom(player, qty)) {
        gemOutcome = { ok: false, reason: 'full', player }
        return player
      }
      player.wallet.gems = roundGems(gems - totalGems)
      recordSink(ctx.db, 'shop', { gems: totalGems })
      for (let i = 0; i < qty; i++) {
        player.inventory.push(entry.id)
      }
      gemOutcome = { ok: true, remaining: player.wallet.gems }
      return player
    }, { critical: true })

    if (gemOutcome.reason === 'level') {
      return ctx.reply(`❌ *${entry.name}* requires Level *${entry.levelReq}*. You are Level ${ctx.player?.level ?? '?'}.`)
    }
    if (gemOutcome.reason === 'gems') {
      const short = roundGems(totalGems - gemOutcome.gems)
      return ctx.reply(
        `❌ *Not enough Gems!*\n` +
        `*${entry.name}*${qty > 1 ? ` × ${qty}` : ''} costs 💎 *${fmtGems(totalGems)} Gems*.\n` +
        `You have 💎 *${fmtGems(gemOutcome.gems)}*. You need 💎 *${fmtGems(short)}* more.`,
      )
    }
    if (gemOutcome.reason === 'full') {
      return ctx.reply(
        `❌ ${inventoryFullMessage(gemOutcome.player)}\n` +
        `_Can't buy_ *${entry.name} x${qty}* _— not enough room._`,
      )
    }

    const qtyLine = qty > 1 ? ` × ${qty}` : ''
    const equipHint = entry.fullArmorSuit
      ? `_Added to your inventory. Equip the full suit with *${p}equip ${entry.name.toLowerCase()}*._`
      : `_Added to your inventory. Use *${p}inventory* to view._`
    const caption =
      `🛒 *Purchase complete!*\n\n` +
      `${rarityEmoji(entry.rarity)} *${entry.name}*${qtyLine}\n` +
      `💰 Paid: 💎 *${fmtGems(totalGems)} Gems*\n` +
      `💰 Remaining: 💎 *${fmtGems(gemOutcome.remaining)} Gems*\n\n` +
      equipHint
    if (entry.image) return sendImage(ctx, entry.image, caption, { fallbackImage: SHOP_BANNER })
    return ctx.reply(caption)
  }

  // Materials (ores, scraps, etc.) share the catalog for .shop sell but have
  // no buyPrice — they're gathered via .mine, not purchased. Block buying
  // them here so totalCost never computes as NaN (buyPrice undefined).
  if (entry.buyPrice == null) {
    return ctx.reply(`❌ *${entry.name}* isn't sold in the shop — gather it with *${p}mine* instead.`)
  }

  // Town favor: Hesta keeps this stall. A Friend pays 5% less and a Confidant
  // 10% less (lib/town-favor.js).
  const discount = townDiscount(ctx.player, 'shop')
  // Market price: if the market has data for this item, use the dynamic
  // price; otherwise fall back to the static buyPrice.
  const marketPrice = getCurrentPrice(ctx.db, entry)
  const totalCost = Math.max(0, Math.round(marketPrice * qty * (1 - discount)))
  const priceChanged = marketPrice !== entry.buyPrice
  let outcome = null

  await updatePlayer(ctx.db, ctx.from, player => {
    if (player.level < entry.levelReq) {
      outcome = { ok: false, reason: 'level' }
      return player
    }

    const solars = player.wallet?.solars ?? 0
    if (solars < totalCost) {
      outcome = { ok: false, reason: 'solars', solars }
      return player
    }

    if (!hasInventoryRoom(player, qty)) {
      outcome = { ok: false, reason: 'full', player }
      return player
    }

    player.wallet.solars -= totalCost
    recordSink(ctx.db, 'shop', { solars: totalCost })
    for (let i = 0; i < qty; i++) {
      player.inventory.push(entry.id)
    }

    outcome = { ok: true, remaining: player.wallet.solars }
    return player
  }, { critical: true })

  // Reply only after updatePlayer's write has actually landed — replying
  // from inside the mutator (the old behaviour) could tell the player
  // "purchase complete" before the write finished, which under a race
  // with another concurrent command could silently lose the write and
  // leave the player with a "successful" purchase that never actually
  // appears in their inventory.
  if (outcome.reason === 'level') {
    return ctx.reply(`❌ *${entry.name}* requires Level *${entry.levelReq}*. You are Level ${ctx.player?.level ?? '?'}.`)
  }
  if (outcome.reason === 'solars') {
    const short = totalCost - outcome.solars
    return ctx.reply(
      `❌ *Not enough Solars!*\n` +
      `*${entry.name}* × ${qty} costs ☀️ *${totalCost}*.\n` +
      `You have ☀️ *${outcome.solars}*. You need ☀️ *${short}* more.`,
    )
  }
  if (outcome.reason === 'full') {
    return ctx.reply(
      `❌ ${inventoryFullMessage(outcome.player)}\n` +
      `_Can't buy_ *${entry.name} x${qty}* _— not enough room._`,
    )
  }

  const qtyLine = qty > 1 ? ` × ${qty}` : ''
  // Record the purchase in the market engine — shifts price UP (demand)
  for (let i = 0; i < qty; i++) {
    recordPurchase(ctx.db, entry.id)
  }
  // Show market price indicator if different from base
  const priceNote = priceChanged
    ? (marketPrice > entry.buyPrice ? ` _(🔴 above base)_` : ` _(🟢 below base)_`)
    : ''
  return ctx.reply(
    `🛒 *Purchase complete!*\n\n` +
    `${rarityEmoji(entry.rarity)} *${entry.name}*${qtyLine}${priceNote}\n` +
    `💰 Paid: ☀️ *${totalCost}*` +
    (discount > 0 ? ` _(Hesta's friend price, ${Math.round(discount * 100)}% off)_` : '') + `\n` +
    `💰 Remaining: ☀️ *${outcome.remaining}*\n\n` +
    `_Added to your inventory. Use *${p}inventory* to view._`,
  )
}

// ── The old woman's Blue Band (The End event) ─────────────────────────────
// What players might type for it. The bare "band" is in here on purpose: it's
// the only band in the game, and a sleeping player typing it deserves an
// answer rather than "not found in the shop".
const BLUE_BAND_QUERIES = new Set([
  'blue band', 'blue_band', 'blueband', 'blue-band', 'band', 'bluband',
])

/**
 * `.shop buy blue band` — start (or re-ask) the old woman's riddle.
 *
 * She costs nothing but honesty: asking only sets
 * `blueBandRiddle.state='awaiting_answer'`, and plugins/answer.js resolves it.
 * A wrong answer locks her door (`state:'locked'`); the lock is cleared by
 * applyEndEventTick() the moment the player is seen outside Astral Town, which
 * is how "travel to a dungeon and come back" is enforced.
 */
async function startBlueBandRiddle(ctx) {
  const p = config.prefix

  // Off-event she's just a bewildered old lady — no spoilers, no band.
  if (!isEventActive(ctx.db)) {
    return ctx.reply(
      `👵 _"A blue band? Whatever for, child? The air is clean today."_\n\n` +
      `_The old woman waves you off._`,
    )
  }

  // A null location means "never left town" (see plugins/profile.js's default).
  const here = ctx.player?.location ?? ASTRAL_TOWN_ID
  if (here !== ASTRAL_TOWN_ID) {
    return ctx.reply(
      `👵 *The old woman keeps her stall in Astral Town.*\n` +
      `🚪 _Head back with_ *${p}travel town* _and ask her there._`,
    )
  }

  let outcome = null
  await updatePlayer(ctx.db, ctx.from, (player) => {
    if (hasBlueBand(player) || (player.inventory ?? []).includes(BLUE_BAND_ID)) {
      outcome = 'already'
      return player
    }
    if (player.blueBandRiddle?.state === 'locked') {
      outcome = 'locked'
      return player
    }
    player.blueBandRiddle = { state: 'awaiting_answer', askedAt: Date.now() }
    outcome = 'asked'
    return player
  })

  if (outcome === 'already') return ctx.reply(RIDDLE_ALREADY_BANDED)
  if (outcome === 'locked')  return ctx.reply(RIDDLE_WRONG)
  return ctx.reply(RIDDLE_QUESTION.replaceAll('{prefix}', p))
}

/**
 * Ability Slot — flat 5 gems, repeatable, no scaling cost, no cap.
 * Directly increments player.abilitySlots (not an inventory item).
 * `qty` lets a player buy several slots in one command, same as any
 * other shop purchase.
 */
async function handleBuyAbilitySlot(ctx, qty) {
  const p          = config.prefix
  const totalCost  = ABILITY_SLOT_GEM_PRICE * qty

  let raceAborted = false
  let newSlotCount = null
  await updatePlayer(ctx.db, ctx.from, (player) => {
    const gems = player.wallet?.gems ?? 0
    if (gems < totalCost) { raceAborted = true; return }
    player.wallet.gems = roundGems(gems - totalCost)
    player.abilitySlots = (player.abilitySlots ?? 1) + qty
    newSlotCount = player.abilitySlots
  }, { critical: true })

  if (raceAborted) {
    return ctx.reply(
      `❌ *Not enough Gems!*\n` +
      `*Ability Slot*${qty > 1 ? ` × ${qty}` : ''} costs 💎 *${totalCost}*.\n` +
      `_Use_ *${p}profile* _to check your balance._`,
    )
  }

  return ctx.reply(
    `🛒 *Purchase complete!*\n\n` +
    `✨ *Ability Slot*${qty > 1 ? ` × ${qty}` : ''}\n` +
    `💰 Paid: 💎 *${totalCost}*\n` +
    `✨ You now have *${newSlotCount}* ability slot(s).\n\n` +
    `_Equip an owned ability with *${p}ability equip <name>*._`,
  )
}

// ── Sell ──────────────────────────────────────────────────────────────

const sellableFallbackList = allItems.filter(
  (i) => Number(i?.sellPrice) > 0 && !i.exclusive && !i.starterPackExclusive && i.id !== 'ghostblade',
)

function findSellableEntry(query, inventory = []) {
  const q = String(query ?? '').toLowerCase().trim()
  if (!q) return undefined
  const key = (v) => String(v ?? '').toLowerCase().replace(/[^a-z0-9]+/g, '')
  const wanted = key(q)
  const inBagSet = new Set(inventory ?? [])

  // Prefer matching an item the player is actually holding in their bag first
  for (const item of sellableFallbackList) {
    if (!inBagSet.has(item.id)) continue
    if (item.id.toLowerCase() === q || key(item.id) === wanted || key(item.name) === wanted) return item
  }
  for (const item of sellableFallbackList) {
    if (!inBagSet.has(item.id)) continue
    if (item.name.toLowerCase().includes(q)) return item
  }

  const fromCatalog = findInCatalog(q)
  if (fromCatalog && Number(fromCatalog.sellPrice) > 0) return fromCatalog

  for (const item of sellableFallbackList) {
    if (item.id.toLowerCase() === q || key(item.id) === wanted || key(item.name) === wanted) return item
  }
  for (const item of sellableFallbackList) {
    if (item.name.toLowerCase().includes(q)) return item
  }
  return undefined
}

async function handleSell(ctx, args) {
  const p = config.prefix
  if (!args[1]) {
    return ctx.reply(
      `❌ *Usage:* *${p}shop sell <item name or id> [quantity]*\n` +
      `_Example:_ *${p}shop sell health_potion 3*`,
    )
  }

  const lastArg = args[args.length - 1]
  let qty       = 1
  let queryParts = args.slice(1)
  if (/^\d+$/.test(lastArg) && args.length > 2) {
    qty        = Math.max(1, Math.min(99, parseInt(lastArg, 10)))
    queryParts = args.slice(1, -1)
  } else if (lastArg?.toLowerCase() === 'all' && args.length > 2) {
    qty        = 999
    queryParts = args.slice(1, -1)
  }
  const query = queryParts.join(' ').toLowerCase()

  const entry = findSellableEntry(query, ctx.player?.inventory)
  if (!entry) {
    return ctx.reply(
      `❌ *Item* "_${queryParts.join(' ')}_" *is not sellable here.*\n` +
      `_Try *${p}salvage* to scrap unsellable items or curios for Solars._`,
    )
  }

  let outcome = null
  await updatePlayer(ctx.db, ctx.from, player => {
    const bag = player.inventory ?? []
    const totalOwned = bag.filter(id => id === entry.id).length
    if (totalOwned === 0) {
      outcome = { reason: 'missing' }
      return player
    }
    const equippedCount = Object.values(player.equipped ?? {}).filter(id => id === entry.id).length
    const sellableOwned = Math.max(0, totalOwned - equippedCount)
    if (sellableOwned <= 0) {
      outcome = { reason: 'equipped' }
      return player
    }

    const actualQty = Math.min(qty, sellableOwned)
    const earnings  = entry.sellPrice * actualQty

    let removed = 0
    player.inventory = bag.filter(id => {
      if (id === entry.id && removed < actualQty) { removed++; return false }
      return true
    })
    player.wallet = player.wallet ?? {}
    player.wallet.solars = (player.wallet.solars ?? 0) + earnings

    outcome = {
      reason: 'ok',
      actualQty,
      owned: sellableOwned,
      requestedAll: qty === 999,
      earnings,
      balance: player.wallet.solars,
    }
    return player
  })

  if (outcome?.reason === 'missing') {
    return ctx.reply(`❌ *You don't have any* *${entry.name}* _in your inventory._`)
  }
  if (outcome?.reason === 'equipped') {
    return ctx.reply(`⚡ *${entry.name}* is currently equipped. Unequip it first before selling.`)
  }

  const qtyLine = outcome.actualQty > 1 ? ` × ${outcome.actualQty}` : ''
  const shortLine = !outcome.requestedAll && outcome.actualQty < qty
    ? `\n⚠️ _You only had ${outcome.owned}, sold ${outcome.actualQty}._`
    : ''

  return ctx.reply(
    `💰 *Sold!*\n\n` +
    `${rarityEmoji(entry.rarity)} *${entry.name}*${qtyLine}\n` +
    `💰 Earned: ☀️ *${outcome.earnings.toLocaleString()}*\n` +
    `💰 Balance: ☀️ *${outcome.balance.toLocaleString()}*` +
    shortLine,
  )
}

// ── Info ──────────────────────────────────────────────────────────────

function handleInfo(args) {
  const query = args.slice(1).join(' ').toLowerCase()
  const entry = findInCatalog(query)
  if (!entry) return { text: `❌ *Item* "_${args.slice(1).join(' ')}_" *not found in the shop.*`, entry: null }
  return { text: fmtDetails(entry), entry }
}

// ── Main menu ─────────────────────────────────────────────────────────

function mainMenu(player) {
  const p = config.prefix
  const solars = player.wallet?.solars ?? 0
  const gems   = player.wallet?.gems   ?? 0
  // Once bought, the ender chest is not for sale again — the line becomes the
  // way into it instead of a price tag for something they already own.
  const enderLine = hasEnderChest(player)
    ? `🔮 *${p}ender* — open your Ender Chest _(100 slots, death-proof)_\n`
    : `🔮 *${p}ender* — the 100-slot Ender Chest, ☀️${ENDER_PRICE_SOLARS.toLocaleString()} _(${p}shop buy ender chest)_\n`
  // Same shape as the ender chest: a price tag until bought, then a doorway
  // into the thing itself.
  const bookLine = hasEnchantingBook(player)
    ? `📕 *${p}enchant* — work the Enchanting Table _(book owned)_\n`
    : `📕 *${p}enchant* — the Enchanting Book, ☀️${ENCHANT_BOOK_SOLARS.toLocaleString()} _(${p}shop buy enchanting book)_\n`
  return (
    `┏━━━━━━━━━━━━━━┓\n` +
    `┃  🏪 *ASTRAL SHOP* 🏪\n` +
    `┗━━━━━━━━━━━━━━┛\n` +
    `_Hesta keeps the counter on Market Row. The bell over the door still works._\n` +
    `_Everything an adventurer needs, under one roof. Guild slips that ask for a potion mean this counter._\n\n` +
    `💰 ☀️ *${solars}* Solars   ·   💎 *${fmtGems(gems)}* Gems\n\n` +
    `📦 *Browse:*\n` +
    `   🗡️ *${p}shop weapons* — _blades, bows & more_\n` +
    `   🛡️ *${p}shop armor* — _helmets, chests, boots_\n` +
    `   🔮 *${p}shop relics* — _offhand trinkets & the Chest_\n` +
    `   ⛏️ *${p}shop tools* — _pickaxes for mining_\n` +
    `   🧪 *${p}shop potions* — _heals, cures & buffs_\n` +
    `   ✨ *${p}shop cosmetics* — _PFPs, banners, Fluid Frames & GIF effects_\n` +
    `   🎞️ *${p}shop effects* — _animated GIF overlay effects for .me_\n\n` +
    `✨ *${p}shop buy ability_slot* — 💎${ABILITY_SLOT_GEM_PRICE} for an extra ability slot\n` +
    `🎴 *${p}skillpack* — pull mythic-tier skills with Gems\n` +
    `🧰 *${p}chest* — safe storage immune to death loss\n` +
    enderLine +
    bookLine + `\n` +
    `🛒 *${p}shop buy <item> [qty]* — _purchase_\n` +
    `💰 *${p}shop sell <item> [qty]* — _sell from bag_\n` +
    `🔍 *${p}shop info <item>* — _full item details_\n\n` +
    `_Tip: add_ *all* _after a category for the full catalog, or_ *page 2* _to flip pages._`
  )
}

// ── Plugin export ─────────────────────────────────────────────────────

// ── The Sect Empire's cart ────────────────────────────────────────────────
import { isInSectEmpire } from '../lib/worlds.js'
import { atPeddler, shopScreen } from '../lib/sect-shop.js'
import { runSectBuy } from '../lib/sect-item-commands.js'

/** The cart, as the lines it reads as. */
function sectShopScreen(player) {
  return shopScreen(player, { here: atPeddler(player) })
}

export default {
  name:           'shop',
  // `store` used to live here. It belongs to plugins/store.js now (the gem PFP
  // & Banner Store, which answers `.store` for every argument). Leaving the
  // alias here too would make the two collide on EVERY input — plugin-manager
  // is last-registered-wins, so `.store` would flip between the item shop and
  // the cosmetic store depending on file order. `.shop key`/`.shop shop` still
  // reach the royal merchant.
  aliases:        ['shop'],
  category:       'economy',
  requiresPlayer: true,
  description:    'Browse and buy weapons, armor, and potions',

  async run(ctx) {
    const { args, player } = ctx
    const sub = args[0]?.toLowerCase()

    // ── The Sect Empire's own cart ─────────────────────────────────────
    // A cultivator buys from the roadside peddler at the Foot of the Mountain
    // Road, in Spirit Stones, off a cart with no Astral item on it. Astra
    // Kingdom's shop below is not reached, not read and not changed.
    if (isInSectEmpire(player)) {
      if (sub === 'buy' || sub === 'purchase') return runSectBuy(ctx, args.slice(1))
      return ctx.reply(sectShopScreen(player).join('\n'))
    }

    if (!sub)                                    return sendShopScreen(ctx, SHOP_BANNER, mainMenu(player), { sections: true })
    if (sub === 'weapons' || sub === 'weapon')   return sendShopScreen(ctx, SHOP_BANNER, handleWeapons(player, args))
    if (sub === 'armor'   || sub === 'armour')   return sendShopScreen(ctx, ARMOR_SHOP_BANNER, handleArmor(player, args))
    if (sub === 'relics'  || sub === 'relic')    return sendShopScreen(ctx, SHOP_BANNER, handleRelics(player, args))
    if (sub === 'tools'   || sub === 'tool')     return sendShopScreen(ctx, SHOP_BANNER, handleTools(player, args))
    if (sub === 'potions' || sub === 'potion') {
      const screen = potionsScreen(args)
      return sendShopScreen(ctx, SHOP_BANNER, screen.text, { buttons: screen.buttons })
    }
    if (['cosmetics', 'cosmetic', 'effects', 'effect', 'gif', 'gifs', 'frames', 'frame', 'pfps', 'banners'].includes(sub)) {
      const { default: storePlugin } = await import('./store.js')
      const forwardArgs = sub === 'cosmetics' || sub === 'cosmetic' ? args.slice(1) : args
      return storePlugin.run({ ...ctx, args: forwardArgs })
    }
    if (sub === 'buy'     || sub === 'purchase') return handleBuy(ctx, args)
    if (sub === 'sell')                          return handleSell(ctx, args)
    if (sub === 'info'    || sub === 'inspect') {
      const { text, entry } = handleInfo(args)
      if (!entry) return sendImage(ctx, SHOP_BANNER, text)
      // entry.image points at this bot's own /assets/items/<id>.png. That art is
      // rendered on demand from vendor/game-icons (lib/item-art-cache.mjs) or
      // read off lib/assets/items/ — but when NEITHER is present on the host,
      // the URL is fetched from our public origin, and that origin being down
      // used to throw out of sendImage and swallow the whole reply: no picture
      // AND no details. Naming the banner as the fallback keeps the item
      // details arriving with a usable image either way (and sendImage still
      // degrades to plain text if even the banner can't be fetched).
      //
      // fmtDetails already opens with name · rarity · level · prices, so no
      // header is prepended here — doing so printed all of it twice.
      //
      // The card is where buying happens in bulk: 🛒 Buy 1 / 5 / 10 are the same
      // `shop buy <id> <qty>` a player would type, so a tap can never buy
      // something typing couldn't. Items with no Solars price get no row.
      return sendShopScreen(ctx, entry.image || SHOP_BANNER, text, {
        buttons: buyQuantityRows(entry),
        fallbackImage: SHOP_BANNER,
      })
    }

    return sendImage(
      ctx, SHOP_BANNER,
      `❌ *Unknown shop command* "_${sub}_".\n\n` + mainMenu(player),
    )
  },
}
