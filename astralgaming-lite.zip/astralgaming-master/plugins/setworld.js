/**
 * setworld.js — `.setworld <player> <astra_kingdom|sect_empire>`.
 *
 * TESTING ONLY, and owner only. There is no road into the Sect Empire yet, so
 * the owner needs a way to put a player there and to bring them back. This is
 * that way, and it will keep being useful long after the road exists: it is the
 * one command that can move a record between the two worlds without playing.
 *
 * WHAT IT WRITES: player.world, and the empty player.sect container if the
 * record does not carry one. That is all, on purpose. The Astral profile is
 * never read, never reset and never converted: a player moved into the Sect
 * Empire and back out again is byte for byte the same player they were, which
 * is exactly what the tests pin.
 *
 * Targets the way every admin tool does: a reply, an @mention, or a typed name.
 */
import { config } from '../config.js'
import { isOwnerJid, extractTarget } from '../lib/group-helpers.js'
import { updatePlayer, getPlayer, findPlayerByName } from '../lib/player-repo.js'
import { ASTRA_KINGDOM, SECT_EMPIRE, PLAYER_WORLDS, worldName, worldOf, setPlayerWorld } from '../lib/worlds.js'

const WORLD_EMOJI = { [ASTRA_KINGDOM]: '🌍', [SECT_EMPIRE]: '⛰️' }

/** Resolve the target player record: reply/mention first, then the typed name. */
function resolveTarget(db, ctx, name) {
  const users = db?.data?.users ?? {}
  const jid = extractTarget(ctx)
  if (jid && users[jid]) return { player: users[jid], jid, how: 'mention' }
  if (jid && !users[jid]) return { player: null, jid, how: 'mention' }
  const typed = String(name ?? '').trim()
  if (!typed) return { player: null, jid: null, how: 'none' }
  const byName = findPlayerByName(users, typed)
  if (!byName) return { player: null, jid: null, how: 'none' }
  return { player: byName, jid: byName.id ?? byName.jid ?? null, how: 'name' }
}

export default {
  name: 'setworld',
  aliases: [],
  category: 'admin',
  requiresPlayer: false,
  description: 'Owner-only: move a player between Astra Kingdom and the Sect Empire (testing)',

  async run(ctx) {
    const p = config.prefix
    if (!ctx.from || !isOwnerJid(ctx.from)) {
      return ctx.reply('❌ This command is restricted to the bot owner.')
    }

    const args = (ctx.args ?? []).map(a => String(a ?? ''))
    const worldArg = (args[args.length - 1] ?? '').trim().toLowerCase()
    const nameQuery = args.slice(0, -1).join(' ').trim()

    if (args.length < 2 || !PLAYER_WORLDS.includes(worldArg)) {
      return ctx.reply(
        `🧭 *Usage:* *${p}setworld <player> <${ASTRA_KINGDOM}|${SECT_EMPIRE}>*\n` +
        `_Moves a player between the two worlds. It changes nothing else: their Astral record is untouched either way._`,
      )
    }

    const { player: target, jid } = resolveTarget(ctx.db, ctx, nameQuery)
    if (!target || !jid) {
      return ctx.reply(
        `❓ *Nobody called "${nameQuery || '?'}" is playing.*\n` +
        `_Name them, or reply to / mention them:_ *${p}setworld <player> <world>*`,
      )
    }

    const before = worldOf(target)
    let wrote = null
    let after = null
    await updatePlayer(ctx.db, jid, pl => {
      wrote = setPlayerWorld(pl, worldArg)
      after = worldOf(pl)
      return pl
    })

    const fresh = getPlayer(ctx.db, jid) ?? target
    if (!wrote) {
      return ctx.reply(`⚠️ *${fresh.name}* could not be moved. Nothing was changed.`)
    }

    const emoji = WORLD_EMOJI[after] ?? '🧭'
    const already = before === after
    return ctx.reply(
      `${emoji} *${fresh.name}* is ${already ? 'already' : 'now'} in *${worldName(after)}*.\n` +
      (already
        ? `_Nothing was changed. They were standing there before this command._`
        : after === SECT_EMPIRE
          ? `_Their Astral record is untouched, and it stays untouched for as long as they are there._`
          : `_Their Astral record is exactly as it was. Nothing was moved, added or taken._`),
    )
  },
}
