/**
 * releasebeast.js — let a summoned beast go, permanently, and free its slot.
 *
 * The roster (player.summonedBeasts) is capped at BEAST_MAX_OWNED (4) and the
 * cap is enforced at ACQUISITION: mining (plugins/mine.js), the Auction House
 * (lib/auction-lots.js), Season shop boxes (lib/season-engine.js) and
 * <prefix>givebeast all refuse a fifth beast. Before this command the only way
 * out of a full roster was to want one of the four you already had, so a beast
 * you had outgrown was a slot you could never get back. This is that way out.
 *
 * Usage:
 *   <prefix>releasebeast                — your roster, with what is in each slot
 *   <prefix>releasebeast <name>         — what releasing it would cost you (no change yet)
 *   <prefix>releasebeast <name> confirm — let it go for good; the slot is free
 *
 * Deliberately two-step. This is the only command in the game that destroys a
 * beast outright, the CP in it took real play to earn (lib/beast-engine.js
 * awardBeastCp), and there is no refund path: no CP comes back, no currency,
 * no item. So `<name>` alone only previews, and the confirm must be typed.
 *
 * Guards: refused while the caller is in a battle or a pending challenge. The
 * active beast is a live combat participant (turn bonus / damage soak via
 * getActiveBeast in beast-engine.js), so releasing it mid-fight would pull it
 * out from under the fight that is already running — every battle shape this
 * bot has is checked here, including the Pokémon and party ones that do not
 * set a plain inBattle flag on the player object.
 *
 * Releasing the ACTIVE beast is allowed and clears activeBeast, so the next
 * beast equipped becomes the active one. Everything else is left untouched:
 * beastInventory keeps the historical record, and no other beast is affected.
 */
import { config } from '../config.js'
import { beastMap } from '../lib/game-data.js'
import { updatePlayer } from '../lib/player-repo.js'
import { BEAST_MAX_OWNED, getBeastStats, releaseOwnedBeast } from '../lib/beast-engine.js'
import { rarityStars } from '../lib/rarity.js'

/** Every owned beast whose name or id matches `query`, loosely. */
function matchOwned(player, query) {
  const q = query.toLowerCase().trim()
  const owned = player.summonedBeasts ?? []
  const named = owned.map((entry) => ({ entry, def: beastMap[entry.beastId] })).filter((r) => r.def)
  const exact = named.filter((r) => r.def.id.toLowerCase() === q || r.def.name.toLowerCase() === q)
  if (exact.length) return exact
  return named.filter((r) => r.def.name.toLowerCase().includes(q) || r.def.id.toLowerCase().includes(q))
}

const rosterLine = (pr, player) => {
  const owned = player.summonedBeasts ?? []
  return owned.map((entry, i) => {
    const def = beastMap[entry.beastId]
    if (!def) return `${i + 1}. _unknown beast (${entry.beastId})_`
    const stats = getBeastStats(def, entry.cp)
    const active = entry.beastId === player.activeBeast ? '  ⭐ _active_' : ''
    return `${i + 1}. ${def.emoji} *${def.name}* ${rarityStars(def.rarity)} — Lv.${stats.level} · ${entry.cp} CP${active}`
  }).join('\n')
}

const usage = (pr) =>
  `Usage:\n` +
  `  *${pr}releasebeast <name>* — see what letting one go would cost you\n` +
  `  *${pr}releasebeast <name> confirm* — let it go for good\n\n` +
  `_Releasing frees the slot. The beast's CP is NOT refunded and it cannot be ` +
  `won back from you: it is gone._\n` +
  `See your roster: *${pr}summon list*`

export default {
  name: 'releasebeast',
  aliases: ['release', 'letgo', 'freebeast'],
  category: 'combat',
  requiresPlayer: true,
  description: `${config.prefix}releasebeast <name> — let a summoned beast go forever and free its roster slot`,
  subcommands: [
    { cmd: '<name>', desc: 'preview the release: exactly what is lost (nothing happens yet)' },
    { cmd: '<name> confirm', desc: 'let it go for good and free the slot' },
  ],

  async run(ctx) {
    const { player, db } = ctx
    const pr = config.prefix
    const args = (ctx.args ?? []).map((a) => String(a))
    const confirm = args[args.length - 1]?.toLowerCase() === 'confirm'
    const query = (confirm ? args.slice(0, -1) : args).join(' ').trim()

    // ── No name: show the roster ────────────────────────────────────────────
    if (!query) {
      if (!(player.summonedBeasts ?? []).length) {
        return ctx.reply(`🐲 You don't have any summoned beasts to release.\n_Beasts are rare finds while mining. (${pr}mine)_`)
      }
      return ctx.reply(
        `🐲 *Your beasts* _(${(player.summonedBeasts ?? []).length}/${BEAST_MAX_OWNED} slots)_\n` +
        `${rosterLine(pr, player)}\n\n` +
        usage(pr),
      )
    }

    const matches = matchOwned(player, query)
    if (!matches.length) {
      const names = (player.summonedBeasts ?? []).map((e) => beastMap[e.beastId]?.name ?? e.beastId)
      return ctx.reply(
        `❌ You don't own a beast matching *"${query}"*.\n` +
        (names.length ? `Your roster: ${names.map((n) => `*${n}*`).join(', ')}` : `_Your roster is empty._`),
      )
    }
    if (matches.length > 1) {
      return ctx.reply(
        `❓ Which one? *"${query}"* matches ${matches.length} of your beasts:\n` +
        matches.map((r) => `• ${r.def.emoji} *${r.def.name}*`).join('\n') +
        `\n_Type the full name._`,
      )
    }

    const { def } = matches[0]
    const stats = getBeastStats(def, matches[0].entry.cp)

    // ── Preview: <name> alone ───────────────────────────────────────────────
    if (!confirm) {
      return ctx.reply(
        `⚠️ *Let ${def.name} go?*\n` +
        `━━━━━━━━━━━━━━━━━━\n` +
        `${def.emoji} *${def.name}* ${rarityStars(def.rarity)} — Lv.${stats.level} · ${matches[0].entry.cp} CP · ⚔️ ${stats.atk} / 🛡️ ${stats.def} / ❤️ ${stats.maxHp}\n\n` +
        `Releasing it for good means:\n` +
        `• it leaves your roster and frees *1 of ${BEAST_MAX_OWNED}* slots\n` +
        `• its *${matches[0].entry.cp} CP* and *Lv.${stats.level}* are gone — nothing is refunded\n` +
        `• it never comes back unless you find or win another one\n` +
        (matches[0].entry.beastId === player.activeBeast ? `• it is your *active* beast, so it is unequipped\n` : '') +
        `\nTo go through with it, type:\n` +
        `*${pr}releasebeast ${def.name} confirm*\n\n` +
        `_Anything else and nothing happens._`,
      )
    }

    // ── Confirm: must not be mid-fight ──────────────────────────────────────
    const busy =
      player.inBattle || player.battleState ||
      player.inPokemonBattle || player.pokemonBattleState ||
      player.pvpChallenge || player.pokemonChallenge ||
      player.inDungeon
    if (busy) {
      return ctx.reply(
        `⛔ *Not while you're in a fight.*\n` +
        `Your beasts fight beside you — finish or flee first, then release it. (_${pr}flee_)`,
      )
    }

    let outcome = null
    await updatePlayer(db, ctx.from, (p) => {
      // Re-resolve under the write lock: another command may have released it
      // (or it may have evolved) between the preview above and this mutator, so
      // the release acts on what is actually in the roster right now.
      const live = matchOwned(p, def.name).find((r) => r.def.id === def.id)
      if (!live) { outcome = { reason: 'gone' }; return p }
      outcome = releaseOwnedBeast(p, live.def.id)
      return p
    })

    if (outcome?.reason === 'gone' || outcome?.reason === 'not_owned') {
      return ctx.reply(`❌ *${def.name}* is no longer in your roster — nothing to release.`)
    }
    if (!outcome?.ok) {
      return ctx.reply(`❌ Couldn't release *${def.name}*. Please try again.`)
    }

    const left = outcome.remaining ?? 0
    return ctx.reply(
      `🕊️ *${def.name} is free.*\n` +
      `_It lingers a moment, then is gone._\n\n` +
      `• Slot freed — you can take in another beast now\n` +
      (outcome.wasActive ? `• It was your active beast, so you have none equipped: *${pr}summon list* then *${pr}equipbeast <name>*\n` : '') +
      `• *${matches[0].entry.cp} CP* and *Lv.${stats.level}* are gone with it; nothing was refunded\n` +
      `_Beasts are still found while mining: *${pr}mine*. ${left}/${BEAST_MAX_OWNED} slots in use._`,
    )
  },
}
