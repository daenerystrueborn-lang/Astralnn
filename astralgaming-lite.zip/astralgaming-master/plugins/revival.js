/**
 * revival.js — buy a Revival Stone. 50 gems, bought outright.
 *
 *   <prefix>revival            what the stone is, and what it costs
 *   <prefix>revival buy        buy one for 50 gems
 *   <prefix>revival info       the same explainer
 *
 * WHY THIS IS ITS OWN COMMAND AND NOT A `.shop` LINE. The stone is the only item
 * in the bot sold for GEMS rather than Solars, and it is the only way back for a
 * character Yelan has killed (see lib/yelan-engine.js). Both of those make it a
 * combat-economy item rather than a shop good, and it reads better next to
 * `.revive` than in the middle of a materials list.
 *
 * ATOMICITY (spec 8.2 and the ground rules): the gems and the stone move in ONE
 * updatePlayer() mutator. Every check that can refuse happens BEFORE the mutator
 * on the caller's snapshot, and the mutator re-checks the two that can race
 * (gems and bag room) against the live record — so a purchase can never take
 * gems without delivering, or deliver without taking gems.
 *
 * The price is one constant. Nothing else in the file knows what it is.
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { hasInventoryRoom, inventoryFullMessage } from '../lib/inventory-limits.js'
import { roundGems, fmtGems } from '../lib/format.js'

export const REVIVAL_STONE_ITEM = 'revival_stone'
/** One constant. Change it here and every message follows. */
export const REVIVAL_STONE_PRICE = 50

const RULE = '━━━━━━━━━━━━━━━━━━━━'

function explainer(pr, gems = null) {
  return (
    `🪨 *REVIVAL STONE* — 💎*${REVIVAL_STONE_PRICE}* gems\n${RULE}\n` +
    `_A companion Yelan has killed stays dead: still owned, still yours, and unable to be equipped or to ` +
    `answer you in any fight. Nothing else in the bot brings one back — not potions, not a Phoenix Down, ` +
    `not Mei's revival. This stone does, and nothing else does._\n\n` +
    `📥 Buy one: *${pr}revival buy*\n` +
    `🩹 Use it on a fallen companion: *${pr}revive <character>*` +
    (gems === null ? '' : `\n\n💎 Your gems: *${fmtGems(gems)}*`)
  )
}

export default {
  name: 'revival',
  aliases: ['revivalstone', 'revival-stone', 'stones'],
  category: 'combat',
  requiresPlayer: true,
  description: `${config.prefix}revival buy — buy a Revival Stone for ${REVIVAL_STONE_PRICE} gems (brings a Yelan-slain character back)`,

  async run(ctx) {
    const pr = config.prefix
    const sub = String(ctx.args[0] ?? '').toLowerCase()
    const gems = roundGems(ctx.player?.wallet?.gems ?? 0)

    if (!sub || sub === 'info' || sub === 'help' || sub === 'stone') {
      return ctx.reply(explainer(pr, gems))
    }
    if (!['buy', 'purchase', 'get'].includes(sub)) {
      return ctx.reply(explainer(pr, gems))
    }

    // ── Refusals, in the owner's stated order (spec 8.2) ──────────────────────
    if (ctx.player?.inBattle) {
      return ctx.reply(
        `⚔️ *Not mid-fight.*\n_You cannot buy your way out of a battle. Finish it, then buy the stone._`,
      )
    }
    if (gems < REVIVAL_STONE_PRICE) {
      return ctx.reply(
        `💎 *Not enough gems.*\n${RULE}\n` +
        `A Revival Stone costs 💎*${REVIVAL_STONE_PRICE}*. You hold 💎*${fmtGems(gems)}*, ` +
        `so you are 💎*${fmtGems(REVIVAL_STONE_PRICE - gems)}* short.\n\n` +
        `_Nothing has been charged._`,
      )
    }
    if (!hasInventoryRoom(ctx.player, 1)) {
      return ctx.reply(`🎒 *No room for the stone.*\n${inventoryFullMessage(ctx.player)}`)
    }

    let outcome = null
    await updatePlayer(ctx.db, ctx.from, (player) => {
      player.wallet = player.wallet ?? { solars: 0, gems: 0 }
      const live = roundGems(player.wallet.gems ?? 0)
      // Re-checked against the live record: both of these can move between the
      // read above and this mutator (a duel ending, an item bought elsewhere).
      if (live < REVIVAL_STONE_PRICE) { outcome = { reason: 'gems', gems: live }; return }
      if (!hasInventoryRoom(player, 1)) { outcome = { reason: 'bag' }; return }

      player.wallet.gems = roundGems(live - REVIVAL_STONE_PRICE)
      player.inventory = player.inventory ?? []
      player.inventory.push(REVIVAL_STONE_ITEM)
      outcome = { reason: 'ok', remaining: player.wallet.gems, count: player.inventory.filter((id) => id === REVIVAL_STONE_ITEM).length }
    })

    if (outcome?.reason === 'gems') {
      return ctx.reply(
        `💎 *Not enough gems.*\nA Revival Stone costs 💎*${REVIVAL_STONE_PRICE}*. You hold 💎*${fmtGems(outcome.gems)}*.\n\n_Nothing has been charged._`,
      )
    }
    if (outcome?.reason === 'bag') {
      return ctx.reply(`🎒 *No room for the stone.*\n${inventoryFullMessage(ctx.player)}`)
    }
    if (outcome?.reason !== 'ok') {
      return ctx.reply(`⚠️ The purchase did not go through. Nothing has been charged.`)
    }

    return ctx.reply(
      `🪨 *REVIVAL STONE BOUGHT*\n${RULE}\n` +
      `💎 Paid: *${REVIVAL_STONE_PRICE}*  ·  Left: 💎*${fmtGems(outcome.remaining)}*\n` +
      `🩹 You now hold *${outcome.count}* stone${outcome.count === 1 ? '' : 's'}.\n\n` +
      `_Use it on a fallen companion: *${pr}revive <character>*._`,
    )
  },
}
