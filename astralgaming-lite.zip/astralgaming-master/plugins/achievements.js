/**
 * achievements — the achievement pillar's player window (.ach).
 *
 *   .ach                the whole board, grouped by track
 *   .ach list [track]   same, optionally one track (combat, adventure, ...)
 *   .ach <track>        shorthand for .ach list <track>
 *   .ach claim          claim every unlocked achievement at once
 *   .ach claim <id>     claim one by id or name
 *   .ach info <id>      the full card for one achievement
 *
 * The engine owns everything (lib/achievement-engine.js). This plugin only
 * renders, and every mutation happens inside one updatePlayer mutator, the
 * same shape plugins/quest.js uses: refresh stamps sticky unlocks, claim pays,
 * and XP from rewards is settled with applyLevelUps in the same breath so a
 * reward never sits half applied.
 *
 * Copy follows the quest board's house style: no dashes, commas and colons.
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { levelsData, classes, races, getTotalStats } from '../lib/game-data.js'
import { applyLevelUps } from '../lib/combat-engine.js'
import { sendRankUp } from '../lib/rank-up.js'
import { sendImage } from '../lib/image.js'
import { getActiveSeason } from '../lib/season-engine.js'
import {
  ACHIEVEMENTS, TRACKS, TIERS,
  ensureAchievementState, refreshAchievements, getAchievementBoard,
  claimAchievements, findAchievement, achievementProgress,
  tierEmoji, tierPoints,
} from '../lib/achievement-engine.js'

const p = () => config.prefix

function bar(progress, goal) {
  const pct = goal > 0 ? Math.min(1, progress / goal) : 1
  const filled = Math.round(pct * 10)
  return '▰'.repeat(filled) + '▱'.repeat(10 - filled)
}

function rewardTag(reward) {
  if (!reward) return ''
  const amt = reward.amount ?? 1
  switch (reward.type) {
    case 'solars':       return `☀️ ${amt}`
    case 'gems':         return `💎 ${amt}`
    case 'xp':           return `📈 ${amt} XP`
    case 'seasonPoints': return `✨ ${amt} SP`
    case 'stamina':      return `⚡ ${amt} stamina`
    case 'character':    return `🎴 character`
    case 'item':         return `🎁 item`
    default:             return `${amt}`
  }
}

function statusGlyph(item) {
  if (item.claimed) return '☑️'
  if (item.claimable) return '🎁'
  return '⬜'
}

function boardLine(item) {
  const head = `${statusGlyph(item)} ${tierEmoji(item.tier)} *${item.name}*`
  if (item.claimable) return `${head}  ·  ${rewardTag(item.reward)} _(ready)_`
  if (item.claimed) return `${head}  ·  ${rewardTag(item.reward)} _(claimed)_`
  return `${head}  ·  ${item.progress}/${item.goal}  ${bar(item.progress, item.goal)}`
}

function renderBoard(player, track) {
  const board = getAchievementBoard(player, track)
  const s = board.summary
  const lines = [
    `🏆 *ACHIEVEMENTS*  ${s.unlocked}/${s.total} unlocked · ${s.points} pts${s.claimable ? ` · ${s.claimable} ready` : ''}\n`,
  ]
  for (const group of board.groups) {
    lines.push(`*${group.name.toUpperCase()}*  (${group.claimed}/${group.total} claimed · ${group.points} pts)`)
    for (const item of group.items) lines.push(boardLine(item))
    lines.push('')
  }
  lines.push(
    s.claimable > 0
      ? `🎁 *${s.claimable}* achievement${s.claimable === 1 ? '' : 's'} ready. Claim with *${p()}ach claim*.`
      : `_Claim finished achievements with *${p()}ach claim*._`,
  )
  return lines.join('\n')
}

function renderInfo(player, def) {
  ensureAchievementState(player)
  const state = player.achievements
  const prog = achievementProgress(player, def)
  const claimed = state.claimed.includes(def.id)
  const unlocked = state.unlocked.includes(def.id) || prog.done
  const status = claimed ? '☑️ claimed' : unlocked ? '🎁 ready to claim' : `${bar(prog.current, prog.goal)}  ${prog.current}/${prog.goal}`
  return (
    `${tierEmoji(def.tier)} *${def.name}*  ·  ${def.track}\n` +
    `_${def.desc}_\n\n` +
    `▸ Tier: *${def.tier}* (${tierPoints(def.tier)} pts)\n` +
    `▸ Reward: ${rewardTag(def.reward)}\n` +
    `▸ Status: ${status}\n\n` +
    (unlocked && !claimed
      ? `Claim it with *${p()}ach claim ${def.id}*.`
      : `_Earn it, then claim with *${p()}ach claim*._`)
  )
}

function renderClaims(claimed, lvlMsgs) {
  const rewardLines = claimed
    .map(c => `✅ ${tierEmoji(c.tier)} *${c.name}*  ·  ${c.rewardLabel ?? 'reward'}`)
    .join('\n')
  return (
    `🏆 *ACHIEVEMENTS CLAIMED*\n\n${rewardLines}` +
    (lvlMsgs.length ? `\n\n${lvlMsgs.join('\n')}` : '') +
    `\n\n_See what's left with *${p()}ach*._`
  )
}

function trackQuery(raw) {
  const q = String(raw ?? '').toLowerCase()
  if (!q || q === 'all') return null
  const match = Object.keys(TRACKS).find(t => t === q || t.startsWith(q))
  return match ?? null
}

export default {
  name:           'achievements',
  aliases:        ['ach', 'badge', 'badges', 'medal', 'medals', 'trophy', 'trophies'],
  category:       'progression',
  requiresPlayer: true,
  description:    `${config.prefix}ach [claim] — your achievement board, and claim finished ones`,
  subcommands: [
    { cmd: 'list [track]', desc: 'the board, optionally one track' },
    { cmd: 'claim [id]',   desc: 'claim every unlocked achievement, or one' },
    { cmd: 'info <id>',    desc: 'the full card for one achievement' },
    { cmd: 'emblem [1-80]',desc: 'equip an emblem crest on your profile card' },
  ],

  async run(ctx) {
    const { args, reply } = ctx
    const sub = (args[0] ?? '').toLowerCase()

    // ── Claim path ─────────────────────────────────────────────────────────
    if (sub === 'claim' || sub === 'complete' || sub === 'turnin') {
      const id = args[1] ? args.slice(1).join(' ').toLowerCase() : null
      let outcome = null
      let lvlMsgs = []
      let rankChange = null
      let unlockedNow = []

      await updatePlayer(ctx.db, ctx.from, player => {
        unlockedNow = refreshAchievements(player)
        const season = getActiveSeason(ctx.db)
        outcome = claimAchievements(player, id, { allowSeasonPoints: !!season, seasonId: season?.id })
        // Achievement XP can push a level, same as quest.js: settle it here so
        // the player sees the level in the same breath as the claim.
        if (!outcome.nothing) {
          const res = applyLevelUps(player, levelsData, classes, races, getTotalStats)
          lvlMsgs = res.msgs ?? []
          rankChange = res.rankChange ?? null
        }
        return player
      })

      if (outcome.nothing && outcome.deferred.length) {
        return reply(`🌙 Your Season Point achievement reward is saved. Claim it when a season is active.`)
      }
      if (outcome.nothing) {
        const hint = unlockedNow.length
          ? `\n\n_You just unlocked *${unlockedNow[0].name}*. Claim it with *${p()}ach claim*._`
          : `\n\n_Finish an achievement first, then come back. See the board with *${p()}ach*._`
        return reply(`🏆 *Nothing to claim yet.*${hint}`)
      }

      const deferredNote = outcome.deferred.length
        ? `\n\n🌙 ${outcome.deferred.length} Season Point reward${outcome.deferred.length === 1 ? ' is' : 's are'} saved until a season is active.`
        : ''
      await reply(renderClaims(outcome.claimed, lvlMsgs) + deferredNote)
      if (rankChange) {
        await sendRankUp(ctx, ctx.player?.name ?? 'Hunter', rankChange.from, rankChange.to)
      }
      return
    }

    // ── Emblem equip path ──────────────────────────────────────────────────
    if (sub === 'emblem' || sub === 'crest') {
      const raw = (args[1] ?? '').trim().toLowerCase()
      if (!raw) {
        const cur = ctx.player?.equippedEmblem ?? 'auto (latest claimed badge)'
        return reply(`🛡️ *Profile Crest:* *${cur}*\n\nEquip any of the 80 Astral crests with *${p()}ach emblem <1-80>* or reset with *${p()}ach emblem clear*.`)
      }
      if (raw === 'clear' || raw === 'reset' || raw === 'off') {
        await updatePlayer(ctx.db, ctx.from, player => { player.equippedEmblem = null; return player })
        return reply(`🛡️ Profile crest reset to automatic achievement/guild emblem.`)
      }
      const num = parseInt(raw.replace(/^emblem_?/, ''), 10)
      if (!Number.isInteger(num) || num < 1 || num > 80) {
        return reply(`⚠️ Choose an emblem number from *1* to *80* (e.g. *${p()}ach emblem 12*).`)
      }
      const emblemId = `emblem_${String(num).padStart(2, '0')}`
      await updatePlayer(ctx.db, ctx.from, player => { player.equippedEmblem = emblemId; return player })
      const url = `${config.publicApiUrl}/assets/badges/${emblemId}.png`
      return sendImage(ctx, url, `🛡️ Equipped *Astral Crest #${num}* on your profile card!`)
    }

    // ── Info path ──────────────────────────────────────────────────────────
    if (sub === 'info' || sub === 'show' || sub === 'view') {
      const query = args.slice(1).join(' ')
      const def = findAchievement(query)
      if (!def) {
        return reply(
          `⚠️ No achievement matches *${query || '(empty)'}*.\n\n` +
          `_Browse the board with *${p()}ach*._`,
        )
      }
      let text = null
      await updatePlayer(ctx.db, ctx.from, player => {
        refreshAchievements(player)
        text = renderInfo(player, def)
        return player
      })
      if (def.emblem) {
        const url = `${config.publicApiUrl}/assets/badges/${def.emblem}.png`
        return sendImage(ctx, url, text)
      }
      return reply(text)
    }

    // ── List path (default) ────────────────────────────────────────────────
    // Sub can be a track name (.ach combat) or absent. Any other single word
    // that is not a track falls through to the full board rather than an
    // error: the board is always a good answer.
    const track = trackQuery(sub)
    let text = null
    let unlockedNow = []
    await updatePlayer(ctx.db, ctx.from, player => {
      unlockedNow = refreshAchievements(player)
      text = renderBoard(player, track)
      return player
    })
    if (unlockedNow.length) {
      const names = unlockedNow.map(d => `${tierEmoji(d.tier)} *${d.name}*`).join(', ')
      text = `🏆 *Achievement unlocked:* ${names}\n\n${text}`
    }
    return reply(text)
  },
}
