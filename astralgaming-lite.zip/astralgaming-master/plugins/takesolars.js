/**
 * takesolars.js — .takesolars <amount|all> [@mention | reply | phone | name]
 * Owner-only command to remove Solars from a player (supports 24m, 500k, all).
 */
import { isOwnerJid } from '../lib/group-helpers.js'
import { takeSolars } from './admin.js'

export default {
  name: 'takesolars',
  aliases: ['takesolar', 'takesoalrs', 'removesolars', 'removesolar', 'tsolar'],
  category: 'admin',
  requiresPlayer: false,
  description: 'Owner-only: remove Solars from a player (e.g. .takesolars 24m)',

  async run(ctx) {
    if (!ctx.from || !isOwnerJid(ctx.from)) {
      return ctx.reply('❌ This command is restricted to the bot owner.')
    }
    return takeSolars({ ...ctx, args: [null, ...ctx.args] })
  },
}
