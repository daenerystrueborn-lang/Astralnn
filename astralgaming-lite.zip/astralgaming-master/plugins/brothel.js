/**
 * brothel.js — The Lantern House on Lantern Alley, and the three who work it.
 *
 *   <prefix>brothel                 the house card: who is here, who is free,
 *                                   and what a buy-out costs
 *   <prefix>brothel <name>          her card (art, disposition, price)
 *   <prefix>brothel take <name>     buy her out into the mansion's harem
 *
 * The house has three residents, and a harem of three is the mansion's ceiling
 * (lib/mansion.js's HAREM_SIZE), so a player who owns no mansion is told to buy
 * the deed first, and a player whose harem is full is told so before any Solars
 * move.
 *
 * ONE OWNER, BOT-WIDE. Cin, Noelle and Kaspavor are individuals, not stock: a
 * buy-out takes her off the floor for everyone, permanently, and the card says
 * whose house she went to (lib/household.js's register). That is the same rule
 * the two butlers are held to, and the same reason servants are exempt.
 *
 * The purchase itself is lib/household.js's purchaseWaifuFor(): one writer for
 * both doors, this one and `.mansion harem <name>`.
 *
 * Walking the street: the house is a real spot on Astral Town's Lantern Alley
 * (data/town.json), so `.town brothel` and `.talk cin` reach the same three
 * people without this command existing at all. This plugin is the shop front;
 * the street is the scenery.
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { sendImage } from '../lib/image.js'
import {
  WAIFUS,
  HAREM_SIZE,
  MANSION_DEED_GEMS,
  waifuByWord,
  ensureMansion,
  ownsMansion,
  haremMembers,
} from '../lib/mansion.js'
import { purchaseWaifuFor, workerOwner, holderName } from '../lib/household.js'
import { fmtGems } from '../lib/format.js'

const RULE = '━━━━━━━━━━━━━━━━━━━━'
const solars = (n) => Math.max(0, Math.round(Number(n) || 0)).toLocaleString()

const DOOR_LINES = [
  'The doorman takes your coat without asking and mentions, warmly, that the house remembers faces.',
  'Red glass throws the whole alley red. Somewhere inside, someone is laughing at something they have not been told.',
  'A girl on the stair counts coins into a dish and does not look up until the last one lands.',
  'It smells of wine, lamp oil, and money.',
]

function houseCard(db, player, p) {
  const m = ensureMansion(player)
  const owned = ownsMansion(player)
  const harem = owned ? haremMembers(player) : []
  const rows = WAIFUS.map(w => {
    const inHarem = m?.harem?.includes(w.id)
    const owner = inHarem ? null : workerOwner(db, 'waifu', w.id)
    const label = inHarem
      ? '🖤 *in your harem*'
      : owner
        ? `🔒 _taken by *${holderName(db, owner) ?? 'another house'}*_`
        : `💵 buy-out *${solars(w.price)} Solars*`
    return `  • *${w.name}* _(${w.title})_\n     ${label}  ·  *${p}brothel ${w.id}*`
  }).join('\n')

  return (
    `🏮 *THE LANTERN HOUSE*  ·  _Lantern Alley_\n${RULE}\n` +
    `_${DOOR_LINES[Math.floor(Date.now() / 3600000) % DOOR_LINES.length]}_\n\n` +
    `${rows}\n\n` +
    `*The house*\n` +
    (owned
      ? `  🏛️ Harem: *${harem.length}/${HAREM_SIZE}*` +
        (harem.length ? ` _(${harem.map(w => w.name).join(', ')})_` : '') + `\n`
      : `  🏛️ _A harem needs a house. Buy the deed on Marble Row first: *${p}mansion buy*._\n`) +
    `  🚶 _Or walk it in person: *${p}town brothel*, then *${p}talk cin*._\n\n` +
    `*${p}brothel take <name>* to buy her out.\n` +
    `_Whoever you take keeps her own room in the mansion and her own name on the door, ` +
    `and no other house in the kingdom can have her._`
  )
}

function waifuCard(w, db, player, p) {
  const m = ensureMansion(player)
  const inHarem = m?.harem?.includes(w.id)
  const owner = inHarem ? null : workerOwner(db, 'waifu', w.id)
  const full = m && m.harem.length >= HAREM_SIZE
  return (
    `🏮 *${w.name.toUpperCase()}*  ·  _${w.title}_\n${RULE}\n` +
    `_${w.line}_\n\n` +
    `🖼️ ${w.image}\n\n` +
    `💵 Buy-out: *${solars(w.price)} Solars*\n` +
    `🖤 ${inHarem
      ? '*She is already in your harem.*'
      : owner
        ? `_She lives in *${holderName(db, owner) ?? 'another house'}* now._`
        : full
          ? `_Your harem is full (${HAREM_SIZE})._`
          : `*${p}brothel take ${w.id}*`}`
  )
}

export default {
  name: 'brothel',
  aliases: ['lanternhouse', 'lantern-house', 'redlantern'],
  category: 'town',
  requiresPlayer: true,
  description: 'The Lantern House in Astral Town: meet Cin, Noelle and Kaspavor, and buy one into your harem',
  subcommands: [
    { cmd: '<name>', desc: 'her card: art, disposition, buy-out price' },
    { cmd: 'take <name>', desc: 'buy her out into your mansion harem. Only one player bot-wide can hold each' },
  ],

  async run(ctx) {
    const p = config.prefix
    if (!ctx.player) return ctx.reply(`⚠️ Register first with *${p}register*.`)

    const args = [...ctx.args]
    const first = (args[0] ?? '').toLowerCase()

    // ── take <name> ───────────────────────────────────────────────────────
    if (first === 'take' || first === 'buy' || first === 'recruit') {
      const word = args.slice(1).join(' ').trim()
      if (!word) {
        return ctx.reply(
          `🏮 *Who?*\n` +
          WAIFUS.map(w => `  • *${w.name}* · *${p}brothel take ${w.id}*`).join('\n'),
        )
      }
      return runTake(ctx, p, word)
    }

    // ── her card ──────────────────────────────────────────────────────────
    if (first) {
      const w = waifuByWord(args.join(' '))
      if (!w) {
        return ctx.reply(
          `🏮 *Nobody by that name works here.*\n` +
          WAIFUS.map(x => `  • *${x.name}* _(${x.title})_`).join('\n') +
          `\n_*${p}brothel* for the house card._`,
        )
      }
      const text = waifuCard(w, ctx.db, ctx.player, p)
      try {
        return await sendImage(ctx, w.image, text)
      } catch {
        return ctx.reply(text)
      }
    }

    // ── the house ─────────────────────────────────────────────────────────
    return ctx.reply(houseCard(ctx.db, ctx.player, p))
  },
}

async function runTake(ctx, p, word) {
  let out = null
  await updatePlayer(ctx.db, ctx.from, (player) => {
    out = purchaseWaifuFor(ctx.db, ctx.from, player, word)
  })

  if (out?.reason === 'unknown') {
    return ctx.reply(`🏮 _Nobody by that name is in the house._\n_${WAIFUS.map(w => w.name).join(', ')}_`)
  }
  if (out?.reason === 'no-mansion') {
    return ctx.reply(
      `🏮 *The madam smiles and closes the ledger.*\n${RULE}\n` +
      `_She goes where you keep her, and you keep nothing._\n\n` +
      `🏛️ Buy the Marble Row deed first: *${p}mansion buy* _(*${fmtGems(MANSION_DEED_GEMS)} Gems*)_`,
    )
  }
  if (out?.reason === 'already') {
    return ctx.reply(`🏮 _${out.waifu.name} already has a room in your house._`)
  }
  if (out?.reason === 'full') {
    return ctx.reply(`🏮 _Your harem is already *${HAREM_SIZE}*. Nobody else fits upstairs._`)
  }
  if (out?.reason === 'claimed') {
    const who = holderName(ctx.db, out.owner)
    return ctx.reply(
      `🏮 *The madam shakes her head.*\n${RULE}\n` +
      `_${out.waifu.name} was bought out. She lives in ${who ? `*${who}*'s` : "another player's"} house now._\n` +
      `_She does not come back to the floor, and no Solars of yours were spent._`,
    )
  }
  if (out?.reason === 'poor') {
    return ctx.reply(
      `🏮 *The madam does not move on price.*\n${RULE}\n` +
      `💵 Buy-out for *${out.waifu.name}*: *${solars(out.price)} Solars*\n` +
      `💰 You carry: *${solars(out.purse)} Solars*\n\n` +
      `_Short by *${solars(out.price - out.purse)}*._`,
    )
  }

  return ctx.reply(
    `🏮 *${out.waifu.name.toUpperCase()} IS BOUGHT OUT*\n${RULE}\n` +
    `_${out.waifu.line}_\n` +
    `_The madam signs the paper, stamps it, and says the door is always open to her, which everyone understands is a lie._\n\n` +
    `💵 Paid: *${solars(out.price)} Solars*\n` +
    `💰 Left: *${solars(out.purse)} Solars*\n` +
    `🏛️ _She is upstairs at Marble Row now. *${p}mansion harem* to see the house._`,
  )
}
