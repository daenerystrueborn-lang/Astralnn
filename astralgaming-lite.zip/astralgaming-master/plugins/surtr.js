/**
 * surtr.js — Surtr, the Molten Colossus. Her one combat ability.
 *
 * Four Arknights skills, one command, one turn shape. The owner's brief: "all
 * surtr skills are listed as her ability in battle and all work in pvp, boss
 * battle dungeon and all, like Circe." So this is built on Circe's model rather
 * than as four top-level commands — `.surtr` with no argument prints the menu
 * (all four skills, what is left, what is armed), and `.surtr <skill>` spends
 * the turn on one of them.
 *
 *   🔥 Laevatain      free, every turn — her sword's burning edge. A killing
 *                     blow stokes the next one (2.4x, and it cannot miss).
 *   🗡️ Molten Giant   once per battle — strikes everything in front of her,
 *                     then stands for 3 turns (+25% damage, +1 target).
 *   ☄️ Surtr's Flame  once per battle — heavy fire, reaches through a quarter
 *                     of their DEF, leaves them burning.
 *   🌋 Twilight       once per battle at 50% HP or lower — the signature. Max
 *                     HP and ATK climb, it never expires, and it costs her HP
 *                     every turn until Remnant Ash ends it.
 *   🕯️ Remnant Ash    free — ends Twilight and hands back what it took.
 *
 * 📖 Bladework Memory is passive and never appears as a turn: every kill with
 * her equipped credits extra weapon mastery (lib/weapon-mastery.js), which is
 * the conversion of the Training-Room specialisation this game has no room for.
 *
 * ROUTES, in the order tried — the same order every signature move in the bot
 * uses, because each mode owns its own turn engine:
 *   League fixture   playLeagueMove()      -> runPvpTurn('surtr')
 *   Duel             plugins/pvp.js        -> pvpSurtr()
 *   Party fight      plugins/surtr.js      -> battleSurtr() (members carry no battleState)
 *   Swarm floor      resolveSwarmAbility() -> one swarm turn at the nearest threat
 *   1v1 dungeon/boss the turn below
 *
 * All the numbers, the gates and the state live in lib/surtr.js. This file only
 * plays the turn.
 *
 * Usage: <prefix>surtr [laevatain|giant|flame|twilight|ash]
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { sendBattleTurnReply } from '../lib/battle-frame-render.mjs'
import {
  calcPlayerDamage, applyDefense, calcPlayerHitChance,
  calcMonsterHitChance, calcMonsterDamage, hpBar,
} from '../lib/combat-engine.js'
import {
  handleVictory,
  processStatusTurn,
  resolvePlayerHpZero,
  checkCatFormOngoingTurn,
  resolveCatFormDefeat,
} from '../lib/combat-handlers.js'
import { getEffectiveStat, hasEffect, addStatusEffect } from '../lib/effects.js'
import {
  applyBossSpecial, checkBossPhase, buildEnemyAttack,
  getBossTaunt, getBossHitLine, getBossDodgeLine,
  incrementBossTurn, cleanupBossFight, EVENT,
} from '../lib/boss-engine.js'
import {
  applyTearOnHit,
  sendWillowAdvisory,
  tickPermanentSever,
  applyIncomingDamage,
} from '../lib/character-abilities.js'
import {
  hasSurtr,
  surtrSkillByCommand,
  buildSurtrMenu,
  surtrStatusLine,
  laevatainStoked,
  laevatainMultiplier,
  noteLaevatainHit,
  activateMoltenGiant,
  activateSurtrFlame,
  activateTwilight,
  endTwilight,
  twilightActive,
  SURTR_FLAME_BURN_TURNS,
  SURTR_FLAME_BURN_FRACTION,
  SURTR_CHARACTER_ID,
  MOLTEN_GIANT_MULT,
  MOLTEN_GIANT_OUTGOING,
  TWILIGHT_OUTGOING,
} from '../lib/surtr.js'
import { pvpSurtr } from './pvp.js'
import { battleSurtr, findPartyForPlayer } from './party.js'
import { playLeagueMove } from './league-battle.js'
import { resolveSwarmAbility } from '../lib/swarm-combat.js'
import { heroesAnswerHit, heroesTurnBoundary } from '../lib/witch-heroes-pve.js'
import { graceHoldsEnemyTurn, graceEnemyHeldLine } from '../lib/king-yato.js'

function isBossFight(player) {
  return !!(player.battleState?.enemy?.isBoss && player.battleState?.bossState)
}

/** Stunned, frozen or asleep: the three states that cost a player their turn. */
function isHeld(player) {
  return hasEffect(player, 'stun') || hasEffect(player, 'freeze') || hasEffect(player, 'sleep')
}

const RULE = '────────────────'

/** One line under a skill's name — its flavor, italicised, one stanza. */
function skillOpening(skill, enemyName) {
  return (
    `${skill.emoji} *${skill.name.toUpperCase()}* — _on *${enemyName}*_\n` +
    `📖 _${skill.flavor}_`
  )
}

/**
 * The Burn Surtr's Flame leaves. It goes through addStatusEffect() like every
 * other status in the game, so a Sanctum, a void or a status-immune target
 * refuses it exactly as they refuse any other debuff — her fire is strong, not
 * exempt from the rules every other ability follows.
 */
function applyFlameBurn(player, enemy) {
  const amount = Math.max(1, Math.floor((Number(enemy.maxHp) || 0) * SURTR_FLAME_BURN_FRACTION))
  const res = addStatusEffect(enemy, {
    type: 'burn',
    amount,
    duration: SURTR_FLAME_BURN_TURNS,
    sourceId: 'surtr_flame',
  })
  if (res?.immune || res?.blocked) return ''
  return `🔥 _Burning for *${SURTR_FLAME_BURN_TURNS}* turns — *${amount}* a turn._\n`
}

export default {
  name: 'surtr',
  aliases: ['molten', 'colossus', 'laevatain'],
  category: 'combat',
  requiresPlayer: true,
  description: `${config.prefix}surtr — Surtr's four skills: Laevatain, Molten Giant, Surtr's Flame, Twilight (+ Remnant Ash)`,

  async run(ctx) {
    const p = config.prefix
    const skill = surtrSkillByCommand(ctx.args[0])

    // ── Astral League fixture ─────────────────────────────────────────
    // A fixture plays this through the League path: the same runPvpTurn()
    // action the duel handoff below uses, plus the turn limit and the table.
    // BEFORE the duel handoff and before updatePlayer(): playLeagueMove() sends
    // and writes, and neither is safe inside a mutator.
    if (skill && await playLeagueMove(ctx, 'surtr', skill.id)) return

    // Duels run their own two-player engine (no bs.enemy).
    if (ctx.player?.battleState?.type === 'pvp') {
      return pvpSurtr(ctx, skill?.id ?? null)
    }

    // A party fight: members carry no battleState of their own, so the move is
    // gated and resolved on the party's per-member state.
    if (ctx.player?.inBattle && !ctx.player.battleState && findPartyForPlayer(ctx.db, ctx.from)?.battle) {
      if (!skill) return ctx.reply(buildSurtrMenu(ctx.player, p, null))
      return battleSurtr(ctx, skill.id)
    }

    // The menu is a readout, not a turn: it never spends anything and works
    // outside a fight too (that is how a player learns what she has).
    if (!skill) {
      const player = ctx.player
      if (!hasSurtr(player)) {
        return ctx.reply(
          `🌋 *Surtr* is not on your slot.\n` +
          `_Equip her with_ *${p}character equip ${SURTR_CHARACTER_ID}*\n\n` +
          `_That is one of her four skills on the card — the rest are read in battle._`,
        )
      }
      return ctx.reply(buildSurtrMenu(player, p))
    }

    let outcome = null

    await updatePlayer(ctx.db, ctx.from, async player => {
      const catTurn = await checkCatFormOngoingTurn(player, ctx, {
        boss: isBossFight(player),
      })
      if (catTurn.intercepted) return catTurn.returnValue

      // ── Cheap up-front gates ──────────────────────────────────────────
      // Checked BEFORE the status ticks below, and deliberately without burning
      // a charge: a turn where start-of-turn poison kills you must not also eat
      // her one Twilight.
      if (!hasSurtr(player)) {
        outcome = {
          reply:
            `🌋 *Surtr* is not on your slot.\n` +
            `_Equip her with_ *${p}character equip ${SURTR_CHARACTER_ID}*`,
        }
        return player
      }
      if (!player.inBattle || !player.battleState) {
        outcome = { reply: `❌ *Not in battle.* Use *${p}dungeon* to find an enemy.` }
        return player
      }
      if (!player.battleState.enemy) {
        outcome = { reply: `⚠️ *No enemy found in your battle state.* _Use *${p}cb* to clear it and try again._` }
        return player
      }
      if (isHeld(player)) {
        outcome = {
          reply:
            `💫 *You are held this turn.*\n` +
            `_Nothing was spent — the skill is still yours._ _Take the turn with *${p}attack* or *${p}defend*._`,
        }
        return player
      }

      // ── The gates that burn a charge ─────────────────────────────────
      // Every one of these refuses without spending the turn, the same contract
      // Cinder Verdict and Blaze Heart keep.
      let gate = { ok: true }
      if (skill.id === 'molten_giant') gate = activateMoltenGiant(player)
      else if (skill.id === 'surtrs_flame') gate = activateSurtrFlame(player)
      else if (skill.id === 'twilight') gate = activateTwilight(player)
      else if (skill.id === 'remnant_ash') {
        if (!twilightActive(player)) {
          gate = {
            ok: false,
            message:
              `🕯️ *Remnant Ash* has nothing to put out.\n` +
              `_It ends Twilight, and Twilight is not running._`,
          }
        } else {
          const end = endTwilight(player, player.battleState, { heal: true })
          gate = {
            ok: true,
            ash: end,
          }
        }
      }
      if (!gate.ok) {
        outcome = { reply: gate.message }
        return player
      }

      // ── Swarm floors ─────────────────────────────────────────────────
      // Fold the move into ONE swarm turn against the nearest threat, the same
      // shape blaze-heart.js / kurama.js use. Without this branch the 1v1 turn
      // below ran against bs.enemy and a kill called handleVictory while other
      // monsters were still alive. The charge was already burned by the gate,
      // so it is paid once either way; Remnant Ash and Twilight are self-only
      // and never reach a target, so they still land here priced once.
      if (player.battleState?.mode === 'swarm') {
        const swarmBs = player.battleState
        let thrown = false
        const settled = await resolveSwarmAbility(player, ctx, (target) => {
          thrown = true
          if (skill.id === 'twilight') {
            return {
              lines: [
                `🌋 *TWILIGHT — THE COLOSSUS STOPS PRETENDING*`,
                `_Max HP *${gate.beforeMax} → ${gate.grownMax}*, ATK +*${gate.atkGain}*. It does not expire, and it costs her HP every turn._`,
              ],
              damage: 0,
              source: 'surtr_twilight',
            }
          }
          if (skill.id === 'remnant_ash') {
            return {
              lines: [
                `🕯️ *REMNANT ASH*`,
                `_The fires fold back down. *+${gate.ash.healed}* HP restored (${gate.ash.hp}/${gate.ash.maxHp})._`,
              ],
              damage: 0,
              source: 'surtr_remnant_ash',
            }
          }
          // The hits. Same stock pipeline as the 1v1 turn: DEF applies, and
          // Surtr's Flame reaches through a quarter of it.
          const mult = skill.id === 'laevatain' ? laevatainMultiplier(player, swarmBs)
            : skill.id === 'molten_giant' ? MOLTEN_GIANT_MULT
              : gate.multiplier
          const targetDef = getEffectiveStat(target, 'def')
          const effectiveDef = skill.id === 'surtrs_flame'
            ? Math.max(0, targetDef * (1 - gate.defPierce))
            : targetDef
          const { rawDmg, isCrit } = calcPlayerDamage(player, null, mult, 0, { battleState: swarmBs })
          let dmg = applyDefense(rawDmg, effectiveDef, player, target, swarmBs)
          target.hp = Math.max(0, target.hp - dmg)
          const lines = [skillOpening(skill, target.name), '']
          if (skill.id === 'molten_giant') {
            lines.unshift(`🗡️ *MOLTEN GIANT* — _it stands for *${gate.turns}* turns._`)
          }
          lines.push(`🩸 *${dmg.toLocaleString('en-US')}* damage!${isCrit ? ' 💥 *CRITICAL!*' : ''}`)
          if (skill.id === 'surtrs_flame' && target.hp > 0) {
            const burn = applyFlameBurn(player, target)
            if (burn) lines.push(burn.trimEnd())
          }
          if (skill.id === 'laevatain') {
            const stoked = noteLaevatainHit(swarmBs, { killed: target.hp <= 0 })
            if (stoked.stoked) lines.push('🔥 *The fires are stoked.* _The next Laevatain lands for more, and it does not miss._')
          }
          return { lines, damage: dmg, source: 'surtr' }
        })
        // Backstop: the swarm engine skips the owner's action when they turn
        // out to be unable to act (nothing left to reach, a hold the check
        // above could not see). A charge burned for a move that was never
        // thrown is handed straight back on the same record.
        if (!thrown && swarmBs.surtr) {
          if (skill.id === 'molten_giant') swarmBs.surtr.moltenGiantUsed = false
          else if (skill.id === 'surtrs_flame') swarmBs.surtr.surtrFlameUsed = false
          else if (skill.id === 'twilight') swarmBs.surtr.twilightUsed = false
        }
        return settled
      }

      const bs = player.battleState
      const e = bs.enemy
      const boss = isBossFight(player)
      const hpBeforeTurn  = player.hp
      const eHpBeforeTurn = e.hp

      bs.playerDefending = false
      let msg = ''

      // Urahara's permanent Tear — action-triggered tick, same as every other
      // combat entry point.
      const permaSeverLine = tickPermanentSever(player)
      if (permaSeverLine) msg += permaSeverLine + '\n'
      if (player.hp <= 0) {
        const res = await resolvePlayerHpZero(player, ctx, msg, { boss })
        if (!res.fallThrough) return res.returnValue
        msg = res.msg
      }

      if (boss) {
        incrementBossTurn(player)
        const tsResult = applyBossSpecial(player, EVENT.TURN_START, {})
        if (tsResult.narrativeLine) msg += `_${tsResult.narrativeLine}_\n`
      }

      const playerStatus = processStatusTurn(player)
      if (playerStatus.incapacitated && player.battleState?.enemy?.tower) player.battleState.towerTacticIncapacitatedTurn = player.battleState.turn ?? 1
      if (!playerStatus.incapacitated && player.hp > 0 && player.battleState?.bossState?._def?.orv) applyBossSpecial(player, EVENT.PLAYER_ABILITY, {})
      if (playerStatus.lines.length) msg += playerStatus.lines.join('\n') + '\n'
      if (player.hp <= 0) {
        const res = await resolvePlayerHpZero(player, ctx, msg, { boss })
        if (!res.fallThrough) return res.returnValue
        msg = res.msg
      }

      if (playerStatus.incapacitated) {
        outcome = {
          reply:
            msg +
            `💫 *${player.name}* is unable to act this turn!\n` +
            `\n\n👤 *${player.name}*\n❤️ ${hpBar(player.hp, player.maxHp)}  💧 ${player.mp}/${player.maxMp} MP\n` +
            `${e.emoji ?? '👾'} *${e.name}*\n❤️ ${hpBar(e.hp, e.maxHp)}\n\n` +
            `*${p}attack* · *${p}skill <name>* · *${p}defend* · *${p}flee*`,
        }
        return player
      }

      // ── 🕯️ Remnant Ash — the exit ─────────────────────────────────────
      // No damage, no roll: she simply stops. It is still her turn (the enemy
      // answers, as it does after a defend), because ending the transformation
      // is a decision the fight gets to punish.
      if (skill.id === 'remnant_ash') {
        msg +=
          `🕯️ *REMNANT ASH*\n${RULE}\n` +
          `_The fires fold back down into the sword. Whatever they were eating out of her is handed back._\n\n` +
          `💚 *+${gate.ash.healed}* HP restored _(now ${gate.ash.hp}/${gate.ash.maxHp})_\n` +
          `_Her maximum HP is hers again._\n`
      }

      // ── 🌋 Twilight — the signature ───────────────────────────────────
      if (skill.id === 'twilight') {
        msg +=
          `🌋 *TWILIGHT — THE COLOSSUS STOPS PRETENDING* 🌋\n${RULE}\n` +
          `_She gets taller. The fires get louder._\n\n` +
          `❤️ Max HP *${gate.beforeMax} → ${gate.grownMax}* _(${gate.hp} now)_\n` +
          `⚔️ +*${gate.atkGain}* ${gate.atkKey.toUpperCase()}\n` +
          `🔥 *+${Math.round((TWILIGHT_OUTGOING - 1) * 100)}%* damage · *+1* target\n` +
          `⏳ *No duration.* _It ends when she ends it, or when she does._\n` +
          `🩸 _It costs her *${Math.round(gate.tickFraction * 100)}%* of her max HP every turn._\n\n` +
          `_End it yourself with *${p}surtr ash*._\n`
      }

      // ── 🗡️ Molten Giant — the summon ──────────────────────────────────
      if (skill.id === 'molten_giant') {
        msg +=
          `🗡️ *MOLTEN GIANT* 🗡️\n${RULE}\n` +
          `_The floor splits, and something the size of a house climbs out of it, already on fire._\n\n` +
          `_It swings once for her, then stands beside her for *${gate.turns}* turns — *+${Math.round((MOLTEN_GIANT_OUTGOING - 1) * 100)}%* damage and one more target while it does._\n\n`
      }

      // ── Damage skills (Laevatain, Molten Giant, Surtr's Flame) ────────
      const isDamageSkill = skill.id !== 'twilight' && skill.id !== 'remnant_ash'
      if (isDamageSkill) {
        msg += skillOpening(skill, e.name) + '\n\n'

        // Accuracy. Laevatain rolls it like any other strike unless it is the
        // stoked one (calcPlayerHitChance returns 1.0 then — the colossus has
        // already decided where the sword goes). Surtr's Flame and the Giant's
        // swing never roll: both charges are burned in the gate above, so a
        // whiff would read as the command being broken.
        const needsRoll = skill.id === 'laevatain' && !laevatainStoked(player)
        const hits = needsRoll ? Math.random() <= calcPlayerHitChance(player, e) : true

        if (!hits) {
          msg += `💨 The edge goes wide — *MISSED!*\n`
          if (boss) {
            const missResult = applyBossSpecial(player, EVENT.PLAYER_MISS, { isMiss: true })
            msg += `💬 _\"${getBossDodgeLine(player)}\"_\n`
            if (missResult.narrativeLine) msg += `_${missResult.narrativeLine}_\n`
          }
          if (skill.id === 'laevatain') noteLaevatainHit(bs, { killed: false })
        } else {
          // The multiplier each skill actually swings with.
          let mult = 1
          if (skill.id === 'laevatain') mult = laevatainMultiplier(player, bs)
          else if (skill.id === 'molten_giant') mult = MOLTEN_GIANT_MULT
          else if (skill.id === 'surtrs_flame') mult = gate.multiplier

          // Surtr's Flame reaches through a share of their DEF: the pierce is
          // expressed as a reduced defense, the same way a weapon's own
          // defenseIgnore is, rather than as a post-hoc subtraction — so the
          // armour-break and doctrine stages downstream still run normally.
          const targetDef = getEffectiveStat(e, 'def')
          const effectiveDef = skill.id === 'surtrs_flame'
            ? Math.max(0, targetDef * (1 - gate.defPierce))
            : targetDef

          const { rawDmg, isCrit } = calcPlayerDamage(player, null, mult)
          let dmg = applyDefense(rawDmg, effectiveDef, player, e)
          if (boss) {
            const takeResult = applyBossSpecial(player, EVENT.ENEMY_TAKE_DAMAGE, {
              damage: dmg, element: 'fire', isCrit, isHit: true,
            })
            if (takeResult.damage !== undefined) dmg = takeResult.damage
            if (takeResult.reflectDamage) {
              const reflected = applyIncomingDamage(player, takeResult.reflectDamage)
              if (reflected.message) msg += reflected.message + '\n'
              if (reflected.catFormDefeated) return resolveCatFormDefeat(player, ctx, { boss })
              if (player.hp <= 0) {
                const resolved = await resolvePlayerHpZero(player, ctx, msg, { boss: true })
                if (!resolved.fallThrough) return resolved.returnValue
                msg = resolved.msg
              }
            }
            if (takeResult.narrativeLine) msg += `_${takeResult.narrativeLine}_\n`
            msg += `💬 _\"${getBossHitLine(player)}\"_\n`
          }
          e.hp = Math.max(0, e.hp - dmg)

          msg +=
            `🩸 *${dmg.toLocaleString('en-US')}* damage!${isCrit ? ' 💥 *CRITICAL!*' : ''}` +
            (skill.id === 'surtrs_flame' ? ` _(reaches through ${Math.round(gate.defPierce * 100)}% of their DEF)_` : '') + '\n'

          if (e.hp > 0) {
            if (skill.id === 'surtrs_flame') msg += applyFlameBurn(player, e)
            const tearLine = applyTearOnHit(player, e, ctx)
            if (tearLine) msg += tearLine + '\n'
          }



          // Laevatain's own rule: a killing blow stokes the next one.
          if (skill.id === 'laevatain') {
            const stoked = noteLaevatainHit(bs, { killed: e.hp <= 0 })
            if (stoked.stoked) {
              msg += `🔥 *The fires are stoked.* _The next Laevatain lands for more, and it does not miss._\n`
            }
          }

          if (e.hp <= 0) {
            if (boss) cleanupBossFight(player)
            await ctx.reply(msg)
            return handleVictory(player, e, ctx)
          }

          if (boss) {
            const phase = checkBossPhase(player)
            if (phase?.triggered && phase.lines?.length) {
              msg += `\n⚡ *— PHASE SHIFT —*\n` + phase.lines.map(l => `_${l}_`).join('\n') + '\n'
            }
          }
        }
      }

      // ── Enemy's turn ──────────────────────────────────────────────────
      const enemyStatus = processStatusTurn(e, { bossState: player.battleState?.bossState })
      if (enemyStatus.lines.length) msg += enemyStatus.lines.join('\n') + '\n'
      if (e.hp <= 0) {
        if (boss) cleanupBossFight(player)
        await ctx.reply(msg)
        return handleVictory(player, e, ctx)
      }

      // 👑 King Yato — Grace of the Crown: turns 1-5 the enemy does not act at all.
      if (graceHoldsEnemyTurn(player)) {
        msg += `\n${graceEnemyHeldLine(e, player)}\n`
      } else if (enemyStatus.incapacitated) {
        msg += `💫 *${e.name}* is unable to attack this turn!\n`
      } else if (boss) {
        const bossAtk    = buildEnemyAttack(player)
        const dealResult = applyBossSpecial(player, EVENT.ENEMY_DEAL_DAMAGE, { damage: bossAtk.damage, isHit: true })
        const rawBossAtk = (dealResult.modified && dealResult.damage !== undefined) ? dealResult.damage : bossAtk.damage
        const incoming   = bossAtk.bypassDefense
          ? rawBossAtk
          : calcMonsterDamage(rawBossAtk, getEffectiveStat(player, 'def'), false)
        // Twilight's guard, Circe's cards and every other interceptor resolve
        // inside applyIncomingDamage().
        const witchHit = heroesAnswerHit({ player, enemy: e, ctx, msg: '', damage: incoming, directAttack: true, boss })
        if (witchHit.returnValue !== undefined) return witchHit.returnValue
        if (witchHit.lines.length) msg += witchHit.lines.map(l => l + '\n').join('')
        const applied = applyIncomingDamage(player, witchHit.damage)
        msg += `\n${e.emoji ?? '👾'} *${e.name}* uses *${bossAtk.attackName}*!\n`
        if (applied.message) msg += applied.message + '\n'
        if (applied.damage > 0) {
          if (!witchHit.turned) msg += `🩸 *${applied.damage}* damage!${bossAtk.bypassDefense ? ' _(bypasses DEF)_' : ''}\n`
        }
        if (dealResult.narrativeLine) msg += `_${dealResult.narrativeLine}_\n`
        msg += `\n💬 _\"${getBossTaunt(player)}\"_\n`
        if (applied.catFormDefeated) {
          return resolveCatFormDefeat(player, ctx, { boss: true })
        }
        if (player.hp <= 0) {
          const res = await resolvePlayerHpZero(player, ctx, msg, { boss: true })
          if (!res.fallThrough) return res.returnValue
          msg = res.msg
        }
      } else if (Math.random() > calcMonsterHitChance(e, player)) {
        msg += `\n${e.emoji ?? '👾'} *${e.name}* retaliates... and *MISSES!*`
      } else {
        const enemyDmg = calcMonsterDamage(e.atk, getEffectiveStat(player, 'def'), false)
        const witchHit = heroesAnswerHit({ player, enemy: e, ctx, msg: '', damage: enemyDmg, directAttack: true, boss })
        if (witchHit.returnValue !== undefined) return witchHit.returnValue
        if (witchHit.lines.length) msg += witchHit.lines.map(l => l + '\n').join('')
        const applied = applyIncomingDamage(player, witchHit.damage)
        msg += `\n${e.emoji ?? '👾'} *${e.name}* retaliates!\n`
        if (applied.message) msg += applied.message + '\n'
        if (applied.damage > 0) msg += `🩸 *${applied.damage}* damage!`
        if (applied.catFormDefeated) {
          return resolveCatFormDefeat(player, ctx)
        }
        if (player.hp <= 0) {
          const res = await resolvePlayerHpZero(player, ctx, msg, {})
          if (!res.fallThrough) return res.returnValue
          msg = res.msg
        }
      }

      if (boss) {
        const teResult = applyBossSpecial(player, EVENT.TURN_END, {})
        if (teResult.narrativeLine) msg += `\n_${teResult.narrativeLine}_`
      }

      const status = surtrStatusLine(player, bs)
      msg += `\n\n👤 *${player.name}*\n❤️ ${hpBar(player.hp, player.maxHp)}  💧 ${player.mp}/${player.maxMp} MP\n` +
             `${e.emoji ?? '👾'} *${e.name}*\n❤️ ${hpBar(e.hp, e.maxHp)}` +
             (status ? `\n${status}` : '') +
             `\n\n*${p}surtr* · *${p}attack* · *${p}skill <name>* · *${p}defend* · *${p}flee*`

      // The shared completed-turn clock (lib/witch-heroes-pve.js): Ronova's
      // count, Maiden's charge, the countdown's narration and the settle for a
      // beam that ends it. A turn that skips this is a turn the kit never saw.
      const witchTurn = await heroesTurnBoundary({ player, enemy: e, ctx, msg, turnId: bs.turn ?? 1, boss })
      if (witchTurn.returnValue !== undefined) return await witchTurn.returnValue
      msg = witchTurn.msg
      bs.turn = (bs.turn ?? 1) + 1
      player.battleState = bs
      await sendWillowAdvisory(ctx, player, e, boss)
      outcome = { battleTurn: { bs, player, e, msg, hpBeforeTurn, eHpBeforeTurn, boss } }
      return player
    })

    if (outcome?.battleTurn) await sendBattleTurnReply(ctx, outcome.battleTurn)
    else if (outcome?.reply) await ctx.reply(outcome.reply)
  },
}
