/**
 * secttasks.js — `.tasks` and `.task` : the Mission Hall board.
 *
 *   .tasks                    today's board
 *   .task accept <number>     take one on
 *   .task complete            hand it in
 *   .task drop                put it back
 *   .task spar                call out the sparring partner
 *
 * A task pays contribution, Spirit Stones and the odd supply, and it teaches no
 * cultivation at all: the board says so. The rules are lib/sect-tasks.js.
 */
import { config } from '../config.js'
import { tasksCommand, settlePendingSectHook } from '../lib/sect-commands.js'
import '../lib/sect-hooks.js'
import { sectDoorRefusal } from '../lib/world-guards.js'

export default {
  name: 'tasks',
  aliases: ['task'],
  category: 'sect',
  requiresPlayer: true,
  description: `${config.prefix}tasks — the Mission Hall board; ${config.prefix}task accept|complete|drop|spar`,
  subcommands: [
    { cmd: 'accept <number>', desc: 'take a task off today\'s board' },
    { cmd: 'complete', desc: 'hand the work in and be paid' },
    { cmd: 'drop', desc: 'put it down unpaid' },
    { cmd: 'spar', desc: 'call out the sparring partner a spar task wants' },
  ],

  async run(ctx) {
    const wrongWorld = sectDoorRefusal(ctx.player, {
      emoji: '📜', title: '*The Mission Hall boards are up the mountain — in the Sect Empire.*',
      here: { cmd: 'quest', label: 'take Astra quests instead' },
    })
    if (wrongWorld) return ctx.reply(wrongWorld)
    const pending = await settlePendingSectHook(ctx)
    if (pending) return ctx.reply(pending.join('\n'))
    return tasksCommand(ctx)
  },
}
