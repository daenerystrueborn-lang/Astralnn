/**
 * <prefix>yelan-spin <amount>
 *
 * Yelan's global-exclusive spin. Structurally identical to
 * plugins/tyla-alya-spin.js: the same global lock through
 * getExclusiveSpinWinner()/claimExclusiveSpinForPlayer() in lib/season-engine.js,
 * the same batch reel and pity bar, the same "one player bot-wide" contract.
 *
 * ODDS (via chanceForExclusiveSpin):
 *   spins 1-269   -> 0%    DEAD_ZONE_UNTIL = 269, a true dead zone
 *   spin 270+     -> 80%   PLATEAU_CHANCE, flat per spin, sustained all the way
 *                          to the 300 cap. PITY_AT sits far past the cap so the
 *                          guaranteed-win branch never fires: spin 300 is the
 *                          same flat roll as spin 270.
 * 0.9 gems a spin, 300 spins lifetime, so the first live roll costs about 242.1
 * gems. NONE of those numbers are ever printed in player-facing copy — only the
 * pity bar is (the rule stated in tyla-alya-spin.js's header, kept here).
 *
 * EXCLUSIVE. The owner's open decision #2 is built as one of one, per the spec's
 * [DEFAULT]. Setting EXCLUSIVE = false switches to plugins/yato-spin.js's
 * behaviour — every player who clears the dead zone gets their own copy — and
 * nothing else in the file changes: the two lock calls are both behind the flag.
 */
import { config } from '../config.js'
import { characterStars } from '../lib/rarity.js'
import {
  getActiveSeason,
  ensurePlayerSeasonState,
  chanceForExclusiveSpin,
  getExclusiveSpinWinner,
  claimExclusiveSpinForPlayer,
  addOwnedSeasonContent,
} from '../lib/season-engine.js'
import { characterMap } from '../lib/game-data.js'
import { updatePlayer } from '../lib/player-repo.js'
import { roundGems, fmtGems } from '../lib/format.js'
import { spinLockGate } from '../lib/spin-locks.js'

const CHARACTER_ID = 'yelan'
const SPIN_FIELD = 'yelanSpins'
const COST_PER_SPIN = 0.9
const DEAD_ZONE_UNTIL = 269   // spins 1-269: 0%
const PLATEAU_CHANCE = 0.80   // spin 270+: flat 80%, sustained, no pity spike
const PITY_AT = 9999          // past the cap, so the guaranteed branch never fires
const MAX_SPINS_PER_PLAYER = 300
// 20 rather than the 5 the Solar spins use, the same call plugins/yato-spin.js
// documents: a 269-spin dead zone at 5 per command is 54 commands before a
// player's first live roll, which reads as a broken command. Still fits the reel.
const MAX_SPINS_PER_COMMAND = 20
/** ONE LINE. false switches this to yato-spin.js's "anyone can win it" behaviour. */
const EXCLUSIVE = true

const RULE = '━━━━━━━━━━━━━━━━━━━━'

const MISS_LINES = [
  'Something in the dark looks at you and decides you are not worth it.',
  'A shadow crosses the room. It was never going to be yours.',
  'You feel watched. Nobody is watching.',
  'The blade turns over once in the dark and goes still.',
  'A soft laugh, from nowhere, at your expense.',
  'She is exactly where you are not.',
]

function missLine(spin) {
  return `🖤 _${MISS_LINES[spin % MISS_LINES.length]}_`
}

/** Progress toward the spin cap. Never reveals the plateau. */
function pityBar(spin, width = 10) {
  const filled = Math.max(0, Math.min(width, Math.round((spin / MAX_SPINS_PER_PLAYER) * width)))
  return `${'▰'.repeat(filled)}${'▱'.repeat(width - filled)}`
}

function reel(results) {
  const MAX_ROWS = 5
  const marks = results.map(r => (r.won ? '✦' : '·'))
  const rows = []
  for (let i = 0; i < marks.length; i += 10) rows.push(marks.slice(i, i + 10).join(' '))
  if (rows.length <= MAX_ROWS) return rows.join('\n')
  return [`_…${(rows.length - MAX_ROWS) * 10} earlier spins_`, ...rows.slice(-MAX_ROWS)].join('\n')
}

async function replyOverArt(ctx, character, text) {
  if (!character?.image) return ctx.reply(text)
  try {
    const image = character.spinImage ?? character.image
    return ctx.replyImage(image, text)
  } catch {
    return ctx.reply(text)
  }
}

export default {
  name: 'yelan-spin',
  aliases: ['yelanspin', 'ye-spin', 'killer-spin'],
  category: 'character',
  requiresPlayer: true,
  description: 'Spin for Yelan — 0.9 Gems per spin, globally exclusive to one winner bot-wide',

  async run(ctx) {
    // Owner freeze (.lockspin / .unlockspin, lib/spin-locks.js). Checked before
    // anything is read or spent, so a locked banner costs nothing.
    if (spinLockGate(ctx, CHARACTER_ID)) return

    const p = config.prefix
    if (!ctx.player) return ctx.reply(`⚠️ Register first with *${p}register*.`)
    const character = characterMap[CHARACTER_ID]
    if (!character) return ctx.reply(`⚠️ Yelan isn't configured yet.`)

    if ((ctx.player.ownedCharacters ?? []).includes(CHARACTER_ID)) {
      return replyOverArt(ctx, character,
        `🖤 *${character.name} is already yours.*\n${RULE}\n` +
        `_Equip her with *${p}character equip ${CHARACTER_ID}*, then meet someone in a duel with a companion at their side._`)
    }

    const isFirstEverAttempt = (ctx.player[SPIN_FIELD] ?? 0) === 0
    const requested = Math.floor(Number(ctx.args[0]) || 1)
    const spinCount = Math.min(MAX_SPINS_PER_COMMAND, MAX_SPINS_PER_PLAYER, Math.max(1, requested))

    if (EXCLUSIVE) {
      const existingWinner = getExclusiveSpinWinner(ctx.db, CHARACTER_ID)
      if (existingWinner) {
        return replyOverArt(ctx, character, existingWinner === ctx.from
          ? `🖤 *${character.name} is already yours.*\n_Her blade, your name. No gems were spent._`
          : `🔒 *SHE ALREADY BELONGS TO SOMEONE.*\n${RULE}\n_${character.name} has been claimed by another player._\n\n_Only one player, bot-wide, could ever obtain her. No gems were spent._`)
      }
    }

    let outcome = null
    await updatePlayer(ctx.db, ctx.from, (player) => {
      player.ownedCharacters = player.ownedCharacters ?? []
      if (player.ownedCharacters.includes(CHARACTER_ID)) { outcome = { reason: 'owned' }; return }

      if (EXCLUSIVE) {
        // Re-checked inside the serialized mutator: this is the race-safe one.
        if (getExclusiveSpinWinner(ctx.db, CHARACTER_ID)) { outcome = { reason: 'claimed' }; return }
        const season = getActiveSeason(ctx.db)
        if (season) ensurePlayerSeasonState(player, season.id)
      }

      player.wallet = player.wallet ?? {}
      let gems = roundGems(player.wallet.gems ?? 0)
      const results = []
      let won = false
      let spinsUsed = 0

      for (let i = 0; i < spinCount; i++) {
        if (EXCLUSIVE && getExclusiveSpinWinner(ctx.db, CHARACTER_ID)) break
        if (gems < COST_PER_SPIN) break
        if ((player[SPIN_FIELD] ?? 0) >= MAX_SPINS_PER_PLAYER) break

        const nextSpin = (player[SPIN_FIELD] ?? 0) + 1
        const chance = chanceForExclusiveSpin(nextSpin, {
          deadZoneUntil: DEAD_ZONE_UNTIL, plateauChance: PLATEAU_CHANCE, pityAt: PITY_AT,
        })
        const thisWon = nextSpin >= PITY_AT || Math.random() < chance

        gems = roundGems(gems - COST_PER_SPIN)
        player.wallet.gems = gems
        player[SPIN_FIELD] = nextSpin
        spinsUsed++
        results.push({ spin: nextSpin, won: thisWon })

        if (thisWon) {
          let claimed = true
          if (EXCLUSIVE) claimed = claimExclusiveSpinForPlayer(ctx.db, CHARACTER_ID, ctx.from)
          if (claimed) {
            if (!player.ownedCharacters.includes(CHARACTER_ID)) player.ownedCharacters.push(CHARACTER_ID)
            addOwnedSeasonContent(player, 'character', CHARACTER_ID)
            won = true
          }
          break
        }
      }

      if (!results.length) {
        outcome = { reason: (player[SPIN_FIELD] ?? 0) >= MAX_SPINS_PER_PLAYER ? 'exhausted_lifetime' : 'gems', gems }
        return
      }
      outcome = { reason: won ? 'won' : 'exhausted', results, spinsUsed, remaining: player.wallet.gems }
    })

    if (outcome?.reason === 'owned') {
      return replyOverArt(ctx, character, `🖤 *${character.name} is already yours.*`)
    }
    if (outcome?.reason === 'claimed') {
      return replyOverArt(ctx, character,
        `🔒 *SHE ALREADY BELONGS TO SOMEONE.*\n${RULE}\n_Another player reached her this very moment. No gems were spent._`)
    }
    if (outcome?.reason === 'gems') {
      return ctx.reply(
        `💎 *Not enough Gems.*\n${RULE}\n` +
        `One spin costs *${COST_PER_SPIN}*. You hold *${fmtGems(outcome.gems)}*.\n\n_The dark only answers gems._`)
    }
    if (outcome?.reason === 'exhausted_lifetime') {
      return ctx.reply(
        `🖤 *No spins left.*\n${RULE}\n` +
        `_You have used all *${MAX_SPINS_PER_PLAYER}* of your spins for Yelan. She never once turned around._`)
    }

    const last = outcome.results[outcome.results.length - 1]
    const spent = roundGems(outcome.spinsUsed * COST_PER_SPIN)
    const range = outcome.spinsUsed === 1
      ? `Spin *${last.spin}*`
      : `Spins *${outcome.results[0].spin}* → *${last.spin}*`

    if (outcome.reason === 'won') {
      const ability = character.ability
      return replyOverArt(ctx, character,
        `🖤✨ *SHE LOOKS AT YOU.* ✨🖤\n${RULE}\n` +
        `_Spin ${last.spin}. The dark parts, and she steps out of it already knowing your name._\n\n` +
        `🏆 *${character.name.toUpperCase()} OBTAINED*\n` +
        `${character.emoji ?? '🖤'} *${characterStars(character.stars)}*` +
        (ability?.name ? `  ·  *${ability.name}*` : '') + `\n` +
        (ability?.flavor ? `_${ability.flavor}_\n` : '') +
        (character.description ? `\n_${character.description}_\n` : '') +
        (EXCLUSIVE ? `\n🔒 *GLOBALLY LOCKED.* No other player can ever obtain her.\n` : '') +
        `_Taken on spin ${last.spin}, for ${fmtGems(spent)} gems this pull._\n\n` +
        `💎 Remaining: *${fmtGems(outcome.remaining)}*\n\n` +
        `_Equip her with *${p}character equip yelan*._`)
    }

    const lines = [
      `🖤 *THE DARK IS PATIENT*`,
      RULE,
      `_You set 💎${fmtGems(spent)} down in front of nothing at all._`,
      ``,
      range,
      reel(outcome.results),
      ``,
      missLine(last.spin),
      ``,
      `📿 Pity  ${pityBar(last.spin)}  *${last.spin}*/${MAX_SPINS_PER_PLAYER}`,
      `💎 Remaining: *${fmtGems(outcome.remaining)}*`,
    ]
    if (requested > MAX_SPINS_PER_COMMAND) {
      lines.push(``, `_Capped at *${MAX_SPINS_PER_COMMAND}* spins per command — run it again for more._`)
    } else if (outcome.spinsUsed < spinCount) {
      lines.push(``, `_Gems ran out after *${outcome.spinsUsed}* of *${spinCount}* requested spins._`)
    }

    const lossText = lines.join('\n')
    return isFirstEverAttempt ? replyOverArt(ctx, character, lossText) : ctx.reply(lossText)
  },
}
