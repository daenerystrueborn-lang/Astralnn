import { migratePersonalFloors } from '../lib/survival-progression.js'
import { godPveTurn, godHeartGuard } from '../lib/god-series/pve.js'
import { interceptHeartStrike } from '../lib/god-series/heart-reaction.js'
import { withGodHostState, rewriteGodHostHit } from '../lib/god-series/host-state.js'
import { battleGodReady } from '../lib/god-series/catalog.js'
import { godDeathRefusal } from '../lib/god-series/battle.js'
import {finiteNumber} from '../lib/vitals.js'
import { armPartySurvival, advanceFormation, formationIncoming, partyFormationReadout } from '../lib/party-survival.js'
import { expectedLevelAtFloor } from '../lib/xp-regulator.js'
import { limitDungeonHp } from '../lib/dungeon-hp-budget.js'
import { ENDLESS_ID, endlessState, applyEndlessRank } from '../lib/endless-dungeon.js'
import { noteCombatVictory, noteDungeonDeath, ultraInstinctStatBoost } from '../lib/ultra-instinct.js'
import { awakenUltraInstinctInBattle } from '../lib/combat-handlers.js'
/**
 * party.js — form a party of up to 3 and take on a dungeon together.
 *
 * Registered as `.dparty` (dungeon party) — the `.party` command belongs to
 * plugins/pokemon.js (Pokémon battle party). Short shortcuts `.pattack`,
 * `.pdefend`, `.pflee` live in plugins/pattack.js.
 *
 * Commands:
 *   .dparty create                    — start a party (you become leader)
 *   .dparty invite <@player>          — invite someone (leader only)
 *   .dparty join / .dparty accept    — accept your pending invite
 *   .dparty decline                   — decline your pending invite
 *   .dparty leave                     — leave your current party
 *   .dparty kick <@player>            — remove a member (leader only)
 *   .dparty disband                   — dissolve the party (leader only)
 *   .dparty                           — show your party status
 *   .dparty enter <dungeonId>         — leader starts a co-op climb of a dungeon
 *   .dparty next / .descend           — leader descends the party to the next floor
 *   .dparty attack / .pattack         — attack the shared enemy (fixed turn order)
 *   .dparty cinderverdict / .pcv      — Wither's once-per-battle ember sentence
 *   .dparty defend                    — brace, reduces damage taken this round
 *   .dparty flee                      — leave the party battle (forfeits your cut)
 *   .dparty skip                      — wave on a teammate who has sat on their turn for 45s
 *
 * How party combat works (fixed turn order):
 *   The leader starts a climb (.dparty enter) and one enemy spawns for the
 *   whole party, with HP scaled up per extra member so it isn't trivial
 *   (regular floors only — bosses aren't scaled). Turn order is FIXED: it is
 *   captured from the members present when a floor spawns, and only the
 *   member at turnOrder[turnIndex] can act — attack, defend, flee, and every
 *   character active all gate on notYourTurn(). After each action the cursor
 *   advances to the next member still standing (advancePartyTurn), so play
 *   rotates in a known order instead of a free-for-all. The enemy strikes
 *   back at the actor (bosses) or a member weighted by aggro (regular
 *   enemies) after each action. When the enemy falls, XP/Solars/drops are
 *   split among everyone who landed at least one hit, weighted by damage
 *   share — and each cleared floor is banked into every present member's
 *   SOLO dungeonProgress (and now quest credit too), so co-op progress
 *   carries across modes. The leader then runs .dparty next to descend one
 *   floor deeper (1 stamina per member), repeating until the dungeon is
 *   conquered, the party wipes, or everyone runs out of stamina. The run
 *   starts at the LOWEST member's checkpoint, so a fresh member is never
 *   dropped deep.
 *
 * The turn clock (lib/party-clock.js): a member who is standing but silent no
 *   longer freezes the party. Settled on read, no timers: when anyone acts and the
 *   holder has sat on their turn for 90 seconds, the holder's turn resolves as an
 *   automatic Brace (never an attack) and the cursor moves on. `.dparty skip` does
 *   the same after 45 seconds. Three auto braces in a row and the member steps out
 *   of the floor; they are back in when the leader runs `.dparty next`.
 *
 * Party mode is CO-OP ONLY and rate-limited: at least MIN_PARTY_TO_ENTER
 * members are required to enter, and each member gets PARTY_DAILY_LIMIT
 * runs per day (PARTY_DAILY_LIMIT_PREMIUM for premium), counted at
 * .dparty enter — the whole climb after that is free.
 *
 * Crash-proofing: no command ever answers "already in a battle" for a fight
 * that is actually over. Victory/down resolution runs OUTSIDE the write-lane
 * mutator (no nested updatePlayer — the old deadlock that left battles stuck
 * forever), the teardown that frees members and clears party.battle runs
 * before the victory message is sent, and repairPartyState() — called at the
 * top of every .dparty/.pattack command — settles any won-but-unsettled
 * battle it finds, clears orphaned inBattle flags, and ends overrun runs.
 *
 * Climb state lives on party.run = { locationId, floor, startedAt } — the
 * cursor for the next floor to fight — while party.battle is the live fight
 * (or null between floors). The season dungeon is the one exception: it stays
 * a single fixed fight against the End on its party-boss floor.
 *
 * State lives in db.data.parties, keyed by leaderId (also the party's id).
 * Each member additionally gets `player.partyId` set to the leader's id for
 * fast lookups. This is intentionally kept separate from the existing solo
 * `player.battleState` / handleVictory / handleDeath flow in
 * combat-handlers.js — party fights are multi-actor and don't map cleanly
 * onto that single-player state machine, so re-using it risked corrupting
 * solo dungeon runs. Nothing in the existing solo combat files is modified.
 */
import { travelTollFor } from '../lib/travel-price.js'
import { config, logger } from '../config.js'
import { applyNighOmni } from '../lib/texas.js'
import { minatoTurnTick, rollFlyingThunderGodDodge } from '../lib/minato.js'
// 🌋 Surtr — Twilight's incoming guard (party damage never reaches
// applyIncomingDamage, so the twin sits in applyPartyIncoming below) and her
// skill gates, which run on the per-member `charState` like every other
// signature move here.
import {
  hasSurtr, surtrSkillByCommand, buildSurtrMenu, surtrStatusLine, ensureSurtrState,
  laevatainStoked, laevatainMultiplier, noteLaevatainHit,
  activateMoltenGiant, activateSurtrFlame, activateTwilight, endTwilight,
  twilightActive, resolveTwilightGuard, surtrTurnTick, clearSurtrKit,
  MOLTEN_GIANT_MULT, MOLTEN_GIANT_OUTGOING, TWILIGHT_OUTGOING,
  SURTR_FLAME_BURN_TURNS, SURTR_FLAME_BURN_FRACTION,
} from '../lib/surtr.js'
import {
  applyFlameCombo, activateBlazeHeart, blazeHeartOpening, sendBlazeHeartImage, BLAZE_HEART_NAME,
} from '../lib/rengoku.js'
import { applyEndMonsterTurn } from '../lib/the-end.js'
import { canCallGarden, callGarden, chargeGrudge, grudgeStatus } from '../lib/garden.js'
import { tickShunShunRikka } from '../lib/orihime.js'
import { sendBattleTurnReply } from '../lib/battle-frame-render.mjs'
import { updatePlayer, updateAllPlayers, getPlayer, findPlayerByName } from '../lib/player-repo.js'
import { resolvePlayerId } from '../lib/identity-resolver.js'
import { extractTarget } from '../lib/group-helpers.js'
import { normalizeMessageContent } from '#wa'
import {
  locationsMap,
  regularByLoc,
  bossByLocFloor,
  getAnimeBossForSlot,
  allItems,
  classes,
  races,
  skills as allSkills,
  levelsData,
  getTotalStats,
} from '../lib/game-data.js'
import { pickMonsterForFloor, refreshStamina, hpBar, calcPlayerDamage, applyDefense, calcMonsterDamage, calcPlayerHitChance, calcMonsterHitChance, rollDrops, applyLevelUps, getNewlyUnlockedSkills, rollEchoStrike, getPrimaryStat, enemyPowerRatio, scaleEnemyToPlayer, scaleBossToPlayer, applyVeteranScaling, veteranBanner } from '../lib/combat-engine.js'
// isDungeonUnlocked is a hoisted function export, so importing it here from the
// solo dungeon plugin is safe even though both are auto-loaded plugins (no
// evaluation-order cycle — it's only ever called at runtime).
import { isDungeonUnlocked } from './dungeon.js'
import { isTowerLocation, TOWER_STAGING_LOCATION_ID } from '../lib/orv-tower.js'
import { sendImage } from '../lib/image.js'
import { hasAffinity, normalizeAffinityId, getElementDef, grantMasteryXp } from '../lib/affinity-engine.js'
import { BEND_MP_COST, computeBendProfile, applyElementalBendRider } from './bend.js'
import { resolveBendingPhaseChain } from '../lib/bending-chains.js'
import {
  initBossFight,
  applyBossSpecial,
  checkBossPhase,
  buildEnemyAttack,
  incrementBossTurn,
  getBossTaunt,
  getBossHitLine,
  getBossDodgeLine,
  EVENT,
} from '../lib/boss-engine.js'
import { hasInventoryRoom } from '../lib/inventory-limits.js'
import {
  getActiveSeason, getSeasonRuntime, isSeasonRunActive,
  ensurePlayerSeasonState, applySeasonLevel, grantRegularXpPassXp, isSeasonLocationAvailable, isSeasonalLocation,
  isSeasonDungeonEnterable, seasonLockdownRefusal,
} from '../lib/season-engine.js'
import { applyMeiSustainHeal, applyInfinity, activateFinalForm, applyTearOnHit, tickPermanentSever, activateCinderVerdict, activateHollowPurple, activateUnlimitedVoid, UNLIMITED_VOID_STUN_TURNS, sendFinalFormVideo, hasSecondTranscendance, activateKurama, resolveKuramaDrain, narutoBattleLine, sendKuramaSummonImage, tickBethMend, tickClaneDrain } from '../lib/character-abilities.js'
import { checkPearlSave, checkTotemRevive, processStatusTurn } from '../lib/combat-handlers.js'
import { haNeulAbsorb, seongHaHymnSave, edoTenseiSave, ownsSkill, KARREN_ID } from '../lib/starfall-champion.js'
import { hasEffect } from '../lib/effects.js'
import { addStatusEffect, absorbDamage, absorbInstinctAttack, getEffectiveStat } from '../lib/effects.js'
import { applyStarterRelicsAfterDamage } from '../lib/starter-pack-engine.js'
import { beastIntervention, clearBeastEffects, BEAST_EVENT } from '../lib/beast-engine.js'
import { isPremiumActive } from '../lib/premium.js'
import { startOfDay } from '../lib/sleep-engine.js'
import { recordQuestEvent } from '../lib/quest-engine.js'
import { notePartyFloor, noteTowerKill } from '../lib/scenario-metrics.js'
import { addSeason02TowerAction } from '../lib/season-event-engine.js'
import { noteKill, readyLine } from '../lib/guild-board.js'
import { recordCodexKill, codexLine } from '../lib/codex.js'
import { partyRewardPool } from '../lib/party-rewards.js'
import {
  TURN_CLOCK_MS, SKIP_CLOCK_MS, stampTurn, hasStamp, turnAgeMs, clockLeftMs, secondsLabel, clockHint,
  noteActed, noteAutoBrace, shouldDrop, autoBraceLine, dropLine, steppedOutLine,
} from '../lib/party-clock.js'
import { graceHoldsEnemyTurn, graceEnemyHeldLine, graceHoldLine, graceReduce } from '../lib/king-yato.js'
// 🏛️ Victoria Minayoko — Sanctum Victoriae, and her allies named under it.
import {
  sanctumShields, sanctumBreakLine, canRaiseSanctum, raiseSanctum, shelterUnderSanctum, cleanseUnderSanctum,
} from '../lib/victoria.js'
import {
  armExcalibur, EXCALIBUR_DAMAGE, EXCALIBUR_ART, sendMoveArt,
} from '../lib/starfall-kits.js'

const MAX_PARTY_SIZE = 3
const MIN_PARTY_TO_ENTER = 2            // party mode is co-op only — no solo XP grinding
const PARTY_DAILY_LIMIT = 1             // regular players: one co-op run per day
const PARTY_DAILY_LIMIT_PREMIUM = 5     // premium players: five co-op runs per day
const INVITE_TIMEOUT_MS = 5 * 60 * 1000 // 5 minutes
const HP_SCALE_PER_EXTRA_MEMBER = 0.85  // enemy gets +85% max HP per member beyond the first
const BOSS_COMBAT_CAPS = { hp: 180_000, atk: 8_500, def: 2_600 }

function ensurePartyStore(db) {
  if (!db.data.parties) db.data.parties = {}
  return db.data.parties
}

function getPartyByLeader(db, leaderId) {
  return ensurePartyStore(db)[leaderId] ?? null
}

function samePlayer(db, left, right) {
  return !!left && !!right && resolvePlayerId(db, left) === resolvePlayerId(db, right)
}

function partyMemberId(db, party, jid) {
  return (party?.members ?? []).find(member => samePlayer(db, member, jid)) ?? null
}

/** Find the party a player belongs to, even when a DM and group use different JIDs. */
export function findPartyForPlayer(db, jid) {
  const parties = ensurePartyStore(db)
  const canonical = resolvePlayerId(db, jid)
  if (parties[jid]) return parties[jid]
  if (parties[canonical]) return parties[canonical]
  return Object.values(parties).find(party => partyMemberId(db, party, jid)) ?? null
}

/**
 * Party state is keyed by member ids, not WhatsApp transport addresses. New
 * parties use canonical player ids; for an existing party retain its stored
 * spelling so its battle turn order, contributions and ability state survive.
 * The original ctx is untouched and reply/sender still address the live chat.
 */
function partyContext(ctx) {
  const party = findPartyForPlayer(ctx.db, ctx.from)
  const member = partyMemberId(ctx.db, party, ctx.from)
  const actor = member ?? resolvePlayerId(ctx.db, ctx.from)
  return actor === ctx.from ? ctx : { ...ctx, partyTransportFrom: ctx.partyTransportFrom ?? ctx.from, from: actor }
}

/** Resolve a mention, number, reply or player name to the actual player key. */
function resolveTargetJid(ctx, raw) {
  const content = normalizeMessageContent(ctx.msg?.message) ?? ctx.msg?.message
  const info = content?.extendedTextMessage?.contextInfo
  const mention = info?.mentionedJid?.[0] ?? (ctx.platform && ctx.platform !== 'whatsapp' ? extractTarget(ctx) : null)
  let target = mention ?? null
  const text = String(raw ?? '').trim()
  if (!target && text) {
    if (/^\d+(?::\d+)?@(?:s\.whatsapp\.net|lid|c\.us)$/i.test(text)) {
      target = text
    } else if (/^@?\+?[\d().\s-]+$/.test(text)) {
      const digits = text.replace(/\D/g, '')
      if (digits) target = `${digits}@s.whatsapp.net`
    } else {
      const player = findPlayerByName(ctx.db.data.users, text)
      if (player) target = player.id ?? player.jid ?? null
    }
  }
  if (!target) target = info?.participant ?? null
  return target ? resolvePlayerId(ctx.db, target) : null
}

function inviteJid(invite) {
  return typeof invite === 'string' ? invite : invite?.jid
}

function inviteIsLive(invite, now = Date.now()) {
  return typeof invite?.invitedAt === 'number' && now - invite.invitedAt < INVITE_TIMEOUT_MS
}

function pendingInvitesFor(db, jid, now = Date.now()) {
  return Object.values(ensurePartyStore(db)).filter(party =>
    (party.pendingInvites ?? []).some(invite => inviteIsLive(invite, now) && samePlayer(db, inviteJid(invite), jid)))
}

function nameFor(db, jid) {
  return getPlayer(db, jid)?.name ?? jid?.split('@')[0] ?? 'unknown'
}

function memberListText(db, party) {
  return party.members
    .map(m => `  ${m === party.leaderId ? '👑' : '⚔️'} ${nameFor(db, m)}`)
    .join('\n')
}

// ── Turn order (fixed round-robin) ─────────────────────────────────────────
// Party combat takes turns in a fixed order instead of a free-for-all. The
// order is captured when a floor spawns (spawnAndAnnounceFloor). A battle from
// before this feature shipped has no turnOrder, so partyTurnHolder returns null
// and the turn gate is skipped (graceful fallback to the old free-for-all).
export function partyTurnHolder(party) {
  const b = party?.battle
  if (!b || !Array.isArray(b.turnOrder) || b.turnOrder.length === 0) return null
  const idx = ((b.turnIndex ?? 0) % b.turnOrder.length + b.turnOrder.length) % b.turnOrder.length
  return b.turnOrder[idx] ?? null
}

// Advance the cursor to the next member who is still standing (inBattle). If
// nobody else is fighting, it lands back on whoever is left. Safe to call even
// when there is no turnOrder.
export function advancePartyTurn(db, party, action = 'offence') {
  const b = party?.battle
  if (!b || !Array.isArray(b.turnOrder) || b.turnOrder.length === 0) return
  // A new turn starts now: this is the moment the 90 second clock counts from.
  stampTurn(b)
  const member = partyTurnHolder(party)
  advanceFormation(b, member, action, b.turnOrder.filter(id => getPlayer(db, id)?.inBattle))
  if (member) {
    b.charState = b.charState ?? {}
    const state = b.charState[member] = b.charState[member] ?? {}
    state.turn = (state.turn ?? 1) + 1
  }
  const n = b.turnOrder.length
  for (let step = 1; step <= n; step++) {
    const cand = b.turnOrder[((b.turnIndex ?? 0) + step) % n]
    if (getPlayer(db, cand)?.inBattle) {
      b.turnIndex = ((b.turnIndex ?? 0) + step) % n
      return
    }
  }
  // Nobody standing found other than possibly the current holder — leave as is.
  b.turnIndex = ((b.turnIndex ?? 0) + 1) % n
}

// Returns a reply string if it is NOT this player's turn, else null. Also
// self-heals the cursor if it is pointing at a member who has fallen (inBattle
// false) so the party never softlocks on a downed player's turn, and settles the
// turn clock: a holder who has sat on their turn for 90 seconds is braced for and
// passed over before this player's own turn is judged (see settleTurnClock).
export async function notYourTurn(ctx, party) {
  ctx = partyContext(ctx)
  let holder = partyTurnHolder(party)
  if (!holder) return null // pre-feature battle: free-for-all fallback
  // The clock's own auto brace runs the real defend path as the idle member.
  // That is not a turn they chose to take, so it neither re-enters this gate nor
  // clears their idle streak.
  if (ctx._turnClockSettling) return null

  if (holder !== ctx.from && !getPlayer(ctx.db, holder)?.inBattle) {
    advancePartyTurn(ctx.db, party)
    holder = partyTurnHolder(party)
  }

  if (holder && holder !== ctx.from) {
    const clock = await settleTurnClock(ctx, party)
    if (clock.settled) {
      // The brace itself can end the climb (a wipe). Nothing is left to act on.
      if (!party.battle) return `🏁 That fight ended while the clock ran.`
      holder = partyTurnHolder(party)
    }
  }

  if (holder && holder !== ctx.from) {
    if (party.battle?.idleOut?.includes(ctx.from)) return steppedOutLine(config.prefix)
    return `⏳ It's *${nameFor(ctx.db, holder)}*'s turn. Wait your turn, then act.` +
      clockHint(party.battle, config.prefix)
  }

  // Their turn, and they are here to take it: the idle streak starts over.
  if (holder === ctx.from) noteActed(party, ctx.from)
  return null
}

// ── The turn clock ─────────────────────────────────────────────────────────
// Settle-on-read, like plugins/raid.js: nothing runs on a timer. Anyone who acts
// (or runs `.dparty skip`) while the holder's turn has outlived `minMs` makes the
// holder's turn resolve as an automatic Brace through the REAL defend path, so
// boss hooks, Grace of the Crown, Infinity and every other defend rule apply as if
// they had typed it. Defend only, never attack: idling cannot advance the fight.
//
// The brace is a consequence of someone else's command, so it is the one place a
// command can send a second message. Its text is captured and sent as ONE reply
// with the clock line in front, and only when a clock actually ran out.
export async function settleTurnClock(ctx, party, { minMs = TURN_CLOCK_MS } = {}) {
  ctx = partyContext(ctx)
  const b = party?.battle
  if (!b || b.resolving || (b.enemy?.hp ?? 1) <= 0) return { settled: false }
  const holder = partyTurnHolder(party)
  if (!holder || holder === ctx.from) return { settled: false }
  // Only a member who is standing in the fight can run somebody else's clock.
  if (!getPlayer(ctx.db, ctx.from)?.inBattle) return { settled: false }

  const now = Date.now()
  // A fight from before the clock shipped has no stamp: start counting now.
  if (!hasStamp(b)) { stampTurn(b, now); return { settled: false } }
  if (turnAgeMs(b, now) < minMs) return { settled: false }
  const idle = getPlayer(ctx.db, holder)
  if (!idle?.inBattle || idle.battleState) return { settled: false }

  // Restart the clock BEFORE awaiting anything, so a second command landing
  // while this one resolves does not settle the same turn twice.
  stampTurn(b, now)

  const name = nameFor(ctx.db, holder)
  const said = []
  const asIdle = {
    ...ctx,
    from: holder,
    player: idle,
    _turnClockSettling: true,
    reply: async (text) => { said.push(String(text)); return text },
  }
  try {
    await battleDefend(asIdle)
  } catch (err) {
    logger?.warn?.({ err: err?.message, holder }, 'party turn clock: auto brace failed, turn left where it was')
    return { settled: false, holder }
  }

  const streak = noteAutoBrace(party, holder)
  let dropped = false
  // Three in a row and they step out of the floor, like a failed flee with no
  // roll: skipped by the cursor, off the enemy's target list, and not counted as
  // standing when the party is checked for a wipe. `.dparty next` seats them again.
  if (party.battle && shouldDrop(streak) && getPlayer(ctx.db, holder)?.inBattle) {
    await updatePlayer(ctx.db, holder, async m => {
      if (!m.battleState) { m.inBattle = false; clearBeastEffects(m) }
      return m
    })
    party.battle.idleOut = [...new Set([...(party.battle.idleOut ?? []), holder])]
    dropped = true
  }

  const lines = [autoBraceLine(name), ...said]
  if (dropped) lines.push(dropLine(name))
  const next = party.battle ? partyTurnHolder(party) : null
  if (next) lines.push(`🎯 Up next: *${nameFor(ctx.db, next)}*.`)
  try { await ctx.reply(lines.join('\n\n')) } catch {}
  return { settled: true, holder, streak, dropped }
}

// ── .dparty skip ───────────────────────────────────────────────────────────
// The same settle as the clock, opened to a standing teammate after 45 seconds
// so the party does not have to wait out the full 90.
async function skipTurn(ctx) {
  const p = config.prefix
  const party = findPartyForPlayer(ctx.db, ctx.from)
  if (!party) return ctx.reply(`❌ You're not in a party.`)
  if (!party.battle) return ctx.reply(`❌ Your party isn't in a battle.`)
  const holder = partyTurnHolder(party)
  if (!holder) return ctx.reply(`❌ This fight has no turn order to skip.`)
  if (holder === ctx.from) {
    return ctx.reply(`🎯 It's your turn. *${p}dparty attack* · *${p}dparty defend*`)
  }
  if (!getPlayer(ctx.db, ctx.from)?.inBattle) {
    return ctx.reply(`❌ You're not standing in this fight, so you can't skip anyone.`)
  }
  if (!getPlayer(ctx.db, holder)?.inBattle) {
    // The cursor is on a fallen member: the gate heals it and says whose turn it is.
    const msg = await notYourTurn(ctx, party)
    return ctx.reply(msg ?? `🎯 It's your turn.`)
  }
  const b = party.battle
  const left = clockLeftMs(b, Date.now(), SKIP_CLOCK_MS)
  if (left > 0) {
    // A fight with no stamp starts counting the first time anyone looks.
    if (!hasStamp(b)) stampTurn(b)
    return ctx.reply(
      `⏳ *${nameFor(ctx.db, holder)}* still has time. You can skip them in *${secondsLabel(left)}*.`,
    )
  }
  const res = await settleTurnClock(ctx, party, { minMs: SKIP_CLOCK_MS })
  if (!res.settled) {
    // Somebody else got there first, or the fight just changed. Say where things are.
    const now = party.battle ? partyTurnHolder(party) : null
    return ctx.reply(now ? `🎯 It's *${nameFor(ctx.db, now)}*'s turn.` : `🏁 That fight is over.`)
  }
}

// ── Stale-state repair (self-healing) ──────────────────────────────────────
// Run at the top of every .dparty / .pattack command. This is the safety net
// that makes the historical stuck states IMPOSSIBLE to sit on, whatever crash
// or lost write produced them — including parties stranded by the old
// victory-in-mutator deadlock on the live bot:
//
//   1. battle set but enemy already dead  → the victory never finished
//     resolving. Re-run resolvePartyVictory: it pays out by contributions
//     (this battle was never resolved — battle is still set — so nothing is
//     double-paid), banks floor progress, frees every member and advances or
//     ends the climb. The idempotency guard inside makes a racing double
//     call a no-op.
//   2. no battle but members still flagged inBattle → clear the stale flags
//     (only for members NOT in a solo fight — solo battles set battleState,
//     party fights don't, so that's the discriminator).
//   3. run cursor pointing past the last floor → the dungeon is done; end
//     the run cleanly as conquered.
//
// Exported so plugins/cb.js (owner-only) can run it against a tagged
// player's party too.
async function repairPartyState(ctx, party) {
  if (!party) return false

  // Case 1 — a won battle whose results never got settled. A battle that is
  // mid-resolution (resolving flag) is skipped: its payout is already running.
  if (party.battle && !party.battle.resolving && (party.battle.enemy?.hp ?? 1) <= 0) {
    await ctx.reply(
      `🧹 _Finishing a battle that was already won — settling the results now._`,
    ).catch(() => {})
    await resolvePartyVictory(ctx, party)
    return true
  }

  // Case 2 — stale inBattle flags with no live party battle.
  if (!party.battle) {
    for (const jid of party.members) {
      const m = getPlayer(ctx.db, jid)
      // A solo fight sets player.battleState; a party fight never does. If
      // battleState is set this flag belongs to a live solo battle — hands off.
      if (m?.inBattle && !m.battleState) {
        try {
          await updatePlayer(ctx.db, jid, async pl => { pl.inBattle = false; clearBeastEffects(pl); return pl })
        } catch {}
      }
    }
  }

  // Case 3 — run cursor past the end of the dungeon.
  if (party.run && !party.battle) {
    const totalFloors = locationsMap[party.run.locationId]?.floors ?? 0
    if (totalFloors > 0 && party.run.floor > totalFloors) {
      party.run = null
      await ctx.reply(`🏆 _The climb was already past the last floor — dungeon conquered._`).catch(() => {})
      return true
    }
  }

  return false
}

// ── .party (status) ────────────────────────────────────────────────────
async function showStatus(ctx) {
  const p = config.prefix
  const party = findPartyForPlayer(ctx.db, ctx.from)

  if (!party) {
    const invites = pendingInvitesFor(ctx.db, ctx.from)
    const invitation = invites.length
      ? `📨 *Invited by:* ${invites.map(squad => nameFor(ctx.db, squad.leaderId)).join(', ')}\n` +
        `*${p}dparty join* (or *${p}dparty accept*) — join an invited party\n` +
        (invites.length > 1 ? `_For multiple invites, add the leader's name or @mention._\n` : '') +
        `*${p}dparty decline* — decline an invite\n\n`
      : ''
    return ctx.reply(
      `┌─────────────────────┐\n│   🤝 *PARTY*   │\n└─────────────────────┘\n\n` +
      `You're not in a party.\n\n` + invitation +
      `*${p}dparty create* — start one\n` +
      `_Invite friends, then *${p}dparty enter <dungeon>* to fight together._`,
    )
  }

  const inBattle = !!party.battle
  let msg = `┌─────────────────────┐\n│   🤝 *YOUR PARTY*   │\n└─────────────────────┘\n\n`
  msg += `👑 Leader: *${nameFor(ctx.db, party.leaderId)}*\n`
  msg += `👥 Members (${party.members.length}/${MAX_PARTY_SIZE}):\n${memberListText(ctx.db, party)}\n\n`
  const pending = (party.pendingInvites ?? []).filter(invite => inviteIsLive(invite))
  if (pending.length) {
    msg += `📨 Pending invites: ${pending.map(invite => nameFor(ctx.db, inviteJid(invite))).join(', ')}\n\n`
  }
  msg += inBattle
    ? `⚔️ *Currently in battle at ${locationsMap[party.battle.locationId]?.name ?? party.battle.locationId}!*\nUse *${p}dparty attack* to join in.` +
      // Fixed turn order: show whose move it is so "it's not my turn" is
      // never a surprise.
      (() => {
        const holder = partyTurnHolder(party)
        return holder ? `\n🎯 It's *${nameFor(ctx.db, holder)}*'s turn.${clockHint(party.battle, p)}` : ''
      })()
    : party.run
      ? `🧗 *Climbing ${locationsMap[party.run.locationId]?.name ?? party.run.locationId}* — next up: *Floor ${party.run.floor}*.\nLeader: *${p}dparty next* to descend.`
      : `📍 Status: *Idle*\nUse *${p}dparty enter <dungeonId>* to head into a dungeon together.`

  if (inBattle) {
    msg += '\n' + partyFormationReadout(party.battle)
    const meters = party.members.map(jid => {
      const member = getPlayer(ctx.db, jid)
      const cs = party.battle?.charState?.[jid] ?? {}
      const line = grudgeStatus(member ? { ...member, battleState: cs } : null)
      return line ? `${member.name}: ${line}` : ''
    }).filter(Boolean)
    if (meters.length) msg += `\n${meters.join('\n')}`
  }
  await ctx.reply(msg)
}

// ── .party create ────────────────────────────────────────────────────────
async function createParty(ctx) {
  const p = config.prefix
  let message = ''
  await updateAllPlayers(ctx.db, () => {
    const player = getPlayer(ctx.db, ctx.from)
    if (!player) { message = `❌ You need to register before creating a party.`; return false }
    if (findPartyForPlayer(ctx.db, ctx.from)) {
      message = `⚠️ You're already in a party. Use *${p}dparty leave* first if you want to start a new one.`
      return false
    }
    const actor = resolvePlayerId(ctx.db, ctx.from)
    const parties = ensurePartyStore(ctx.db)
    parties[actor] = {
      leaderId: actor, members: [actor], pendingInvites: [],
      battle: null, createdAt: Date.now(),
    }
    player.partyId = actor
    message = `┌─────────────────────┐\n│   🤝 *PARTY CREATED*   │\n└─────────────────────┘\n\n` +
      `👑 *${player.name}* is now the party leader!\n\n` +
      `*${p}dparty invite <@player>* — invite up to ${MAX_PARTY_SIZE - 1} more members\n` +
      `*${p}dparty enter <dungeonId>* — once ready, head in together`
    return true
  })
  return ctx.reply(message)
}

// ── .party invite <@player> ──────────────────────────────────────────────
async function invite(ctx, targetRaw) {
  const p = config.prefix
  const targetJid = resolveTargetJid(ctx, targetRaw)
  let message = ''

  // Invites are shared party state, not part of the leader's player object.
  // Serialize and persist the check + insert, including against joins and
  // seasonal party entry, instead of relying on an unrelated player save.
  await updateAllPlayers(ctx.db, () => {
    const party = findPartyForPlayer(ctx.db, ctx.from)
    if (!party) { message = `❌ You're not in a party. Use *${p}dparty create* first.`; return false }
    if (!samePlayer(ctx.db, party.leaderId, ctx.from)) { message = `❌ Only the party leader can invite members.`; return false }
    if (!targetJid) { message = `❓ Usage: *${p}dparty invite <@player>*`; return false }
    if (samePlayer(ctx.db, targetJid, ctx.from)) { message = `❌ You can't invite yourself.`; return false }
    if (!getPlayer(ctx.db, targetJid)) { message = `❌ That player isn't registered yet.`; return false }
    if (partyMemberId(ctx.db, party, targetJid)) { message = `⚠️ ${nameFor(ctx.db, targetJid)} is already in the party.`; return false }
    if (party.members.length >= MAX_PARTY_SIZE) { message = `❌ Party is full (${MAX_PARTY_SIZE}/${MAX_PARTY_SIZE}).`; return false }
    if (findPartyForPlayer(ctx.db, targetJid)) { message = `❌ ${nameFor(ctx.db, targetJid)} is already in another party.`; return false }

    const before = party.pendingInvites ?? []
    party.pendingInvites = before.filter(entry => inviteIsLive(entry))
    if (party.pendingInvites.some(entry => samePlayer(ctx.db, inviteJid(entry), targetJid))) {
      message = `⚠️ You've already invited ${nameFor(ctx.db, targetJid)}. Waiting on their response.`
      return before.length !== party.pendingInvites.length
    }
    party.pendingInvites.push({ jid: targetJid, invitedAt: Date.now() })
    message = `📨 *Invite sent to ${nameFor(ctx.db, targetJid)}!*\n\n` +
      `They can join with *${p}dparty join* or *${p}dparty accept* _(expires in 5 min)_.`
    return true
  })
  // No unsolicited DM: the invitation is shown when the invitee runs .dparty.
  return ctx.reply(message)
}

// ── .party join / accept / decline ───────────────────────────────────────
async function respondInvite(ctx, accept, targetRaw = '') {
  const p = config.prefix
  const selectedLeader = targetRaw ? resolveTargetJid(ctx, targetRaw) : null
  if (targetRaw && !selectedLeader) return ctx.reply(`❓ Name or mention the party leader to choose an invite.`)
  let message = ''

  await updateAllPlayers(ctx.db, () => {
    const now = Date.now()
    let changed = false
    const candidates = []
    for (const party of Object.values(ensurePartyStore(ctx.db))) {
      const before = party.pendingInvites ?? []
      const live = before.filter(entry => inviteIsLive(entry, now))
      if (live.length !== before.length) { party.pendingInvites = live; changed = true }
      if (live.some(entry => samePlayer(ctx.db, inviteJid(entry), ctx.from)) &&
          (!selectedLeader || samePlayer(ctx.db, party.leaderId, selectedLeader))) candidates.push(party)
    }

    if (!candidates.length) {
      message = selectedLeader
        ? `❌ You don't have a pending invite from that leader.`
        : `❌ You don't have a pending party invite. Ask a leader to use *${p}dparty invite @you*.`
      return changed
    }
    if (candidates.length > 1) {
      const leaders = candidates.map(party => `• ${nameFor(ctx.db, party.leaderId)}`).join('\n')
      message = `📨 You have multiple party invites:\n${leaders}\n\n` +
        `Choose one: *${p}dparty ${accept ? 'join' : 'decline'} <leader name or @mention>*.`
      return changed
    }

    const party = candidates[0]
    if (!accept) {
      party.pendingInvites = party.pendingInvites.filter(entry => !samePlayer(ctx.db, inviteJid(entry), ctx.from))
      message = `🚫 Invite declined.`
      return true
    }
    // Do not consume the invitation on a refusal: it may still be usable when
    // a temporary climb ends, provided the five-minute expiry has not passed.
    if (party.members.length >= MAX_PARTY_SIZE) { message = `❌ That party is now full.`; return changed }
    if (findPartyForPlayer(ctx.db, ctx.from)) { message = `❌ You're already in a party.`; return changed }
    if (party.battle || party.run) {
      message = `⏳ That party is mid-dungeon right now. Wait until the run ends, then accept while the invite is still valid.`
      return changed
    }
    const player = getPlayer(ctx.db, ctx.from)
    if (!player) { message = `❌ You need to register before joining a party.`; return changed }
    party.pendingInvites = party.pendingInvites.filter(entry => !samePlayer(ctx.db, inviteJid(entry), ctx.from))
    party.members.push(resolvePlayerId(ctx.db, ctx.from))
    player.partyId = party.leaderId
    message = `✅ *${player.name}* joined the party!\n\n` +
      `👥 Members (${party.members.length}/${MAX_PARTY_SIZE}):\n${memberListText(ctx.db, party)}`
    return true
  })
  return ctx.reply(message)
}

// ── .party leave / kick / disband ────────────────────────────────────────
function removeParty(db, party) {
  const parties = ensurePartyStore(db)
  for (const [key, value] of Object.entries(parties)) {
    if (value === party) delete parties[key]
  }
}

function clearPartyMember(player) {
  if (!player) return
  player.partyId = null
  // An orphaned party fight has no battleState; never clear a solo fight.
  if (player.inBattle && !player.battleState) {
    player.inBattle = false
    clearBeastEffects(player)
  }
}

async function leave(ctx) {
  const p = config.prefix
  let message = ''
  await updateAllPlayers(ctx.db, () => {
    const party = findPartyForPlayer(ctx.db, ctx.from)
    if (!party) { message = `❌ You're not in a party.`; return false }
    if (party.battle) { message = `⚠️ You can't leave mid-battle. Use *${p}dparty flee* instead.`; return false }
    const player = getPlayer(ctx.db, ctx.from)
    if (samePlayer(ctx.db, party.leaderId, ctx.from)) {
      for (const jid of party.members) clearPartyMember(getPlayer(ctx.db, jid))
      removeParty(ctx.db, party)
      message = `🚪 *${player?.name ?? nameFor(ctx.db, ctx.from)}* (leader) left — the party has disbanded.`
    } else {
      clearPartyMember(player)
      party.members = party.members.filter(member => !samePlayer(ctx.db, member, ctx.from))
      message = `🚪 *${player?.name ?? nameFor(ctx.db, ctx.from)}* left the party.`
    }
    return true
  })
  return ctx.reply(message)
}

async function kick(ctx, targetRaw) {
  const targetJid = resolveTargetJid(ctx, targetRaw)
  let message = ''
  await updateAllPlayers(ctx.db, () => {
    const party = findPartyForPlayer(ctx.db, ctx.from)
    if (!party) { message = `❌ You're not in a party.`; return false }
    if (!samePlayer(ctx.db, party.leaderId, ctx.from)) { message = `❌ Only the leader can kick members.`; return false }
    const memberJid = partyMemberId(ctx.db, party, targetJid)
    if (!memberJid) { message = `❌ That player isn't in your party.`; return false }
    if (samePlayer(ctx.db, memberJid, ctx.from)) {
      message = `❌ You can't kick yourself — use *${config.prefix}dparty disband* instead.`
      return false
    }
    if (party.battle) { message = `⚠️ Can't kick mid-battle.`; return false }
    party.members = party.members.filter(member => member !== memberJid)
    clearPartyMember(getPlayer(ctx.db, memberJid))
    message = `👢 *${nameFor(ctx.db, memberJid)}* was removed from the party.`
    return true
  })
  return ctx.reply(message)
}

async function disband(ctx) {
  let message = ''
  await updateAllPlayers(ctx.db, () => {
    const party = findPartyForPlayer(ctx.db, ctx.from)
    if (!party) { message = `❌ You're not in a party.`; return false }
    if (!samePlayer(ctx.db, party.leaderId, ctx.from)) { message = `❌ Only the leader can disband the party.`; return false }
    if (party.battle) { message = `⚠️ Can't disband mid-battle.`; return false }
    for (const jid of party.members) clearPartyMember(getPlayer(ctx.db, jid))
    removeParty(ctx.db, party)
    message = `💥 *Party disbanded.*`
    return true
  })
  return ctx.reply(message)
}

// ── Combat helpers ───────────────────────────────────────────────────────

function isBossFloor(locId, floor) {
  return (locationsMap[locId]?.bossFloors ?? []).includes(floor)
}

function spawnPartyEnemy(locId, floor, memberCount, anchorPlayer = null) {
  let base
  if (isBossFloor(locId, floor)) {
    const animeBoss = getAnimeBossForSlot(locId, floor)
    if (animeBoss) {
      const init = initBossFight(anchorPlayer ?? {}, animeBoss.id, floor, { mode: 'party' })
      if (!init.ok) return null
      base = {
        ...init.enemy,
        locationId: locId,
        floor,
        hp: init.enemy.hp,
        maxHp: init.enemy.maxHp,
        isBoss: true,
        animeBossId: animeBoss.id,
        // Conquest title for the final-floor reveal AND the title granted on
        // conquest (resolvePartyVictory). Mirrors dungeon.js spawnBoss so a
        // party clearing a dungeon's last floor earns the same title solo does.
        conquestTitle: animeBoss.conquestTitle ?? `${animeBoss.name}'s Equal`,
        // Carried alongside the enemy so battleAttack/battleCinderVerdict can
        // drive lib/boss-engine.js's mechanics (Infinity, Mahoraga adapt,
        // phase shifts, named attacks, etc.) via _withBossBattleState below.
        // Plain (non-anime) bosses from bossByLocFloor have no def.special/
        // phases/attacks, so bossState stays undefined for them and the
        // bridge below simply no-ops — same as they behave today.
        bossState: init.bossState,
      }
      // resolvePartyVictory reads enemy.rewards?.xp/solars and rollDrops(enemy.drops)
      // (which needs [{itemId,chance}]). initBossFight only sets exp/gold and a
      // string[] of drops, which that path doesn't read — so an anime boss that
      // is ALSO a monsters.json entry (same id at this loc/floor, e.g. the
      // Season 1 End boss) would otherwise award nothing. Carry the twin's
      // reward/drop fields through in the format victory resolution expects.
      // Twinless anime bosses (the floor 100–1000 roster) have no matching
      // monster entry, so this is a no-op for them.
      const twin = bossByLocFloor[locId]?.[floor]
      if (twin && twin.id === animeBoss.id) {
        base.rewards = twin.rewards
        base.drops   = twin.drops
      }
    } else {
      const boss = bossByLocFloor[locId]?.[floor]
      if (!boss) return null
      base = {
        ...boss,
        hp: Math.min(BOSS_COMBAT_CAPS.hp, boss.stats.hp),
        maxHp: Math.min(BOSS_COMBAT_CAPS.hp, boss.stats.hp),
        def: Math.min(BOSS_COMBAT_CAPS.def, boss.stats.def),
        atk: Math.min(BOSS_COMBAT_CAPS.atk, boss.stats.atk),
        isBoss: true,
      }
    }
  } else {
    base = pickMonsterForFloor(locId, floor, regularByLoc)
  }
  if (!base) return null

  const cloned = { ...base }
  if (anchorPlayer && !isTowerLocation(locId) && locationsMap[locId]?.realm !== 'dreamlands') {
    const ratio = enemyPowerRatio(anchorPlayer, locId, floor)
    if (ratio > 1) {
      if (cloned.isBoss) scaleBossToPlayer(cloned, anchorPlayer, ratio)
      else scaleEnemyToPlayer(cloned, ratio, { hpExp: 0.94, atkExp: 0.66, defExp: 0.40 })
    }
  }

  // Party budgets are bounded at the actual three-member roster cap.
  // Every additional participant brings damage, healing and control. Bosses
  // must receive a budget too; formerly a three-player boss had solo HP.
  const extra = Math.max(0, Math.min(MAX_PARTY_SIZE, memberCount) - 1)
  const scale = 1 + extra * (cloned.isBoss ? 0.95 : HP_SCALE_PER_EXTRA_MEMBER)
  const scaledHp = Math.round(cloned.maxHp * scale)
  const atk = Math.round(cloned.atk * (1 + extra * 0.18))
  const def = Math.round(cloned.def * (1 + extra * 0.20))
  return limitDungeonHp({ ...cloned, hp: scaledHp, maxHp: scaledHp, atk, def,
    ...(cloned.baseAtk != null ? { baseAtk: atk } : {}),
    ...(cloned.baseDef != null ? { baseDef: def } : {}) })
}

/**
 * Bridge for lib/boss-engine.js in party fights.
 *
 * applyBossSpecial / checkBossPhase / buildEnemyAttack all read and mutate
 * `player.battleState.enemy` / `player.battleState.bossState`. Party fights
 * don't use player.battleState — the enemy is shared across the whole party
 * on party.battle.enemy instead — so calling those functions directly during
 * a party turn would silently no-op (no battleState.enemy to find).
 *
 * This shapes a throwaway battleState-like object pointing at the *same*
 * enemy and bossState objects that live on party.battle, calls fn against
 * it, then returns fn's result untouched. Because JS objects are references,
 * any in-place mutation the boss-engine functions make (enemy.hp, bossState
 * counters, etc.) lands directly on party.battle.enemy / .bossState — no
 * copy-back step needed. Player-side effects (stat reductions, MP drain)
 * read/write `player`, which is the real per-member document already.
 *
 * @param {object} player - the acting party member's real player document
 * @param {object} enemy  - party.battle.enemy (shared boss)
 * @param {(bridgedPlayer: object) => any} fn - call one of the boss-engine
 *   functions against bridgedPlayer.battleState, e.g.
 *   `p => applyBossSpecial(p, EVENT.TURN_START, {})`
 */
function withBossBattleState(player, enemy, fn, cs = null) {
  if (!enemy?.isBoss || !enemy?.bossState) return null
  const savedBattleState = player.battleState
  player.battleState = { enemy, bossState: enemy.bossState }
  // 🏛️ A party member's Sanctum (or their shelter under Victoria's) lives on
  // their party state, not on this stand-in, so it is carried in: the boss
  // engine's own turn-start specials ask sanctumShields() too.
  if (cs && (cs.sanctum || cs.sanctumShelter)) {
    Object.assign(player.battleState, { turn: cs.turn, sanctum: cs.sanctum, sanctumShelter: cs.sanctumShelter })
  }
  try {
    return fn(player)
  } finally {
    player.battleState = savedBattleState
  }
}

/** withBossBattleState with the acting member's party state bound (see above). */
function withBossBattleStateFor(cs) {
  return (player, enemy, fn) => withBossBattleState(player, enemy, fn, cs)
}

/**
 * Fallback enemy-attack for a *plain* boss — `isBoss: true` but no `bossState`
 * (e.g. the Season 1 "End" boss, built by spawnPartyEnemy's bossByLocFloor
 * branch). Plain bosses have no boss-engine mechanics, so withBossBattleState()
 * above no-ops and never populates the bossAtk/dealResult that the boss-
 * retaliation blocks in battleAttack/battleDefend/battleCinderVerdict read —
 * dereferencing dealResult.modified then threw and killed the whole turn
 * (the bot reacts ⚔️ but never replies). This returns values shaped exactly
 * like buildEnemyAttack()/applyBossSpecial() would, so the boss still lands a
 * basic attacker-targeted strike (raw ATK, run through DEF downstream).
 */
function plainBossStrike(enemy) {
  return {
    bossAtk: {
      attackName: 'Strike',
      damage: enemy.atk,
      bypassDefense: false,
      doubleStrike: false,
      narrativeLines: [],
    },
    dealResult: { modified: false, damage: undefined, guaranteedHits: null, narrativeLine: null },
  }
}

// ── .dparty enter <dungeonId> ─────────────────────────────────────────────
// Starts a co-op CLIMB: the party descends floor by floor (leader steps with
// .dparty next), and each cleared floor banks into every present member's SOLO
// dungeonProgress so the run carries across modes. The season boss stays a
// single fixed fight on its party-boss floor.
function chargePartyEntry(member, loc, today) {
  member.stamina = refreshStamina(member.stamina)
  member.stamina.current -= 1
  const memberToll = travelTollFor(loc, member)
  if (memberToll > 0) {
    member.wallet = member.wallet ?? {}
    member.wallet.solars = (member.wallet.solars ?? 0) - memberToll
  }
  if (member.partyRunsDate !== today) {
    member.partyRunsDate = today
    member.partyRunsToday = 0
  }
  member.partyRunsToday = (member.partyRunsToday ?? 0) + 1
  if (member.ultraInstinct) member.ultraInstinct.partyAwakening = false
  member.inBattle = true
}

async function enterDungeon(ctx, dungeonArg) {
  const p = config.prefix
  const party = findPartyForPlayer(ctx.db, ctx.from)
  if (!party) return ctx.reply(`❌ You're not in a party. Use *${p}dparty create* first.`)
  if (!samePlayer(ctx.db, party.leaderId, ctx.from)) return ctx.reply(`❌ Only the party leader can lead the party into a dungeon.`)
  if (party.battle) return ctx.reply(`⚠️ Your party is already in a battle! Use *${p}dparty attack*.`)
  if (party.run) return ctx.reply(`🧗 Your party is already climbing *${locationsMap[party.run.locationId]?.name ?? party.run.locationId}*. Use *${p}dparty next* to descend, or *${p}dparty leave* to stop.`)
  if (party.members.length < MIN_PARTY_TO_ENTER) {
    return ctx.reply(
      `❌ Party mode is co-op only. You need at least *${MIN_PARTY_TO_ENTER}* members to enter a dungeon together.\n\n` +
      `_Invite someone with *${p}dparty invite @player*, then head in. Grinding solo? Use *${p}dungeon* instead._`,
    )
  }
  if (!dungeonArg) return ctx.reply(`❓ Usage: *${p}dparty enter <dungeonId>*\nExample: *${p}dparty enter entry_tower*`)

  // If someone joins or leaves while entry is waiting for the barrier, the
  // original checks and checkpoint no longer describe this party.
  const entryMembers = party.members.slice()
  const locId = dungeonArg.toLowerCase().replace(/\s+/g, '_')
  const loc = locationsMap[locId]
  if (locId === ENDLESS_ID) return ctx.reply('🌌 The Endless Dungeon is a solo scenario. Use .enter endless_dungeon.')
  if (!loc || loc.type !== 'dungeon') return ctx.reply(`❌ Unknown dungeon *${locId}*.`)
  if (!isSeasonLocationAvailable(ctx.db, loc)) {
    return ctx.reply(`🌙 *${loc.name}* is closed. Its season is not active.`)
  }
  if (!isSeasonDungeonEnterable(ctx.db, loc)) {
    return ctx.reply(seasonLockdownRefusal(ctx.db) ?? `🌙 *${loc.name}* is closed.`)
  }
  const season = getActiveSeason(ctx.db)
  const seasonal = isSeasonalLocation(loc)
  if (seasonal && !season) return ctx.reply(`🌙 *${loc.name}* is closed. Its season is not active.`)
  const isSeasonBoss = locId === season?.dungeon
  const seasonRunNumber = seasonal ? getSeasonRuntime(ctx.db).runNumber : null
  if (isTowerLocation(locId)) {
    const unstaged = party.members
      .map(jid => getPlayer(ctx.db, jid))
      .find(member => !member || member.location !== TOWER_STAGING_LOCATION_ID)
    if (unstaged) {
      return ctx.reply(
        `☣️ The tower’s airlock is sealed against toxic air. Every party member must stage at Wardgate first: ` +
        `*${p}travel ${TOWER_STAGING_LOCATION_ID}*. No one was charged.`,
      )
    }
  }
  if (isSeasonBoss) {
    // The season dungeon is intentionally narrow: a party may only enter it
    // for the End on the party-boss floor, never for the solo floors before it.
    // Fall back to the dungeon's own last floor rather than a hardcoded 50,
    // which stopped being any dungeon's depth when they all became 100 floors.
    const gateFloor = season.partyBossFloor ?? loc.floors ?? 100
    for (const jid of party.members) {
      const member = getPlayer(ctx.db, jid)
      const progress = member?.seasonProgress?.seasonId === season.id ? member.seasonProgress : null
      if (!progress || progress.currentFloor < gateFloor) {
        return ctx.reply(`❌ Everyone must reach Floor ${gateFloor} before the party can challenge the End.`)
      }
    }
  }

  // Validate every member: unlocked, high enough level, and free to enter.
  for (const jid of party.members) {
    const member = getPlayer(ctx.db, jid)
    if (!member) continue
    if (member.inDungeon || member.inBattle) {
      return ctx.reply(`⚠️ *${member.name}* is busy in their own dungeon/battle. Everyone must be free to enter together.`)
    }
    if (!isSeasonBoss && !isDungeonUnlocked(member, locId)) {
      return ctx.reply(`🔒 *${member.name}* hasn't unlocked *${loc.name}* yet, everyone needs it unlocked to climb together.`)
    }
    if (member.level < loc.entryLevel) {
      return ctx.reply(`❌ *${member.name}* is below the required Level ${loc.entryLevel} for *${loc.name}*.`)
    }
  }

  // Gated start floor: begin at the LOWEST member's checkpoint, so a fresh
  // member can never be dropped straight onto a deep floor they never earned.
  // The season boss is fixed to its party-boss floor.
  let startFloor
  if (isSeasonBoss) {
    startFloor = season.partyBossFloor ?? loc.floors ?? 100
  } else {
    const checkpoints = party.members.map(jid =>
      getPlayer(ctx.db, jid)?.dungeonProgress?.[locId]?.highestFloor ?? 0)
    startFloor = Math.max(1, Math.min(...checkpoints))
  }

  // Pre-check that everyone can pay (stamina + travel) WITHOUT mutating — an
  // all-or-nothing entry must not half-charge the members who could afford it.
  for (const jid of party.members) {
    const member = getPlayer(ctx.db, jid)
    if (!member) continue
    const stam = refreshStamina({ ...member.stamina })
    if (stam.current < 1) {
      return ctx.reply(`❌ *${member.name}* has no stamina left. Entry cancelled.`)
    }
    const travelCost = travelTollFor(loc, member)
    if (travelCost > 0 && (member.wallet?.solars ?? 0) < travelCost) {
      return ctx.reply(`❌ *${member.name}* can't afford the *${travelCost} ☀️* travel cost. Entry cancelled.`)
    }
  }

  // Pre-check the daily co-op limit for every member (all-or-nothing). Regular
  // players get PARTY_DAILY_LIMIT runs/day, premium members get the higher cap.
  // A "run" is one dungeon entry; the whole climb that follows is free.
  const today = startOfDay(Date.now())
  for (const jid of party.members) {
    const member = getPlayer(ctx.db, jid)
    if (!member) continue
    const limit = isPremiumActive(member) ? PARTY_DAILY_LIMIT_PREMIUM : PARTY_DAILY_LIMIT
    const usedToday = member.partyRunsDate === today ? (member.partyRunsToday ?? 0) : 0
    if (usedToday >= limit) {
      const isSelf = jid === ctx.from
      const who = isSelf ? 'You have' : `*${member.name}* has`
      const extra = isPremiumActive(member)
        ? ''
        : `\n_Premium members get ${PARTY_DAILY_LIMIT_PREMIUM} party runs a day._`
      return ctx.reply(`❌ ${who} used up today's party runs (${limit}/day). Entry cancelled.${extra}`)
    }
  }

  // A party entry changes the shared roster/run and several player records.
  // Keep its final checks, all charges and fight creation together against
  // joins/leaves and season settlement. Never wait for network I/O in here.
  let refusal = null
  let announcement = null
  await updateAllPlayers(ctx.db, () => {
    if (!isSeasonDungeonEnterable(ctx.db, loc)) {
      refusal = seasonLockdownRefusal(ctx.db) ?? `🌙 *${loc.name}* is closed; nobody was charged.`
      return false
    }
    if (seasonRunNumber !== null &&
        (!isSeasonRunActive(ctx.db, season.id, seasonRunNumber) || !isSeasonLocationAvailable(ctx.db, loc))) {
      refusal = `🌙 *${loc.name}* is closed. Its season is not active; nobody was charged.`
      return false
    }
    const rosterUnchanged = party.members.length === entryMembers.length &&
      party.members.every((jid, index) => jid === entryMembers[index])
    if (findPartyForPlayer(ctx.db, ctx.from) !== party || party.run || party.battle ||
        party.members.length < MIN_PARTY_TO_ENTER || !rosterUnchanged) {
      refusal = `⚠️ The party changed before entry. Nobody was charged; please try again.`
      return false
    }
    if (isTowerLocation(locId) && party.members.some(jid =>
      getPlayer(ctx.db, jid)?.location !== TOWER_STAGING_LOCATION_ID)) {
      refusal = `☣️ The tower’s airlock is sealed against toxic air. Everyone must stage at Wardgate first; nobody was charged.`
      return false
    }
    const commitDay = startOfDay(Date.now())
    for (const jid of party.members) {
      const member = getPlayer(ctx.db, jid)
      const progress = season && member?.seasonProgress?.seasonId === season.id ? member.seasonProgress : null
      const limit = member && (isPremiumActive(member) ? PARTY_DAILY_LIMIT_PREMIUM : PARTY_DAILY_LIMIT)
      const used = member?.partyRunsDate === commitDay ? (member.partyRunsToday ?? 0) : 0
      if (!member || member.inDungeon || member.inBattle || member.level < loc.entryLevel ||
          (isTowerLocation(locId) && member.location !== TOWER_STAGING_LOCATION_ID) ||
          (isSeasonBoss && (!progress || progress.currentFloor < startFloor)) ||
          (!isSeasonBoss && !isDungeonUnlocked(member, locId)) ||
          refreshStamina({ ...member.stamina }).current < 1 ||
          (member.wallet?.solars ?? 0) < travelTollFor(loc, member) || used >= limit) {
        refusal = `⚠️ A party member is no longer ready to enter. Nobody was charged; please check the party and try again.`
        return false
      }
    }
    for (const jid of party.members) chargePartyEntry(getPlayer(ctx.db, jid), loc, commitDay)
    party.run = { locationId: locId, floor: startFloor, startedAt: Date.now() }
    announcement = spawnAndAnnounceFloor(ctx, party, { first: true })
    // It is awaited after the barrier; mark an early send failure as handled
    // while the database flush is still in flight.
    announcement.catch(() => {})
    return true
  })
  if (refusal) return ctx.reply(refusal)
  await announcement
}

// ── Spawn + announce one floor of the climb ───────────────────────────────
// Shared by enterDungeon (first floor) and handleNext (every floor after). The
// caller has already charged stamina and set inBattle=true on the members
// joining this floor; this reads that to size the enemy and drive the announce.
// Tears the run down and returns false if no enemy could spawn.
async function spawnAndAnnounceFloor(ctx, party, { first = false } = {}) {
  const p = config.prefix
  const { locationId: locId, floor } = party.run
  const loc = locationsMap[locId]
  // "Present" = standing in the party fight AND not mid-solo-fight. inBattle
  // is shared between solo and party combat, so a member's solo battleState
  // is the discriminator: their true inBattle flag belongs to the solo fight
  // and must not size the party enemy, join the turn order, or bank floors.
  const present = party.members.filter(m => {
    const pl = getPlayer(ctx.db, m)
    return pl?.inBattle && !pl.battleState
  })
  const memberCount = present.length || 1

  const presentPlayers = present.map(m => getPlayer(ctx.db, m)).filter(Boolean)
  const anchorPlayer = presentPlayers.reduce(
    (best, pl) => (best && getPrimaryStat(best) >= getPrimaryStat(pl) ? best : pl),
    null,
  )
  const enemy = spawnPartyEnemy(locId, floor, memberCount, anchorPlayer)
  // Level-100+ difficulty tier (see applyVeteranScaling). A co-op floor is
  // sized from the HIGHEST present level, not the average: a level 200 player
  // carrying two friends is still a level 200 fight, and averaging would let
  // one low-level alt quietly halve the tier for the whole party.
  const veteranAnchor = presentPlayers.reduce(
    (best, pl) => (best && (best.level ?? 0) >= (pl.level ?? 0) ? best : pl),
    null,
  )
  if (veteranAnchor) applyVeteranScaling(enemy, veteranAnchor)
  if (enemy && loc?.realm !== 'dreamlands') {
    const rank = Math.max(0, ...present.map(m => endlessState(getPlayer(ctx.db, m), ctx.db).index))
    applyEndlessRank(enemy, rank)
  }
  if (enemy) limitDungeonHp(enemy)
  if (!enemy) {
    for (const jid of party.members) await updatePlayer(ctx.db, jid, async m => {
      if (!m.battleState) { m.inBattle = false; clearBeastEffects(m) }
      return m
    })
    party.run = null
    party.battle = null
    await ctx.reply(`❌ No monsters found for Floor ${floor} of *${loc?.name ?? locId}*. The climb ends.`)
    return false
  }

  party.battle = {
    locationId: locId,
    floor,
    seasonRunNumber: isSeasonalLocation(loc) ? getSeasonRuntime(ctx.db).runNumber : null,
    enemy,
    contributions: {}, // jid -> total damage dealt
    // Per-member, once-per-battle character-ability flags (Mei's Final Form,
    // Wither's Cinder Verdict). Party fights don't use player.battleState, so
    // these stand in for it — discarded with each floor's battle object, so
    // they reset every floor for free, same as solo battleState flags.
    charState: Object.fromEntries(present.map((jid) => [jid, { turn: 1 }])),
    // Fixed round-robin turn order, captured from the members present on this
    // floor. Actions are gated to turnOrder[turnIndex]; advancePartyTurn moves
    // the cursor after each action, skipping members who've fallen.
    turnOrder: present.slice(),
    turnIndex: 0,
    startedAt: Date.now(),
    // The turn clock counts from here (lib/party-clock.js). advancePartyTurn
    // re-stamps it after every action.
    turnStartedAt: Date.now(),
  }

  armPartySurvival(party.battle, expectedLevelAtFloor(locId, floor))
  const totalFloors = loc?.floors ?? 0
  // Full boss reveal for the season End OR any dungeon's true final floor (the
  // conquest boss). Every other boss floor gets the normal inline boss tag.
  const isFinalBoss = enemy.isBoss && (locId === getActiveSeason(ctx.db)?.dungeon || (totalFloors > 0 && floor >= totalFloors))
  const formationText = partyFormationReadout(party.battle)
  if (formationText) await ctx.reply(formationText)
  const tierTag = enemy.isBoss ? ' _(Boss)_' : enemy.tier === 'elite' ? ' _(Elite ⭐)_' : ''

  let msg = isFinalBoss
    ? `╔═══ 👑 *THE FINAL BOSS* ═══╗\n\n`
    : first
      ? `╔═══ ⚔️ *PARTY CLIMB* ═══╗\n\n`
      : `╔═══ ⬇️ *FLOOR ${floor}* ═══╗\n\n`
  msg += `📍 *${loc?.name ?? locId}* — Floor ${floor}${totalFloors ? `/${totalFloors}` : ''}\n`
  msg += `👥 Party (${present.length}): ${present.map(m => nameFor(ctx.db, m)).join(', ')}\n`
  const vetLine = veteranBanner(veteranAnchor)
  if (vetLine) msg += `${vetLine}\n`
  msg += `\n`
  if (isFinalBoss) {
    // Full reveal — conquest title, lore, HP, and the loot on the line.
    msg += `${enemy.emoji ?? '👑'} *${enemy.name}*`
    if (enemy.conquestTitle) msg += ` — _"${enemy.conquestTitle}"_`
    msg += `\n`
    if (enemy.description) msg += `_${enemy.description}_\n`
    msg += `\n❤️ ${hpBar(enemy.hp, enemy.maxHp)} *(${finiteNumber(enemy.maxHp,0).toLocaleString()} HP)*\n`
    msg += `⚔️ ATK: *${enemy.atk}*  🛡️ DEF: *${enemy.def}*\n`
    const dropNames = (enemy.drops ?? [])
      .map(d => allItems.find(i => i.id === d.itemId)?.name ?? d.itemId)
    if (dropNames.length) msg += `🎁 *On the line:* ${dropNames.join(', ')}\n`
    msg += `\n_This is the last floor. There is no fleeing — the whole party must break it together._\n`
  } else {
    msg += `${enemy.emoji ?? '👾'} *${enemy.name}*${tierTag} appears!\n`
    msg += `❤️ ${hpBar(enemy.hp, enemy.maxHp)}\n`
    msg += `⚔️ ATK: *${enemy.atk}*  🛡️ DEF: *${enemy.def}*\n\n`
  }
  // Fixed turn order: show the queue and whose turn is first. If it's not your
  // turn you can't act, so the party always knows who's up.
  if (party.battle.turnOrder?.length) {
    const order = party.battle.turnOrder
      .map((m, i) => `${i === (party.battle.turnIndex ?? 0) ? '▶️' : `${i + 1}.`} ${nameFor(ctx.db, m)}`)
      .join('  ')
    msg += `🎯 *Turn order:* ${order}\n`
    msg += `_Take turns. If it isn't your turn, you can't act. Each turn has a 90 second clock: go quiet and your guard goes up and the fight moves on._\n`
  }
  // battleFlee() rejects .dparty flee against ANY boss, so the footer only
  // advertises flee on regular (non-boss) floors.
  msg += enemy.isBoss
    ? `*${p}dparty attack* (or *${p}pattack*) · *${p}dparty defend*\n`
    : `*${p}dparty attack* (or *${p}pattack*) · *${p}dparty defend* · *${p}dparty flee*\n`
  msg += `_🔥 Wither: *${p}dparty cv* · 🌸 Mei's Final Form triggers automatically below 70% HP._`

  await ctx.reply(msg)
  return true
}

// ── .dparty next — leader descends the party to the next floor ─────────────
async function handleNext(ctx) {
  const p = config.prefix
  const party = findPartyForPlayer(ctx.db, ctx.from)
  if (!party) return ctx.reply(`❌ You're not in a party.`)
  if (!samePlayer(ctx.db, party.leaderId, ctx.from)) return ctx.reply(`❌ Only the party leader can descend to the next floor.`)
  if (party.battle) return ctx.reply(`⚔️ Finish the current floor first — *${p}dparty attack*.`)
  if (!party.run) return ctx.reply(`❌ Your party isn't climbing. Use *${p}dparty enter <dungeonId>* to start.`)

  const locId = party.run.locationId
  const loc = locationsMap[locId]
  const floor = party.run.floor
  if (!loc) { party.run = null; return ctx.reply(`❌ Location data missing. The climb ends.`) }
  if (!isSeasonDungeonEnterable(ctx.db, loc)) {
    return ctx.reply(seasonLockdownRefusal(ctx.db) ?? `🌙 This seasonal dungeon is closed. Your progress is safe; use *${p}dparty leave* to stop the climb.`)
  }

  const seasonal = isSeasonalLocation(loc)
  const season = seasonal ? getActiveSeason(ctx.db) : null
  if (seasonal && !season) return ctx.reply(`🌙 This seasonal dungeon is closed. Use *${p}dparty leave* to stop the climb.`)
  const seasonRunNumber = seasonal ? getSeasonRuntime(ctx.db).runNumber : null
  const run = party.run
  let refusal = null
  let announcement = null
  let anyReady = false
  const rested = []

  // A floor start changes the shared battle and multiple players. Serialize
  // it with both membership changes and season settlement for every dungeon,
  // so a concurrent disband/leave or second .next cannot charge a ghost party.
  await updateAllPlayers(ctx.db, () => {
    if (!isSeasonDungeonEnterable(ctx.db, loc)) {
      refusal = seasonLockdownRefusal(ctx.db) ?? `🌙 This dungeon is closed. Nobody was charged; use *${p}dparty leave* to stop the climb.`
      return false
    }
    if (seasonal &&
        (!isSeasonRunActive(ctx.db, season.id, seasonRunNumber) || !isSeasonLocationAvailable(ctx.db, loc))) {
      refusal = `🌙 This seasonal dungeon is closed. Nobody was charged; use *${p}dparty leave* to stop the climb.`
      return false
    }
    if (findPartyForPlayer(ctx.db, ctx.from) !== party || party.run !== run || party.battle ||
        !samePlayer(ctx.db, party.leaderId, ctx.from)) {
      refusal = `⚠️ The party's climb changed. Nobody was charged; please try again.`
      return false
    }
    for (const jid of party.members) {
      const member = getPlayer(ctx.db, jid)
      // A live solo battle owns inBattle; do not change or charge that player.
      if (!member || member.battleState) continue
      member.stamina = refreshStamina(member.stamina)
      if (member.stamina.current < 1) {
        member.inBattle = false
        rested.push(jid)
        continue
      }
      member.stamina.current -= 1
      if (member.ultraInstinct) member.ultraInstinct.partyAwakening = false
      member.inBattle = true
      anyReady = true
    }
    if (!anyReady) party.run = null
    else {
      announcement = spawnAndAnnounceFloor(ctx, party)
      announcement.catch(() => {})
    }
    return true
  })
  if (refusal) return ctx.reply(refusal)
  if (!anyReady) {
    return ctx.reply(
      `⚡ *Nobody is ready for the next floor.* The party rests — progress is saved at Floor ${floor}.\n` +
      `_Return with *${p}dparty enter ${locId}* when the party is ready._`,
    )
  }
  if (rested.length) {
    await ctx.reply(`😮‍💨 _${rested.map(j => nameFor(ctx.db, j)).join(', ')} ${rested.length === 1 ? 'is' : 'are'} out of stamina and sit${rested.length === 1 ? 's' : ''} this floor out._`)
  }
  await announcement
}

// ── Alpha's Garden Call in a shared co-op battle ───────────────────────────
export async function battleGarden(ctx) {
  ctx = partyContext(ctx)
  const party = findPartyForPlayer(ctx.db, ctx.from)
  if (!party?.battle) return ctx.reply('🌑 There is no party fight to call the Garden into.')
  const notTurn = await notYourTurn(ctx, party)
  if (notTurn) return ctx.reply(notTurn)
  let msg = ''
  let refused = false
  let down = false
  let victory = false
  let scene = null
  await updatePlayer(ctx.db, ctx.from, player => {
    const battle = party.battle
    const e = battle.enemy
    battle.charState = battle.charState ?? {}
    const cs = battle.charState[ctx.from] = battle.charState[ctx.from] ?? { turn: 1 }
    const gate = canCallGarden(player, cs)
    if (!gate.ok) { refused = true; msg = gate.message; return player }
    const hpBeforeTurn = player.hp
    const eHpBeforeTurn = e.hp
    const boss = !!e.isBoss
    if (boss) withBossBattleStateFor(cs)(player, e, bp => {
      incrementBossTurn(bp)
      const start = applyBossSpecial(bp, EVENT.TURN_START, {})
      if (start.narrativeLine) msg += start.narrativeLine + '\n'
    })
    const sever = tickPermanentSever(player)
    if (sever) msg += sever + '\n'
    // The Starfall champion package reads the foe off the per-member state;
    // lend it the real enemy record for the length of the tick, then take
    // it back so the serialized charState never carries a copy of it.
    if (battle?.enemy) cs.enemy = battle.enemy
    const status = processStatusTurn(player, { battleState: cs })
    delete cs.enemy
    if (status.lines.length) msg += status.lines.join('\n') + '\n'
    if (player.hp <= 0) { down = true; return player }
    msg += applyPartyBeastTurn(player, battle, cs, ctx.from)
    if (e.hp <= 0) { victory = true; return player }
    if (status.incapacitated) {
      msg += `💫 *${player.name}* cannot call the Garden this turn.\n`
    } else {
      const before = e.hp
      const result = callGarden(player, e, cs)
      msg += result.message + '\n'
      battle.contributions[ctx.from] = (battle.contributions[ctx.from] ?? 0) + before - e.hp
    }
    if (e.hp <= 0) { victory = true; return player }
    const enemyStatus = processStatusTurn(e)
    if (enemyStatus.lines.length) msg += enemyStatus.lines.join('\n') + '\n'
    if (e.hp <= 0) { victory = true; return player }
    if (graceHoldsEnemyTurn(player, cs)) {
      msg += `${graceEnemyHeldLine(e, player, cs)}\n`
    } else if (!enemyStatus.incapacitated && (boss || Math.random() <= calcMonsterHitChance(e, player))) {
      let raw = e.atk
      if (boss) withBossBattleStateFor(cs)(player, e, bp => {
        const attack = buildEnemyAttack(bp)
        const dealt = applyBossSpecial(bp, EVENT.ENEMY_DEAL_DAMAGE, { damage: attack.damage, isHit: true })
        raw = dealt.modified && dealt.damage !== undefined ? dealt.damage : attack.damage
      })
      const dmg = calcMonsterDamage(raw, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), false)
      const applied = applyPartyIncoming(player, dmg, cs, e, battle, ctx.from)
      msg += applyPartyHpDamage(player, applied.damage, cs)
      msg += `${e.emoji ?? '👾'} *${e.name}* answers for *${applied.damage}* damage!\n`
      if (applied.message) msg += applied.message + '\n'
    } else msg += `💨 *${e.name}* cannot land a counter.\n`
    down = player.hp <= 0
    victory = e.hp <= 0
    scene = { player, e, hpBeforeTurn, eHpBeforeTurn, boss }
    return player
  })
  if (refused) return ctx.reply(msg)
  if (scene && !victory) await sendBattleTurnReply(ctx, { ...scene, msg })
  else if (msg) await ctx.reply(msg.trim())
  if (victory) return resolvePartyVictory(ctx, party)
  await karrenPartyPulse(ctx, party)
  if (down) await handlePartyMemberDown(ctx, party, ctx.from)
  if (party.battle) { advancePartyTurn(ctx.db, party); const formationText=partyFormationReadout(party.battle); if(formationText) await ctx.reply(formationText) }
}

// ── 🏛️ Victoria Minayoko's Sanctum Victoriae in a shared co-op battle ──────
// `.dparty victory [@ally ...]` (or `.victory` during a party fight). She claims
// the ground for herself and names anyone she wants "under Victoria's roof".
// Each named member's shelter is stamped on THEIR OWN party state (lib/victoria.js
// shelterUnderSanctum), so applyPartyIncoming() and the boss engine answer for
// them without ever reading her record. Raising it is the whole turn; the enemy's
// answer to it lands on the Sanctum like everything else for the next ten turns.
export async function battleVictory(ctx) {
  ctx = partyContext(ctx)
  const party = findPartyForPlayer(ctx.db, ctx.from)
  if (!party?.battle) return ctx.reply('🏛️ There is no party fight to raise the Sanctum in.')
  const notTurn = await notYourTurn(ctx, party)
  if (notTurn) return ctx.reply(notTurn)
  const content = normalizeMessageContent(ctx.msg?.message) ?? ctx.msg?.message
  const named = (content?.extendedTextMessage?.contextInfo?.mentionedJid ?? [])
    .map(jid => partyMemberId(ctx.db, party, jid))
    .filter(jid => jid && jid !== ctx.from)
  let msg = ''
  let refused = false
  let down = false
  let victory = false
  let scene = null
  const sheltered = []
  await updatePlayer(ctx.db, ctx.from, player => {
    const battle = party.battle
    const e = battle.enemy
    battle.charState = battle.charState ?? {}
    const cs = battle.charState[ctx.from] = battle.charState[ctx.from] ?? { turn: 1 }
    const boss = !!e.isBoss
    const gate = canRaiseSanctum(player, { bs: cs, boss })
    if (!gate.ok) { refused = true; msg = gate.message; return player }
    const hpBeforeTurn = player.hp
    const eHpBeforeTurn = e.hp
    if (boss) withBossBattleStateFor(cs)(player, e, bp => {
      incrementBossTurn(bp)
      const start = applyBossSpecial(bp, EVENT.TURN_START, {})
      if (start.narrativeLine) msg += start.narrativeLine + '\n'
    })
    const sever = tickPermanentSever(player)
    if (sever) msg += sever + '\n'
    // The Starfall champion package reads the foe off the per-member state;
    // lend it the real enemy record for the length of the tick, then take
    // it back so the serialized charState never carries a copy of it.
    if (battle?.enemy) cs.enemy = battle.enemy
    const status = processStatusTurn(player, { battleState: cs })
    delete cs.enemy
    if (status.lines.length) msg += status.lines.join('\n') + '\n'
    if (player.hp <= 0) { down = true; return player }
    msg += applyPartyBeastTurn(player, battle, cs, ctx.from)
    if (e.hp <= 0) { victory = true; return player }
    if (status.incapacitated) {
      msg += `💫 *${player.name}* cannot claim the ground this turn.\n`
    } else {
      const raised = raiseSanctum(player, { bs: cs, boss })
      if (raised.ok) {
        msg += raised.lines.join('\n') + '\n'
        // Only members standing in THIS fight can be named under her roof.
        const inFight = new Set(battle.turnOrder?.length ? battle.turnOrder : (party.members ?? []))
        for (const jid of named) {
          if (!inFight.has(jid) || sheltered.includes(jid)) continue
          const allyCs = battle.charState[jid] = battle.charState[jid] ?? { turn: 1 }
          msg += shelterUnderSanctum(allyCs, { name: nameFor(ctx.db, jid) }, { by: player.name }) + '\n'
          raised.record.sheltered.push(jid)
          sheltered.push(jid)
        }
      } else {
        msg += raised.message + '\n'
      }
    }
    const enemyStatus = processStatusTurn(e)
    if (enemyStatus.lines.length) msg += enemyStatus.lines.join('\n') + '\n'
    if (e.hp <= 0) { victory = true; return player }
    if (graceHoldsEnemyTurn(player, cs)) {
      msg += `${graceEnemyHeldLine(e, player, cs)}\n`
    } else if (!enemyStatus.incapacitated && (boss || Math.random() <= calcMonsterHitChance(e, player))) {
      let raw = e.atk
      if (boss) withBossBattleStateFor(cs)(player, e, bp => {
        const attack = buildEnemyAttack(bp)
        const dealt = applyBossSpecial(bp, EVENT.ENEMY_DEAL_DAMAGE, { damage: attack.damage, isHit: true })
        raw = dealt.modified && dealt.damage !== undefined ? dealt.damage : attack.damage
      })
      const dmg = calcMonsterDamage(raw, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), false)
      const applied = applyPartyIncoming(player, dmg, cs, e, battle, ctx.from)
      msg += applyPartyHpDamage(player, applied.damage, cs)
      msg += `${e.emoji ?? '👾'} *${e.name}* answers for *${applied.damage}* damage!\n`
      if (applied.message) msg += applied.message + '\n'
    } else msg += `💨 *${e.name}* cannot land a counter.\n`
    down = player.hp <= 0
    victory = e.hp <= 0
    scene = { player, e, hpBeforeTurn, eHpBeforeTurn, boss }
    return player
  })
  if (refused) return ctx.reply(msg)
  // The threshold wash for each named ally, in their own write (never nested).
  for (const jid of sheltered) {
    await updatePlayer(ctx.db, jid, ally => { cleanseUnderSanctum(ally); return ally })
  }
  if (scene && !victory) await sendBattleTurnReply(ctx, { ...scene, msg })
  else if (msg) await ctx.reply(msg.trim())
  if (victory) return resolvePartyVictory(ctx, party)
  await karrenPartyPulse(ctx, party)
  if (down) await handlePartyMemberDown(ctx, party, ctx.from)
  if (party.battle) { advancePartyTurn(ctx.db, party); const formationText=partyFormationReadout(party.battle); if(formationText) await ctx.reply(formationText) }
}

// A summon's clocks belong to the acting member, not the shared enemy. All
// committed party turns use this helper, so the same summon works alongside
// character moves as well as basic attacks and defend.
function applyPartyBeastTurn(player, battle, cs, jid) {
  const e = battle.enemy
  let godText = ''
  if (battleGodReady(player, 'alenious') && e?.hp > 0) {
    const before = e.hp
    godText = withGodHostState(player, cs, e, () => godPveTurn({
      player, enemy: e, turnId: cs.turn ?? 1, boss: Boolean(e.bossState), mode: 'party',
    })).join('\n')
    if (godText) godText += '\n'
    battle.contributions ??= {}
    battle.contributions[jid] = (battle.contributions[jid] ?? 0) + Math.max(0, before - e.hp)
    if (e.hp <= 0) return godText
  }
  // ⚡ Minato — Flying Thunder God. A party member has no battleState and never
  // reaches processStatusTurn(), which is where the technique's clock ticks in
  // every solo fight (lib/combat-handlers.js). This helper is the one thing
  // every committed party turn already calls, so the seal lands and a flash is
  // announced here, on the acting member's own per-battle state and their own
  // turn counter. '' for everyone without him equipped.
  const flash = minatoTurnTick(player, cs, { enemyName: e?.name })
  const flashText = godText + (flash ? flash + '\n' : '')
  const result = beastIntervention(player, BEAST_EVENT.TURN_START, { enemy: e, bs: cs, dungeon: true, turnId: cs.turn ?? 1 })
  if (!result.modified) return flashText
  const dealt = Math.min(Math.max(0, e.hp), Math.max(0, result.bonusDamage ?? 0))
  e.hp = Math.max(0, e.hp - dealt)
  if (dealt > 0) battle.contributions[jid] = (battle.contributions[jid] ?? 0) + dealt
  return flashText + result.lines.join('\n') + '\n'
}

// ── Party battle: attack ─────────────────────────────────────────────────
// Resolve a hit that lands on a party member. Gojo's Infinity thins the strike
// before it arrives (a no-op for anyone else); Mei's sustain catches an
// otherwise-lethal blow. A player has exactly one equipped character, so at most
// one of the two ever fires. They compose in the order damage actually resolves
// — Infinity slows the strike first, then Mei's seal decides whether to catch
// what is left — and this returns the same { damage, message } shape every
// retaliation site below already consumes, with any Infinity line folded in.
function applyPartyGrudge(target, dealt, cs, enemy) {
  const grudge = chargeGrudge(target, Math.min(target.hp ?? 0, Math.max(0, dealt)), cs)
  if (grudge?.returnDamage && enemy?.hp > 0) enemy.hp = Math.max(0, enemy.hp - grudge.returnDamage)
  const meter = target.equippedCharacter === 'delta' ? grudgeStatus({ ...target, battleState: cs }) : ''
  return [grudge?.message, meter].filter(Boolean).join('\n')
}

function applyPartyIncoming(target, rawDamage, cs, enemy = null, battle = null, memberId = target?.id) {
  if (battleGodReady(target, 'alenious') && enemy && rawDamage > 0) {
    const before = enemy.hp
    const answer = withGodHostState(target, cs, enemy, () =>
      rewriteGodHostHit(target, enemy, rawDamage) ??
      interceptHeartStrike({ player: target, attacker: enemy, damage: rawDamage, turn: cs.turn ?? 1 }) ??
      godHeartGuard(target, rawDamage, cs.turn ?? 1))
    if (battle && answer) {
      battle.contributions ??= {}
      battle.contributions[memberId] = (battle.contributions[memberId] ?? 0) + Math.max(0, before - enemy.hp)
    }
    if (answer?.blocked || answer?.redirected) return answer
    if (answer) rawDamage = answer.damage
  }
  // 🏛️ Victoria Minayoko's Sanctum, on whoever is struck: her own, or the
  // shelter of an ally she named. Ahead of everything, nothing pierces it.
  if (sanctumShields(target, cs)) {
    return { damage: 0, message: sanctumBreakLine(target), catFormDefeated: false }
  }
  // 👑 King Yato — Grace of the Crown. Party damage never reaches
  // applyIncomingDamage(), so both halves of the grace are enforced here on the
  // struck member's own per-battle state: turns 1-5 nothing arrives at all,
  // from turn 6 every blow is 30% lighter.
  if (graceHoldsEnemyTurn(target, cs)) {
    return { damage: 0, message: graceHoldLine(target, cs), catFormDefeated: false }
  }
  // ⚡ Minato — Flying Thunder God, the party twin of the check in
  // applyIncomingDamage() (party damage never reaches that funnel). On a flash
  // turn the first blow that would have landed on his owner is dodged, before
  // a beast, a shield or Mei's sustain can spend itself on a hit that never
  // arrived. Read off the STRUCK member's own state, so a retaliation that was
  // redirected onto them is answered by their Minato, not the attacker's.
  const flash = rollFlyingThunderGodDodge(target, cs, { damage: rawDamage })
  if (flash.dodged) {
    return { damage: 0, message: flash.message, catFormDefeated: false, dodged: true }
  }
  // 🌋 Surtr — Twilight, the party twin of the check in applyIncomingDamage()
  // (party damage never reaches that funnel). While the transformation runs the
  // first blow of each turn is swallowed by the colossus and handed back as
  // heat. Read off the STRUCK member's own state, like the flash above.
  const twilight = resolveTwilightGuard(target, Math.max(0, Number(rawDamage) || 0), cs)
  if (twilight.blocked) {
    return { damage: 0, message: twilight.message, catFormDefeated: false }
  }
  const formation = formationIncoming(battle, memberId, rawDamage)
  rawDamage = formation.damage
  const graceCut = graceReduce(target, Math.max(0, Number(rawDamage) || 0), cs)
  rawDamage = graceCut.damage
  // The defender has their own beast state, even when another party member
  // drew this retaliation. A Last Stand can also hit the shared enemy here.
  const enemyHpBefore = Math.max(0, Number(enemy?.hp) || 0)
  const beast = beastIntervention(target, BEAST_EVENT.ENEMY_DEAL_DAMAGE, {
    enemy, bs: cs, damage: rawDamage, dungeon: true,
  })
  const counterDamage = Math.max(0, enemyHpBefore - Math.max(0, Number(enemy?.hp) || 0))
  if (battle && memberId && counterDamage > 0) {
    battle.contributions = battle.contributions ?? {}
    battle.contributions[memberId] = (battle.contributions[memberId] ?? 0) + counterDamage
  }
  if (beast.modified && beast.damage !== undefined) rawDamage = beast.damage
  const beforeShield = Math.max(0, Number(rawDamage) || 0)
  const instinct = absorbInstinctAttack(target, beforeShield, enemy)
  const afterShield = instinct.damage
  const infinity = applyInfinity(target, afterShield)
  const sustain = applyMeiSustainHeal(target, infinity.damage, cs)
  const shieldLine = !instinct.dodged && afterShield < beforeShield
    ? `🛡️✨ *${beforeShield - afterShield}* damage absorbed before it reached you.`
    : ''
  const message = [
    formation.message,
    graceCut.message,
    ...(beast.lines ?? []),
    instinct.dodged ? '💨 *Ultra Instinct!* Attack dodged.' : '',
    shieldLine,
    infinity.message,
    sustain.message,
    applyPartyGrudge(target, sustain.damage, cs, enemy),
  ].filter(Boolean).join('\n')
  return { ...sustain, message }
}

/** 📖 Karren, the Archivist — once per HER turn, the most-wounded living member
 * in the fight is corrected by 12% of her max HP. Member health is only knowable
 * outside the per-member mutator, so the mend runs after it, like the down-
 * resolution below it. Her turn is any turn where she is the actor. */
export async function karrenPartyPulse(ctx, party) {
  if (!party?.battle) return false
  const karren = getPlayer(ctx.db, ctx.from)
  if (karren?.equippedCharacter !== KARREN_ID) return false
  if (karren.inBattle === false) return false
  let targetId = null
  let worst = Infinity
  for (const jid of party.members ?? []) {
    const member = getPlayer(ctx.db, jid)
    // No mends for the dead — a member who fell this turn reads 0 HP until the
    // down-resolution runs, and healing a corpse is not an act of support.
    if (!member || member.inBattle === false || (member.hp ?? 0) <= 0) continue
    const frac = (member.hp ?? 0) / Math.max(1, member.maxHp ?? 1)
    if (frac < worst) { worst = frac; targetId = jid }
  }
  if (!targetId) return false
  const amount = Math.max(1, Math.floor((karren.maxHp ?? 1) * 0.12))
  let healed = 0
  await updatePlayer(ctx.db, targetId, member => {
    const before = member.hp ?? 0
    member.hp = Math.min(member.maxHp ?? 1, before + amount)
    healed = member.hp - before
    return member
  })
  if (healed > 0) {
    const target = getPlayer(ctx.db, targetId)
    await ctx.reply(`📖 *The Archivist's Pages.* Karren corrects the record — *${healed} HP* restored to *${target?.name ?? 'an ally'}*.`)
  }
  return healed > 0
}

/** Apply party-mode HP loss and run the same Starter Relic reactions as solo combat. */
function applyPartyHpDamage(target, damage, cs) {
  const previousHp = Math.max(0, Number(target?.hp) || 0)
  let dmg = Math.max(0, Number(damage) || 0)
  const starLines = []
  // ⛪ Sanctuary — while the Burning Cathedral stands, no struck hit may
  // carry its holder below 1 HP. Refused, not resisted.
  if (hasEffect(target, 'cathedral') && previousHp > 0 && dmg >= previousHp) {
    dmg = Math.max(0, previousHp - 1)
    starLines.push('⛪ *Sanctuary.* The cathedral refuses the falling.')
  }
  // 🪽 Ha-neul — 35% of every struck blow is lifted off the target and stored
  // as Weight on her owner's tether.
  const haneulCut = haNeulAbsorb(target, dmg, cs)
  if (haneulCut.absorbed > 0) {
    dmg -= haneulCut.absorbed
    starLines.push(...haneulCut.lines)
  }
  // ⛪ Ledger of Flame — struck damage written into the domain's tally.
  if (cs?.cathedral && previousHp - Math.min(previousHp, dmg) > 0) {
    cs.cathedral.dealtByEnemy = Math.max(0, Number(cs.cathedral.dealtByEnemy) || 0) + Math.min(previousHp, dmg) + haneulCut.absorbed
  }
  target.hp = Math.max(0, previousHp - dmg)
  const refusal = godDeathRefusal(target, cs)
  if (refusal) return starLines.concat(refusal).join('\n') + '\n'
  const lines = applyStarterRelicsAfterDamage(target, previousHp, Date.now(), cs).lines
  const all = starLines.concat(lines)
  return all.length ? `${all.join('\n')}\n` : ''
}

async function battleAttack(ctx) {
  ctx = partyContext(ctx)
  const p = config.prefix
  const party = findPartyForPlayer(ctx.db, ctx.from)
  if (!party) return ctx.reply(`❌ You're not in a party.`)
  if (!party.battle) return ctx.reply(`❌ Your party isn't in a battle. Use *${p}dparty enter <dungeon>*.`)

  // Fixed turn order: only the member at the cursor may act this round.
  const notTurn = await notYourTurn(ctx, party)
  if (notTurn) return ctx.reply(notTurn)

  // The mutator below only mutates state and records the outcome — no network
  // I/O or nested updatePlayer. The single-writer queue is shared even across
  // different players, so a redirected enemy hit must run after this write.
  // Sends are queued in `outbox` and flushed once
  // updatePlayer settles, and victory / member-down resolution happens there
  // too — the same discipline battleDefend already followed. This is also
  // THE fix for the "your party is already in a battle even though the battle
  // is over" reports: the old code resolved victory INSIDE the mutator, the
  // nested write deadlocked the lane, and party.battle was never cleared.
  let outbox = []
  let victoryPending = false
  let downJid = null
  let redirectedHit = null

  await updatePlayer(ctx.db, ctx.from, async player => {
    const battle = party.battle
    const e = battle.enemy

    const eHpBeforeTurn = e.hp
    const boss = e.isBoss ?? false

    // Per-member, once-per-battle character-ability flags stand in for
    // player.battleState here (party fights don't use it) — see the
    // party.battle.charState note in enterDungeon().
    battle.charState = battle.charState ?? {}
    const cs = battle.charState[ctx.from] = battle.charState[ctx.from] ?? {}

    let pre = ''

    // Urahara's permanent Tear — action-triggered tick, same as every other
    // combat entry point (attack.js / pvp.js / cinderverdict.js).
    const permaSeverLine = tickPermanentSever(player)
    if (permaSeverLine) pre += permaSeverLine + '\n'
    if (player.hp <= 0) {
      if (pre) outbox.push({ text: pre })
      downJid = ctx.from
      return player
    }

    // Mei's Final Form — automatic at ≤70% HP, once per battle.
    const finalForm = activateFinalForm(player, cs)
    if (finalForm.ok) {
      pre += finalForm.message + '\n'
      void sendFinalFormVideo(ctx, finalForm.message, ctx.sender).catch(() => {})
    }

    // Orihime — Shun Shun Rikka (turn-start heal + one rejection per battle).
    const rikka = tickShunShunRikka(player, cs)
    if (rikka) pre += rikka.message + '\n'

    // Beth — Mend & Reinforce (turn-start armor repair + HP heal).
    const bethMend = tickBethMend(player, cs)
    if (bethMend) pre += bethMend.message + '\n'

    // Clane — Crimson Hunger. A party turn is the acting member's own turn, so
    // the shared enemy is bitten and the acting member pays the Toll, exactly
    // as she does on a solo turn. The bite is credited to the enemy's HP, not
    // to the member's damage contribution (it is an ambient aura, not a hit),
    // but a floor it clears is still the party's floor: the victoryPending path
    // below is the same one a DOT tick uses.
    const claneFeed = tickClaneDrain(player, e)
    if (claneFeed) {
      pre += claneFeed.message + '\n'
      if (claneFeed.reboundDamage > 0) {
        player.hp = Math.max(0, (player.hp ?? 0) - claneFeed.reboundDamage)
      }
      if (e.hp <= 0) {
        outbox.push({ text: pre + `\n${e.emoji ?? '👾'} *${e.name}* succumbs to its wounds!` })
        victoryPending = true
        return player
      }
      if (player.hp <= 0) {
        outbox.push({ text: pre })
        downJid = ctx.from
        return player
      }
    }

    pre += applyPartyBeastTurn(player, battle, cs, ctx.from)
    if (e.hp <= 0) {
      outbox.push({ text: pre + `\n${e.emoji ?? '👾'} *${e.name}* falls to the summon!` })
      victoryPending = true
      return player
    }

    // Tick the enemy's own DOTs (e.g. Urahara's Tear/Reshape bleed) so party
    // fights honour status effects the same way solo/PvP turns do.
    const enemyStatus = processStatusTurn(e)
    if (enemyStatus.lines.length) pre += enemyStatus.lines.join('\n') + '\n'
    if (e.hp <= 0) {
      outbox.push({ text: pre + `\n${e.emoji ?? '👾'} *${e.name}* succumbs to its wounds!` })
      victoryPending = true
      return player
    }

    const endHit = applyEndMonsterTurn(player, e, { battleState: battle, turnId: battle.turn ?? 1 })
    if (endHit.triggered) {
      pre += endHit.message + '\n'
      battle.contributions[ctx.from] = (battle.contributions[ctx.from] ?? 0) + endHit.damage
      if (e.hp <= 0) {
        outbox.push({ text: pre })
        victoryPending = true
        return player
      }
    }

    // ── Boss: increment turn counter + TURN_START event ─────────────────────
    // Mirrors attack.js's turn-start boss-engine hook (Jotaro's Time Stop,
    // narrative turn-start lines, etc.) via the withBossBattleState bridge —
    // see its doc comment above spawnPartyEnemy for why this is needed.
    if (boss) {
      withBossBattleStateFor(cs)(player, e, bp => {
        incrementBossTurn(bp)
        const tsResult = applyBossSpecial(bp, EVENT.TURN_START, {})
        if (tsResult.narrativeLine) pre += `_${tsResult.narrativeLine}_\n`
      })
      if (e.hp <= 0) {
        outbox.push({ text: pre })
        victoryPending = true
        return player
      }
    }

    if (Math.random() > calcPlayerHitChance(player, e, cs)) {
      let missMsg = pre + `💨 *${player.name}* attacks *${e.name}*... and *MISSES!*`
      if (boss) {
        withBossBattleStateFor(cs)(player, e, bp => {
          const missResult = applyBossSpecial(bp, EVENT.PLAYER_MISS, { isMiss: true })
          missMsg += `\n💬 _"${getBossDodgeLine(bp)}"_`
          if (missResult.narrativeLine) missMsg += `\n_${missResult.narrativeLine}_`
        })
      }
      outbox.push({ turn: {
        player, e, msg: missMsg,
        hpBeforeTurn: player.hp, eHpBeforeTurn, boss,
      } })
      return player
    }

    const { rawDmg, isCrit } = calcPlayerDamage(
      player,
      null,
      1,
      0,
      { battleState: cs },
    )
    let finalDmg = applyDefense(rawDmg, getEffectiveStat(e, 'def'), player, e, cs)

    let msg = pre
    if (boss) {
      // PLAYER_BASIC_ATTACK + ENEMY_TAKE_DAMAGE — Gojo nullifies, Mahoraga
      // adapts, Meliodas reflects, etc. Same two-call sequence attack.js uses.
      withBossBattleStateFor(cs)(player, e, bp => {
        const basicResult = applyBossSpecial(bp, EVENT.PLAYER_BASIC_ATTACK, {
          damage: finalDmg, element: 'physical', isCrit, isHit: true,
        })
        if (basicResult.modified && basicResult.damage !== undefined) finalDmg = basicResult.damage
        if (basicResult.narrativeLine) msg += `_${basicResult.narrativeLine}_\n`

        const takeResult = applyBossSpecial(bp, EVENT.ENEMY_TAKE_DAMAGE, {
          damage: finalDmg, element: 'physical', isCrit, isHit: true,
        })
        if (takeResult.modified && takeResult.damage !== undefined) finalDmg = takeResult.damage
        if (takeResult.narrativeLine) msg += `_${takeResult.narrativeLine}_\n`

        // Meliodas' Full Counter — reflect damage back at the attacker.
        if (takeResult.reflectDamage) {
          msg += applyPartyHpDamage(player, takeResult.reflectDamage, cs)
          msg += `🔁 *Full Counter!* Your attack is reflected!\n🩸 *${takeResult.reflectDamage}* damage back at you!\n`
        }
      })
    }

    e.hp = Math.max(0, e.hp - finalDmg)
    battle.contributions[ctx.from] = (battle.contributions[ctx.from] ?? 0) + finalDmg

    msg += `⚔️ *${player.name}* hits *${e.name}*${isCrit ? ' ⚡*CRIT!*' : ''} for *${finalDmg}* damage!\n`
    const texasHit = applyNighOmni(player, e, finalDmg, { battleState: battle })
    if (texasHit.message) msg += texasHit.message + '\n'
    battle.contributions[ctx.from] += texasHit.damage
    // 🔥 Rengoku — Flame Breathing in a party fight: the combo follows the
    // member's landed hit onto the shared enemy and is credited to that member's
    // damage share. The chain lives on the member's own per-battle state (cs),
    // so it counts THEIR consecutive turns, not the party's.
    const flameCombo = applyFlameCombo(player, e, finalDmg, { battleState: cs })
    if (flameCombo.message) msg += flameCombo.message + '\n'
    battle.contributions[ctx.from] += flameCombo.damage
    msg += `❤️ ${e.name}: ${hpBar(e.hp, e.maxHp)}\n`

    if (player.hp <= 0) {
      outbox.push({ text: msg })
      downJid = ctx.from
      return player
    }

    if (e.hp > 0) {
      // Urahara's Tear/Reshape — mark the enemy on a landed hit (ticks next round).
      const tearLine = applyTearOnHit(player, e)
      if (tearLine) msg += tearLine + '\n'
    }

    if (e.hp <= 0) {
      outbox.push({ text: msg })
      victoryPending = true
      return player
    }

    if (boss) {
      // PLAYER_HIT_ENEMY — Shanks hit-streak, Aizen hypnosis, etc.
      withBossBattleStateFor(cs)(player, e, bp => {
        const hitResult = applyBossSpecial(bp, EVENT.PLAYER_HIT_ENEMY, {
          damage: finalDmg, isCrit, element: 'physical', isHit: true,
        })
        if (hitResult.narrativeLine) msg += `_${hitResult.narrativeLine}_\n`
        if (finalDmg > 0) msg += `💬 _"${getBossHitLine(bp)}"_\n`
      })

      if (e.hp <= 0) {
        outbox.push({ text: msg })
        victoryPending = true
        return player
      }

      // Phase transition — announce narrative when HP crosses 75/50/25%.
      withBossBattleStateFor(cs)(player, e, bp => {
        const phase = checkBossPhase(bp)
        if (phase?.triggered && phase.lines?.length) {
          msg += `\n⚡ *— PHASE SHIFT —*\n` + phase.lines.join('\n') + '\n'
        }
      })
    }

    if (e.hp <= 0) {
      outbox.push({ text: msg })
      victoryPending = true
      return player
    }

    // ⚡ Second Transcendance — the equipped Transcendent strikes a SECOND time,
    // same as solo attack.js. Damage-only echo inserted after the primary hit
    // and before the enemy retaliates; it never advances the turn counter and
    // adds no second retaliation. Routes through the withBossBattleState bridge
    // so a boss's nullify/halve/adapt still governs the 2nd hit, and credits the
    // echo's damage to this member's contribution like the primary hit does.
    if (e.hp > 0 && hasSecondTranscendance(player)) {
      const echo = rollEchoStrike(player, e, null, cs)
      if (echo?.missed) {
        msg += `⚡ *SECOND TRANSCENDANCE* — *${player.name}*'s echo swings and *misses!*\n`
      } else if (echo) {
        let echoDmg = applyDefense(echo.rawDmg, getEffectiveStat(e, 'def'), player, e, cs)
        if (boss) {
          withBossBattleStateFor(cs)(player, e, bp => {
            const echoTake = applyBossSpecial(bp, EVENT.ENEMY_TAKE_DAMAGE, {
              damage: echoDmg, element: 'physical', isCrit: echo.isCrit, isHit: true,
            })
            if (echoTake.modified && echoTake.damage !== undefined) echoDmg = echoTake.damage
            if (echoTake.narrativeLine) msg += `_${echoTake.narrativeLine}_\n`
          })
        }
        e.hp = Math.max(0, e.hp - echoDmg)
        battle.contributions[ctx.from] = (battle.contributions[ctx.from] ?? 0) + echoDmg
        msg += `⚡ *SECOND TRANSCENDANCE* — *${player.name}* moves again!${echo.isCrit ? ' ⚡ *CRIT!*' : ''}\n`
        msg += echoDmg > 0 ? `🩸 *${echoDmg}* damage!\n` : `🛡️ _The echo is absorbed — no damage._\n`
        msg += `❤️ ${e.name}: ${hpBar(e.hp, e.maxHp)}\n`
      }
      if (e.hp <= 0) {
        outbox.push({ text: msg })
        victoryPending = true
        return player
      }
    }

    // A stunned or frozen enemy — most often one caught in a party member's
    // Unlimited Void — forfeits its retaliation entirely. enemyStatus was
    // ticked at the top of this turn, so the lock counts down one step per
    // party action and the enemy stays silent until it lifts.
    // 👑 King Yato — Grace of the Crown: turns 1-5 the enemy does not act at all.
    // 🏛️ The attacker's Sanctum only holds a BOSS's turn here: a boss always
    // answers the attacker, but a regular enemy rolls an aggro target below,
    // and that target's own Sanctum/shelter is checked in applyPartyIncoming.
    const graceHeld = graceHoldsEnemyTurn(player, cs, { sanctum: boss })
    if (graceHeld || enemyStatus.incapacitated) {
      msg += graceHeld
        ? `\n${graceEnemyHeldLine(e, player, cs, { sanctum: boss })}`
        : `\n${e.emoji ?? '👾'} *${e.name}* is locked down and cannot act.`
      outbox.push({ turn: {
        player, e, msg: msg + `\n\n*${p}dparty attack* · *${p}dparty defend* · *${p}dparty flee*`,
        hpBeforeTurn: player.hp, eHpBeforeTurn, boss,
      } })
      return player
    }

    // Enemy retaliates. On a boss floor, the boss's own named attack (via
    // buildEnemyAttack) always lands on the attacker — bosses in this engine
    // don't redirect their counter onto other party members. Regular enemies
    // keep the existing aggro-weighted random-target behaviour.
    if (boss) {
      const hpBeforeTurn = player.hp
      let bossAtk = null
      let dealResult = null
      withBossBattleStateFor(cs)(player, e, bp => {
        bossAtk = buildEnemyAttack(bp)
        dealResult = applyBossSpecial(bp, EVENT.ENEMY_DEAL_DAMAGE, {
          damage: bossAtk.damage, isHit: true,
        })
      })
      if (!bossAtk) {
        const fb = plainBossStrike(e)   // plain boss: bridge above no-op'd
        bossAtk = fb.bossAtk
        dealResult = fb.dealResult
      }
      const rawBossAtk = dealResult.modified && dealResult.damage !== undefined
        ? dealResult.damage
        : bossAtk.damage

      const hitList = Array.isArray(dealResult.guaranteedHits) ? dealResult.guaranteedHits : null
      let totalPlayerDmg = 0

      if (hitList) {
        for (const rawHit of hitList) {
          // Gojo's Infinity thins each guaranteed hit as well; a no-op otherwise.
          const incoming = applyPartyIncoming(player, rawHit, cs, e, battle, ctx.from)
          const hDmg = incoming.damage
          if (incoming.message) msg += incoming.message + '\n'
          msg += applyPartyHpDamage(player, hDmg, cs)
          totalPlayerDmg += hDmg
        }
        msg += `${e.emoji ?? '👾'} *${e.name}* unleashes *${bossAtk.attackName}*! _(${hitList.length} hits)_\n`
        msg += `🩸 *${totalPlayerDmg}* total damage! _(ignores DEF)_\n`
      } else {
        const primaryHit = bossAtk.bypassDefense
          ? rawBossAtk
          : calcMonsterDamage(rawBossAtk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), false)
        const sustain = applyPartyIncoming(player, primaryHit, cs, e, battle, ctx.from)
        msg += applyPartyHpDamage(player, sustain.damage, cs)
        totalPlayerDmg = sustain.damage
        if (sustain.message) msg += sustain.message + '\n'

        if (bossAtk.doubleStrike) {
          const hit2 = bossAtk.bypassDefense
            ? rawBossAtk
            : calcMonsterDamage(rawBossAtk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), false)
          const sustain2 = applyPartyIncoming(player, hit2, cs, e, battle, ctx.from)
          msg += applyPartyHpDamage(player, sustain2.damage, cs)
          totalPlayerDmg += sustain2.damage
          if (sustain2.message) msg += sustain2.message + '\n'
          msg += `${e.emoji ?? '👾'} *${e.name}* uses *${bossAtk.attackName}*! ⚡ *DOUBLE STRIKE!*\n`
          msg += `🩸 *${totalPlayerDmg}* total damage!\n`
        } else {
          msg += `${e.emoji ?? '👾'} *${e.name}* uses *${bossAtk.attackName}*!\n`
          msg += `🩸 *${totalPlayerDmg}* damage!${bossAtk.bypassDefense ? ' _(bypasses DEF)_' : ''}\n`
        }
      }

      if (bossAtk.narrativeLines?.length) msg += `_${bossAtk.narrativeLines[0]}_\n`
      if (dealResult.narrativeLine) msg += `_${dealResult.narrativeLine}_\n`

      let taunt = ''
      withBossBattleStateFor(cs)(player, e, bp => { taunt = getBossTaunt(bp) })
      if (taunt) msg += `\n💬 _"${taunt}"_\n`
      msg += `❤️ ${player.name}: ${hpBar(player.hp, player.maxHp)}`

      outbox.push({ turn: {
        player, e, msg: msg + `\n\n*${p}dparty attack* · *${p}dparty defend* · *${p}dparty flee*`,
        hpBeforeTurn, eHpBeforeTurn, boss,
      } })
      if (player.hp <= 0) downJid = ctx.from
      return player
    }

    // Enemy retaliates against a random party member currently in battle,
    // weighted toward whoever has dealt the most damage (highest aggro).
    const combatants = party.members.filter(m => getPlayer(ctx.db, m)?.inBattle)
    const weights = combatants.map(m => 1 + (battle.contributions[m] ?? 0) / 10)
    const totalWeight = weights.reduce((a, b) => a + b, 0)
    let roll = Math.random() * totalWeight
    let targetJid = combatants[0]
    for (let i = 0; i < combatants.length; i++) {
      roll -= weights[i]
      if (roll <= 0) { targetJid = combatants[i]; break }
    }

    const hpBeforeTurn = player.hp
    if (targetJid === ctx.from) {
      // Simple case: resolve inline against the attacker.
      if (Math.random() > calcMonsterHitChance(e, player)) {
        msg += `\n${e.emoji ?? '👾'} *${e.name}* lunges at *${player.name}*... *MISSES!*`
        outbox.push({ turn: {
          player, e, msg: msg + `\n\n*${p}dparty attack* · *${p}dparty defend* · *${p}dparty flee*`,
          hpBeforeTurn, eHpBeforeTurn, boss,
        } })
        return player
      }
      const dmg = calcMonsterDamage(e.atk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), false)
      const sustain = applyPartyIncoming(player, dmg, cs, e, battle, ctx.from)
      msg += applyPartyHpDamage(player, sustain.damage, cs)
      if (sustain.message) msg += sustain.message + '\n'
      msg += `\n${e.emoji ?? '👾'} *${e.name}* strikes *${player.name}* for *${sustain.damage}* damage!\n`
      msg += `❤️ ${player.name}: ${hpBar(player.hp, player.maxHp)}`
      outbox.push({ turn: {
        player, e, msg: msg + `\n\n*${p}dparty attack* · *${p}dparty defend* · *${p}dparty flee*`,
        hpBeforeTurn, eHpBeforeTurn, boss,
      } })
      if (player.hp <= 0) downJid = ctx.from
      return player
    } else {
      // Do not await a second updatePlayer while holding the global writer.
      redirectedHit = { targetJid, e, battle, msg, hpBeforeTurn, eHpBeforeTurn, boss }
      return player
    }
  })

  if (redirectedHit) {
    const { targetJid, e, battle, msg, hpBeforeTurn, eHpBeforeTurn, boss } = redirectedHit
    const targetName = nameFor(ctx.db, targetJid)
    let hitMsg = ''
    await updatePlayer(ctx.db, targetJid, async target => {
      if (Math.random() > calcMonsterHitChance(e, target)) {
        hitMsg = `\n${e.emoji ?? '👾'} *${e.name}* lunges at *${targetName}*... *MISSES!*`
        return target
      }
      const dmg = calcMonsterDamage(e.atk, (ultraInstinctStatBoost(target) ? getEffectiveStat(target, 'def') : target.stats.def), false)
      // The TARGET's own flags and beast, not the attacker's.
      const targetCs = battle.charState[targetJid] = battle.charState[targetJid] ?? {}
      const sustain = applyPartyIncoming(target, dmg, targetCs, e, battle, targetJid)
      hitMsg += applyPartyHpDamage(target, sustain.damage, targetCs)
      if (sustain.message) hitMsg += sustain.message + '\n'
      hitMsg += `\n${e.emoji ?? '👾'} *${e.name}* strikes *${targetName}* for *${sustain.damage}* damage!\n❤️ ${targetName}: ${hpBar(target.hp, target.maxHp)}`
      return target
    })
    outbox.push({ turn: {
      player: getPlayer(ctx.db, ctx.from), e,
      msg: msg + hitMsg + `\n\n*${p}dparty attack* · *${p}dparty defend* · *${p}dparty flee*`,
      hpBeforeTurn, eHpBeforeTurn, boss,
    } })
    const targetAfter = getPlayer(ctx.db, targetJid)
    if (targetAfter.hp <= 0) downJid = targetJid
  }

  // Flush the queued sends — a failed send must never block the state
  // resolution below (a stuck battle flag is worse than a lost message).
  for (const item of outbox) {
    try {
      if (item.turn) await sendBattleTurnReply(ctx, item.turn)
      else if (item.thunk) await item.thunk()
      else if (item.text != null) await ctx.reply(item.text)
    } catch {}
  }
  if (victoryPending || (party.battle?.enemy?.hp ?? 1) <= 0) return resolvePartyVictory(ctx, party)
  await karrenPartyPulse(ctx, party)
  if (downJid) await handlePartyMemberDown(ctx, party, downJid)
  // A completed action passes the turn to the next member — unless the
  // battle just ended (resolvePartyVictory cleared party.battle).
  if (party.battle) { advancePartyTurn(ctx.db, party); const formationText=partyFormationReadout(party.battle); if(formationText) await ctx.reply(formationText) }
}

// ── Party battle: defend ──────────────────────────────────────────────────
async function battleDefend(ctx) {
  ctx = partyContext(ctx)
  const p = config.prefix
  const party = findPartyForPlayer(ctx.db, ctx.from)
  if (!party) return ctx.reply(`❌ You're not in a party.`)
  if (!party.battle) return ctx.reply(`❌ Your party isn't in a battle.`)

  const notTurn = await notYourTurn(ctx, party)
  if (notTurn) return ctx.reply(notTurn)

  // Mutator only mutates and records the outcome — no network I/O (ctx.reply)
  // runs inside it. It executes on the shared global write queue (see
  // lib/player-repo.js's runExclusive); an awaited sendMessage call in here
  // would hold that queue open for the duration of a WhatsApp round-trip,
  // and if that round-trip ever hangs (e.g. mid-reconnect), every other
  // player's command stalls behind it indefinitely — the bot looks fully
  // dead (reacts ⚔️ but never replies) until the process is restarted.
  let outcome = null // 'miss' | { dmg, hp, maxHp, name, lines }
  let hpZero = false
  let claneFeedText = '' // Clane's Crimson Hunger, printed above every outcome
  let beastTurnText = ''
  let enemyStatusText = ''

  await updatePlayer(ctx.db, ctx.from, player => {
    const battle = party.battle
    const e = battle.enemy
    const boss = e.isBoss ?? false
    let lines = []

    // Per-member, once-per-battle character-ability state — stands in for
    // player.battleState, which party fights don't use. See the
    // party.battle.charState note in enterDungeon().
    battle.charState = battle.charState ?? {}
    const cs = battle.charState[ctx.from] = battle.charState[ctx.from] ?? {}

    // Clane — Crimson Hunger. Bracing is still a turn: the shared enemy is
    // bitten and the acting member pays the Toll before the enemy swings, so
    // there is no "safe" action that skips her. A bite that clears the floor
    // or a Toll that takes the member down ends the turn here, with no
    // counter-attack to brace against — the same precedence plugins/defend.js
    // uses (floor first, then the owner).
    const claneFeed = tickClaneDrain(player, e)
    if (claneFeed) {
      claneFeedText = claneFeed.message
      if (claneFeed.reboundDamage > 0) {
        player.hp = Math.max(0, (player.hp ?? 0) - claneFeed.reboundDamage)
      }
      if (e.hp <= 0 || player.hp <= 0) {
        hpZero = player.hp <= 0
        outcome = { feedOnly: true, name: player.name, hp: player.hp, maxHp: player.maxHp }
        return player
      }
    }

    beastTurnText = applyPartyBeastTurn(player, battle, cs, ctx.from).trimEnd()
    if (e.hp <= 0) {
      outcome = { feedOnly: true, name: player.name, hp: player.hp, maxHp: player.maxHp }
      return player
    }
    // A defend is also an enemy turn: tick a summon's burn or control before
    // deciding whether the enemy gets to retaliate.
    const enemyStatus = processStatusTurn(e)
    enemyStatusText = enemyStatus.lines.join('\n')
    if (e.hp <= 0 || enemyStatus.incapacitated) {
      outcome = e.hp <= 0
        ? { feedOnly: true, name: player.name, hp: player.hp, maxHp: player.maxHp }
        : { held: `💫 *${e.name}* is unable to attack.`, name: player.name, hp: player.hp, maxHp: player.maxHp }
      return player
    }

    if (boss) {
      // TURN_START + PLAYER_DEFEND — Aizen breaks hypnosis on defend, etc.
      // Mirrors solo defend.js's boss-engine hooks via the same bridge
      // battleAttack/battleCinderVerdict use.
      withBossBattleStateFor(cs)(player, e, bp => {
        incrementBossTurn(bp)
        const tsResult = applyBossSpecial(bp, EVENT.TURN_START, {})
        if (tsResult.narrativeLine) lines.push(`_${tsResult.narrativeLine}_`)

        const defendResult = applyBossSpecial(bp, EVENT.PLAYER_DEFEND, {})
        if (defendResult.narrativeLine) lines.push(`_${defendResult.narrativeLine}_`)
        if (defendResult.removeEffect) {
          player.activeEffects = (player.activeEffects ?? []).filter(
            fx => fx.sourceId !== defendResult.removeEffect,
          )
        }
      })
    }

    // 👑 King Yato — Grace of the Crown: turns 1-5 the enemy does not act at all.
    if (graceHoldsEnemyTurn(player, cs)) {
      outcome = { held: graceEnemyHeldLine(e, player, cs), name: player.name, hp: player.hp, maxHp: player.maxHp }
      return player
    }

    if (boss) {
      let bossAtk = null
      let dealResult = null
      withBossBattleStateFor(cs)(player, e, bp => {
        bossAtk = buildEnemyAttack(bp)
        dealResult = applyBossSpecial(bp, EVENT.ENEMY_DEAL_DAMAGE, { damage: bossAtk.damage, isHit: true })
      })
      if (!bossAtk) {
        const fb = plainBossStrike(e)   // plain boss: bridge above no-op'd
        bossAtk = fb.bossAtk
        dealResult = fb.dealResult
      }
      const rawBossAtk = dealResult.modified && dealResult.damage !== undefined
        ? dealResult.damage
        : bossAtk.damage

      const hitList = Array.isArray(dealResult.guaranteedHits) ? dealResult.guaranteedHits : null
      let totalPlayerDmg = 0

      if (hitList) {
        for (const rawHit of hitList) {
          // Gojo's Infinity thins each guaranteed hit as well; a no-op otherwise.
          const incoming = applyPartyIncoming(player, rawHit, cs, e, battle, ctx.from)
          const hDmg = incoming.damage
          if (incoming.message) lines.push(incoming.message)
          const relicText = applyPartyHpDamage(player, hDmg, cs)
          if (relicText) lines.push(relicText.trimEnd())
          totalPlayerDmg += hDmg
        }
        lines.push(`${e.emoji ?? '👾'} *${e.name}* unleashes *${bossAtk.attackName}*! _(${hitList.length} hits)_`)
        lines.push(`🩸 *${totalPlayerDmg}* total damage! _(ignores DEF)_`)
      } else {
        // Defending halves incoming damage (calcMonsterDamage's 3rd arg),
        // same as it does for regular enemies below.
        const primaryHit = bossAtk.bypassDefense
          ? rawBossAtk
          : calcMonsterDamage(rawBossAtk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), true)
        const sustain = applyPartyIncoming(player, primaryHit, cs, e, battle, ctx.from)
        const relicText = applyPartyHpDamage(player, sustain.damage, cs)
        if (relicText) lines.push(relicText.trimEnd())
        totalPlayerDmg = sustain.damage
        if (sustain.message) lines.push(sustain.message)

        if (bossAtk.doubleStrike) {
          const hit2 = bossAtk.bypassDefense
            ? rawBossAtk
            : calcMonsterDamage(rawBossAtk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), true)
          const sustain2 = applyPartyIncoming(player, hit2, cs, e, battle, ctx.from)
          const relicText2 = applyPartyHpDamage(player, sustain2.damage, cs)
          if (relicText2) lines.push(relicText2.trimEnd())
          totalPlayerDmg += sustain2.damage
          if (sustain2.message) lines.push(sustain2.message)
          lines.push(`${e.emoji ?? '👾'} *${e.name}* uses *${bossAtk.attackName}*! ⚡ *DOUBLE STRIKE!*`)
          lines.push(`🩸 *${totalPlayerDmg}* total damage!`)
        } else {
          lines.push(`${e.emoji ?? '👾'} *${e.name}* uses *${bossAtk.attackName}*!`)
          lines.push(`🩸 *${totalPlayerDmg}* damage!${bossAtk.bypassDefense ? ' _(bypasses DEF)_' : ''}`)
        }
      }

      if (bossAtk.narrativeLines?.length) lines.push(`_${bossAtk.narrativeLines[0]}_`)
      if (dealResult.narrativeLine) lines.push(`_${dealResult.narrativeLine}_`)

      let taunt = ''
      withBossBattleStateFor(cs)(player, e, bp => { taunt = getBossTaunt(bp) })
      if (taunt) lines.push(`💬 _"${taunt}"_`)

      outcome = { dmg: totalPlayerDmg, hp: player.hp, maxHp: player.maxHp, name: player.name, lines }
      hpZero = player.hp <= 0
      return player
    }

    if (Math.random() > calcMonsterHitChance(e, player)) {
      outcome = 'miss'
      return player
    }
    const dmg = calcMonsterDamage(e.atk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), true)
    const sustain = applyPartyIncoming(player, dmg, cs, e, battle, ctx.from)
    const relicText = applyPartyHpDamage(player, sustain.damage, cs)
    if (relicText) lines.push(relicText.trimEnd())
    outcome = { dmg: sustain.damage, hp: player.hp, maxHp: player.maxHp, name: player.name, message: [...lines, sustain.message].filter(Boolean).join('\n') }
    hpZero = player.hp <= 0
    return player
  })

  const feedPrefix = claneFeedText + (claneFeedText ? '\n' : '') +
    [beastTurnText, enemyStatusText].filter(Boolean).map(line => line + '\n').join('')

  if (outcome === 'miss') {
    await ctx.reply(feedPrefix + `🛡️ Braces for impact... the enemy *MISSES!*`)
  } else if (outcome?.feedOnly) {
    // The bite emptied the floor or the Toll emptied the member — either way
    // the enemy never got to swing, so this is the whole turn.
    await ctx.reply(
      feedPrefix +
      `🛡️ *${outcome.name}* braces!\n` +
      `❤️ ${outcome.name}: ${hpBar(outcome.hp, outcome.maxHp)}\n\n` +
      `*${p}dparty attack* · *${p}dparty defend* · *${p}dparty flee*`,
    )
  } else if (outcome?.held) {
    await ctx.reply(
      feedPrefix +
      `🛡️ *${outcome.name}* braces!\n` +
      outcome.held + '\n' +
      `❤️ ${outcome.name}: ${hpBar(outcome.hp, outcome.maxHp)}\n\n` +
      `*${p}dparty attack* · *${p}dparty defend* · *${p}dparty flee*`,
    )
  } else if (outcome.lines) {
    // Boss defend result — lines already carry the boss-engine narrative.
    await ctx.reply(
      feedPrefix +
      `🛡️ *${outcome.name}* braces!\n` +
      outcome.lines.join('\n') + '\n' +
      `❤️ ${outcome.name}: ${hpBar(outcome.hp, outcome.maxHp)}\n\n` +
      `*${p}dparty attack* · *${p}dparty defend* · *${p}dparty flee*`,
    )
  } else {
    await ctx.reply(
      feedPrefix +
      (outcome.message ?? '') +
      `🛡️ *${outcome.name}* braces and takes a reduced *${outcome.dmg}* damage!\n` +
      `❤️ ${outcome.name}: ${hpBar(outcome.hp, outcome.maxHp)}\n\n` +
      `*${p}dparty attack* · *${p}dparty defend* · *${p}dparty flee*`,
    )
  }
  if ((party.battle?.enemy?.hp ?? 1) <= 0) return resolvePartyVictory(ctx, party)
  await karrenPartyPulse(ctx, party)
  if (hpZero) await handlePartyMemberDown(ctx, party, ctx.from)
  // A defend takes the defender's turn and establishes cover for allies.
  if (party.battle) { advancePartyTurn(ctx.db, party, 'defend'); const formationText=partyFormationReadout(party.battle); if(formationText) await ctx.reply(formationText) }
}

// ── Party battle: flee ─────────────────────────────────────────────────────
// Same 35%+LCK escape chance and failed-flee damage as solo flee.js — a
// party fighter shouldn't get a strictly better (guaranteed, free) flee
// than a solo one just because they're in a party. Only real difference
// from solo: a successful flee here just pulls THIS member out (forfeiting
// their reward share) while the rest of the party keeps fighting, same as
// before — it doesn't end the whole party's battle unless everyone's gone.
async function battleFlee(ctx) {
  ctx = partyContext(ctx)
  const p = config.prefix
  const party = findPartyForPlayer(ctx.db, ctx.from)
  if (!party) return ctx.reply(`❌ You're not in a party.`)
  if (!party.battle) return ctx.reply(`❌ Your party isn't in a battle.`)
  if (party.battle.enemy.isBoss) return ctx.reply(`⚠️ Can't flee a boss fight!`)
  // ⛪ Sealed Doors — the cathedral refuses the exit for anyone standing in it.
  if (hasEffect(getPlayer(ctx.db, ctx.from), 'cathedral')) {
    return ctx.reply('⛪ *The doors are sealed.* Nothing leaves the cathedral while it stands.')
  }

  const notTurn = await notYourTurn(ctx, party)
  if (notTurn) return ctx.reply(notTurn)

  const e = party.battle.enemy
  let hpZero = false
  // Sends are queued and flushed after updatePlayer settles — no I/O inside
  // the write lane (same discipline as battleDefend).
  const outbox = []

  await updatePlayer(ctx.db, ctx.from, async player => {
    const chance = 0.35 + (player.stats?.lck ?? 0) * 0.003
    if (Math.random() < chance) {
      addSeason02TowerAction(player, 'retreat', { db: ctx.db })
      if (party.run?.locationId === 'season_02_tower') {
        addSeason02TowerAction(player, 'safe_flee', { db: ctx.db, context: { floor: party.run.floor } })
      }
      // 🌋 Surtr — a successful escape is an exit from the fight, so Twilight's
      // max HP and ATK go back with the rest of it.
      clearSurtrKit(player, party.battle?.charState?.[ctx.from] ?? null)
      player.inBattle = false
      clearBeastEffects(player)
      outbox.push({ text: `💨 *${player.name}* escapes the fight! _(forfeits any reward share)_` })

      const stillFighting = party.members.some(m => m !== ctx.from && getPlayer(ctx.db, m)?.inBattle)
      if (!stillFighting) {
        party.battle = null
        party.run = null
        outbox.push({ text: `🏳️ Everyone has left the fight — the party retreats. _(Cleared floors are kept.)_` })
      }
      return player
    }

    const dmg = calcMonsterDamage(e.atk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), false)
    // Per-member character state (see enterDungeon's charState note) — the
    // parting blow on a failed escape can still spend a Mei sustain, so it
    // has to count against the same per-battle pool as everything else.
    party.battle.charState = party.battle.charState ?? {}
    const cs = party.battle.charState[ctx.from] = party.battle.charState[ctx.from] ?? {}
    // 👑 King Yato — Grace of the Crown: turns 1-5 the enemy does not act at
    // all, so a failed escape is simply a failed escape — nothing catches you.
    if (graceHoldsEnemyTurn(player, cs)) {
      outbox.push({ text:
        `❌ *Escape failed!*\n${graceEnemyHeldLine(e, player, cs)}\n\n` +
        `❤️ ${hpBar(player.hp, player.maxHp)}\n\n` +
        `*${p}dparty attack* · *${p}dparty defend* · *${p}dparty flee*`,
      })
      return player
    }
    const sustain = applyPartyIncoming(player, dmg, cs, e, party.battle, ctx.from)
    // (This used to be `msg += …` with no `msg` in scope — a ReferenceError
    // on every failed party escape. The relic lines now ride on the reply.)
    const relicText = applyPartyHpDamage(player, sustain.damage, cs)
    hpZero = player.hp <= 0

    if (!hpZero) {
      outbox.push({ text:
        (sustain.message ? sustain.message + '\n' : '') + relicText +
        `❌ *Escape failed!*\n${e.emoji ?? '👾'} *${e.name}* catches you!\n🩸 *${sustain.damage}* damage!\n\n` +
        `❤️ ${hpBar(player.hp, player.maxHp)}\n\n` +
        `*${p}dparty attack* · *${p}dparty defend* · *${p}dparty flee*`,
      })
    }
    return player
  })

  for (const item of outbox) {
    try { if (item.text != null) await ctx.reply(item.text) } catch {}
  }
  // Dying on a failed flee attempt routes through the same party-down
  // handler (respawn at half HP, pull from the fight, pearl-checkpoint
  // check) as a failed attack/defend — kept outside updatePlayer's mutator
  // since handlePartyMemberDown does its own updatePlayer call.
  if ((party.battle?.enemy?.hp ?? 1) <= 0) return resolvePartyVictory(ctx, party)
  await karrenPartyPulse(ctx, party)
  if (hpZero) await handlePartyMemberDown(ctx, party, ctx.from)
  // Fleeing takes the turn too (whether it worked or the escape failed). If the
  // flee actually ended the battle (party.battle cleared inside the mutator),
  // the guard skips the advance.
  if (party.battle) { advancePartyTurn(ctx.db, party); const formationText=partyFormationReadout(party.battle); if(formationText) await ctx.reply(formationText) }
}

// ── Party battle: Cinder Verdict (Wither) ───────────────────────────────────
// Wither's once-per-battle, no-MP ember sentence — the party-combat twin of
// plugins/cinderverdict.js. Same 8x damageMultiplier through the stock
// calcPlayerDamage() -> applyDefense() pipeline; the per-member witherUsed
// flag lives on party.battle.charState so it resets with the fight.
async function battleCinderVerdict(ctx) {
  ctx = partyContext(ctx)
  const p = config.prefix
  const party = findPartyForPlayer(ctx.db, ctx.from)
  if (!party) return ctx.reply(`❌ You're not in a party.`)
  if (!party.battle) return ctx.reply(`❌ Your party isn't in a battle. Use *${p}dparty enter <dungeon>*.`)

  // Fixed turn order: only the member at the cursor may act this round.
  const notTurn = await notYourTurn(ctx, party)
  if (notTurn) return ctx.reply(notTurn)

  // Mutator records the outcome only — sends are queued in `outbox` and
  // flushed after updatePlayer settles, and victory / member-down resolution
  // happens there too. No I/O and no nested updatePlayer inside the lane
  // (the nested same-player write deadlocks it — the old stuck-battle bug).
  let outbox = []
  let victoryPending = false
  let downJid = null

  await updatePlayer(ctx.db, ctx.from, async player => {
    const battle = party.battle
    const e = battle.enemy
    const eHpBeforeTurn = e.hp
    const boss = e.isBoss ?? false

    battle.charState = battle.charState ?? {}
    const cs = battle.charState[ctx.from] = battle.charState[ctx.from] ?? {}

    const gate = activateCinderVerdict(player, cs)
    if (!gate.ok) {
      if (gate.message) outbox.push({ text: gate.message })
      return player
    }

    let pre = ''
    const permaSeverLine = tickPermanentSever(player)
    if (permaSeverLine) pre += permaSeverLine + '\n'
    if (player.hp <= 0) {
      if (pre) outbox.push({ text: pre })
      downJid = ctx.from
      return player
    }

    pre += applyPartyBeastTurn(player, battle, cs, ctx.from)
    if (e.hp <= 0) {
      outbox.push({ text: pre + `\n${e.emoji ?? '👾'} *${e.name}* falls to the summon!` })
      victoryPending = true
      return player
    }

    let msg = pre +
      `🔥⚖️ *CINDER VERDICT*\n─────────────\n` +
      `_${player.name}'s Wither names *${e.name}*, and the name catches fire._\n\n`

    if (Math.random() > calcPlayerHitChance(player, e, cs)) {
      msg += `💨 The sentence gutters out — *MISSED!*\n`
      outbox.push({ turn: {
        player, e, msg: msg + `\n*${p}dparty attack* · *${p}dparty defend* · *${p}dparty flee*`,
        hpBeforeTurn: player.hp, eHpBeforeTurn, boss,
      } })
      return player
    }

    let { rawDmg, isCrit } = calcPlayerDamage(player, null, gate.multiplier, 0, { battleState: cs })
    let finalDmg = applyDefense(rawDmg, getEffectiveStat(e, 'def'), player, e, cs)

    if (boss) {
      // Cinder Verdict counts as the player's attack for boss-special
      // purposes — same PLAYER_BASIC_ATTACK/ENEMY_TAKE_DAMAGE pair as a
      // regular hit, so Gojo/Mahoraga/Meliodas etc. still react correctly
      // when a boss is burned down with Wither's ember sentence.
      withBossBattleStateFor(cs)(player, e, bp => {
        const basicResult = applyBossSpecial(bp, EVENT.PLAYER_BASIC_ATTACK, {
          damage: finalDmg, element: 'physical', isCrit, isHit: true,
        })
        if (basicResult.modified && basicResult.damage !== undefined) finalDmg = basicResult.damage
        if (basicResult.narrativeLine) msg += `_${basicResult.narrativeLine}_\n`

        const takeResult = applyBossSpecial(bp, EVENT.ENEMY_TAKE_DAMAGE, {
          damage: finalDmg, element: 'physical', isCrit, isHit: true,
        })
        if (takeResult.modified && takeResult.damage !== undefined) finalDmg = takeResult.damage
        if (takeResult.narrativeLine) msg += `_${takeResult.narrativeLine}_\n`

        if (takeResult.reflectDamage) {
          msg += applyPartyHpDamage(player, takeResult.reflectDamage, cs)
          msg += `🔁 *Full Counter!* The sentence is reflected!\n🩸 *${takeResult.reflectDamage}* damage back at you!\n`
        }
      })
    }

    e.hp = Math.max(0, e.hp - finalDmg)
    battle.contributions[ctx.from] = (battle.contributions[ctx.from] ?? 0) + finalDmg

    msg += `🩸 *${finalDmg}* damage!${isCrit ? ' 💥 *CRITICAL!*' : ''}\n`
    msg += `❤️ ${e.name}: ${hpBar(e.hp, e.maxHp)}\n`

    if (player.hp <= 0) {
      outbox.push({ text: msg })
      downJid = ctx.from
      return player
    }

    if (e.hp <= 0) {
      outbox.push({ text: msg })
      victoryPending = true
      return player
    }

    if (boss) {
      withBossBattleStateFor(cs)(player, e, bp => {
        const hitResult = applyBossSpecial(bp, EVENT.PLAYER_HIT_ENEMY, {
          damage: finalDmg, isCrit, element: 'physical', isHit: true,
        })
        if (hitResult.narrativeLine) msg += `_${hitResult.narrativeLine}_\n`
        if (finalDmg > 0) msg += `💬 _"${getBossHitLine(bp)}"_\n`
      })

      if (e.hp <= 0) {
        outbox.push({ text: msg })
        victoryPending = true
        return player
      }

      withBossBattleStateFor(cs)(player, e, bp => {
        const phase = checkBossPhase(bp)
        if (phase?.triggered && phase.lines?.length) {
          msg += `\n⚡ *— PHASE SHIFT —*\n` + phase.lines.join('\n') + '\n'
        }
      })
    }

    if (e.hp <= 0) {
      outbox.push({ text: msg })
      victoryPending = true
      return player
    }

    // Enemy retaliates against the caster (Cinder Verdict draws its attention).
    const enemyStatus = processStatusTurn(e)
    if (enemyStatus.lines.length) msg += enemyStatus.lines.join('\n') + '\n'
    if (e.hp <= 0) {
      outbox.push({ text: msg })
      victoryPending = true
      return player
    }
    const hpBeforeTurn = player.hp
    if (graceHoldsEnemyTurn(player, cs)) {
      // 👑 King Yato — Grace of the Crown: turns 1-5 the enemy does not act at all.
      msg += `\n${graceEnemyHeldLine(e, player, cs)}`
    } else if (enemyStatus.incapacitated) {
      msg += `\n${e.emoji ?? '👾'} *${e.name}* is unable to attack.`
    } else if (boss) {
      let bossAtk = null
      let dealResult = null
      withBossBattleStateFor(cs)(player, e, bp => {
        bossAtk = buildEnemyAttack(bp)
        dealResult = applyBossSpecial(bp, EVENT.ENEMY_DEAL_DAMAGE, {
          damage: bossAtk.damage, isHit: true,
        })
      })
      if (!bossAtk) {
        const fb = plainBossStrike(e)   // plain boss: bridge above no-op'd
        bossAtk = fb.bossAtk
        dealResult = fb.dealResult
      }
      const rawBossAtk = dealResult.modified && dealResult.damage !== undefined
        ? dealResult.damage
        : bossAtk.damage

      const hitList = Array.isArray(dealResult.guaranteedHits) ? dealResult.guaranteedHits : null
      let totalPlayerDmg = 0

      if (hitList) {
        for (const rawHit of hitList) {
          // Gojo's Infinity thins each guaranteed hit as well; a no-op otherwise.
          const incoming = applyPartyIncoming(player, rawHit, cs, e, battle, ctx.from)
          const hDmg = incoming.damage
          if (incoming.message) msg += incoming.message + '\n'
          msg += applyPartyHpDamage(player, hDmg, cs)
          totalPlayerDmg += hDmg
        }
        msg += `\n${e.emoji ?? '👾'} *${e.name}* unleashes *${bossAtk.attackName}*! _(${hitList.length} hits)_\n`
        msg += `🩸 *${totalPlayerDmg}* total damage! _(ignores DEF)_\n`
      } else {
        const primaryHit = bossAtk.bypassDefense
          ? rawBossAtk
          : calcMonsterDamage(rawBossAtk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), false)
        const sustain = applyPartyIncoming(player, primaryHit, cs, e, battle, ctx.from)
        msg += applyPartyHpDamage(player, sustain.damage, cs)
        totalPlayerDmg = sustain.damage
        if (sustain.message) msg += sustain.message + '\n'

        if (bossAtk.doubleStrike) {
          const hit2 = bossAtk.bypassDefense
            ? rawBossAtk
            : calcMonsterDamage(rawBossAtk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), false)
          const sustain2 = applyPartyIncoming(player, hit2, cs, e, battle, ctx.from)
          msg += applyPartyHpDamage(player, sustain2.damage, cs)
          totalPlayerDmg += sustain2.damage
          if (sustain2.message) msg += sustain2.message + '\n'
          msg += `\n${e.emoji ?? '👾'} *${e.name}* uses *${bossAtk.attackName}*! ⚡ *DOUBLE STRIKE!*\n`
          msg += `🩸 *${totalPlayerDmg}* total damage!\n`
        } else {
          msg += `\n${e.emoji ?? '👾'} *${e.name}* uses *${bossAtk.attackName}*!\n`
          msg += `🩸 *${totalPlayerDmg}* damage!${bossAtk.bypassDefense ? ' _(bypasses DEF)_' : ''}\n`
        }
      }

      if (bossAtk.narrativeLines?.length) msg += `_${bossAtk.narrativeLines[0]}_\n`
      if (dealResult.narrativeLine) msg += `_${dealResult.narrativeLine}_\n`
      msg += `❤️ ${player.name}: ${hpBar(player.hp, player.maxHp)}`
    } else if (Math.random() > calcMonsterHitChance(e, player)) {
      msg += `\n${e.emoji ?? '👾'} *${e.name}* lashes back at *${player.name}*... *MISSES!*`
    } else {
      const dmg = calcMonsterDamage(e.atk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), false)
      const sustain = applyPartyIncoming(player, dmg, cs, e, battle, ctx.from)
      msg += applyPartyHpDamage(player, sustain.damage, cs)
      if (sustain.message) msg += sustain.message + '\n'
      msg += `\n${e.emoji ?? '👾'} *${e.name}* strikes *${player.name}* for *${sustain.damage}* damage!\n`
      msg += `❤️ ${player.name}: ${hpBar(player.hp, player.maxHp)}`
    }

    outbox.push({ turn: {
      player, e, msg: msg + `\n\n*${p}dparty attack* · *${p}dparty defend* · *${p}dparty flee*`,
      hpBeforeTurn, eHpBeforeTurn, boss,
    } })
    if (player.hp <= 0) downJid = ctx.from
    return player
  })

  // Flush the queued sends — a failed send must never block the state
  // resolution below (a stuck battle flag is worse than a lost message).
  for (const item of outbox) {
    try {
      if (item.turn) await sendBattleTurnReply(ctx, item.turn)
      else if (item.thunk) await item.thunk()
      else if (item.text != null) await ctx.reply(item.text)
    } catch {}
  }
  if (victoryPending || (party.battle?.enemy?.hp ?? 1) <= 0) return resolvePartyVictory(ctx, party)
  await karrenPartyPulse(ctx, party)
  if (downJid) await handlePartyMemberDown(ctx, party, downJid)
  // A completed action passes the turn to the next member — unless the
  // battle just ended (resolvePartyVictory cleared party.battle).
  if (party.battle) { advancePartyTurn(ctx.db, party); const formationText=partyFormationReadout(party.battle); if(formationText) await ctx.reply(formationText) }
}

// ── Party battle: Blaze Heart (Rengoku) ─────────────────────────────────────
// Rengoku's finisher, the party-combat twin of plugins/blaze-heart.js. Same
// shape as battleCinderVerdict above (the stock calcPlayerDamage() ->
// applyDefense() -> applyHighDefenseCatchup() pipeline, the boss-special pair,
// the enemy's answer), with the three things that make it his:
//   • the gate is activateBlazeHeart(player, cs): once per battle AND only from
//     the member's 3rd move, both read off party.battle.charState, so the
//     charge and the move count reset with the fight;
//   • it does not roll accuracy (a finisher that whiffs after its charge is
//     burned reads as a broken command);
//   • a refused gate spends NOTHING: not the charge and not the member's turn.
//     "Too early" is a refusal players will actually hit, and passing the turn
//     on it would also bump the very move counter it is waiting on.
async function battleBlazeHeart(ctx) {
  ctx = partyContext(ctx)
  const p = config.prefix
  const party = findPartyForPlayer(ctx.db, ctx.from)
  if (!party) return ctx.reply(`❌ You're not in a party.`)
  if (!party.battle) return ctx.reply(`❌ Your party isn't in a battle. Use *${p}dparty enter <dungeon>*.`)

  // Fixed turn order: only the member at the cursor may act this round.
  const notTurn = await notYourTurn(ctx, party)
  if (notTurn) return ctx.reply(notTurn)

  // Mutator records the outcome only — sends are queued in `outbox` and
  // flushed after updatePlayer settles, and victory / member-down resolution
  // happens there too. No I/O and no nested updatePlayer inside the lane
  // (the nested same-player write deadlocks it — the old stuck-battle bug).
  let outbox = []
  let victoryPending = false
  let downJid = null
  let refused = false

  await updatePlayer(ctx.db, ctx.from, async player => {
    const battle = party.battle
    const e = battle.enemy
    const eHpBeforeTurn = e.hp
    const boss = e.isBoss ?? false

    battle.charState = battle.charState ?? {}
    const cs = battle.charState[ctx.from] = battle.charState[ctx.from] ?? {}

    const gate = activateBlazeHeart(player, cs)
    if (!gate.ok) {
      refused = true
      if (gate.message) outbox.push({ text: gate.message })
      return player
    }

    let pre = ''
    const permaSeverLine = tickPermanentSever(player)
    if (permaSeverLine) pre += permaSeverLine + '\n'
    if (player.hp <= 0) {
      if (pre) outbox.push({ text: pre })
      downJid = ctx.from
      return player
    }

    pre += applyPartyBeastTurn(player, battle, cs, ctx.from)
    if (e.hp <= 0) {
      outbox.push({ text: pre + `\n${e.emoji ?? '👾'} *${e.name}* falls to the summon!` })
      victoryPending = true
      return player
    }

    let msg = pre + blazeHeartOpening(e.name) + '\n\n'

    // No accuracy roll: the charge is already burned by the gate above.
    let { rawDmg, isCrit } = calcPlayerDamage(player, null, gate.multiplier, 0, { battleState: cs })
    let finalDmg = applyDefense(rawDmg, getEffectiveStat(e, 'def'), player, e, cs)

    if (boss) {
      // Blaze Heart counts as the player's attack for boss-special purposes:
      // the same PLAYER_BASIC_ATTACK/ENEMY_TAKE_DAMAGE pair as a regular hit,
      // so Gojo/Mahoraga/Meliodas etc. still react correctly to it.
      withBossBattleStateFor(cs)(player, e, bp => {
        const basicResult = applyBossSpecial(bp, EVENT.PLAYER_BASIC_ATTACK, {
          damage: finalDmg, element: 'fire', isCrit, isHit: true,
        })
        if (basicResult.modified && basicResult.damage !== undefined) finalDmg = basicResult.damage
        if (basicResult.narrativeLine) msg += `_${basicResult.narrativeLine}_\n`

        const takeResult = applyBossSpecial(bp, EVENT.ENEMY_TAKE_DAMAGE, {
          damage: finalDmg, element: 'fire', isCrit, isHit: true,
        })
        if (takeResult.modified && takeResult.damage !== undefined) finalDmg = takeResult.damage
        if (takeResult.narrativeLine) msg += `_${takeResult.narrativeLine}_\n`

        if (takeResult.reflectDamage) {
          msg += applyPartyHpDamage(player, takeResult.reflectDamage, cs)
          msg += `🔁 *Full Counter!* The blaze is reflected!\n🩸 *${takeResult.reflectDamage}* damage back at you!\n`
        }
      })
    }

    e.hp = Math.max(0, e.hp - finalDmg)
    battle.contributions[ctx.from] = (battle.contributions[ctx.from] ?? 0) + finalDmg

    // The finishing-move art, queued FIRST so it lands ahead of the turn text
    // on every exit below (a kill, a member going down, the ordinary frame).
    // Queued only here, once the strike has actually been thrown: a refusal or
    // a turn that never reached the swing sends no art.
    outbox.push({ thunk: () => sendBlazeHeartImage(ctx, `🔥❤️‍🔥 *${BLAZE_HEART_NAME.toUpperCase()}*`, ctx.sender) })

    msg += `🩸 *${finalDmg.toLocaleString('en-US')}* damage!${isCrit ? ' 💥 *CRITICAL!*' : ''}\n`
    msg += `❤️ ${e.name}: ${hpBar(e.hp, e.maxHp)}\n`

    if (player.hp <= 0) {
      outbox.push({ text: msg })
      downJid = ctx.from
      return player
    }

    if (e.hp <= 0) {
      outbox.push({ text: msg })
      victoryPending = true
      return player
    }

    if (boss) {
      withBossBattleStateFor(cs)(player, e, bp => {
        const hitResult = applyBossSpecial(bp, EVENT.PLAYER_HIT_ENEMY, {
          damage: finalDmg, isCrit, element: 'fire', isHit: true,
        })
        if (hitResult.narrativeLine) msg += `_${hitResult.narrativeLine}_\n`
        if (finalDmg > 0) msg += `💬 _"${getBossHitLine(bp)}"_\n`
      })

      if (e.hp <= 0) {
        outbox.push({ text: msg })
        victoryPending = true
        return player
      }

      withBossBattleStateFor(cs)(player, e, bp => {
        const phase = checkBossPhase(bp)
        if (phase?.triggered && phase.lines?.length) {
          msg += `\n⚡ *— PHASE SHIFT —*\n` + phase.lines.join('\n') + '\n'
        }
      })
    }

    if (e.hp <= 0) {
      outbox.push({ text: msg })
      victoryPending = true
      return player
    }

    // Enemy retaliates against the caster (Blaze Heart draws its attention).
    const enemyStatus = processStatusTurn(e)
    if (enemyStatus.lines.length) msg += enemyStatus.lines.join('\n') + '\n'
    if (e.hp <= 0) {
      outbox.push({ text: msg })
      victoryPending = true
      return player
    }
    const hpBeforeTurn = player.hp
    if (graceHoldsEnemyTurn(player, cs)) {
      // 👑 King Yato — Grace of the Crown: turns 1-5 the enemy does not act at all.
      msg += `\n${graceEnemyHeldLine(e, player, cs)}`
    } else if (enemyStatus.incapacitated) {
      msg += `\n${e.emoji ?? '👾'} *${e.name}* is unable to attack.`
    } else if (boss) {
      let bossAtk = null
      let dealResult = null
      withBossBattleStateFor(cs)(player, e, bp => {
        bossAtk = buildEnemyAttack(bp)
        dealResult = applyBossSpecial(bp, EVENT.ENEMY_DEAL_DAMAGE, {
          damage: bossAtk.damage, isHit: true,
        })
      })
      if (!bossAtk) {
        const fb = plainBossStrike(e)   // plain boss: bridge above no-op'd
        bossAtk = fb.bossAtk
        dealResult = fb.dealResult
      }
      const rawBossAtk = dealResult.modified && dealResult.damage !== undefined
        ? dealResult.damage
        : bossAtk.damage

      const hitList = Array.isArray(dealResult.guaranteedHits) ? dealResult.guaranteedHits : null
      let totalPlayerDmg = 0

      if (hitList) {
        for (const rawHit of hitList) {
          // Gojo's Infinity thins each guaranteed hit as well; a no-op otherwise.
          const incoming = applyPartyIncoming(player, rawHit, cs, e, battle, ctx.from)
          const hDmg = incoming.damage
          if (incoming.message) msg += incoming.message + '\n'
          msg += applyPartyHpDamage(player, hDmg, cs)
          totalPlayerDmg += hDmg
        }
        msg += `\n${e.emoji ?? '👾'} *${e.name}* unleashes *${bossAtk.attackName}*! _(${hitList.length} hits)_\n`
        msg += `🩸 *${totalPlayerDmg}* total damage! _(ignores DEF)_\n`
      } else {
        const primaryHit = bossAtk.bypassDefense
          ? rawBossAtk
          : calcMonsterDamage(rawBossAtk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), false)
        const sustain = applyPartyIncoming(player, primaryHit, cs, e, battle, ctx.from)
        msg += applyPartyHpDamage(player, sustain.damage, cs)
        totalPlayerDmg = sustain.damage
        if (sustain.message) msg += sustain.message + '\n'

        if (bossAtk.doubleStrike) {
          const hit2 = bossAtk.bypassDefense
            ? rawBossAtk
            : calcMonsterDamage(rawBossAtk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), false)
          const sustain2 = applyPartyIncoming(player, hit2, cs, e, battle, ctx.from)
          msg += applyPartyHpDamage(player, sustain2.damage, cs)
          totalPlayerDmg += sustain2.damage
          if (sustain2.message) msg += sustain2.message + '\n'
          msg += `\n${e.emoji ?? '👾'} *${e.name}* uses *${bossAtk.attackName}*! ⚡ *DOUBLE STRIKE!*\n`
          msg += `🩸 *${totalPlayerDmg}* total damage!\n`
        } else {
          msg += `\n${e.emoji ?? '👾'} *${e.name}* uses *${bossAtk.attackName}*!\n`
          msg += `🩸 *${totalPlayerDmg}* damage!${bossAtk.bypassDefense ? ' _(bypasses DEF)_' : ''}\n`
        }
      }

      if (bossAtk.narrativeLines?.length) msg += `_${bossAtk.narrativeLines[0]}_\n`
      if (dealResult.narrativeLine) msg += `_${dealResult.narrativeLine}_\n`
      msg += `❤️ ${player.name}: ${hpBar(player.hp, player.maxHp)}`
    } else if (Math.random() > calcMonsterHitChance(e, player)) {
      msg += `\n${e.emoji ?? '👾'} *${e.name}* lashes back at *${player.name}*... *MISSES!*`
    } else {
      const dmg = calcMonsterDamage(e.atk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), false)
      const sustain = applyPartyIncoming(player, dmg, cs, e, battle, ctx.from)
      msg += applyPartyHpDamage(player, sustain.damage, cs)
      if (sustain.message) msg += sustain.message + '\n'
      msg += `\n${e.emoji ?? '👾'} *${e.name}* strikes *${player.name}* for *${sustain.damage}* damage!\n`
      msg += `❤️ ${player.name}: ${hpBar(player.hp, player.maxHp)}`
    }

    outbox.push({ turn: {
      player, e, msg: msg + `\n\n*${p}dparty attack* · *${p}dparty defend* · *${p}dparty flee*`,
      hpBeforeTurn, eHpBeforeTurn, boss,
    } })
    if (player.hp <= 0) downJid = ctx.from
    return player
  })

  // Flush the queued sends — a failed send must never block the state
  // resolution below (a stuck battle flag is worse than a lost message).
  for (const item of outbox) {
    try {
      if (item.turn) await sendBattleTurnReply(ctx, item.turn)
      else if (item.thunk) await item.thunk()
      else if (item.text != null) await ctx.reply(item.text)
    } catch {}
  }
  // A refused Blaze Heart is not a move: the turn stays with this member.
  if (refused) return
  if (victoryPending || (party.battle?.enemy?.hp ?? 1) <= 0) return resolvePartyVictory(ctx, party)
  await karrenPartyPulse(ctx, party)
  if (downJid) await handlePartyMemberDown(ctx, party, downJid)
  // A completed action passes the turn to the next member — unless the
  // battle just ended (resolvePartyVictory cleared party.battle).
  if (party.battle) { advancePartyTurn(ctx.db, party); const formationText=partyFormationReadout(party.battle); if(formationText) await ctx.reply(formationText) }
}

// ── Party battle: Surtr, the Molten Colossus ────────────────────────────────
// Surtr's skill in a PARTY fight — the party-combat twin of plugins/surtr.js.
// Members carry no battleState of their own, so every gate and every latch runs
// on the per-member `charState` (battle.charState[jid]) exactly the way Blaze
// Heart's, Kurama's and the Sanctum's do, and it resets with the fight for free.
//
// The shape is Blaze Heart's, because her skills are the same kind of thing: a
// charge burned in the gate, one strike through the stock pipeline
// (calcPlayerDamage -> applyDefense -> applyHighDefenseCatchup), the boss
// engine's event hooks when the enemy is an anime boss, then the enemy's answer.
//
// What is different, and why it is here rather than in the party router:
//   • Twilight is a SELF buff, not a strike. It grows maxHp and writes an ATK
//     strengthen onto the player record, and it has to be put back when the
//     fight ends — resolvePartyVictory does that (clearSurtrKit), so a member
//     who won as a colossus walks out as themselves.
//   • Remnant Ash is a free exit: it ends the transformation and hands back a
//     quarter of the growth as healing, then the enemy still gets its answer.
//   • Laevatain is the only one that rolls accuracy, and only when it is not
//     the stoked swing (calcPlayerHitChance returns 1.0 then).
async function battleSurtr(ctx, skillId = null) {
  ctx = partyContext(ctx)
  const p = config.prefix
  const party = findPartyForPlayer(ctx.db, ctx.from)
  if (!party) return ctx.reply(`❌ You're not in a party.`)
  if (!party.battle) return ctx.reply(`❌ Your party isn't in a battle. Use *${p}dparty enter <dungeon>*.`)

  // Fixed turn order: only the member at the cursor may act this round.
  const notTurn = await notYourTurn(ctx, party)
  if (notTurn) return ctx.reply(notTurn)

  const skill = surtrSkillByCommand(skillId)
  if (!skill) {
    const cs = party.battle.charState?.[ctx.from] ?? null
    return ctx.reply(buildSurtrMenu(ctx.player ?? { equippedCharacter: 'surtr' }, p, cs))
  }

  // Mutator records the outcome only — sends are queued in `outbox` and
  // flushed after updatePlayer settles, and victory / member-down resolution
  // happens there too. No I/O and no nested updatePlayer inside the lane.
  let outbox = []
  let victoryPending = false
  let downJid = null
  let refused = false

  await updatePlayer(ctx.db, ctx.from, async player => {
    const battle = party.battle
    const e = battle.enemy
    const eHpBeforeTurn = e.hp
    const boss = e.isBoss ?? false

    battle.charState = battle.charState ?? {}
    const cs = battle.charState[ctx.from] = battle.charState[ctx.from] ?? {}
    battle.contributions = battle.contributions ?? {}

    if (!hasSurtr(player)) {
      refused = true
      outbox.push({ text: `🌋 *Surtr* is not on your slot. _Equip her first._` })
      return player
    }

    // Her own turn's price (Twilight) and the giant's clock, off the member's
    // own state — the party has no shared status funnel.
    const tick = surtrTurnTick(player, cs)
    let pre = tick.lines.length ? tick.lines.join('\n') + '\n' : ''
    if (tick.died || player.hp <= 0) {
      outbox.push({ text: pre })
      downJid = ctx.from
      return player
    }

    pre += applyPartyBeastTurn(player, battle, cs, ctx.from)
    if (e.hp <= 0) {
      outbox.push({ text: pre + `\n${e.emoji ?? '👾'} *${e.name}* falls to the summon!` })
      victoryPending = true
      return player
    }

    // ── The gates. A refusal costs neither the charge nor the turn. ──────
    let gate = { ok: true }
    if (skill.id === 'molten_giant') gate = activateMoltenGiant(player, cs)
    else if (skill.id === 'surtrs_flame') gate = activateSurtrFlame(player, cs)
    else if (skill.id === 'twilight') gate = activateTwilight(player, cs)
    else if (skill.id === 'remnant_ash') {
      if (!twilightActive(player, cs)) {
        gate = { ok: false, message: `🕯️ *Remnant Ash* has nothing to put out. _Twilight is not running._` }
      } else {
        gate = { ok: true, ash: endTwilight(player, cs, { heal: true }) }
      }
    }
    if (!gate.ok) {
      refused = true
      if (gate.message) outbox.push({ text: gate.message })
      return player
    }

    let msg = pre

    if (skill.id === 'twilight') {
      msg +=
        `🌋 *TWILIGHT — THE COLOSSUS STOPS PRETENDING* 🌋\n─────────────\n` +
        `_She gets taller. The fires get louder._\n\n` +
        `❤️ Max HP *${gate.beforeMax} → ${gate.grownMax}* _(${gate.hp} now)_\n` +
        `⚔️ +*${gate.atkGain}* ${gate.atkKey.toUpperCase()}\n` +
        `🔥 *+${Math.round((TWILIGHT_OUTGOING - 1) * 100)}%* damage · *+1* target\n` +
        `⏳ *No duration.* _It ends when she ends it, or when she does._\n` +
        `🩸 _It costs her *${Math.round(gate.tickFraction * 100)}%* of her max HP every turn._\n`
    } else if (skill.id === 'remnant_ash') {
      msg +=
        `🕯️ *REMNANT ASH*\n─────────────\n` +
        `_The fires fold back down into the sword._\n` +
        `💚 *+${gate.ash.healed}* HP restored _(now ${gate.ash.hp}/${gate.ash.maxHp})_\n`
    } else {
      if (skill.id === 'molten_giant') {
        msg +=
          `🗡️ *MOLTEN GIANT* 🗡️\n─────────────\n` +
          `_The floor splits, and something the size of a house climbs out of it, already on fire._\n` +
          `_It stands beside her for *${gate.turns}* turns — *+${Math.round((MOLTEN_GIANT_OUTGOING - 1) * 100)}%* damage and one more target._\n\n`
      }
      msg += `${skill.emoji} *${skill.name.toUpperCase()}* — _on *${e.name}*_\n📖 _${skill.flavor}_\n\n`

      const needsRoll = skill.id === 'laevatain' && !laevatainStoked(player, cs)
      const hits = needsRoll ? Math.random() <= calcPlayerHitChance(player, e, cs) : true

      if (!hits) {
        msg += `💨 The edge goes wide — *MISSED!*\n`
        if (skill.id === 'laevatain') noteLaevatainHit(cs, { killed: false })
      } else {
        const mult = skill.id === 'laevatain' ? laevatainMultiplier(player, cs)
          : skill.id === 'molten_giant' ? MOLTEN_GIANT_MULT
            : gate.multiplier
        const targetDef = getEffectiveStat(e, 'def')
        const effectiveDef = skill.id === 'surtrs_flame'
          ? Math.max(0, targetDef * (1 - gate.defPierce))
          : targetDef

        let { rawDmg, isCrit } = calcPlayerDamage(player, null, mult, 0, { battleState: cs })
        let finalDmg = applyDefense(rawDmg, effectiveDef, player, e, cs)

        if (boss) {
          // The strike counts as the player's attack for boss-special purposes,
          // the same pair every other party signature uses.
          withBossBattleStateFor(cs)(player, e, bp => {
            const basicResult = applyBossSpecial(bp, EVENT.PLAYER_BASIC_ATTACK, {
              damage: finalDmg, element: 'fire', isCrit, isHit: true,
            })
            if (basicResult.modified && basicResult.damage !== undefined) finalDmg = basicResult.damage
            if (basicResult.narrativeLine) msg += `_${basicResult.narrativeLine}_\n`

            const takeResult = applyBossSpecial(bp, EVENT.ENEMY_TAKE_DAMAGE, {
              damage: finalDmg, element: 'fire', isCrit, isHit: true,
            })
            if (takeResult.modified && takeResult.damage !== undefined) finalDmg = takeResult.damage
            if (takeResult.narrativeLine) msg += `_${takeResult.narrativeLine}_\n`

            if (takeResult.reflectDamage) {
              msg += applyPartyHpDamage(player, takeResult.reflectDamage, cs)
              msg += `🔁 *Full Counter!* The fire is reflected!\n🩸 *${takeResult.reflectDamage}* damage back at you!\n`
            }
          })
        }

        e.hp = Math.max(0, e.hp - finalDmg)
        battle.contributions = battle.contributions ?? {}
        battle.contributions[ctx.from] = (battle.contributions[ctx.from] ?? 0) + finalDmg

        msg += `🩸 *${finalDmg.toLocaleString('en-US')}* damage!${isCrit ? ' 💥 *CRITICAL!*' : ''}` +
          (skill.id === 'surtrs_flame' ? ` _(reaches through ${Math.round(gate.defPierce * 100)}% of their DEF)_` : '') + '\n'

        if (skill.id === 'surtrs_flame' && e.hp > 0) {
          const amount = Math.max(1, Math.floor((Number(e.maxHp) || 0) * SURTR_FLAME_BURN_FRACTION))
          const res = addStatusEffect(e, {
            type: 'burn', amount, duration: SURTR_FLAME_BURN_TURNS, sourceId: 'surtr_flame',
          })
          if (!res?.immune && !res?.blocked) {
            msg += `🔥 _Burning for *${SURTR_FLAME_BURN_TURNS}* turns — *${amount}* a turn._\n`
          }
        }

        if (skill.id === 'laevatain') {
          const stoked = noteLaevatainHit(cs, { killed: e.hp <= 0 })
          if (stoked.stoked) msg += `🔥 *The fires are stoked.* _The next Laevatain lands for more, and it does not miss._\n`
        }
      }

      if (player.hp <= 0) {
        outbox.push({ text: msg })
        downJid = ctx.from
        return player
      }
      if (e.hp <= 0) {
        outbox.push({ text: msg })
        victoryPending = true
        return player
      }
      if (boss) {
        withBossBattleStateFor(cs)(player, e, bp => {
          const phase = checkBossPhase(bp)
          if (phase?.triggered && phase.lines?.length) {
            msg += `\n⚡ *— PHASE SHIFT —*\n` + phase.lines.join('\n') + '\n'
          }
        })
      }
    }

    if (e.hp <= 0) {
      outbox.push({ text: msg })
      victoryPending = true
      return player
    }

    // Enemy retaliates against the caster.
    const enemyStatus = processStatusTurn(e)
    if (enemyStatus.lines.length) msg += enemyStatus.lines.join('\n') + '\n'
    if (e.hp <= 0) {
      outbox.push({ text: msg })
      victoryPending = true
      return player
    }
    const hpBeforeTurn = player.hp
    if (graceHoldsEnemyTurn(player, cs)) {
      msg += `\n${graceEnemyHeldLine(e, player, cs)}`
    } else if (enemyStatus.incapacitated) {
      msg += `\n${e.emoji ?? '👾'} *${e.name}* is unable to attack.`
    } else if (Math.random() > calcMonsterHitChance(e, player)) {
      msg += `\n${e.emoji ?? '👾'} *${e.name}* lashes back at *${player.name}*... *MISSES!*`
    } else {
      const dmg = calcMonsterDamage(e.atk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), false)
      const sustain = applyPartyIncoming(player, dmg, cs, e, battle, ctx.from)
      msg += applyPartyHpDamage(player, sustain.damage, cs)
      if (sustain.message) msg += sustain.message + '\n'
      msg += `\n${e.emoji ?? '👾'} *${e.name}* strikes *${player.name}* for *${sustain.damage}* damage!\n`
      msg += `❤️ ${player.name}: ${hpBar(player.hp, player.maxHp)}`
    }

    const status = surtrStatusLine(player, cs)
    outbox.push({ turn: {
      player, e,
      msg: msg + (status ? `\n${status}` : '') + `\n\n*${p}dparty attack* · *${p}dparty defend* · *${p}dparty surtr* · *${p}dparty flee*`,
      hpBeforeTurn, eHpBeforeTurn, boss,
    } })
    if (player.hp <= 0) downJid = ctx.from
    return player
  })

  // Flush the queued sends — a failed send must never block the state
  // resolution below (a stuck battle flag is worse than a lost message).
  for (const item of outbox) {
    try {
      if (item.turn) await sendBattleTurnReply(ctx, item.turn)
      else if (item.thunk) await item.thunk()
      else if (item.text != null) await ctx.reply(item.text)
    } catch {}
  }
  // A refused skill is not a move: the turn stays with this member.
  if (refused) return
  if (victoryPending || (party.battle?.enemy?.hp ?? 1) <= 0) return resolvePartyVictory(ctx, party)
  await karrenPartyPulse(ctx, party)
  if (downJid) await handlePartyMemberDown(ctx, party, downJid)
  if (party.battle) { advancePartyTurn(ctx.db, party); const formationText=partyFormationReadout(party.battle); if(formationText) await ctx.reply(formationText) }
}

// ── Party battle: Baryon Mode / Kurama (Naruto) ─────────────────────────────
// Naruto's once-per-battle Nine Tails summon — the party-combat twin of
// plugins/kurama.js. Same shape as battleCinderVerdict above: the strike runs
// through the stock calcPlayerDamage() -> applyDefense() -> applyHighDefenseCatchup()
// pipeline with the Baryon multiplier, and the per-member charge lives on
// party.battle.charState via activateKurama(player, cs), so it resets with the
// fight for free. Two things it adds on top: activateKurama also burns a slice of
// Naruto's OWN health (the Baryon self-cost, floored so it never downs him), and
// after the strike lands a lifespan-drain rider tears a flat share of the enemy's
// MAX HP as true damage no armour softens. The enemy then retaliates against the
// caster normally — there is no tangle, so this is a heavy finisher, not a lock.
// ── Party battle: Avatar Elemental Bending Art (.dparty bend / .bend) ───────
async function battleBend(ctx, rawElement = null) {
  ctx = partyContext(ctx)
  const p = config.prefix
  const party = findPartyForPlayer(ctx.db, ctx.from)
  if (!party) return ctx.reply(`❌ You're not in a party.`)
  if (!party.battle) return ctx.reply(`❌ Your party isn't in a battle. Use *${p}dparty enter <dungeon>*.`)

  const notTurn = await notYourTurn(ctx, party)
  if (notTurn) return ctx.reply(notTurn)

  const reqEl = normalizeAffinityId(rawElement)
  let outbox = []
  let victoryPending = false
  let downJid = null
  let refused = false

  await updatePlayer(ctx.db, ctx.from, async player => {
    if (!hasAffinity(player)) {
      refused = true
      outbox.push({ text: `🐢 You have not awakened an Elemental Affinity yet! Run *${p}affinity* at Level 60+.` })
      return player
    }
    if (reqEl && !hasAffinity(player, reqEl)) {
      refused = true
      outbox.push({ text: `🚫 You do not possess *${getElementDef(reqEl).name}*!` })
      return player
    }

    const battle = party.battle
    const e = battle.enemy
    const eHpBeforeTurn = e.hp
    const boss = e.isBoss ?? false

    battle.charState = battle.charState ?? {}
    const cs = battle.charState[ctx.from] = battle.charState[ctx.from] ?? {}

    if (cs.affinityBendUsed) {
      refused = true
      outbox.push({ text: `🌀 You have already unleashed *${p}bend* in this party battle!` })
      return player
    }
    if ((player.mp ?? 0) < BEND_MP_COST) {
      refused = true
      outbox.push({ text: `💧 Need *${BEND_MP_COST} MP* to channel *${p}bend* _(You have ${player.mp ?? 0} MP)_.` })
      return player
    }

    cs.affinityBendUsed = true
    player.mp = Math.max(0, (player.mp ?? 0) - BEND_MP_COST)
    const prof = computeBendProfile(player, reqEl)

    let pre = ''
    const permaSeverLine = tickPermanentSever(player)
    if (permaSeverLine) pre += permaSeverLine + '\n'
    if (player.hp <= 0) {
      if (pre) outbox.push({ text: pre })
      downJid = ctx.from
      return player
    }

    pre += applyPartyBeastTurn(player, battle, cs, ctx.from)
    if (e.hp <= 0) {
      outbox.push({ text: pre + `\n${e.emoji ?? '👾'} *${e.name}* falls to the summon!` })
      victoryPending = true
      return player
    }

    let msg = pre + `${prof.emoji} *${player.name}* channels *${prof.artName}* *(×${prof.multiplier.toFixed(2)})*!\n_${prof.flavor}_\n\n`

    let { rawDmg, isCrit } = calcPlayerDamage(player, null, prof.multiplier, 0, { battleState: cs })
    const defPierce = prof.sub?.id === 'lightning' ? 0.25 : prof.sub?.id === 'metal' ? 0.20 : 0
    const effDef = Math.max(0, getEffectiveStat(e, 'def') * (1 - defPierce))
    let finalDmg = applyDefense(rawDmg, effDef, player, e, cs)
    const bendElement = prof.moveElement ?? (prof.element === 'air' ? 'wind' : prof.element)
    const partyPhase = resolveBendingPhaseChain(
      player,
      e,
      { affinity: prof.element, element: bendElement, isBend: true },
      finalDmg,
    )
    finalDmg = partyPhase.damage

    if (boss) {
      withBossBattleStateFor(cs)(player, e, bp => {
        const basicResult = applyBossSpecial(bp, EVENT.PLAYER_BASIC_ATTACK, {
          damage: finalDmg, element: bendElement, isCrit, isHit: true,
        })
        if (basicResult.modified && basicResult.damage !== undefined) finalDmg = basicResult.damage
        if (basicResult.narrativeLine) msg += `_${basicResult.narrativeLine}_\n`

        const takeResult = applyBossSpecial(bp, EVENT.ENEMY_TAKE_DAMAGE, {
          damage: finalDmg, element: bendElement, isCrit, isHit: true,
        })
        if (takeResult.modified && takeResult.damage !== undefined) finalDmg = takeResult.damage
        if (takeResult.narrativeLine) msg += `_${takeResult.narrativeLine}_\n`

        if (takeResult.reflectDamage) {
          msg += applyPartyHpDamage(player, takeResult.reflectDamage, cs)
          msg += `🔁 *Full Counter!* *${takeResult.reflectDamage}* damage reflected back!\n`
        }
      })
    }

    e.hp = Math.max(0, e.hp - finalDmg)
    battle.contributions[ctx.from] = (battle.contributions[ctx.from] ?? 0) + finalDmg

    const splashCaption = `${prof.emoji} *${prof.artName.toUpperCase()}* — _${prof.masterLabel}_`
    outbox.push({ thunk: () => sendImage(ctx, prof.crestKey, splashCaption) })

    const riders = e.hp > 0 ? applyElementalBendRider(player, e, prof, finalDmg) : []
    for (const el of prof.elementsUsed) grantMasteryXp(player, 8, { elementId: el, source: 'combat' })

    msg += `💥 *${finalDmg.toLocaleString('en-US')}* damage!${isCrit ? ' ⚡ *CRITICAL!*' : ''}\n`
    if (partyPhase.lines.length) msg += partyPhase.lines.join('\n') + '\n'
    if (riders.length) msg += riders.join('\n') + '\n'
    msg += `❤️ ${e.name}: ${hpBar(e.hp, e.maxHp)}\n`

    if (player.hp <= 0) {
      outbox.push({ text: msg })
      downJid = ctx.from
      return player
    }
    if (e.hp <= 0) {
      outbox.push({ text: msg })
      victoryPending = true
      return player
    }

    const enemyStatus = processStatusTurn(e)
    if (enemyStatus.lines.length) msg += enemyStatus.lines.join('\n') + '\n'
    if (e.hp <= 0) {
      outbox.push({ text: msg })
      victoryPending = true
      return player
    }

    const hpBeforeTurn = player.hp
    if (graceHoldsEnemyTurn(player, cs)) {
      msg += `\n${graceEnemyHeldLine(e, player, cs)}`
    } else if (enemyStatus.incapacitated) {
      msg += `\n${e.emoji ?? '👾'} *${e.name}* is unable to attack.`
    } else if (Math.random() > calcMonsterHitChance(e, player)) {
      msg += `\n${e.emoji ?? '👾'} *${e.name}* lashes back at *${player.name}*... *MISSES!*`
    } else {
      const dmg = calcMonsterDamage(e.atk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), false)
      const sustain = applyPartyIncoming(player, dmg, cs, e, battle, ctx.from)
      msg += applyPartyHpDamage(player, sustain.damage, cs)
      if (sustain.message) msg += sustain.message + '\n'
      msg += `\n${e.emoji ?? '👾'} *${e.name}* strikes *${player.name}* for *${sustain.damage}* damage!\n`
      msg += `❤️ ${player.name}: ${hpBar(player.hp, player.maxHp)}`
    }

    outbox.push({ turn: {
      player, e, msg: msg + `\n\n*${p}dparty attack* · *${p}dparty defend* · *${p}dparty flee*`,
      hpBeforeTurn, eHpBeforeTurn, boss,
    } })
    if (player.hp <= 0) downJid = ctx.from
    return player
  })

  for (const item of outbox) {
    try {
      if (item.turn) await sendBattleTurnReply(ctx, item.turn)
      else if (item.thunk) await item.thunk()
      else if (item.text != null) await ctx.reply(item.text)
    } catch {}
  }
  if (refused) return
  if (victoryPending || (party.battle?.enemy?.hp ?? 1) <= 0) return resolvePartyVictory(ctx, party)
  await karrenPartyPulse(ctx, party)
  if (downJid) await handlePartyMemberDown(ctx, party, downJid)
  if (party.battle) { advancePartyTurn(ctx.db, party); const formationText=partyFormationReadout(party.battle); if(formationText) await ctx.reply(formationText) }
}

async function battleKurama(ctx) {
  ctx = partyContext(ctx)
  const p = config.prefix
  const party = findPartyForPlayer(ctx.db, ctx.from)
  if (!party) return ctx.reply(`❌ You're not in a party.`)
  if (!party.battle) return ctx.reply(`❌ Your party isn't in a battle. Use *${p}dparty enter <dungeon>*.`)

  // Fixed turn order: only the member at the cursor may act this round.
  const notTurn = await notYourTurn(ctx, party)
  if (notTurn) return ctx.reply(notTurn)

  // Mutator records the outcome only — sends are queued in `outbox` and
  // flushed after updatePlayer settles, and victory / member-down resolution
  // happens there too. No I/O and no nested updatePlayer inside the lane
  // (the nested same-player write deadlocks it — the old stuck-battle bug).
  let outbox = []
  let victoryPending = false
  let downJid = null

  await updatePlayer(ctx.db, ctx.from, async player => {
    const battle = party.battle
    const e = battle.enemy
    const eHpBeforeTurn = e.hp
    const boss = e.isBoss ?? false

    battle.charState = battle.charState ?? {}
    const cs = battle.charState[ctx.from] = battle.charState[ctx.from] ?? {}

    const gate = activateKurama(player, cs)
    if (!gate.ok) {
      if (gate.message) outbox.push({ text: gate.message })
      return player
    }

    // Summon splash, its own message the moment the fusion commits, before the
    // party turn text. Never blocks the turn (media failure is swallowed).
    outbox.push({ thunk: () => sendKuramaSummonImage(ctx, `🦊🌀 *${player.name} tears the seal open. KURAMA answers.*`, ctx.partyTransportFrom ?? ctx.from) })

    let pre = ''
    const permaSeverLine = tickPermanentSever(player)
    if (permaSeverLine) pre += permaSeverLine + '\n'
    // The Baryon self-cost is already paid inside the gate; show it whether the
    // strike then lands or misses. A player the self-cost + a DoT downs is
    // handled by the hp check below, same as Cinder Verdict's permaSever tick.
    if (gate.selfCostLine) pre += gate.selfCostLine + '\n'
    if (player.hp <= 0) {
      if (pre) outbox.push({ text: pre })
      downJid = ctx.from
      return player
    }

    pre += applyPartyBeastTurn(player, battle, cs, ctx.from)
    if (e.hp <= 0) {
      outbox.push({ text: pre + `\n${e.emoji ?? '👾'} *${e.name}* falls to the summon!` })
      victoryPending = true
      return player
    }

    let msg = pre +
      `🦊🌀 *BARYON MODE: KURAMA*\n─────────────\n` +
      `💬 _"${narutoBattleLine('party')}"_\n` +
      `_${player.name} and the Nine Tails fold into one against *${e.name}*._\n\n`

    if (Math.random() > calcPlayerHitChance(player, e, cs)) {
      msg += `💨 _The fusion overshoots by a hair and *MISSES!*_\n`
      outbox.push({ turn: {
        player, e, msg: msg + `\n*${p}dparty attack* · *${p}dparty defend* · *${p}dparty flee*`,
        hpBeforeTurn: player.hp, eHpBeforeTurn, boss,
      } })
      return player
    }

    let { rawDmg, isCrit } = calcPlayerDamage(player, null, gate.multiplier, 0, { battleState: cs })
    let finalDmg = applyDefense(rawDmg, getEffectiveStat(e, 'def'), player, e, cs)

    if (boss) {
      // The strike counts as the player's attack for boss-special purposes —
      // same PLAYER_BASIC_ATTACK/ENEMY_TAKE_DAMAGE pair as a regular hit, so a
      // boss can still nullify, adapt or reflect the STRIKE. The drain rider
      // below is true damage and deliberately bypasses this layer.
      withBossBattleStateFor(cs)(player, e, bp => {
        const basicResult = applyBossSpecial(bp, EVENT.PLAYER_BASIC_ATTACK, {
          damage: finalDmg, element: 'physical', isCrit, isHit: true,
        })
        if (basicResult.modified && basicResult.damage !== undefined) finalDmg = basicResult.damage
        if (basicResult.narrativeLine) msg += `_${basicResult.narrativeLine}_\n`

        const takeResult = applyBossSpecial(bp, EVENT.ENEMY_TAKE_DAMAGE, {
          damage: finalDmg, element: 'physical', isCrit, isHit: true,
        })
        if (takeResult.modified && takeResult.damage !== undefined) finalDmg = takeResult.damage
        if (takeResult.narrativeLine) msg += `_${takeResult.narrativeLine}_\n`

        if (takeResult.reflectDamage) {
          msg += applyPartyHpDamage(player, takeResult.reflectDamage, cs)
          msg += `🔁 *Full Counter!* The strike is reflected!\n🩸 *${takeResult.reflectDamage}* damage back at you!\n`
        }
      })
    }

    e.hp = Math.max(0, e.hp - finalDmg)
    battle.contributions[ctx.from] = (battle.contributions[ctx.from] ?? 0) + finalDmg
    msg += `🌠 *Baryon Rasengan* lands for *${finalDmg}*!${isCrit ? ' 💥 *CRITICAL!*' : ''}\n`

    // Lifespan drain rider — true damage, a flat share of the enemy's MAX HP,
    // no armour applies. Applied after the strike so the two together can finish
    // an enemy the strike alone left standing.
    const drainRes = resolveKuramaDrain(e, gate.drainPct)
    if (drainRes.drain > 0) {
      e.hp = drainRes.newHp
      battle.contributions[ctx.from] = (battle.contributions[ctx.from] ?? 0) + drainRes.drain
      msg += `🦊 _The fox's touch tears *${drainRes.drain}* more lifespan out of *${e.name}*, past any armour._\n`
    }
    msg += `❤️ ${e.name}: ${hpBar(e.hp, e.maxHp)}\n`

    if (player.hp <= 0) {
      outbox.push({ text: msg })
      downJid = ctx.from
      return player
    }

    if (e.hp <= 0) {
      outbox.push({ text: msg })
      victoryPending = true
      return player
    }

    if (boss) {
      withBossBattleStateFor(cs)(player, e, bp => {
        const hitResult = applyBossSpecial(bp, EVENT.PLAYER_HIT_ENEMY, {
          damage: finalDmg, isCrit, element: 'physical', isHit: true,
        })
        if (hitResult.narrativeLine) msg += `_${hitResult.narrativeLine}_\n`
        if (finalDmg > 0) msg += `💬 _"${getBossHitLine(bp)}"_\n`
      })

      if (e.hp <= 0) {
        outbox.push({ text: msg })
        victoryPending = true
        return player
      }

      withBossBattleStateFor(cs)(player, e, bp => {
        const phase = checkBossPhase(bp)
        if (phase?.triggered && phase.lines?.length) {
          msg += `\n⚡ *— PHASE SHIFT —*\n` + phase.lines.join('\n') + '\n'
        }
      })
    }

    if (e.hp <= 0) {
      outbox.push({ text: msg })
      victoryPending = true
      return player
    }

    // Enemy retaliates against the caster (the summon draws its attention).
    const enemyStatus = processStatusTurn(e)
    if (enemyStatus.lines.length) msg += enemyStatus.lines.join('\n') + '\n'
    if (e.hp <= 0) {
      outbox.push({ text: msg })
      victoryPending = true
      return player
    }
    const hpBeforeTurn = player.hp
    if (graceHoldsEnemyTurn(player, cs)) {
      // 👑 King Yato — Grace of the Crown: turns 1-5 the enemy does not act at all.
      msg += `\n${graceEnemyHeldLine(e, player, cs)}`
    } else if (enemyStatus.incapacitated) {
      msg += `\n${e.emoji ?? '👾'} *${e.name}* is unable to attack.`
    } else if (boss) {
      let bossAtk = null
      let dealResult = null
      withBossBattleStateFor(cs)(player, e, bp => {
        bossAtk = buildEnemyAttack(bp)
        dealResult = applyBossSpecial(bp, EVENT.ENEMY_DEAL_DAMAGE, {
          damage: bossAtk.damage, isHit: true,
        })
      })
      if (!bossAtk) {
        const fb = plainBossStrike(e)   // plain boss: bridge above no-op'd
        bossAtk = fb.bossAtk
        dealResult = fb.dealResult
      }
      const rawBossAtk = dealResult.modified && dealResult.damage !== undefined
        ? dealResult.damage
        : bossAtk.damage

      const hitList = Array.isArray(dealResult.guaranteedHits) ? dealResult.guaranteedHits : null
      let totalPlayerDmg = 0

      if (hitList) {
        for (const rawHit of hitList) {
          const incoming = applyPartyIncoming(player, rawHit, cs, e, battle, ctx.from)
          const hDmg = incoming.damage
          if (incoming.message) msg += incoming.message + '\n'
          msg += applyPartyHpDamage(player, hDmg, cs)
          totalPlayerDmg += hDmg
        }
        msg += `\n${e.emoji ?? '👾'} *${e.name}* unleashes *${bossAtk.attackName}*! _(${hitList.length} hits)_\n`
        msg += `🩸 *${totalPlayerDmg}* total damage! _(ignores DEF)_\n`
      } else {
        const primaryHit = bossAtk.bypassDefense
          ? rawBossAtk
          : calcMonsterDamage(rawBossAtk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), false)
        const sustain = applyPartyIncoming(player, primaryHit, cs, e, battle, ctx.from)
        msg += applyPartyHpDamage(player, sustain.damage, cs)
        totalPlayerDmg = sustain.damage
        if (sustain.message) msg += sustain.message + '\n'

        if (bossAtk.doubleStrike) {
          const hit2 = bossAtk.bypassDefense
            ? rawBossAtk
            : calcMonsterDamage(rawBossAtk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), false)
          const sustain2 = applyPartyIncoming(player, hit2, cs, e, battle, ctx.from)
          msg += applyPartyHpDamage(player, sustain2.damage, cs)
          totalPlayerDmg += sustain2.damage
          if (sustain2.message) msg += sustain2.message + '\n'
          msg += `\n${e.emoji ?? '👾'} *${e.name}* uses *${bossAtk.attackName}*! ⚡ *DOUBLE STRIKE!*\n`
          msg += `🩸 *${totalPlayerDmg}* total damage!\n`
        } else {
          msg += `\n${e.emoji ?? '👾'} *${e.name}* uses *${bossAtk.attackName}*!\n`
          msg += `🩸 *${totalPlayerDmg}* damage!${bossAtk.bypassDefense ? ' _(bypasses DEF)_' : ''}\n`
        }
      }

      if (bossAtk.narrativeLines?.length) msg += `_${bossAtk.narrativeLines[0]}_\n`
      if (dealResult.narrativeLine) msg += `_${dealResult.narrativeLine}_\n`
      msg += `❤️ ${player.name}: ${hpBar(player.hp, player.maxHp)}`
    } else if (Math.random() > calcMonsterHitChance(e, player)) {
      msg += `\n${e.emoji ?? '👾'} *${e.name}* lashes back at *${player.name}*... *MISSES!*`
    } else {
      const dmg = calcMonsterDamage(e.atk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), false)
      const sustain = applyPartyIncoming(player, dmg, cs, e, battle, ctx.from)
      msg += applyPartyHpDamage(player, sustain.damage, cs)
      if (sustain.message) msg += sustain.message + '\n'
      msg += `\n${e.emoji ?? '👾'} *${e.name}* strikes *${player.name}* for *${sustain.damage}* damage!\n`
      msg += `❤️ ${player.name}: ${hpBar(player.hp, player.maxHp)}`
    }

    outbox.push({ turn: {
      player, e, msg: msg + `\n\n*${p}dparty attack* · *${p}dparty defend* · *${p}dparty flee*`,
      hpBeforeTurn, eHpBeforeTurn, boss,
    } })
    if (player.hp <= 0) downJid = ctx.from
    return player
  })

  // Flush the queued sends — a failed send must never block the state
  // resolution below (a stuck battle flag is worse than a lost message).
  for (const item of outbox) {
    try {
      if (item.turn) await sendBattleTurnReply(ctx, item.turn)
      else if (item.thunk) await item.thunk()
      else if (item.text != null) await ctx.reply(item.text)
    } catch {}
  }
  if (victoryPending || (party.battle?.enemy?.hp ?? 1) <= 0) return resolvePartyVictory(ctx, party)
  await karrenPartyPulse(ctx, party)
  if (downJid) await handlePartyMemberDown(ctx, party, downJid)
  // A completed action passes the turn to the next member — unless the
  // battle just ended (resolvePartyVictory cleared party.battle).
  if (party.battle) { advancePartyTurn(ctx.db, party); const formationText=partyFormationReadout(party.battle); if(formationText) await ctx.reply(formationText) }
}

// ── Party battle: Hollow Purple (Gojo) ──────────────────────────────────────
// Gojo's once-per-battle, no-MP imaginary-mass burst — the party-combat twin of
// plugins/purple.js. Same shape as battleCinderVerdict above, with the two
// differences Hollow Purple always carries: it NEVER MISSES (no accuracy roll)
// and no armour softens it (the multiplier is applied RAW, without applyDefense
// / applyHighDefenseCatchup). A boss can still nullify, adapt or reflect it
// through its ENEMY_TAKE_DAMAGE special — the same defensive layer every hit
// passes. The per-member charge lives on party.battle.charState via
// activateHollowPurple(player, cs), so it resets with the fight for free.
async function battleHollowPurple(ctx) {
  ctx = partyContext(ctx)
  const p = config.prefix
  const party = findPartyForPlayer(ctx.db, ctx.from)
  if (!party) return ctx.reply(`❌ You're not in a party.`)
  if (!party.battle) return ctx.reply(`❌ Your party isn't in a battle. Use *${p}dparty enter <dungeon>*.`)

  // Fixed turn order: only the member at the cursor may act this round.
  const notTurn = await notYourTurn(ctx, party)
  if (notTurn) return ctx.reply(notTurn)

  // Mutator records the outcome only — sends are queued in `outbox` and
  // flushed after updatePlayer settles, and victory / member-down resolution
  // happens there too. No I/O and no nested updatePlayer inside the lane
  // (the nested same-player write deadlocks it — the old stuck-battle bug).
  let outbox = []
  let victoryPending = false
  let downJid = null

  await updatePlayer(ctx.db, ctx.from, async player => {
    const battle = party.battle
    const e = battle.enemy
    const eHpBeforeTurn = e.hp
    const boss = e.isBoss ?? false

    battle.charState = battle.charState ?? {}
    const cs = battle.charState[ctx.from] = battle.charState[ctx.from] ?? {}

    const gate = activateHollowPurple(player, cs)
    if (!gate.ok) {
      if (gate.message) outbox.push({ text: gate.message })
      return player
    }

    let pre = ''
    const permaSeverLine = tickPermanentSever(player)
    if (permaSeverLine) pre += permaSeverLine + '\n'
    if (player.hp <= 0) {
      if (pre) outbox.push({ text: pre })
      downJid = ctx.from
      return player
    }

    pre += applyPartyBeastTurn(player, battle, cs, ctx.from)
    if (e.hp <= 0) {
      outbox.push({ text: pre + `\n${e.emoji ?? '👾'} *${e.name}* falls to the summon!` })
      victoryPending = true
      return player
    }

    let msg = pre +
      `🟦🟥 *HOLLOW PURPLE*\n─────────────\n` +
      `_Blue draws *${e.name}* in. Red throws them out. *${player.name}* brings both hands together, and the two become one._\n\n`

    // No accuracy roll — Hollow Purple always lands. Multiplier from the stock
    // roll, applied RAW: no applyDefense(), so armour is meaningless here.
    let { rawDmg, isCrit } = calcPlayerDamage(player, null, gate.multiplier, 0, { battleState: cs })
    let finalDmg = Math.max(1, Math.round(rawDmg))

    if (boss) {
      withBossBattleStateFor(cs)(player, e, bp => {
        const basicResult = applyBossSpecial(bp, EVENT.PLAYER_BASIC_ATTACK, {
          damage: finalDmg, element: 'physical', isCrit, isHit: true,
        })
        if (basicResult.modified && basicResult.damage !== undefined) finalDmg = basicResult.damage
        if (basicResult.narrativeLine) msg += `_${basicResult.narrativeLine}_\n`

        const takeResult = applyBossSpecial(bp, EVENT.ENEMY_TAKE_DAMAGE, {
          damage: finalDmg, element: 'physical', isCrit, isHit: true,
        })
        if (takeResult.modified && takeResult.damage !== undefined) finalDmg = takeResult.damage
        if (takeResult.narrativeLine) msg += `_${takeResult.narrativeLine}_\n`

        if (takeResult.reflectDamage) {
          msg += applyPartyHpDamage(player, takeResult.reflectDamage, cs)
          msg += `🔁 *Full Counter!* The burst is reflected!\n🩸 *${takeResult.reflectDamage}* damage back at you!\n`
        }
      })
    }

    e.hp = Math.max(0, e.hp - finalDmg)
    battle.contributions[ctx.from] = (battle.contributions[ctx.from] ?? 0) + finalDmg

    msg += `🟪 *${finalDmg}* damage! _(ignores DEF)_${isCrit ? ' 💥 *CRITICAL!*' : ''}\n`
    msg += `_Everything in the line simply stops being there._\n`
    msg += `❤️ ${e.name}: ${hpBar(e.hp, e.maxHp)}\n`

    if (player.hp <= 0) {
      outbox.push({ text: msg })
      downJid = ctx.from
      return player
    }
    if (e.hp <= 0) {
      outbox.push({ text: msg })
      victoryPending = true
      return player
    }

    if (boss) {
      withBossBattleStateFor(cs)(player, e, bp => {
        const hitResult = applyBossSpecial(bp, EVENT.PLAYER_HIT_ENEMY, {
          damage: finalDmg, isCrit, element: 'physical', isHit: true,
        })
        if (hitResult.narrativeLine) msg += `_${hitResult.narrativeLine}_\n`
        if (finalDmg > 0) msg += `💬 _"${getBossHitLine(bp)}"_\n`
      })
      if (e.hp <= 0) {
        outbox.push({ text: msg })
        victoryPending = true
        return player
      }
      withBossBattleStateFor(cs)(player, e, bp => {
        const phase = checkBossPhase(bp)
        if (phase?.triggered && phase.lines?.length) {
          msg += `\n⚡ *— PHASE SHIFT —*\n` + phase.lines.join('\n') + '\n'
        }
      })
      if (e.hp <= 0) {
        outbox.push({ text: msg })
        victoryPending = true
        return player
      }
    }

    // Enemy retaliates against the caster. Tick its statuses first: a boss
    // caught in Unlimited Void is still locked, so it forfeits the counter,
    // and the lock counts down one step here too.
    const enemyStatus = processStatusTurn(e)
    if (enemyStatus.lines.length) msg += enemyStatus.lines.join('\n') + '\n'
    if (e.hp <= 0) {
      outbox.push({ text: msg })
      victoryPending = true
      return player
    }

    const hpBeforeTurn = player.hp
    if (graceHoldsEnemyTurn(player, cs)) {
      // 👑 King Yato — Grace of the Crown: turns 1-5 the enemy does not act at all.
      msg += `\n${graceEnemyHeldLine(e, player, cs)}`
    } else if (enemyStatus.incapacitated) {
      msg += `\n${e.emoji ?? '👾'} *${e.name}* is locked down and cannot act.`
    } else if (boss) {
      let bossAtk = null
      let dealResult = null
      withBossBattleStateFor(cs)(player, e, bp => {
        bossAtk = buildEnemyAttack(bp)
        dealResult = applyBossSpecial(bp, EVENT.ENEMY_DEAL_DAMAGE, {
          damage: bossAtk.damage, isHit: true,
        })
      })
      if (!bossAtk) {
        const fb = plainBossStrike(e)   // plain boss: bridge above no-op'd
        bossAtk = fb.bossAtk
        dealResult = fb.dealResult
      }
      const rawBossAtk = dealResult.modified && dealResult.damage !== undefined
        ? dealResult.damage
        : bossAtk.damage

      const hitList = Array.isArray(dealResult.guaranteedHits) ? dealResult.guaranteedHits : null
      let totalPlayerDmg = 0

      if (hitList) {
        for (const rawHit of hitList) {
          // Gojo's Infinity thins each guaranteed hit as well; a no-op otherwise.
          const incoming = applyPartyIncoming(player, rawHit, cs, e, battle, ctx.from)
          const hDmg = incoming.damage
          if (incoming.message) msg += incoming.message + '\n'
          msg += applyPartyHpDamage(player, hDmg, cs)
          totalPlayerDmg += hDmg
        }
        msg += `\n${e.emoji ?? '👾'} *${e.name}* unleashes *${bossAtk.attackName}*! _(${hitList.length} hits)_\n`
        msg += `🩸 *${totalPlayerDmg}* total damage! _(ignores DEF)_\n`
      } else {
        const primaryHit = bossAtk.bypassDefense
          ? rawBossAtk
          : calcMonsterDamage(rawBossAtk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), false)
        const sustain = applyPartyIncoming(player, primaryHit, cs, e, battle, ctx.from)
        msg += applyPartyHpDamage(player, sustain.damage, cs)
        totalPlayerDmg = sustain.damage
        if (sustain.message) msg += sustain.message + '\n'

        if (bossAtk.doubleStrike) {
          const hit2 = bossAtk.bypassDefense
            ? rawBossAtk
            : calcMonsterDamage(rawBossAtk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), false)
          const sustain2 = applyPartyIncoming(player, hit2, cs, e, battle, ctx.from)
          msg += applyPartyHpDamage(player, sustain2.damage, cs)
          totalPlayerDmg += sustain2.damage
          if (sustain2.message) msg += sustain2.message + '\n'
          msg += `\n${e.emoji ?? '👾'} *${e.name}* uses *${bossAtk.attackName}*! ⚡ *DOUBLE STRIKE!*\n`
          msg += `🩸 *${totalPlayerDmg}* total damage!\n`
        } else {
          msg += `\n${e.emoji ?? '👾'} *${e.name}* uses *${bossAtk.attackName}*!\n`
          msg += `🩸 *${totalPlayerDmg}* damage!${bossAtk.bypassDefense ? ' _(bypasses DEF)_' : ''}\n`
        }
      }

      if (bossAtk.narrativeLines?.length) msg += `_${bossAtk.narrativeLines[0]}_\n`
      if (dealResult.narrativeLine) msg += `_${dealResult.narrativeLine}_\n`
      msg += `❤️ ${player.name}: ${hpBar(player.hp, player.maxHp)}`
    } else if (Math.random() > calcMonsterHitChance(e, player)) {
      msg += `\n${e.emoji ?? '👾'} *${e.name}* lashes back at *${player.name}*... *MISSES!*`
    } else {
      const dmg = calcMonsterDamage(e.atk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), false)
      const sustain = applyPartyIncoming(player, dmg, cs, e, battle, ctx.from)
      msg += applyPartyHpDamage(player, sustain.damage, cs)
      if (sustain.message) msg += sustain.message + '\n'
      msg += `\n${e.emoji ?? '👾'} *${e.name}* strikes *${player.name}* for *${sustain.damage}* damage!\n`
      msg += `❤️ ${player.name}: ${hpBar(player.hp, player.maxHp)}`
    }

    outbox.push({ turn: {
      player, e, msg: msg + `\n\n*${p}dparty attack* · *${p}dparty defend* · *${p}dparty flee*`,
      hpBeforeTurn, eHpBeforeTurn, boss,
    } })
    if (player.hp <= 0) downJid = ctx.from
    return player
  })

  // Flush the queued sends — a failed send must never block the state
  // resolution below (a stuck battle flag is worse than a lost message).
  for (const item of outbox) {
    try {
      if (item.turn) await sendBattleTurnReply(ctx, item.turn)
      else if (item.thunk) await item.thunk()
      else if (item.text != null) await ctx.reply(item.text)
    } catch {}
  }
  if (victoryPending || (party.battle?.enemy?.hp ?? 1) <= 0) return resolvePartyVictory(ctx, party)
  await karrenPartyPulse(ctx, party)
  if (downJid) await handlePartyMemberDown(ctx, party, downJid)
  // A completed action passes the turn to the next member — unless the
  // battle just ended (resolvePartyVictory cleared party.battle).
  if (party.battle) { advancePartyTurn(ctx.db, party); const formationText=partyFormationReadout(party.battle); if(formationText) await ctx.reply(formationText) }
}

// ── Party battle: Excalibur (Saber) ─────────────────────────────────────────
// Saber's once-per-battle Sword of Promised Victory — 3,000 flat damage that
// never misses and ignores DEF, gated by Saber + Excalibur equipped in the
// weapon slot. Charge lives on party.battle.charState[ctx.from] via
// armExcalibur(player, cs, { opponent: e }), so it resets per floor/fight.
async function battleExcalibur(ctx) {
  ctx = partyContext(ctx)
  const p = config.prefix
  const party = findPartyForPlayer(ctx.db, ctx.from)
  if (!party) return ctx.reply(`❌ You're not in a party.`)
  if (!party.battle) return ctx.reply(`❌ Your party isn't in a battle. Use *${p}dparty enter <dungeon>*.`)

  const notTurn = await notYourTurn(ctx, party)
  if (notTurn) return ctx.reply(notTurn)

  let outbox = []
  let victoryPending = false
  let downJid = null

  await updatePlayer(ctx.db, ctx.from, async player => {
    const battle = party.battle
    const e = battle.enemy
    const boss = e.isBoss ?? false

    battle.charState = battle.charState ?? {}
    const cs = battle.charState[ctx.from] = battle.charState[ctx.from] ?? {}

    const gate = armExcalibur(player, cs, { opponent: e })
    if (!gate.ok) {
      if (gate.message) outbox.push({ text: gate.message })
      return player
    }

    let pre = ''
    const permaSeverLine = tickPermanentSever(player)
    if (permaSeverLine) pre += permaSeverLine + '\n'
    if (player.hp <= 0) {
      if (pre) outbox.push({ text: pre })
      downJid = ctx.from
      return player
    }

    pre += applyPartyBeastTurn(player, battle, cs, ctx.from)
    if (e.hp <= 0) {
      outbox.push({ text: pre + `\n${e.emoji ?? '👾'} *${e.name}* falls to the summon!` })
      victoryPending = true
      return player
    }

    let msg = pre +
      `🔱 *EXCALIBUR — SWORD OF PROMISED VICTORY*\n─────────────\n` +
      `_🔱 *Saber* raises two hands around nothing you could name — and then the wind comes off the blade._\n` +
      `_Gold gathers along the edge until the whole floor is one colour._\n` +
      `*"EXCALIBUR!"*\n\n`

    let finalDmg = EXCALIBUR_DAMAGE

    if (boss) {
      withBossBattleStateFor(cs)(player, e, bp => {
        const takeResult = applyBossSpecial(bp, EVENT.ENEMY_TAKE_DAMAGE, {
          damage: finalDmg, element: 'light', isCrit: false, isHit: true,
        })
        if (takeResult.modified && takeResult.damage !== undefined) finalDmg = takeResult.damage
        if (takeResult.narrativeLine) msg += `_${takeResult.narrativeLine}_\n`

        if (takeResult.reflectDamage) {
          msg += applyPartyHpDamage(player, takeResult.reflectDamage, cs)
          msg += `🔁 *Full Counter!* The light is reflected!\n🩸 *${takeResult.reflectDamage}* damage back at you!\n`
        }
      })
    }

    const dealt = Math.min(Math.max(0, finalDmg), Math.max(0, e.hp ?? 0))
    e.hp = Math.max(0, e.hp - dealt)
    battle.contributions[ctx.from] = (battle.contributions[ctx.from] ?? 0) + dealt

    msg += `🩸 *${dealt}* damage! _(DEF does not apply)_\n`
    msg += `_The light goes through *${e.name}* and keeps going, out the far wall of the world._\n`
    msg += `❤️ ${e.name}: ${hpBar(e.hp, e.maxHp)}\n`

    if (player.hp <= 0) {
      outbox.push({ thunk: () => sendMoveArt(ctx, EXCALIBUR_ART, msg) })
      downJid = ctx.from
      return player
    }
    if (e.hp <= 0) {
      outbox.push({ thunk: () => sendMoveArt(ctx, EXCALIBUR_ART, msg) })
      victoryPending = true
      return player
    }

    if (boss) {
      withBossBattleStateFor(cs)(player, e, bp => {
        const hitResult = applyBossSpecial(bp, EVENT.PLAYER_HIT_ENEMY, {
          damage: dealt, isCrit: false, element: 'light', isHit: true,
        })
        if (hitResult.narrativeLine) msg += `_${hitResult.narrativeLine}_\n`
        if (dealt > 0) msg += `💬 _"${getBossHitLine(bp)}"_\n`
      })
      if (e.hp <= 0) {
        outbox.push({ thunk: () => sendMoveArt(ctx, EXCALIBUR_ART, msg) })
        victoryPending = true
        return player
      }
      withBossBattleStateFor(cs)(player, e, bp => {
        const phase = checkBossPhase(bp)
        if (phase?.triggered && phase.lines?.length) {
          msg += `\n⚡ *— PHASE SHIFT —*\n` + phase.lines.join('\n') + '\n'
        }
      })
      if (e.hp <= 0) {
        outbox.push({ thunk: () => sendMoveArt(ctx, EXCALIBUR_ART, msg) })
        victoryPending = true
        return player
      }
    }

    const enemyStatus = processStatusTurn(e)
    if (enemyStatus.lines.length) msg += enemyStatus.lines.join('\n') + '\n'
    if (e.hp <= 0) {
      outbox.push({ thunk: () => sendMoveArt(ctx, EXCALIBUR_ART, msg) })
      victoryPending = true
      return player
    }

    if (graceHoldsEnemyTurn(player, cs)) {
      msg += `\n${graceEnemyHeldLine(e, player, cs)}`
    } else if (enemyStatus.incapacitated) {
      msg += `\n${e.emoji ?? '👾'} *${e.name}* is locked down and cannot act.`
    } else if (boss) {
      let bossAtk = null
      let dealResult = null
      withBossBattleStateFor(cs)(player, e, bp => {
        bossAtk = buildEnemyAttack(bp)
        dealResult = applyBossSpecial(bp, EVENT.ENEMY_DEAL_DAMAGE, {
          damage: bossAtk.damage, isHit: true,
        })
      })
      if (!bossAtk) {
        const fb = plainBossStrike(e)
        bossAtk = fb.bossAtk
        dealResult = fb.dealResult
      }
      const rawBossAtk = dealResult.modified && dealResult.damage !== undefined
        ? dealResult.damage
        : bossAtk.damage

      const hitList = Array.isArray(dealResult.guaranteedHits) ? dealResult.guaranteedHits : null
      let totalPlayerDmg = 0

      if (hitList) {
        for (const rawHit of hitList) {
          const incoming = applyPartyIncoming(player, rawHit, cs, e, battle, ctx.from)
          const hDmg = incoming.damage
          if (incoming.message) msg += incoming.message + '\n'
          msg += applyPartyHpDamage(player, hDmg, cs)
          totalPlayerDmg += hDmg
        }
        msg += `\n${e.emoji ?? '👾'} *${e.name}* unleashes *${bossAtk.attackName}*! _(${hitList.length} hits)_\n`
        msg += `🩸 *${totalPlayerDmg}* total damage! _(ignores DEF)_\n`
      } else {
        const primaryHit = bossAtk.bypassDefense
          ? rawBossAtk
          : calcMonsterDamage(rawBossAtk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), false)
        const sustain = applyPartyIncoming(player, primaryHit, cs, e, battle, ctx.from)
        msg += applyPartyHpDamage(player, sustain.damage, cs)
        totalPlayerDmg = sustain.damage
        if (sustain.message) msg += sustain.message + '\n'

        if (bossAtk.doubleStrike) {
          const hit2 = bossAtk.bypassDefense
            ? rawBossAtk
            : calcMonsterDamage(rawBossAtk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), false)
          const sustain2 = applyPartyIncoming(player, hit2, cs, e, battle, ctx.from)
          msg += applyPartyHpDamage(player, sustain2.damage, cs)
          totalPlayerDmg += sustain2.damage
          if (sustain2.message) msg += sustain2.message + '\n'
          msg += `\n${e.emoji ?? '👾'} *${e.name}* uses *${bossAtk.attackName}*! ⚡ *DOUBLE STRIKE!*\n`
          msg += `🩸 *${totalPlayerDmg}* total damage!\n`
        } else {
          msg += `\n${e.emoji ?? '👾'} *${e.name}* uses *${bossAtk.attackName}*!\n`
          msg += `🩸 *${totalPlayerDmg}* damage!${bossAtk.bypassDefense ? ' _(bypasses DEF)_' : ''}\n`
        }
      }

      if (bossAtk.narrativeLines?.length) msg += `_${bossAtk.narrativeLines[0]}_\n`
      if (dealResult.narrativeLine) msg += `_${dealResult.narrativeLine}_\n`
      msg += `❤️ ${player.name}: ${hpBar(player.hp, player.maxHp)}`
    } else if (Math.random() > calcMonsterHitChance(e, player)) {
      msg += `\n${e.emoji ?? '👾'} *${e.name}* lashes back at *${player.name}*... *MISSES!*`
    } else {
      const dmg = calcMonsterDamage(e.atk, (ultraInstinctStatBoost(player) ? getEffectiveStat(player, 'def') : player.stats.def), false)
      const sustain = applyPartyIncoming(player, dmg, cs, e, battle, ctx.from)
      msg += applyPartyHpDamage(player, sustain.damage, cs)
      if (sustain.message) msg += sustain.message + '\n'
      msg += `\n${e.emoji ?? '👾'} *${e.name}* strikes *${player.name}* for *${sustain.damage}* damage!\n`
      msg += `❤️ ${player.name}: ${hpBar(player.hp, player.maxHp)}`
    }

    const fullMsg = msg + `\n\n*${p}dparty attack* · *${p}dparty defend* · *${p}dparty flee*`
    outbox.push({ thunk: () => sendMoveArt(ctx, EXCALIBUR_ART, fullMsg) })
    if (player.hp <= 0) downJid = ctx.from
    return player
  })

  for (const item of outbox) {
    try {
      if (item.turn) await sendBattleTurnReply(ctx, item.turn)
      else if (item.thunk) await item.thunk()
      else if (item.text != null) await ctx.reply(item.text)
    } catch {}
  }
  if (victoryPending || (party.battle?.enemy?.hp ?? 1) <= 0) return resolvePartyVictory(ctx, party)
  await karrenPartyPulse(ctx, party)
  if (downJid) await handlePartyMemberDown(ctx, party, downJid)
  if (party.battle) { advancePartyTurn(ctx.db, party); const formationText=partyFormationReadout(party.battle); if(formationText) await ctx.reply(formationText) }
}

// ── Party battle: Unlimited Void (Gojo) ─────────────────────────────────────
// Gojo's once-per-battle, no-MP Domain Expansion — the party-combat twin of
// plugins/domain.js. Deals NO damage: it is pure control. Opening the domain
// floods the enemy and applies a hard 'stun' for UNLIMITED_VOID_STUN_TURNS, and
// the void spends the enemy's action so there is no counter on the turn it
// opens. The lockdown then plays out across the party's following turns — every
// .dparty attack (and .dparty hollowpurple) ticks the enemy's statuses, so the
// stun counts down one step per party action and the enemy stays silent until
// it lifts. Charge latched on party.battle.charState via
// activateUnlimitedVoid(player, cs).
async function battleUnlimitedVoid(ctx) {
  ctx = partyContext(ctx)
  const p = config.prefix
  const party = findPartyForPlayer(ctx.db, ctx.from)
  if (!party) return ctx.reply(`❌ You're not in a party.`)
  if (!party.battle) return ctx.reply(`❌ Your party isn't in a battle. Use *${p}dparty enter <dungeon>*.`)

  // Fixed turn order: only the member at the cursor may act this round.
  const notTurn = await notYourTurn(ctx, party)
  if (notTurn) return ctx.reply(notTurn)

  // Mutator records the outcome only — sends are queued in `outbox` and
  // flushed after updatePlayer settles, and victory / member-down resolution
  // happens there too. No I/O and no nested updatePlayer inside the lane
  // (the nested same-player write deadlocks it — the old stuck-battle bug).
  let outbox = []
  let victoryPending = false
  let downJid = null

  await updatePlayer(ctx.db, ctx.from, async player => {
    const battle = party.battle
    const e = battle.enemy
    const eHpBeforeTurn = e.hp
    const boss = e.isBoss ?? false

    battle.charState = battle.charState ?? {}
    const cs = battle.charState[ctx.from] = battle.charState[ctx.from] ?? {}

    const gate = activateUnlimitedVoid(player, cs)
    if (!gate.ok) {
      if (gate.message) outbox.push({ text: gate.message })
      return player
    }

    let msg = ''
    const permaSeverLine = tickPermanentSever(player)
    if (permaSeverLine) msg += permaSeverLine + '\n'
    if (player.hp <= 0) {
      if (msg) outbox.push({ text: msg })
      downJid = ctx.from
      return player
    }

    msg += applyPartyBeastTurn(player, battle, cs, ctx.from)
    if (e.hp <= 0) {
      outbox.push({ text: msg + `\n${e.emoji ?? '👾'} *${e.name}* falls to the summon!` })
      victoryPending = true
      return player
    }

    msg +=
      `🌌 *DOMAIN EXPANSION*\n─────────────\n` +
      `_"Unlimited Void." The world falls away, and *${e.name}* is handed every thought at once._\n\n`

    // Flood the enemy with the domain's infinite information: a hard stun. If
    // the enemy is itself status-immune, addStatusEffect no-sells it and the
    // void finds nothing to fill.
    const res = addStatusEffect(e, {
      type: 'stun',
      duration: UNLIMITED_VOID_STUN_TURNS,
      sourceId: 'unlimited_void',
    })
    if (res?.immune) {
      msg += `⭕ _There is nothing in ${e.name} to flood. The void closes on emptiness._\n`
    } else {
      msg += `🕳️ _Infinite information pours in. ${e.name} cannot move, cannot think, cannot act._\n`
      msg += `💤 _Locked down for the next *${UNLIMITED_VOID_STUN_TURNS}* turns._\n`

      if (boss) {
        // Report the domain to the boss engine as a landed, damage-less hit so
        // phase logic that watches for the player acting still ticks.
        withBossBattleStateFor(cs)(player, e, bp => {
          const takeResult = applyBossSpecial(bp, EVENT.ENEMY_TAKE_DAMAGE, {
            damage: 0, isCrit: false, isHit: true,
          })
          if (takeResult.narrativeLine) msg += `_${takeResult.narrativeLine}_\n`
          const phase = checkBossPhase(bp)
          if (phase?.triggered && phase.lines?.length) {
            msg += `\n⚡ *— PHASE SHIFT —*\n` + phase.lines.join('\n') + '\n'
          }
        })
      }
    }

    // No counter on the turn the domain opens — the void spends the enemy's
    // action for it, same as the solo domain.
    msg += `\n❤️ ${player.name}: ${hpBar(player.hp, player.maxHp)}`

    outbox.push({ turn: {
      player, e, msg: msg + `\n\n*${p}dparty attack* · *${p}dparty defend* · *${p}dparty flee*`,
      hpBeforeTurn: player.hp, eHpBeforeTurn, boss,
    } })
    return player
  })

  // Flush the queued sends — a failed send must never block the state
  // resolution below (a stuck battle flag is worse than a lost message).
  for (const item of outbox) {
    try {
      if (item.turn) await sendBattleTurnReply(ctx, item.turn)
      else if (item.thunk) await item.thunk()
      else if (item.text != null) await ctx.reply(item.text)
    } catch {}
  }
  if (victoryPending || (party.battle?.enemy?.hp ?? 1) <= 0) return resolvePartyVictory(ctx, party)
  await karrenPartyPulse(ctx, party)
  if (downJid) await handlePartyMemberDown(ctx, party, downJid)
  // A completed action passes the turn to the next member — unless the
  // battle just ended (resolvePartyVictory cleared party.battle).
  if (party.battle) { advancePartyTurn(ctx.db, party); const formationText=partyFormationReadout(party.battle); if(formationText) await ctx.reply(formationText) }
}

export async function handlePartyMemberDown(ctx, party, jid) {
  await updatePlayer(ctx.db, jid, async player => {
    const godLine = godDeathRefusal(player, party?.battle?.charState?.[jid] ?? player.battleState, { deathAttempt: true })
    if (godLine) { await ctx.reply(godLine); return player }
    try {
      if (await awakenUltraInstinctInBattle(player, ctx, { partyBattle: true })) return player
    } catch {
      await ctx.reply('⚠️ Could not confirm the Ultra Instinct claim. The fight is paused; retry your move.').catch(() => {})
      return player
    }
    // Death-save chain, same doctrine as solo resolvePlayerHpZero: the Totem
    // of Undying is checked FIRST — it keeps the member IN the fight at 40%
    // HP/MP (consumes itself) — then the Ender Pearl checkpoint, which pulls
    // them out with no penalty at all. Only when neither fires does the
    // normal party-down penalty (half HP, pulled from the fight) apply.
    // Party fights never strip gear on a member down — but before this fix a
    // member's totem sat unused through the soft respawn, which players with
    // one equipped rightly read as "my totem didn't save me".
    const memberState = party?.battle
      ? ((party.battle.charState ??= {})[jid] ??= {})
      : null
    // ⛪📖 The Starfall champion package answers before any consumable. Sanctuary
    // refuses the fall outright while the cathedral stands; Seong-ha's Hymn
    // leaves her at 1 HP and writes the blow down as Debt; a member holding an
    // armed Edo Tensei is called back at 30%. Party fights carry no MP, so a
    // held rite fires on ownership alone — the cost was the spin itself.
    if (hasEffect(player, 'cathedral')) {
      player.hp = Math.max(1, Number(player.hp) || 0)
      await ctx.reply(`⛪ *Sanctuary.* The cathedral refuses the falling. *${player.name}* stands at 1 HP.`)
      return player
    }
    const hymnSave = seongHaHymnSave(player, memberState)
    if (hymnSave) {
      await ctx.reply(`💀 *${player.name} has fallen!*\n${hymnSave}`)
      return player
    }
    const edoSave = edoTenseiSave(player, memberState, { armedOnly: false })
    if (edoSave) {
      await ctx.reply(`💀 *${player.name} has fallen!*\n${edoSave}`)
      return player
    }
    // 📿 Edo Tensei no Jutsu — one gate further: a LIVING rite-holder in this
    // party may spend theirs to call the fallen member back. One rite, one
    // rewrite, once per match per holder.
    if (party?.battle) {
      const holders = (party.members ?? []).filter(m => {
        if (m === jid) return false
        const cs = party.battle.charState?.[m]
        if (cs?.edoUsed) return false
        const owner = getPlayer(ctx.db, m)
        return owner && ownsSkill(owner, 'edo_tensei_no_jutsu')
      })
      if (holders.length) {
        const sponsor = holders[Math.floor(Math.random() * holders.length)]
        party.battle.charState[sponsor] = party.battle.charState[sponsor] ?? {}
        party.battle.charState[sponsor].edoUsed = true
        player.hp = Math.max(1, Math.floor((Number(player.maxHp) || 1) * 0.30))
        const sponsorName = getPlayer(ctx.db, sponsor)?.name ?? 'A name unspoken'
        await ctx.reply(
          `💀 *${player.name} has fallen!*\n📿 *Edo Tensei no Jutsu.* *${sponsorName}* calls a name back out of the record — *${player.name}* rises at 30% HP.`,
        )
        return player
      }
    }
    const totemMsg = checkTotemRevive(player, memberState)
    if (totemMsg) {
      const name = player.name
      ctx.sock.sendMessage(ctx.sender, {
        text: `💀 *${name} has fallen!*${totemMsg}\n⚔️ _The battle continues — it's still your side's fight._`,
      }).catch(() => {})
      return player
    }

    const pearlMsg = checkPearlSave(player)
    if (pearlMsg) {
      const name = player.name
      ctx.sock.sendMessage(ctx.sender, {
        text: `💀 *${name} has fallen!*${pearlMsg}`,
      }).catch(() => {})
      return player
    }

    noteDungeonDeath(player, { partyBattle: true })
    // 🌋 Surtr — downed means out. Half HP of a max HP the fight invented is
    // not a respawn, so the transformation comes off first.
    clearSurtrKit(player, party.battle?.charState?.[jid] ?? null)
    player.hp = Math.floor(player.maxHp * 0.5)
    player.inBattle = false
    clearBeastEffects(player)
    const name = player.name
    ctx.sock.sendMessage(ctx.sender, {
      text: `💀 *${name} has fallen!* Respawned with half HP and pulled from the fight.`,
    }).catch(() => {})
    return player
  })

  const stillFighting = party.members.some(m => getPlayer(ctx.db, m)?.inBattle)
  if (!stillFighting) {
    const wipedFloor = party.run?.floor
    party.battle = null
    party.run = null
    await ctx.reply(
      `☠️ *The whole party has been wiped out!* The climb ends.` +
      (wipedFloor ? `\n📍 _Floors you already cleared are saved — start a fresh run to pick the climb back up._` : ''),
    )
  }
}

export async function resolvePartyVictory(ctx, party) {
  const p = config.prefix
  const battle = party.battle
  // Idempotency guard: a battle already resolved (or already cleared by the
  // stale-state repair) has nothing left to pay out — never double-reward.
  // `resolving` also closes the race where a second command lands while the
  // (necessarily async) payout loop below is still running: repairPartyState
  // checks this flag and skips, and the guard here makes a re-entry no-op.
  if (!battle || battle.resolving) return
  battle.resolving = true
  const season = getActiveSeason(ctx.db)
  const enemy = battle.enemy
  const locId = battle.locationId
  const clearedFloor = battle.floor
  const loc = locationsMap[locId]
  const totalFloors = loc?.floors ?? 0
  const isFinalFloor = totalFloors > 0 && clearedFloor >= totalFloors
  const contributions = battle.contributions
  const totalDmg = Object.values(contributions).reduce((a, b) => a + b, 0) || 1

  // The pool the party splits. A boss has a floor under it (lib/party-rewards.js):
  // five final bosses used to carry no reward at all here, so every member got
  // the 1 XP / 1 Solar minimum for beating the last floor of a dungeon.
  const pool = partyRewardPool(enemy, locId, clearedFloor)
  const xpTotal = pool.xp
  const solarsTotal = pool.solars
  // Enchantment: Looting. The drop roll is shared — one table, one set of
  // drops to split — so it is read off the top contributor's weapon: the
  // member who actually landed the killing blows. A pull with no participants
  // passes no looter, and the roll behaves exactly as it always did.
  const topLooterJid = Object.entries(contributions).sort((a, b) => b[1] - a[1])[0]?.[0] ?? null
  const topLooter = topLooterJid ? getPlayer(ctx.db, topLooterJid) : null
  const dropped = rollDrops(enemy.drops ?? [], topLooter)

  // Members still standing at the kill (inBattle) bank this floor toward their
  // SOLO progress; participants (dealt damage) get the XP/Solars split. A
  // member is almost always both — but a fled/downed member banks nothing
  // further, and a present non-attacker still banks the floor they survived.
  const presentMembers = party.members.filter(m => {
    const pl = getPlayer(ctx.db, m)
    return pl?.inBattle && !pl.battleState
  })
  const participants = Object.keys(contributions)
  const relevant = [...new Set([...participants, ...presentMembers])]

  let rewardLines = []
  let seasonLines = []

  for (const jid of relevant) {
    const isParticipant = contributions[jid] != null
    const isPresent = presentMembers.includes(jid)
    const share = isParticipant ? contributions[jid] / totalDmg : 0
    const xpShare = isParticipant ? Math.max(1, Math.round(xpTotal * share)) : 0
    const solarsShare = isParticipant ? Math.max(1, Math.round(solarsTotal * share)) : 0

    // One member failing to update must never strand the whole party in a
    // stuck battle — catch, log, and keep the rest of the resolution going.
    try {
      await updatePlayer(ctx.db, jid, async player => {
      // 🌋 Surtr — Twilight grew maxHp and wrote an ATK strengthen. The floor
      // is over, so she puts the colossus away BEFORE anything heals her, or
      // the 8% between-floor recovery is paid against 300,000 that never was.
      clearSurtrKit(player, battle.charState?.[jid] ?? null)
      if (isPresent || isParticipant) noteCombatVictory(player)
      if (player.ultraInstinct) player.ultraInstinct.partyAwakening = false
      if (isParticipant) {
        player.xp = (player.xp ?? 0) + xpShare
        // A stale seasonal fight must never credit a later season run. Other
        // active-season party kills feed the same pass share as solo kills.
        const validSeasonFight = season && (!isSeasonalLocation(loc) ||
          isSeasonRunActive(ctx.db, season.id, battle.seasonRunNumber ?? 0))
        const passAward = validSeasonFight
          ? grantRegularXpPassXp(player, season, xpShare, { source: locId === season.dungeon ? 'towerXp' : 'regularXp' })
          : null
        player.wallet = player.wallet ?? {}
        player.wallet.solars = (player.wallet.solars ?? 0) + solarsShare

        // Level-ups — the piece co-op fights never had. Same call solo
        // victories use (lib/combat-handlers.js handleVictory), so climbing
        // actually grows characters. applyLevelUps full-heals on each level.
        const { msgs: lvlMsgs } = applyLevelUps(player, levelsData, classes, races, getTotalStats)
        if (lvlMsgs.length) recordQuestEvent(player, 'level', lvlMsgs.length)
        const newSkills = getNewlyUnlockedSkills(player, allSkills)
        for (const s of newSkills) player.skills.push(s.id)

        // Quest credit — party kills and cleared floors now advance the daily
        // kill/floor quests and kill milestones exactly like solo victories
        // do (recordQuestEvent is a pure in-mutator mutation). Before this,
        // party grinders' quests never moved, and .quest claim came up empty.
        recordQuestEvent(player, 'kill', 1)
        // Season 2: a party kill in the tower feeds First Blood too. Party kills
        // never call creditKill, so the tower counter is recorded here directly.
        if (season && locId === season.dungeon &&
            isSeasonRunActive(ctx.db, season.id, battle.seasonRunNumber ?? 0)) {
          noteTowerKill(player, { inTower: true, species: enemy?.id ?? enemy?.name, enemy, db: ctx.db })
        }
        // Party kills never call creditKill, so the guild-board cull has to
        // hear them here or a co-op clear would not count.
        const boardKill = noteKill(player, {
          name: enemy.name,
          locationId: locId,
          isBoss: !!enemy.isBoss,
        })
        // Codex: a co-op kill counts toward the family for everyone who landed a hit.
        const codexKill = recordCodexKill(player, { name: enemy.name, isBoss: !!enemy.isBoss }, locId)

        let line = `  ${nameFor(ctx.db, jid)}: +${xpShare} XP, +${solarsShare} ☀️ _(${Math.round(share * 100)}% dmg)_`
        if (passAward?.earned) line += ` · +${passAward.earned} Pass XP${passAward.tieredUp ? ` · Tier ${passAward.tier}!` : ''}`
        if (boardKill.ready) line += `\n     ${readyLine(config.prefix)}`
        if (codexKill?.events?.length) line += `\n     ${codexLine(codexKill, config.prefix).split('\n').join('\n     ')}`
        if (lvlMsgs.length) line += `  · 🎉 *Lv ${player.level}!*`
        if (newSkills.length) line += `\n     ✨ Skill: ${newSkills.map(s => s.name).join(', ')}`
        rewardLines.push(line)
      }

      if (isPresent) {
        migratePersonalFloors(player)
        // Bank the cleared floor into cross-mode solo progress — the source of
        // truth handleEnter reads to resume (dungeon.js). Gated carry: because
        // the run started at the lowest member's checkpoint, nobody banks a
        // floor they weren't actually present for.
        if (!player.dungeonProgress) player.dungeonProgress = {}
        const prog = player.dungeonProgress[locId] ?? { highestFloor: 0, conquered: false }
        prog.highestFloor = Math.max(prog.highestFloor ?? 0, clearedFloor)
        if (isFinalFloor && !prog.conquered) {
          prog.conquered = true
          // Same convention as solo (combat-handlers.js): only if untitled.
          if (enemy.conquestTitle && !player.title) player.title = enemy.conquestTitle
        }
        player.dungeonProgress[locId] = prog

        // Cleared-floor quest credit for everyone who was standing at the win.
        recordQuestEvent(player, 'floor', 1)
        // Season 2: the party clear feeds the tower climb and Not Alone for
        // everyone who was standing at the win.
        notePartyFloor(player, {
          inTower: !!(season && locId === season.dungeon &&
            isSeasonRunActive(ctx.db, season.id, battle.seasonRunNumber ?? 0)),
          isBoss: !!enemy.isBoss,
          partySize: relevant.length,
          floor: clearedFloor,
          db: ctx.db,
        })

        if (season && locId === season.dungeon &&
            isSeasonRunActive(ctx.db, season.id, battle.seasonRunNumber ?? 0) &&
            clearedFloor >= (season.partyBossFloor ?? locationsMap[locId]?.floors ?? 100)) {
          // Credit only the still-active run that actually spawned this fight.
          const result = applySeasonLevel(player, season, 1)
          player.seasonProgress.currentFloor = clearedFloor + 1
          seasonLines.push(
            `  ${nameFor(ctx.db, jid)}: 🌙 Season Level ${result.seasonLevel}` +
            (result.tieredUp > 0
              ? ` · 🎫 Tier ${result.tier}!`
              : ` · 🎫 Tier ${result.tier} (${(result.progress?.toNext ?? 0).toLocaleString()} XP to next)`),
          )
        } else if (!isFinalFloor) {
          // Small between-floor recovery on a regular floor — same 8% as solo.
          player.hp = Math.min(player.maxHp, player.hp + Math.floor(player.maxHp * 0.08))
          player.mp = Math.min(player.maxMp, player.mp + Math.floor(player.maxMp * 0.08))
        }
      }
      return player
      })
    } catch (err) {
      process.stderr.write(
        `[${new Date().toISOString()}] ⚠️ party victory: reward update failed for ${jid}, continuing — ${err?.message ?? err}\n`,
      )
    }
  }

  // Drops go to a random participant. Combat loot — a full inventory shouldn't
  // block the victory message, so grant what fits and note any losses.
  let dropMsg = ''
  if (dropped.length && participants.length) {
    const winner = participants[Math.floor(Math.random() * participants.length)]
    let granted = []
    let lost = []
    await updatePlayer(ctx.db, winner, async player => {
      for (const id of dropped) {
        if (hasInventoryRoom(player, 1)) {
          player.inventory.push(id)
          granted.push(id)
        } else {
          lost.push(id)
        }
      }
      return player
    })
    if (granted.length) {
      dropMsg = `\n🎁 *Drop:* ${granted.map(id => allItems.find(i => i.id === id)?.name ?? id).join(', ')} → ${nameFor(ctx.db, winner)}`
    }
    if (lost.length) {
      dropMsg += `\n⚠️ *${nameFor(ctx.db, winner)}'s inventory was full — lost:* ${lost.map(id => allItems.find(i => i.id === id)?.name ?? id).join(', ')}`
    }
  }

  // ── Teardown: ALWAYS runs, whatever happened above ──────────────────────
  // Freeing the members and clearing party.battle happens BEFORE the victory
  // message is composed or sent. This ordering is the anti-stuck guarantee:
  // even if every reward update and even ctx.reply itself fail, no member is
  // left flagged inBattle and no party left flagged mid-battle — the exact
  // "already in a battle / finish the current floor first" lock the players
  // reported. party.battle is nulled synchronously the moment the free loop
  // starts, so a concurrent command can never re-enter the finished fight.
  party.battle = null
  for (const jid of party.members) {
    try {
      const member = getPlayer(ctx.db, jid)
      // A member mid-solo-fight keeps their inBattle flag — it belongs to the
      // solo fight, not to this party battle.
      if (member?.inBattle && !member.battleState) await updatePlayer(ctx.db, jid, async pl => {
        // 🌋 Surtr — the anti-stuck sweep is also the last exit from a party
        // fight. Restoring here covers the member who never dealt damage and
        // the member who fled before the kill (flee clears too; this is the
        // belt to that brace, and clearSurtrKit is idempotent).
        clearSurtrKit(pl, battle.charState?.[jid] ?? null)
        pl.inBattle = false
        clearBeastEffects(pl)
        return pl
      })
    } catch (err) {
      process.stderr.write(
        `[${new Date().toISOString()}] ⚠️ party victory: freeing ${jid} failed — ${err?.message ?? err}\n`,
      )
    }
  }

  let conquestMsg = ''
  if (isFinalFloor) {
    party.run = null
    conquestMsg =
      `\n\n🏆 *${(loc?.name ?? locId).toUpperCase()} CONQUERED!*\n` +
      (enemy.conquestTitle ? `🎖️ Title earned: *"${enemy.conquestTitle}"*\n` : '') +
      `_Everyone who stood at the end has the next dungeon unlocked._`
  } else if (party.run) {
    party.run.floor = clearedFloor + 1
  }

  let msg = `┌─────────────────────┐\n│   ✅ *FLOOR ${clearedFloor} CLEARED!*   │\n└─────────────────────┘\n\n`
  msg += `${enemy.emoji ?? '👾'} *${enemy.name}* defeated by the party!\n\n`
  if (pool.boss) msg += `🎁 *Boss purse:* ☀️ ${pool.solars.toLocaleString('en-US')}  ·  ✨ ${pool.xp.toLocaleString('en-US')} XP, split by damage\n\n`
  msg += `📊 *Rewards (by damage share):*\n${rewardLines.join('\n')}`
  if (seasonLines.length) msg += `\n\n🌙 *Season progress:*\n${seasonLines.join('\n')}`
  msg += dropMsg
  msg += conquestMsg
  if (!isFinalFloor && party.run) {
    msg += `\n\n⬇️ _Leader: *${p}dparty next* to descend to Floor ${party.run.floor}._`
  }
  await ctx.reply(msg).catch(() => {})
}

// ── Plugin export ─────────────────────────────────────────────────────────
// Registered as `.dparty` (dungeon party) — NOT `.party`, which is owned by
// plugins/pokemon.js (the Pokémon battle party). Both plugins used to export
// name:'party'; alphabetical load order let pokemon.js overwrite this one in
// the registry, so the co-op dungeon party had no reachable command. Renaming
// this to `.dparty` (+ aliases) gives it its own keys and leaves the Pokémon
// party untouched.
export default {
  name: 'dparty',
  aliases: ['dungeonparty', 'dp', 'coop'],
  category: 'party',
  requiresPlayer: true,
  description: 'Form a dungeon party and climb a dungeon together, floor by floor',

  async run(ctx) {
    ctx = partyContext(ctx)
    const sub = ctx.args[0]?.toLowerCase()
    const p = config.prefix

    // Self-heal any stale party state (won-but-unsettled battle, orphaned
    // inBattle flags, overrun run cursor) BEFORE acting, so no command ever
    // answers "already in a battle" for a fight that is actually over.
    const partyBefore = findPartyForPlayer(ctx.db, ctx.from)
    if (partyBefore) await repairPartyState(ctx, partyBefore)

    switch (sub) {
      case 'create':  return createParty(ctx)
      case 'invite':  return invite(ctx, ctx.args.slice(1).join(' '))
      case 'join':
      case 'accept':  return respondInvite(ctx, true, ctx.args.slice(1).join(' '))
      case 'decline': return respondInvite(ctx, false, ctx.args.slice(1).join(' '))
      case 'leave':   return leave(ctx)
      case 'kick':    return kick(ctx, ctx.args.slice(1).join(' '))
      case 'disband': return disband(ctx)
      case 'enter':   return enterDungeon(ctx, ctx.args[1])
      case 'next':    case 'descend': case 'n': return handleNext(ctx)
      case 'attack':  case 'atk': return battleAttack(ctx)
      case 'garden': return battleGarden(ctx)
      case 'victory': case 'sanctum': return battleVictory(ctx)
      case 'cinderverdict': case 'cinder': case 'cv': case 'verdict':
        return battleCinderVerdict(ctx)
      case 'blaze-heart': case 'blazeheart': case 'blaze': case 'bh':
        return battleBlazeHeart(ctx)
      case 'kurama': case 'baryon': case 'ninetails': case 'krm':
        return battleKurama(ctx)
      case 'hollowpurple': case 'purple': case 'hollow-purple':
        return battleHollowPurple(ctx)
      case 'unlimitedvoid': case 'void': case 'unlimited-void':
        return battleUnlimitedVoid(ctx)
      case 'excalibur': case 'excaliber': case 'exc': case 'excal': case 'saber': case 'swordofpromisedvictory':
        return battleExcalibur(ctx)
      // 🌋 Surtr — the party door. `.dparty surtr <skill>`; the skill token is
      // resolved by plugins/surtr.js's own matcher, so every alias of every one
      // of her skills works here exactly as it does in a dungeon.
      case 'surtr': case 'molten': case 'colossus': case 'laevatain':
        return battleSurtr(ctx, ctx.args[1] ?? null)
      case 'bend': case 'bendingart': case 'elementart':
        return battleBend(ctx, ctx.args[1] ?? null)
      case 'defend':  return battleDefend(ctx)
      case 'flee':    return battleFlee(ctx)
      case 'skip':    return skipTurn(ctx)
      default:        return showStatus(ctx)
    }
  },
}

// Exported so plugins/pattack.js can offer shorter top-level aliases, and so
// plugins/cb.js (owner-only) can settle a tagged player's stuck party battle.
export { battleAttack, battleDefend, battleFlee, battleCinderVerdict, battleBlazeHeart, battleBend, battleKurama, battleHollowPurple, battleUnlimitedVoid, battleExcalibur, battleSurtr, repairPartyState, spawnPartyEnemy }
