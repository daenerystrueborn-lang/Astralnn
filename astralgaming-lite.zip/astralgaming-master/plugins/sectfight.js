/**
 * sectfight.js — `.sectfight [stage] [element] [role]` : the owner's trial.
 *
 * A fight against a foe the generator builds on the spot, so the combat engine
 * can be tried, tuned and demonstrated before a single monster exists. It is
 * the owner's, it pays nothing at all — no progress, no mastery, no loot — and
 * it changes nothing on the Astral record.
 *
 *   .sectfight                 a foe of the caller's own stage
 *   .sectfight 10              a foe at stage 10 (Foundation Establishment, Early)
 *   .sectfight 12 fire elite   a stage 12 foe of Fire, at elite strength
 *   .sectfight boss            a boss of the caller's own stage
 */
import { config } from '../config.js'
import { isOwnerJid, NOT_ALLOWED } from '../lib/group-helpers.js'
import { sectDoorRefusal } from '../lib/world-guards.js'
import { isElement, ROLES } from '../lib/sect-combat.js'
import { stageByIndex, stageLabel } from '../lib/sect-cultivation.js'
import { ownerTestFight, startRefusal } from '../lib/sect-fight.js'


export default {
  name: 'sectfight',
  category: 'admin',
  requiresPlayer: true,
  description: `${config.prefix}sectfight [stage] [element] [role] — the owner's test fight (owner only)`,

  async run(ctx) {
    const p = config.prefix
    if (!isOwnerJid(ctx.from)) return ctx.reply(NOT_ALLOWED)
    const wrongWorld = sectDoorRefusal(ctx.player, {
      emoji: '⛰️', title: '*The trial ground belongs to the Sect Empire.*',
    })
    if (wrongWorld) return ctx.reply(wrongWorld)

    const words = (ctx.args ?? []).map(a => String(a).toLowerCase()).filter(Boolean)
    let stage = null
    let element = null
    let role = 'normal'
    const unknown = []

    for (const word of words) {
      if (/^\d+$/.test(word)) {
        stage = Number(word)
        continue
      }
      if (isElement(word)) {
        element = word
        continue
      }
      if (ROLES.includes(word)) {
        role = word
        continue
      }
      unknown.push(word)
    }

    if (stage !== null && !stageByIndex(stage)) {
      return ctx.reply(`❓ *Stage *${stage}* is not on the ladder.* _0 is Mortal, 41 is the far end of Tribulation Transcendence._`)
    }
    if (unknown.length) {
      return ctx.reply(
        `❓ *Not a stage, an element or a role: "${unknown.join(' ')}".*\n` +
        `_*${p}sectfight [stage] [element] [role]* — roles: ${ROLES.join(', ')}._`,
      )
    }

    const refusal = startRefusal(ctx.player, { now: Date.now() })
    if (refusal) return ctx.reply(refusal)

    return ownerTestFight(ctx, { stage, element, role })
  },
}

export { stageLabel }
