import { playerExists, createPlayer, updatePlayer } from '../lib/player-repo.js'
import {
  validateRegistration, buildPlayerForWorld, normalizeRegWorld, listRaces,
  FACTION_KINGDOM, FACTION_SECT,
} from '../lib/player-factory.js'
import { config } from '../config.js'
import { syncTutorialProgress, tutorialKickoffCard } from '../lib/tutorial-engine.js'
import { kingdomIntro, sectIntro } from '../lib/faction-choice.js'
import {
  registerWorldCard, registerGuide, registerNeedsWorld, worldClosedCard,
  registerClassChoices, registerRaceChoices, registerNamePrompt, pushNameAsCharacter,
  worldFromArg, classIdFromArg, raceIdFromArg,
} from '../lib/registration-flow.js'
import { isWorldOpenFor, SECT_EMPIRE } from '../lib/worlds.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import { sendButtons, sendList, interactiveSupported } from '../lib/interactive-buttons.js'
import { canonicalPlayerId, senderIdentity, senderPhoneDigits } from '../lib/identity-resolver.js'
import {
  ensureDbNamesDeduplicatedSync,
  isPlayerNameTaken,
  nextAvailablePlayerName,
} from '../lib/unique-names.js'

/**
 * register — create a player profile. THE WORLD IS THE FIRST QUESTION.
 *
 * Usage (the guided flow — a tap where the client can draw a card, a numbered
 * answer everywhere else; the whatsmeow transport cannot render cards, see
 * lib/interactive-buttons.js):
 *   <prefix>register                          — the world question: 1 · 2
 *   <prefix>register kingdom                  — the nine classes, as a pick list
 *   <prefix>register kingdom <class>          — the five races, as a pick list
 *   <prefix>register kingdom <class> <race>    — done: your WhatsApp name is used
 *   <prefix>register sect                     — the five cultivation paths, as a pick list
 *   <prefix>register sect <path>              — the races, as a pick list
 *   <prefix>register sect <path> <race>        — done
 * Usage (the typed sheet — still supported, and the way to pick your own name):
 *   <prefix>register kingdom <name> <class> <race>
 *   <prefix>register sect <name> <path> <race>
 *
 * The guided flow asks for the world first because the two worlds do not share
 * a class list. Astra answers "who are you?" with nine classes from
 * data/classes.json; the Sect Empire answers with five cultivation paths from
 * data/sect-classes.json, and validateRegistration() refuses either one's ids
 * in the other world. A valid legacy three-field sheet is still accepted for
 * existing group members, with the world inferred from its class/path.
 *
 * The record itself is built by lib/player-factory.js's buildPlayerForWorld(),
 * so the website's sign-up page (POST /api/auth/register) produces an identical
 * player, world included. Explicit world-first syntax remains the clearest path;
 * the legacy three-field form is also accepted when its class/path identifies a
 * world (ambiguous legacy forms default to Astra Kingdom).
 *
 * Because the world is settled here, a new record is never left pendingFaction:
 * `.faction` is a read-only status line from birth, and the free pick cannot be
 * used to dodge the tolled `.road` later.
 */
/** A race id that exists in this world — validation filler for the class step. */
function anyRaceOf(world) {
  return listRaces(world)[0]?.id ?? 'human'
}

function inferLegacyWorld(args) {
  if (!Array.isArray(args) || args.length !== 3) return null
  const [name, classId, raceId] = args
  const kingdom = validateRegistration({ name, classId, raceId, world: FACTION_KINGDOM })
  const sect = validateRegistration({ name, classId, raceId, world: FACTION_SECT })

  // Preserve the historical `.register <name> <class> <race>` kingdom path.
  // A uniquely valid Sect path can be inferred too; for ambiguous aliases the
  // player can still select the Sect explicitly with `.register sect ...`.
  if (kingdom.ok) return FACTION_KINGDOM
  if (sect.ok) return FACTION_SECT
  return null
}

export default {
  name: 'register',
  // `signup` is the word a person reaches for when the bot has just told them
  // they have no character. It is an alias rather than a second plugin so the
  // world-first flow stays one implementation (and handler.js's DM allowlist
  // lists both spellings, since it matches the word that was typed).
  aliases: ['signup'],
  category: 'account',
  description: 'Register your profile with a world-first guide or legacy character sheet',

  async run(ctx) {
    // Resolve the actual member, not the group chat. Older WhatsApp group
    // messages can carry the sender's phone/LID on the message key even when
    // `ctx.from` is absent or not a person address. Prefer an existing canonical
    // record; otherwise canonicalPlayerId stores a new LID-addressed signup
    // under its phone JID when WhatsApp supplied that number.
    const identity = senderIdentity(ctx.msg)
    const phone = senderPhoneDigits(ctx)
    const senderAddress = [
      ctx.from,
      identity.from,
      identity.phone,
      identity.lid,
      ctx.playerId,
    ].find(id => id && !String(id).endsWith('@g.us'))
    if (!senderAddress) {
      return ctx.reply('❌ I could not identify your individual WhatsApp account from this group message. Please try again or DM the bot.')
    }
    const playerId = canonicalPlayerId(ctx.db, senderAddress, {
      phone: identity.phone ?? phone,
    })

    if (playerExists(ctx.db, playerId)) {
      return ctx.reply(`⚠️ Already registered. Use *${config.prefix}profile* to view your stats.`)
    }
    ensureDbNamesDeduplicatedSync(ctx.db)

    const args = (ctx.args ?? []).map(a => String(a ?? ''))
    const p = config.prefix
    let effectiveArgs = args
    // `1` / `2` are the numbered world answers the card asks for. Resolved
    // before everything else so a number is never mistaken for a name.
    let worldId = normalizeRegWorld(args[0]) ?? worldFromArg(args[0])

    // The transport decides the shape of every step below: a tappable card when
    // the socket can render one, otherwise the same card's text — which always
    // carries the full guide, because every card body is built from it.
    const canTap = interactiveSupported(ctx.sock)
    const sendCard = async (card) => {
      if (canTap) {
        try { return await sendList({ ...ctx, jid: ctx.sender }, card) } catch { /* fall through */ }
      }
      return ctx.reply(card.body)
    }
    if (!worldId && args.length === 3) {
      const inferredWorld = inferLegacyWorld(args)
      if (inferredWorld) {
        worldId = inferredWorld
        effectiveArgs = [worldId, ...args]
      }
    }

    // The owner's world switch (`.openworld`) is honoured here exactly as `.road`
    // and `.travel` honour it: while the Sect Empire is shut, registration does
    // not become the back door around it. The owner is exempt, as everywhere.
    const sectOpen = isOwnerJid(ctx.from) || isWorldOpenFor(ctx.db, SECT_EMPIRE)
    if (worldId === FACTION_SECT && !sectOpen) return ctx.reply(worldClosedCard(p))

    // ── No world named yet: ask. Nothing else is offered before this. ────────
    if (!worldId) {
      // A valid legacy three-field sheet was inferred above. If it is invalid,
      // explain both explicit forms instead of mislabeling the character name
      // as a world.
      const text = args.length === 3
        ? `❌ That character sheet could not be validated. Choose a world explicitly:\n\n${config.prefix}register kingdom <name> <class> <race>\n${config.prefix}register sect <name> <path> <race>\n\n${registerWorldCard(p, { sectOpen })}`
        : args.length
          ? registerNeedsWorld(p, args[0], { sectOpen })
          : registerWorldCard(p, { sectOpen })
      if (!canTap) {
        // whatsmeow: the card would arrive as "This message couldn't load", so
        // the same text goes as an ordinary message. It names both worlds and
        // the exact line (`.register 1` / `.register 2`) that picks one.
        return ctx.reply(text)
      }
      try {
        return await sendButtons({ ...ctx, jid: ctx.sender }, {
          body: text,
          footer: 'Tap a world, or type the command yourself.',
          // No button for a closed world: a button that answers "not now" is a
          // worse door than no button.
          buttons: [
            { id: `${p}register kingdom`, label: '🌍 Astra Kingdom' },
            ...(sectOpen ? [{ id: `${p}register sect`, label: '⛰️ Sect Empire' }] : []),
          ],
        })
      } catch {
        return ctx.reply(text)
      }
    }

    // ── World named, sheet not filled in: that world's options. ─────────────
    //
    // Three steps, each one a tap and each one a complete command, so a tap and
    // a typed line are the same thing (handler.js turns a button id into the
    // command body). A client that cannot draw the list gets the world's plain
    // guide as the message body instead — nothing is lost.
    const rest = effectiveArgs.slice(1)

    // Step 1 — no class yet: the world's classes/paths.
    if (!rest.length) {
      return sendCard(registerClassChoices(p, worldId))
    }

    // Step 2 — a class/path, no race yet: the races.
    if (rest.length === 1) {
      // A number is the third class/path of THIS world's guide; anything else
      // goes through untouched so validateRegistration's aliases still resolve
      // ("sword" → sword_saint).
      const classId = classIdFromArg(worldId, rest[0]) ?? String(rest[0] ?? '').toLowerCase()
      const valid = validateRegistration({
        name: 'Probe', classId, raceId: anyRaceOf(worldId), world: worldId,
      })
      // A one-word line that names no class in THIS world is not a character
      // sheet, and the answer is still the list of the ones that exist.
      if (!valid.ok) {
        return sendCard(registerClassChoices(p, worldId, {
          notice: `❓ That is not a full character sheet${worldId === FACTION_SECT ? ' for the Sect Empire' : ''}. ${valid.error}`,
        }))
      }
      // `valid.classId` is the RESOLVED id (a typed "monk" becomes its path),
      // which is what the race rows must carry.
      return sendCard(registerRaceChoices(p, worldId, valid.classId))
    }

    // Step 3 — a class AND a race: the character is ready. The name is the one
    // WhatsApp already shows for this person (`pushName`), which is why the card
    // flow asks for nothing else; `.rename` changes it afterwards.
    if (rest.length === 2) {
      const classArg = classIdFromArg(worldId, rest[0]) ?? rest[0]
      const raceArg = raceIdFromArg(worldId, rest[1]) ?? rest[1]
      // `ctx.pushName` is the platform-neutral copy the Telegram adapter fills
      // from the sender's first/last name (WhatsApp has carried it on the raw
      // message all along). Without it, `/register kingdom warrior human` in a
      // Telegram DM always stopped at "type your name" — and a bare name is not
      // a command, so the adapter ignored the answer and the flow was stuck.
      const autoName = pushNameAsCharacter(ctx.pushName || ctx.msg?.pushName)
      if (!autoName) return ctx.reply(registerNamePrompt(p, worldId, classArg, raceArg))
      const uniqueAutoName = nextAvailablePlayerName(ctx.db?.data?.users, autoName, playerId)
      effectiveArgs = [worldId, uniqueAutoName, classArg, raceArg]
    }

    if (effectiveArgs.slice(1).length !== 3) {
      return ctx.reply(
        `❓ That is not a full character sheet${worldId === FACTION_SECT ? ' for the Sect Empire' : ''}.\n\n${registerGuide(p, worldId)}`,
      )
    }

    // `effectiveArgs`, not `rest`: the card flow fills the name in above.
    const [nameArg, classArg, raceArg] = effectiveArgs.slice(1)
    const check = validateRegistration({
      name: nameArg, classId: classArg, raceId: raceArg, world: worldId,
    })
    if (!check.ok) {
      // A class/path typo is the one mistake worth answering with the list
      // rather than the bare message — and the list is always THIS world's.
      return ctx.reply(`❌ ${check.error}\n\n${registerGuide(p, worldId)}`)
    }

    if (isPlayerNameTaken(ctx.db?.data?.users, check.name, playerId)) {
      const suggestion = nextAvailablePlayerName(ctx.db?.data?.users, check.name, playerId)
      return ctx.reply(
        `❌ The name *${check.name}* is already taken.` +
        (suggestion ? ` Try *${suggestion}* or choose another name:\n\n` : '\n\n') +
        `${p}register ${worldId} <name> ${check.classId} ${check.raceId}`,
      )
    }

    const built = buildPlayerForWorld({
      id: playerId,
      name: check.name,
      world: check.world,
      classId: check.classId,
      raceId: check.raceId,
    })
    const newPlayer = built.player

    // The phone number, when this message carried one, goes on the record from
    // the start so the website's OTP login finds THIS character by number.
    if (phone) newPlayer.phone = phone
    if (identity.lid) newPlayer.lid = identity.lid

    // createPlayer binds every address above to the new record, so the next
    // message from either spelling resolves to this one character instead of
    // looking like a second, unregistered player.
    try { await createPlayer(ctx.db, playerId, newPlayer) } catch (err) {
      if (err?.code === 'PLAYER_EXISTS') return ctx.reply(`⚠️ Already registered. Use *${config.prefix}profile* to view your stats.`)
      if (err?.code === 'NAME_TAKEN') {
        const suggestion = nextAvailablePlayerName(ctx.db?.data?.users, check.name, playerId)
        return ctx.reply(`❌ The name *${check.name}* is already taken.${suggestion ? ` Try *${suggestion}* instead.` : ''}`)
      }
      throw err
    }

    // Registering IS tutorial step 1 ("claim your character"); bank its
    // completion (and reward) silently now. The tutorial card itself is shown
    // only to a Kingdom player — a disciple gets the mountain's own orientation
    // (lib/sect-orientation.js) instead.
    let intro = ''
    let kickoff = ''
    await updatePlayer(ctx.db, playerId, (player) => {
      syncTutorialProgress(player)
      intro = built.world === FACTION_SECT
        ? sectIntro(player, p, built.roll)
        : kingdomIntro(player, p)
      if (built.world !== FACTION_SECT) kickoff = tutorialKickoffCard(player, p)
      return player
    })

    await ctx.reply(intro)
    if (kickoff) await ctx.reply(kickoff)

    // ── A DM registration ends by pointing at the group ────────────────────
    // Registering in a private chat is supported (it is in the adapter's DM
    // allowlist), but the game itself happens in the group: DMs stay closed
    // for gameplay. Saying that HERE, with the invite in hand, is the
    // difference between "I registered and nothing happened" and "I know where
    // to go next".
    if (ctx.platform === 'telegram' && !ctx.isGroup) {
      const invite = config.communityTelegramLink
      return ctx.reply(
        `✅ *${check.name}* of ${built.world === FACTION_SECT ? 'the Sect Empire' : 'the Astra Kingdom'} is ready.\n\n` +
        `Play in the group — that is where battles, dungeons, quests and cards happen.\n` +
        (invite
          ? `${invite}\n\n`
          : `_The invite link is not configured yet: ask the owner to set COMMUNITY_TELEGRAM_LINK._\n\n`) +
        `_Here in the DM you can always use ${p}register, ${p}link, ${p}profile, ${p}stats and ${p}menu._`,
      )
    }
    return undefined
  },
}
