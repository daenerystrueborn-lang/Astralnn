/**
 * info.js — alias surface for character info.
 *
 * `.info season <name>` and `.info <name>` both resolve to exactly the same
 * output as `.character info <name>` (plugins/character.js), which already
 * sends the character's image plus full ability/ownership details for every
 * character including Season 1's — sendImage(ctx, character.image, ...) runs
 * regardless of seasonId.
 *
 * This file deliberately contains NO rendering logic of its own: it rewrites
 * the args and delegates straight into the character plugin's run(), so the
 * two commands can never drift apart.
 */
import { createRequire } from 'module'
import { config } from '../config.js'
import { characters, allItems } from '../lib/game-data.js'
import { rarityBadge, rarityStars } from '../lib/rarity.js'
import { sendImage } from '../lib/image.js'
import { findAnySkill, formatSkillInfoCard } from '../lib/skill-info.js'
import characterPlugin from './character.js'

const require = createRequire(import.meta.url)
const namedPassives = require('../data/named-weapon-passives.json')
const passiveById = Object.fromEntries(namedPassives.map((p) => [p.id, p]))

function findCharacterQuery(query) {
  const q = String(query ?? '').toLowerCase().trim()
  if (!q) return null
  return characters.find((c) => c.id === q)
    ?? characters.find((c) => c.name.toLowerCase() === q)
    ?? characters.find((c) => c.name.toLowerCase().includes(q) || c.id.includes(q.replace(/\s+/g, '_')))
    ?? null
}

function findItemQuery(query) {
  const q = String(query ?? '').toLowerCase().trim()
  if (!q) return null
  const idForm = q.replace(/\s+/g, '_')
  return allItems.find((i) => i.id === idForm || i.id === q)
    ?? allItems.find((i) => i.name.toLowerCase() === q)
    ?? allItems.find((i) => i.name.toLowerCase().includes(q))
    ?? null
}

function formatItemInfoCard(item, pr) {
  const slotLabel = item.fullArmorSuit
    ? 'Full Armor Suit (helmet, chestplate, boots)'
    : item.slot ?? item.type
  const bonuses = Object.entries(item.statBonuses ?? {})
    .filter(([, v]) => v !== 0)
    .map(([k, v]) => `${k.toUpperCase()} +${v}`)
    .join(' · ')
  const passive = item.passiveId ? passiveById[item.passiveId] : null
  const lines = [
    `🖤 *${item.name}* ${rarityStars(item.rarity)}`,
    `${rarityBadge(item.rarity)} · ${item.type.charAt(0).toUpperCase() + item.type.slice(1)} (${slotLabel})`,
    item.unbreakable ? `🛡️ *Durability:* Unbreakable _(can never break)_` : '',
    item.gemPrice != null ? `💎 *Price:* ${item.gemPrice} Gems` : (item.buyPrice != null ? `☀️ *Price:* ${item.buyPrice} Solars` : ''),
    '',
    `📖 ${item.description}`,
  ].filter(Boolean)

  if (bonuses) {
    lines.push('', `📊 *Stat Bonuses:* ${bonuses}`)
  }
  if (passive?.description) {
    lines.push('', `✨ *Passive:* ${passive.description}`)
  }
  if (item.gemPrice != null) {
    lines.push('', `🛒 _Buy with *${pr}shop buy ${item.name.toLowerCase()}* · Equip with *${pr}equip ${item.name.toLowerCase()}*_`)
  }
  return lines.join('\n')
}

export default {
  name: 'info',
  aliases: ['charinfo'],
  category: 'account',
  requiresPlayer: true,
  description: `${config.prefix}info <name> — view character or mythic armor/item info`,

  async run(ctx) {
    const pr = config.prefix
    const args = [...(ctx.args ?? [])]

    // `.info season <name>` — drop the optional "season" keyword; character
    // lookup is by id/name and doesn't care which season a character is from.
    const hadSeasonPrefix = (args[0] ?? '').toLowerCase() === 'season'
    if (hadSeasonPrefix) args.shift()

    if (!args.length) {
      return ctx.reply(
        `ℹ️ Usage: *${pr}info <name>*\n` +
        `_Example: ${pr}info season wither · ${pr}info black armor of napoleon_\n\n` +
        `Same as *${pr}character info <name>*. Browse everyone with *${pr}character*.`,
      )
    }

    const query = args.join(' ')
    if ((args[0] ?? '').toLowerCase() === 'skill' && args.length > 1) {
      const sk = findAnySkill(args.slice(1).join(' '), ctx.player)
      if (sk) return ctx.reply(formatSkillInfoCard(sk, ctx.player, pr))
    }
    if (!hadSeasonPrefix && !findCharacterQuery(query)) {
      const item = findItemQuery(query)
      if (item) {
        const card = formatItemInfoCard(item, pr)
        const img = item.image || `https://play.astral.qzz.io/assets/items/${item.id}.jpg`
        return sendImage(ctx, img, card)
      }
      const sk = findAnySkill(query, ctx.player)
      if (sk) {
        return ctx.reply(formatSkillInfoCard(sk, ctx.player, pr))
      }
    }

    return characterPlugin.run({ ...ctx, args: ['info', ...args] })
  },
}
