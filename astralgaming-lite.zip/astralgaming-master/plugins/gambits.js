/**
 * gambits.js - .gambits: the duel "opening book".
 *
 * Lists every named line the PvP commentator can recognize (openings,
 * variations, and motifs) and the exact .pvp moves that trigger each one.
 * The data comes straight from lib/pvp-gambits.js via listGambits(), so this
 * listing can never drift from what the battle engine actually announces.
 */
import { config } from '../config.js'
import { listGambits } from '../lib/pvp-gambits.js'
import { listPveGambits, ATTRITION_FROM_TURN, EXECUTE_FRACTION, BEATEN_FRACTION } from '../lib/pve-gambits.js'

const DIV = '━━━━━━━━━━━━━━━━━'

function section(title, items) {
  return (
    `*${title}*\n\n` +
    items
      .map(i =>
        `📖 *${i.name}*\n` +
        `   _“${i.flavor}”_\n` +
        `   ▸ ${i.trigger}`
      )
      .join('\n\n')
  )
}

export default {
  name: 'gambits',
  aliases: ['variations', 'openings', 'gambit', 'lines', 'book'],
  category: 'pvp',
  requiresPlayer: false,
  description: 'List every named line (duel and dungeon) and how to trigger each',
  subcommands: [
    { cmd: 'pve', desc: 'the dungeon lines: openings, motifs and the three PvE-only shapes' },
  ],

  async run(ctx) {
    const { reply } = ctx
    const p = config.prefix
    const { openings, variations, motifs } = listGambits(p)

    // `.gambits pve` — the dungeon book. A dungeon fight used to be the one
    // fight in the bot with no commentary at all, because nothing on the PvE
    // side read the detector lib/pvp-gambits.js already had.
    if ((ctx.args?.[0] ?? '').toLowerCase() === 'pve') {
      const pve = listPveGambits(p)
      const pveOpenings = [
        { name: 'Vanguard Opening', flavor: 'a straight blade, first thing.', trigger: pve.openings[0].trigger },
        { name: 'Arcane Opening', flavor: 'magic drawn on the opening breath.', trigger: pve.openings[1].trigger },
        { name: 'Turtle Opening', flavor: 'shield up before a word is said.', trigger: pve.openings[2].trigger },
        { name: "Artificer's Opening", flavor: 'a crafted trick, sprung early.', trigger: pve.openings[3].trigger },
      ]
      const pveMotifs = [
        { name: "Berserker's Rush", flavor: 'three unbroken strikes, nobody is blinking.', trigger: 'Land three attacks in a row.' },
        { name: 'The Iron Wall', flavor: 'shields locked, turn after turn. A siege.', trigger: 'Guard four turns back to back.' },
        { name: 'Sustained Barrage', flavor: 'the air keeps cracking, spell after spell.', trigger: 'Cast three skills in a row.' },
        { name: 'War of Attrition', flavor: 'neither side giving. The floor is getting tired.', trigger: `Take the fight past turn ${ATTRITION_FROM_TURN}.` },
        { name: 'The Finish', flavor: 'read the opening, and took it clean.', trigger: `Land the killing blow on a foe under ${Math.round(EXECUTE_FRACTION * 100)}% HP.` },
        { name: 'Unbroken', flavor: 'everything it had, and still standing.', trigger: `Still standing under ${Math.round(BEATEN_FRACTION * 100)}% HP after turn 8, without turtling.` },
      ]
      return reply(
        `📖 *THE DUNGEON BOOK*\n` +
        `${DIV}\n` +
        `_The bot names the shape of a dungeon fight as it forms, in the same voice it calls a duel. Every line below fires mid-fight, once._\n\n` +
        `${section('⚔️ OPENINGS  ·  your very first move', pveOpenings)}\n\n` +
        `${DIV}\n` +
        `${section('✨ MOTIFS  ·  shapes that form over a whole fight', pveMotifs)}\n\n` +
        `${DIV}\n` +
        `_The first six are the same detector a duel uses — a dungeon turn and a duel turn are the same shape. The last three need fight context a ply log cannot carry._\n` +
        `_Read *${p}gambits* for the duel book._`,
      )
    }

    const msg =
      `📖 *THE DUEL OPENING BOOK*\n` +
      `${DIV}\n` +
      `_Like a chess engine, the bot names the shape of your duel as it forms and calls it out mid fight. Here is every line it knows and how to reach it._\n\n` +
      `${section('⚔️ OPENINGS  ·  your very first move', openings)}\n\n` +
      `${DIV}\n` +
      `${section('🔀 VARIATIONS  ·  first move plus the answer', variations)}\n\n` +
      `${DIV}\n` +
      `${section('✨ MOTIFS  ·  shapes that form over a whole duel', motifs)}\n\n` +
      `${DIV}\n` +
      `_Start any duel with *${p}pvp @player*. New here? Read *${p}guide pvp*._\n` +
      `_Dungeon fights get their own book — read *${p}gambits pve*._`

    return reply(msg)
  },
}
