/**
 * allcmds.js — every command the caller can type.
 *
 * .menu is the ten sections. This is the flat list, and it is now honest about
 * WHO is asking (reported 2026-10: "most commands are not in allcommands"):
 *
 *   players  owner tools stay out, and so do `hidden: true` helpers
 *   mods     players' list PLUS the staff tools marked `modTool: true` —
 *            .mod-here (League verification) and .cb, which mods are supposed
 *            to use on players they are rescuing. A mod could not find them
 *            before because every one of them sat behind the owner/admin filter.
 *   owner    everything, admin and hidden plugins included, each marked 🔒
 *
 * An unknown word is a SEARCH over names, aliases, descriptions and
 * subcommands instead of a refusal, so "verify", "league verify" or "release"
 * finds the command that does it. `.allcommands release` is the fastest way to
 * answer "what releases a beast".
 */
import { config } from '../config.js'
import { listPluginsFor } from '../lib/plugin-manager.js'
import { SECTIONS } from './menu.js'
import { buildCommandPages } from '../lib/command-list.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import { isMod } from '../lib/mod-repo.js'
import { isInSectEmpire } from '../lib/worlds.js'
import { sectHelpLines } from '../lib/sect-help.js'

function prefixFor(platform) {
  return platform === 'telegram' ? config.telegramPrefix : config.prefix
}

// `.menu` remains kingdom-only, but the flat directory deliberately includes
// commands that work after crossing to the Sect Empire. Keep that world in a
// distinct section so Astra players can discover the road without implying
// those commands run in their current world.
const ALL_COMMAND_SECTIONS = [
  ...SECTIONS,
  {
    key: 'sect-empire',
    emoji: '⛰️',
    label: 'Sect Empire',
    blurb: 'Cultivation commands available after crossing worlds with .road.',
    subs: [{ cat: 'sect', label: 'Sect Empire' }],
  },
]

/** Owner sees everything, mods see the staff tools too, everyone else the player list. */
function viewerFor(ctx) {
  if (isOwnerJid(ctx.from)) return 'owner'
  if (isMod(ctx.db, ctx.from)) return 'mod'
  return 'player'
}

export default {
  name: 'allcommands',
  aliases: ['cmdlist', 'allcmds', 'commandlist'],
  category: 'utility',
  cooldown: 5,
  requiresPlayer: false,
  description: 'Every command you can use (owners get the full list, mods get the staff tools)',
  subcommands: [
    { cmd: '<section>', desc: 'only that menu section' },
    { cmd: '<word>', desc: 'search every command by name, alias, text or subcommand' },
    { cmd: '<page>', desc: 'the next page of the full list' },
  ],

  async run(ctx) {
    // The flat command list is the kingdom's registry; the Sect Empire has
    // its own short list of words, so up the mountain the search answers
    // with the mountain's guide instead (lib/sect-help.js).
    if (isInSectEmpire(ctx.player)) {
      return ctx.reply(sectHelpLines(prefixFor(ctx.platform)).join('\n'))
    }
    const p = prefixFor(ctx.platform)
    const args = ctx.args ?? []
    let page = 1
    const words = []
    for (const arg of args) {
      if (/^\d+$/.test(String(arg))) page = parseInt(arg, 10)
      else words.push(String(arg))
    }
    const sectionQuery = words.join(' ')
    const viewer = viewerFor(ctx)
    if (['sect', 'sect empire', 'sect_empire', 'sect-empire'].includes(sectionQuery.trim().toLowerCase())) {
      return ctx.reply(sectHelpLines(p).join('\n'))
    }

    const result = buildCommandPages(listPluginsFor(ctx.platform), {
      prefix: p,
      sections: ALL_COMMAND_SECTIONS,
      page,
      sectionQuery,
      viewer,
    })

    if (result.error === 'notfound') {
      return ctx.reply(
        `🔍 Nothing matches *${result.query}*.\n` +
        `Try one word from what you want to do (*${p}allcommands release*, *${p}allcommands verify*), ` +
        `or a section:\n` +
        ALL_COMMAND_SECTIONS.map(s => `*${p}allcommands ${s.label}*`).join('  ·  '),
      )
    }

    const viewerNote = viewer === 'owner'
      ? '_Full list, owner tools included (🔒)._'
      : viewer === 'mod'
        ? '_Player list plus staff tools (🔒 mod tools)._'
        : '_Owner tools are not listed._'
    const header =
      `📋 *${result.title}*\n` +
      `_${result.total} command${result.total === 1 ? '' : 's'}${result.searched ? ' matching' : ''}. ${viewerNote}_\n` +
      (result.pageCount > 1 ? `_Page ${result.page}/${result.pageCount}_\n` : '') +
      `\n`

    const nextWord = sectionQuery ? ` ${sectionQuery}` : ''
    const sectDirectory = `_Sect Empire commands: *${p}allcommands sect*_ (use after crossing with *${p}road*).`
    const footer = result.pageCount > 1 && result.page < result.pageCount
      ? `\n\n*${p}allcommands${nextWord} ${result.page + 1}* for the next page\n${sectDirectory}`
      : `\n\n_Kingdom sections: *${p}menu*_\n${sectDirectory}`

    return ctx.reply(header + result.text + footer)
  },
}
