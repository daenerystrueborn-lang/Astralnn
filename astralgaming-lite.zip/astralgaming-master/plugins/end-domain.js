/** end-domain.js — The End's private dimension and summon toggle. */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { sendImage } from '../lib/image.js'
import { characterMap } from '../lib/game-data.js'
import { END_CHARACTER_ID, END_DIMENSION_ID, endStatus, setEndSummon, ownsEnd } from '../lib/the-end.js'
import { handleEnter } from './dungeon.js'

export default {
  name: 'end-domain',
  aliases: ['enddomain', 'the-end', 'end-monster'],
  category: 'character',
  requiresPlayer: true,
  description: `${config.prefix}end-domain — The End's private dimension, summon toggle and status`,
  subcommands: [
    { cmd: 'status', desc: 'show The End, her dimension and summon' },
    { cmd: 'enter', desc: 'enter the private End dimension' },
    { cmd: 'summon on|off', desc: 'enable/disable The End Monster' },
  ],
  async run(ctx) {
    const p = config.prefix
    const sub = String(ctx.args[0] ?? 'status').toLowerCase()
    if (sub === 'enter' || sub === 'go') {
      if (!ownsEnd(ctx.player)) return ctx.reply(`🌑 The dimension belongs to The End's collector. Spin: *${p}end-spin*.`)
      return handleEnter({ ...ctx, args: [END_DIMENSION_ID] })
    }
    if (sub === 'summon') {
      const mode = String(ctx.args[1] ?? '').toLowerCase()
      if (!['on', 'off', 'enable', 'disable'].includes(mode)) return ctx.reply(`Usage: *${p}end-domain summon on|off*`)
      let out = null
      await updatePlayer(ctx.db, ctx.from, player => { out = setEndSummon(player, ['on', 'enable'].includes(mode)) })
      if (!out?.ok) return ctx.reply(`🌑 You do not own The End.`)
      return ctx.reply(`🌑 *The End Monster* ${out.enabled ? 'enabled. It attacks each completed turn while The End is equipped.' : 'disabled.'}`)
    }
    const text = endStatus(ctx.player, p)
    const art = characterMap[END_CHARACTER_ID]?.infoImage ?? characterMap[END_CHARACTER_ID]?.image
    if (art && ownsEnd(ctx.player)) return sendImage(ctx, art, text)
    return ctx.reply(text)
  },
}
