/**
 * <prefix>queen-spin <amount>
 *
 * The Queen of Fairies' banner. 310 spins at 1 gem each; spins 1-284 are a
 * true dead zone, and from 285 every roll is a flat 90%. One-of-one bot-wide,
 * the same ownership model as Gogeta/Cid/Victoria: the first player anywhere
 * to land her takes the lock through claimExclusiveSpinForPlayer() and the
 * banner closes for everybody, in chat and on the website alike.
 *
 * Odds, caps and the pull loop itself live in lib/spin-banners.js, NOT here —
 * the website spins the same banner through POST
 * /api/characters/queen_of_fairies/spin, and two copies of the curve would
 * drift the first time one was tuned. This file owns the art and the copy.
 *
 * Never prints deadZoneUntil or plateauChance. Only the pity bar (progress
 * toward the 310-spin ceiling) is player-facing, the same rule every spin in
 * the bot follows.
 */
import { config } from '../config.js'
import { getExclusiveSpinWinner } from '../lib/season-engine.js'
import { characterMap } from '../lib/game-data.js'
import { getPlayer, updatePlayer } from '../lib/player-repo.js'
import { roundGems, fmtGems } from '../lib/format.js'
import { characterStars } from '../lib/rarity.js'
import { spinLockGate } from '../lib/spin-locks.js'
import { getSpinBanner, runSpinBatch } from '../lib/spin-banners.js'
import { FAIRY_SPELLS } from '../lib/fairy-queen.js'

const CHARACTER_ID = 'queen_of_fairies'
const BANNER = getSpinBanner(CHARACTER_ID)
const RULE = '━━━━━━━━━━━━━━━━━━━━'

const MISS_LINES = [
  'A crown of moths gathers over the water, then forgets what it was going to say.',
  'The dark court leans in to listen, hears your name, and turns away.',
  'Something with too many wings circles you once and decides you are not the one.',
  'The veins of the forest go quiet. Whatever was about to answer changes its mind.',
  'A bell rings somewhere under the roots. One note, and then nothing.',
  'The fairies leave a ring in the grass and no queen standing in it.',
]

function missLine(spin) {
  return `🧚‍♀️ _${MISS_LINES[spin % MISS_LINES.length]}_`
}

/** Progress toward the spin cap. Never reveals the plateau. */
function pityBar(spin, width = 10) {
  const filled = Math.max(0, Math.min(width, Math.round((spin / BANNER.maxSpinsPerPlayer) * width)))
  return `${'▰'.repeat(filled)}${'▱'.repeat(width - filled)}`
}

function reel(results) {
  const MAX_ROWS = 5
  const marks = results.map(r => (r.won ? '✦' : '·'))
  const rows = []
  for (let i = 0; i < marks.length; i += 10) rows.push(marks.slice(i, i + 10).join(' '))
  if (rows.length <= MAX_ROWS) return rows.join('\n')
  return [`_…${(rows.length - MAX_ROWS) * 10} earlier spins_`, ...rows.slice(-MAX_ROWS)].join('\n')
}

async function replyOverArt(ctx, character, text) {
  const art = character?.spinImage ?? character?.image
  if (!art) return ctx.reply(text)
  try {
    return await ctx.replyImage(art, text)
  } catch {
    return ctx.reply(text)
  }
}

function holderName(ctx, jid) {
  try {
    return getPlayer(ctx.db, jid)?.name ?? null
  } catch {
    return null
  }
}

export default {
  name: 'queen-spin',
  aliases: ['queenspin', 'fairy-spin', 'fairyspin', 'qof-spin', 'queenoffairies-spin', 'fairys'],
  category: 'character',
  requiresPlayer: true,
  description: 'Spin for the Queen of Fairies at 1 gem per spin. One-of-one, bot-wide, never for sale',

  async run(ctx) {
    const p = config.prefix
    if (!ctx.player) return ctx.reply(`⚠️ Register first with *${p}register*.`)

    const character = characterMap[CHARACTER_ID]
    if (!character) return ctx.reply(`⚠️ The Queen of Fairies isn't configured yet.`)

    if (spinLockGate(ctx, CHARACTER_ID, character.name)) return

    const existingWinner = getExclusiveSpinWinner(ctx.db, CHARACTER_ID)
    if (existingWinner) {
      if (existingWinner === ctx.from) {
        return replyOverArt(ctx, character,
          `🧚‍♀️ *${character.name} is already yours.*\n${RULE}\n` +
          `_The dark court answers to you now, and to nobody else. There is nothing left to spin for._\n` +
          `_Equip her with *${p}character equip ${CHARACTER_ID}*. The court does the rest: your race becomes Fairy, ` +
          `your mana goes past 10,000, and every wound you take gives a tenth of itself back._`)
      }
      const who = holderName(ctx, existingWinner)
      return replyOverArt(ctx, character,
        `🔒 *THE THRONE IS TAKEN*\n${RULE}\n` +
        `_${character.name} has chosen ${who ? `*${who}*` : 'another player'}._\n\n` +
        `Only one player, bot-wide, could ever win her, and someone got there first. ` +
        `No gems were spent.`)
    }

    const isFirstEverAttempt = (ctx.player[BANNER.spinField] ?? 0) === 0
    const requested = Math.floor(Number(ctx.args[0]) || 1)

    let outcome = null
    await updatePlayer(ctx.db, ctx.from, (player) => {
      outcome = runSpinBatch(ctx.db, player, BANNER, ctx.from, requested)
    })

    if (outcome?.reason === 'owned') {
      return replyOverArt(ctx, character,
        `🧚‍♀️ *${character.name} is already yours.*\n${RULE}\n` +
        `_Equip her with *${p}character equip ${CHARACTER_ID}*._`)
    }
    if (outcome?.reason === 'claimed') {
      return replyOverArt(ctx, character,
        `🔒 *THE THRONE IS TAKEN*\n${RULE}\n` +
        `_${character.name} was claimed while you were still reaching._\n\n` +
        `Another player got there first this very moment. No gems were spent.`)
    }
    if (outcome?.reason === 'gems') {
      return ctx.reply(
        `💎 *Not enough Gems.*\n${RULE}\n` +
        `One spin costs 💎*${BANNER.costPerSpin}*. You hold 💎*${fmtGems(outcome.gems)}*.\n\n` +
        `_Come back with more._`,
      )
    }
    if (outcome?.reason === 'exhausted_lifetime') {
      return ctx.reply(
        `🧚‍♀️ *No spins left.*\n${RULE}\n` +
        `_You have used all *${BANNER.maxSpinsPerPlayer}* of your spins for ${character.name}. ` +
        `The court never once turned its head._`,
      )
    }

    const last = outcome.results[outcome.results.length - 1]
    const spent = roundGems(outcome.spinsUsed * BANNER.costPerSpin)
    const range = outcome.spinsUsed === 1
      ? `Spin *${last.spin}*`
      : `Spins *${outcome.results[0].spin}* → *${last.spin}*`

    if (outcome.reason === 'won') {
      const ability = character.ability
      const spells = FAIRY_SPELLS.map(s => `${s.icon} ${p}${s.command}`).join('  ·  ')
      return replyOverArt(ctx, character,
        `🧚‍♀️✨ *THE DARK COURT OPENS* ✨🧚‍♀️\n${RULE}\n` +
        `_Spin ${last.spin}. The ring in the grass closes. Every moth in the forest lifts at once, ` +
        `and something with a crown of black light steps out of the middle of them._\n\n` +

        `🏆 *${character.name.toUpperCase()} OBTAINED*\n` +
        `${character.emoji ?? '🧚‍♀️'} *${characterStars(character.stars)}*` +
        (ability?.name ? `  ·  *${ability.name}*` : '') + `\n` +
        (ability?.flavor ? `_${ability.flavor}_\n` : '') +
        (character.description ? `\n_${character.description}_\n` : '') +

        `\n🔒 *GLOBALLY LOCKED.* No other player can ever obtain her.\n` +
        `_Taken on spin ${last.spin}, for 💎${spent} this pull._\n` +
        `💎 Remaining: 💎*${fmtGems(outcome.remaining)}*\n\n` +
        `*What you are now:*\n` +
        `1️⃣ *Fairy.* The court changes your race the moment she is yours — permanently.\n` +
        `2️⃣ *${p}character equip ${CHARACTER_ID}* — then your mana pool is at least *10,000* and every hit you take gives back *10%* of its damage at the start of your next turn.\n` +
        `3️⃣ *${p}encore* — the enemy repeats its last move for three turns.\n` +
        `4️⃣ *${p}seal* — the court's board. Any enemy move used more than three times in a fight is taken away automatically.\n` +
        `5️⃣ *Creative Magic* — one cast each per battle, no MP:\n${spells}\n`,
      )
    }

    const lines = [
      `🧚‍♀️ *THE COURT SAYS NOTHING*`,
      RULE,
      `_You spent 💎${spent}. The ring in the grass closes._`,
      ``,
      range,
      reel(outcome.results),
      ``,
      missLine(last.spin),
      ``,
      `📿 Pity  ${pityBar(last.spin)}  *${last.spin}*/${BANNER.maxSpinsPerPlayer}`,
      `💎 Remaining: 💎*${fmtGems(outcome.remaining)}*`,
    ]

    if (requested > BANNER.maxSpinsPerCommand) {
      lines.push(``, `_Capped at *${BANNER.maxSpinsPerCommand}* spins per command. Run it again for more._`)
    } else if (outcome.spinsUsed < outcome.count) {
      lines.push(``, `_Gems ran out after *${outcome.spinsUsed}* of *${outcome.count}* requested spins._`)
    }

    const lossText = lines.join('\n')
    return isFirstEverAttempt ? replyOverArt(ctx, character, lossText) : ctx.reply(lossText)
  },
}
