/**
 * sectphenomena.js — `.phenomena` / `.phenomenon` / `.sky` : the sky overhead.
 *
 *   .phenomena              the sky right now, what it changes, and when it turns
 *   .phenomena list         every sky the wheel can deal
 *   .phenomena roll         (owner) hang a freshly rolled sky over EVERYBODY
 *   .phenomena set <id> [days]   (owner) hang a named one
 *   .phenomena clear        (owner) take the hand off the wheel again
 *
 * One sky for every cultivator, turned on Monday 00:00 WAT and worked out from
 * the week itself (lib/sect-phenomena.js). What it changes is applied by
 * lib/sect-fate.js, and this card is written from the same effect keys.
 */
import { config } from '../config.js'
import { settlePendingSectHook, humanLeft } from '../lib/sect-commands.js'
import { sectDoorRefusal } from '../lib/world-guards.js'
import {
  PHENOMENA, matchPhenomenon, describePhenomenon, allPhenomenaLines, rollPhenomenon,
  skyAt, nextTurn, hydrateSky, decreeSky, clearSkyDecree,
} from '../lib/sect-phenomena.js'
import { isOwnerJid } from '../lib/group-helpers.js'

export default {
  name: 'phenomena',
  // `heavens` used to be listed here too: it is the NAME of plugins/heavens.js
  // (the hidden heavens), so the alias could only ever shadow or be shadowed.
  aliases: ['phenomenon', 'sky'],
  category: 'sect',
  requiresPlayer: true,
  description: `${config.prefix}phenomena — the celestial phenomenon over the Sect Empire, and what it changes this week`,
  subcommands: [
    { cmd: 'list', desc: 'every sky the weekly wheel can deal' },
    { cmd: 'roll', desc: 'hang a freshly rolled sky over everybody (owner only)' },
    { cmd: 'set <id> [days]', desc: 'hang a named sky over everybody (owner only)' },
    { cmd: 'clear', desc: 'hand the sky back to the weekly wheel (owner only)' },
  ],
  async run(ctx) {
    const p = config.prefix
    const wrongWorld = sectDoorRefusal(ctx.player, {
      emoji: '☁️', title: '*The heavens are above the Sect Empire.*',
      here: { cmd: 'me', label: 'Astra has no heavens like these' },
    })
    if (wrongWorld) return ctx.reply(wrongWorld)
    const pending = await settlePendingSectHook(ctx)
    if (pending) return ctx.reply(pending.join('\n'))

    hydrateSky(ctx.db)
    const now = Date.now()
    const args = (ctx.args ?? []).map(a => String(a).trim()).filter(Boolean)
    const word = (args[0] ?? '').toLowerCase()

    // ── the keeper's hand: one sky, for everybody ───────────────────────────
    if (['roll', 'reroll', 'set', 'clear', 'reset'].includes(word)) {
      if (!isOwnerJid(ctx.from)) return ctx.reply('🔒 *Only the heavens\' keeper may turn the sky by hand.* _It turns by itself every Monday._')
      if (word === 'clear' || word === 'reset') {
        await clearSkyDecree(ctx.db)
        const sky = skyAt(now)
        return ctx.reply([
          '🌌 *The sky is the wheel\'s again.*',
          describePhenomenon(sky?.phenomenon ?? null),
        ].join('\n'))
      }
      let phenomenon = null
      let days = null
      if (word === 'set') {
        // `.phenomena set blood moon 3`: a trailing number is the days.
        const rest = args.slice(1)
        if (rest.length && /^\d+(\.\d+)?$/.test(rest[rest.length - 1])) days = Number(rest.pop())
        phenomenon = matchPhenomenon(rest.join(' '))
        if (!phenomenon) {
          return ctx.reply([
            `❓ *Which sky?* _${p}phenomena set <id> [days]_`,
            ...PHENOMENA.map(x => `• *${x.id}* — ${x.name}`),
          ].join('\n'))
        }
      } else {
        phenomenon = rollPhenomenon()
      }
      if (!phenomenon) return ctx.reply('☁️ *The heavens are silent.*')
      const hung = await decreeSky(ctx.db, phenomenon, { now, days, by: ctx.from })
      return ctx.reply([
        '🌌 *The heavens turn — for every cultivator on the mountain.*',
        describePhenomenon(hung.phenomenon),
        '',
        `_It hangs for ${humanLeft(hung.until - now)}, then the weekly wheel takes the sky back. *${p}phenomena clear* ends it sooner._`,
      ].join('\n'))
    }

    if (word === 'list' || word === 'all') {
      return ctx.reply([
        `📜 *The heavens the wheel can deal (${PHENOMENA.length})*`,
        ...allPhenomenaLines(),
        '',
        '_One is dealt every Monday. It hangs for its own days; the rest of the week is clear sky._',
      ].join('\n'))
    }

    const sky = skyAt(now)
    const turn = nextTurn(now)
    if (sky) {
      return ctx.reply([
        describePhenomenon(sky.phenomenon),
        '',
        `⏳ _Overhead for another ${humanLeft(sky.until - now)}${sky.source === 'decree' ? ' (hung by the heavens\' keeper)' : ''}. The wheel turns again in ${humanLeft(turn - now)}._`,
        `_Every cultivator is under this same sky. *${p}phenomena list* shows the rest._`,
      ].join('\n'))
    }
    return ctx.reply([
      describePhenomenon(null),
      '',
      `⏳ _The wheel turns again in ${humanLeft(turn - now)} (Monday, 00:00 WAT)._`,
      `_*${p}phenomena list* shows every sky it can deal._`,
    ].join('\n'))
  },
}
