import { config } from '../config.js'
import { updatePlayer, getPlayer } from '../lib/player-repo.js'
import { getActiveSeason, getSeasonRuntime, isSeasonRunActive, ensurePlayerSeasonState, openDokkaebiBox } from '../lib/season-engine.js'
import { SEASON_02_COSMETICS } from '../lib/profile-cosmetics.js'

const BOX_ORDER = ['narrative', 'historic', 'myth']
const BOX_EMOJI = { narrative: '📖', historic: '🏺', myth: '🌌' }

export default {
  name: 'dokkaebi',
  aliases: ['dbox', 'dokkaebibox'],
  category: 'season',
  requiresPlayer: true,
  description: 'Check and open your Season 2 Dokkaebi Boxes',
  subcommands: [
    { cmd: 'boxes', desc: 'check your Narrative, Historic and Myth Box stash' },
    { cmd: 'open <box> [amount]', desc: 'open up to 25 Season 2 boxes' },
    { cmd: 'cards', desc: 'view your collectible Dokkaebi cards' },
  ],

  async run(ctx) {
    const season = getActiveSeason(ctx.db)
    if (!season || season.id !== 'season_02') {
      return ctx.reply('🌙 Dokkaebi Boxes are Season 2 rewards and can only be opened during Season 2.')
    }
    if (!ctx.player) return ctx.reply(`⚠️ Register first with *${config.prefix}register*.`)
    const action = String(ctx.args[0] ?? 'boxes').toLowerCase()
    if (action === 'cards' || action === 'collection') return showCards(ctx)
    if (action === 'open' || BOX_ORDER.includes(action)) {
      const boxId = action === 'open' ? String(ctx.args[1] ?? '').toLowerCase() : action
      const amountToken = action === 'open' ? ctx.args[2] : ctx.args[1]
      const amount = amountToken == null ? 1 : Number(amountToken)
      if (!BOX_ORDER.includes(boxId)) {
        return ctx.reply(`Usage: *${config.prefix}dokkaebi open <narrative|historic|myth> [amount]*.`)
      }
      if (!Number.isInteger(amount) || amount < 1 || amount > 25) {
        return ctx.reply('Open between 1 and 25 boxes at a time.')
      }
      const runNumber = getSeasonRuntime(ctx.db).runNumber
      let result = null
      await updatePlayer(ctx.db, ctx.from, (player) => {
        if (!isSeasonRunActive(ctx.db, season.id, runNumber)) {
          result = { ok: false, reason: 'seasonClosed' }
          return
        }
        ensurePlayerSeasonState(player, season.id)
        result = openDokkaebiBox(player, season, boxId, amount)
      })
      if (result?.reason === 'seasonClosed') return ctx.reply('🌙 Season 2 ended before the boxes opened. Nothing was used.')
      if (result?.reason === 'boxes') {
        return ctx.reply(`📦 You have *${result.available}* ${SEASON_02_COSMETICS.boxes[boxId].name}${result.available === 1 ? '' : 's'}, not ${amount}. Nothing was opened.`)
      }
      if (!result?.ok) return ctx.reply('❌ That box could not be opened. Nothing was used.')
      const rows = result.rewards.map((item, index) =>
        `• ${index + 1}. ⭐${item.stars} · ✨${item.passXp} Pass XP · ${item.bonus}${item.pity ? `\n  ${item.pity}` : ''}`,
      )
      return ctx.reply(
        `${BOX_EMOJI[boxId]} *${result.opened} ${SEASON_02_COSMETICS.boxes[boxId].name}${result.opened === 1 ? '' : 's'} opened!*\n` +
        `⭐ Stars: *${result.totalStars}* · ✨ Pass XP earned: *${result.totalPassXp}*\n` +
        `${rows.join('\n')}\n\n` +
        `Your profile cosmetics are not equipped automatically. Select unlocked art with *${config.prefix}pickpfp <id>* or *${config.prefix}pickbanner <id>*; frames with *${config.prefix}pickframe <id>*.\n` +
        `Remaining ${SEASON_02_COSMETICS.boxes[boxId].name}s: *${result.remaining}* · Boxes opened this season: *${result.openedTotal}*.`,
      )
    }
    return showBoxes(ctx)
  },
}

function showBoxes(ctx) {
  const player = getPlayer(ctx.db, ctx.from) ?? ctx.player
  ensurePlayerSeasonState(player, 'season_02')
  const stash = player.seasonProgress.dokkaebiBoxes ?? {}
  const opened = player.seasonProgress.boxesOpened ?? 0
  const lines = BOX_ORDER.map((id) =>
    `${BOX_EMOJI[id]} *${SEASON_02_COSMETICS.boxes[id].name}*: ${stash[id] ?? 0}`,
  )
  const nextPity = 5 - (opened % 5 || 0)
  return ctx.reply(
    `📦 *DOKKAEBI BOX STASH*\n${lines.join('\n')}\n\n` +
    `Pity: every fifth box guarantees a rarity-step upgrade. *${nextPity}* more open${nextPity === 1 ? '' : 's'} until the next pity reward.\n` +
    `Open with *${config.prefix}dokkaebi open <narrative|historic|myth> [amount]*.`,
  )
}

function showCards(ctx) {
  const player = getPlayer(ctx.db, ctx.from) ?? ctx.player
  ensurePlayerSeasonState(player, 'season_02')
  const owned = Object.values(player.dokkaebiCards ?? {})
    .filter((card) => Number(card?.count) > 0)
    .sort((a, b) => String(a.name).localeCompare(String(b.name)))
  if (!owned.length) return ctx.reply(`🎴 Your Dokkaebi card album is empty. Win cards from a boss tier or a Historic/Myth Box.`)
  const lines = owned.map((card) => `• ${card.rarity ?? 'common'} · *${card.name}* ×${card.count}`)
  return ctx.reply(`🎴 *DOKKAEBI CARD ALBUM*\n${lines.join('\n')}`)
}
