/**
 * esta.js — speak to Queen Esta, the Mother of Constellations.
 *
 *   <prefix>esta <anything>   talk to her — AI-powered (the same askAI stack
 *                             Yu Miaoyi uses), in character, aware of her
 *                             owner's live state: wallet, whose turn it is, and
 *                             whether the sky may be called yet
 *                             (lib/queen-king-persona.js)
 *   <prefix>esta              her card — what she is, the three prices, what
 *                             .const does, and the turn it opens on
 *
 * Aliases: <prefix>queen, <prefix>queenesta, <prefix>queen-esta.
 *
 * The AI voice belongs to the player WEARING her, exactly as Yu Miaoyi's belongs
 * to hers — anyone else gets a static, in-character dismissal and never an API
 * call. A player holding the fused Queen-King is answered from this door too:
 * after the fusion there is only one character, and she is half of it.
 *
 * The personality lives in data/queen-esta-personality.json.
 */
import { config } from '../config.js'
import {
  CONST_AGI_KNEE, CONST_TURN_GATE, dodgeFraction,
} from '../lib/queen-esta.js'
import { CROWN_ART, QUEEN_ID, crownDef, crownHoldings } from '../lib/queen-king.js'
import { crownChat } from '../lib/queen-king-persona.js'

const RULE = '━━━━━━━━━━━━━━━━━━━━'

const STRANGER_LINES = [
  `🌙 _She looks past you the way the sky looks past a rooftop._ "You are not the one I counted stars for. Go and be someone's weather."`,
  `🌙 _One polite, unhurried glance._ "I do not owe a stranger a conversation, and I owe the moon a schedule. Both stay where they are."`,
]

const UNEQUIPPED_LINES = [
  `🌙 _"You left me on the shelf. I can wait — I have nothing but time up there." (${config.prefix}character equip ${QUEEN_ID})_`,
  `🌙 _"Equip me, little one. I don't hold a conversation the way I hold a sky." (${config.prefix}character equip ${QUEEN_ID})_`,
]

const QUIET = `🌙 _The moon is out, and she is not talking just now. Come back later._`

export default {
  name: 'esta',
  // 'queen' is the allowlisted short door (handler.js + lib/platform/pipeline.js
  // both list it), and it is only an alias here so the two cannot drift.
  aliases: ['queen', 'queenesta', 'queen-esta'],
  category: 'character',
  requiresPlayer: true,
  description: `${config.prefix}esta <message>: talk to Queen Esta (works while she is equipped). Bare command shows her card.`,

  async run(ctx) {
    const pr = config.prefix
    const sub = String(ctx.args[0] ?? '').toLowerCase()
    const def = crownDef(QUEEN_ID)
    const held = crownHoldings(ctx.player)

    if (!sub || ['status', 'info', 'help', 'card'].includes(sub)) {
      const owned = ctx.player?.ownedCharacters?.includes(QUEEN_ID)
      const equipped = ctx.player?.equippedCharacter === QUEEN_ID
      const lines = [
        `🌙 *QUEEN ESTA — Mother of Constellations*`,
        RULE,
        `${'★'.repeat(def?.stars ?? 5)} _${def?.stars ?? 5}-star · ${def?.rarity ?? 'boundless'} · an Astral Pass Elite reward — no spin, no drop, not season-locked_`,
        held.fused
          ? `👑 _You hold the fused *Queen-King* — she is in there, and so is he._`
          : equipped
            ? `✅ _Equipped. She is watching the sky for you._`
            : owned
              ? `📦 _Yours, but shelved. Equip her: *${pr}character equip ${QUEEN_ID}*._`
              : `🌠 _Not yours yet — and not for sale. She is the tier *50* reward of the Astral Pass Elite column: *${pr}ap* to see where you are._`,
        ``,
        `🌠 *MOTHER OF CONSTELLATIONS* — *${pr}const*, once per battle. She lifts your target into the sky, counts what falls, and lets go.`,
        `⭐ Stars ignore DEF entirely. How many the target slips is decided by *their AGI*: over *${CONST_AGI_KNEE}* they dodge ${Math.round(dodgeFraction(CONST_AGI_KNEE + 1) * 100)}% and up to ${Math.round(dodgeFraction(99999) * 100)}%; at or under it, far fewer — at *0* AGI, almost none.`,
        `⏳ Opens on turn *${CONST_TURN_GATE.pvp}* of a duel, turn *${CONST_TURN_GATE.boss}* of a boss fight, turn *${CONST_TURN_GATE.pve}* anywhere else — and from turn *1* if you also field King Yato (or the fused crown).`,
        `👑☀️ _Nothing of it works against an opponent whose King Yato grace is up. Neither does his, against you — the two crowns are never allowed to face each other._`,
        ``,
        `🗺️ Dungeons, boss floors, swarms, rescues and duels. Stowed in the Dreamlands, like everything else.`,
        `💬 Talk to her (equipped only): *${pr}esta <message>* · The sky: *${pr}const*`,
      ]
      // The card carries her art; a dead URL costs the card its image only.
      const { sendImage } = await import('../lib/image.js')
      return sendImage(ctx, CROWN_ART.queenInfo, lines.join('\n'))
    }

    return crownChat(ctx, {
      persona: 'queen',
      text: ctx.args.join(' ').trim(),
      strangerLines: STRANGER_LINES,
      unequippedLines: UNEQUIPPED_LINES,
      quietLine: QUIET,
    })
  },
}
