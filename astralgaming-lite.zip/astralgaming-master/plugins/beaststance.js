import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { getActiveBeast } from '../lib/beast-engine.js'
import { beastMap } from '../lib/game-data.js'

const STANCES = new Set(['balanced', 'guard', 'hunt', 'scout'])

export default {
  name: 'beaststance',
  aliases: ['bstance', 'beast-stance'],
  category: 'combat',
  requiresPlayer: true,
  description: `${config.prefix}beaststance <balanced|guard|hunt|scout> — set your beast's dungeon role`,

  async run(ctx) {
    const { player, args, db } = ctx
    const pr = config.prefix
    const active = getActiveBeast(player)
    if (!active) {
      return ctx.reply(`🐲 Equip a summoned beast first with *${pr}equipbeast <name>*.`)
    }

    const stance = String(args[0] ?? '').toLowerCase()
    if (!STANCES.has(stance)) {
      return ctx.reply(
        `${active.def.emoji} *${active.def.name}* — current stance: *${player.beastStance ?? 'balanced'}*.\n\n` +
        `• *balanced* — its own ability; natural guardians may intercept\n` +
        `• *guard* — any beast can intercept dungeon hits, at a higher chance\n` +
        `• *hunt* — up to +25% special-attack damage (battle cap applies); no interception\n` +
        `• *scout* — reduce the first incoming hit by 25%; no interception\n\n` +
        `Its individual ability still works in every stance. Stances apply in dungeons, not duels.\n` +
        `Change it outside battle: *${pr}beaststance <stance>*`,
      )
    }
    if (player.inBattle) return ctx.reply(`⚔️ Set your beast's stance before the fight, not during it.`)

    let failed = false
    await updatePlayer(db, ctx.from, current => {
      if (current.inBattle || !current.activeBeast || !beastMap[current.activeBeast]) {
        failed = true
        return current
      }
      current.beastStance = stance
      return current
    })
    if (failed) return ctx.reply(`⚠️ Your beast or battle state changed. Try again outside battle.`)

    const lines = {
      balanced: 'Its special works normally; only natural guardians intercept.',
      guard: 'It may intercept dungeon hits; its special still works.',
      hunt: 'Its special damage is up to 25% stronger (battle cap applies); it will not intercept.',
      scout: 'It reduces the first dungeon hit by 25% and does not intercept.',
    }
    return ctx.reply(`${active.def.emoji} *${active.def.name}* takes the *${stance}* stance.\n_${lines[stance]}_`)
  },
}
