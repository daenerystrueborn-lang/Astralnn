/**
 * elite.js — `.elite`, the short DM doorway to buying Astral Pass Elite.
 *
 *   .elite            price + how to buy
 *   .elite buy        stage 1 (tiers 1-50)   — DM only
 *   .elite buy 2      stage 2 (tiers 51-100) — DM only
 *
 * Players said buying Elite "doesn't work in DM". It never could: the DM lock
 * in handler.js only lets a short allowlist through, and `astral-pass` was not
 * on it. Both names are on it now. This command exists so the purchase reads
 * like `.topup`: one short word, list, then `buy`. It forwards to
 * plugins/astral-pass.js, so there is still exactly one Elite purchase flow
 * (pending → DM screenshot → `.astral-pass confirm <number>` by the owner).
 */
import { config } from '../config.js'
import astralPass from './astral-pass.js'

export default {
  name: 'elite',
  aliases: ['elitepass', 'buyelite'],
  category: 'season',
  requiresPlayer: false,
  description: 'Buy Astral Pass Elite (DM only), the same way as .topup',
  subcommands: [
    { cmd: '', desc: 'Elite price and how to buy' },
    { cmd: 'buy [1|2]', desc: 'payment details for Elite stage 1 or 2 (DM only)' },
  ],

  async run(ctx) {
    const sub = String(ctx.args?.[0] ?? '').toLowerCase()
    if (sub === 'buy') {
      const stage = String(ctx.args?.[1] ?? '1')
      return astralPass.run({ ...ctx, args: ['buy', 'elite', stage] })
    }
    if (!ctx.player) {
      return ctx.reply(`⚠️ Register first with *${config.prefix}register*.`)
    }
    return astralPass.run({ ...ctx, args: ['elite'] })
  },
}
