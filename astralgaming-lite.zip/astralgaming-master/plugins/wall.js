// <prefix>wall - Kim Dokja's The Fourth Wall. Once per fight: for one turn
// he cannot be hurt, and every hit aimed at him is reflected at 40%.
// In a duel it routes through the PvP turn engine as the 'wall' action
// (pvpWall), so it spends his turn like any other duel move; everywhere
// else the shared regressor runner resolves it.
// docs/season-02-characters/kim-dokja.md
import { config } from '../config.js'
import { activateWall } from '../lib/regressor-characters.js'
import { runRegressorCommand } from '../lib/regressor-command-runner.js'
import { pvpWall } from './pvp.js'

export default {
  name: 'wall',
  aliases: [],
  category: 'combat',
  description: `${config.prefix}wall - Kim Dokja's Fourth Wall. One turn unhurtable, hits reflected at 40%. Once per fight.`,
  requiresPlayer: true,
  async run(ctx) {
    if (ctx.player?.battleState?.type === 'pvp') return pvpWall(ctx)
    return runRegressorCommand(ctx, activateWall)
  },
}
