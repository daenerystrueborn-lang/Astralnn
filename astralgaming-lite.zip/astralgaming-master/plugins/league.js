/**
 * league.js — the Astral League, player facing.
 *
 * Twenty seats at one table: thirteen Adventurers and seven qualified players,
 * everybody plays everybody, nineteen days. This file is the READ side plus the
 * owner's season start. Fighting arrives in Phase 2 with `.battle`.
 *
 * Name note: `.league` used to be an alias of Pokemon Tower. That alias is gone
 * (plugins/poketower.js keeps .poketower and .ptower), so this command owns the
 * name now. See ASTRal league/astral-league-plan.txt section 13.
 *
 * Every branch here checks the master flag FIRST and falls through to the away
 * line, so with the flag off nothing about the bot changes except the two alias
 * removals.
 */
import { config } from '../config.js'
import { getPlayer, updatePlayer, updateWorldState } from '../lib/player-repo.js'
import { pushNotificationSync } from '../lib/notification-repo.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import {
  getGroupSettings,
  saveGroupSettings,
  saveFailedMessage,
} from '../lib/group-settings.js'
import {
  ensurePvp, ratingOf, rankFor, winRate, duelsPlayed, isProvisional,
  streakLabel, PLACEMENT_DUELS,
} from '../lib/pvp-engine.js'
import {
  getLeague,
  leagueDayOf,
  leagueGate,
  seatOfPlayer,
  seatByNumber,
  resolveSeat,
  matchesDueOn,
  otherSeatOf,
  seatAdventurers,
  seatQualifiedPlayers,
  drawSeason,
  isFullySeated,
  seatingProblems,
  ensureNpcs,
  ensureAdventurerRecord,
} from '../lib/league/league-repo.js'
import { rowForSeat, placeWord } from '../lib/league/league-table.js'
import {
  LEAGUE_SEATS,
  LEAGUE_ROUNDS,
  dayKeyWAT,
} from '../lib/league/league-rules.js'
import {
  tableLines,
  myCard,
  fixturesCard,
  prizesCard,
  rulesCard,
  qualifierRulesCard,
  kickoffCard,
  firstOpponentDm,
  resultLine,
  seatLabel,
  dayDateLine,
  avaStreamCard,
  loreCaption,
  loreListCaption,
  SEAT_ROWS_PER_PAGE,
  LEAGUE_SEAT_EMPTY,
} from '../lib/league/league-copy.js'
import { scriptsForDay } from '../lib/league/league-script.js'
import { lifeLines, portraitUrlOf } from '../lib/league/league-life.js'
import { tvActive, tvPrice, tvExpiryLine, applyTvPurchase } from '../lib/league/league-tv.js'
import { trialOf, trialStatusLine } from '../lib/league/league-trial.js'
import { replyAdventurerPortrait } from '../lib/portrait-reply.js'
import { listAdventurers, getPersonality, loreOf, findAdventurerByQuery } from '../lib/league/adventurer-repo.js'
import { announceGroups, sendPaced } from '../lib/league/league-scheduler.js'
import { renderLeagueTable, renderLeagueSeatCard } from '../lib/league-table-render.mjs'
import {
  renderMatchdayCard,
  renderMatchVsCard,
  renderPlayerVsCard,
  buildFighterVsProps,
} from '../lib/league-matchday-render.mjs'
import { renderAstralTvBroadcast, renderAstralTvGuide } from '../lib/league-tv-render.mjs'
import { renderAdventurerLoreCard } from '../lib/league-adventurers-render.mjs'
import { renderLeagueHallCard, renderLeaguePurseCard } from '../lib/league-hall-render.mjs'
import { renderQualifierTrialCard } from '../lib/league-qualifier-render.mjs'
import { levelTag } from '../lib/level-display.js'

/**
 * Deliver a rendered canvas PNG with caption when `ctx.replyImage` is present,
 * falling back cleanly to `ctx.reply(caption)` when running in text-only mode.
 */
async function replyCard(ctx, renderFn, caption) {
  if (typeof ctx.replyImage === 'function' && typeof renderFn === 'function') {
    try {
      const png = await renderFn()
      if (png) return ctx.replyImage(png, caption)
    } catch {}
  }
  return ctx.reply(caption)
}

/** The help, which is also what an unknown subcommand falls back to. */
function helpText() {
  const p = config.prefix
  return [
    '🏟️🔥 *THE ASTRAL LEAGUE · COMMAND HUB* 🔥🏟️',
    '━━━━━━━━━━━━━━━━━━━━',
    `🪑 *${LEAGUE_SEATS} seats, ${LEAGUE_ROUNDS} days, one table.*`,
    '',
    `👑 *${p}league*  ·  *your personal League card & rank*`,
    `📊 *${p}league table [page]*  ·  *the full standings board (rendered)*`,
    `🗓️ *${p}league today*  ·  *today's 10-bout matchday fight card*`,
    `🥊 *${p}league vs [name|#seat]*  ·  *head to head VS poster*`,
    `📅 *${p}league schedule [me|day N|name]*  ·  *the nineteen day card*`,
    `📕 *${p}league results [day]*  ·  *settled results on the record*`,
    `📺 *${p}league tv [day]*  ·  *the day's fights, called by the booth (pass holders)*`,
    `💎 *${p}league tv subscribe gems|solars*  ·  *the Astral TV pass, ${config.tvPriceGems} gems or ${config.tvPriceSolars} solars for ${config.tvDays} days*`,
    `🗡️ *${p}league qualify*  ·  *how to qualify for the 7 player seats*`,
    `📖 *${p}league lore <name>*  ·  *an Adventurer's portrait and story, no stats*`,
    `📋 *${p}league stats <name|@player|seat>*  ·  *any seat on the board*`,
    `💰 *${p}league prizes*  ·  *the 1,000,000 solars & 10 monds purse*`,
    `📜 *${p}league rules*  ·  *every arena rule*`,
    `🏛️ *${p}league hall*  ·  *Hall of Champions*`,
    `🌟 *${p}adventurers*  ·  *the thirteen Titled Adventurers*`,
  ].join('\n')
}

/** A player's duel card, the same numbers `.pvpstats` shows. */
function pvpStatsLines(player) {
  ensurePvp(player)
  const band = rankFor(player)
  const played = duelsPlayed(player)
  const lines = []
  if (isProvisional(player)) {
    lines.push(`🎯 ${band.emoji} *${band.name}*  ·  *${ratingOf(player)} rating*  ·  _provisional, ${PLACEMENT_DUELS - played} duels to go_`)
  } else {
    lines.push(`🎯 ${band.emoji} *${band.name}*  ·  *${ratingOf(player)} rating*  ·  *${winRate(player)} win rate* over *${played}* duels`)
  }
  lines.push(`⚔️ *${player.pvp.wins} wins*, *${player.pvp.losses} losses*  ·  🔥 ${streakLabel(player)}`)
  return lines
}

/** An Adventurer's card, from the roster plus the League row. */
function adventurerStatsLines(db, league, seat) {
  const npc = listAdventurers().find(n => n.id === seat.id)
  if (!npc) return ['🌟 *That seat is empty.*']
  const personality = getPersonality(npc.id)
  // Read only: their saved duel record, if any exists yet.
  const record = db?.data?.npcs?.adventurers?.[npc.id] ?? null
  const lines = []
  lines.push(`${npc.tier?.glyph ?? '🌟'} *${npc.name}${npc.surname ? ` ${npc.surname}` : ''}*  ·  _${npc.byname ?? ''}_`)
  lines.push(`🎭 *Level ${npc.level?.value ?? '?'}* ${npc.raceId} *${npc.classId}*${npc.level?.reborn ? '  ·  🔥 *reborn*' : ''}`)
  lines.push(`❤️ *${npc.stats.maxHp} HP*  ·  🔷 *${npc.stats.maxMp} MP*`)
  lines.push(`⚔️ *STR ${npc.stats.str}*  ·  💨 *AGI ${npc.stats.agi}*  ·  ✨ *INT ${npc.stats.int}*  ·  🛡️ *DEF ${npc.stats.def}*  ·  🍀 *LCK ${npc.stats.lck}*`)
  if (npc.hometown?.name) lines.push(`🏘️ *From ${npc.hometown.name}*`)
  if (personality?.identity?.hometown?.name && !npc.hometown?.name) lines.push(`🏘️ *From ${personality.identity.hometown.name}*`)
  if (npc.powerSkill?.name) lines.push(`🌟💥 *Power skill:* *${npc.powerSkill.name}*`)
  if (npc.specialty) lines.push(`💬 _${npc.specialty}_`)
  const row = rowForSeat(league, seat.seat)
  if (row) {
    lines.push('')
    lines.push(`🏆 *${placeWord(row.rank)} place*, *${row.points} points*, *${row.wins} wins* and *${row.losses} losses*`)
  }
  if (record?.pvp) {
    lines.push(`🎯 *League duel record:* *${record.pvp.wins} wins*, *${record.pvp.losses} losses*`)
  }
  // Phase 7: the career. One chapter per season, the hall placements, and the
  // story purse that funds their telling of it.
  lines.push(...lifeLines(record))
  return lines
}

/** The status word a match carries on `.league today`. */
function statusGlyph(match) {
  if (match.result?.applied) return '✅'
  switch (match.status) {
    case 'live': return '⚔️🔥'
    case 'awaiting_mod': return '🛡️🧾'
    case 'challenged': return '📩⚡'
    default: return '🕐'
  }
}

function statusWord(match) {
  if (match.result?.applied) return '*settled*'
  switch (match.status) {
    case 'live': return '*fighting now*'
    case 'awaiting_mod': return '*waiting on a mod*'
    case 'challenged': return '*challenge out*'
    default: return '_not started_'
  }
}

export default {
  name: 'league',
  aliases: ['aleague', 'alg', 'astralleague'],
  category: 'pvp',
  requiresPlayer: false,
  description: `${config.prefix}league — the Astral League: the twenty seat table, the schedule and the purse.`,
  subcommands: ['table', 'today', 'vs', 'schedule', 'results', 'stats', 'lore', 'tv', 'qualify', 'prizes', 'rules', 'hall', 'start', 'on', 'off',
    { cmd: 'verify [match id]', desc: '(Mods) verify the fixture waiting in this group so it can start' }],

  async run(ctx) {
    const { db, from, args, reply } = ctx
    const sub = String(args[0] ?? '').toLowerCase()

    // Master flag first. Off means the League is simply away.
    const gate = leagueGate(db)
    if (!gate.open) return reply(gate.message)

    const league = getLeague(db)
    const now = Date.now()
    const day = leagueDayOf(league, now)
    const mySeat = seatOfPlayer(league, from)

    switch (sub) {
      case '':
      case 'card':
      case 'me': {
        if (!mySeat) {
          if (league.fixtures?.length) {
            return replyCard(
              ctx,
              () => renderLeagueTable(league, { limit: SEAT_ROWS_PER_PAGE, offset: 0 }),
              LEAGUE_SEAT_EMPTY
            )
          }
          return reply(LEAGUE_SEAT_EMPTY)
        }
        const caption = myCard(league, mySeat, day)
        return replyCard(ctx, () => renderLeagueSeatCard(league, mySeat, day), caption)
      }

      case 'table':
      case 'standings':
      case 'board': {
        const page = Math.max(1, parseInt(args[1], 10) || 1)
        const offset = (page - 1) * SEAT_ROWS_PER_PAGE
        if (offset >= LEAGUE_SEATS) return reply(`🏟️📊 *The board holds ${LEAGUE_SEATS} seats.* Try *.league table 1* or *.league table 2*.`)
        if (!league.fixtures.length) {
          return reply('🏟️⏳ *The season has not been drawn yet.* _The table appears the moment the owner opens it._')
        }
        const caption = tableLines(league, { limit: SEAT_ROWS_PER_PAGE, offset }).join('\n')
        return replyCard(
          ctx,
          () => renderLeagueTable(league, {
            limit: SEAT_ROWS_PER_PAGE,
            offset,
            highlightSeat: mySeat?.seat ?? null,
          }),
          caption
        )
      }

      case 'today':
      case 'matchday':
      case 'fixtures': {
        if (!day || day < 1) return reply('🏟️⏳ *The season has not started.* _The owner opens it with *.league start*._')
        const matches = matchesDueOn(league, day)
        if (!matches.length) return reply(`🍃 *Day ${day} has no matches on the board.*`)
        const lines = [
          '🏟️🔥 *TODAY ON THE BOARD* 🔥🏟️',
          '━━━━━━━━━━━━━━━━━━━━',
          `📅 *Day ${day} of ${LEAGUE_ROUNDS}*${dayDateLine(league, day) ? `, *${dayDateLine(league, day)}*` : ''}`,
          '',
        ]
        for (const m of matches) {
          const mine = mySeat && (m.seatA === mySeat.seat || m.seatB === mySeat.seat)
          lines.push(`${statusGlyph(m)} ${seatLabel(league, m.seatA)}  vs  ${seatLabel(league, m.seatB)}  ·  ${statusWord(m)}${mine ? '  🔥 *(yours)*' : ''}`)
        }
        lines.push('')
        lines.push('🌙 *Anything not started by midnight is a walkover.* Start yours with *.battle*!')
        const caption = lines.join('\n')
        return replyCard(
          ctx,
          () => renderMatchdayCard(league, day, { mySeat: mySeat?.seat ?? null }),
          caption
        )
      }

      case 'vs':
      case 'matchup':
      case 'faceoff': {
        if (!league.fixtures.length) return reply('🏟️⏳ *The season has not been drawn yet.*')
        const d = (day && day >= 1) ? day : 1
        const query = args.slice(1).join(' ').trim()
        if (!query && mySeat) {
          const mine = matchesDueOn(league, d).find(m => m.seatA === mySeat.seat || m.seatB === mySeat.seat)
          if (mine) {
            const caption = [
              '⚔️🔥 *ASTRAL LEAGUE · HEAD TO HEAD* 🔥⚔️',
              '━━━━━━━━━━━━━━━━━━━━',
              `📅 *Day ${d} of ${LEAGUE_ROUNDS}*  ·  *Match ${mine.id}*`,
              `🥊 *${seatLabel(league, mine.seatA)}*  vs  *${seatLabel(league, mine.seatB)}*`,
              `📡 *Status:* ${statusWord(mine)}`,
              '',
              '🗡️ *Start your match with .battle!*',
            ].join('\n')
            return replyCard(ctx, () => renderMatchVsCard(db, league, mine), caption)
          }
        }
        const target = query ? resolveSeat(league, query) : (mySeat ?? seatByNumber(league, 1))
        if (!target) return reply('🏟️❓ *Could not find that seat on the board.* Try *.league vs Tenmai* or *.league vs 1*.')
        const match = matchesDueOn(league, d).find(m => m.seatA === target.seat || m.seatB === target.seat)
        if (match && (!mySeat || mySeat.seat === target.seat)) {
          const caption = [
            '⚔️🔥 *ASTRAL LEAGUE · HEAD TO HEAD* 🔥⚔️',
            '━━━━━━━━━━━━━━━━━━━━',
            `📅 *Day ${d} of ${LEAGUE_ROUNDS}*  ·  *Match ${match.id}*`,
            `🥊 *${seatLabel(league, match.seatA)}*  vs  *${seatLabel(league, match.seatB)}*`,
            `📡 *Status:* ${statusWord(match)}`,
          ].join('\n')
          return replyCard(ctx, () => renderMatchVsCard(db, league, match), caption)
        }
        const leftSeat = (mySeat && mySeat.seat !== target.seat) ? mySeat : (seatByNumber(league, 1) ?? target)
        const fighterA = buildFighterVsProps(db, league, leftSeat)
        const fighterB = buildFighterVsProps(db, league, target)
        const caption = [
          '⚔️🔥 *ASTRAL LEAGUE · TALE OF THE TAPE* 🔥⚔️',
          '━━━━━━━━━━━━━━━━━━━━',
          `🥊 *${seatLabel(league, leftSeat.seat)}*  vs  *${seatLabel(league, target.seat)}*`,
          `🏅 *${fighterA.name}:* *${fighterA.points ?? 0} pts* (${fighterA.wins ?? 0}W ${fighterA.losses ?? 0}L) · ${levelTag(fighterA, { bold: true })}`,
          `🏅 *${fighterB.name}:* *${fighterB.points ?? 0} pts* (${fighterB.wins ?? 0}W ${fighterB.losses ?? 0}L) · ${levelTag(fighterB, { bold: true })}`,
        ].join('\n')
        return replyCard(
          ctx,
          () => renderPlayerVsCard(fighterA, fighterB, {
            headerTitle: 'ASTRAL LEAGUE · TALE OF THE TAPE',
            subTitle: `SEAT #${leftSeat.seat} VS SEAT #${target.seat}`,
            dayLabel: `DAY ${d} / ${LEAGUE_ROUNDS}`,
            matchTypeLabel: 'HEAD TO HEAD COMPARISON',
          }),
          caption
        )
      }

      case 'schedule': {
        if (!league.fixtures.length) return reply('🏟️⏳ *The schedule is not drawn yet.*')
        const arg = String(args[1] ?? '').toLowerCase()
        if (arg.startsWith('day') || /^\d+$/.test(arg)) {
          const dayNo = parseInt(arg.replace(/\D/g, '') || args[2], 10)
          if (!Number.isInteger(dayNo) || dayNo < 1 || dayNo > LEAGUE_ROUNDS) {
            return reply(`📅 *Days run from 1 to ${LEAGUE_ROUNDS}.* Try *.league schedule day 3*.`)
          }
          const caption = fixturesCard(league, dayNo, { now, closing: false })
          return replyCard(
            ctx,
            () => renderMatchdayCard(league, dayNo, { mySeat: mySeat?.seat ?? null }),
            caption
          )
        }
        const target = arg === 'me' ? mySeat : arg ? resolveSeat(league, args.slice(1).join(' ')) : mySeat
        if (!target) {
          return reply([
            '📅🔥 *THE NINETEEN DAY CARD* 🔥📅',
            '━━━━━━━━━━━━━━━━━━━━',
            '⚔️ *Every seat plays every other seat once, one round a day.*',
            '',
            `👑 *${config.prefix}league schedule me*  ·  *your nineteen opponents*`,
            `🗓️ *${config.prefix}league schedule day 3*  ·  *one full day*`,
            `🔍 *${config.prefix}league schedule <name>*  ·  *anyone else's run*`,
          ].join('\n'))
        }
        const mine = Object.values(league.matches)
          .filter(m => m.seatA === target.seat || m.seatB === target.seat)
          .sort((a, b) => a.dueDay - b.dueDay || a.slot - b.slot)
        const lines = [
          `📅⚔️ *${target.name.toUpperCase()}'S RUN* ⚔️📅`,
          '━━━━━━━━━━━━━━━━━━━━',
          `🪑 *Seat ${target.seat}*, ${target.kind === 'adventurer' ? '🌟 *an Adventurer*' : '🎮 *a player*'}.`,
          '',
        ]
        for (const m of mine) {
          const other = seatLabel(league, otherSeatOf(m, target.seat))
          const date = dayDateLine(league, m.dueDay)
          lines.push(`🗓️ Day ${String(m.dueDay).padStart(2, ' ')}  ${date ? `${date}  ` : ''}vs ${other}${m.result?.applied ? '  ✅' : ''}`)
        }
        const caption = lines.join('\n')
        return replyCard(ctx, () => renderLeagueSeatCard(league, target, day), caption)
      }

      case 'results': {
        const dayNo = parseInt(args[1], 10) || day
        if (!Number.isInteger(dayNo) || dayNo < 1) return reply('🏟️⏳ *Nothing has been played yet.*')
        const settled = matchesDueOn(league, dayNo).filter(m => m.result?.applied)
        const lines = [
          `🏆📕 *RESULTS, DAY ${dayNo}* 📕🏆`,
          '━━━━━━━━━━━━━━━━━━━━',
          '',
        ]
        if (!settled.length) {
          lines.push('🍃 *Nothing on the record for that day.*')
        } else {
          for (const m of settled) {
            const entry = league.results.find(r => r.matchId === m.id) ?? m.result
            lines.push(`   ${resultLine(league, { ...m.result, deltas: entry?.deltas ?? {} })}`)
          }
        }
        const caption = lines.join('\n')
        return replyCard(
          ctx,
          () => renderMatchdayCard(league, dayNo, { mySeat: mySeat?.seat ?? null }),
          caption
        )
      }

      case 'stats': {
        const target = args.length > 1 ? resolveSeat(league, args.slice(1).join(' ')) : mySeat
        if (!target) return reply('🏟️🔍 *Name a seat, a player or a seat number.* Try *.league stats Tenmai*.')
        const lines = [
          `📋👑 *SEAT ${target.seat}* 👑📋`,
          '━━━━━━━━━━━━━━━━━━━━',
          '',
        ]
        if (target.kind === 'adventurer') {
          lines.push(...adventurerStatsLines(db, league, target))
        } else {
          const player = getPlayer(db, target.id)
          if (!player) {
            lines.push(`🎮 *${target.name}* is seated but has no record here.`)
          } else {
            lines.push(`🎮 *${player.name ?? target.name}*`)
            lines.push(...pvpStatsLines(player))
          }
          const row = rowForSeat(league, target.seat)
          if (row) {
            lines.push('')
            lines.push(`🏆 *${placeWord(row.rank)} place*, *${row.points} points*, *${row.wins} wins* and *${row.losses} losses*`)
            const recent = league.results
              .filter(r => r.winnerSeat === target.seat || r.loserSeat === target.seat)
              .slice(-3).reverse()
            if (recent.length) {
              lines.push('')
              lines.push('📜 *Recent:*')
              for (const r of recent) lines.push(`   ${resultLine(league, r)}`)
            }
            const next = Object.values(league.matches)
              .filter(m => (m.seatA === target.seat || m.seatB === target.seat) && !m.result?.applied)
              .sort((a, b) => a.dueDay - b.dueDay || a.slot - b.slot)
              .slice(0, 3)
            if (next.length) {
              lines.push('')
              lines.push('📅 *Next up:*')
              for (const m of next) {
                lines.push(`   ⚔️ Day ${m.dueDay}: ${seatLabel(league, otherSeatOf(m, target.seat))}`)
              }
            }
          }
        }
        const text = lines.join('\n')
        if (target.kind === 'adventurer') {
          // An Adventurer's info is their own image with the text, nothing generated.
          const npc = listAdventurers().find(n => n.id === target.id)
          const portrait = portraitUrlOf(npc)
          return replyAdventurerPortrait(ctx, portrait, text)
        }
        if (typeof ctx.replyImage === 'function') {
          return replyCard(ctx, () => renderLeagueSeatCard(league, target, day), text)
        }
        return reply(text)
      }

      case 'qualify':
      case 'qualifier':
      case 'qualifiers':
      case 'trial': {
        const me = getPlayer(db, from)
        const trial = trialOf(league, from)
        const statusBlock = `\n\n${trialStatusLine(trial, config.prefix, { league, jid: from })}`
        const caption = `${qualifierRulesCard(config.prefix)}${statusBlock}`
        return replyCard(
          ctx,
          () => renderQualifierTrialCard(league, me, trial, {
            headerTitle: 'THE ASTRAL LEAGUE · QUALIFIER GATE',
          }),
          caption
        )
      }

      case 'prizes': {
        const caption = prizesCard(league)
        return replyCard(ctx, () => renderLeaguePurseCard(league), caption)
      }

      case 'tv': {
        const sub = String(args[1] ?? '').toLowerCase()
        const nowTv = Date.now()
        const me = getPlayer(db, from)
        const activePass = isOwnerJid(from) || tvActive(me, nowTv)

        if (sub === 'subscribe' || sub === 'buy') {
          const way = String(args[2] ?? '').toLowerCase()
          const confirmArg = String(args[3] ?? '').toLowerCase()
          const price = tvPrice(league)
          if (way !== 'gems' && way !== 'solars') {
            const caption = [
              '🏟️📺 *ASTRAL TV · PASS COUNTER* 📺🏟️',
              '━━━━━━━━━━━━━━━━━━━━',
              '',
              `💎 *Gems: ${price.gems} for ${config.tvDays} days.* You hold *${Math.floor(me?.wallet?.gems ?? 0)} gems*.`,
              `☀️ *Solars: ${price.solars} for ${config.tvDays} days.* You hold *${Math.floor(me?.wallet?.solars ?? 0)} solars*.`,
              '',
              `🎟️ Pay with *${config.prefix}league tv subscribe gems confirm* or *${config.prefix}league tv subscribe solars confirm*.`,
              `📅 Buying again adds onto the days you already have, up to *${config.tvMaxStackDays} days* ahead.`,
            ].join('\n')
            const all = Object.values(db?.data?.leagueScripts?.scripts ?? {})
            const days = [...new Set(all.map(s => s.day))].sort((x, y) => y - x)
            const latestDay = days[0] ?? day ?? 1
            const latestScripts = scriptsForDay(db, latestDay)
            return replyCard(
              ctx,
              () => renderAstralTvGuide({ day: latestDay, scripts: latestScripts, active: activePass, daysLeft: 0 }),
              caption
            )
          }
          const cost = way === 'gems' ? price.gems : price.solars
          const held = way === 'gems' ? Math.floor(me?.wallet?.gems ?? 0) : Math.floor(me?.wallet?.solars ?? 0)
          if (confirmArg !== 'confirm') {
            return reply([
              '🏟️📺 *ASTRAL TV · CONFIRM PASS* 📺🏟️',
              '━━━━━━━━━━━━━━━━━━━━',
              '',
              `💰 *${cost} ${way}* for *${config.tvDays} days*.`,
              `👛 *Your balance:* ${held} ${way}.`,
              `📡 ${tvExpiryLine(me, nowTv)}`,
              '',
              `✅ Say *${config.prefix}league tv subscribe ${way} confirm* to pay.`,
            ].join('\n'))
          }
          const result = { ok: false, problem: 'funds', balance: held }
          await updatePlayer(db, from, (p) => {
            const res = applyTvPurchase(p, way, cost, nowTv)
            Object.assign(result, res)
            if (res.ok) {
              pushNotificationSync(db, from, {
                kind: 'tv',
                title: 'Astral TV pass renewed',
                body: `Your pass now covers you for ${config.tvDays} more days, stacked onto whatever was left.`,
              }, nowTv)
            }
            return p
          })
          if (!result.ok) {
            return reply(result.problem === 'funds'
              ? `❌ *Not enough ${way} for the pass.* You hold *${Math.floor(result.balance ?? 0)} ${way}*.`
              : '❌ *That purchase did not go through.*')
          }
          return reply([
            '✅📺 *ASTRAL TV · PASS RENEWED* 📺✅',
            '━━━━━━━━━━━━━━━━━━━━',
            '',
            `💳 *Paid: ${cost} ${way}.*`,
            `📡 ${tvExpiryLine(getPlayer(db, from), nowTv)}`,
            '',
            `🎬 *Watch any fight:* *${config.prefix}league tv*`,
          ].join('\n'))
        }

        if (sub === 'status') {
          return reply([
            '🏟️📺 *ASTRAL TV · PASS STATUS* 📺🏟️',
            '━━━━━━━━━━━━━━━━━━━━',
            '',
            `📡 ${tvExpiryLine(getPlayer(db, from), nowTv)}`,
          ].join('\n'))
        }

        // The archive itself: pass holders only.
        if (!activePass) {
          const price = tvPrice(league)
          const caption = [
            '🏟️📺 *ASTRAL TV* 📺🏟️',
            '━━━━━━━━━━━━━━━━━━━━',
            '',
            '🔒 *The replays are for pass holders.*',
            `🎟️ A pass is *${price.gems} gems* or *${price.solars} solars* for *${config.tvDays} days*.`,
            `👛 You hold *${Math.floor(me?.wallet?.gems ?? 0)} gems* and *${Math.floor(me?.wallet?.solars ?? 0)} solars*.`,
            '',
            `💳 Buy with *${config.prefix}league tv subscribe gems confirm* (or *solars*).`,
          ].join('\n')
          return replyCard(
            ctx,
            () => renderAstralTvGuide({ day: day ?? 1, scripts: [], active: false, daysLeft: 0 }),
            caption
          )
        }

        const dayArg = args[1] ? parseInt(args[1], 10) : null
        const pickArg = args[2] ? parseInt(args[2], 10) : null
        const all = Object.values(db?.data?.leagueScripts?.scripts ?? {})
        if (!all.length) {
          return reply(`🏟️📺 *ASTRAL TV*\n\n📻 _Nothing has been broadcast yet. The fights go out at 18:00 on a match day._`)
        }
        const days = [...new Set(all.map(s => s.day))].sort((x, y) => y - x)
        const wantedDay = Number.isFinite(dayArg) ? dayArg : days[0]
        const dayScripts = scriptsForDay(db, wantedDay)
        if (!dayScripts.length) {
          return reply(`🏟️📺 *ASTRAL TV*\n\n📻 _Nothing was broadcast on day ${wantedDay}._`)
        }
        if (Number.isFinite(pickArg) && pickArg >= 1 && pickArg <= dayScripts.length) {
          const script = dayScripts[pickArg - 1]
          const caption = avaStreamCard(script)
          return replyCard(
            ctx,
            () => renderAstralTvBroadcast(script, {
              matchNumber: pickArg,
              totalMatches: dayScripts.length,
              isSubscriber: true,
            }),
            caption
          )
        }
        const lines = [
          `🏟️📺 *ASTRAL TV* · Day ${wantedDay} 📺🏟️`,
          '━━━━━━━━━━━━━━━━━━━━',
          '',
        ]
        for (const [i, s] of dayScripts.entries()) {
          lines.push(`🎬 *${i + 1}.* *${s.winner} over ${s.loser}*${s.coin ? `, a coin called *${s.coin}*` : ''}`)
        }
        lines.push('')
        lines.push(`🎙️ _Watch one in full: *${config.prefix}league tv ${wantedDay} <number>*_`)
        const caption = lines.join('\n')
        return replyCard(
          ctx,
          () => renderAstralTvGuide({
            day: wantedDay,
            scripts: dayScripts,
            active: true,
            daysLeft: 30,
          }),
          caption
        )
      }

      case 'lore':
      case 'info':
      case 'story': {
        const query = args.slice(1).join(' ').trim()
        if (!query) return reply(loreListCaption(listAdventurers(), config.prefix))
        const npc = findAdventurerByQuery(query)
        if (!npc) return reply(`🌟❓ *No Adventurer called "${query}".* Try *${config.prefix}league lore* for the thirteen.`)
        return replyCard(ctx, () => renderAdventurerLoreCard(npc), loreCaption(loreOf(npc)))
      }

      case 'rules':
        return reply(rulesCard())

      // Mods: verify the fixture waiting in THIS group, so it goes live.
      //
      // `.mod-here` is the canonical command (plugins/mod-here.js) and stays
      // the one the mod docs point at, but "league verify" is what gets typed
      // when someone is standing in a group with a queued fight — reported
      // 2026-10. Rather than reimplement the gate, the snapshot and the reply
      // here, this delegates to that plugin's run(): ONE implementation, two
      // ways in, and a player who tries it gets that command's own "that one
      // is for the mods" answer.
      case 'verify':
      case 'modverify': {
        const modHere = (await import('./mod-here.js')).default
        // args[0] is the word "verify" itself; mod-here reads args[0] as an
        // optional match id, so hand it the rest only — `.league verify 42`
        // must mean match 42, not a match called "verify".
        return modHere.run({ ...ctx, args: args.slice(1) })
      }

      case 'hall': {
        if (!league.honors.length) {
          const caption = [
            '🏛️👑 *THE HALL* 👑🏛️',
            '━━━━━━━━━━━━━━━━━━━━',
            '🕯️ *Empty for now. The first season has not closed yet.*',
            '🏆 _When it does, the top three and their awards are cut in stone here._',
          ].join('\n')
          return replyCard(ctx, () => renderLeagueHallCard(league), caption)
        }
        const lines = [
          '🏛️👑 *THE HALL* 👑🏛️',
          '━━━━━━━━━━━━━━━━━━━━',
        ]
        for (const honor of league.honors.slice().reverse()) {
          lines.push('')
          lines.push(`🏆 *Season ${honor.seasonId ?? '?'}*`)
          for (const [i, seatNo] of (honor.top3 ?? []).entries()) {
            const seat = seatByNumber(league, seatNo)
            lines.push(`   ${['🥇', '🥈', '🥉'][i] ?? '🏅'} *${seat?.name ?? `seat ${seatNo}`}*`)
          }
        }
        const caption = lines.join('\n')
        return replyCard(ctx, () => renderLeagueHallCard(league), caption)
      }

      case 'start': {
        if (!isOwnerJid(from)) return reply('🔒 *Only the owner can open the season.*')
        if (['running', 'catchup'].includes(league.season.status)) {
          return reply(`🏟️🔥 *The season is already running.* Day *${day ?? 1}* of *${LEAGUE_ROUNDS}*.`)
        }
        if (league.season.status === 'closed') {
          return reply('🏟️🏁 *This season is closed.* _The owner opens the next one with *.ladmin*._')
        }

        let problems = []
        let kickoffText = null
        let waiting = []
        const dms = []
        await updateWorldState(db, 'league', (data) => {
          const target = data.league
          if (!target) return
          ensureNpcs({ data })
          for (const npc of listAdventurers()) ensureAdventurerRecord(data.npcs, npc.id)

          const seatedAdventurers = target.seats.filter(s => s.kind === 'adventurer').length
          if (seatedAdventurers !== listAdventurers().length) {
            try { seatAdventurers(target, listAdventurers()) } catch (err) { problems.push(err.message); return }
          }
          if (!isFullySeated(target)) {
            const seated = seatQualifiedPlayers(target, jid => getPlayer(db, jid)?.name ?? null)
            waiting = seated?.waiting ?? []
          }
          if (!isFullySeated(target)) { problems = seatingProblems(target); return }
          if (!target.fixtures.length) {
            const drawn = drawSeason(target, { now })
            if (!drawn.ok) { problems = drawn.problems; return }
          }
          target.season.startDay = dayKeyWAT(now)
          target.season.startedAt = now
          target.season.status = 'running'
          target.rollover.lastDayDone = 0
          kickoffText = kickoffCard(target, 1, { now })
          for (const seat of target.seats.filter(s => s.kind === 'player')) {
            const dm = firstOpponentDm(target, seat, 1)
            if (dm) dms.push({ jid: seat.id, text: dm })
          }
        })

        if (problems.length) {
          return reply([
            '🏟️⚠️ *THE LEAGUE CANNOT OPEN YET*',
            '━━━━━━━━━━━━━━━━━━━━',
            ...problems.map(p => `   • ${p}`),
            '',
            `⚔️ Players earn their seat with *${config.prefix}qualify enter* by facing Master Del Astra; the seven he acknowledges are seated here. The owner can still seat a cohort by hand with *${config.prefix}ladmin qualify @p1 ... @p7*.`,
          ].join('\n'))
        }

        for (const jid of announceGroups()) {
          await ctx.sock.sendMessage(jid, { text: kickoffText }).catch(() => {})
        }
        await sendPaced(ctx.sock, dms, { log: null })
        const finalKickoff = waiting.length
          ? `${kickoffText}\n\n⏳ *${waiting.length} acknowledged player(s) did not fit the seven seats.* Their seals are kept and they go in first next season.`
          : kickoffText
        return replyCard(
          ctx,
          () => renderLeagueTable(league, { limit: SEAT_ROWS_PER_PAGE, offset: 0 }),
          finalKickoff
        )
      }

      case 'on':
      case 'off': {
        if (!ctx.isGroup) return reply('❌ *That only works in a group.*')
        if (!isOwnerJid(from)) return reply('🔒 *Only the owner can turn League matches on in a group.*')
        const want = sub === 'on'
        const current = (await getGroupSettings(ctx.sender))?.leagueEnabled === true
        if (current === want) {
          return reply(want
            ? '🏟️✅ *This group is already hosting League matches.*'
            : '🏟️🔕 *This group is not hosting League matches.*')
        }
        const res = await saveGroupSettings(ctx.sender, (settings) => { settings.leagueEnabled = want; return settings })
        if (!res.ok) return reply(saveFailedMessage('League matches', res.error))
        return reply(want
          ? '🏟️🔥 *This group is now hosting League matches.* Players can challenge each other here with *.battle @player*, and a mod must watch every one.'
          : '🏟️🔕 *This group is no longer hosting League matches.* Player challenges will be refused here.')
      }

      default:
        return reply(helpText())
    }
  },
}
