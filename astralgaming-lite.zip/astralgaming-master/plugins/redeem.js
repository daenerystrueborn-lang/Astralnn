/**
 * redeem — the 600 celebration code drop (.redeem).
 *
 *   .redeem             the help card plus the server wide claim tally
 *   .redeem <code>      claim a code: the first claim rolls 10 prizes for good
 *   .redeem codes       owner: every code, open or claimed, and its holder
 *   .redeem who <code>  owner: who claimed a code and what they pulled
 *
 * A code is single use for the WHOLE server: the first player to claim it
 * takes the pull, and it fails for everyone after that, the claimant included.
 * The engine owns everything (lib/redeem-engine.js). The claim path is two
 * writes in a fixed order: the world gate (updateWorldState, lane 'redeem')
 * checks, rolls and stamps in ONE synchronous mutator, so two simultaneous
 * claimants cannot both pass, then updatePlayer pays the recorded prizes. The
 * ledger is the single use check and the audit trail at the same time, so
 * support can answer "who took this code" from data instead of vibes.
 *
 * requiresPlayer is false on purpose: the owner inspection subcommands work
 * without a registered character. The claim path checks ctx.player itself.
 *
 * Copy follows the house style: no dashes, commas and colons only.
 */
import { config } from '../config.js'
import { updatePlayer, updateWorldState, getPlayer } from '../lib/player-repo.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import { levelsData, classes, races, getTotalStats } from '../lib/game-data.js'
import { applyLevelUps } from '../lib/combat-engine.js'
import { sendRankUp } from '../lib/rank-up.js'
import { getActiveSeason, ensurePlayerSeasonState } from '../lib/season-engine.js'
import {
  CODES, PULL_SIZE,
  normalizeCode, findCode, prizeById,
  redeemCode, codeClaimants, claimedCodeCount,
  grantPull, playerRedemptions,
} from '../lib/redeem-engine.js'

const p = () => config.prefix

/** YYYY-MM-DD for every "when" this file prints. */
function day(at) {
  return new Date(Number(at) || 0).toISOString().slice(0, 10)
}

/** The name to print for a claimant, falling back to the jid. */
function claimName(db, jid) {
  return getPlayer(db, jid)?.name ?? jid
}

/**
 * The footer every reply carries: how much of the drop the server has burned,
 * and (for a registered player) how much of it is theirs.
 */
function tallyLine(data, player) {
  const claimed = claimedCodeCount(data)
  const label = claimed >= CODES.length
    ? `Every code claimed`
    : `Server codes claimed: *${claimed}/${CODES.length}*`
  if (!player) return `_${label}. Register with *${p()}register* to claim yours._`
  return `_${label}. You hold *${playerRedemptions(data, player.id).length}/${CODES.length}*._`
}

function renderHelp(player, data) {
  return (
    `🎁 *REDEEM*\n` +
    `Drop a celebration code and pull *${PULL_SIZE}* random prizes from the 600 pool.\n\n` +
    `▸ *${p()}redeem <code>* : claim a code\n` +
    `▸ Codes are *6* letters and numbers and never expire\n` +
    `▸ Each code drops *once for the whole server*, first come first served\n` +
    `▸ Every pull is *${PULL_SIZE}* different prizes\n\n` +
    tallyLine(data, player)
  )
}

function renderPull(code, lines, data, player) {
  const rows = lines
    .map(l => `▸ ${l.granted}${l.note ? `  _(${l.note})_` : ''}`)
    .join('\n')
  return (
    `🎉 *CODE ACCEPTED!*  \`${code}\`\n\n` +
    `Your *${PULL_SIZE}* prizes:\n${rows}\n\n` +
    tallyLine(data, player)
  )
}

/** The "someone beat you to it" reply, shared by both refusal flavours. */
function renderClaimed(db, code, claim, player) {
  const mine = claim.jid === player?.id
  const who = mine
    ? `_You got this one on ${day(claim.at)}. Each code drops once, so it is spent for good._`
    : `*${claimName(db, claim.jid)}* got this one on ${day(claim.at)}. Each code drops once for the whole server.`
  return (
    `🎟️ *Already claimed:* \`${code}\`\n\n` +
    `${who}\n\n` +
    tallyLine(db.data, player)
  )
}

export default {
  name:           'redeem',
  aliases:        ['claimcode', 'giftcode', 'coupon'],
  category:       'economy',
  // False so the owner's `.redeem codes` / `.redeem who` work without a
  // registered character. The claim path checks ctx.player itself.
  requiresPlayer: false,
  description:    `${config.prefix}redeem <code> — claim a celebration code and pull 10 random prizes`,
  subcommands: [
    { cmd: '<code>',      desc: 'claim a code, first come first served' },
    { cmd: 'codes',       desc: 'owner: every code, open or claimed, and its holder' },
    { cmd: 'who <code>',  desc: 'owner: who claimed a code and what they pulled' },
  ],

  async run(ctx) {
    const { args, reply, db, player } = ctx
    const sub = normalizeCode(args[0] ?? '')

    // ── Owner: the code list ───────────────────────────────────────────────
    if (sub === 'CODES' || sub === 'LIST') {
      if (!isOwnerJid(ctx.from)) return reply(`❌ This command is restricted to the bot owner.`)
      const lines = CODES.map(code => {
        const claim = codeClaimants(db.data, code)[0]
        if (!claim) return `▸ \`${code}\` : *open*`
        return `▸ \`${code}\` : *claimed* by *${claimName(db, claim.jid)}*  _(${day(claim.at)})_`
      })
      const claimed = claimedCodeCount(db.data)
      return reply(
        `🎟️ *REDEEM CODES*  (${claimed}/${CODES.length} claimed)\n\n${lines.join('\n')}\n\n` +
        `_Who claimed one: *${p()}redeem who <code>*._`,
      )
    }

    // ── Owner: the ledger for one code ─────────────────────────────────────
    if (sub === 'WHO') {
      if (!isOwnerJid(ctx.from)) return reply(`❌ This command is restricted to the bot owner.`)
      const code = findCode(args[1] ?? '')
      if (!code) return reply(`❌ No such code. Live codes: *${p()}redeem codes*.`)
      const claims = codeClaimants(db.data, code)
      if (!claims.length) return reply(`🎟️ *\`${code}\`* is still open. No claims yet.`)
      const multiple = claims.length > 1
      const lines = claims.map((claim, i) => {
        const name = claimName(db, claim.jid)
        const tag = multiple ? (i === 0 ? '  first' : '  legacy') : ''
        const haul = (claim.prizes ?? []).map(id => prizeById(id)?.label ?? id).join(', ')
        return `▸ *${name}*  _(${day(claim.at)})_${tag}\n   ${haul}`
      })
      return reply(
        `🎟️ *\`${code}\`* claims: *${claims.length}*\n\n${lines.join('\n')}` +
        (multiple ? `\n\n_Legacy lines were claimed back when codes were once per player._` : ''),
      )
    }

    // ── Help ───────────────────────────────────────────────────────────────
    if (!args.length) return reply(renderHelp(player, db.data))

    // ── The claim path ─────────────────────────────────────────────────────
    const code = findCode(args.join(''))
    if (!code) {
      return reply(
        `❌ *Unknown code.*\n\n_Codes are 6 letters and numbers. Check your spelling and try again._`,
      )
    }
    if (!player) {
      return reply(
        `⚠️ Register with *${p()}register* first, then claim your codes.`,
      )
    }

    // 1. WORLD GATE: check, roll and stamp in one synchronous mutator. This is
    //    the single use check and the audit trail in one write. The lane is
    //    what makes it safe: two claimants tap at the same instant, the second
    //    one reads the first one's record and is refused.
    const gate = await updateWorldState(db, 'redeem', (data) => redeemCode(data, code, ctx.from))

    if (!gate.ok) {
      if (gate.reason === 'claimed') {
        return reply(renderClaimed(db, code, gate.claim, player))
      }
      return reply(`❌ *Unknown code.*`)
    }

    // 2. PLAYER PAY: grant the recorded prizes. XP settles through
    //    applyLevelUps in the same breath, mirroring plugins/quest.js.
    let lines = []
    let lvlMsgs = []
    let rankChange = null
    await updatePlayer(db, ctx.from, (fresh) => {
      const season = getActiveSeason(db)
      if (season) ensurePlayerSeasonState(fresh, season.id)
      lines = grantPull(fresh, gate.pull, { allowSeasonPoints: !!season })
      const res = applyLevelUps(fresh, levelsData, classes, races, getTotalStats)
      lvlMsgs = res.msgs ?? []
      rankChange = res.rankChange ?? null
      return fresh
    })

    await reply(renderPull(code, lines, db.data, player) + (lvlMsgs.length ? `\n\n${lvlMsgs.join('\n')}` : ''))
    if (rankChange) {
      await sendRankUp(ctx, ctx.player?.name ?? 'Hunter', rankChange.from, rankChange.to)
    }
  },
}
