/**
 * mentor.js — the Astra Kingdom's MASTER and STUDENT bond.
 *
 *   .master                     your bond: your master, your student, what is due
 *   .master invite <player>     a master invites a student
 *   .master accept <master>     a student accepts
 *   .master milestone           claim a level milestone (both sides get paid)
 *   .master leave               end the bond
 *
 * `.mentor` / `.student` / `.sifu` all reach this file (aliases below) — the old
 * word is kept because it is what half the players already type, but the game
 * speaks MASTER and STUDENT, the same pair the Sect Empire's sensei/student
 * bond uses so the two worlds teach the same lesson.
 *
 * Two things pay and they are different on purpose:
 *   • MILESTONES — a one-off pack per rung, claimed with `.master milestone`
 *     (lib/mentor-bonds.js MILESTONES);
 *   • GROWTH DIVIDENDS — every level the STUDENT crosses pays both of them,
 *     automatically, settled on the student's next command by
 *     lib/lineage-dividends.js (GROWTH_DIVIDEND). No claiming, nothing to miss.
 *
 * A master is level 50+, a student level 25 or under — the same two numbers the
 * bond has always used (MENTOR_MIN_LEVEL / APPRENTICE_MAX_LEVEL).
 */
import { config } from '../config.js'
import { updatePlayer, getPlayer, findPlayerByName } from '../lib/player-repo.js'
import {
  ensureBond, inviteApprentice, acceptBond, confirmBond, breakBond,
  dueMilestone, markMilestone, canBeMentor, canBeApprentice, formatBond,
  startGrowthWatermark, startTeacherWatermark, GROWTH_DIVIDEND,
  MILESTONES, MENTOR_MIN_LEVEL, APPRENTICE_MAX_LEVEL,
} from '../lib/mentor-bonds.js'
import { recordFaucet } from '../lib/economy-ledger.js'

const RULE = '━━━━━━━━━━━━━━━━━━━━'

export default {
  name: 'mentor',
  // `.master` and `.student` are the words the game now uses; `.apprentice` and
  // `.sifu` are the ones people type anyway. All of them reach this one file.
  aliases: ['master', 'student', 'apprentice', 'sifu', 'teacher'],
  category: 'social',
  requiresPlayer: true,
  description: 'Master & student: take a student, accept a master, and the growth both of you earn',

  async run(ctx) {
    const p = config.prefix
    const sub = (ctx.args?.[0] ?? '').toLowerCase().trim()
    const targetName = (ctx.args ?? []).slice(1).join(' ').trim()
    const users = Object.values(ctx.db.data.users ?? {})

    // ── invite (the master's word) ──
    if (sub === 'invite' || sub === 'take' || sub === 'teach') {
      if (!targetName) return ctx.reply(`Usage: \`${p}master invite <player name>\``)
      const target = findPlayerByName(users, targetName)
      if (!target) return ctx.reply('❌ No player found by that name.')
      if (target.id === ctx.from) return ctx.reply('❌ You cannot take yourself as a student.')
      let reply
      await updatePlayer(ctx.db, ctx.from, (master) => {
        const r = inviteApprentice(master, target.id)
        if (!r.ok) {
          reply = r.reason === 'mentor_level'
            ? `❌ Only level-${MENTOR_MIN_LEVEL}+ masters can take a student.`
            : r.reason === 'already_bonded' ? '❌ You already have a student.'
            : '❌ That invite is already standing.'
          return master
        }
        reply =
          `📨 *Invite sent to ${target.name}.*\n\n` +
          `_They accept with_ *${p}master accept ${master.name}*.\n` +
          `_Students must be level ${APPRENTICE_MAX_LEVEL} or under._\n` +
          `_Every level they cross from there pays you BOTH (${p}master to see the bond)._`
        return master
      })
      return ctx.reply(reply)
    }

    // ── accept (the student's word) ──
    if (sub === 'accept' || sub === 'join') {
      if (!targetName) return ctx.reply(`Usage: \`${p}master accept <master name>\``)
      const masterRecord = findPlayerByName(users, targetName)
      if (!masterRecord) return ctx.reply('❌ No master found by that name.')
      let reply
      let bonded = false
      await updatePlayer(ctx.db, ctx.from, (student) => {
        if (!canBeApprentice(student)) {
          reply = `❌ Students must be level ${APPRENTICE_MAX_LEVEL} or under.`
          return student
        }
        const bond = ensureBond(masterRecord)
        if (!bond.invites.includes(student.id)) {
          reply = '❌ That master has not invited you.'
          return student
        }
        const r = acceptBond(student, masterRecord.id)
        if (!r.ok) { reply = '❌ You already have a master.'; return student }
        // The watermark starts HERE: the climb before the master arrived is not
        // re-billed, and every level from now on pays both of you.
        startGrowthWatermark(student)
        bonded = true
        reply =
          `🎓 *${masterRecord.name} is your master.*\n${RULE}\n` +
          `• Every level you cross pays YOU *+${GROWTH_DIVIDEND.studentSolars} Solars* and *+${GROWTH_DIVIDEND.studentXp} XP*\n` +
          `• …and pays your master *+${GROWTH_DIVIDEND.masterSolars} Solars* and *+${GROWTH_DIVIDEND.masterXp} XP*\n` +
          `_Settled automatically on your next command. Read the bond with *${p}master*; leave it with *${p}master leave*._`
        return student
      })
      if (bonded) {
        // The master's half: their bond now names this student, so their share
        // of the dividends is paid while it stays that way.
        await updatePlayer(ctx.db, masterRecord.id, (master) => {
          confirmBond(master, ctx.from)
          // …and the watermark for the OTHER direction: the master's own rise
          // pays this student from here on (lib/lineage-dividends.js).
          startTeacherWatermark(master)
          return master
        }).catch(() => {})
      }
      return ctx.reply(reply)
    }

    // ── milestone (the old one-off pack, still claimable) ──
    if (sub === 'milestone' || sub === 'claim') {
      let reply
      let payout = null
      let mentorId = null
      await updatePlayer(ctx.db, ctx.from, (student) => {
        const m = dueMilestone(student)
        if (!m) { reply = '❌ No milestone is ready. Keep leveling under your master.'; return student }
        markMilestone(student, m.level)
        student.xp = (student.xp ?? 0) + m.apprenticeXp
        student.wallet.solars = (student.wallet?.solars ?? 0) + m.apprenticeSolars
        recordFaucet(ctx.db, 'mentor_milestone', { solars: m.apprenticeSolars })
        payout = m
        mentorId = student.mentorBond.mentorId
        reply = `🎓 *Milestone ${m.level}!* You earned ${m.apprenticeSolars.toLocaleString()} Solars and ${m.apprenticeXp.toLocaleString()} XP. Your master is paid too.`
        return student
      })
      if (payout && mentorId) {
        const master = getPlayer(ctx.db, mentorId)
        if (master) {
          await updatePlayer(ctx.db, master.id, (m) => {
            m.wallet.solars = (m.wallet?.solars ?? 0) + payout.mentorSolars
            recordFaucet(ctx.db, 'mentor_milestone', { solars: payout.mentorSolars })
            m.mentorTitles = m.mentorTitles ?? []
            if (!m.mentorTitles.includes(payout.title)) m.mentorTitles.push(payout.title)
            return m
          })
        }
      }
      return ctx.reply(reply)
    }

    // ── leave ──
    if (sub === 'leave' || sub === 'end' || sub === 'release') {
      let otherId = null
      await updatePlayer(ctx.db, ctx.from, (player) => {
        const r = breakBond(player)
        otherId = r.other
        return player
      })
      if (otherId) {
        await updatePlayer(ctx.db, otherId, (other) => { breakBond(other); return other }).catch(() => {})
      }
      return ctx.reply('🤝 *The bond ends.* _No growth dividends follow either of you from here._')
    }

    // ── status ──
    let text = ''
    const snap = getPlayer(ctx.db, ctx.from)
    const bondNow = snap ? ensureBond(snap) : null
    const masterName = bondNow?.mentorId ? getPlayer(ctx.db, bondNow.mentorId)?.name ?? null : null
    const studentName = bondNow?.apprenticeId ? getPlayer(ctx.db, bondNow.apprenticeId)?.name ?? null : null
    await updatePlayer(ctx.db, ctx.from, (player) => {
      text = formatBond(player, p, { masterName, studentName })
      text += `\n\n_Milestones: ${MILESTONES.map((m) => `Lv${m.level}`).join(' · ')} · masters need level ${MENTOR_MIN_LEVEL}, students level ≤${APPRENTICE_MAX_LEVEL}._`
      if (canBeMentor(player) === false && canBeApprentice(player) === false) {
        text += '\n_You are between student and master levels — keep climbing._'
      }
      return player
    })
    return ctx.reply(text)
  },
}
