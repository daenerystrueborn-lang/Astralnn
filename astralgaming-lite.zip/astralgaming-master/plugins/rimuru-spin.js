// <prefix>rimuru-spin [amount] - Rimuru's Season 2 paid chase.
// 3 Gems per spin, 400 spins, guaranteed by spin 400. One-of-one bot-wide.
// The OTHER door is .character buy rimuru for 17 Monds — a spin never
// charges Monds. docs/season-02-characters/rimuru.md. Copy shows
// count/cost/guarantee only.
// The playable Rimuru is separate from bosses/rimuru_tempest.js (untouched).
import { runRegressorSpin } from '../lib/regressor-spin-runner.js'

export default {
  name: 'rimuru-spin',
  aliases: ['rimuruspin', 'slime-spin'],
  category: 'character',
  requiresPlayer: true,
  description: 'Spin for Rimuru - 3 Gems per spin, one-of-one, guaranteed by spin 400',
  async run(ctx) { return runRegressorSpin(ctx, 'rimuru') },
}
