// <prefix>minato-spin [amount] - Minato Namikaze's Season 2 Gem chase.
// 3 Gems per spin, 350 spins, guaranteed by spin 350. One-of-one bot-wide.
// The OTHER door is .character buy minato for 7 Monds — a spin never charges
// Monds. docs/season-02-characters/minato.md. Copy shows count/cost/guarantee
// only. The banner (cost, cap, curve) lives in lib/spin-banners.js; this file
// is the command and nothing else.
import { runRegressorSpin } from '../lib/regressor-spin-runner.js'

export default {
  name: 'minato-spin',
  aliases: ['minatospin', 'flash-spin', 'hokage-spin'],
  category: 'character',
  requiresPlayer: true,
  description: 'Spin for Minato Namikaze - 3 Gems per spin, one-of-one, guaranteed by spin 350',
  async run(ctx) { return runRegressorSpin(ctx, 'minato') },
}
