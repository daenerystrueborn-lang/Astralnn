/**
 * plugins/rewind.js — Liorei's "Rewind".
 *
 * Snapshot itself is NOT a command and never was meant to be: Liorei frames the
 * fight on her own, automatically, at the start of her turns — the opening
 * frame on her 4th turn, then at random, never twice inside 5 moves. See
 * `tickLioreiTurnStart()` in lib/character-abilities.js. Nothing here takes a
 * frame, and no `.snapshot` / `.snap` / `.retake` command exists.
 *
 * This plugin is only the panic button on top of those automatic frames:
 *
 *   .rewind — spend 1 of her five charges to go back to the frame she is
 *             holding. Refuses (and spends nothing) when the current state is
 *             already as good as the frame, and it is also folded into the
 *             lethal-damage path so a killing blow rewinds on its own.
 */
import { config } from '../config.js'
import { getPlayer, updatePlayer } from '../lib/player-repo.js'
import { sendImageTo } from '../lib/image.js'
import {
  resolveSnapshotRewind,
  restoreOpponentSnapshot,
} from '../lib/character-abilities.js'

async function replyWithOptionalImage(ctx, imageUrl, text) {
  const clean = String(text ?? '').trim()
  if (imageUrl && ctx?.sock && ctx?.jid) {
    const sent = await sendImageTo(ctx.sock, ctx.jid, imageUrl, clean).catch(() => false)
    if (sent) return
  }
  await ctx.reply(clean)
}

export default {
  name: 'rewind',
  aliases: ['liorei-rewind', 'snapshotrewind'],
  category: 'combat',
  requiresPlayer: true,
  description: `Rewind to Liorei's automatic Snapshot (${config.prefix}rewind)`,

  async run(ctx) {
    const initialPlayer = getPlayer(ctx.db, ctx.from) ?? ctx.player
    const isPvp = initialPlayer?.battleState?.type === 'pvp'
    const opponentJid = isPvp ? initialPlayer?.battleState?.opponentJid : null

    let res = null
    let snapAbility = null
    await updatePlayer(ctx.db, ctx.from, (player) => {
      res = resolveSnapshotRewind(player, { manual: true })
      snapAbility = player.snapshotAbility
    })

    if (!res?.rewound) {
      return ctx.reply(res?.message ?? `❌ Could not rewind.`)
    }

    if (isPvp && opponentJid && snapAbility?.oppSnapshot) {
      await updatePlayer(ctx.db, opponentJid, (opp) => {
        restoreOpponentSnapshot(opp, snapAbility)
      })
    }

    return replyWithOptionalImage(ctx, res.image, res.message)
  },
}
