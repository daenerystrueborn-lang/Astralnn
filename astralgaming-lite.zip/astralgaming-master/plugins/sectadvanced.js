/**
 * sectadvanced.js — the short doors to the later Sect Empire systems.
 *
 *   .bloodline                 your line, its memory, and the daily rite
 *   .bloodline awaken <id>     wake a line you have inherited enough of
 *   .beast                     the beasts you have tamed
 *   .beast tame <name>         spend that beast's bait and try to catch it
 *   .beast set <name>          make it your active companion
 *   .beast feed <name>         raise its bond with its own tier's herb
 *   .bonds                     friends, rivals and waiting requests
 *   .bonds friend @player      ask somebody in your sect to be friends
 *   .bonds rival @player       declare a rival (both records are written)
 *   .bonds accept [@player]    answer a friend request
 *   .bonds end @player         end a friend or rival bond on both records
 *   .time                      the four cultivation windows and your alignment
 *
 * Every word also works under `.sect` — these are only shortcuts. All of them
 * call the same dispatcher, so there is one copy of each rule and one way to
 * write a player record.
 */
import { config } from '../config.js'
import { advancedSectCommand } from '../lib/sect-advanced.js'
import { sectDoorRefusal } from '../lib/world-guards.js'
import { isInSectEmpire } from '../lib/worlds.js'
import favorPlugin from './favor.js'

export default {
  name: 'bloodline',
  aliases: ['bloodlines', 'beast', 'beasts', 'bonds', 'cycle', 'time', 'secttime'],
  category: 'sect',
  requiresPlayer: true,
  description: `${config.prefix}bloodline / ${config.prefix}beast / ${config.prefix}bonds / ${config.prefix}time — inheritance, tamed companions, sect bonds and cultivation hours`,
  subcommands: [
    { cmd: 'bloodline [awaken|rite|rest] <id>', desc: '🩸 inherit, remember and wake a bloodline' },
    { cmd: 'beast [tame|set|feed] <name>', desc: '🐾 tame, keep and feed a beast' },
    { cmd: 'bonds [friend|rival|accept|end] @player', desc: '🤝 write a friend or rival connection inside your sect' },
    { cmd: 'time', desc: '🕐 the four hourly windows and your sect’s alignment' },
  ],

  async run(ctx) {
    if (!ctx.player) return ctx.reply(`⚠️ You need to *${config.prefix}register* first before using that command.`)
    const typed = String(ctx.cmd ?? 'bloodline').toLowerCase()
    if (typed === 'bonds' && !isInSectEmpire(ctx.player)) {
      return favorPlugin.run(ctx)
    }
    const wrongWorld = sectDoorRefusal(ctx.player, {
      emoji: '⛰️', title: '*That is a Sect Empire art.*',
      here: { cmd: 'guild', label: 'Astra has guilds instead' },
    })
    if (wrongWorld) return ctx.reply(wrongWorld)
    const word = typed === 'secttime' ? 'time' : typed
    return advancedSectCommand({ ...ctx, args: [word, ...(ctx.args ?? [])] }, word)
  },
}
