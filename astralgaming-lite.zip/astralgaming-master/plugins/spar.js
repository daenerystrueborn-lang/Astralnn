/**
 * spar.js — a practice bout: with a disciple of the sect you are standing in,
 * or with another cultivator.
 *
 *   .spar            the disciples you may face here
 *   .spar <name>     a bout with one of them (auto-resolved)
 *   .spar @player    exchange pointers with another cultivator (auto-resolved
 *                    against their shadow; nothing of theirs is touched)
 *
 * Ten bouts a WAT day, one a minute, shared between the two. A bout costs
 * nothing but the clock. A disciple's is worth a little favor with them; a
 * cultivator's goes on your record. Both count for the week's spar goal.
 * See lib/sect-spar.js.
 */
import { config } from '../config.js'
import { updatePlayer, getPlayer } from '../lib/player-repo.js'
import { resolvePlayerId } from '../lib/identity-resolver.js'
import { extractTarget } from '../lib/group-helpers.js'
import { sectDoorRefusal } from '../lib/world-guards.js'
import { hereSect } from '../lib/sect-town.js'
import { stageLabel } from '../lib/sect-cultivation.js'
import { weeklyDoneLines } from '../lib/sect-weekly.js'
import {
  sparOpponents, canSparWith, sparRefusal, runSpar, SPAR_DAILY_CAP,
  pointersRefusal, runPointers, POINTERS_STILL_STAGES,
} from '../lib/sect-spar.js'

/** The three refusals a disciple's bout and a cultivator's share. */
function limitLine(block) {
  if (block?.reason === 'pathPending') {
    return `🧭 *Choose your cultivation path first.* _Type_ *${config.prefix}path* _to see the five ways._`
  }
  if (block?.reason === 'cap') return `*You have used all ${block.limit} bouts for today.*`
  if (block?.reason === 'cooldown') return `*Wait ${block.seconds}s before the next bout.*`
  return null
}

/** `.spar @player` — a bout against another cultivator's shadow. */
async function pointersCommand(ctx, rival) {
  const p = config.prefix
  const myId = resolvePlayerId(ctx.db, ctx.from) ?? ctx.from
  const rivalName = rival.player?.name ?? 'Your rival'
  const refuse = block => {
    if (!block) return null
    if (block.reason === 'noRecord') return `🥋 *You have not stepped onto the mountain yet.* _Read the five sects with *${p}sect*._`
    if (block.reason === 'self') return `🪞 *You cannot exchange pointers with yourself.* _Mention somebody else:_ *${p}spar @player*`
    if (block.reason === 'notOnMountain') {
      return `🏔️ *${rivalName} is not in the Sect Empire.* _Pointers are exchanged between cultivators; they would have to walk up the mountain first._`
    }
    if (block.reason === 'busy') return `⚔️ *Finish the fight you are in first.*`
    return limitLine(block) ?? `*The bout could not start. Try again in a moment.*`
  }

  const first = pointersRefusal(ctx.player, rival.player, { now: Date.now(), selfId: myId, rivalId: rival.id })
  if (first) return ctx.reply(refuse(first))

  let result = null
  let failed = null
  await updatePlayer(ctx.db, ctx.from, fresh => {
    const now = Date.now()
    // The rival is read again at the moment of the bout, so the shadow is the
    // cultivator they are now and not the one they were when the list loaded.
    const them = getPlayer(ctx.db, rival.id)
    const again = pointersRefusal(fresh, them, { now, selfId: myId, rivalId: rival.id })
    if (again) { failed = again; return fresh }
    result = runPointers(fresh.sect, them.sect, {
      now, name: fresh.name ?? 'You', rivalName: them.name ?? rivalName, rivalId: rival.id,
    })
    result.rivalStage = Math.max(0, Math.round(Number(them.sect?.stage) || 0))
    result.myStage = Math.max(0, Math.round(Number(fresh.sect?.stage) || 0))
    return fresh
  })
  if (failed) return ctx.reply(refuse(failed))
  if (!result) return ctx.reply(`*The bout could not start. Try again in a moment.*`)

  const won = result.outcome === 'win'
  const lines = [
    `🥊 *Exchanging pointers with ${rivalName}* _(${stageLabel(result.rivalStage)})_ — ${result.rounds} exchange${result.rounds === 1 ? '' : 's'}`,
    `_You face their shadow: their stats, their techniques, their path. Nothing of theirs is touched._`,
    '',
    ...(result.reel ?? []),
    '',
    won
      ? `✅ *You win the bout.* _You had ${result.left.mine}% of yourself left._`
      : `💫 *You lose the bout.* _They had ${result.left.theirs}% of themselves left._`,
  ]
  if (won && !result.worthy) {
    lines.push(`💤 _${rivalName} is ${result.myStage - result.rivalStage} stages under you. A win over someone ${POINTERS_STILL_STAGES} or more stages below teaches nothing: it is not counted for the week or your record._`)
  }
  if (result.bondLines?.length) lines.push(...result.bondLines)
  lines.push(`📒 *Against cultivators:* ${result.record.wins} win${result.record.wins === 1 ? '' : 's'} · ${result.record.losses} loss${result.record.losses === 1 ? '' : 'es'}`)
  lines.push(...weeklyDoneLines(result.weekly, { prefix: p }))
  lines.push(`Bouts today: *${result.count}/${SPAR_DAILY_CAP}*`)
  return ctx.reply(lines.join('\n'))
}

export default {
  name: 'spar',
  aliases: ['practice'],
  category: 'town',
  requiresPlayer: true,
  description: 'Practice bout with a disciple of this sect, or with another cultivator',
  subcommands: [
    { cmd: '', desc: 'list the disciples you may face' },
    { cmd: '<name>', desc: 'a practice bout with one of them' },
    { cmd: '@player', desc: 'exchange pointers with another cultivator (their shadow; nothing of theirs is touched)' },
  ],

  async run(ctx) {
    const p = config.prefix
    const wrongWorld = sectDoorRefusal(ctx.player, {
      emoji: '🥋', title: '*Sparring is Sect Empire training.*',
      here: { cmd: 'pvp', label: 'duel another Astra player instead' },
    })
    if (wrongWorld) return ctx.reply(wrongWorld)

    // Another cultivator: a mention anywhere in the message, or a bare `.spar`
    // sent as a reply to them. (A reply WITH a name is still a disciple's bout.)
    const raw = (ctx.args ?? []).join(' ').trim()
    const mentioned = /@\S/.test(raw)
    if (mentioned || !raw) {
      const jid = extractTarget(ctx)
      const id = jid ? resolvePlayerId(ctx.db, jid) : null
      const player = id ? getPlayer(ctx.db, id) : null
      if (player) return pointersCommand(ctx, { jid, id, player })
      if (mentioned) {
        return ctx.reply(jid
          ? `🌱 *That player has no record yet.* _They must register before anyone can exchange pointers with them._`
          : `🥊 *Who?* _Mention them or reply to their message:_ *${p}spar @player*`)
      }
    }

    const sect = hereSect(ctx.player)
    if (!sect) {
      return ctx.reply([
        `🥋 *Nobody to spar with here.* _Walk to a sect hall first: *${p}travel* or *${p}town*._`,
        `🥊 _Or exchange pointers with another cultivator, wherever you both are:_ *${p}spar @player*`,
      ].join('\n'))
    }
    if (!ctx.player.sect) return ctx.reply(`🥋 *You have not joined a sect yet.* _Read the five mountains with *${p}sect*, then join one at its Outer Gate._`)

    const opponents = sparOpponents(sect)
    const query = raw.toLowerCase()
    if (!query) {
      const lines = opponents.map(n => `  • *${n.name}* _(${n.title})_ · *${p}spar ${n.id}*`)
      const book = ctx.player.sect?.pointers
      return ctx.reply([`*Sparring partners at ${sect.name}*`, ...lines,
        `🥊 *${p}spar @player* — exchange pointers with another cultivator.${book ? ` _Your record: ${Number(book.wins) || 0} won, ${Number(book.losses) || 0} lost._` : ''}`,
        `*${SPAR_DAILY_CAP} bouts a day.*`].join('\n'))
    }
    const npc = opponents.find(n => n.id === query || n.name.toLowerCase() === query)
      ?? opponents.find(n => n.name.toLowerCase().includes(query))
    if (!npc) return ctx.reply(`*No sparring partner called ${ctx.args.join(' ')} here.*`)

    const gate = canSparWith(ctx.player.sect, npc, sect)
    if (!gate.ok) {
      return ctx.reply(`*${npc.name} will not spar with a stranger yet. Talk with them more first.*`)
    }
    const block = sparRefusal(ctx.player.sect, Date.now())
    if (block) return ctx.reply(limitLine(block) ?? `*The bout could not start. Try again in a moment.*`)

    let result = null
    await updatePlayer(ctx.db, ctx.from, fresh => {
      if (!fresh.sect) return fresh
      const again = sparRefusal(fresh.sect, Date.now())
      if (again) return fresh
      result = runSpar(fresh.sect, npc, sect, { now: Date.now() })
      return fresh
    })
    if (!result) return ctx.reply(`*The bout could not start. Try again in a moment.*`)

    // The bout reads as a fight now, not a coin flip: the reel is the
    // engine's own events (best exchange each way, the deciding blow).
    const verdict = result.outcome === 'win' ? `✅ *You win the bout.*` : `💫 *You lose the bout.*`
    const favor = result.gained ? ` *+${result.gained} favor with ${npc.name}.*` : ''
    const lines = [
      `🥊 *Bout with ${npc.name}* — ${result.rounds} exchange${result.rounds === 1 ? '' : 's'}`,
      '',
      ...(result.reel ?? []),
      '',
      `${verdict}${favor}`,
      ...weeklyDoneLines(result.weekly, { prefix: p }),
      `Bouts today: *${result.count}/${SPAR_DAILY_CAP}*`,
    ]
    return ctx.reply(lines.join('\n'))
  },
}
