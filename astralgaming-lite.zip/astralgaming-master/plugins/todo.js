/**
 * todo.js — `.todo` : the day board.
 *
 * The Sect Empire's "what can I do right now" screen: every clock running
 * (cave, study, basket, bench, chore, ruins), every repeated act with its
 * live counter (hunt, tasks, spar, talk), the ladder rungs (bottleneck,
 * rank, legend) and the road back down. The board itself is lib/sect-todo.js
 * and is read-only: this command never starts anything.
 *
 * In the Astra Kingdom the same word answers with a pointer instead of a
 * refusal, because "what should I do" is a fair question in both worlds.
 */
import { config } from '../config.js'
import { isInSectEmpire } from '../lib/worlds.js'
import { sectTodoLines } from '../lib/sect-todo.js'

export default {
  name: 'todo',
  aliases: ['deeds'],
  category: 'sect',
  requiresPlayer: true,
  description: `${config.prefix}todo — everything you can do on the mountain today`,
  subcommands: [],

  async run(ctx) {
    if (!isInSectEmpire(ctx.player)) {
      return ctx.reply(
        `📋 *The day board is up the mountain.*\n` +
        `_Walk the road (*${config.prefix}road*) into the Sect Empire to use it._\n` +
        `_Here in the kingdom: *${config.prefix}menu* for every command, *${config.prefix}tutorial* for the guided start._`,
      )
    }
    return ctx.reply(sectTodoLines(ctx.player, { prefix: config.prefix }).join('\n'))
  },
}
