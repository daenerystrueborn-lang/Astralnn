/**
 * setpfp.js — .setpfp
 * Sets your custom profile picture, shown on .me / .profile and on the
 * short public .profile @mention view.
 *
 * Usage:
 *   Send an image with the caption ".setpfp"        — direct attach
 *   Reply ".setpfp" to a message that has an image   — quoted/reply
 *
 * ── What it costs (owner's call, 2026-10-13) ────────────────────────────────
 * The FIRST picture is free: that is the one-time set-up. Every picture after
 * it is a *change* and costs PFP_CHANGE_GEMS gems out of the player's own
 * wallet. Gems only — never Solars, never Naira. `.setbanner` is untouched and
 * stays free (profile picture only, the owner's call).
 *
 * "Have they set one before?" is read from a counter (player.pfpSets), not from
 * player.pfp, because `.delpfp` clears that field. Deleting your picture and
 * setting a new one is exactly the change this price is about, so it must cost
 * the same 50 gems — otherwise the fee has a free bypass one command long.
 *
 * The check, the charge, the new URL and the counter are one write
 * (applyPfpChange() inside a single updatePlayer() call), so a change can never
 * be charged without landing, nor land without being charged — and two
 * `.setpfp` commands racing each other cannot both read "first set" and skip
 * the fee. An image that cannot be downloaded or uploaded is refused before
 * any of that, so a failed picture never costs gems.
 */
import { config } from '../config.js'
import { updatePlayer, getPlayer } from '../lib/player-repo.js'
import { getActiveSeason } from '../lib/season-engine.js'
import { profileUploadDisabledForSeason } from '../lib/profile-cosmetics.js'
import { roundGems, fmtGems } from '../lib/format.js'
import { readProfilePictureBuffer, saveProfilePictureBuffer } from '../lib/pfp.js'

/** What a picture change costs, in gems. The first set is free. */
export const PFP_CHANGE_GEMS = 50

/**
 * The whole rule in one place — charge, store, count. Mutates `player`
 * in place, the way the other *-engine modules do, so it can run inside an
 * updatePlayer() mutator and nowhere else.
 *
 * "Has this player had their free set?" is `pfpSets > 0` OR a picture already
 * on the record: everybody who set one before this price existed has a `pfp`
 * and no counter, and their first set was the free one, so their next picture
 * is a change like anybody else's. (The counter is still the field that
 * matters afterwards, because `.delpfp` clears `pfp` — see hasHadPfpSet.)
 *
 * @returns {{ok: true, free: boolean, left: number|undefined}}
 *          | {{ok: false, short: true, gems: number}}  — not enough gems, nothing written
 */
export function hasHadPfpSet(player) {
  return Number(player?.pfpSets ?? 0) > 0 || Boolean(player?.pfp)
}

export function applyPfpChange(player, url, { gems = PFP_CHANGE_GEMS } = {}) {
  const sets = Number(player?.pfpSets ?? 0)
  const balance = Number(player?.wallet?.gems ?? 0)
  const hadOne = hasHadPfpSet(player)

  if (hadOne && balance < gems) return { ok: false, short: true, gems: balance }

  if (hadOne) {
    player.wallet = player.wallet ?? {}
    player.wallet.gems = roundGems(balance - gems)
  }
  player.pfp = url
  player.pfpSets = (hadOne ? Math.max(sets, 1) : 0) + 1
  return { ok: true, free: !hadOne, left: player?.wallet?.gems }
}

function usageMessage() {
  return (
    `❌ *Usage:* send an image with caption *${config.prefix}setpfp*, ` +
    `or reply *${config.prefix}setpfp* to an existing image.` +
    `\n\n_First picture free · changes cost 💎${PFP_CHANGE_GEMS}._`
  )
}

function shortOnGems(gems) {
  return (
    `❌ *Not enough gems!* Changing your profile picture costs *💎${PFP_CHANGE_GEMS}* ` +
    `and you have *💎${fmtGems(gems)}*.` +
    `\n_Your first picture was free. Get gems with *${config.prefix}topup*._`
  )
}

export default {
  name:           'setpfp',
  aliases:        ['setprofilepic', 'setavatar'],
  category:       'account',
  requiresPlayer: true,
  description:    `Set your profile picture (attach or reply to an image) — first one free, changes 💎${PFP_CHANGE_GEMS}`,

  async run(ctx) {
    const { db, from, reply } = ctx
    const pr = config.prefix
    if (profileUploadDisabledForSeason(getActiveSeason(db))) {
      return reply(`🚫 Custom profile-picture uploads are disabled for Season 2. Earn and select a PFP with *${pr}cosmetics* / *${pr}pickpfp <id|default>*.`)
    }

    // Fresh read: whether this is the free first set decides both the answer
    // and the write below, so it must be right even if ctx.player is a stale
    // snapshot.
    const player = ctx.player ?? getPlayer(db, from)
    const balance = Number(player?.wallet?.gems ?? 0)

    // Fast path: answer an unaffordable change before downloading and
    // uploading a picture the player is not going to be allowed to keep.
    if (hasHadPfpSet(player) && balance < PFP_CHANGE_GEMS) return reply(shortOnGems(balance))

    // Platform-neutral: Telegram hands the bytes over through the adapter's
    // getAttachment() hook, WhatsApp through Baileys. Reading only the Baileys
    // shape meant .setpfp could never succeed on Telegram (see lib/pfp.js).
    let buffer = null
    try {
      buffer = await readProfilePictureBuffer(ctx)
    } catch (err) {
      return reply(`❌ Couldn't read that image — please try again.\n_Error: ${err.message}_`)
    }
    if (!buffer) return reply(usageMessage())

    let filePath
    try {
      filePath = await saveProfilePictureBuffer(buffer, from)
    } catch (err) {
      return reply(`❌ Couldn't save that image — please try again.\n_Error: ${err.message}_`)
    }

    // Authoritative pass — the rule runs again inside the write, where the
    // wallet it reads cannot change under it.
    let outcome = null
    await updatePlayer(db, from, (p) => { outcome = applyPfpChange(p, filePath) }, { critical: true })

    if (!outcome?.ok) return reply(shortOnGems(outcome?.gems ?? balance))

    if (outcome.free) {
      return reply(
        `✅ *Profile picture set!* Check it with *${pr}me* or *${pr}profile*.\n` +
        `_That one was free — changing it again costs 💎${PFP_CHANGE_GEMS}._`,
      )
    }
    return reply(
      `✅ *Profile picture changed!* 💎${PFP_CHANGE_GEMS} paid. Remaining: *💎${fmtGems(outcome.left)}*.\n` +
      `Check it with *${pr}me* or *${pr}profile*.`,
    )
  },
}
