/**
 * sect.js — `.sect` : your sect, and the three things a member does with it.
 *
 *   .sect                     where you stand, what you hold, what is next
 *   .sect join <sect>         ask a mountain to take you in (at its Outer Gate)
 *   .sect leave [now]         walk out: rank and contribution are given back
 *   .sect promote             ask at the Main Hall for the next rank up
 *   .sect takeover            defeat your sect master for the throne
 *   .sect take @player        take another PLAYER as your disciple
 *                             (you must stand at Foundation Establishment, Early)
 *   .sect accept / decline    answer an offer of discipleship
 *   .sect disciples           your lineage: your master and your disciples
 *   .sect release [@player]   cut a bond, from either side
 *
 * GROUP MODE. In a group, `.sect on` makes the chat a SECT HALL (only the Sect
 * Empire's words work there for regular members) and `.sect off` closes it.
 * The flag is per group, set by bot mods and the owner, and enforced by
 * handler.js — see lib/sect-hall.js.
 *
 * The membership itself is lib/sect-sects.js; the trials are fights and live in
 * lib/sect-commands.js with the rest of the glue. This file is the door.
 */
import { config } from '../config.js'
import { sectCommand, settlePendingSectHook } from '../lib/sect-commands.js'
import { sectHallToggle } from '../lib/sect-hall.js'
import '../lib/sect-hooks.js'
import { sectDoorRefusal } from '../lib/world-guards.js'

export default {
  name: 'sect',
  aliases: ['sects', 'disciple'],
  category: 'sect',
  // The setup switch is a staff tool, even if that staff member has no
  // character. Gameplay below still requires a registered player.
  requiresPlayer: false,
  description: `${config.prefix}sect [join <sect> | leave | promote | takeover | take @player | disciples] — your sect, your rank, your contribution and your lineage`,
  subcommands: [
    { cmd: 'join <sect>', desc: 'ask to be taken in (stand at the Outer Gate first)' },
    { cmd: 'leave', desc: 'walk out of your sect' },
    { cmd: 'takeover', desc: '👑 reach the final realm and defeat your sect master for the throne' },
    { cmd: 'promote', desc: 'ask at the Main Hall for the next rank up' },
    { cmd: 'take @player', desc: '🎓 take another player as your disciple (Foundation Establishment, Early+)' },
    { cmd: 'accept / decline', desc: 'answer an offer of discipleship' },
    { cmd: 'disciples', desc: 'your lineage: your master and the disciples you teach' },
    { cmd: 'release [@player]', desc: 'cut a master/disciple bond (either side may)' },
    { cmd: 'bloodline [awaken|rite|rest]', desc: '🩸 inherited lines, their memory and the daily rite' },
    { cmd: 'beast [tame|set|feed]', desc: '🐾 catch a beast and make it your companion' },
    { cmd: 'bonds [friend|rival|accept|end]', desc: '🤝 connections with players inside your own sect' },
    { cmd: 'time', desc: '🕐 the four cultivation windows and your sect’s alignment' },
    { cmd: 'on / off', desc: '⛰️ in a group: turn this chat into a sect hall, or close it' },
  ],

  async run(ctx) {
    // A hall toggle answers in ANY world — bot staff in the kingdom must be
    // able to open or close it without walking up the mountain.
    if (await sectHallToggle(ctx)) return
    if (!ctx.player) return ctx.reply(`⚠️ You need to *${config.prefix}register* first before using that command.`)
    const wrongWorld = sectDoorRefusal(ctx.player, {
      emoji: '⛰️', title: '*The five great sects are up the mountain — in the Sect Empire.*',
      here: { cmd: 'guild', label: 'Astra has guilds instead' },
    })
    if (wrongWorld) return ctx.reply(wrongWorld)
    // A trial that ended while nothing was listening settles here, in its own
    // reply, before the status card: the player reads what their fight did.
    const pending = await settlePendingSectHook(ctx)
    if (pending) return ctx.reply([...pending, '', `*${config.prefix}sect* _for where that leaves you._`].join('\n'))
    return sectCommand(ctx)
  },
}
