// <prefix>squall - Klein Moretti, Tyrant form. Once per fight.
import { config } from '../config.js'
import { activateSquall } from '../lib/regressor-form-commands.js'
import { runRegressorCommand } from '../lib/regressor-command-runner.js'

export default {
  name: 'squall',
  aliases: ['storm'],
  category: 'combat',
  description: `${config.prefix}squall - Tyrant form. Enemies lose 25% accuracy for 3 turns and cannot flee.`,
  requiresPlayer: true,
  async run(ctx) { return runRegressorCommand(ctx, activateSquall) },
}
