/**
 * combat.js — Combat help command.
 *
 * Shows all available combat commands. The actual battle logic is split into:
 *   attack.js, skill.js, defend.js, flee.js
 */
import { config } from '../config.js'
import { gardenStatus, grudgeStatus, GRUDGE_STORE_PCT, GRUDGE_THRESHOLD } from '../lib/garden.js'

export default {
  name: 'combat',
  // The 'battle' alias is GONE. `.battle` is the Astral League's own command
  // now (see ASTRal league/astral-league-plan.txt section 13, and
  // plugins/battle.js in Phase 2). This help stays at .combat, and typing
  // .battle with no League match on falls back to this same help text, so
  // nobody loses the old habit.
  aliases: [],
  category: 'combat',
  requiresPlayer: false,
  description: 'Show combat command reference',

  async run(ctx) {
    const p = config.prefix
    await ctx.reply(
      `⚔️ *COMBAT COMMANDS*\n\n` +
      `*${p}attack*  _(alias: atk, a)_\n  Basic attack using your primary stat.\n\n` +
      `*${p}skill <name>*  _(alias: sk, s)_\n  Use an active skill. Costs MP.\n  Type *${p}skill* alone to list your skills.\n\n` +
      `*${p}defend*  _(alias: def, d)_\n  Guard stance — doubles DEF, recovers 5% MP.\n\n` +
      `*${p}flee*  _(alias: run, escape)_\n  35%+LCK chance to escape. Cannot flee bosses.\n\n` +
      `🌑 *SHADOW GARDEN* _(equip the character first)_\n` +
      `*Alpha: ${p}garden*\n  After two completed turns, once per battle. Seven ordered cuts, each 3% of the target's max HP, ignoring DEF and shields; stops if the target falls. Also: *${p}pvp garden* / *${p}dparty garden*.\n` +
      (gardenStatus(ctx.player) ? `  ${gardenStatus(ctx.player)}\n` : '') +
      `*Delta: Beast's Grudge* _(automatic, no command)_\n  Stores ${Math.round(GRUDGE_STORE_PCT * 100)}% of damage actually taken from direct hits. At ${GRUDGE_THRESHOLD.toLocaleString()} grudge, returns the full meter as unreflectable damage and resets.\n` +
      (grudgeStatus(ctx.player) ? `  ${grudgeStatus(ctx.player)}\n` : '') +
      `  In duels, *${p}pvp moves* shows your live move list.\n\n` +
      `🗡️ *Texas: Nigh Omni* _(automatic, equip first)_\n  After your hit: below 300 → ×4; 300+ → copied exactly. Absolute damage, no on-hit loops. Stowed in the Dreamlands.\n\n` +
      `*DUNGEON*\n` +
      `*${p}enter <dungeon>* — Enter a dungeon\n` +
      `*${p}dungeon* — Advance to next floor\n` +
      `*${p}dungeon leave* — Save and exit\n\n` +
      `*TOWN*\n` +
      `*${p}inn* — Restore HP/MP at Astral Town\n` +
      `*${p}ranking* — View leaderboards`,
    )
  },
}
