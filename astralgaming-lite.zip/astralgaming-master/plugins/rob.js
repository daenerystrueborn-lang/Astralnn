/**
 * rob.js — risk/reward theft attempt against another registered player.
 *
 * Usage: <prefix>rob (reply to or @mention the target)
 *
 * Design notes:
 *  - Mirrors plugins/jobs.js's `.work` cooldown shape exactly: a single
 *    epoch-ms timestamp field (`lastRobAt`) checked against a fixed
 *    duration (`ROB_COOLDOWN_MS`), same updatePlayer + Date.now() pattern.
 *  - Target resolution reuses transfer.js's `resolveTargetJid` pattern
 *    (reply -> @mention -> raw phone number) since, like `.send`, `.rob`
 *    targets another *registered player*, not a group member generically
 *    (which is what kick.js's simpler extractTarget is for).
 *  - Amount is 25% of the ROBBER's own last `.work` payout, never the
 *    victim's balance — this is deliberate (see spec): robbing a rich
 *    player nets exactly the same as robbing a poor one, so there's no
 *    incentive to single out wealthy targets.
 *  - No check for "is the target asleep at the inn" — lib/sleep-engine.js
 *    and handler.js's inn lockout only ever gate the *actor's own* asleep
 *    state (see handler.js), there is no existing precedent anywhere in
 *    this codebase for blocking an action because of another player's
 *    (the target's) state in that way, so this assumption is intentionally
 *    not enforced here.
 */
import { config } from '../config.js'
import { sendImage } from '../lib/image.js'
import { updatePlayer, getPlayer, playerExists } from '../lib/player-repo.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import { isFrozen, isUnconscious } from '../lib/dreamlands-death.js'
import { jailPlayer } from '../lib/jail-repo.js'

const ROB_COOLDOWN_MS = 60 * 60 * 1000 // 60 minutes
const SUCCESS_CHANCE = 0.60
const HP_SCRAPE_PCT = 0.05

// ── Jail sentence ─────────────────────────────────────────────────────────
// TUNABLE: how long a caught robber is locked out for (first-offence baseline).
// Adjust freely — 20 min is a punchy but not punishing starting point.
const ROB_JAIL_MS = 20 * 60 * 1000 // 20 minutes

/** Same reply-quote -> @mention -> raw-number resolution used by .send. */
function resolveTargetJid(ctx, raw) {
  const contextInfo = ctx.msg?.message?.extendedTextMessage?.contextInfo
  if (contextInfo?.participant) return contextInfo.participant
  if (contextInfo?.mentionedJid?.length) return contextInfo.mentionedJid[0]
  if (!raw) return null
  const digits = raw.replace(/[^0-9]/g, '')
  if (!digits) return null
  return `${digits}@s.whatsapp.net`
}

const SUCCESS_LINES = [
  'You slip in, lift the pouch, and vanish into the crowd.',
  'A quick hand and a sharp eye — nobody even noticed.',
  'You lift their coin purse clean before they can react.',
]
const FAIL_LINES = [
  'They catch your wrist mid-reach and things get ugly fast.',
  'Your hand freezes on their pocket — they were already watching.',
  'A shout goes up before you can even grab anything.',
]

// Shown immediately after the failed-rob narrative, before the player
// discovers they're sentenced. Same rotation style as FAIL_LINES.
const ARREST_LINES = [
  'A guard materialises from the shadows — your wrist is in irons before you can blink.',
  'Turns out the "easy mark" was a plainclothes enforcer. The judge is not amused.',
  'The Watch was waiting the whole time. A whistle, a net, and suddenly the world is a cell.',
  "You're halfway down the alley when a crossbow bolt buries itself in the wall beside your ear. \"Hands where I can see 'em.\"",
]

export default {
  name: 'rob',
  aliases: [],
  category: 'economy',
  requiresPlayer: true,
  description: 'Attempt to rob another player (60 min cooldown)',

  async run(ctx) {
    const p = config.prefix
    const targetJid = resolveTargetJid(ctx, ctx.args?.[0])

    if (!targetJid) {
      return ctx.reply(
        `❓ Usage: *${p}rob* — reply to or @mention the player you want to rob.\n` +
        `Example: *${p}rob @target*`,
      )
    }
    if (targetJid === ctx.from) {
      return ctx.reply(`❌ You can't rob yourself.`)
    }
    if (isOwnerJid(targetJid)) {
      return ctx.reply(`❌ You wouldn't dare rob the bot owner.`)
    }
    if (!playerExists(ctx.db, targetJid)) {
      return ctx.reply(`❌ That player isn't registered yet.`)
    }

    // Phase 1: validate robber & lock cooldown (or apply failure fine/scrape) on
    // the robber's lane alone — never nest updatePlayer(targetJid) inside
    // updatePlayer(ctx.from) (which deadlocks if A and B rob each other at once)
    // and never await network sends while holding a player lane.
    let phase1 = null
    await updatePlayer(ctx.db, ctx.from, robber => {
      if (robber.inDungeon) {
        phase1 = { error: `⚠️ You can't rob anyone while in a dungeon!` }
        return robber
      }
      if (robber.inBattle) {
        phase1 = { error: `⚠️ You can't rob anyone during a battle!` }
        return robber
      }

      const victim = getPlayer(ctx.db, targetJid)
      if (!victim) {
        phase1 = { error: `❌ That player isn't registered yet.` }
        return robber
      }
      if (victim.inDungeon) {
        phase1 = { error: `⚠️ *${victim.name}* is deep in a dungeon — you can't reach them right now.` }
        return robber
      }
      if (victim.inBattle) {
        phase1 = { error: `⚠️ *${victim.name}* is mid-battle — too risky to try right now.` }
        return robber
      }
      // §11.8: a frozen body cannot be robbed. There is nothing in their hands
      // to take, and the ice is not a place you can reach into.
      if (isFrozen(victim) || isUnconscious(victim)) {
        phase1 = { error: `🧊 *${victim.name}* is not in a state to be robbed.` }
        return robber
      }

      if (!robber.lastWorkAmount) {
        phase1 = {
          error:
            `❌ *You've never worked a shift.*\n\n` +
            `Use *${p}work* first — robbing requires knowing the streets, and a job is how you learn them.`,
        }
        return robber
      }

      const now = Date.now()
      const prevRobAt = robber.lastRobAt ?? 0
      const nextAvailable = prevRobAt ? prevRobAt + ROB_COOLDOWN_MS : 0
      if (now < nextAvailable) {
        const remainMs = nextAvailable - now
        const mins = Math.ceil(remainMs / 60000)
        phase1 = {
          error:
            `⏳ *Still laying low from your last attempt.*\n\n` +
            `Next shift available in: *${mins} min*\n\n` +
            `_Rest up, then try again._ 🕶️`,
        }
        return robber
      }

      robber.lastRobAt = now
      robber.wallet = robber.wallet ?? {}

      const amount = Math.max(1, Math.floor(robber.lastWorkAmount * 0.25))
      const success = Math.random() < SUCCESS_CHANCE

      if (success) {
        phase1 = { ok: true, success: true, amount, prevRobAt, victimName: victim.name }
        return robber
      }

      const fine = Math.min(amount, robber.wallet.solars ?? 0)
      robber.wallet.solars = Math.max(0, (robber.wallet.solars ?? 0) - fine)

      const scrape = Math.max(1, Math.floor(robber.maxHp * HP_SCRAPE_PCT))
      const hpBefore = robber.hp
      robber.hp = Math.max(1, robber.hp - scrape)
      const hpLost = hpBefore - robber.hp

      phase1 = {
        ok: true,
        success: false,
        victimName: victim.name,
        fine,
        hpLost,
        balance: robber.wallet.solars,
        hp: robber.hp,
        maxHp: robber.maxHp,
      }
      return robber
    })

    if (!phase1 || phase1.error) {
      if (phase1?.error) await ctx.reply(phase1.error)
      return
    }

    if (phase1.success) {
      let victimCheckError = null
      let stolen = 0
      let victimName = phase1.victimName
      await updatePlayer(ctx.db, targetJid, v => {
        victimName = v.name ?? victimName
        if (v.inDungeon) {
          victimCheckError = `⚠️ *${victimName}* is deep in a dungeon — you can't reach them right now.`
          return v
        }
        if (v.inBattle) {
          victimCheckError = `⚠️ *${victimName}* is mid-battle — too risky to try right now.`
          return v
        }
        if (isFrozen(v) || isUnconscious(v)) {
          victimCheckError = `🧊 *${victimName}* is not in a state to be robbed.`
          return v
        }
        v.wallet = v.wallet ?? {}
        const victimSolars = v.wallet.solars ?? 0
        stolen = Math.min(phase1.amount, victimSolars)
        v.wallet.solars = Math.max(0, victimSolars - stolen)
        return v
      })

      if (victimCheckError) {
        await updatePlayer(ctx.db, ctx.from, robber => {
          robber.lastRobAt = phase1.prevRobAt
          return robber
        })
        return ctx.reply(victimCheckError)
      }

      let newBalance = 0
      await updatePlayer(ctx.db, ctx.from, robber => {
        robber.wallet = robber.wallet ?? {}
        robber.wallet.solars = (robber.wallet.solars ?? 0) + stolen
        newBalance = robber.wallet.solars
        return robber
      })

      const narrative = SUCCESS_LINES[Math.floor(Math.random() * SUCCESS_LINES.length)]
      let msg = `┌─────────────────────┐\n`
      msg += `│   🥷 *ROB SUCCESS*   │\n`
      msg += `└─────────────────────┘\n\n`
      msg += `_${narrative}_\n\n`
      msg += `🎯 Target: *${victimName}*\n`
      msg += `☀️ Stolen: *+${stolen} solars*\n`
      msg += `💰 Your balance: *${newBalance.toLocaleString()} solars*\n\n`
      msg += `⏳ _Next attempt available in 60 minutes_`
      return sendImage(ctx, 'rob_success_card.jpg',
        `*Astral Heist*\nAnother mark, lighter pockets\n\n${msg}`)
    }

    const narrative = FAIL_LINES[Math.floor(Math.random() * FAIL_LINES.length)]
    let msg = `┌─────────────────────┐\n`
    msg += `│   🚨 *ROB FAILED*   │\n`
    msg += `└─────────────────────┘\n\n`
    msg += `_${narrative}_\n\n`
    msg += `🎯 Target: *${phase1.victimName}*\n`
    msg += `💸 Fine: *-${phase1.fine} solars*\n`
    msg += `🩸 You take a scrape: *-${phase1.hpLost} HP*\n`
    msg += `💰 Your balance: *${phase1.balance.toLocaleString()} solars*\n`
    msg += `❤️ HP: *${phase1.hp}/${phase1.maxHp}*\n\n`
    msg += `⏳ _Next attempt available in 60 minutes_`

    // ── Jail ─────────────────────────────────────────────────────────
    const arrest = ARREST_LINES[Math.floor(Math.random() * ARREST_LINES.length)]
    msg += `\n\n🔒 *ARRESTED* — _${arrest}_\n_Sentence: ${ROB_JAIL_MS / 60000} min. No commands until you're released._`
    await jailPlayer(ctx.db, ctx.from, ROB_JAIL_MS, 'robbery')
    return sendImage(ctx, 'rob_fail_card.jpg',
      `*Astral Heist Gone Wrong*\nCaught red-handed and thrown in a cell\n\n${msg}`)
  },
}
