/**
 * premium.js — Premium subscriptions (Naira, screenshot-confirmed).
 *
 * Usage:
 *   .premium                              — status (DM/group) or plan list if inactive
 *   .premium buy <plan>                   — DM only; shows payment details
 *   .premium buy <plan> for <username>    — DM only; gift Premium to another player
 *   .premium confirm <who> [plan]         — owner-only, grants premium. `<who>` is the
 *                                           buyer's WhatsApp number (what the screenshot
 *                                           caption prints) or their display name; the
 *                                           plan defaults to the one they paid for.
 *                                           If the pending has `recipientJid` (gift),
 *                                           the grant is applied to the recipient and
 *                                           the buyer gets a thank-you note.
 *   .premium reject <who>                 — owner-only, clears a pending purchase
 *   .premium on / .premium off            — owner-only, run inside the target group
 *
 * See lib/premium.js for perk logic, lib/premium-perks.js for the 2026-10-21
 * additions (spam-ban immunity, 50 DM commands/day, pre-orders, gifting),
 * lib/pending-purchase.js for the shared DM-screenshot flow, and handler.js
 * for the DM lock + premium-gated-group enforcement that surround this plugin.
 */
import { PREMIUM_DAILY_GEMS, PREMIUM_EXTRA_SPINS, PREMIUM_DM_LIMIT } from '../lib/premium-perks.js'
import { config } from '../config.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import { updatePlayer, getPlayer } from '../lib/player-repo.js'
import { saveGroupSettings, saveFailedMessage } from '../lib/group-settings.js'
import { addPremiumGroup, removePremiumGroup } from '../lib/premium-groups.js'
import { isPremiumActive, grantPremium, premiumDaysLeft, previewPremiumGrant } from '../lib/premium.js'
import { premiumPlans as plansData } from '../lib/game-data.js'
import { sendImage, sendImageTo } from '../lib/image.js'
import { grantMonthlyExclusiveAbility, grantPremiumAbility } from '../lib/premium-abilities.js'
import {
  getPending, pendingHelp, PURCHASE_KINDS, pendingKinds, resolvePurchaseTarget,
  candidateRecords,
} from '../lib/pending-confirm.js'

const PLAN_KEYS = Object.keys(plansData.plans)

function daysLeft(expiresAt) {
  return premiumDaysLeft(expiresAt)
}

/**
 * abilityGiftLine(gift) — the buyer-facing result of the monthly one-of-one
 * gift (grantMonthlyExclusiveAbility), shown in the confirmation DM. Empty
 * string for plans that don't take the gift (weekly/yearly).
 *
 * There is no losing outcome on purpose: 'won' is the gift, 'already' is a
 * renewal keeping its gift, and 'sold_out' means every one-of-one is currently
 * with another active Premium holder (they free up as those plans expire) and
 * the buyer has Crown's Favor from grantPremiumAbility instead.
 */
function abilityGiftLine(gift) {
  switch (gift?.outcome) {
    case 'won': {
      const a = gift.ability
      const move = a?.activeCommand ? `Active move: *${config.prefix}${a.activeCommand}*.\n` : `Passive only, no active move.\n`
      return (
        `✨ *MONTHLY ABILITY GIFT*\n` +
        `Chosen for you: ${a?.emoji ?? '✨'} *${a?.name ?? gift.abilityId}* — one of only *5* in the whole game, held by a single player at a time. Gifted outright: no spin, no luck.\n` +
        move +
        `${a?.passiveDesc ?? ''}\n` +
        `⏳ _It lives while your Premium lives: when the plan expires, the ability goes with it._`
      )
    }
    case 'sold_out':
      return `✨ *Monthly gift:* all 5 one-of-one abilities are currently held by other active Premium holders — they free up as those plans expire, and yours will find you on a later monthly purchase. *Crown's Favor* stands in for now.`
    case 'already':
      return `✨ *Monthly gift:* ${gift.ability?.emoji ?? '✨'} *${gift.ability?.name ?? 'your one-of-one'}* is already yours and stays yours — a player holds exactly one, and renewals don't reroll it.`
    default:
      return ''
  }
}

/** Short owner-facing note appended to the confirm ack. */
function giftOutcomeShort(gift) {
  switch (gift?.outcome) {
    case 'won':      return `✨ Gifted one-of-one *${gift.ability?.name ?? gift.abilityId}*!`
    case 'sold_out': return `✨ All 5 held — Crown's Favor given.`
    case 'already':  return `✨ Already holds *${gift.ability?.name ?? 'a one-of-one'}*.`
    default:         return ''
  }
}

const PERKS_LINE =
  `Perks: ✨ 1.25× XP/Solars on kill · 💫 1 free auto-revive/day · 📖 Story Mode chapters · ` +
  `🛡️ Never auto-banned for spam · 💬 ${PREMIUM_DM_LIMIT} DM commands/day · 🔖 Pre-order upcoming characters & items · ` +
  `💎 +${PREMIUM_DAILY_GEMS} gems on every ${config.prefix}daily · 🎰 +${PREMIUM_EXTRA_SPINS} spins on every banner\n` +
  `✨ Monthly plan: a random one-of-one ability, gifted outright (only 5 exist). It expires with Premium.`

function planList(pr) {
  return Object.entries(plansData.plans)
    .map(([key, plan]) => `  • *${key}* — ${plan.label}, ₦${plan.priceNaira.toLocaleString()} / ${plan.durationDays}d`)
    .join('\n') +
    (!purchaseBlockReason()
      ? `\n\nBuy for yourself: *${pr}premium buy <plan>*\nGift to someone else: *${pr}premium buy <plan> for <username>* _(DM only)_`
      : `\n\n🔒 _${purchaseBlockReason() === 'paused' ? 'New purchases are paused by the owner.' : 'Bank-transfer payment details are not fully configured.'}_`) +
    `\n➕ _Already have Premium? Buying again stacks the new days onto the days you already have._` +
    `\n\n✨ The *monthly* plan *gifts* a random one-of-one ability — only *5* exist in the entire game, each held by a single player at a time. Gifted outright: no spin, no luck roll. ⏳ Abilities live and die with the plan — when Premium expires, the ability goes with it.`
}

function statusText(player, pr) {
  if (isPremiumActive(player)) {
    const remaining = daysLeft(player.premium.expiresAt)
    const giftedLine = player.premium.giftedBy
      ? `🎁 Gifted by: *${player.premium.giftedBy}*${player.premium.giftedByJid ? ` _(${player.premium.giftedByJid.split('@')[0]})_` : ''}\n`
      : ''
    return (
      `👑 *Premium active!*\n` +
      `Plan: *${player.premium.plan}*\n` +
      `Expires in *${remaining} day(s)* _(${new Date(player.premium.expiresAt).toLocaleDateString()})_\n` +
      giftedLine +
      `\n${PERKS_LINE}\n\n` +
      (!purchaseBlockReason()
        ? `➕ _Want more time? DM *${pr}premium buy <weekly|monthly|yearly>*. New days stack onto your *${remaining} day(s)* left. View plans: *${pr}premium plans*._`
        : `➕ _*${remaining} day(s)* left. ${purchaseBlockReason() === 'paused' ? 'New purchases are paused by the owner.' : 'Bank-transfer payment details are not fully configured.'} Plans: *${pr}premium plans*._`)
    )
  }
  return `🔓 *No active Premium.*\n\n📦 *Plans:*\n${planList(pr)}`
}

/**
 * Are purchases open RIGHT NOW?
 *
 * Read per call so an explicit PREMIUM_PURCHASES_OPEN=false pause is honoured
 * without a code change. This is a pause switch, not a payment-provider check:
 * WhatsApp Premium uses the configured bank-transfer + owner-confirmation
 * flow. The bank details themselves are validated separately before any
 * pending order is created.
 */
function purchasesOpen() {
  const raw = process.env.PREMIUM_PURCHASES_OPEN
  if (raw != null && String(raw).trim() !== '') return String(raw).trim() === 'true'
  return config.premiumPurchasesOpen
}

/** The manual transfer desk needs all three bank fields before it can bill. */
function paymentConfigured() {
  const pay = config.payment ?? {}
  return [pay.bankName, pay.accountNumber, pay.accountName]
    .every(value => String(value ?? '').trim() !== '')
}

function purchaseBlockReason() {
  if (!purchasesOpen()) return 'paused'
  if (!paymentConfigured()) return 'missing-payment-details'
  return null
}

function purchasesClosedText(pr) {
  const reason = purchaseBlockReason()
  const headline = reason === 'missing-payment-details'
    ? '🔒 *Premium purchases are unavailable right now.*'
    : '🔒 *Premium purchases are paused right now.*'
  const detail = reason === 'missing-payment-details'
    ? 'The bank-transfer payment details are not fully configured, so no payment has been requested and no order has been created.'
    : 'The owner has paused new Premium orders. No payment has been requested and no order has been created.'
  return (
    `${headline}\n\n` +
    `${detail}\n\n` +
    `Premium includes 💬 ${PREMIUM_DM_LIMIT} DM commands/day, ` +
    `💎 +${PREMIUM_DAILY_GEMS} gems on every ${pr}daily, and ` +
    `🎰 +${PREMIUM_EXTRA_SPINS} spins on every banner.\n\n` +
    `• *${pr}premium plans* — view the plans\n` +
    `• *${pr}premium status* — your current status`
  )
}

function purchaseUnavailableText(pr) {
  return purchasesClosedText(pr)
}

async function handleBuy(ctx) {
  const pr = config.prefix
  if (purchaseBlockReason()) {
    return ctx.reply(purchaseUnavailableText(pr))
  }
  if (ctx.isGroup) {
    return ctx.reply(`💬 DM me *${pr}premium buy <plan>* to see payment details.`)
  }
  if (!ctx.player) {
    return ctx.reply(`⚠️ Register first with *${pr}register*, then run *${pr}premium buy <plan>*.`)
  }

  // Parse "<plan> [for <username>]" — gifting syntax:
  //   .premium buy monthly for Yochan
  //   .premium buy weekly @someone
  // The "for" keyword separates the plan from the recipient. Anything after
  // "for" is treated as a name/jid resolved up front so we can tell the buyer
  // NOW if the name doesn't exist, rather than letting them pay first and
  // hear it from the owner later.
  const planKey = (ctx.args[1] ?? '').toLowerCase()
  const forIdx = ctx.args.findIndex((a, i) => i >= 2 && a.toLowerCase() === 'for')
  let recipientQuery = null
  if (forIdx !== -1) {
    recipientQuery = ctx.args.slice(forIdx + 1).join(' ').trim()
  } else if (ctx.args.length >= 3) {
    // Backwards-compat: ".premium buy monthly Yochan" (no "for") is also
    // treated as a gift to Yochan.
    recipientQuery = ctx.args.slice(2).join(' ').trim()
  }

  if (!PLAN_KEYS.includes(planKey)) {
    return ctx.reply(`❌ Unknown plan *"${ctx.args[1] ?? ''}"*.\n\n${planList(pr)}`)
  }

  let recipient = null
  let recipientKey = null
  if (recipientQuery) {
    const matches = candidateRecords(ctx.db, recipientQuery)
    if (!matches.length) {
      return ctx.reply(
        `❌ I couldn't find any player named *"${recipientQuery}"*. Double-check the spelling, or use their phone number/JID.`,
      )
    }
    if (matches.length > 1) {
      const sample = matches.slice(0, 5).map(m => `• *${m.player?.name ?? '(unnamed)'}* _(${m.key})_`).join('\n')
      return ctx.reply(
        `⚠️ More than one player matches *"${recipientQuery}"* — be more specific:\n${sample}\n\n_Try using their full name or phone number._`,
      )
    }
    recipient = matches[0].player
    recipientKey = matches[0].key
    if (recipientKey === ctx.from) {
      return ctx.reply(`ℹ️ That's you! Just use *${pr}premium buy ${planKey}* without the "for" to buy for yourself.`)
    }
  }

  const plan = plansData.plans[planKey]
  let busy = false
  await updatePlayer(ctx.db, ctx.from, p => {
    // A receipt already with the owner is never overwritten by a new order —
    // let the owner confirm the paid screenshot first, then the buyer can
    // immediately buy again and stack more days on top.
    if (p.premiumPending?.state === 'pending_confirmation') { busy = true; return }
    p.premiumPending = {
      plan: planKey,
      state: 'awaiting_screenshot',
      at: Date.now(),
    }
    if (recipient && recipientKey) {
      p.premiumPending.recipientJid = recipientKey
      p.premiumPending.recipientName = recipient.name ?? recipientQuery
      p.premiumPending.isGift = true
    }
  })
  if (busy) {
    return ctx.reply(
      `⏳ Your last Premium payment screenshot is still waiting for the owner to confirm.\n` +
      `_Once it's approved, you can order again right away and the new days will stack onto your total._`,
    )
  }

  const targetPlayer = recipient ? (getPlayer(ctx.db, recipientKey) ?? recipient) : (getPlayer(ctx.db, ctx.from) ?? ctx.player)
  const preview = previewPremiumGrant(targetPlayer, planKey, plansData)
  const pay = config.payment
  const forLine = recipient
    ? `🎁 *Gifting to:* ${recipient.name} _(${recipientKey})_\n_After confirmation, Premium will be applied to their account — not yours._\n\n`
    : ''
  const stackLine = preview?.stacked
    ? (recipient
      ? `➕ *Stacking onto ${recipient.name}'s active Premium:* +*${preview.addedDays} days* added to their *${preview.previousDaysLeft} day(s)* left → *${preview.totalDaysLeft} day(s)* total.\n\n`
      : `➕ *Stacking onto your active Premium:* +*${preview.addedDays} days* added to your *${preview.previousDaysLeft} day(s)* left → *${preview.totalDaysLeft} day(s)* total.\n\n`)
    : ''
  return ctx.reply(
    `👑 *${plan.label} Premium* — ₦${plan.priceNaira.toLocaleString()} _(${plan.durationDays} days)_\n\n` +
    forLine +
    stackLine +
    `💳 *Payment Details:*\n` +
    `  🏦 Bank: *${pay.bankName || '(not configured)'}*\n` +
    `  🔢 Account: *${pay.accountNumber || '(not configured)'}*\n` +
    `  👤 Name: *${pay.accountName || '(not configured)'}*\n\n` +
    `📸 Once paid, send a screenshot of the transfer *right here in this DM* to confirm.\n\n` +
    (recipient
      ? `_Make sure the name above is the right person — once confirmed, the gift can't be moved._`
      : `_Want to buy this for someone else? Use *${pr}premium buy ${planKey} for <username>*._`),
  )
}

async function handleConfirm(ctx) {
  if (!isOwnerJid(ctx.from)) return ctx.reply(`❌ Owner only.`)

  // `<who>` is a number or a name; `<plan>` is optional, because the pending the
  // screenshot caption points at already says which plan was bought.
  const typedPlan = ctx.args[ctx.args.length - 1]?.toLowerCase()
  const hasPlan = PLAN_KEYS.includes(typedPlan)
  const query = ctx.args.slice(1, hasPlan ? -1 : undefined).join(' ')
  const usage = `Usage: *${config.prefix}premium confirm <player name or number> [weekly|monthly|yearly]*`
  if (!query) return ctx.reply(usage)

  const found = resolvePurchaseTarget(ctx.db, query)
  if (!found) return ctx.reply(`❌ No player found matching *"${query}"*.` + pendingHelp(ctx.db, { prefix: config.prefix }))

  // The BUYER is the one whose pending record this is (the person who sent
  // the screenshot). If the pending is a gift (recipientJid is set), the
  // Premium actually lands on the RECIPIENT, not on the buyer.
  const buyer = found.player
  const buyerId = found.key
  const pending = getPending(buyer, 'premium')
  const pendingPlan = pending?.plan
  const recipientJid = pending?.recipientJid ?? null
  const recipientName = pending?.recipientName ?? null
  const isGift = Boolean(pending?.isGift && recipientJid)

  // The plan to grant: explicit typed plan first, then the pending's plan,
  // then refuse (no pending, no plan — same as before).
  const planKey = hasPlan ? typedPlan : pendingPlan
  if (!PLAN_KEYS.includes(planKey)) {
    return ctx.reply(pendingPlan
      ? `❌ Unknown plan *"${typedPlan ?? ''}"*. Their pending purchase is for *${pendingPlan}* — run *${config.prefix}premium confirm ${buyerId} ${pendingPlan}*.`
      : `${usage}\n_They have no pending Premium purchase, so say which plan to grant._`)
  }

  // Resolve the recipient: either the gift target from the pending, or the
  // buyer themself for an ordinary purchase.
  const granteeId = isGift ? recipientJid : buyerId
  const grantee = getPlayer(ctx.db, granteeId)
  if (!grantee) {
    return ctx.reply(
      `❌ The gift recipient *${recipientName ?? recipientJid}* doesn't appear to be registered yet.` +
      (pendingPlan ? `\n_The pending is for *${pendingPlan}* — ask them to register first, or run *${config.prefix}premium confirm ${buyerId} ${pendingPlan}* to grant to the buyer instead._` : ''),
    )
  }

  let giftResult = null
  let abilityResult = null
  let grantPreview = null
  await updatePlayer(ctx.db, granteeId, p => {
    grantPreview = previewPremiumGrant(p, planKey, plansData)
    grantPremium(p, planKey, plansData)
    // Bookkeeping: if this was a gift, stamp who it came from so the
    // recipient sees it on .premium status.
    if (isGift) {
      p.premium.giftedBy = buyer.name ?? 'a friend'
      p.premium.giftedByJid = buyerId
    }
    // The MONTHLY plan's whole hook: one of the 5 one-of-one premium
    // abilities, picked at random and gifted OUTRIGHT — no luck roll, no
    // spin. Premium is not a gamble for an ability; a buyer always leaves
    // with one. Claimed through the shared exclusive-spin registry INSIDE
    // this mutator so the claim persists atomically with the grant (see
    // grantMonthlyExclusiveAbility).
    if (planKey === 'monthly') {
      giftResult = grantMonthlyExclusiveAbility(ctx.db, granteeId, p)
    }
    // The floor under every buyer — weekly/yearly plans, renewals, and the
    // rare monthly buyer who arrives while all 5 one-of-ones are held —
    // leaves with Crown's Favor in their equipped slot (see
    // grantPremiumAbility). Same mutator, so the grant can never persist
    // without the premium and vice versa. NOTE: every ability granted here
    // is stripped again when Premium expires (stripPremiumAbilities, run by
    // the expiry sweep in main.js and by .premium-revoke).
    abilityResult = grantPremiumAbility(p, giftResult)
  }, { critical: true })

  // Clear the pending off the BUYER record (it's their DM that originated
  // the flow), not the grantee's. In the non-gift case buyerId === granteeId
  // so the same update clears it.
  await updatePlayer(ctx.db, buyerId, p => {
    p.premiumPending = null
  })

  const freshGrantee = getPlayer(ctx.db, granteeId)
  const giftBlock = giftResult ? `\n\n${abilityGiftLine(giftResult)}` : ''

  let abilityBlock = ''
  if (abilityResult?.granted === 'gift') {
    abilityBlock = `\n\n✨ *Ability slot:* your one-of-one ability is equipped — see it on *${config.prefix}profile*.`
  } else if (abilityResult?.granted === 'new') {
    const equippedLine = abilityResult.equipped
      ? `It's equipped in your ability slot already.`
      : `All your ability slots are full — it's in your inventory, ready to equip.`
    abilityBlock = `\n\n✨ *Ability slot:* you received *Crown's Favor* (epic passive, +3 to every stat in battle). ${equippedLine} See it on *${config.prefix}profile*.`
  } else if (abilityResult?.granted === 'already') {
    abilityBlock = `\n\n✨ *Ability slot:* *Crown's Favor* is already yours from a previous purchase.`
  }

  const expiryDateStr = new Date(freshGrantee.premium.expiresAt).toLocaleDateString()
  const totalDays = daysLeft(freshGrantee.premium.expiresAt)
  const stacked = Boolean(grantPreview?.stacked)
  const addedDays = grantPreview?.addedDays ?? plansData.plans[planKey]?.durationDays ?? 0

  const granteeHeader = isGift
    ? (stacked
      ? `🎁 *Someone gifted you +${addedDays} days of Premium!*\nFrom: *${buyer.name ?? 'a friend'}*\n`
      : `🎁 *Someone gifted you Premium!*\nFrom: *${buyer.name ?? 'a friend'}*\n`)
    : (stacked
      ? `🎉 *Premium extended! (+${addedDays} days stacked)*\n`
      : `🎉 *Premium activated!*\n`)
  const granteePlanLine = stacked
    ? `Added *+${addedDays} days* (*${planKey}*) onto your *${grantPreview.previousDaysLeft} day(s)* left → *${totalDays} day(s)* total _(expires *${expiryDateStr}*)_`
    : `Plan: *${planKey}* (*${totalDays} day(s)*) — expires *${expiryDateStr}*`

  const granteeCaption =
    granteeHeader +
    `${granteePlanLine}\n\n` +
    PERKS_LINE +
    giftBlock + abilityBlock +
    `\n\n${isGift ? 'Thank them when you see them — ' : ''}Thank you for supporting the game!`

  // Done card to the grantee (the person who now HAS Premium). This is the
  // whole reason for the isGift branch: the buyer already knows they paid;
  // the recipient needs the activation notice.
  await sendImageTo(ctx, 'payment_done.jpg', granteeCaption, granteeId).catch(() => {})

  // Buyer gets a separate DM so they know the gift landed (and so in the
  // non-gift case they still get the thank-you — same image, different
  // wording). In non-gift buyer === grantee so skip the duplicate send.
  if (isGift) {
    await ctx.sock.sendMessage(buyerId, {
      text:
        `✅ *Gift delivered!*\n\n` +
        `You sent *${planKey} Premium* (+*${addedDays} days*) to *${grantee.name}* _(${granteeId})_.\n` +
        (stacked
          ? `Stacked onto their active Premium — they now have *${totalDays} day(s)* left _(expires *${expiryDateStr}*)_.\n\n`
          : `It expires *${expiryDateStr}*.\n\n`) +
        `🎁 Thanks for gifting — they just got the activation DM.`,
    }).catch(() => {})
  }

  const ownerNote = giftResult ? ` ${giftOutcomeShort(giftResult)}` : ''
  const whoGotIt = isGift
    ? `*${planKey}* Premium to *${grantee.name}* _(gift from ${buyer.name})_`
    : `*${planKey}* Premium to *${buyer.name}*`
  const ackLead = stacked
    ? `✅ Stacked *+${addedDays}d* (${whoGotIt}) — *${grantPreview.previousDaysLeft}d → ${totalDays}d* left.`
    : `✅ Granted ${whoGotIt} (*${totalDays}d* left).`
  return ctx.reply(`${ackLead}${ownerNote}` +
    (pendingPlan && hasPlan && pendingPlan !== planKey
      ? `\n_⚠️ Their pending was for *${pendingPlan}* and has been cleared either way — re-grant that one too if this was a typo._`
      : ''))
}

async function handleReject(ctx) {
  if (!isOwnerJid(ctx.from)) return ctx.reply(`❌ Owner only.`)

  const query = ctx.args.slice(1).join(' ')
  if (!query) return ctx.reply(`Usage: *${config.prefix}premium reject <player name or number>*`)

  const found = resolvePurchaseTarget(ctx.db, query)
  if (!found) return ctx.reply(`❌ No player found matching *"${query}"*.` + pendingHelp(ctx.db, { prefix: config.prefix }))

  const target = found.player
  const pending = getPending(target, 'premium')
  await updatePlayer(ctx.db, found.key, p => { p[PURCHASE_KINDS.premium.field] = null })

  const isGift = Boolean(pending?.isGift && pending?.recipientJid)
  await ctx.sock.sendMessage(found.key, {
    text: `❌ Your Premium ${isGift ? 'gift ' : ''}purchase couldn't be confirmed. Please double-check the payment and try *${config.prefix}premium buy <plan>* again, or contact support.`,
  }).catch(() => {})

  const other = pendingKinds(getPlayer(ctx.db, found.key))
  return ctx.reply(`✅ Cleared *${target.name}*'s pending Premium purchase.` +
    (isGift ? ` _(was a gift to ${pending.recipientName ?? pending.recipientJid ?? '?'})_` : '') +
    (other.length
      ? `\n\n⚠️ They still have ${other.length} other pending purchase(s) on the same record — *${config.prefix}${PURCHASE_KINDS[other[0]].command} ${found.key}*.`
      : ''))
}

async function handleOnOff(ctx, turnOn) {
  if (!isOwnerJid(ctx.from)) return ctx.reply(`❌ Owner only.`)
  if (!ctx.isGroup) return ctx.reply(`❌ Run this inside the group you want to gate.`)

  // Save FIRST and bail if it didn't land. The premium-group list and this flag
  // have to agree: adding the group to the list after a failed settings write
  // gates the group while its saved setting says it's open, and `.premium off`
  // would then read the (unsaved) flag and think there's nothing to undo.
  const res = await saveGroupSettings(ctx.sender, s => { s.premiumOnly = turnOn; return s })
  if (!res.ok) return ctx.reply(saveFailedMessage('Premium-only gating', res.error))

  const stored = res.settings.premiumOnly === true
  if (stored) await addPremiumGroup(ctx.sender)
  else await removePremiumGroup(ctx.sender)

  return ctx.reply(
    stored
      ? `🔒 This group is now *Premium-only*. Non-premium members will be rejected (not kicked) when they try to use commands here.`
      : `🔓 Premium-only gating has been removed from this group.`,
  )
}

export default {
  name: 'premium',
  aliases: ['vip'],
  category: 'economy',
  description: `${config.prefix}premium — view/buy/gift Premium; owner-only admin subcommands`,

  async run(ctx) {
    const sub = (ctx.args[0] ?? '').toLowerCase()
    const pr  = ctx.platform === 'telegram' ? config.telegramPrefix : config.prefix

    // The manual Naira transfer + screenshot confirmation desk lives on
    // WhatsApp. Other platforms may still read their own Premium status and
    // the plan list; purchase/owner actions are handled by platform wrappers
    // or refused here so no bank details leak into a platform without a desk.
    if (ctx.platform !== 'whatsapp' && ['buy', 'confirm', 'reject', 'on', 'off'].includes(sub)) {
      return ctx.reply(
        `👑 *Premium purchases are handled on WhatsApp.* ` +
        `Use *${config.prefix}premium buy <plan>* there, then check *${pr}premium status* here.`,
      )
    }

    if (sub === 'buy')                    return handleBuy(ctx)
    if (sub === 'confirm')                return handleConfirm(ctx)
    if (sub === 'reject')                 return handleReject(ctx)
    if (sub === 'on')                     return handleOnOff(ctx, true)
    if (sub === 'off')                    return handleOnOff(ctx, false)
    if (sub === 'plans' || sub === 'list') {
      const activeNote = ctx.player && isPremiumActive(ctx.player)
        ? `👑 You currently have *${daysLeft(ctx.player.premium.expiresAt)} day(s)* of Premium left — any plan you buy adds its days right onto that.\n\n`
        : ''
      return sendImage(ctx, 'premium.jpg', `*👑 Astral Premium Plans*\n\n${activeNote}📦 *Plans:*\n${planList(pr)}`)
    }

    // Default: status view — needs a registered player.
    if (!ctx.player) {
      return ctx.reply(`⚠️ Register first with *${pr}register*, or *${pr}premium buy <plan>* still needs registration too.\n\n📦 *Plans:*\n${planList(pr)}`)
    }
    const caption = statusText(ctx.player, pr)
    const bodyLine = isPremiumActive(ctx.player)
      ? `Active plan: ${ctx.player.premium.plan}`
      : 'Weekly, monthly, and yearly plans available'
    return sendImage(ctx, 'premium.jpg', `*👑 Astral Premium*\n${bodyLine}\n\n${caption}`)
  },
}
