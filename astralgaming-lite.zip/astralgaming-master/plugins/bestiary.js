/**
 * bestiary.js — dungeon voices and monster families, and your Codex.
 *
 * Not 929 essays. One line for the place, one line for the family the name
 * already belongs to. Floor 100 is the master. The middle floors are not.
 *
 * The families are fogged by what you have fought (lib/codex.js): ??? until you
 * meet one, its lore after the first kill, its tell after 10, its epithet after
 * 50. The places themselves (the strata, the master's rumor) are not fogged:
 * only the families are. Someone with no character yet sees the whole book, with
 * a nudge that registering starts a Codex.
 */
import { config } from '../config.js'
import { locationsMap } from '../lib/game-data.js'
import { canFindPlace } from '../lib/story-perks.js'
import { DUNGEON_NAMES, entryBrief, encounterLine, familyIndex, familyOf, stratumFor } from '../lib/dungeon-lore.js'
import {
  familyLines, familyCardLines, progressLines, codexSummary, familiesIn, pageDone,
} from '../lib/codex.js'

const LORE_IDS = Object.keys(DUNGEON_NAMES)

function dungeonPage(locId, p, player = null) {
  const loc = locationsMap[locId]
  const name = loc?.name ?? DUNGEON_NAMES[locId] ?? locId
  const families = familyIndex().filter(f => f.locId === locId)
  const sealed = player && pageDone(player, locId)
  const lines = [
    `📖 *${name.toUpperCase()}*${sealed ? '  ✅ _surveyed_' : ''}`,
    loc?.description ? `_${loc.description}_` : '',
    '',
  ]
  const low = stratumFor(locId, 1)
  const high = stratumFor(locId, Math.max(1, (loc?.floors ?? 90) - 1))
  if (low) lines.push(`*Low:* ${low.name}. ${low.line}`)
  if (high && high !== low) lines.push(`*High:* ${high.name}. ${high.line}`)
  const brief = loc ? entryBrief(loc, 1, false) : ''
  if (brief) lines.push('', brief)
  if (families.length) {
    const s = player ? codexSummary(player).byDungeon.find(d => d.locId === locId) : null
    lines.push('', s ? `*Families*  ·  ${s.met} of ${s.total} met` : `*Families*`)
    if (player) {
      lines.push(...familyLines(player, locId, p))
    } else {
      for (const family of families) {
        lines.push(`  • *${family.words[0]}*: ${family.line}`)
      }
    }
  }
  lines.push('', `*${p}bestiary* for the other places.`)
  return lines.filter(Boolean).join('\n')
}

export default {
  name: 'bestiary',
  aliases: ['beastiary', 'families'],
  category: 'dungeon',
  requiresPlayer: false,
  description: 'What the towers feel like, and the families that walk them',
  subcommands: [
    { cmd: '<dungeon or family>', desc: 'a place, or a family word like slime or wraith' },
  ],

  async run(ctx) {
    const p = config.prefix
    const query = ctx.args.join(' ').trim().toLowerCase()

    // Someone with a character has a Codex. Someone without one sees the whole book.
    const player = ctx.player ?? null

    if (!query) {
      const lines = [
        `📖 *BESTIARY*`,
        `_One voice per tower. One line per family. The master is the last floor, not every tenth._`,
        '',
      ]
      for (const id of LORE_IDS) {
        lines.push(`  • *${DUNGEON_NAMES[id]}*  ·  *${p}bestiary ${id}*`)
      }
      lines.push('', `_Or name a family: *${p}bestiary slime*_`)
      if (player) {
        lines.push('', ...progressLines(player, p))
        lines.push(`_Families stay *???* until you fight one. 1 kill opens its lore, 10 its tell, 50 its epithet._`)
      } else {
        lines.push('', `_Register and your Codex starts filling in as you fight._`)
      }
      return ctx.reply(lines.join('\n'))
    }

    const compact = query.replace(/\s+/g, '_')
    // DUNGEON_NAMES deliberately does NOT list the off-the-map places (it is
    // the bestiary's index, and an index would give them away), so a page can
    // only be reached by naming one outright. That lookup is gated the same way
    // every other surface is: a place you cannot find has no page to read.
    const known = DUNGEON_NAMES[compact] || (locationsMap[compact] && canFindPlace(player, locationsMap[compact]))
    if (known) {
      return ctx.reply(dungeonPage(compact, p, player))
    }
    const byName = LORE_IDS.find(id => (DUNGEON_NAMES[id] ?? '').toLowerCase().includes(query))
    if (byName) return ctx.reply(dungeonPage(byName, p, player))

    const families = familyIndex().filter(f => f.words.some(w => w.includes(query) || query.includes(w)))
    if (families.length) {
      const lines = [`📖 *${query.toUpperCase()}*`, '']
      for (const family of families) {
        if (player) {
          lines.push(...familyCardLines(player, { ...family, key: `${family.locId}:${family.words[0]}`, word: family.words[0] }, p))
        } else {
          lines.push(`*${family.dungeon}*`)
          lines.push(family.line)
        }
        lines.push('')
      }
      return ctx.reply(lines.join('\n').trim())
    }

    // A full monster name still gets its family if one matches.
    for (const id of LORE_IDS) {
      const fam = familyOf(id, query)
      if (!fam) continue
      if (player) {
        return ctx.reply(`📖 *${query}*\n${familyCardLines(player, fam, p).join('\n')}`)
      }
      return ctx.reply(`📖 *${query}*\n_${DUNGEON_NAMES[id]}_\n\n${fam.line}`)
    }

    return ctx.reply(
      `❓ Nothing in the book under *${query}*.\n` +
      `*${p}bestiary* lists the towers.`,
    )
  },
}
