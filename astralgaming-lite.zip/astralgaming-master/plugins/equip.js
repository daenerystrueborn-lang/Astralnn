import { gearRefusal } from '../lib/survival-progression.js'
/**
 * <prefix>equip <item id or partial name>  (alias: attune)
 * Equips a non-consumable item from inventory into its matching slot.
 * If the slot is already occupied, the old item is returned to inventory
 * first. Equipping/unequipping folds the item's statBonuses in/out of
 * player.stats (and maxHp/maxMp) directly.
 */

import { config } from '../config.js'
import { createRequire } from 'node:module'
import { allItems } from '../lib/game-data.js'
import { updatePlayer } from '../lib/player-repo.js'
import { applyEquipmentBonus } from '../lib/combat-engine.js'
import { initDurability, clearDurability } from '../lib/durability.js'
// Tutorial hook — fires when a weapon is equipped
import { recordTutorialEvent, tutorialNotice } from '../lib/tutorial-engine.js'

const itemMap = Object.fromEntries(allItems.map((i) => [i.id, i]))
const require = createRequire(import.meta.url)
const pokemonHeldItems = require('../data/pokemon-items.json').filter(i => i.category === 'held')

function findPokemonHeldItem(query) {
  const q = String(query ?? '').toLowerCase().trim()
  if (!q) return null
  const withPrefix = q.startsWith('poke_') ? q : `poke_${q.replace(/\s+/g, '_')}`
  return pokemonHeldItems.find(item => item.id === q || item.id === withPrefix)
    ?? pokemonHeldItems.find(item => item.name.toLowerCase().includes(q))
    ?? null
}

function pokemonHeldItemHint(item) {
  return (
    `ℹ️ *${item.name}* is a Pokémon held item, not a Kingdom gear slot. ` +
    `Equip it with *${config.prefix}party hold <Pokémon> ${item.id}*. ` +
    `Browse with *${config.prefix}p-shop held*; buy it with *${config.prefix}p-shop buy ${item.id}*.`
  )
}

/** Find first matching item id in the player's inventory (exact id or partial name). */
function findInInventory(inventory, query) {
  const q = query.toLowerCase()
  // Exact id match.
  if (inventory.includes(q)) return q
  // Partial name match.
  for (const id of inventory) {
    const item = itemMap[id]
    if (item && item.name.toLowerCase().includes(q)) return id
  }
  return null
}

// ── The Sect Empire's own gear ────────────────────────────────────────────
// A player standing in the Sect Empire equips ARTIFACTS, out of their Sect bag
// and into their own four slots. Astra Kingdom's equipment is untouched: the
// module answers false for every other world, and nothing on the sect side
// reads an Astral inventory.
import { runSectEquip } from '../lib/sect-item-commands.js'

export default {
  name: 'equip',
  aliases: ['attune', 'switch', 'wield'],
  category: 'inventory',
  description: `${config.prefix}equip <item> — equip a weapon, offhand (shield), armor, or relic.`,
  requiresPlayer: true,

  async run(ctx) {
    const { player, args, db } = ctx

    if (await runSectEquip(ctx)) return

    if (!args || args.length === 0) {
      return ctx.reply(`Usage: *${config.prefix}equip <item id or name>*`)
    }

    const query = args.join(' ')
    const foundId = findInInventory(player.inventory ?? [], query)
    const pokemonHeldItem = findPokemonHeldItem(query)

    if (!foundId) {
      if (pokemonHeldItem) return ctx.reply(pokemonHeldItemHint(pokemonHeldItem))
      return ctx.reply(
        `❌ *"${query}"* not found in your inventory.\n` +
        `Use *${config.prefix}inventory* to see what you're carrying.`,
      )
    }

    const item = itemMap[foundId]
    if (!item) {
      if (pokemonHeldItem) return ctx.reply(pokemonHeldItemHint(pokemonHeldItem))
      return ctx.reply(`❌ Item data for *${foundId}* is missing. Please report this bug.`)
    }

    if (item.type === 'consumable') {
      return ctx.reply(
        `❌ *${item.name}* is a consumable — it can't be equipped.\n` +
        `Use *${config.prefix}use ${foundId}* to consume it instead.`,
      )
    }

    if (item.type === 'material') {
      return ctx.reply(
        `❌ *${item.name}* is a crafting material — visit the forge to use it, it can't be equipped.`,
      )
    }

    // Shields and relics share one physical offhand. Normalize old item data
    // that may still call this slot `relic` before reading or writing equipment.
    const slot = item.slot === 'relic' ? 'offhand' : item.slot
    if (!slot) {
      return ctx.reply(`❌ Don't know how to equip item type "${item.type}". This is a bug.`)
    }

    if (player.level < item.levelReq) {
      return ctx.reply(
        `❌ You need to be *level ${item.levelReq}* to equip *${item.name}*.\n` +
        `You are currently level ${player.level}.`,
      )
    }

    const attunementError = gearRefusal(player, item)
    if (attunementError) return ctx.reply(attunementError)

    // Perform the equip via updatePlayer to prevent stale-write races.
    const replacedNames = []
    let raceAborted = false
    const targetSlots = item.fullArmorSuit
      ? (item.suitSlots ?? ['helmet', 'chestplate', 'boots'])
      : [slot]

    await updatePlayer(db, player.id, (p) => {
      if (gearRefusal(p, item)) { raceAborted = true; return }
      const inv = p.inventory ?? []
      const equipped = p.equipped ?? {}

      // Re-validate against fresh inventory before mutating.
      const idx = inv.indexOf(foundId)
      if (idx === -1) {
        raceAborted = true
        return // item no longer present — abort without mutation
      }

      // Determine all slots that must be vacated. If any target slot currently
      // holds a full-armor suit (e.g. Black Armor of Napoleon), vacate all of
      // that suit's slots together as one unit.
      const slotsToClear = new Set(targetSlots)
      if (slot === 'offhand') slotsToClear.add('relic')
      for (const s of [...slotsToClear]) {
        const curId = equipped[s]
        const curItem = curId ? itemMap[curId] : null
        if (curItem?.fullArmorSuit) {
          for (const suitSlot of (curItem.suitSlots ?? ['helmet', 'chestplate', 'boots'])) {
            slotsToClear.add(suitSlot)
          }
        }
      }

      const returnedFullSuitIds = new Set()
      const returnedOffhandIds = new Set()
      for (const s of slotsToClear) {
        const existing = equipped[s]
        if (!existing) continue
        const oldItem = itemMap[existing]
        if (oldItem?.fullArmorSuit) {
          if (!returnedFullSuitIds.has(existing)) {
            returnedFullSuitIds.add(existing)
            applyEquipmentBonus(p, oldItem, -1)
            replacedNames.push(oldItem.name ?? existing)
            inv.push(existing)
          }
        } else if (s === 'offhand' || s === 'relic') {
          if (!returnedOffhandIds.has(existing)) {
            returnedOffhandIds.add(existing)
            if (oldItem) applyEquipmentBonus(p, oldItem, -1)
            replacedNames.push(oldItem?.name ?? existing)
            inv.push(existing)
          }
        } else {
          if (oldItem) applyEquipmentBonus(p, oldItem, -1)
          replacedNames.push(oldItem?.name ?? existing)
          inv.push(existing)
        }
        equipped[s] = null
        if (s !== 'relic') clearDurability(p, s)
      }

      // Remove one instance of the new item from inventory, equip it, and
      // apply its stat bonuses (once for a full-armor suit).
      const removeIdx = inv.indexOf(foundId)
      if (removeIdx !== -1) inv.splice(removeIdx, 1)

      if (item.fullArmorSuit) {
        for (const s of targetSlots) {
          equipped[s] = foundId
          clearDurability(p, s)
        }
        applyEquipmentBonus(p, item, +1)
      } else {
        equipped[slot] = foundId
        if (slot === 'offhand') equipped.relic = null
        applyEquipmentBonus(p, { ...item, slot }, +1)
        initDurability(p, slot, foundId)
      }

      p.inventory = inv
      p.equipped  = equipped
    })

    if (raceAborted) {
      return ctx.reply(
        `❌ *${item.name}* is no longer in your inventory. Inventory state changed — please try again.`,
      )
    }

    // ── Tutorial hook: weapon equipped ──────────────────────────────
    let tutorialResult = null
    if (slot === 'weapon') {
      await updatePlayer(db, player.id, p => {
        tutorialResult = recordTutorialEvent(p, 'weapon_equipped')
        return p
      })
    }

    const swapLine = replacedNames.length
      ? `\n↩️ *${replacedNames.join(', ')}* returned to your inventory.`
      : ''

    if (item.fullArmorSuit) {
      return ctx.reply(
        `🖤 You equipped *${item.name}* as a full armor suit!${swapLine}\n` +
        `Slots: ${targetSlots.join(', ')} _(Unified Armor · Unbreakable)_ — use *${config.prefix}armor* or *${config.prefix}profile* to see your full loadout.`,
      )
    }

    return ctx.reply(
      `⚔️ You equipped *${item.name}*!${swapLine}\n` +
      `Slot: ${slot} — use *${config.prefix}profile* to see your full loadout.` +
      (tutorialResult ? `\n\n${tutorialNotice(tutorialResult, config.prefix)}` : ''),
    )
  },
}
