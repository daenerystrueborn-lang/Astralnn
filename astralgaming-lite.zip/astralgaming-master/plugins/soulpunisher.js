/**
 * soulpunisher.js — Gogeta's Soul Punisher, the cheap half of his kit.
 *
 * A ranged ki blast: medium damage (SOUL_PUNISHER_MULT), no MP, no weapon
 * wear (nothing in his hand touches anything), and a two-turn cooldown that
 * Instant Transmission sometimes refuses to start. Everything about whether
 * it is allowed to fire lives in activateSoulPunisher() in lib/gogeta.js; this
 * plugin owns the turn.
 *
 * The turn is the same shape as plugins/purple.js — status tick, the blast,
 * boss-engine hooks, then the enemy's counter-attack and bs.turn++ — with two
 * differences from Hollow Purple:
 *
 *   1. DEF APPLIES. This is a normal hit, just a strong one, so the multiplier
 *      goes through applyDefense() like an ordinary attack.
 *   2. IT NEVER MISSES. There is no accuracy roll, for the same reason no
 *      character move in the bot has one: the charge is already spent by the
 *      time the roll would happen, and eating a two-turn cooldown on a whiff
 *      reads as the command being broken. Crit still rolls, out of
 *      calcPlayerDamage().
 *
 * No art. The user's brief puts the standing image on standard displays
 * (profile, spin result, idle) and reserves the Kamehameha image for the
 * ultimate, so a basic ki blast firing every other turn stays plain text.
 *
 * PvP: hands off to pvp.js's pvpSoulPunisher() ('soulpunisher' action there),
 * since this plugin only knows the PvE battleState shape (bs.enemy).
 *
 * Usage: <prefix>soulpunisher
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import {
  calcPlayerDamage, applyDefense,
  calcMonsterHitChance, calcMonsterDamage, hpBar,
} from '../lib/combat-engine.js'
import {
  handleVictory,
  processStatusTurn,
  resolvePlayerHpZero,
  checkCatFormOngoingTurn,
  resolveCatFormDefeat,
} from '../lib/combat-handlers.js'
import { getEffectiveStat } from '../lib/effects.js'
import {
  applyBossSpecial, checkBossPhase, buildEnemyAttack,
  getBossTaunt, getBossHitLine,
  incrementBossTurn, cleanupBossFight, EVENT,
} from '../lib/boss-engine.js'
import {
  activateSoulPunisher,
  fusionTurnsLeft,
  applyTearOnHit,
  sendWillowAdvisory,
  tickPermanentSever,
  applyIncomingDamage,
} from '../lib/character-abilities.js'
import { pvpSoulPunisher } from './pvp.js'
import { playLeagueMove } from './league-battle.js'
import { resolveSwarmAbility } from '../lib/swarm-combat.js'
import { sendBattleTurnReply } from '../lib/battle-frame-render.mjs'
import { heroesAnswerHit, heroesTurnBoundary } from '../lib/witch-heroes-pve.js'
import { graceHoldsEnemyTurn, graceEnemyHeldLine } from '../lib/king-yato.js'

function isBossFight(player) {
  return !!(player.battleState?.enemy?.isBoss && player.battleState?.bossState)
}

export default {
  name: 'soulpunisher',
  // No 'sp' alias: plugins/skill.js already owns it, and it loads first, so
  // claiming it here would silently shadow nothing and just confuse.
  aliases: ['soulpunish', 'soul-punisher', 'punisher', 'spunisher', 'kiblast'],
  category: 'combat',
  requiresPlayer: true,
  description: `${config.prefix}soulpunisher: Gogeta's ranged ki blast (no MP, short cooldown)`,

  async run(ctx) {
    const p = config.prefix

    // ── Astral League fixture ─────────────────────────────────────────
    // A fixture plays this through the League path: the same runPvpTurn()
    // action as the duel handoff below, plus the turn limit, the stand in
    // answer and the table. BEFORE the duel handoff and before updatePlayer():
    // playLeagueMove() sends and writes, and neither is safe inside a mutator.
    if (await playLeagueMove(ctx, 'soulpunisher', '')) return

    // In a duel this hands off to the PvP turn engine: this plugin only knows
    // the PvE battleState shape (bs.enemy).
    if (ctx.player?.battleState?.type === 'pvp') {
      return pvpSoulPunisher(ctx)
    }

    await updatePlayer(ctx.db, ctx.from, async player => {
      const catTurn = await checkCatFormOngoingTurn(player, ctx, {
        boss: isBossFight(player),
      })
      if (catTurn.intercepted) return catTurn.returnValue

      const gate = activateSoulPunisher(player)
      if (!gate.ok) {
        if (gate.message) await ctx.reply(gate.message)
        return player
      }

      // Swarm floors: fold the blast into ONE swarm turn against the nearest
      // threat, the same shape kurama.js/kurohitsugi.js/puppetry.js use. Without
      // this branch the 1v1 turn below ran against bs.enemy and a kill called
      // handleVictory while other monsters were still alive, wiping the pack for
      // free. The cooldown is already burned by the gate above, so the charge is
      // spent exactly once either way, and a non-final kill pays through the
      // shared swarm branch.
      if (player.battleState?.mode === 'swarm') {
        return resolveSwarmAbility(player, ctx, (target) => {
          const { rawDmg, isCrit } = calcPlayerDamage(player, null, gate.multiplier)
          let dmg = Math.max(1, Math.round(applyDefense(rawDmg, getEffectiveStat(target, 'def'), player, target)))
          target.hp = Math.max(0, target.hp - dmg)
          const fusionLeft = fusionTurnsLeft(player, player.battleState)
          const lines = [
            `🔵 *SOUL PUNISHER*`,
            `─────────────`,
            `_Gogeta puts a hand out, and a point of ki the size of a fist crosses the distance to *${target.name}* before the sound does._`,
            ``,
          ]
          if (gate.extra) lines.push(gate.extra)
          lines.push(`💠 *${dmg.toLocaleString()}* damage!${isCrit ? ' 💥 *CRITICAL!*' : ''}`)
          if (fusionLeft > 0) lines.push(`_Fusion of Equals: ${fusionLeft} turn${fusionLeft === 1 ? '' : 's'} left._`)
          return { lines }
        })
      }

      // CHUNK_MARKER_SP_TURN
      const bs   = player.battleState
      const e    = bs.enemy
      const boss = isBossFight(player)
      const hpBeforeTurn  = player.hp
      const eHpBeforeTurn = e.hp

      bs.playerDefending = false
      let msg = ''

      // Urahara's permanent Tear — action-triggered tick, same as every
      // other combat entry point. (No-op unless Urahara is equipped.)
      const permaSeverLine = tickPermanentSever(player)
      if (permaSeverLine) msg += permaSeverLine + '\n'
      if (player.hp <= 0) {
        const res = await resolvePlayerHpZero(player, ctx, msg, {})
        if (!res.fallThrough) return res.returnValue
        msg = res.msg
      }

      if (boss) {
        incrementBossTurn(player)
        const tsResult = applyBossSpecial(player, EVENT.TURN_START, {})
        if (tsResult.narrativeLine) msg += `_${tsResult.narrativeLine}_\n`
      }

      // processStatusTurn also ticks the fusion clock (see lib/combat-handlers.js),
      // so the countdown and the break both narrate themselves from here.
      const playerStatus = processStatusTurn(player)
      if (playerStatus.incapacitated && player.battleState?.enemy?.tower) player.battleState.towerTacticIncapacitatedTurn = player.battleState.turn ?? 1
      if (!playerStatus.incapacitated && player.hp > 0 && player.battleState?.bossState?._def?.orv) applyBossSpecial(player, EVENT.PLAYER_ABILITY, {})
      if (playerStatus.lines.length) msg += playerStatus.lines.join('\n') + '\n'
      if (player.hp <= 0) {
        const res = await resolvePlayerHpZero(player, ctx, msg, { boss })
        if (!res.fallThrough) return res.returnValue
        msg = res.msg
      }

      const fusionLeft = fusionTurnsLeft(player, bs)
      msg +=
        `🔵 *SOUL PUNISHER*\n` +
        `─────────────\n` +
        `_Gogeta puts a hand out, and a point of ki the size of a fist crosses the distance to *${e.name}* before the sound does._\n\n`
      if (gate.extra) msg += gate.extra + '\n'
      // CHUNK_MARKER_SP_DAMAGE
      if (playerStatus.incapacitated) {
        msg += `💫 *${player.name}* is unable to act this turn!\n`
      } else {
        const { rawDmg, isCrit } = calcPlayerDamage(player, null, gate.multiplier)
        let dmg = Math.max(1, Math.round(applyDefense(rawDmg, getEffectiveStat(e, 'def'), player, e)))
        if (boss) {
          const takeResult = applyBossSpecial(player, EVENT.ENEMY_TAKE_DAMAGE, {
            damage: dmg, isCrit, isHit: true,
          })
          if (takeResult.damage !== undefined) dmg = takeResult.damage
          if (takeResult.reflectDamage) {
            const reflected = applyIncomingDamage(player, takeResult.reflectDamage)
            if (reflected.message) msg += reflected.message + '\n'
            if (reflected.catFormDefeated) return resolveCatFormDefeat(player, ctx, { boss })
            if (player.hp <= 0) {
              const resolved = await resolvePlayerHpZero(player, ctx, msg, { boss: true })
              if (!resolved.fallThrough) return resolved.returnValue
              msg = resolved.msg
            }
          }
          if (takeResult.narrativeLine) msg += `_${takeResult.narrativeLine}_\n`
          msg += `💬 _"${getBossHitLine(player)}"_\n`
        }
        e.hp = Math.max(0, e.hp - dmg)

        msg += `💠 *${dmg.toLocaleString()}* damage!${isCrit ? ' 💥 *CRITICAL!*' : ''}\n`
        if (fusionLeft > 0) msg += `_Fusion of Equals: ${fusionLeft} turn${fusionLeft === 1 ? '' : 's'} left._\n`

        if (e.hp > 0) {
          const tearLine = applyTearOnHit(player, e, ctx)
          if (tearLine) msg += tearLine + '\n'
        }



        if (e.hp <= 0) {
          if (boss) cleanupBossFight(player)
          return handleVictory(player, e, ctx)
        }

        if (boss) {
          const phase = checkBossPhase(player)
          if (phase?.triggered && phase.lines?.length) {
            msg += `\n⚡ *— PHASE SHIFT —*\n` + phase.lines.map(l => `_${l}_`).join('\n') + '\n'
          }
        }
      }

      const enemyStatus = processStatusTurn(e, { bossState: player.battleState?.bossState })
      if (enemyStatus.lines.length) msg += enemyStatus.lines.join('\n') + '\n'
      if (e.hp <= 0) {
        if (boss) cleanupBossFight(player)
        return handleVictory(player, e, ctx)
      }
      // CHUNK_MARKER_SP_COUNTER
      // 👑 King Yato — Grace of the Crown: turns 1-5 the enemy does not act at all.
      if (graceHoldsEnemyTurn(player)) {
        msg += `\n${graceEnemyHeldLine(e, player)}\n`
      } else if (enemyStatus.incapacitated) {
        msg += `💫 *${e.name}* is unable to attack this turn!\n`
      } else if (boss) {
        const bossAtk    = buildEnemyAttack(player)
        const dealResult = applyBossSpecial(player, EVENT.ENEMY_DEAL_DAMAGE, { damage: bossAtk.damage, isHit: true })
        const rawBossAtk = (dealResult.modified && dealResult.damage !== undefined) ? dealResult.damage : bossAtk.damage
        const incoming   = bossAtk.bypassDefense
          ? rawBossAtk
          : calcMonsterDamage(rawBossAtk, getEffectiveStat(player, 'def'), false)
        const witchHit = heroesAnswerHit({ player, enemy: e, ctx, msg: '', damage: incoming, directAttack: true, boss: boss })
        if (witchHit.returnValue !== undefined) return witchHit.returnValue
        if (witchHit.lines.length) msg += witchHit.lines.map(l => l + '\n').join('')
        const applied = applyIncomingDamage(player, witchHit.damage)
        if (applied.message) msg += applied.message + '\n'
        msg += `\n${e.emoji ?? '👾'} *${e.name}* uses *${bossAtk.attackName}*!\n`
        if (!witchHit.turned) msg += `🩸 *${applied.damage}* damage!${bossAtk.bypassDefense ? ' _(bypasses DEF)_' : ''}\n`
        if (dealResult.narrativeLine) msg += `_${dealResult.narrativeLine}_\n`
        msg += `\n💬 _"${getBossTaunt(player)}"_\n`
        if (applied.catFormDefeated) {
          return resolveCatFormDefeat(player, ctx, { boss: true })
        }
        if (player.hp <= 0) {
          const res = await resolvePlayerHpZero(player, ctx, msg, { boss: true })
          if (!res.fallThrough) return res.returnValue
          msg = res.msg
        }
      } else if (Math.random() > calcMonsterHitChance(e, player)) {
        msg += `\n${e.emoji ?? '👾'} *${e.name}* retaliates... and *MISSES!*`
      } else {
        const enemyDmg = calcMonsterDamage(e.atk, getEffectiveStat(player, 'def'), false)
        const witchHit = heroesAnswerHit({ player, enemy: e, ctx, msg: '', damage: enemyDmg, directAttack: true, boss: boss })
        if (witchHit.returnValue !== undefined) return witchHit.returnValue
        if (witchHit.lines.length) msg += witchHit.lines.map(l => l + '\n').join('')
        const applied = applyIncomingDamage(player, witchHit.damage)
        if (applied.message) msg += applied.message + '\n'
        if (!witchHit.turned) msg += `\n${e.emoji ?? '👾'} *${e.name}* retaliates!\n🩸 *${applied.damage}* damage!`
        if (applied.catFormDefeated) {
          return resolveCatFormDefeat(player, ctx)
        }
        if (player.hp <= 0) {
          const res = await resolvePlayerHpZero(player, ctx, msg, {})
          if (!res.fallThrough) return res.returnValue
          msg = res.msg
        }
      }

      if (boss) {
        const teResult = applyBossSpecial(player, EVENT.TURN_END, {})
        if (teResult.narrativeLine) msg += `\n_${teResult.narrativeLine}_`
      }

      msg += `\n\n👤 *${player.name}*\n❤️ ${hpBar(player.hp, player.maxHp)}  💧 ${player.mp}/${player.maxMp} MP\n` +
             `${e.emoji ?? '👾'} *${e.name}*\n❤️ ${hpBar(e.hp, e.maxHp)}\n\n` +
             `*${p}attack* · *${p}soulpunisher* · *${p}kamehameha* · *${p}defend* · *${p}flee*`

      // The shared completed-turn clock (lib/witch-heroes-pve.js): Ronova's count,
      // Maiden's charge, the countdown's narration, and the settle for a beam that ends
      // it. A turn that skips this is a turn the kit never saw, which is precisely how
      // "she does nothing in a dungeon" gets reported.
      const witchTurn = await heroesTurnBoundary({ player, enemy: e, ctx, msg, turnId: bs.turn ?? 1, boss: boss })
      if (witchTurn.returnValue !== undefined) return await witchTurn.returnValue
      msg = witchTurn.msg
      bs.turn = (bs.turn ?? 1) + 1
      player.battleState = bs
      await sendWillowAdvisory(ctx, player, e, boss)

      // The battle screen (lib/battle-frame-render.mjs), the same arena art
      // every other dungeon, boss and League fight draws on. The move is
      // scripted as a skill so the frame plays his casting pose and stamps the
      // damage it just dealt; lastAction is passed explicitly because nothing
      // about "SOUL PUNISHER" matches the text the 1v1 heuristic looks for.
      const dealt = Math.max(0, Math.round(eHpBeforeTurn - e.hp))
      await sendBattleTurnReply(ctx, {
        bs, player, e, msg, hpBeforeTurn, eHpBeforeTurn, boss, isDungeon: true,
        lastAction: playerStatus.incapacitated
          ? null
          : { actor: 'left', kind: 'skill', damage: dealt, skillName: 'Soul Punisher' },
      })
      return player
    })
  },
}
