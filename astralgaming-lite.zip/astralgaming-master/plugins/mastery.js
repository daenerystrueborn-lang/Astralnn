/**
 * mastery — weapon-type mastery levels and Solar-funded training (G1).
 * Usage:
 *   .mastery                    — your mastery across weapon families
 *   .mastery train <family>     — spend Solars to train one family
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import {
  formatMastery, trainMastery, trainCost,
} from '../lib/weapon-mastery.js'
import { recordSink } from '../lib/economy-ledger.js'

export default {
  name: 'mastery',
  aliases: ['weaponmastery'],
  category: 'combat',
  requiresPlayer: true,
  description: 'View weapon mastery or train a weapon family with Solars',

  async run(ctx) {
    const p = config.prefix
    const sub = (ctx.args?.[0] ?? '').toLowerCase().trim()

    if (sub === 'train') {
      const family = (ctx.args?.[1] ?? '').toLowerCase().trim()
      if (!family) return ctx.reply(`Usage: \`${p}mastery train <family>\``)
      let reply
      await updatePlayer(ctx.db, ctx.from, (player) => {
        const cost = trainCost(player, family)
        const r = trainMastery(player, family)
        if (!r.ok) {
          reply = r.reason === 'unknown_family' ? '❌ Unknown weapon family.'
            : r.reason === 'maxed' ? '❌ That family is already at max mastery.'
            : `❌ You need ${r.cost?.toLocaleString() ?? cost?.toLocaleString()} Solars to train.`
          return player
        }
        recordSink(ctx.db, 'mastery_training', { solars: r.cost })
        reply = `⚔️ *${family}* mastery trained${r.leveledUp ? ` — **LEVEL ${r.level}!**` : ''} (${r.cost.toLocaleString()} Solars spent)`
        return player
      })
      return ctx.reply(reply)
    }

    let text = ''
    await updatePlayer(ctx.db, ctx.from, (player) => {
      text = formatMastery(player, p)
      return player
    })
    return ctx.reply(text)
  },
}
