/**
 * spectate — watch a live PVP duel from any group or DM.
 *
 * Usage:
 *   .spectate               — Audrey Hall's Justice of the Mind in her duel
 *   .spectate @player       — start watching a player's active duel
 *   .spectate stop          — stop spectating
 *   .spectate status        — show what you're currently watching
 *   .spectate privacy on    — opt out of being spectated
 *   .spectate privacy off   — allow others to spectate your duels (default)
 *   .spectate list          — (owner) list all active spectacles
 */
import { config } from '../config.js'
import { getPlayer, updatePlayer } from '../lib/player-repo.js'
import {
  registerSpectacle,
  setSpectacleMessageKey,
  removeSpectacle,
  getSpectacle,
  isSpectating,
  isPrivatePlayer,
  formatSpectatorIntro,
  totalSpectatorCount,
} from '../lib/spectator-engine.js'
import { ensurePvp, ratingOf, rankFor } from '../lib/pvp-engine.js'
import { hasAudrey } from '../lib/audrey.js'
import { LEAGUE_BLOCKED_MSG } from '../lib/league/league-block.js'
import { pvpSpectate } from './pvp.js'

export default {
  name: 'spectate',
  aliases: ['watch', 'view'],
  category: 'pvp',
  requiresPlayer: true,
  description: 'Watch a duel, or use Audrey Hall\'s Justice of the Mind in PvP',
  subcommands: [
    { cmd: '@player', desc: 'start watching a player\'s active duel' },
    { cmd: 'stop', desc: 'stop spectating' },
    { cmd: 'status', desc: 'show what you\'re watching' },
    { cmd: 'privacy on|off', desc: 'control whether others can watch your duels' },
  ],

  async run(ctx) {
    const p = config.prefix
    const sub = (ctx.args?.[0] ?? '').toLowerCase().trim()
    const player = getPlayer(ctx.db, ctx.from) ?? ctx.player
    const bare = !sub && !ctx.mentioned?.[0] && !ctx.replyTo?.sender
    const audreyCommand = bare && (!ctx.cmd || ctx.cmd === 'spectate')

    // During a compulsory League fixture, do not let this shared command's
    // watcher/privacy operations bypass the default-deny League gate.
    if (player?.inBattle && player.battleState?.league) {
      if (!audreyCommand) return ctx.reply(LEAGUE_BLOCKED_MSG)
      if (!hasAudrey(player)) return ctx.reply('👁️ *Justice of the Mind* belongs to Audrey Hall. Equip her first.')
      if (player.battleState.justiceOfTheMind?.used) return pvpSpectate(ctx)
      const { playLeagueMove } = await import('./league-battle.js')
      if (await playLeagueMove(ctx, 'spectate')) return
      return ctx.reply('🏟️ _This League fixture is not available to play right now._')
    }
    // Only a bare .spectate while Audrey is in a duel is her ability. Mentions,
    // replies, stop, status and privacy retain their original watcher meanings.
    if (audreyCommand && hasAudrey(player) && player?.inBattle && player.battleState?.type === 'pvp') {
      return pvpSpectate(ctx)
    }

    // ── .spectate stop ──────────────────────────────────────────────────
    if (sub === 'stop' || sub === 'leave') {
      if (!isSpectating(ctx.from)) {
        return ctx.reply('👁️ You are not currently spectating any duel.')
      }
      removeSpectacle(ctx.from)
      return ctx.reply('👁️ Stopped spectating.')
    }

    // ── .spectate status ────────────────────────────────────────────────
    if (sub === 'status' || sub === 'info') {
      const session = getSpectacle(ctx.from)
      if (!session) {
        return ctx.reply(
          `👁️ You are not spectating any duel.\n\n` +
          `_Use ${p}spectate @player to watch someone's active duel._`,
        )
      }
      return ctx.reply(
        `👁️ *Currently Spectating*\n\n` +
        `⚔️ *${session.playerA.name}* vs *${session.playerB.name}*\n` +
        `Watching since: ${new Date(session.startedAt).toLocaleTimeString()}`,
      )
    }

    // ── .spectate privacy on|off ────────────────────────────────────────
    if (sub === 'privacy') {
      const val = (ctx.args[1] ?? '').toLowerCase().trim()
      if (!['on', 'off'].includes(val)) {
        return ctx.reply(
          `Usage: *${p}spectate privacy on|off*\n\n` +
          `*on* — nobody can spectate your duels\n` +
          `*off* — others can watch your duels (default)`,
        )
      }
      await updatePlayer(ctx.db, ctx.from, player => {
        player.spectatePrivacy = val === 'on' ? 'private' : 'public'
        return player
      })
      return ctx.reply(
        val === 'on'
          ? '🔒 Your duels are now private. Nobody can spectate you.'
          : '🔓 Your duels are now public. Others can spectate your fights.',
      )
    }

    // ── .spectate list (owner only) ─────────────────────────────────────
    if (sub === 'list') {
      const { isOwnerJid } = await import('../lib/group-helpers.js')
      if (!isOwnerJid(ctx.sender)) {
        return ctx.reply('🔒 Only the bot owner can list all spectacles.')
      }
      const count = totalSpectatorCount()
      if (!count) return ctx.reply('👁️ No active spectacles.')
      return ctx.reply(`👁️ *${count}* active spectator(s) across all duels.`)
    }

    // ── .spectate @player ───────────────────────────────────────────────
    // The target is either a @mention, a reply, or a jid/number argument
    const mentioned = ctx.mentioned?.[0] ?? ctx.replyTo?.sender ?? null
    const rawArg = (ctx.args[0] ?? '').trim()

    if (!mentioned && !rawArg) {
      return ctx.reply(
        `👁️ *Spectate a Live Duel*\n\n` +
        `Usage: *${p}spectate @player*\n\n` +
        `Watch someone's active PVP duel from anywhere.\n` +
        `The message updates live as the fight progresses.\n` +
        `_With Audrey Hall equipped in a duel, bare *${p}spectate* uses Justice of the Mind instead._\n\n` +
        `*Other commands:*\n` +
        `• *${p}spectate stop* — stop watching\n` +
        `• *${p}spectate privacy on* — hide your duels from spectators`,
      )
    }

    // Resolve target player
    const targetJid = mentioned ?? rawArg.replace(/[^0-9@s.]/g, '')
    if (!targetJid) {
      return ctx.reply('❌ Could not identify the target player.')
    }

    // Check if target is in a PVP battle
    const target = await getPlayer(ctx.db, targetJid)
    if (!target) {
      return ctx.reply('❌ That player is not registered.')
    }

    if (!target.battleState || target.battleState.type !== 'pvp') {
      return ctx.reply(`❌ *${target.name}* is not currently in a PVP duel.`)
    }

    // Check privacy
    if (isPrivatePlayer(target)) {
      return ctx.reply(`🔒 *${target.name}* has set their duels to private.`)
    }

    // Also check the opponent's privacy
    const opponentJid = target.battleState.opponentJid
    if (opponentJid) {
      const opponent = await getPlayer(ctx.db, opponentJid)
      if (opponent && isPrivatePlayer(opponent)) {
        return ctx.reply(`🔒 One of the duelists has set their duels to private.`)
      }
    }

    // Check the spectator isn't one of the duelists
    if (ctx.from === targetJid || ctx.from === opponentJid) {
      return ctx.reply('❌ You cannot spectate your own duel!')
    }

    // Build player info
    const playerA = { jid: targetJid, name: target.name }
    const playerB = opponentJid
      ? { jid: opponentJid, name: target.battleState.opponentName ?? 'Opponent' }
      : { jid: 'unknown', name: 'Opponent' }

    // Register the spectacle
    const result = registerSpectacle({
      spectatorJid: ctx.from,
      spectatorName: ctx.player?.name ?? 'Spectator',
      targetJid: ctx.jid,
      playerA,
      playerB,
      chatJid: ctx.jid,
      sock: ctx.sock,
    })

    if (!result.ok) {
      return ctx.reply(`❌ ${result.reason}`)
    }

    // Send the initial spectator message
    const introText = formatSpectatorIntro(playerA, playerB)
    const sent = await ctx.reply(introText)

    // Store the message key for future edits
    if (sent?.key) {
      setSpectacleMessageKey(ctx.from, sent.key)
    }
  },
}
