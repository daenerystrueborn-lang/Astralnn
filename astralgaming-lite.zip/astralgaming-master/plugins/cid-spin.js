/**
 * <prefix>cid-spin <amount>
 *
 * Cid Kagenou's spin (Shadow, The Eminence in Shadow). Same shared odds curve
 * (chanceForExclusiveSpin), batch reel and pity bar as the other one-of-one
 * banners. He is one-of-one bot-wide: the first player anywhere to land him takes
 * the lock through claimExclusiveSpinForPlayer(), and the banner closes for
 * everybody, in chat and on the website alike.
 *
 * Odds, caps and the pull loop live in lib/spin-banners.js, NOT here, so the
 * website and chat stay on one set of numbers. This file owns the copy, the art
 * and the replies. 350 spins lifetime at 0.5 gems each, with the first 324 spins
 * a dead zone. None of those numbers are printed in player-facing copy. Only the
 * pity bar is.
 *
 * The banner ships OPEN. spinLockGate() is wired, so the owner can freeze it with
 * `.lockspin cid` and reopen it with `.unlockspin cid`.
 */
import { config } from '../config.js'
import { getExclusiveSpinWinner } from '../lib/season-engine.js'
import { characterMap } from '../lib/game-data.js'
import { getPlayer, updatePlayer } from '../lib/player-repo.js'
import { roundGems, fmtGems } from '../lib/format.js'
import { characterStars } from '../lib/rarity.js'
import { spinLockGate } from '../lib/spin-locks.js'
import { getSpinBanner, runSpinBatch } from '../lib/spin-banners.js'

const CHARACTER_ID = 'cid'
const BANNER = getSpinBanner(CHARACTER_ID)

const RULE = '━━━━━━━━━━━━━━━━━━━━'

const MISS_LINES = [
  'The shadow stretches across the floor, and then pulls back into nothing.',
  'A pale flicker behind the eyes, and then only the dark.',
  'Close. Something answers from the dark, then goes quiet.',
  'He smiles behind the mask. The plan is not finished yet.',
  'The mana gathers at his fingertips, and scatters before it takes a shape.',
  'Somewhere in the dark a shadow bows, and nothing else happens.',
]

function missLine(spin) {
  return `🌑 _${MISS_LINES[spin % MISS_LINES.length]}_`
}

/** Progress toward the spin cap. Never reveals the plateau. */
function pityBar(spin, width = 10) {
  const filled = Math.max(0, Math.min(width, Math.round((spin / BANNER.maxSpinsPerPlayer) * width)))
  return `${'▰'.repeat(filled)}${'▱'.repeat(width - filled)}`
}

function reel(results) {
  const MAX_ROWS = 5
  const marks = results.map(r => (r.won ? '✦' : '·'))
  const rows = []
  for (let i = 0; i < marks.length; i += 10) rows.push(marks.slice(i, i + 10).join(' '))
  if (rows.length <= MAX_ROWS) return rows.join('\n')
  return [`_…${(rows.length - MAX_ROWS) * 10} earlier spins_`, ...rows.slice(-MAX_ROWS)].join('\n')
}

async function replyOverArt(ctx, character, text) {
  if (!character?.image) return ctx.reply(text)
  try {
    return await ctx.replyImage(character.image, text)
  } catch {
    return ctx.reply(text)
  }
}

/** Display name of whoever holds the one-of-one, for the refusal copy. */
function holderName(ctx, jid) {
  try {
    return getPlayer(ctx.db, jid)?.name ?? null
  } catch {
    return null
  }
}

export default {
  name: 'cid-spin',
  aliases: ['cid', 'cidspin', 'shadowspin', 'cid-claim'],
  category: 'character',
  requiresPlayer: true,
  description: 'Spin for Cid Kagenou at 0.5 gems per spin. One-of-one, bot-wide, never for sale',

  async run(ctx) {
    const p = config.prefix
    if (!ctx.player) return ctx.reply(`⚠️ Register first with *${p}register*.`)

    const character = characterMap[CHARACTER_ID]
    if (!character) return ctx.reply(`⚠️ Cid isn't configured yet.`)

    // Owner spin lock. Nothing is read or spent past this until it is open.
    if (spinLockGate(ctx, CHARACTER_ID, character.name)) return

    // One-of-one pre-check, before a single gem is at risk. The authoritative
    // re-check happens inside runSpinBatch() on the serialized write queue.
    const existingWinner = getExclusiveSpinWinner(ctx.db, CHARACTER_ID)
    if (existingWinner) {
      if (existingWinner === ctx.from) {
        return replyOverArt(ctx, character,
          `🌑 *${character.name} is already yours.*\n${RULE}\n` +
          `_He answers to you and to nobody else, and there is nothing left to spin for. ` +
          `Equip him with *${p}character equip ${CHARACTER_ID}*, and *${p}atomic* is yours in every battle._`)
      }
      const who = holderName(ctx, existingWinner)
      return replyOverArt(ctx, character,
        `🔒 *THE SHADOW IS SPOKEN FOR*\n${RULE}\n` +
        `_${character.name} has been claimed by ${who ? `*${who}*` : 'another player'}._\n\n` +
        `Only one player, bot-wide, could ever win him, and someone got there first. ` +
        `No gems were spent.`)
    }

    // First ever attempt, read before this command mutates the spin count. Only
    // decides whether a losing reply carries the art as a one time preview.
    const isFirstEverAttempt = (ctx.player[BANNER.spinField] ?? 0) === 0

    const requested = Math.floor(Number(ctx.args[0]) || 1)

    let outcome = null
    await updatePlayer(ctx.db, ctx.from, (player) => {
      outcome = runSpinBatch(ctx.db, player, BANNER, ctx.from, requested)
    })

    if (outcome?.reason === 'owned') {
      return replyOverArt(ctx, character,
        `🌑 *${character.name} is already yours.*\n${RULE}\n` +
        `_Equip him with *${p}character equip ${CHARACTER_ID}*._`)
    }
    if (outcome?.reason === 'claimed') {
      return replyOverArt(ctx, character,
        `🔒 *THE SHADOW IS SPOKEN FOR*\n${RULE}\n` +
        `_${character.name} was claimed while you were still reaching._\n\n` +
        `Another player got there first this very moment. No gems were spent.`)
    }
    if (outcome?.reason === 'gems') {
      return ctx.reply(
        `💎 *Not enough Gems.*\n${RULE}\n` +
        `One spin costs 💎*${BANNER.costPerSpin}*. You hold 💎*${fmtGems(outcome.gems)}*.\n\n` +
        `_Come back with more._`,
      )
    }
    if (outcome?.reason === 'exhausted_lifetime') {
      return ctx.reply(
        `🌑 *No spins left.*\n${RULE}\n` +
        `_You have used all *${BANNER.maxSpinsPerPlayer}* of your spins for ${character.name}. ` +
        `The shadow never once answered._`,
      )
    }

    const last = outcome.results[outcome.results.length - 1]
    const spent = roundGems(outcome.spinsUsed * BANNER.costPerSpin)
    const range = outcome.spinsUsed === 1
      ? `Spin *${last.spin}*`
      : `Spins *${outcome.results[0].spin}* → *${last.spin}*`

    if (outcome.reason === 'won') {
      const ability = character.ability
      return replyOverArt(ctx, character,
        `🌑✨ *I AM ATOMIC.* ✨🌑\n${RULE}\n` +
        `_Spin ${last.spin}. The shadow finally steps out of the background, and the whole room notices._\n\n` +

        `🏆 *${character.name.toUpperCase()} OBTAINED*\n` +
        `${character.emoji ?? '🌑'} *${characterStars(character.stars)}*` +
        (ability?.name ? `  ·  *${ability.name}*` : '') + `\n` +
        (ability?.flavor ? `_${ability.flavor}_\n` : '') +
        (character.description ? `\n_${character.description}_\n` : '') +

        `\n🔒 *GLOBALLY LOCKED.* No other player can ever obtain him.\n` +
        `_Taken on spin ${last.spin}, for 💎${spent} this pull._\n` +
        `💎 Remaining: 💎*${fmtGems(outcome.remaining)}*\n\n` +
        `*How to use him:*\n` +
        `1️⃣ *${p}character equip ${CHARACTER_ID}*\n` +
        `2️⃣ *${p}atomic*: once per battle, no MP. A nuclear burst of mana: 8x INT damage that still runs through DEF. The flash blinds the target, so it loses its next turn even if the blast misses\n` +
        `   _The overload burns 10% of your max HP, and never below 1 HP. That is the price of the light._\n` +
        `3️⃣ Battles only for now: dungeons and boss fights, not duels or League fixtures\n`,
      )
    }

    const lines = [
      `🌑 *THE SHADOW STAYS HIDDEN*`,
      RULE,
      `_You spent 💎${spent}. Nothing answered._`,
      ``,
      range,
      reel(outcome.results),
      ``,
      missLine(last.spin),
      ``,
      `📿 Pity  ${pityBar(last.spin)}  *${last.spin}*/${BANNER.maxSpinsPerPlayer}`,
      `💎 Remaining: 💎*${fmtGems(outcome.remaining)}*`,
    ]

    if (requested > BANNER.maxSpinsPerCommand) {
      lines.push(``, `_Capped at *${BANNER.maxSpinsPerCommand}* spins per command. Run it again for more._`)
    } else if (outcome.spinsUsed < outcome.count) {
      lines.push(``, `_Gems ran out after *${outcome.spinsUsed}* of *${outcome.count}* requested spins._`)
    }

    const lossText = lines.join('\n')
    // Art preview only on a player's very first ever spin attempt. Every losing
    // spin after that is text only, matching the other spins.
    return isFirstEverAttempt ? replyOverArt(ctx, character, lossText) : ctx.reply(lossText)
  },
}
