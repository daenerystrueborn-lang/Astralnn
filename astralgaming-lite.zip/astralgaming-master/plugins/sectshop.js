/**
 * sectshop.js — `.sectshop` : the quartermaster inside your sect.
 *
 *   .sectshop                 what is on the counter today
 *   .sectshop <n|item> [x]    buy with contribution
 *
 * Paid in CONTRIBUTION, not in Spirit Stones: the peddler at the foot of the
 * road is the one who takes stones, and he is unchanged. Rank opens the lines,
 * the elder's own shelf opens with the elder's favor, and every line has a daily
 * limit (lib/sect-quartermaster.js).
 */
import { config } from '../config.js'
import { sectShopCommand } from '../lib/sect-commands.js'
import { sectDoorRefusal } from '../lib/world-guards.js'

export default {
  name: 'sectshop',
  aliases: ['quartermaster'],
  category: 'sect',
  requiresPlayer: true,
  description: `${config.prefix}sectshop — buy from your sect's quartermaster with contribution`,
  subcommands: [
    { cmd: '<n|item>', desc: 'buy one of the line the counter lists' },
  ],

  async run(ctx) {
    const wrongWorld = sectDoorRefusal(ctx.player, {
      emoji: '🛒', title: '*The quartermaster serves the Sect Empire.*',
      here: { cmd: 'shop', label: 'the Astra shops take Solars instead' },
    })
    if (wrongWorld) return ctx.reply(wrongWorld)
    return sectShopCommand(ctx)
  },
}
