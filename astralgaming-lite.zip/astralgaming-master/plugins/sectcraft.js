/**
 * sectcraft.js — the Sect Empire's `.craft`: the bench, and everything that
 * comes off it. plugins/craft.js (the kingdom blacksmith) hands a player in
 * the Sect Empire over to this file, so the word stays the kingdom's.
 *
 *   .craft                       what your trades can make from what you carry
 *   .craft recipes [trade]       the whole list, or one trade's
 *   .craft <recipe>              make it (a brew or a forging leaves a bench)
 *   .craft collect               take a finished piece off the bench
 *   .craft improve <artifact>    push a piece one step further, to +5
 *
 * The odds, the hours, the quality bands and the failure rules are all in
 * lib/sect-craft.js; this file is the list, the phrases and the two taps.
 */
import { config } from '../config.js'
import { sectDoorRefusal, missingSectRecordRefusal } from '../lib/world-guards.js'
import { updatePlayer } from '../lib/player-repo.js'
import { withGrowthLock } from '../lib/sect-progress.js'
import { BUSY } from '../lib/sect-fight.js'
import { itemById } from '../lib/sect-items.js'
import { missingMaterials, materialName } from '../lib/sect-materials.js'
import {
  PROFESSIONS, knows, levelOf, professionName,
} from '../lib/sect-professions.js'
import {
  RECIPES, craftHours, matchArtifact, matchRecipe, artifactsHeld,
  benchLeft, benchOf, collectBench, cancelBench, busyCraftRefusal, craftRefusal, craftWords, furnaceName, improveArtifact,
  improveRefusal, plusOf, qualityLabel, beginCraft, recipeById, wantedFurnace, furnaceTierAt,
} from '../lib/sect-craft.js'


const p = config.prefix
const fill = (text, values = {}) => String(text ?? '').replace(/\{(\w+)\}/g, (_, key) => String(values[key] ?? ''))

function leftText(ms) {
  const minutes = Math.max(0, Math.ceil(Number(ms) / 60_000))
  if (minutes < 60) return `${minutes} minutes`
  const hours = Math.floor(minutes / 60)
  return hours >= 24 ? `${Math.floor(hours / 24)} days` : `${hours} hours`
}

/** One recipe, as a line: what it makes, what it wants, whether it is ready. */
function recipeLine(profile, recipe, { player = null, prefix = p } = {}) {
  const known = knows(profile, recipe.profession)
  const level = levelOf(profile, recipe.profession)
  const levelOk = known && level >= Math.max(1, Number(recipe.level) || 1)
  const short = missingMaterials(profile, recipe.materials ?? [])
  const furnaceOk = !player || recipe.furnace == null
    || furnaceTierAt(player, recipe.profession) >= wantedFurnace(recipe)
  const mark = levelOk && !short.length && furnaceOk ? '✅' : '🔒'
  const need = !known
    ? `learn ${professionName(recipe.profession)}`
    : !levelOk
      ? `${professionName(recipe.profession)} level ${recipe.level}`
      : !furnaceOk
        ? `a ${furnaceName(wantedFurnace(recipe))}`
        : short.map(m => `${materialName(m.id)} ${m.have}/${m.need}`).join(', ')
  return fill(craftWords.line ?? '', {
    mark,
    emoji: PROFESSIONS.find(r => r.id === recipe.profession)?.emoji ?? '🛠️',
    name: recipe.name,
    level: `${professionName(recipe.profession)} ${recipe.level}`,
    materials: need,
    prefix,
  })
}

/** The list: one trade's, or every trade the player knows. */
function recipeScreen(player, { trade = null, all = false, prefix = p } = {}) {
  const profile = player.sect
  const lines = [craftWords.title ?? '🛠️ *THE BENCH*', craftWords.subtitle ?? '', '']
  const trades = trade ? [trade] : (all ? PROFESSIONS : PROFESSIONS.filter(r => knows(profile, r.id)))
  if (!trades.length) {
    lines.push(craftWords.noBench ?? '')
    lines.push('', fill(craftWords.foot ?? '', { prefix }))
    return lines.filter(l => l !== '').join('\n')
  }
  for (const record of trades) {
    const known = knows(profile, record.id)
    const level = levelOf(profile, record.id)
    const rows = RECIPES.filter(r => r.profession === record.id)
    const mine = rows.filter(r => known && level >= Math.max(1, Number(r.level) || 1))
    const later = rows.filter(r => !(known && level >= Math.max(1, Number(r.level) || 1)))
    lines.push(`${record.emoji ?? '🛠️'} *${record.name}*  ·  _${known ? `level ${level}` : 'not learned'}_  ·  _${rows.length} recipes_`)
    for (const recipe of mine.slice(0, 10)) lines.push(recipeLine(profile, recipe, { player, prefix }))
    if (mine.length > 10) lines.push(`   … _${mine.length - 10} more: *${prefix}craft recipes ${record.id}*_`)
    if (!known) lines.push(`   🔒 _${fill(craftWords.notLearned ?? '', { profession: record.name })}_`)
    else if (!mine.length) lines.push(`   🔒 _${later.slice(0, 3).map(r => r.name).join('  ·  ')}_`)
    lines.push('')
  }
  lines.push(fill(craftWords.foot ?? '', { prefix }))
  return lines.filter(l => l !== '').join('\n')
}

/** The whole list of one trade, uncut. */
function fullList(player, trade, { prefix = p } = {}) {
  const profile = player.sect
  const rows = RECIPES.filter(r => r.profession === trade.id)
  const lines = [
    `${trade.emoji ?? '🛠️'} *${trade.name}*  ·  _${rows.length} recipes_`,
    '',
    ...rows.map(recipe => recipeLine(profile, recipe, { player, prefix })),
    '',
    fill(craftWords.foot ?? '', { prefix }),
  ]
  return lines.filter(l => l !== '').join('\n')
}

export default {
  // NOT 'craft': that word is the kingdom blacksmith's (plugins/craft.js),
  // whose run hands a Sect Empire player over to this bench, the way the
  // mine hands `.gather` over. This name only keeps the delegation honest.
  name: 'sectcraft',
  aliases: [],
  category: 'event',
  requiresPlayer: true,
  description: `${config.prefix}craft [recipe|collect|improve <artifact>] — the bench of the four trades`,

  async run(ctx) {
    const player = ctx.player
    const wrongWorld = sectDoorRefusal(player, {
      emoji: '🛠️', title: '*The mountain crafting bench belongs to the Sect Empire.*',
      here: { cmd: 'craft', label: 'use the Astra crafting bench instead' },
    })
    if (wrongWorld) return ctx.reply(wrongWorld)
    if (!player.sect) return ctx.reply(missingSectRecordRefusal())

    const words = (ctx.args ?? []).map(a => String(a).toLowerCase()).filter(Boolean)
    const first = words[0] ?? ''
    const profile = player.sect

    // ── The screen ──────────────────────────────────────────────────────────
    if (!first) {
      const now = Date.now()
      const bench = benchOf(profile)
      const blocker = busyCraftRefusal(player, { now, includeBench: false })
      const lines = [recipeScreen(player)]
      if (blocker) lines.push(blocker)
      if (bench) {
        const recipe = recipeById(bench.recipeId)
        const left = benchLeft(profile, now)
        lines.push(left > 0
          ? fill(craftWords.running ?? '', { name: recipe?.name ?? bench.recipeId, left: leftText(left) })
          : fill(craftWords.ready ?? '', { name: recipe?.name ?? bench.recipeId, prefix: p }))
      }
      if (artifactsHeld(profile).length) {
        const rows = artifactsHeld(profile).slice(0, 6).map(record => fill(craftWords.improveLine ?? '', {
          mark: '·', name: itemById(record.id)?.name ?? record.id, plus: plusOf(record),
          bonus: record.quality ? `made ${qualityLabel(record.quality)}` : '',
        }))
        lines.push([fill(craftWords.improveFoot ?? '', { prefix: p }), ...rows].join('\n'))
      }
      return ctx.reply(lines.filter(l => l !== '').join('\n\n'))
    }

    // ── The list, in full ───────────────────────────────────────────────────
    if (first === 'recipes' || first === 'list') {
      const wanted = words.slice(1).join(' ')
      const trade = wanted ? PROFESSIONS.find(r => r.id === wanted || r.name.toLowerCase() === wanted) : null
      if (wanted && !trade) return ctx.reply(fill(craftWords.unknown ?? '', { prefix: p }))
      if (trade) return ctx.reply(fullList(player, trade, { prefix: p }))
      return ctx.reply(recipeScreen(player, { all: true, prefix: p }))
    }

    // ── Clear / abandon the bench ───────────────────────────────────────────
    if (first === 'cancel' || first === 'abandon' || first === 'clear') {
      let out = null
      const ran = await withGrowthLock(ctx.from, async () => {
        await updatePlayer(ctx.db, ctx.from, fresh => {
          out = cancelBench(fresh)
          return fresh
        })
      })
      if (!ran) return ctx.reply(BUSY)
      if (!out?.ok) return ctx.reply(fill(craftWords.emptyBench ?? '🛠️ *Nothing is on the bench.*', { prefix: p }))
      return ctx.reply(fill(craftWords.cancelled ?? '🛠️ *Cleared {name} off the bench.*', {
        name: out.recipe?.name ?? out.bench?.recipeId ?? 'item',
        prefix: p,
      }))
    }

    // ── Off the bench ───────────────────────────────────────────────────────
    if (first === 'collect' || first === 'take') {
      let out = null
      let failed = null
      const ran = await withGrowthLock(ctx.from, async () => {
        await updatePlayer(ctx.db, ctx.from, fresh => {
          out = collectBench(fresh, { now: Date.now() })
          if (!out.ok) {
            if (out.reason === 'notYet') {
              failed = fill(craftWords.running ?? '', { name: recipeById(out.bench?.recipeId)?.name ?? '', left: leftText(out.left) })
            } else if (out.reason === 'full') {
              failed = craftWords.bagFull ?? ''
            } else {
              failed = fill(craftWords.emptyBench ?? '🛠️ *Nothing is on the bench.*', { prefix: p })
            }
          }
          return fresh
        })
      })
      if (!ran) return ctx.reply(BUSY)
      if (failed) return ctx.reply(failed)
      if (!out?.ok) return ctx.reply(fill(craftWords.emptyBench ?? '🛠️ *Nothing is on the bench.*', { prefix: p }))
      return ctx.reply([
        fill(craftWords.collected ?? '', { name: out.recipe.name, quality: qualityLabel(out.quality ?? 'common') }),
        ...(out.lines ?? []),
      ].filter(l => l !== '').join('\n'))
    }

    // ── The forge's second half: improving a piece ──────────────────────────
    if (first === 'improve' || first === 'sharpen' || first === 'enhance') {
      const rest = words.slice(1).join(' ')
      const record = matchArtifact(profile, rest)
      const refusal = improveRefusal(player, record, { now: Date.now() })
      if (refusal) return ctx.reply(refusal)
      let out = null
      const ran = await withGrowthLock(ctx.from, async () => {
        await updatePlayer(ctx.db, ctx.from, fresh => {
          const found = matchArtifact(fresh.sect, rest)
          const why = improveRefusal(fresh, found, { now: Date.now() })
          if (why) { out = { ok: false, lines: [why] }; return fresh }
          out = improveArtifact(fresh, found, { now: Date.now(), seed: (Date.now() % 100000) + 1 })
          return fresh
        })
      })
      if (!ran) return ctx.reply(BUSY)
      if (!out?.ok) return ctx.reply((out?.lines ?? [craftWords.busy ?? '']).join('\n'))
      return ctx.reply([
        ...(out.lines ?? []),
        '',
        fill(craftWords.improveFoot ?? '', { prefix: p }),
      ].filter(l => l !== '').join('\n'))
    }

    // ── Making something ────────────────────────────────────────────────────
    const recipe = matchRecipe(words.join(' '))
    if (!recipe) {
      return ctx.reply([
        fill(craftWords.unknown ?? '', { prefix: p }),
        '',
        recipeScreen(player, { prefix: p }),
      ].filter(l => l !== '').join('\n'))
    }
    const refusal = craftRefusal(player, recipe, { now: Date.now() })
    if (refusal) return ctx.reply(refusal)

    let out = null
    let failed = null
    const ran = await withGrowthLock(ctx.from, async () => {
      await updatePlayer(ctx.db, ctx.from, fresh => {
        const again = craftRefusal(fresh, recipe, { now: Date.now() })
        if (again) { failed = again; return fresh }
        out = beginCraft(fresh, recipe, { now: Date.now(), seed: (Date.now() % 100000) + 1 })
        if (!out.ok) failed = (out.lines ?? [craftWords.busy ?? '']).join('\n')
        return fresh
      })
    })
    if (!ran) return ctx.reply(BUSY)
    if (failed) return ctx.reply(failed)
    if (!out?.ok) return ctx.reply(craftWords.busy ?? '')

    if (out.timed) {
      return ctx.reply(fill(craftWords.started ?? '', {
        name: recipe.name, hours: out.hours, prefix: p,
      }))
    }
    return ctx.reply([
      fill(craftWords.quickDone ?? '', {
        name: recipe.name,
        quality: qualityLabel(out.quality ?? 'common'),
      }),
      ...(out.lines ?? []),
    ].filter(l => l !== '').join('\n'))
  },
}

export { craftHours, craftWords }
