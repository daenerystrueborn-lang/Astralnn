/**
 * plugins/affinity.js — Avatar Multi-Affinity (Sacred 100-Vessel Box:
 * 90% Single · 5% Duo · 4% Tri · 1% THE AVATAR), Mastery Lv. 1–10,
 * Strict Per-Element Temple Training, 3-Stage Pilgrimage & Master Ordeals.
 */

import { config } from '../config.js'
import { updatePlayer, updateWorldState } from '../lib/player-repo.js'
import { sendImage, replyWithPicture } from '../lib/image.js'
import { locationsMap, skills } from '../lib/game-data.js'
import { ensureAffinityBendingSkills } from '../lib/skill-slots.js'
import { refreshStamina } from '../lib/combat-engine.js'

const skillById = Object.fromEntries(skills.map((s) => [s.id, s]))
import {
  AFFINITY_DATA,
  AFFINITY_ELEMENTS,
  NATION_LOCATION_TO_ELEMENT,
  VESSEL_LABELS,
  MIN_AWAKEN_LEVEL,
  AWAKEN_COST_SOLARS,
  RETRY_TRIBUTE_SOLARS,
  MAX_MASTERY_LEVEL,
  TEMPLE_TRAIN_COOLDOWN_MS,
  TEMPLE_TRAIN_BACKLASH_MS,
  TEMPLE_TRAIN_STAMINA_COST,
  SUB_BENDING_UNLOCK_LEVEL,
  APEX_SUB_BENDING_UNLOCK_LEVEL,
  normalizeAffinityId,
  normalizePlayerAffinity,
  getElementDef,
  hasAffinity,
  getUnlockedElements,
  isAvatarVessel,
  getMasteryRank,
  xpRequiredForMasteryLevel,
  isGateLocked,
  templePracticeProgress,
  grantMasteryXp,
  getUnlockedMasters,
  getAllElementMasters,
  getCurrentMaster,
  getSubBendingDef,
  getUnlockedSubBendings,
  hasSubBending,
  affinitySkillMultiplier,
  getLionTurtleBoxStats,
  drawFromLionTurtleBox,
  createChakraForge,
  stepChakraForge,
  masterPortraitKey,
  spiritTrialPortraitKey,
} from '../lib/affinity-engine.js'

function activeTrialPortrait(trial, fallback = 'affinity-lion-turtle') {
  if (!trial) return fallback
  if (trial.stage === 'spirit') {
    const curId = trial.spiritQueue?.[trial.spiritIndex ?? 0]
    return spiritTrialPortraitKey(curId) ?? fallback
  }
  if (trial.stage === 'doctrine') {
    return masterPortraitKey(trial.masterName) ?? getElementDef(trial.element)?.imageKey ?? fallback
  }
  if (trial.stage === 'forge') {
    if (trial.kind === 'awaken') return 'avatar-npc-pathik'
    return masterPortraitKey(trial.masterName) ?? getElementDef(trial.element)?.imageKey ?? 'avatar-npc-pathik'
  }
  if (trial.kind === 'gate' || trial.kind === 'sub' || trial.kind === 'train') {
    return masterPortraitKey(trial.masterName) ?? getElementDef(trial.element)?.imageKey ?? fallback
  }
  return fallback
}

function progressBar(cur, max, len = 10) {
  const safeMax = Math.max(1, max)
  const ratio = Math.max(0, Math.min(1, cur / safeMax))
  const filled = Math.round(ratio * len)
  return '█'.repeat(filled) + '░'.repeat(Math.max(0, len - filled))
}

function fmtCooldown(ms) {
  const totalSec = Math.max(1, Math.ceil(ms / 1000))
  const h = Math.floor(totalSec / 3600)
  const m = Math.floor((totalSec % 3600) / 60)
  const s = totalSec % 60
  if (h > 0) return `${h}h ${m}m`
  if (m > 0) return `${m}m ${s}s`
  return `${s}s`
}

function pickSpiritTrialIds(count = 2) {
  const pool = [...(AFFINITY_DATA.spiritTrials ?? [])]
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    const tmp = pool[i]
    pool[i] = pool[j]
    pool[j] = tmp
  }
  return pool.slice(0, count).map((s) => s.id)
}

function findSpiritTrial(id) {
  return (AFFINITY_DATA.spiritTrials ?? []).find((s) => s.id === id) ?? AFFINITY_DATA.spiritTrials[0]
}

function formatChakraForgePrompt(trial, p) {
  const f = trial.forge
  const cur = f.current
  const heading = trial.kind === 'train'
    ? `🥋 *TEMPLE CHAKRA DRILL — ${trial.label}*`
    : `🧘 *STAGE 3: CHAKRA FORGE — ${trial.label}*`
  const sceneLead = trial.kind === 'train' && f.turn === 1 && trial.scene
    ? `_${trial.scene}_\n\n`
    : ''
  return (
    `${heading}\n` +
    sceneLead +
    `Breath *${f.turn}/${f.maxTurns}*  ·   Lotus Inversion: ${f.lotusUsed ? '❌ Spent' : '🪷 Ready'}\n` +
    `✨ *Resonance:*   \`[${progressBar(f.resonance, 100)}]\` *${f.resonance}% / 100%*\n` +
    `⚠️ *Instability:* \`[${progressBar(f.instability, 100)}]\` *${f.instability}% / 100%*\n\n` +
    `${cur.emoji} *Cosmic Current — ${cur.name}:*\n` +
    `_${cur.desc}_\n\n` +
    `🧭 *Choose Your Chakra Breath:*\n` +
    `• \`${p}affinity forge surge\` — Heavy draw (*~+34% Resonance*, *~+26% Instability*, costs 15% HP)\n` +
    `• \`${p}affinity forge harmonize\` — Balanced breath (*~+22% Resonance*, *~+11% Instability*, 25 MP)\n` +
    `• \`${p}affinity forge ground\` — Neutral Jing vent (*-28% Instability*, *+6% Resonance*)\n` +
    `• \`${p}affinity forge lotus\` — *(1× per forge)* Convert *60%* of current Instability into Resonance!`
  )
}

function formatActiveTrialView(trial, p) {
  if (trial.stage === 'crucible') {
    const bossLine = trial.bossKillsReq
      ? `\n• Dungeon Bosses Slain: *${trial.bossKillsDone ?? 0} / ${trial.bossKillsReq}*`
      : ''
    const reqCasts = trial.kind === 'awaken' ? 0 : (trial.castsReq ?? 0)
    const castHint = trial.kind === 'gate'
      ? `*${getElementDef(trial.element).shortName}* Skills Cast in Battle`
      : `Skills Channeled in Battle`
    const castLine = reqCasts > 0
      ? `\n• ${castHint}: *${trial.castsDone ?? 0} / ${reqCasts}*`
      : `\n• _Martial Trial: Battle Skills are sealed before Awakening — slay monsters with *${p}attack*, *${p}defend*, and character *${p}ability*!_`
    return (
      `🔥 *STAGE 1: LIVE WORLD CRUCIBLE — ${trial.label}*\n` +
      `_"A vessel is tested in real blood and dust, not idle words."_\n\n` +
      `📋 *Combat Mandate (fight real monsters in Dungeons / World):*\n` +
      `• Monsters Slain: *${trial.killsDone ?? 0} / ${trial.killsReq}* _(Bosses count as 3)_` +
      bossLine +
      castLine + `\n\n` +
      `_Enter any dungeon (\`${p}dungeon\`), complete your Crucible in live battles, then run \`${p}affinity trial\`!_`
    )
  }

  if (trial.stage === 'spirit') {
    const curId = trial.spiritQueue?.[trial.spiritIndex ?? 0]
    const st = findSpiritTrial(curId)
    return (
      `👻 *STAGE 2: THE SPIRIT WORLD CROSSING (${(trial.spiritIndex ?? 0) + 1}/${trial.spiritQueue.length})*\n` +
      `Encounter: *${st.spirit}*  ·  Spirit Composure: *${trial.composure ?? 2} / 2*\n\n` +
      `_${st.scene}_\n\n` +
      `*A)* ${st.options.a}\n` +
      `*B)* ${st.options.b}\n` +
      `*C)* ${st.options.c}\n\n` +
      `👉 Respond with \`${p}affinity answer a\`, \`${p}affinity answer b\`, or \`${p}affinity answer c\`.`
    )
  }

  if (trial.stage === 'doctrine') {
    const d = trial.doctrine
    return (
      `🥋 *STAGE 2: MASTER'S DOCTRINE — ${trial.masterName.toUpperCase()}*\n` +
      `💬 _"${trial.quote}"_\n\n` +
      `❓ *${d.question}*\n\n` +
      `*A)* ${d.options.a}\n` +
      `*B)* ${d.options.b}\n` +
      `*C)* ${d.options.c}\n\n` +
      `👉 Respond with \`${p}affinity answer a\`, \`${p}affinity answer b\`, or \`${p}affinity answer c\`.`
    )
  }

  if (trial.stage === 'forge') {
    return formatChakraForgePrompt(trial, p)
  }

  return `⚠️ Unknown trial stage. Run \`${p}affinity abandon\` if stuck.`
}

function buildUnawakenedOverview(player, dbData, p) {
  const lv = Number(player.level) || 1
  const ready = lv >= MIN_AWAKEN_LEVEL
  const box = getLionTurtleBoxStats(dbData)

  return [
    `🐢 *THE ANCIENT LION TURTLE & SACRED 100-VESSEL BOX*`,
    `_"In the era before the Avatar, we bent not the elements, but the energy within ourselves."_`,
    ``,
    `Elemental Bending is *earned through a 3-Stage Pilgrimage* (Live Dungeon Crucible → Spirit World Crossing → Guru Pathik's Chakra Forge). When your Chakra seals, your soul draws *1 Sacred Vessel* from the *Box of 100 Vessels*:`,
    ``,
    `📦 *Sacred 100-Vessel Box (Era ${box.era} — ${box.remaining}/100 Remaining):*`,
    `• 🟢 *90%* _(90 in box · ${box.counts.single} left)_ — *1 Affinity* (Single Bender)`,
    `• 🔵 *5%*  _(5 in box · ${box.counts.duo} left)_ — *2 Affinities* (Twin-Soul Duo, e.g. Fire + Water!)`,
    `• 🟣 *4%*  _(4 in box · ${box.counts.tri} left)_ — *3 Affinities* (Primordial Tri-Bender!)`,
    `• 🌟 *1%*  _(1 in box · ${box.counts.avatar} left)_ — *ALL 4 AFFINITIES: THE AVATAR!* _(Masters all 4!)_`,
    ``,
    `🔒 *Chakra Law:* *Elemental Skills* (🔥🌊🪨🌪️) are *SEALED* until you awaken your Affinity — before Awakening, fight with the **10 Universal ⚪ Neutral Martial Skills (Lv. 1–50)** which require no element! Once awakened, your Affinity skills become your *Dominant Domain*, while off-element skills fizzle at *12% power*.`,
    ``,
    `🏛️ *Strict Temple Law:* You can *only* enter and train inside a Nation's Temple if you possess that Element's Affinity! Each Element scales from *Mastery Lv. 1 → Lv. 10* under real Avatar Masters.`,
    ``,
    `📋 *Requirements:* Level *${MIN_AWAKEN_LEVEL}+* _(You: Lv.${lv} ${ready ? '✅' : '🔒'})_ · *${AWAKEN_COST_SOLARS.toLocaleString('en-US')} Solars*`,
    ready
      ? `⚡ *Begin Pilgrimage:* \`${p}affinity trial <fire|water|earth|air>\`  ·  \`${p}affinity box\``
      : `🔒 _Reach *Level ${MIN_AWAKEN_LEVEL}* to begin the Lion Turtle Pilgrimage._`,
  ].join('\n')
}

function buildAwakenedCard(player, p, now = Date.now()) {
  const aff = normalizePlayerAffinity(player)
  const unlocked = getUnlockedElements(player)
  const vMeta = VESSEL_LABELS[aff.vesselTier] ?? VESSEL_LABELS.single
  const locElement = NATION_LOCATION_TO_ELEMENT[player.location] ?? null

  const blocks = unlocked.map((el) => {
    const elDef = getElementDef(el)
    const entry = aff.elements[el]
    const rank = getMasteryRank(entry.level)
    const master = getCurrentMaster(player, el)
    const sub = getSubBendingDef(player, el)
    const unlockedSubs = getUnlockedSubBendings(player, el)
    const needed = entry.level >= MAX_MASTERY_LEVEL ? 0 : xpRequiredForMasteryLevel(entry.level)
    const locked = isGateLocked(aff, el)
    const gm = rank.gateAt ? elDef.gateMasters?.[String(rank.gateAt)] : null
    const mult = affinitySkillMultiplier(player, { affinity: el, element: el })
    const multPct = Math.round((mult - 1) * 100)
    const cdLeft = Math.max(0, (entry.lastTrainAt ?? 0) + TEMPLE_TRAIN_COOLDOWN_MS - now)
    const primStar = aff.primary === el && unlocked.length > 1 ? ' ⭐' : ''

    const lvBar = entry.level >= MAX_MASTERY_LEVEL
      ? `*Lv. 10 / 10 (MAX)* \`[${progressBar(1, 1)}]\``
      : `*Lv. ${entry.level} / ${MAX_MASTERY_LEVEL}* \`[${progressBar(entry.xp, needed)}]\` ${entry.xp.toLocaleString('en-US')}/${needed.toLocaleString('en-US')} XP`

    let subSummary = ''
    if (unlockedSubs.length > 1 && sub) {
      const chainStr = unlockedSubs
        .slice()
        .sort((a, b) => (a.stage ?? 2) - (b.stage ?? 2))
        .map(sb => sb.id === sub.id ? `${sb.emoji} *${sb.name}* _(Active)_` : `${sb.emoji} ${sb.name}`)
        .join(' ➔ ')
      subSummary = chainStr
    } else if (sub) {
      const nextHint = sub.stage === 2 && entry.level >= APEX_SUB_BENDING_UNLOCK_LEVEL
        ? ` _(⚡ Stage III Apex ready via \`${p}affinity sub\`!)_`
        : ''
      subSummary = `${sub.emoji} *${sub.name}*${nextHint}`
    } else if (entry.level >= SUB_BENDING_UNLOCK_LEVEL) {
      subSummary = `_Ready! (\`${p}affinity sub\`)_`
    } else {
      subSummary = `_Stage II at Lv.${SUB_BENDING_UNLOCK_LEVEL} ➔ Stage III at Lv.${APEX_SUB_BENDING_UNLOCK_LEVEL}_`
    }

    const practice = templePracticeProgress(player, el)
    const templeStatus = entry.level >= MAX_MASTERY_LEVEL
      ? `👑 Maxed`
      : cdLeft > 0
        ? `⏳ ${fmtCooldown(cdLeft)}`
        : !practice.ready
          ? `⚔️ Field Practice (${practice.castsDone}/${practice.castsReq} casts or ${practice.killsDone}/${practice.killsReq} kills)`
          : `✅ Ready (\`${p}travel ${elDef.nationId}\` · ${TEMPLE_TRAIN_STAMINA_COST}⚡)`

    let block =
      `${elDef.emoji} *${elDef.name}*${primStar} — ${rank.badge} _${rank.name}_\n` +
      `   Mastery: ${lvBar}\n` +
      `   🥋 Master: *${master.name}* _(Tier ${master.roman} · +${Math.round(master.totalBonus * 100)}%)_ → *×${mult.toFixed(2)} (+${multPct}%)* ${elDef.shortName} Skill Power\n` +
      `   🌀 Sub-Art: ${subSummary}\n` +
      `   🧘 Temple: ${templeStatus}`

    if (locked && gm) {
      block += `\n   ⛩️ *GATE LOCKED (Lv.${entry.level}):* Go to *${elDef.nationName}* & run \`${p}affinity breakthrough\` to face *${gm.name}*!`
    }
    return block
  })

  const header = [
    `${vMeta.badge} *${vMeta.name.toUpperCase()} — ${player.name}*` + (aff.vesselNumber ? ` _(#${aff.vesselNumber}/100)_` : ''),
    `📍 *Current Location:* ${locationsMap[player.location]?.name ?? player.location}` +
      (locElement && aff.elements[locElement] ? ` _(✅ Your ${getElementDef(locElement).shortName} Sanctuary)_` : ''),
    ``,
    blocks.join('\n\n'),
  ]

  if (player.affinityTrial) {
    header.push(
      ``,
      `⚔️ *Active Ordeal:* ${player.affinityTrial.label} _(Stage: ${player.affinityTrial.stage.toUpperCase()})_ — run \`${p}affinity trial\`!`,
    )
  }

  header.push(
    ``,
    `_Commands: \`${p}affinity train\` · \`${p}affinity breakthrough\` · \`${p}affinity masters\` · \`${p}affinity sub\` · \`${p}affinity box\` · \`${p}bend\`_`,
    ...(unlocked.length > 1 ? [`_Multi-Element Vessel: switch active crest with \`${p}affinity primary <${unlocked.join('|')}>\`.`] : []),
  )

  return header.join('\n')
}

export default {
  name: 'affinity',
  aliases: ['bending', 'element', 'temple', 'nations'],
  category: 'bending',
  requiresPlayer: true,
  description: `Awaken & master your Avatar Elemental Affinities (${config.prefix}affinity)`,
  subcommands: [
    { cmd: 'trial <fire|water|earth|air>', desc: 'begin the 3-stage Lion Turtle Pilgrimage (Lv. 20+)' },
    { cmd: 'train', desc: 'meditate at your Nation Temple for Mastery XP (Lv. 1 to 10)' },
    { cmd: 'breakthrough', desc: 'challenge a Master Gate ordeal (Lv. 2, 4, 5, 6, 8, 9)' },
    { cmd: 'sub [id]', desc: 'view or unlock Sub-Bending specializations (Lv. 6+)' },
    { cmd: 'masters', desc: 'inspect your 7-tier Avatar Master lineage & bonuses' },
    { cmd: 'primary <element>', desc: 'switch active element on Multi-Element Vessels' },
    { cmd: 'box', desc: 'check the Sacred 100-Vessel Box odds & Era chronicle' },
  ],

  async run(ctx) {
    const p = config.prefix
    const sub = String(ctx.args?.[0] ?? '').toLowerCase().trim()

    // ── 1. STATUS / OVERVIEW ───────────────────────────────────────────────
    if (!sub || sub === 'status' || sub === 'info') {
      if (!hasAffinity(ctx.player)) {
        if (ctx.player.affinityTrial) {
          return replyWithPicture(
            ctx,
            activeTrialPortrait(ctx.player.affinityTrial, 'affinity-lion-turtle'),
            formatActiveTrialView(ctx.player.affinityTrial, p),
          )
        }
        return sendImage(ctx, 'affinity-lion-turtle', buildUnawakenedOverview(ctx.player, ctx.db?.data, p))
      }
      const aff = normalizePlayerAffinity(ctx.player)
      const crestKey = isAvatarVessel(ctx.player)
        ? 'affinity-lion-turtle'
        : (getElementDef(aff.primary)?.imageKey ?? 'affinity-lion-turtle')
      return sendImage(ctx, crestKey, buildAwakenedCard(ctx.player, p))
    }

    // ── 2. SACRED 100-VESSEL BOX VIEW (.affinity box) ─────────────────────
    if (sub === 'box' || sub === 'pool' || sub === 'odds' || sub === 'vessels') {
      const box = getLionTurtleBoxStats(ctx.db?.data)
      const rareRows = box.chronicle.length
        ? box.chronicle.map((c) => {
            const vm = VESSEL_LABELS[c.tier] ?? VESSEL_LABELS.duo
            const icons = (c.elements ?? []).map((e) => getElementDef(e)?.emoji ?? '').join('')
            return `• ${vm.badge} *${c.name}* — *${vm.name}* ${icons} _(Vessel #${c.vesselNumber}/100)_`
          }).join('\n')
        : `_No rare Multi-Element or Avatar vessels have been drawn in this Era yet!_`

      return sendImage(
        ctx,
        'affinity-lion-turtle',
        `📦 *SACRED LION TURTLE BOX — ERA ${box.era}*\n` +
        `Total Vessels Drawn: *${box.drawn}*  ·  Remaining in Current 100-Box: *${box.remaining} / 100*\n\n` +
        `📊 *Exact Vessel Distribution (100 Total):*\n` +
        `• 🟢 *1 Affinity (90%)* — *${box.counts.single} / 90* remaining\n` +
        `• 🔵 *2 Affinities · Duo (5%)* — *${box.counts.duo} / 5* remaining\n` +
        `• 🟣 *3 Affinities · Tri-Bender (4%)* — *${box.counts.tri} / 4* remaining\n` +
        `• 🌟 *ALL 4 · THE AVATAR (1%)* — *${box.counts.avatar} / 1* remaining\n\n` +
        `📜 *Chronicle of Rare Awakenings:*\n${rareRows}`,
      )
    }

    // ── 3. LEADERBOARD (.affinity leaderboard) ────────────────────────────
    if (sub === 'leaderboard' || sub === 'lb' || sub === 'top') {
      const users = Object.values(ctx.db?.data?.users ?? {})
        .filter((u) => !u?.hiddenFromLeaderboard && hasAffinity(u))
        .map((u) => {
          const aff = normalizePlayerAffinity(u)
          const els = getUnlockedElements(u)
          const sumLevels = els.reduce((s, e) => s + aff.elements[e].level, 0)
          const maxLv = Math.max(...els.map((e) => aff.elements[e].level))
          const sumXp = els.reduce((s, e) => s + (aff.elements[e].totalXp ?? 0), 0)
          return { u, aff, els, sumLevels, maxLv, sumXp }
        })
        .sort((a, b) => (b.maxLv - a.maxLv) || (b.sumLevels - a.sumLevels) || (b.sumXp - a.sumXp))
        .slice(0, 10)

      if (!users.length) {
        return ctx.reply(`🐢 *Four Nations Leaderboard*\n\n_No adventurer has completed the Lion Turtle Pilgrimage yet!_`)
      }

      const rows = users.map((row, i) => {
        const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `*#${i + 1}*`
        const vm = VESSEL_LABELS[row.aff.vesselTier] ?? VESSEL_LABELS.single
        const badges = row.els.map((e) => `${getElementDef(e).emoji}Lv.${row.aff.elements[e].level}`).join(' ')
        return `${medal} *${row.u.name}* ${vm.badge} — ${badges}`
      })

      return ctx.reply(`🪷 *FOUR NATIONS — TOP ELEMENTAL MASTERS*\n\n${rows.join('\n')}`)
    }

    // ── 4. SWITCH PRIMARY ELEMENT (.affinity primary <el>) ────────────────
    if (sub === 'primary' || sub === 'focus' || sub === 'active') {
      const targetEl = normalizeAffinityId(ctx.args?.[1])
      if (!hasAffinity(ctx.player)) {
        return ctx.reply(`🐢 You have not awakened an Affinity yet (\`${p}affinity\`).`)
      }
      const unlocked = getUnlockedElements(ctx.player)
      if (!targetEl || !unlocked.includes(targetEl)) {
        return ctx.reply(
          `🧭 Choose one of your awakened elements: ${unlocked.map((e) => `\`${p}affinity primary ${e}\``).join(' · ')}`,
        )
      }
      await updatePlayer(ctx.db, ctx.from, (player) => {
        normalizePlayerAffinity(player).primary = targetEl
        return player
      })
      const d = getElementDef(targetEl)
      return ctx.reply(`${d.emoji} Active Crest & Battle Focus set to *${d.name}*!`)
    }

    // ── 5. START OR VIEW PILGRIMAGE / ORDEAL (.affinity trial [el]) ───────
    if (sub === 'trial' || sub === 'awaken' || sub === 'pilgrimage') {
      if (ctx.player.affinityTrial) {
        const fb = hasAffinity(ctx.player)
          ? (getElementDef(ctx.player.affinityTrial.element)?.imageKey ?? 'affinity-lion-turtle')
          : 'affinity-lion-turtle'
        return replyWithPicture(
          ctx,
          activeTrialPortrait(ctx.player.affinityTrial, fb),
          formatActiveTrialView(ctx.player.affinityTrial, p),
        )
      }

      if (hasAffinity(ctx.player)) {
        return ctx.reply(`🐢 Your vessel is already awakened! Check \`${p}affinity\` or run \`${p}affinity breakthrough\` inside your Nation's Temple when at a Rank Gate.`)
      }

      const elId = normalizeAffinityId(ctx.args?.[1])
      if (!elId) {
        return ctx.reply(
          `🐢 *Choose Your Root Element for the Lion Turtle Pilgrimage:*\n` +
          `• \`${p}affinity trial fire\` — 🔥 Firebending\n` +
          `• \`${p}affinity trial water\` — 🌊 Waterbending\n` +
          `• \`${p}affinity trial earth\` — 🪨 Earthbending\n` +
          `• \`${p}affinity trial air\` — 🌪️ Airbending\n\n` +
          `_(Your chosen element is guaranteed — and if you pull a 5% Duo, 4% Tri, or the 1% Avatar from the 100-Box, bonus elements awaken alongside it!)_`,
        )
      }

      let outcome = null
      await updatePlayer(ctx.db, ctx.from, (player) => {
        if ((player.level ?? 1) < MIN_AWAKEN_LEVEL) {
          outcome = { err: `🔒 Reach *Level ${MIN_AWAKEN_LEVEL}* before beginning the Lion Turtle Pilgrimage _(You are Lv. ${player.level ?? 1})_.` }
          return player
        }
        if (player.inBattle) {
          outcome = { err: `⚔️ Finish your current battle first!` }
          return player
        }
        const retry = Boolean(player.affinityAwakenAttempted)
        const cost = retry ? RETRY_TRIBUTE_SOLARS : AWAKEN_COST_SOLARS
        const solars = player.wallet?.solars ?? 0
        if (solars < cost) {
          outcome = { err: `☀️ Need *${cost.toLocaleString('en-US')} Solars* for the Lion Turtle Offering _(You have ${solars.toLocaleString('en-US')})_.` }
          return player
        }
        player.wallet.solars -= cost
        player.affinityAwakenAttempted = true
        const elDef = getElementDef(elId)
        player.affinityTrial = {
          kind: 'awaken',
          element: elId,
          label: `${elDef.emoji} Lion Turtle Pilgrimage (${elDef.name})`,
          stage: 'crucible',
          killsReq: 8,
          killsDone: 0,
          castsReq: 0,
          castsDone: 0,
          spiritQueue: pickSpiritTrialIds(2),
          spiritIndex: 0,
          composure: 2,
          forgeDifficulty: 1,
          forge: null,
        }
        outcome = { started: player.affinityTrial, cost }
        return player
      })

      if (outcome?.err) return ctx.reply(outcome.err)
      return sendImage(
        ctx,
        'affinity-lion-turtle',
        `🐢 *THE LION TURTLE MARKS YOUR SPIRIT...*\n` +
        `_(Offering paid: ${outcome.cost.toLocaleString('en-US')} Solars)_\n\n` +
        formatActiveTrialView(outcome.started, p),
      )
    }

    // ── 6. START MASTER BREAKTHROUGH ORDEAL (.affinity breakthrough) ──────
    if (sub === 'breakthrough' || sub === 'gate' || sub === 'rankup' || sub === 'ordeal') {
      if (!hasAffinity(ctx.player)) {
        return ctx.reply(`🐢 Awaken an Elemental Affinity first (\`${p}affinity\`).`)
      }
      if (ctx.player.affinityTrial) {
        return ctx.reply(formatActiveTrialView(ctx.player.affinityTrial, p))
      }

      let outcome = null
      await updatePlayer(ctx.db, ctx.from, (player) => {
        if (player.inBattle) {
          outcome = { err: `⚔️ Finish your current battle first!` }
          return player
        }
        const aff = normalizePlayerAffinity(player)
        const locEl = NATION_LOCATION_TO_ELEMENT[player.location] ?? null

        if (!locEl) {
          const ownedRoads = getUnlockedElements(player).map((e) => `\`${p}travel ${getElementDef(e).nationId}\``).join(' · ')
          outcome = {
            err: `🏛️ *Stand inside the Elemental Nation whose Mastery Gate you want to break through!*\nYour unlocked Nations: ${ownedRoads}`,
          }
          return player
        }

        if (!aff.elements[locEl]) {
          const elDef = getElementDef(locEl)
          outcome = {
            err: `🚫 You do not possess *${elDef.emoji} ${elDef.name}*! You cannot challenge Masters or train inside a Temple without its Affinity.`,
          }
          return player
        }

        const entry = aff.elements[locEl]
        const elDef = getElementDef(locEl)
        if (!isGateLocked(aff, locEl)) {
          const rank = getMasteryRank(entry.level)
          const needed = entry.level >= MAX_MASTERY_LEVEL ? 0 : xpRequiredForMasteryLevel(entry.level)
          outcome = {
            err: entry.level >= MAX_MASTERY_LEVEL
              ? `👑 Your *${elDef.name}* is already *Lv. 10/10 (Legend of the Nation)*!`
              : rank.gateAt
                ? `⏳ Fill your *${elDef.name}* Lv. ${entry.level} XP bar first (*${entry.xp.toLocaleString('en-US')}/${needed.toLocaleString('en-US')} XP*) via \`${p}affinity train\` and combat!`
                : `✨ Level ${entry.level} has no Gate Master — keep earning Mastery XP to level up automatically!`,
          }
          return player
        }

        const gm = elDef.gateMasters?.[String(entry.level)]
        player.affinityTrial = {
          kind: 'gate',
          element: locEl,
          gateLevel: entry.level,
          label: `⛩️ ${elDef.emoji} Lv.${entry.level}→${entry.level + 1} Ordeal (${gm.name})`,
          masterName: gm.name,
          masterTitle: gm.title,
          quote: gm.quote,
          doctrine: gm.doctrine,
          stage: 'crucible',
          killsReq: gm.killsReq ?? 6,
          killsDone: 0,
          bossKillsReq: gm.bossKillsReq ?? 0,
          bossKillsDone: 0,
          castsReq: gm.castsReq ?? 5,
          castsDone: 0,
          forgeDifficulty: gm.forgeDifficulty ?? 2,
          forge: null,
        }
        outcome = { started: player.affinityTrial, crest: elDef.imageKey }
        return player
      })

      if (outcome?.err) return ctx.reply(outcome.err)
      const t = outcome.started
      return replyWithPicture(
        ctx,
        masterPortraitKey(t.masterName) ?? outcome.crest,
        `⛩️ *MASTER'S THREE-FOLD ORDEAL — ${t.masterName.toUpperCase()}*\n` +
        `_${t.masterTitle}_\n` +
        `💬 _"${t.quote}"_\n\n` +
        formatActiveTrialView(t, p),
      )
    }

    // ── 7. SUB-BENDING SPECIALIZATION (.affinity sub [id]) ────────────────
    if (sub === 'sub' || sub === 'subbending' || sub === 'specialize') {
      if (!hasAffinity(ctx.player)) {
        return ctx.reply(`🐢 Awaken an Elemental Affinity first (\`${p}affinity\`).`)
      }
      const aff = normalizePlayerAffinity(ctx.player)
      const locEl = NATION_LOCATION_TO_ELEMENT[ctx.player.location] ?? aff.primary
      if (!aff.elements[locEl]) {
        return ctx.reply(`🚫 You do not possess the Affinity of this Nation!`)
      }
      const elDef = getElementDef(locEl)
      const entry = aff.elements[locEl]
      const chosenSubId = String(ctx.args?.[1] ?? '').toLowerCase().trim()
      const subList = Object.values(elDef.subBendings ?? {})

      if (!chosenSubId) {
        const curSub = getSubBendingDef(ctx.player, locEl)
        const stage2 = subList.filter(s => (s.stage ?? 2) === 2)
        const stage3 = subList.filter(s => s.stage === 3)

        const fmtSubCard = (sb) => {
          const reqLv = sb.unlockLevel ?? SUB_BENDING_UNLOCK_LEVEL
          const mastered = hasSubBending(ctx.player, sb.id, locEl)
          const isActive = curSub?.id === sb.id
          const prereqDef = sb.requiresSub ? elDef.subBendings?.[sb.requiresSub] : null
          const prereqMet = !sb.requiresSub || hasSubBending(ctx.player, sb.requiresSub, locEl)
          const lvMet = entry.level >= reqLv

          const statusTag = isActive
            ? ' ⭐ *(ACTIVE)*'
            : mastered
              ? ' ✅ *(MASTERED — instant switch)*'
              : (lvMet && prereqMet)
                ? ' ⚡ *(READY TO FORGE)*'
                : ' 🔒'

          const reqLine = prereqDef
            ? `Requires *${prereqDef.emoji} ${prereqDef.name}* + *Mastery Lv. ${reqLv}*`
            : `Unlocks at *${elDef.shortName} Mastery Lv. ${reqLv}*`

          return (
            `${sb.emoji} *${sb.name}* (\`${sb.id}\`)${statusTag}\n` +
            `   Mentor: *${sb.mentor}* · ${reqLine}\n` +
            `   _${sb.description}_`
          )
        }

        return sendImage(
          ctx,
          elDef.imageKey,
          `🌀 *${elDef.name.toUpperCase()} — MASTERY EVOLUTION TREE*\n` +
          `_Foundation phase mastery leads into Apex & Forbidden arts (+8% permanent Lineage carry-over!)._\n\n` +
          `── Stage II: Phase Foundation (Lv. ${SUB_BENDING_UNLOCK_LEVEL}+) ──\n` +
          stage2.map(fmtSubCard).join('\n\n') +
          `\n\n── Stage III: Apex Specialization (Lv. ${APEX_SUB_BENDING_UNLOCK_LEVEL}+) ──\n` +
          stage3.map(fmtSubCard).join('\n\n') +
          `\n\n${entry.level >= SUB_BENDING_UNLOCK_LEVEL
            ? `⚡ Stand inside *${elDef.nationName}* (\`${p}travel ${elDef.nationId}\`) and run \`${p}affinity sub <${subList.map((s) => s.id).join('|')}>\`!`
            : `🔒 _Reach *${elDef.shortName} Mastery Lv. ${SUB_BENDING_UNLOCK_LEVEL} (Sifu)* first (currently Lv. ${entry.level}/10)._`}`,
        )
      }

      let outcome = null
      await updatePlayer(ctx.db, ctx.from, (player) => {
        const pAff = normalizePlayerAffinity(player)
        const sb = elDef.subBendings?.[chosenSubId]
        if (!sb) {
          outcome = { err: `❌ Unknown Sub-Bending \`${chosenSubId}\`. Options: ${subList.map((s) => `\`${s.id}\``).join(', ')}.` }
          return player
        }

        const pEntry = pAff.elements[locEl]
        // Instant stance switch if the player ALREADY mastered this art earlier!
        if (pEntry.subBendings?.includes(sb.id)) {
          pEntry.subBending = sb.id
          ensureAffinityBendingSkills(player)
          outcome = { switched: sb }
          return player
        }

        const hereEl = NATION_LOCATION_TO_ELEMENT[player.location] ?? null
        if (hereEl !== locEl || !pAff.elements[locEl]) {
          outcome = { err: `🏛️ Travel to *${elDef.nationName}* (\`${p}travel ${elDef.nationId}\`) to forge *${sb.emoji} ${sb.name}*!` }
          return player
        }

        const reqLv = sb.unlockLevel ?? SUB_BENDING_UNLOCK_LEVEL
        if (sb.requiresSub && !pEntry.subBendings?.includes(sb.requiresSub)) {
          const prereq = elDef.subBendings?.[sb.requiresSub]
          outcome = {
            err:
              `🔒 *${sb.emoji} ${sb.name}* evolves directly from *${prereq?.emoji ?? ''} ${prereq?.name ?? sb.requiresSub}*!\n` +
              `Master Stage II first via \`${p}affinity sub ${sb.requiresSub}\` — once you command phase-shifts, the Apex art opens at *Lv. ${reqLv}*!`,
          }
          return player
        }
        if (pEntry.level < reqLv) {
          outcome = { err: `🔒 *${sb.emoji} ${sb.name}* requires *${elDef.shortName} Mastery Lv. ${reqLv}* _(You are Lv. ${pEntry.level}/10)_.` }
          return player
        }
        if (player.inBattle) {
          outcome = { err: `⚔️ Finish your current battle first!` }
          return player
        }
        if (player.affinityTrial) {
          outcome = { err: `⚔️ Finish your active *${player.affinityTrial.label}* first (\`${p}affinity trial\` or \`${p}affinity abandon\`).` }
          return player
        }
        const diff = sb.forgeDifficulty ?? (sb.stage === 3 ? 3 : 2)
        player.affinityTrial = {
          kind: 'sub',
          element: locEl,
          subId: sb.id,
          subName: sb.name,
          subEmoji: sb.emoji,
          masterName: sb.mentor,
          label: `${sb.emoji} ${sb.name} Chakra Forge`,
          stage: 'forge',
          forgeDifficulty: diff,
          forge: createChakraForge(diff),
        }
        outcome = { started: player.affinityTrial, crest: elDef.imageKey }
        return player
      })

      if (outcome?.err) return ctx.reply(outcome.err)
      if (outcome?.switched) {
        return ctx.reply(
          `${outcome.switched.emoji} *Active Sub-Bending Switched — ${outcome.switched.name}!*\n` +
          `_${outcome.switched.description}_`,
        )
      }
      return replyWithPicture(
        ctx,
        activeTrialPortrait(outcome.started, outcome.crest),
        formatActiveTrialView(outcome.started, p),
      )
    }

    // ── 8. STAGE 2 SPIRIT / DOCTRINE ANSWER (.affinity answer <a|b|c>) ────
    if (sub === 'answer' || sub === 'ans' || sub === 'reply') {
      const choice = String(ctx.args?.[1] ?? '').toLowerCase().trim()
      if (!['a', 'b', 'c'].includes(choice)) {
        return ctx.reply(`🧭 Answer with \`${p}affinity answer a\`, \`${p}affinity answer b\`, or \`${p}affinity answer c\`.`)
      }

      let res = null
      await updatePlayer(ctx.db, ctx.from, (player) => {
        const t = player.affinityTrial
        if (!t || (t.stage !== 'spirit' && t.stage !== 'doctrine')) {
          res = { err: `⚠️ You have no Spirit Encounter or Master Doctrine question waiting right now. Check \`${p}affinity trial\`.` }
          return player
        }

        if (t.stage === 'spirit') {
          const curId = t.spiritQueue[t.spiritIndex ?? 0]
          const st = findSpiritTrial(curId)
          if (choice === st.correct) {
            t.spiritIndex = (t.spiritIndex ?? 0) + 1
            if (t.spiritIndex >= t.spiritQueue.length) {
              t.stage = 'forge'
              t.forge = createChakraForge(t.forgeDifficulty ?? 1)
              res = {
                img: activeTrialPortrait(t, 'avatar-npc-pathik'),
                msg: `✅ *${st.spirit}:*\n_${st.winLine}_\n\n🌟 *Spirit World Crossing Passed!* Guru Pathik awaits you at the Eastern Air Temple:\n\n${formatChakraForgePrompt(t, p)}`,
              }
            } else {
              res = {
                img: activeTrialPortrait(t, spiritTrialPortraitKey(curId)),
                msg: `✅ *${st.spirit}:*\n_${st.winLine}_\n\n${formatActiveTrialView(t, p)}`,
              }
            }
          } else {
            t.composure = (t.composure ?? 2) - 1
            if (t.composure <= 0) {
              player.affinityTrial = null
              res = {
                img: spiritTrialPortraitKey(curId),
                msg:
                  `💥 *${st.spirit}:*\n_${st.failLine}_\n\n` +
                  `🕯️ *Your Spirit Composure shattered in the Spirit World!* Center yourself and restart with \`${p}affinity trial ${t.element}\`.`,
              }
            } else {
              res = {
                img: activeTrialPortrait(t, spiritTrialPortraitKey(curId)),
                msg:
                  `⚠️ *${st.spirit}:*\n_${st.failLine}_\n` +
                  `_(Composure remaining: *${t.composure}/2* — choose carefully!)_\n\n` +
                  formatActiveTrialView(t, p),
              }
            }
          }
          return player
        }

        // t.stage === 'doctrine' (Master Gate Ordeal Fold II)
        if (choice === t.doctrine.correct) {
          t.stage = 'forge'
          t.forge = createChakraForge(t.forgeDifficulty ?? 2)
          res = {
            img: masterPortraitKey(t.masterName) ?? 'avatar-npc-pathik',
            msg:
              `✅ *${t.masterName} nods approvingly:*\n_"You understand the heart of the art. Now seal it inside your meridians!"_\n\n` +
              formatChakraForgePrompt(t, p),
          }
        } else {
          const masterImg = masterPortraitKey(t.masterName)
          player.affinityTrial = null
          res = {
            img: masterImg,
            msg:
              `❌ *${t.masterName} shakes their head:*\n_"Your technique outran your understanding. Meditate on our Nation's teachings and run \`${p}affinity breakthrough\` again."_`,
          }
        }
        return player
      })

      if (res?.err) return ctx.reply(res.err)
      return replyWithPicture(ctx, res.img ?? null, res.msg)
    }

    // ── 9. STAGE 3 CHAKRA FORGE (.affinity forge <surge|harmonize|ground|lotus>) ──
    if (sub === 'forge' || sub === 'chakra' || sub === 'breathe') {
      const action = String(ctx.args?.[1] ?? '').toLowerCase().trim()
      if (!ctx.player.affinityTrial || ctx.player.affinityTrial.stage !== 'forge') {
        return ctx.reply(`⚠️ You are not inside a Chakra Forge right now. Check \`${p}affinity\`.`)
      }

      // First run the Chakra Forge step on the player; if an Awakening Forge seals,
      // atomically draw from the Sacred 100-Vessel Box via `updateWorldState`!
      let forgeOutcome = null
      await updatePlayer(ctx.db, ctx.from, (player) => {
        const t = player.affinityTrial
        if (!t || t.stage !== 'forge') {
          forgeOutcome = { err: `⚠️ No active Chakra Forge.` }
          return player
        }
        const step = stepChakraForge(t.forge, action, player)
        if (!step.ok) {
          forgeOutcome = { err: step.err }
          return player
        }

        if (step.status === 'ongoing') {
          forgeOutcome = { ongoing: `${step.log}\n\n${formatChakraForgePrompt(t, p)}` }
          return player
        }

        if (step.status === 'shattered' || step.status === 'exhausted') {
          const reason = step.status === 'shattered'
            ? `💥 *Chi Backlash!* Instability hit *100%* and shattered the Chakra seal!`
            : `🕯️ *Out of Breaths!* You ran out of breaths at *${t.forge.resonance}% Resonance*.`
          const kind = t.kind
          const el = t.element
          player.affinityTrial = null

          if (kind === 'train') {
            const failNow = Date.now()
            const liveEntry = normalizePlayerAffinity(player)?.elements?.[el]
            if (liveEntry) {
              liveEntry.lastTrainAt = failNow - (TEMPLE_TRAIN_COOLDOWN_MS - TEMPLE_TRAIN_BACKLASH_MS)
            }
          }

          forgeOutcome = {
            failed:
              `${step.log}\n\n${reason}\n` +
              (kind === 'awaken'
                ? `_Re-enter the Lion Turtle Pilgrimage anytime with \`${p}affinity trial ${el}\`._`
                : kind === 'gate'
                  ? `_Challenge your Gate Master again in your Temple with \`${p}affinity breakthrough\`._`
                  : kind === 'train'
                    ? `_Your meridians suffered backlash — 0 Mastery XP gained. Rest *2h* before attempting \`${p}affinity train\` again._`
                    : `_Re-attempt the Sub-Bending Forge in your Temple with \`${p}affinity sub\`._`),
          }
          return player
        }

        // step.status === 'sealed'!
        forgeOutcome = { sealedKind: t.kind, trialSnapshot: { ...t, forge: { ...t.forge } }, log: step.log }
        return player
      })

      if (forgeOutcome?.err) return ctx.reply(forgeOutcome.err)
      if (forgeOutcome?.ongoing) return ctx.reply(forgeOutcome.ongoing)
      if (forgeOutcome?.failed) return ctx.reply(forgeOutcome.failed)

      // ── SEALED: AWAKENING DRAW FROM THE SACRED 100-VESSEL BOX! ─────────
      if (forgeOutcome.sealedKind === 'awaken') {
        const chosenEl = forgeOutcome.trialSnapshot.element
        const drawn = await updateWorldState(ctx.db, 'lionTurtleBox', (data) =>
          drawFromLionTurtleBox(data, chosenEl, ctx.player.name),
        )

        let finalCard = ''
        let crestKey = getElementDef(chosenEl).imageKey
        await updatePlayer(ctx.db, ctx.from, (player) => {
          player.affinityTrial = null
          const elementsMap = {}
          for (const el of drawn.unlockedElements) {
            elementsMap[el] = {
              level: 1,
              xp: 0,
              totalXp: 0,
              subBending: null,
              masterId: null,
              clearedGates: [],
              lastTrainAt: 0,
              skillCasts: 0,
              templeSessions: 0,
            }
          }
          player.affinity = {
            vesselTier: drawn.tier,
            vesselNumber: drawn.vesselNumber,
            primary: chosenEl,
            elements: elementsMap,
            awakenedAt: Date.now(),
            dailyCombatDay: 0,
            dailyCombatXp: 0,
          }
          const newBendingIds = ensureAffinityBendingSkills(player)

          const vm = VESSEL_LABELS[drawn.tier] ?? VESSEL_LABELS.single
          if (drawn.tier === 'avatar') crestKey = 'affinity-avatar'
          const awakenedList = drawn.unlockedElements.map((e) => {
            const d = getElementDef(e)
            const m = getCurrentMaster(player, e)
            return `• ${d.emoji} *${d.name}* — Homeland: \`${p}travel ${d.nationId}\` _(Master: ${m.name})_`
          }).join('\n')
          const skillNotice = newBendingIds.length
            ? `\n\n📜 *Awakened Bending Forms:* ${newBendingIds.map((s) => `*${s?.name ?? skillById[s]?.name ?? s}*`).join(', ')} _(Equip via \`${p}skillslot\` or cast with \`${p}bend\`)_`
            : ''

          finalCard =
            `${forgeOutcome.log}\n\n` +
            `🐢✨ *THE SACRED 100-VESSEL BOX OPENS — VESSEL #${drawn.vesselNumber}/100!*\n` +
            `${vm.badge} *SOUL GRADE:* *${vm.name}* _(${vm.odds} Rarity · ${drawn.remainingInBox}/100 left in box)_\n\n` +
            `🌌 *Awakened Affinities (${drawn.unlockedElements.length}):*\n` +
            `${awakenedList}\n\n` +
            (drawn.unlockedElements.length > 1
              ? `🔥 *RARE BLESSING!* Because you awakened *${drawn.unlockedElements.length} Elements*, you can enter *each* of their Nations' Temples, train each Element from *Lv. 1 → Lv. 10*, and empower all matching Skill Slots!`
              : `🏛️ Travel to your Nation's Temple to meditate (\`${p}affinity train\`) and climb from *Mastery Lv. 1 → Lv. 10*!`) +
            skillNotice
          return player
        })

        return sendImage(ctx, crestKey, finalCard)
      }

      // ── SEALED: MASTER GATE BREAKTHROUGH! ──────────────────────────────
      if (forgeOutcome.sealedKind === 'gate') {
        const snap = forgeOutcome.trialSnapshot
        const elDef = getElementDef(snap.element)
        let msg = ''
        await updatePlayer(ctx.db, ctx.from, (player) => {
          player.affinityTrial = null
          const aff = normalizePlayerAffinity(player)
          const entry = aff.elements[snap.element]
          if (!entry.clearedGates.includes(snap.gateLevel)) entry.clearedGates.push(snap.gateLevel)
          entry.level = Math.min(MAX_MASTERY_LEVEL, snap.gateLevel + 1)
          entry.xp = 0
          entry.masterId = null // Auto-promote to the stronger Avatar Master just defeated!
          const rk = getMasteryRank(entry.level)
          const mst = getCurrentMaster(player, snap.element)
          msg =
            `${forgeOutcome.log}\n\n` +
            `⛩️ *ORDEAL COMPLETE — ${snap.masterName.toUpperCase()} ACKNOWLEDGES YOU!*\n` +
            `${elDef.emoji} *${elDef.name} Mastery:* *Lv. ${entry.level} / ${MAX_MASTERY_LEVEL}* _(${rk.badge} ${rk.name})_\n` +
            `🥋 *New Personal Master:* *${mst.name}* _(Tier ${mst.roman} · +${Math.round(mst.skillBonus * 100)}% Master Skill Power!)_` +
            (entry.level === SUB_BENDING_UNLOCK_LEVEL
              ? `\n🌀 *Sub-Bending Unlocked!* Run \`${p}affinity sub\` inside *${elDef.nationName}*!`
              : '')
          return player
        })
        return replyWithPicture(ctx, masterPortraitKey(snap.masterName) ?? elDef.imageKey, msg)
      }

      // ── SEALED: SUB-BENDING SPECIALIZATION! ────────────────────────────
      if (forgeOutcome.sealedKind === 'sub') {
        const snap = forgeOutcome.trialSnapshot
        const elDef = getElementDef(snap.element)
        let newSubSkills = []
        let leadsHint = ''
        await updatePlayer(ctx.db, ctx.from, (player) => {
          player.affinityTrial = null
          const pEntry = normalizePlayerAffinity(player).elements[snap.element]
          if (!Array.isArray(pEntry.subBendings)) pEntry.subBendings = []
          if (!pEntry.subBendings.includes(snap.subId)) pEntry.subBendings.push(snap.subId)
          pEntry.subBending = snap.subId
          newSubSkills = ensureAffinityBendingSkills(player)

          const sbDef = elDef.subBendings?.[snap.subId]
          if (sbDef?.leadsTo?.length) {
            const nextNames = sbDef.leadsTo.map(id => {
              const nd = elDef.subBendings?.[id]
              return nd ? `${nd.emoji} *${nd.name}*` : id
            }).join(' or ')
            leadsHint = `\n🔓 *Evolution Path Opened:* At *Mastery Lv. ${APEX_SUB_BENDING_UNLOCK_LEVEL}*, this foundation leads into ${nextNames} (\`${p}affinity sub\`)!`
          }
          return player
        })
        const subSkillLine = newSubSkills.length
          ? `\n📜 *New Sub-Bending Form Unlocked:* ${newSubSkills.map((s) => `*${s?.name ?? skillById[s]?.name ?? s}*`).join(', ')} _(Equip via \`${p}skillslot\` or cast with \`${p}bend\`)_`
          : ''
        return replyWithPicture(
          ctx,
          masterPortraitKey(snap.masterName) ?? elDef.imageKey,
          `${forgeOutcome.log}\n\n` +
          `${snap.subEmoji} *SUB-BENDING MASTERED — ${snap.subName.toUpperCase()}!*\n` +
          `Mentor *${snap.masterName}* seals the art into your *${elDef.name}* lineage!` +
          subSkillLine +
          leadsHint,
        )
      }

      // ── SEALED: TEMPLE CHAKRA DRILL! ───────────────────────────────────
      if (forgeOutcome.sealedKind === 'train') {
        const snap = forgeOutcome.trialSnapshot
        const elDef = getElementDef(snap.element)
        let crest = elDef.imageKey
        let msg = ''
        await updatePlayer(ctx.db, ctx.from, (player) => {
          const sealNow = Date.now()
          player.affinityTrial = null
          const aff = normalizePlayerAffinity(player)
          const master = getCurrentMaster(player, snap.element)
          const finalInst = Math.max(0, Math.min(100, Number(snap.forge?.instability) || 0))
          const baseXp = 130 + Math.round((100 - finalInst) * 0.55)
          const award = Math.round(baseXp * (1 + (master?.totalBonus ?? 0.05) * 0.8))

          const xpRes = grantMasteryXp(player, award, { elementId: snap.element, source: 'temple', now: sealNow })
          const liveEntry = aff.elements[snap.element]
          liveEntry.lastTrainAt = sealNow
          liveEntry.templeSessions = (liveEntry.templeSessions ?? 0) + 1
          liveEntry.practiceAtLastTrain = liveEntry.combatPractice ?? 0
          liveEntry.killsAtLastTrain = liveEntry.combatKills ?? 0

          const needed = liveEntry.level >= MAX_MASTERY_LEVEL ? 0 : xpRequiredForMasteryLevel(liveEntry.level)
          const nextPractice = templePracticeProgress(player, snap.element)
          crest = master?.imageKey ?? masterPortraitKey(master?.name) ?? elDef.imageKey
          msg =
            `${forgeOutcome.log}\n\n` +
            `${elDef.emoji} *${elDef.nationName.toUpperCase()} — TEMPLE DRILL SEALED!*\n` +
            `🥋 *${master.name}* _(Tier ${master.roman} · ${100 - finalInst}% Chi Purity)_: *+${xpRes.gained.toLocaleString('en-US')} ${elDef.shortName} Mastery XP*\n` +
            `✨ *${elDef.shortName} Mastery:* *Lv. ${liveEntry.level}/${MAX_MASTERY_LEVEL}*` +
            (liveEntry.level >= MAX_MASTERY_LEVEL
              ? ` *(MAX)*`
              : ` \`[${progressBar(liveEntry.xp, needed)}]\` *${liveEntry.xp.toLocaleString('en-US')}/${needed.toLocaleString('en-US')} XP*`) +
            (xpRes.leveledUp ? `\n🎉 *MASTERY LEVEL UP! Lv. ${xpRes.oldLevel} → Lv. ${xpRes.newLevel}/10!*` : '') +
            (xpRes.unlockedSkills?.length
              ? `\n📜 *New Bending Form Learned:* ${xpRes.unlockedSkills.map((s) => `*${s?.name ?? skillById[s]?.name ?? s}*`).join(', ')}! _(Equip via \`${p}skillslot\` or cast with \`${p}bend\`)_`
              : '') +
            (xpRes.hitGate
              ? `\n\n⛩️ *Master Gate Reached!* Run \`${p}affinity breakthrough\` right here in *${elDef.nationName}* to face *${xpRes.hitGate.name}*!`
              : `\n\n_Next ${elDef.shortName} Temple drill in 6h · Field practice needed first: *${nextPractice.castsReq} casts* or *${nextPractice.killsReq} kills*._`)
          return player
        })
        return replyWithPicture(ctx, crest, msg)
      }
    }

    // ── 10. STRICT PER-ELEMENT TEMPLE TRAINING (.affinity train) ──────────
    if (sub === 'train' || sub === 'meditate' || sub === 'drill') {
      let res = null
      const now = Date.now()
      await updatePlayer(ctx.db, ctx.from, (player) => {
        if (!hasAffinity(player)) {
          res = { err: `🐢 Awaken an Elemental Affinity first (\`${p}affinity\`).` }
          return player
        }
        if (player.inBattle) {
          res = { err: `⚔️ Finish your current battle before entering Temple training!` }
          return player
        }

        if (player.affinityTrial) {
          if (player.affinityTrial.kind === 'train') {
            res = {
              crest: activeTrialPortrait(player.affinityTrial, getElementDef(player.affinityTrial.element)?.imageKey),
              msg: formatChakraForgePrompt(player.affinityTrial, p),
            }
            return player
          }
          res = {
            err: `⚔️ Finish your active *${player.affinityTrial.label}* first (\`${p}affinity trial\` or \`${p}affinity abandon\`).`,
          }
          return player
        }

        const aff = normalizePlayerAffinity(player)
        const locEl = NATION_LOCATION_TO_ELEMENT[player.location] ?? null

        if (!locEl) {
          const roads = getUnlockedElements(player).map((e) => `\`${p}travel ${getElementDef(e).nationId}\``).join(' · ')
          res = {
            err:
              `🏛️ *Temple Training requires standing inside your Element's Nation!*\n` +
              `Travel to your unlocked homeland(s): ${roads}`,
          }
          return player
        }

        // STRICT RULE: Cannot train in a Temple whose Affinity you do not possess!
        if (!aff.elements[locEl]) {
          const targetDef = getElementDef(locEl)
          res = {
            err:
              `🚫 *You do not possess ${targetDef.emoji} ${targetDef.name}!*\n` +
              `No one may train inside *${targetDef.nationName}* without holding *${targetDef.shortName}* Affinity.`,
          }
          return player
        }

        const entry = aff.elements[locEl]
        const elDef = getElementDef(locEl)
        if (entry.level >= MAX_MASTERY_LEVEL) {
          res = { err: `👑 Your *${elDef.name}* Mastery is already maxed at *Lv. 10/10 (Legend of the Nation)*!` }
          return player
        }

        if (isGateLocked(aff, locEl)) {
          const rank = getMasteryRank(entry.level)
          const gm = elDef.gateMasters?.[String(rank.gateAt)]
          res = {
            err:
              `⛩️ *${elDef.name} Lv. ${entry.level} Gate Locked!*\n` +
              `Complete *${gm?.name ?? 'your Gate Master'}'s* Three-Fold Ordeal first with \`${p}affinity breakthrough\`!`,
          }
          return player
        }

        const cdLeft = (entry.lastTrainAt ?? 0) + TEMPLE_TRAIN_COOLDOWN_MS - now
        if (cdLeft > 0) {
          res = { err: `🧘 Your *${elDef.shortName}* meridians are resting. Next *${elDef.nationName}* drill ready in *${fmtCooldown(cdLeft)}*.` }
          return player
        }

        const master = getCurrentMaster(player, locEl)
        const practice = templePracticeProgress(player, locEl)
        if (!practice.ready) {
          res = {
            err:
              `🥋 *${master.name}* blocks the sanctum mat:\n` +
              `_"Temple mastery is forged in real battle, not idle repetition. Temper your ${elDef.shortName} in the field before your next drill."_\n\n` +
              `⚔️ *Field Practice Required (complete either):*\n` +
              `  ▸ ${elDef.shortName} Skills / Bend Casts: *${practice.castsDone} / ${practice.castsReq}*\n` +
              `  ▸ Monsters Slain: *${practice.killsDone} / ${practice.killsReq}* _(Bosses count as 3)_`,
          }
          return player
        }

        player.stamina = refreshStamina(player.stamina)
        if ((player.stamina?.current ?? 0) < TEMPLE_TRAIN_STAMINA_COST) {
          res = {
            err: `⚡ Entering *${master.name}'s* Temple Drill requires *${TEMPLE_TRAIN_STAMINA_COST} Stamina* _(You have ${player.stamina?.current ?? 0}/${player.stamina?.max ?? 30})_.`,
          }
          return player
        }
        player.stamina.current = Math.max(0, (player.stamina.current ?? 0) - TEMPLE_TRAIN_STAMINA_COST)

        const diff = entry.level >= 7 ? 3 : entry.level >= 4 ? 2 : 1
        const scene = elDef.trainingScenes[Math.floor(Math.random() * elDef.trainingScenes.length)]
        player.affinityTrial = {
          kind: 'train',
          element: locEl,
          masterName: master.name,
          scene,
          label: `${elDef.emoji} ${master.name}'s ${elDef.shortName} Drill (Lv.${entry.level})`,
          stage: 'forge',
          forgeDifficulty: diff,
          forge: createChakraForge(diff, { maxTurns: 6 }),
        }

        res = {
          crest: master?.imageKey ?? masterPortraitKey(master?.name) ?? elDef.imageKey,
          msg:
            `⚡ *-${TEMPLE_TRAIN_STAMINA_COST} Stamina* · *${master.name}* _(Tier ${master.roman})_ summons you to the Temple floor!\n\n` +
            formatChakraForgePrompt(player.affinityTrial, p),
        }
        return player
      })

      if (res?.err) return ctx.reply(res.err)
      return replyWithPicture(ctx, res.crest, res.msg)
    }

    // ── 11. MASTERS LINEAGE (.affinity masters / .affinity master <name>) ─
    if (sub === 'masters' || sub === 'master' || sub === 'mentor' || sub === 'lineage') {
      if (!hasAffinity(ctx.player)) {
        return ctx.reply(`🐢 Awaken an Elemental Affinity first (\`${p}affinity\`).`)
      }
      const aff = normalizePlayerAffinity(ctx.player)
      const locEl = NATION_LOCATION_TO_ELEMENT[ctx.player.location]
      const targetEl = (locEl && aff.elements[locEl]) ? locEl : aff.primary
      const elDef = getElementDef(targetEl)
      const query = ctx.args.slice(1).join(' ').trim().toLowerCase()

      if (!query || sub === 'masters' || sub === 'lineage') {
        const allM = getAllElementMasters(targetEl)
        const unlockedIds = new Set(getUnlockedMasters(ctx.player, targetEl).map((m) => m.id))
        const cur = getCurrentMaster(ctx.player, targetEl)

        const rows = allM.map((m) => {
          const isUnl = unlockedIds.has(m.id)
          const isCur = cur?.id === m.id
          const favPts = m.npcId ? Math.max(0, Number(ctx.player?.townFavor?.[m.npcId]?.pts ?? 0)) : 0
          const favTag = isUnl && m.npcId ? ` · Favor: ${favPts}/100` : ''
          const req = m.gateLevel <= 0 ? 'Awakening' : `Clear Lv.${m.gateLevel}→${m.gateLevel + 1} Ordeal`
          return (
            `${isCur ? '🥋' : isUnl ? '✅' : '🔒'} *Tier ${m.roman} — ${m.name}* _(${m.title})_\n` +
            `   Skill Power: *+${Math.round(m.skillBonus * 100)}%* · ${isUnl ? `Unlocked${favTag}` : `Locked (${req})`}`
          )
        })

        return sendImage(
          ctx,
          elDef.imageKey,
          `🥋 *${elDef.name.toUpperCase()} — AVATAR MASTER LINEAGE*\n` +
          `_"The stronger your Master, the stronger your skills become."_\n\n` +
          rows.join('\n\n') +
          `\n\n_Select unlocked Master: \`${p}affinity master <name>\` · Deepen Favor (+up to 8%) via \`${p}talk\` & \`${p}gift\` in *${elDef.nationName}*!_`,
        )
      }

      let switched = null
      await updatePlayer(ctx.db, ctx.from, (player) => {
        const pAff = normalizePlayerAffinity(player)
        const unlocked = getUnlockedMasters(player, targetEl)
        const match = unlocked.find(
          (m) => m.id.includes(query.replace(/[^a-z0-9]+/g, '_')) || m.name.toLowerCase().includes(query),
        )
        if (!match) {
          switched = { err: `❌ Master *"${query}"* is locked or not part of ${elDef.name}. Check \`${p}affinity masters\`.` }
          return player
        }
        pAff.elements[targetEl].masterId = match.id
        const active = getCurrentMaster(player, targetEl)
        switched = {
          img: active.imageKey ?? masterPortraitKey(active.name) ?? elDef.imageKey,
          msg: `🥋 *${elDef.emoji} ${elDef.name} Master Updated!* You now study under *${active.name}* (*Tier ${active.roman} · +${Math.round(active.totalBonus * 100)}% Skill Power*).`,
        }
        return player
      })

      if (switched?.err) return ctx.reply(switched.err)
      return replyWithPicture(ctx, switched.img, switched.msg)
    }

    // ── 12. ABANDON STUCK TRIAL (.affinity abandon) ───────────────────────
    if (sub === 'abandon' || sub === 'cancel') {
      let note = `🕯️ Active Bending Trial abandoned.`
      await updatePlayer(ctx.db, ctx.from, (player) => {
        const t = player.affinityTrial
        if (t?.kind === 'train' && t.element) {
          const liveEntry = normalizePlayerAffinity(player)?.elements?.[t.element]
          if (liveEntry) {
            liveEntry.lastTrainAt = Date.now() - (TEMPLE_TRAIN_COOLDOWN_MS - TEMPLE_TRAIN_BACKLASH_MS)
            note = `🕯️ Temple Drill abandoned — meridians need *2h* to settle before your next drill.`
          }
        }
        player.affinityTrial = null
        return player
      })
      return ctx.reply(note)
    }

    return ctx.reply(
      `🪷 *Avatar Multi-Affinity Commands:*\n` +
      `• \`${p}affinity\` — View your Vessel, Elements (Lv. 1–10), Masters & Crests\n` +
      `• \`${p}affinity box\` — Inspect the Sacred 100-Vessel Box (90% / 5% / 4% / 1%)\n` +
      `• \`${p}affinity trial [element]\` — Start or check your 3-Stage Pilgrimage / Ordeal\n` +
      `• \`${p}affinity answer <a|b|c>\` — Answer Spirit World or Master Doctrine trials\n` +
      `• \`${p}affinity forge <surge|harmonize|ground|lotus>\` — Channel in the Chakra Forge\n` +
      `• \`${p}affinity train\` — Train inside your Element's Nation Temple _(6h CD)_\n` +
      `• \`${p}affinity breakthrough\` — Start a Gate Master's 3-Fold Ordeal\n` +
      `• \`${p}affinity masters\` / \`${p}affinity master <name>\` — View/switch Master\n` +
      `• \`${p}affinity sub [id]\` — Master a Lv.5+ Sub-Bending specialization\n` +
      `• \`${p}affinity primary <element>\` — Switch active element (Duo / Tri / Avatar)\n` +
      `• \`${p}bend\` — Unleash your Signature Bending Art (or *Avatar State* for the 1%!)`,
    )
  },
}
