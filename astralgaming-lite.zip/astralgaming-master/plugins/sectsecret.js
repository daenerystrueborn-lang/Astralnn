/**
 * sectsecret.js — `.secret` / `.secrets` : world secrets and fragments.
 *
 * Six fragments tell why the heavens are dead. A fragment is found by doing
 * the thing its hint points at (lib/sect-world-secrets.js); the reward is paid
 * with the last one, and anything that reward still owed is settled here. So
 * is a fragment that waits on what the reader already is (a rank held, the hall
 * stood in): lib/sect-sects.js secretStandingOf.
 */
import { config } from '../config.js'
import { settlePendingSectHook } from '../lib/sect-commands.js'
import { sectDoorRefusal } from '../lib/world-guards.js'
import {
  SECRETS, describeSecret, secretProgress, settleSecretRewards, secretRewardsPending, titlesOf,
  secretStanding, secretStandingOwed,
} from '../lib/sect-world-secrets.js'
import { secretStandingOf } from '../lib/sect-sects.js'
import { updatePlayer, getPlayer } from '../lib/player-repo.js'

export default {
  name: 'secrets',
  aliases: ['secret', 'lore', 'worldsecret'],
  category: 'sect',
  requiresPlayer: true,
  description: `${config.prefix}secrets — fragments of the truth the world forgot; ${config.prefix}secret <name> for detail`,
  subcommands: [
    { cmd: '<name>', desc: 'detail of one secret (e.g. heavens_are_dead)' },
  ],
  async run(ctx) {
    const wrongWorld = sectDoorRefusal(ctx.player, {
      emoji: '📜', title: '*Secrets lie in the Sect Empire.*',
      here: { cmd: 'story', label: 'Astra tells a different story' },
    })
    if (wrongWorld) return ctx.reply(wrongWorld)
    const pending = await settlePendingSectHook(ctx)
    if (pending) return ctx.reply(pending.join('\n'))

    // Opening the book settles two things. A fragment that waits on something
    // the reader already IS (a rank they hold, the hall they stand in) is
    // found. And a reward that could not be handed over whole when the last
    // fragment was found (or a book completed before rewards were paid at all)
    // is paid.
    let settled = []
    let player = ctx.player
    if (secretRewardsPending(player) || secretStandingOwed(player, secretStandingOf(player))) {
      await updatePlayer(ctx.db, ctx.from, fresh => {
        const now = Date.now()
        settled = [
          ...secretStanding(fresh, secretStandingOf(fresh), { now }),
          ...settleSecretRewards(fresh, { now }),
        ]
        return fresh
      })
      player = getPlayer(ctx.db, ctx.from) ?? player
    }
    const head = settled.length ? [...settled, ''] : []

    const q = (ctx.args ?? []).join(' ').trim().toLowerCase()
    if (q) {
      const found = SECRETS.find(s => s.id === q || s.name.toLowerCase().includes(q) || s.id.includes(q.replace(/\s+/g, '_')))
      if (!found) {
        return ctx.reply([
          ...head,
          `📜 *No secret named "${q}".*`,
          ...SECRETS.map(s => `• *${s.id}* — ${s.name} (${s.fragments?.length ?? 0} fragments)`),
        ].join('\n'))
      }
      const held = player?.sect?.secretFragments?.[found.id] ?? {}
      const texts = Object.keys(held)
        .sort((a, b) => Number(a) - Number(b))
        .map(index => `   _${held[index]?.text ?? ''}_`)
      return ctx.reply([
        ...head,
        describeSecret(found, player),
        ...(texts.length ? ['', '*What you have read so far:*', ...texts] : []),
      ].join('\n'))
    }

    const lines = [...head, `📜 *World Secrets — ${SECRETS.length} known* _(${config.prefix}secret <id> for detail)_`, '']
    for (const s of SECRETS) {
      const prog = secretProgress(player, s.id)
      lines.push(`${s.emoji ?? '📜'} *${s.name}* _(${s.id})_ — ${prog.owned}/${prog.total} fragments${prog.complete ? ' ✅ COMPLETE' : ''}`)
      lines.push(`   _${s.description ?? ''}_`)
    }
    const titles = titlesOf(player)
    if (titles.length) lines.push('', `🎖️ *Titles earned:* ${titles.join(', ')}`)
    lines.push('', `_Each hint names a place or a deed: a cave, a hunting ground, a gate, a rank. Go there, do that._`)
    return ctx.reply(lines.join('\n'))
  },
}
