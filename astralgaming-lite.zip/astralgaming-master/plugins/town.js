/**
 * town.js — walk the streets of whatever town you are standing in.
 *
 *   .town              the streets
 *   .town <place>      walk there
 *
 * Soft. It writes player.townSpot and nothing else. .shop and .inn keep
 * working from anywhere in town. This is not .walk: .roam already answers to that.
 *
 * Every settlement keeps its own street ids (data/town.json), so a word can be
 * a real street of one town and nothing at all in another. When it is, the
 * reply says which town it stands in and how to get there instead of listing
 * the streets the player is already standing next to.
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { replyWithPicture } from '../lib/image.js'
import {
  spotsIn, findSpot, findSpotsElsewhere, npcsAt, townWalkBlock, hasTown,
  townNameOf, roadToTown,
} from '../lib/town.js'
import { noteVisit, heldSlipLine, heldSlipNow } from '../lib/guild-board.js'
import { isInSectEmpire } from '../lib/worlds.js'
import { sectTownCommand } from '../lib/sect-commands.js'

function blockReply(reason, p) {
  if (reason === 'battle') return `⚔️ Finish the fight before you wander town.`
  if (reason === 'dungeon') return `🗺️ You are still in a dungeon.\n_Leave with *${p}dungeon leave*, then walk._`
  return `⚠️ Register first.`
}

/**
 * A word that is not a street HERE. Two different answers hide behind it, and
 * only one of them is a dead end. The street may be real and stand in another
 * town: every slip on the guild board is Astral Town work, so a player holding
 * one in Crownspire who types `.town orchard` has not made a word up, and the
 * old reply (a list of Crownspire ids) told them they had. That answer now
 * names the town, the road to it, and the slip waiting there when there is one.
 */
function noStreetReply(player, query, p) {
  const here = player?.location ?? 'astral_town'
  const local = spotsIn(here).map(s => s.id)
  const elsewhere = findSpotsElsewhere(query, here)
  if (!elsewhere.length) {
    return (
      `🧭 No street called *${query}*.\n` +
      (local.length ? `_Try: ${local.join(', ')}._` : `_This place has no streets. *${p}travel* for the map._`)
    )
  }
  // More than one town can answer to the same word (`gate` is a street in three
  // of them). The slip in your hand picks, because that is the street you meant.
  const wanted = heldSlipNow(player)?.spotId
  const hit = (wanted && elsewhere.find(h => h.spot.id === wanted)) ?? elsewhere[0]
  const road = roadToTown(player, hit.town, p)
  const slip = heldSlipLine(player, hit.spot.id)
  const lines = [
    `🧭 *${hit.spot.name}* is not a street of *${townNameOf(here)}*.`,
    `_It stands in *${townNameOf(hit.town)}*.${slip ? ` ${slip}` : ''}_`,
    road
      ? `*${road}*, then *${p}town ${hit.spot.id}*`
      : `_No road from where you stand reaches it. *${p}travel* for the map._`,
  ]
  // `gate` is a street in three towns. The one above is the answer, the rest are
  // named so the word is not guessed at twice.
  const also = elsewhere.filter(h => h.spot.id !== hit.spot.id)
  if (also.length) {
    lines.push(`_Also: ${also.map(h => `${h.spot.name} in ${townNameOf(h.town)}`).join(', ')}._`)
  }
  if (local.length) lines.push(`\n_Streets here: ${local.join(', ')}._`)
  return lines.join('\n')
}

function listStreets(player, p) {
  const townId = player?.location ?? 'astral_town'
  const here = player?.townSpot
  const spots = spotsIn(townId)
  if (!spots.length) {
    return (
      `🧭 *${townNameOf(townId).toUpperCase()}*\n` +
      `This place has no streets to walk.\n_*${p}travel* to find a town that does._`
    )
  }
  const lines = [
    `🧭 *${townNameOf(townId).toUpperCase()}*`,
    `_The streets, not the menu. Walking here does not lock the shop or the inn._`,
    '',
  ]
  for (const spot of spots) {
    const mark = spot.id === here ? '  ·  you are here' : ''
    const people = npcsAt(spot.id).map(n => n.name).join(', ')
    lines.push(`${spot.emoji} *${spot.name}*${mark}`)
    lines.push(`   _${people}_  ·  *${p}town ${spot.id}*`)
  }
  lines.push('')
  lines.push(`*${p}where*  ·  *${p}talk*  ·  *${p}board*`)
  lines.push(`_Inside an empire, the interior is *${p}goto*, not this._`)
  return lines.join('\n')
}

export default {
  name: 'town',
  aliases: ['streets', 'stroll'],
  category: 'town',
  requiresPlayer: true,
  description: 'Walk the streets of the town you are in and see who is standing there',
  subcommands: [
    { cmd: '<place>', desc: 'walk to a street: square, market, inn, guildhall, pier, and the rest' },
  ],

  async run(ctx) {
    const p = config.prefix
    // A sect mountain is walked with the same command as a town: the halls of
    // the sect the player is standing in, and the door rule between them.
    if (isInSectEmpire(ctx.player)) return sectTownCommand(ctx)
    const query = ctx.args.join(' ').trim()
    if (!query) {
      const firstSpotImg = spotsIn(ctx.player?.location ?? 'astral_town')[0]?.image ?? null
      return replyWithPicture(ctx, firstSpotImg, listStreets(ctx.player, p))
    }

    const blocked = townWalkBlock(ctx.player)
    if (blocked) return ctx.reply(blockReply(blocked, p))

    const spot = findSpot(query, ctx.player.location)
    if (!spot) return ctx.reply(noStreetReply(ctx.player, query, p))

    let note = null
    await updatePlayer(ctx.db, ctx.from, player => {
      player.townSpot = spot.id
      note = noteVisit(player)
      return player
    })

    const people = npcsAt(spot.id)
    const who = people.length
      ? people.map(n => `*${n.name}* _(${n.title})_`).join(', ')
      : '_nobody is waiting_'
    return replyWithPicture(
      ctx,
      spot.image ?? null,
      `${spot.emoji} *You walk to ${spot.name}.*\n` +
      `_${spot.scene}_\n\n` +
      `People here: ${who}\n` +
      `*${p}talk* to speak to them.` +
      (note?.line ? `\n\n${note.line}` : ''),
    )
  },
}
