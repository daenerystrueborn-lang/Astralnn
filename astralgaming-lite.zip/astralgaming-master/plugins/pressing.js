// <prefix>pressing - Evelyn Ling's Pressing. Three uses per dungeon run.
// Replays the last hit she took onto the enemy at 1.2x; each use erases one of
// her own journal memories. docs/season-02-characters/evelyn-ling.md
import { config } from '../config.js'
import { activatePressing } from '../lib/regressor-characters.js'
import { runRegressorCommand } from '../lib/regressor-command-runner.js'

export default {
  name: 'pressing',
  aliases: ['press'],
  category: 'combat',
  description: `${config.prefix}pressing - Evelyn Ling replays a recorded moment. Three per dungeon run, each costs a memory. Confirm with ${config.prefix}pressing confirm.`,
  requiresPlayer: true,
  async run(ctx) { return runRegressorCommand(ctx, activatePressing) },
}
