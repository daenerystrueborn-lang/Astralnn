/**
 * pro.js — .pro on|off
 *
 * Turns a group into a veterans' room: only players at level 100+ may run
 * commands there. Everyone below is refused with a reply (never a kick).
 * Group admins, bot mods and the bot owner bypass the gate entirely — they
 * set the mode and can always lift it with `.pro off`.
 *
 * The flag lives in data/group-settings.json (`proOnly`) and is enforced by
 * the level gate in handler.js (lib/level-gate.js). `.pro` and `.noob` are
 * opposites: turning one on clears the other.
 */
import { config } from '../config.js'
import {
  parseOnOff, saveGroupSettings, saveFailedMessage, settingsStorageLabel, isGroupOrBotOwnerOrMod,
} from '../lib/group-settings.js'
import { NOT_GROUP, NOT_STAFF } from '../lib/group-helpers.js'
import { PRO_MIN_LEVEL } from '../lib/level-gate.js'

export default {
  name:        'pro',
  aliases:     [],
  category:    'group',
  description: `Restrict a group to level ${PRO_MIN_LEVEL}+ players only (.pro on/off)`,

  async run(ctx) {
    const p = config.prefix
    if (!ctx.isGroup) return ctx.reply(NOT_GROUP)
    if (!(await isGroupOrBotOwnerOrMod(ctx))) return ctx.reply(NOT_STAFF)

    const want = parseOnOff(ctx.args[0])
    if (want === null) return ctx.reply(`❌ *Usage:* ${p}pro on|off`)

    const res = await saveGroupSettings(ctx.sender, s => {
      s.proOnly = want
      if (want) s.noobOnly = false
      return s
    })
    if (!res.ok) return ctx.reply(saveFailedMessage('Pro-only mode', res.error))

    const stored = res.settings.proOnly === true
    return ctx.reply(
      `🏆 *Pro-only mode* is now *${stored ? 'ON' : 'OFF'}*.` +
      (stored ? `\nOnly players at *level ${PRO_MIN_LEVEL}+* can use commands here now. Everyone below is refused with a reply — admins and mods are exempt, and can lift it with *${p}pro off*.` : '') +
      `\n_Saved to ${settingsStorageLabel()} — verify any time with ${p}gcsettings._`,
    )
  },
}
