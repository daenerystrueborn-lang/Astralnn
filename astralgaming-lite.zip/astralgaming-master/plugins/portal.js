import { touchDreamlandsActivity } from '../lib/dreamlands-idle.js'
/**
 * portal.js — the door between the Astra Kingdom and the Dreamlands.
 *
 *   <prefix>portal            the door, what it costs, and what it will do to you
 *   <prefix>portal enter      step through (one confirmation, then 10,000 ☀️)
 *   <prefix>portal confirm    the confirmation, inside 60 seconds
 *   <prefix>portal exit       from Cradlehold, pay 10,000 ☀️ and go home
 *   <prefix>portal info       the same explainer as the bare command
 *
 * THE PRICE OF ADMISSION (§4), in full:
 *   5 Gems, once, ever — that is what opens it (`player.portal.unlocked`)
 *   10,000 Solars — every time you step through
 *   10,000 Solars — every time you step back out, paid at Cradlehold
 *
 * ATOMICITY: the payment and the move happen inside ONE updatePlayer() mutator.
 * Every check that can refuse runs BEFORE the mutator on the caller's snapshot,
 * and the mutator re-checks the two that can race against the live record (the
 * wallet and the unlock), so a charge can never happen without the move and the
 * move can never happen without the charge.
 *
 * THE CONFIRMATION. Stepping into a realm where death takes your whole
 * inventory, freezes your body and requires another player to come and get you
 * is not something to do on a typo. The card goes up first; nothing is charged
 * until `portal confirm` inside PORTAL_CONFIRM_MS, and an expired confirmation
 * just shows the card again.
 */

import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import {
  PORTAL_CONFIRM_MS, PORTAL_ENTRY_SOLARS, PORTAL_EXIT_SOLARS, PORTAL_LOCATION_ID,
  PORTAL_UNLOCK_GEMS, SPAWN_PLACE_ID, VOICE, dreamlandsArt, dreamlandsRealm,
  isDreamlandsLocation, noServicesRefusal, DREAMLAND_PLACES, stepsToSpawn,
} from '../lib/dreamlands-core.js'
import { stowCharacterForDreamlands, unstowCharacterFromDreamlands, stowedCharacterName } from '../lib/dreamlands-characters.js'
import { wipeDecay } from '../lib/dreamlands-monsters.js'
import { refreshStamina } from '../lib/combat-engine.js'
import { getPlayer } from '../lib/player-repo.js'
import { creditRescue, isFrozen, reconcileCarry, thawPlayer } from '../lib/dreamlands-death.js'
import { seasonLockdownRefusal } from '../lib/season-engine.js'

const ENTRY_LEVEL = dreamlandsRealm?.portalEntryLevel ?? 100

/** The card, in the realm's voice: what it is, and what it costs. */
function portalCard(player) {
  const p = config.prefix
  const unlocked = player?.portal?.unlocked === true
  return (
    `🌫️ *THE DOOR IN THE SQUARE*\n\n` +
    `_There is a door standing in the middle of Astral Town that nobody built. It is not attached to anything. ` +
    `When the light is right you can see a field through it, and the field is full of lanterns, and the lanterns are all lit._\n\n` +
    `🕯️ _Fog comes out of it, and the fog is warm._\n\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `🚪 *THE DREAMLANDS*\n` +
    `_A wasteland of nightmares. No town. No shop. No inn. Nothing that mends you._\n\n` +
    `*What it asks of you:*\n` +
    `  • *Level ${ENTRY_LEVEL}+*\n` +
    `  • 🔮 *${PORTAL_UNLOCK_GEMS} Gems* — once, to open it  ${unlocked ? '✅' : ''}\n` +
    `  • ☀️ *${PORTAL_ENTRY_SOLARS.toLocaleString()} Solars* — every time you step through\n` +
    `  • ☀️ *${PORTAL_EXIT_SOLARS.toLocaleString()} Solars* — every time you step back out\n\n` +
    `*What it will do to you:*\n` +
    `  • Every nightmare out there sleeps you on contact, and everything it touches decays\n` +
    `  • There is no healing and no shopping past the door\n` +
    `  • ⚠️ *If you die out there, everything you carry dies with you* — gear, bag, chest, home storage. ` +
    `Your Solars, Gems, level, stats, characters, beasts and pets come back with you. Your body does not: ` +
    `it freezes in the Ice Wastelands until another player carries it home.\n\n` +
    (unlocked
      ? `✅ *The door is open to you.*\n_Step through with_ *${p}portal enter*.\n_Or walk away. Nobody would blame you._`
      : `🔒 *The door is shut to you.*\n_Open it with_ *${p}portal enter* _— it will ask you to confirm, and it will not charge you until you do._`) +
    `\n\n_Current place: ${player.location === PORTAL_LOCATION_ID ? 'Astral Town square' : 'not the square'} · ` +
    `❤️ ${player.hp}/${player.maxHp} · ☀️ ${player.wallet?.solars ?? 0} · 🔮 ${player.wallet?.gems ?? 0}_`
  )
}

/** The one-screen warning that stands between a player and the charge. */
function confirmationCard(player, action) {
  const p = config.prefix
  const cost = action === 'enter' ? PORTAL_ENTRY_SOLARS : PORTAL_EXIT_SOLARS
  const gems = player.portal?.unlocked === true ? 0 : PORTAL_UNLOCK_GEMS
  return (
    `⚠️ *CONFIRM — ${action === 'enter' ? 'STEP THROUGH' : 'GO HOME'}*\n\n` +
    (action === 'enter'
      ? `_The fog takes your weight before you decide to move. Beyond it there is no going back without paying again, ` +
        `no inn, no shop, and nothing that heals. If you fall out there, you stay fallen until someone comes for you._\n\n`
      : `_The lanterns let go of you one at a time. Astral Town is on the other side of the same nothing you came through._\n\n`) +
    `💸 *This will charge you:*\n` +
    (gems ? `  • 🔮 ${gems} Gems _(the door, once)_\n` : '') +
    `  • ☀️ ${cost.toLocaleString()} Solars\n\n` +
    `Type *${p}portal confirm* within ${Math.round(PORTAL_CONFIRM_MS / 1000)} seconds to go through.\n` +
    `_Anything else, and the door stays shut and your wallet stays full._`
  )
}

/** Everything a would-be traveller is told before any charge can happen. */
function entryRefusals(player, db) {
  const lockdown = seasonLockdownRefusal(db)
  if (lockdown) return lockdown
  if (player.level < ENTRY_LEVEL) {
    return `🔒 *The door does not open for you yet.*\n_It asks for Level *${ENTRY_LEVEL}*. You are Level *${player.level}*._`
  }
  if (player.location !== PORTAL_LOCATION_ID) {
    return `🗺️ *The door is in the Astral Town square.*\n_You are not standing in it._`
  }
  if (player.inBattle) return `⚔️ *Finish the fight first.*`
  if (isDreamlandsLocation(player.location)) return `🌫️ *You are already past the door.*`
  if (player.stamina?.current < 1) return `⚡ *You are too tired to step through.*`
  return null
}

function hasSolars(player, amount) {
  return (player.wallet?.solars ?? 0) >= amount
}

/** The name of the character the cold took, for the arrival card's receipt. */
function stowReceiptName(player) {
  return stowedCharacterName(player)
}

// ── Enter ──────────────────────────────────────────────────────────────────

async function handleEnter(ctx, { confirmed = false } = {}) {
  const { reply } = ctx
  const player = ctx.player

  const refusal = entryRefusals(player, ctx.db)
  if (refusal) return reply(refusal)

  const unlocked = player.portal?.unlocked === true
  const gemsNeeded = unlocked ? 0 : PORTAL_UNLOCK_GEMS
  const gems = player.wallet?.gems ?? 0
  if (gemsNeeded && gems < gemsNeeded) {
    return reply(
      `🔮 *The door wants ${gemsNeeded} Gems to open for the first time.*\n` +
      `_You have ${gems}. It is not interested in Solars, and it is not interested in why not._`,
    )
  }
  if (!hasSolars(player, PORTAL_ENTRY_SOLARS)) {
    return reply(
      `☀️ *Stepping through costs ${PORTAL_ENTRY_SOLARS.toLocaleString()} Solars.*\n` +
      `_You have ${(player.wallet?.solars ?? 0).toLocaleString()}. The fog waits, but it does not wait for free._`,
    )
  }

  if (!confirmed) {
    await updatePlayer(ctx.db, ctx.from, pl => {
      pl.portalPending = { at: Date.now(), action: 'enter' }
      return pl
    })
    return reply(confirmationCard(player, 'enter'))
  }

  // Confirmed: one mutator, re-checked against the live record.
  let outcome = null
  await updatePlayer(ctx.db, ctx.from, pl => {
    const lockdown = seasonLockdownRefusal(ctx.db)
    if (lockdown) {
      outcome = { ok: false, error: 'lockdown', refusal: lockdown }
      return pl
    }
    if (pl.inBattle) {
      outcome = { ok: false, error: 'battle' }
      return pl
    }
    const fresh = ((pl.wallet?.gems ?? 0) >= (pl.portal?.unlocked ? 0 : PORTAL_UNLOCK_GEMS)) &&
      ((pl.wallet?.solars ?? 0) >= PORTAL_ENTRY_SOLARS) &&
      pl.location === PORTAL_LOCATION_ID
    if (!fresh) {
      outcome = { ok: false, error: 'race' }
      return pl
    }
    pl.wallet = pl.wallet ?? { solars: 0, gems: 0 }
    if (!pl.portal?.unlocked) {
      pl.wallet.gems -= PORTAL_UNLOCK_GEMS
      pl.portal = { unlocked: true, unlockedAt: Date.now(), entries: 0, exits: 0 }
    }
    pl.wallet.solars -= PORTAL_ENTRY_SOLARS
    pl.portal.entries = (pl.portal.entries ?? 0) + 1
    pl.portalPending = null
    pl.stamina = refreshStamina(pl.stamina)
    pl.location = SPAWN_PLACE_ID
    touchDreamlandsActivity(pl, Date.now())
    pl.inDungeon = false
    pl.inBattle = false
    pl.battleState = null
    pl.dungeonFloor = 0
    pl.journey = null
    // The cold takes the character at the door (the owner's amendment): the
    // stow is inside the same mutator as the crossing, so there is no window
    // where a player stands in the realm with a live character.
    stowCharacterForDreamlands(pl)
    outcome = { ok: true, first: (pl.portal.entries ?? 1) === 1 }
    return pl
  })

  if (!outcome?.ok) {
    if (outcome?.refusal) return reply(outcome.refusal)
    return reply(outcome?.error === 'race'
      ? `⚠️ *Something changed while you were confirming.* _No charge was made. Try again._`
      : `⚠️ *You cannot step through right now.*`)
  }

  // The cold's receipt, if there was a character to take.
  const stowedName = ctx.player?.dreamlandsStowedCharacter ? stowReceiptName(ctx.player) : null
  const stowLine = stowedName
    ? `\n❄️ ${VOICE.coldTakesCharacter(stowedName)}\n`
    : ''

  const art = dreamlandsArt('arrival') ?? dreamlandsArt(SPAWN_PLACE_ID)
  const text =
    `🌫️ ━━━━━ *${VOICE.arrivalTitle}* ━━━━━ 🌫️\n\n` +
    VOICE.arrival.map(l => `_${l}_`).join('\n') + `\n\n` +
    VOICE.arrivalRules.map(l => `_${l}_`).join('\n') + `\n\n` +
    `🚪 _The door is not behind you anymore. It is somewhere else now, and it will still want ${PORTAL_EXIT_SOLARS.toLocaleString()} Solars when you find it._\n\n` +
    `⚡ Stamina: *${ctx.player.stamina?.current ?? 0}/${ctx.player.stamina?.max ?? 0}*\n` +
    stowLine +
    `_${VOICE.arrivalFirst}_\n\n` +
    `*${config.prefix}travel lantern_fields* · *${config.prefix}portal info* · *${config.prefix}help*`
  if (art && typeof ctx.replyImage === 'function') {
    await ctx.replyImage(art, text).catch(() => ctx.reply(text).catch(() => {}))
  } else {
    await reply(text)
  }
  return ctx.player
}

// ── Exit ───────────────────────────────────────────────────────────────────

async function handleExit(ctx, { confirmed = false } = {}) {
  const { reply } = ctx
  const player = ctx.player
  if (!isDreamlandsLocation(player.location)) {
    return reply(`🌫️ *There is no door here.*\n_You are already home._`)
  }
  if (player.location !== SPAWN_PLACE_ID) {
    return reply(
      `🚶 *The door is at Cradlehold.*\n` +
      `_You have to walk back to it._ *${config.prefix}travel cradlehold* _(once you are not somewhere worse)._`,
    )
  }
  if (player.inBattle) return reply(`⚔️ *Finish the fight first.*`)
  if (!hasSolars(player, PORTAL_EXIT_SOLARS)) {
    return reply(
      `☀️ *Leaving costs ${PORTAL_EXIT_SOLARS.toLocaleString()} Solars.*\n` +
      `_You have ${(player.wallet?.solars ?? 0).toLocaleString()}. The fog is very sorry about that._`,
    )
  }

  if (!confirmed) {
    await updatePlayer(ctx.db, ctx.from, pl => {
      pl.portalPending = { at: Date.now(), action: 'exit' }
      return pl
    })
    return reply(confirmationCard(player, 'exit'))
  }

  // Is there a body on this rescuer's shoulders? Read before the mutator; the
  // carry is re-validated against the live users map so a stale flag cannot
  // carry a body that someone else already brought home.
  const carriedName = player.carryingBody?.name ?? null
  let carriedJid = player.carryingBody?.jid ?? null
  let carriedRecord = null
  if (carriedName) {
    const users = ctx.db.data.users ?? {}
    carriedRecord = Object.values(users).find(u =>
      (carriedJid && (u.id ?? u.jid) === carriedJid) ||
      (!carriedJid && u.name === carriedName))
    if (carriedRecord) {
      reconcileCarry(users, carriedRecord)
      if (!isFrozen(carriedRecord) || carriedRecord.frozen?.rescuer !== player.name) {
        carriedRecord = null
        carriedJid = null
      } else {
        carriedJid = carriedRecord.id ?? carriedRecord.jid ?? null
      }
    }
  }

  let ok = false
  let rescueCredit = null
  let unstowedName = null
  await updatePlayer(ctx.db, ctx.from, pl => {
    if (pl.location !== SPAWN_PLACE_ID || (pl.wallet?.solars ?? 0) < PORTAL_EXIT_SOLARS) return pl
    pl.wallet.solars -= PORTAL_EXIT_SOLARS
    pl.portal = { ...(pl.portal ?? {}), exits: (pl.portal?.exits ?? 0) + 1 }
    pl.portalPending = null
    pl.location = PORTAL_LOCATION_ID
    touchDreamlandsActivity(pl, Date.now())
    pl.inDungeon = false
    pl.battleState = null
    pl.dungeonFloor = 0
    pl.journey = null
    // Leaving the realm alive ends the decay (§8.6). The Draught stays — that
    // lasts until death, and death is the only thing that ends it.
    wipeDecay(pl)
    // The body comes through with them. The rescuer's own record takes the
    // credit here; the body's record is woken below, AFTER this mutator, so the
    // two writes never nest inside one another (see lib/player-repo.js's queue).
    if (carriedRecord) {
      pl.carryingBody = null
      rescueCredit = creditRescue(pl, { name: carriedName })
    }
    // The cold gives the character back on the way out — same mutator, same
    // no-window rule as the entry stow.
    unstowedName = unstowCharacterFromDreamlands(pl)
    ok = true
    return pl
  })
  if (!ok) return reply(`⚠️ *The door did not take.* _No charge was made._`)

  // ── The body wakes up in the square (unconscious, not frozen) ───────────
  let bodyLine = ''
  if (carriedRecord && carriedJid) {
    let thawed = false
    await updatePlayer(ctx.db, carriedJid, bodyPl => {
      if (!isFrozen(bodyPl) || bodyPl.frozen?.rescuer !== player.name) return bodyPl
      thawPlayer(bodyPl, { by: player.name })
      bodyPl.frozen = null
      delete bodyPl.frozen
      thawed = true
      return bodyPl
    }).catch(() => {})
    if (thawed) {
      bodyLine =
        `\n\n🧊 *${carriedName} comes through with you.*\n` +
        `_They are lying on the stones of the square with their eyes closed and their hands very cold._\n` +
        `_Pour a Revival Drink into them until they wake:_ *${config.prefix}revive ${carriedName}*_._`
    } else {
      bodyLine = `\n\n🧊 _The weight on your shoulders is gone. Whatever you were carrying, it is not there anymore._`
    }
  }
  if (unstowedName) {
    bodyLine += `\n❄️ ${VOICE.coldGivesCharacterBack(unstowedName)}\n`
  }
  if (rescueCredit) {
    bodyLine +=
      `\n\n🕊️ *RESCUE COMPLETE.*\n` +
      `☀️ *+${rescueCredit.reward} Solars* · 🧊 Rescues: *${rescueCredit.count}*` +
      (rescueCredit.titled ? `\n🎖️ Title: *"Frostbreaker"*` : '')
  }

  return reply(
    `🚪 *You step back into Astral Town.*\n\n` +
    `_The square is loud, and warm in the ordinary way, and nobody looks up._\n` +
    `_The fog that came out of the door with you thins and goes._\n\n` +
    `✨ _The decay you were carrying is gone. It does not follow you home._\n` +
    `☀️ Solars: *${ctx.player.wallet?.solars ?? 0}*  ·  🔮 Gems: *${ctx.player.wallet?.gems ?? 0}*` +
    bodyLine
  )
}

// ── Plugin ─────────────────────────────────────────────────────────────────

export default {
  name:           'portal',
  aliases:        ['dreamgate', 'dreamlands'],
  category:       'dungeon',
  requiresPlayer: true,
  description:    `${config.prefix}portal [enter|confirm|exit|info] — the door to the Dreamlands, and the way back out.`,

  subcommands: [
    { cmd: 'enter',   desc: 'step through (requires a confirmation)' },
    { cmd: 'confirm', desc: 'confirm the charge and go' },
    { cmd: 'exit',    desc: 'pay and return to Astral Town from Cradlehold' },
    { cmd: 'info',    desc: 'what the door is, and what it costs' },
  ],

  async run(ctx) {
    const { args, reply, player } = ctx
    const sub = (args[0] ?? '').toLowerCase()

    if (!sub || sub === 'info' || sub === 'status') {
      const art = dreamlandsArt('arrival')
      const text = portalCard(player)
      if (art && typeof ctx.replyImage === 'function') {
        return ctx.replyImage(art, text).catch(() => reply(text))
      }
      return reply(text)
    }

    if (sub === 'enter' || sub === 'go' || sub === 'through') return handleEnter(ctx, { confirmed: false })
    if (sub === 'exit' || sub === 'leave' || sub === 'home') return handleExit(ctx, { confirmed: false })

    if (sub === 'confirm') {
      const pending = player.portalPending
      if (!pending || Date.now() - (pending.at ?? 0) > PORTAL_CONFIRM_MS) {
        return reply(
          `⌛ *Nothing is waiting to be confirmed.*\n` +
          `_Start again with_ *${config.prefix}portal enter* _or_ *${config.prefix}portal exit*_._`,
        )
      }
      return pending.action === 'exit'
        ? handleExit(ctx, { confirmed: true })
        : handleEnter(ctx, { confirmed: true })
    }

    return reply(
      `🚪 *Usage:* *${config.prefix}portal <enter|confirm|exit|info>*\n` +
      `_${noServicesRefusal(player) ? 'Past the door, the fog answers for the bot.' : 'The door is in the Astral Town square.'}_`,
    )
  },
}
