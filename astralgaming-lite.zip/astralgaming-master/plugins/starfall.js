/**
 * starfall.js — 🌠 STARFALL, the Seong-ha character spin.
 *
 *   <prefix>starfall                    the banner card and lifetime spin total
 *   <prefix>starfall <n>                spin n times, paying Gems
 *   <prefix>starfall <n> solar          spin n times, paying Solars
 *   <prefix>starfall info               how the pool works
 *
 * One band is selected per spin, then five slots come from that band. Premium
 * prizes are one-time per player; owned prizes are removed and the rest
 * reweighted. The lifetime spin count never resets.
 */
import { config } from '../config.js'
import { updatePlayer, updateWorldState } from '../lib/player-repo.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import { roundGems } from '../lib/format.js'
import { sendImage } from '../lib/image.js'
import { awardAstralPoints, POINT_VALUES } from '../lib/astral-pass-engine.js'
import {
  ITEMS_PER_SPIN, MAX_SPINS_PER_COMMAND, COST_PER_SPIN, COST_PER_SPIN_SOLARS,
  PREMIUM, BOXES, SOLARS, ensureStarfallState, totalStarfallBoxes,
  costFor, rollStarfall, grantEntry, entryName, entryMark,
} from '../lib/starfall-engine.js'
import { runOpenStarfallBoxFlow } from './season-boxes.js'
import { settlePlayerXp } from '../lib/player-xp.js'

const RULE = '━━━━━━━━━━━━━━━━━━━━'
const BANNER_ART = 'starfall/starfall-banner.jpg'
const BAND_NAMES = Object.freeze({ premium: 'premium', box: 'box', solars: 'solars' })

function parseSpinArgs(args) {
  const words = args.map(a => String(a ?? '').toLowerCase().trim()).filter(Boolean)
  if (!words.length) return { count: null, currency: 'gems' }
  if (words[0] === 'info' || words[0] === 'help') return { info: true }
  const currencyWord = words.find(w => ['solar', 'solars', 'gem', 'gems'].includes(w))
  const countWord = words.find(w => /^\d+$/.test(w))
  if (!countWord) return { invalid: true }
  const currency = currencyWord && ['solar', 'solars'].includes(currencyWord) ? 'solars' : 'gems'
  return { count: Math.floor(Number(countWord)), currency }
}

function reveal(spins) {
  return spins.map((spin) => {
    const items = spin.slots
      .map(({ entry }) => `${entryMark(entry)} ${entryName(entry)}`)
      .join(' · ')
    return `*Spin ${spin.lifetimeSpin} — ${BAND_NAMES[spin.band]}*  ${items}`
  }).join('\n')
}

function bandSummary(spins) {
  const counts = { premium: 0, box: 0, solars: 0 }
  for (const spin of spins) counts[spin.band]++
  return `${counts.premium} premium · ${counts.box} box · ${counts.solars} solars`
}

function bannerCard(player, pr) {
  const state = ensureStarfallState(player)
  const remaining = PREMIUM.filter(entry => !state.premiumsWon.includes(entry.id))
  const boxesHeld = totalStarfallBoxes(player)
  const lines = [
    `🌠 *STARFALL*`,
    RULE,
    `_Seong-ha's spin. Five items shown per spin._`,
    `_One band roll fills all five slots. Premium prizes are one-time only._`,
    ``,
    `💎 *${COST_PER_SPIN} gems*  ·  ☀️ *${COST_PER_SPIN_SOLARS.toLocaleString()} solars* per spin`,
    `_Choose the wallet with: ${pr}starfall 1 solar_`,
    ``,
    `*Premium prizes (${remaining.length} left)*`,
    ...remaining.map(entry => `${entryMark(entry)} ${entryName(entry)}`),
    ``,
    `🎰 Lifetime spins: *${state.spins}*` + (boxesHeld > 0 ? `  ·  📦 Boxes: *${boxesHeld}* _(${pr}openbox)_` : ''),
    ``,
    `▶️ *${pr}starfall 1*  ·  *${pr}starfall 10 solar*  ·  *${pr}openbox*`,
  ]
  return lines.join('\n')
}

function resultCard(spins, state, spending, currency, pr, boxesHeld = 0) {
  const premiumSpins = spins.filter(spin => spin.headline).length
  const allSlots = spins.flatMap(spin => spin.slots)
  const wallet = currency === 'solars' ? `☀️ ${spending.toLocaleString()} Solars` : `💎 ${spending} gems`
  const lines = [
    `🌠 *STARFALL*`,
    RULE,
    reveal(spins),
    ``,
    `_${spins.length} spin${spins.length === 1 ? '' : 's'} · ${allSlots.length} items · paid with ${wallet}._`,
    `Spin types: ${bandSummary(spins)}.`,
  ]
  if (premiumSpins) lines.push(``, `✨ *${premiumSpins} premium-band spin${premiumSpins === 1 ? '' : 's'}.*`)
  lines.push(``, `*What landed*`)
  const tally = new Map()
  for (const slot of allSlots) {
    const key = slot.payout?.granted ?? entryName(slot.entry)
    const note = slot.payout?.note ?? null
    const id = `${key}|${note ?? ''}`
    const current = tally.get(id) ?? { granted: key, note, n: 0 }
    current.n++
    tally.set(id, current)
  }
  for (const item of tally.values()) {
    lines.push(`· ${item.granted}${item.n > 1 ? ` ×${item.n}` : ''}${item.note ? ` _(${item.note})_` : ''}`)
  }
  lines.push(
    ``,
    `Lifetime spins: *${state.spins}*` + (boxesHeld > 0 ? `  ·  📦 Boxes: *${boxesHeld}*` : ''),
    ``,
    `▶️ Again: *${pr}starfall 1*` + (boxesHeld > 0 ? `  ·  Open: *${pr}openbox*` : ''),
  )
  return lines.join('\n')
}

function helpText(pr) {
  return (
    `🌠 *STARFALL* — how it works\n${RULE}\n` +
    `💎 *${COST_PER_SPIN} gems* or ☀️ *${COST_PER_SPIN_SOLARS.toLocaleString()} solars* per spin. Choose with *${pr}starfall 1 solar*. Each spin shows *${ITEMS_PER_SPIN} items*.\n\n` +
    `🎲 One band is rolled per spin: premium, box, or mini Solars packs.\n\n` +
    `✨ Premium prizes are one-time only. Their odds stay hidden — but winning one never resets your spin counters.\n\n` +
    `✨ Premium prizes are one-time only. Owned prizes leave the pool and the rest reweight. When all ${PREMIUM.length} are owned, Starfall is complete for you.\n\n` +
    `☀️ Mini Solars packs can appear in Solars and box spins.\n\n` +
    `▶️ *${pr}starfall 1*  ·  *${pr}starfall 10 solar*  ·  *${pr}starfall info*`
  )
}

export default {
  name: 'starfall',
  aliases: ['sf', 'star-fall'],
  category: 'character',
  requiresPlayer: true,
  description: `STARFALL — ${ITEMS_PER_SPIN} items per spin. ${COST_PER_SPIN} gems or ${COST_PER_SPIN_SOLARS.toLocaleString()} solars`,
  subcommands: [
    { cmd: '', desc: 'the banner card and lifetime spin count' },
    { cmd: '<n>', desc: `spin n times (1-${MAX_SPINS_PER_COMMAND}), paying Gems` },
    { cmd: '<n> solar', desc: 'spin n times, paying Solars' },
    { cmd: 'boxes [type|all] [n]', desc: 'view or open your Starfall boxes' },
    { cmd: 'info', desc: 'how Starfall works' },
  ],

  async run(ctx) {
    const pr = config.prefix
    const firstArg = String(ctx.args?.[0] ?? '').toLowerCase().trim()
    if ((firstArg === 'open' || firstArg === 'close') && ctx.from && isOwnerJid(ctx.from) && ctx.args?.length === 1) {
      const lock = firstArg === 'close'
      await updateWorldState(ctx.db, 'starfall-lock', (data) => {
        data.starfallLocked = lock
        data.starfallReopened = true
      })
      return ctx.reply(lock ? '🔒 *Starfall is now closed.*' : '🌠 *Starfall is now open.*')
    }
    if (!ctx.player) return ctx.reply(`⚠️ Register first with *${pr}register*.`)
    if (firstArg === 'box' || firstArg === 'boxes' || (firstArg === 'open' && ctx.args?.length > 1)) {
      return runOpenStarfallBoxFlow(ctx, (ctx.args ?? []).slice(1))
    }
    if (ctx.db?.data?.starfallLocked) return ctx.reply(`🌠 *Starfall is closed.*`)
    const parsed = parseSpinArgs(ctx.args)
    if (parsed.info) return sendImage(ctx, BANNER_ART, helpText(pr))
    if (!parsed.count && parsed.count !== null) {
      return ctx.reply(
        `❌ *${pr}starfall <n>* takes a number of spins.\n` +
        `Try *${pr}starfall 1*, *${pr}starfall 10 solar*, or *${pr}starfall info*.`,
      )
    }

    const state = ensureStarfallState(ctx.player)
    if (state.premiumsWon.length >= PREMIUM.length) {
      return sendImage(ctx, BANNER_ART,
        `🌠 *STARFALL COMPLETE*\n${RULE}\nYou own all ${PREMIUM.length} premium prizes. Starfall has ended for you.\n_Lifetime spins: ${state.spins}._`)
    }
    if (parsed.count === null) return sendImage(ctx, BANNER_ART, bannerCard(ctx.player, pr))

    const count = parsed.count
    if (count < 1 || count > MAX_SPINS_PER_COMMAND) {
      return ctx.reply(`❌ *1-${MAX_SPINS_PER_COMMAND} spins at a time.*`)
    }

    const currency = parsed.currency
    const spending = costFor(count, currency)
    let outcome = null

    await updatePlayer(ctx.db, ctx.from, (player) => {
      const current = ensureStarfallState(player)
      if (current.premiumsWon.length >= PREMIUM.length) {
        outcome = { reason: 'complete' }
        return
      }
      player.wallet = player.wallet ?? {}
      const balance = currency === 'solars'
        ? Math.floor(Number(player.wallet.solars) || 0)
        : Number(player.wallet.gems) || 0
      if (balance < spending) {
        outcome = { reason: 'poor', need: spending, have: balance, currency }
        return
      }
      if (currency === 'solars') player.wallet.solars = balance - spending
      else player.wallet.gems = roundGems(balance - spending)

      const results = rollStarfall(count, current.spins, Math.random, current, currency)
      const paid = results.map(spin => ({
        ...spin,
        slots: spin.slots.map(entry => ({ entry, payout: grantEntry(player, entry) })),
      }))
      const liveState = ensureStarfallState(player)
      for (const spin of paid) {
        if (!spin.headline) continue
        for (const slot of spin.slots) {
          if (
            slot.entry.band === 'premium' &&
            slot.payout?.failed !== true &&
            !liveState.premiumsWon.includes(slot.entry.id)
          ) {
            liveState.premiumsWon.push(slot.entry.id)
          }
        }
      }
      liveState.spins += count
      if (currency === 'solars') {
        liveState.solarsSpins = (liveState.solarsSpins ?? 0) + count
        liveState.solarsSpent = (liveState.solarsSpent ?? 0) + spending
      } else {
        liveState.gemsSpins = (liveState.gemsSpins ?? 0) + count
        liveState.gemsSpent = roundGems((liveState.gemsSpent ?? 0) + spending)
      }

      awardAstralPoints(player, POINT_VALUES.spin * count, 'starfall')
      outcome = {
        reason: 'ok',
        results: paid,
        spending,
        currency,
        state: { ...liveState },
        boxesHeld: totalStarfallBoxes(player),
        lvlMsgs: settlePlayerXp(player).msgs ?? [],
      }
    })

    if (outcome.reason === 'complete') return ctx.reply(`🌠 Starfall is already complete for you.`)
    if (outcome.reason === 'poor') {
      const label = outcome.currency === 'solars' ? `☀️ ${outcome.need.toLocaleString()} Solars` : `💎 ${outcome.need} gems`
      const have = outcome.currency === 'solars' ? `☀️ ${outcome.have.toLocaleString()}` : `💎 ${outcome.have}`
      return ctx.reply(`Not enough. ${label} needed for ${count} spin${count === 1 ? '' : 's'}, you have *${have}*.`)
    }
    const caption = resultCard(outcome.results, outcome.state, outcome.spending, outcome.currency, pr, outcome.boxesHeld) +
      (outcome.lvlMsgs?.length ? `\n\n${outcome.lvlMsgs.join('\n')}` : '')
    return (outcome.results.some(spin => spin.headline) || outcome.results.some(spin => spin.slots.some(s => s.entry.band === 'premium')))
      ? sendImage(ctx, BANNER_ART, caption)
      : ctx.reply(caption)
  },
}
