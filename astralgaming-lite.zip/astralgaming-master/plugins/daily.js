/**
 * daily — claim a once-per-day reward of Solars, XP, and stamina.
 *
 * Usage: <prefix>daily
 *
 * Resets at midnight (local server time). Consecutive-day claims build a
 * streak (bonus grows daily, caps at 7 days); missing a full day resets the
 * streak back to 1 on the next claim.
 *
 * STREAK MILESTONES: on top of the per-day streak bonus, hitting key
 * thresholds (3, 7, 14, 30, 60, 100 days) pays a one-time bonus reward
 * including Solars, XP, and gems. Tracked in player.streakMilestones to
 * prevent double-claiming. The raw dailyStreak (uncapped) triggers these.
 *
 * ALSO the live owner of the `.claim` key: 'claim' is this plugin's alias, and
 * the loader hands a same-platform alias collision to the LAST plugin
 * registered (lib/plugin-manager.js resolvePlugin), which — with the loader
 * visiting files in sorted order — is deterministically this one rather than
 * plugins/claim.js. So `.claim` lands here. Since `.claim
 * <code>` is how a spawned card/series gets grabbed, a typed claim code is
 * routed on to the shared spawn-claim helper below instead of being ignored —
 * otherwise a player's code silently buys them a daily reward and the spawn
 * stays on the floor. A bare `.claim`/`.daily` is the daily reward, unchanged.
 */
import { premiumDailyGems, premiumDailyLine } from '../lib/premium-perks.js'
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { kingdomDoorRefusal } from '../lib/world-guards.js'
import { levelsData, classes, races, getTotalStats } from '../lib/game-data.js'
import { applyLevelUps } from '../lib/combat-engine.js'
import { sendRankUp } from '../lib/rank-up.js'
import { claimActiveSpawn, looksLikeClaimCode } from './collect.js'
// Tutorial hook — daily claim counts as a tutorial step
import { recordTutorialEvent, tutorialNotice } from '../lib/tutorial-engine.js'
import { refreshClash, clashDailyLine } from '../lib/guild-clash.js'
import { awardAstralPoints, POINT_VALUES } from '../lib/astral-pass-engine.js'
import { recordFaucet } from '../lib/economy-ledger.js'
import { styledPanel } from '../lib/orv-style.js'

const BASE_SOLARS        = 50
const PER_LEVEL_SOLARS   = 3
const STREAK_BONUS_PER_DAY = 15
const STREAK_CAP         = 7
const STAMINA_RESTORE    = 10
const BASE_XP            = 20
const XP_PER_LEVEL       = 2

/**
 * STREAK MILESTONES — bonus rewards at key streak thresholds.
 * These are one-time bonuses paid on top of the normal daily reward
 * when the streak first reaches each milestone. Tracked in
 * player.streakMilestones = [3, 7, ...] to prevent double-claiming.
 * The streak counter itself caps its Solars bonus at STREAK_CAP (7),
 * but the LIFETIME streak (player.dailyStreak can keep growing past 7)
 * triggers these milestone payouts.
 */
const STREAK_MILESTONES = [
  { days: 3,  solars: 150, xp: 50,  gems: 0,  label: '3-Day Streak',  emoji: '🔥' },
  { days: 7,  solars: 500, xp: 150, gems: 3,  label: '1-Week Streak', emoji: '🔥🔥' },
  { days: 14, solars: 1000, xp: 300, gems: 5, label: '2-Week Streak', emoji: '🔥🔥🔥' },
  { days: 30, solars: 2500, xp: 500, gems: 10, label: '1-Month Streak', emoji: '💎🔥💎' },
  { days: 60, solars: 5000, xp: 1000, gems: 20, label: '2-Month Streak', emoji: '👑💎👑' },
  { days: 100, solars: 10000, xp: 2000, gems: 50, label: '100-Day Streak', emoji: '🌟👑🌟' },
]
const MILESTONE_MAP = Object.fromEntries(STREAK_MILESTONES.map(m => [m.days, m]))

function startOfDay(ts) {
  const d = new Date(ts)
  d.setHours(0, 0, 0, 0)
  return d.getTime()
}

export default {
  name:           'daily',
  aliases:        ['claim'],
  category:       'economy',
  requiresPlayer: true,
  description:    'Claim your daily Solars, XP, and stamina reward',

  async run(ctx) {
    const p = config.prefix

    // ── `.claim <code>` — a spawn claim, not a daily claim ──────────────
    const codeArg = (ctx.args?.[0] ?? '').trim()
    if (looksLikeClaimCode(codeArg)) return claimActiveSpawn(ctx, codeArg)

    const wrongWorld = kingdomDoorRefusal(ctx.player, {
      emoji: '📅', title: '*The Astra daily pays Solars, back in the kingdom.*',
      instead: { cmd: 'tasks', label: 'the Mission Hall board is the mountain’s day board' },
    })
    if (wrongWorld) return ctx.reply(wrongWorld)

    let outcome = null
    let outcome_astral = null
    let tutorialResult = null
    let premiumGems = 0

    await updatePlayer(ctx.db, ctx.from, player => {
      const now          = Date.now()
      const todayStart   = startOfDay(now)
      const last         = player.lastDailyClaim ?? 0
      const lastDayStart = last ? startOfDay(last) : null

      if (lastDayStart === todayStart) {
        const next = new Date(todayStart + 24 * 60 * 60 * 1000)
        outcome = { already: true, next }
        return player
      }

      const yesterdayStart = todayStart - 24 * 60 * 60 * 1000
      const isConsecutive  = lastDayStart === yesterdayStart

      player.dailyStreak    = isConsecutive ? (player.dailyStreak ?? 0) + 1 : 1
      player.lastDailyClaim = now

      const streakDays   = Math.min(player.dailyStreak ?? 1, STREAK_CAP)
      const solarsReward = BASE_SOLARS + player.level * PER_LEVEL_SOLARS + streakDays * STREAK_BONUS_PER_DAY
      const xpReward     = BASE_XP + player.level * XP_PER_LEVEL

      if (!player.wallet) player.wallet = {}
      player.wallet.solars = (player.wallet.solars ?? 0) + solarsReward
      player.xp = (player.xp ?? 0) + xpReward

      // ── Streak milestone check ──────────────────────────────────────
      // If the streak just reached a milestone threshold AND this milestone
      // hasn't been claimed before, pay the bonus. The raw dailyStreak
      // (uncapped) is what triggers milestones, so a 14-day streak fires
      // even though the Solars bonus capped at 7.
      let milestoneHit = null
      const rawStreak = player.dailyStreak ?? 1
      if (!Array.isArray(player.streakMilestones)) player.streakMilestones = []
      const milestone = MILESTONE_MAP[rawStreak]
      if (milestone && !player.streakMilestones.includes(rawStreak)) {
        player.streakMilestones.push(rawStreak)
        player.wallet.solars = (player.wallet.solars ?? 0) + milestone.solars
        player.xp = (player.xp ?? 0) + milestone.xp
        if (milestone.gems > 0) {
          player.wallet.gems = (player.wallet.gems ?? 0) + milestone.gems
        }
        milestoneHit = milestone
      }

      // 👑 Premium bonus: gems on every claim. This is the perk that replaced
      // DM access on 2026-11-01 (lib/premium-perks.js) — read at claim time, so
      // turning Premium on or off takes effect on the next daily.
      premiumGems = premiumDailyGems(player)
      if (premiumGems > 0) {
        player.wallet.gems = (player.wallet.gems ?? 0) + premiumGems
      }

      // Track the longest streak ever achieved (for achievements/leaderboards)
      if (!player.bestDailyStreak || rawStreak > player.bestDailyStreak) {
        player.bestDailyStreak = rawStreak
      }

      // ── Tutorial hook ──────────────────────────────────────────────
      tutorialResult = recordTutorialEvent(player, 'daily_claimed')

      const { msgs: lvlMsgs, rankChange } = applyLevelUps(player, levelsData, classes, races, getTotalStats)

      let staminaAfter = player.stamina?.current ?? 0
      if (player.stamina) {
        player.stamina.current = Math.min(player.stamina.max, player.stamina.current + STAMINA_RESTORE)
        staminaAfter = player.stamina.current
      }

      // 🌠 Astral Pass — claiming the daily is worth points, for the same
      // reason it is worth solars: it is the habit the pass wants to reward.
      outcome_astral = awardAstralPoints(player, POINT_VALUES.daily, 'daily')

      // G4 economy ledger: the daily is a major faucet, count it once.
      recordFaucet(ctx.db, 'daily', {
        solars: solarsReward + (milestoneHit?.solars ?? 0),
        gems: milestoneHit?.gems ?? 0,
      })

      outcome = {
        already: false,
        solarsReward,
        xpReward,
        astral: outcome_astral,
        streak: player.dailyStreak,
        staminaAfter,
        staminaMax: player.stamina?.max ?? '?',
        lvlMsgs,
        rankChange,
        playerName: player.name,
        milestoneHit,
        premiumGems,
        bestDailyStreak: player.bestDailyStreak ?? player.dailyStreak,
      }
      return player
    })

    if (outcome.already) {
      const legacy = `⏳ You've already claimed today's reward.\nCome back after *${outcome.next.toLocaleTimeString()}*.`
      return ctx.reply(styledPanel(ctx.db, {
        emoji: '⏳',
        title: 'Already Claimed',
        blocks: [[`Today's reward is settled.`, `Next claim *${outcome.next.toLocaleTimeString()}*`]],
        footer: ['quest', 'gate'],
      }, legacy))
    }

    // 👑 Premium's daily line (the perk that replaced DM access). Rendered
    // from the gems actually granted, so it can never claim more than paid.
    const premiumLine = premiumDailyLine(ctx.player, outcome.premiumGems ?? 0)

    // ── Next milestone hint ───────────────────────────────────────────
    const nextMilestone = STREAK_MILESTONES.find(m => m.days > outcome.streak)
    const nextHint = nextMilestone
      ? `\n\n_${nextMilestone.emoji} ${nextMilestone.label} bonus at day ${nextMilestone.days}!_`
      : ''

    // The Guild Clash draw is random, so nobody asked to be in it: the daily claim
    // is the one command nearly everybody sends, so it is where a champion hears
    // the bot picked them. One more line on the same message, nothing sent extra.
    let clashLine = null
    if (ctx.player?.guildId) {
      try {
        await refreshClash(ctx.db)
        clashLine = clashDailyLine(ctx.db, ctx.player, { prefix: config.prefix })
      } catch { /* the daily reward never waits on the Clash */ }
    }

    const caption =
      `☀️ Solars: *+${outcome.solarsReward}*\n` +
      `✨ XP: *+${outcome.xpReward}*\n` +
      `⚡ Stamina: *+${STAMINA_RESTORE}* _(now ${outcome.staminaAfter}/${outcome.staminaMax})_\n\n` +
      `🔥 Streak: *${outcome.streak} day${outcome.streak === 1 ? '' : 's'}*` +
      (outcome.streak < STREAK_CAP ? ` _(bonus grows until day ${STREAK_CAP})_` : ` _(max streak bonus)_`) +
      (outcome.lvlMsgs.length ? `\n\n${outcome.lvlMsgs.join('\n')}` : '') +
      // 🌠 Only shown when points actually landed — a player already on the
      // daily cap should not read "+15 Astral points" for points they did not
      // receive (awardAstralPoints' `gained`, never the face-value constant).
      (outcome.astral?.gained
        ? `\n\n🌠 *Astral Pass*: +${outcome.astral.gained} points · tier *${outcome.astral.tier}*`
          + (outcome.astral.capped ? `\n_Daily cap reached — points resume tomorrow._` : '')
        : outcome.astral?.capped
          ? `\n\n🌠 _Astral Pass daily cap reached — points resume tomorrow._`
          : '') +
      nextHint +
      (premiumLine ? `\n\n${premiumLine}` : '') +
      (clashLine ? `\n\n${clashLine}` : '') +
      (tutorialResult ? `\n\n${tutorialNotice(tutorialResult, p)}` : '') +
      `\n\n_Come back tomorrow to keep your streak alive!_`

    // ── The System window (Season 2) ────────────────────────────────────────
    // Same numbers, same lines, one voice: while the ORV season runs the daily
    // wears the brackets and the System font the quest board and the gate cards
    // already wear. With no season running the legacy card is sent untouched.
    const legacyDaily = `🎁 *Daily Reward Claimed!*\n\n${caption}`
    const dailyText = styledPanel(ctx.db, {
      emoji: '🎁',
      title: 'Daily Reward',
      subtitle: `Streak ${outcome.streak} day${outcome.streak === 1 ? '' : 's'} · ${outcome.playerName ?? 'Hunter'}`,
      blocks: [
        [
          `☀️ *+${outcome.solarsReward}* Solars`,
          `📈 *+${outcome.xpReward}* XP`,
          `⚡ *+${STAMINA_RESTORE}* Stamina · now *${outcome.staminaAfter}/${outcome.staminaMax}*`,
        ],
        outcome.lvlMsgs.length ? outcome.lvlMsgs.join('\n') : null,
        outcome.astral?.gained
          ? `🌠 Astral Pass *+${outcome.astral.gained}* · tier *${outcome.astral.tier}*${outcome.astral.capped ? '\n_Daily cap reached. Points resume tomorrow._' : ''}`
          : outcome.astral?.capped ? '🌠 _Astral Pass daily cap reached. Points resume tomorrow._' : null,
        premiumLine || null,
        clashLine || null,
        nextHint ? nextHint.replace(/^\n\n/, '').replace(/^_|_$/g, '') : null,
        tutorialResult ? tutorialNotice(tutorialResult, p) : null,
      ],
      footer: ['daily', 'quest'],
    }, legacyDaily)
    await ctx.reply(dailyText)

    // Rank promotion — separate message so it stands out (dedicated rank-up card)
    if (outcome.rankChange) {
      await sendRankUp(ctx, outcome.playerName ?? 'Hunter', outcome.rankChange.from, outcome.rankChange.to)
    }

    // ── Streak milestone celebration (separate message) ──────────────
    if (outcome.milestoneHit) {
      const m = outcome.milestoneHit
      const parts = []
      if (m.solars) parts.push(`☀️ +${m.solars} Solars`)
      if (m.xp) parts.push(`✨ +${m.xp} XP`)
      if (m.gems) parts.push(`💎 +${m.gems} Gems`)

      // Find the next milestone after this one
      const afterThis = STREAK_MILESTONES.find(ms => ms.days > outcome.streak)
      const nextLine = afterThis
        ? `\n\n_Next milestone: ${afterThis.emoji} ${afterThis.label} (day ${afterThis.days})_`
        : `\n\n_All streak milestones reached._`

      const legacyMilestone =
        `${m.emoji} *MILESTONE: ${m.label}!*\n\n` +
        `Bonus Reward:\n${parts.join('\n')}` +
        nextLine
      await ctx.reply(styledPanel(ctx.db, {
        emoji: m.emoji,
        title: `Streak Milestone · ${m.label}`,
        blocks: [
          parts.join('\n'),
          nextLine ? nextLine.replace(/^\n\n/, '').replace(/^_|_$/g, '') : null,
        ],
        footer: ['daily', 'quest'],
      }, legacyMilestone))
    }
  },
}
