/**
 * menu — the ten-section command map, auto-built from the plugin registry.
 * No hardcoded command list.
 *   <prefix>menu                 → the ten sections
 *   <prefix>menu <section>      → every command in that section
 * Aliases: help, commands — prefix is config.prefix, never hardcoded.
 *
 * ── Why ten and not twenty-four (2026-09-21 rework) ─────────────────────────
 * The overview used to list one line per plugin CATEGORY: 24 of them, with
 * thin ones like "Season Packs" (1 command) sitting beside "Combat" (40).
 * That is not how the game is played: nobody hunts for "Progression", they
 * hunt for their character, their fights, their season. So the overview is
 * now exactly TEN sections, and the old categories survive as SUB-SECTIONS
 * inside the drill-downs, which is where the answer to "why is Season Packs
 * separate from Season?" lives: it isn't anymore. `.menu Season` shows the
 * Season commands, the Season Packs commands, and the Events commands, under
 * their own little headers. `.menu season packs` still finds it too, because
 * every folded name still matches.
 *
 * SUBCOMMAND EXPANSION: a plugin can optionally export a `subcommands`
 * array on its default export — [{ cmd: 'give <n> @user', desc: 'gift a
 * card' }, ...] — and the drill-down lists each one indented under that
 * plugin's entry. Opt-in and additive: plugins without `subcommands` render
 * name + one description line. See plugins/card.js for the convention.
 */
import { existsSync } from 'fs'
import { dirname, join } from 'path'
import { fileURLToPath } from 'url'
import { listKingdomPluginsFor } from '../lib/plugin-manager.js'
import { config } from '../config.js'
import { sendImage } from '../lib/image.js'
import { playerSubcommands, cleanCopy, scorePluginQuery, isOwnerCommand } from '../lib/command-list.js'
import { fuzzyMatchScore } from '../lib/fuzzy.js'
import { isInSectEmpire } from '../lib/worlds.js'
import { sectHelpLines } from '../lib/sect-help.js'

// Per-instance banner: the whole menu (overview AND every section
// drill-down) shows ONE image depending on which of the bot's two numbers
// answered. Mirrors instanceIdentity's sun/moon detection below.
//
// Both numbers currently point at the same 2026-10 menu banner, at the owner's
// request (it replaced Icon.png on 2026-10-24).
// The two constants are kept separate on purpose rather than collapsed into
// one: if the numbers ever want different art again, it is a one line change
// here and nothing else in this file moves.
const MENU_ICON   = 'https://i.ibb.co/0jkMrkXS/menu-2026-10-24-04-16-13-393126.webp'
const SUN_BANNER  = MENU_ICON
const MOON_BANNER = MENU_ICON
// Fallback if botName is ever neither (shouldn't happen with the two
// configured numbers, but keeps sendImage from getting a bad url).
const MENU_BANNER = SUN_BANNER

/**
 * Telegram's own menu art.
 *
 * Telegram does not inherit the WhatsApp banner on purpose: its menu is a
 * photo with TAPPABLE sections (see telegramOverview below), and the owner
 * supplied this icon for that card. Percent-encoded filename kept verbatim —
 * decoding it would change the CDN path.
 */
const TELEGRAM_MENU_ART_REMOTE =
  'https://i.postimg.cc/1tLWH45W/%F0%9D%97%9C%F0%9D%97%96%F0%9D%97%A2%F0%9D%97%A1-tu-biao.jpg'

/**
 * Local copies win over the remote one.
 *
 * The remote icon lived on a free image host that neither Telegram's fetchers
 * nor the bot's own server could reach, and Telegram's answer to an
 * unreachable URL is to reject the whole photo — the menu arrived with its
 * caption and its buttons but no picture. A file in the repo always works:
 * no DNS, no CDN, no third party that can move or expire.
 *
 * Drop the artwork at the FIRST path below (any of .jpg / .png / .webp) and it
 * is used automatically; until one exists the remote URL is still tried.
 * `lib/assets/ui/telegram-menu.jpg` ships with a built-in emblem, so replace
 * that file to change the picture.
 */
const __menuDir = dirname(fileURLToPath(import.meta.url))
const TELEGRAM_MENU_ART_LOCAL = [
  'telegram-menu.jpg',
  'telegram-menu.png',
  'telegram-menu.webp',
].map((f) => join(__menuDir, '..', 'lib', 'assets', 'ui', f))

const TELEGRAM_MENU_ART = TELEGRAM_MENU_ART_LOCAL.find((p) => existsSync(p)) ?? TELEGRAM_MENU_ART_REMOTE

function bannerFor(botName) {
  const n = (botName ?? '').toLowerCase()
  if (n.includes('moon')) return MOON_BANNER
  if (n.includes('sun'))  return SUN_BANNER
  return MENU_BANNER
}

/**
 * The ten sections, in overview order. Each carries the sub-sections it
 * absorbed: `cat` is the plugin's raw `category` value (the registry keeps
 * tagging exactly as before, this is purely presentation), `label` is the
 * header the drill-down groups under. A plugin whose category matches no
 * sub anywhere falls into Utility's Misc sub, so a future category can
 * never orphan itself out of the menu.
 */
export const SECTIONS = [
  {
    key: 'adventurer', emoji: '🧳', label: 'Adventurer',
    blurb: 'Your identity in the Sun World: profile, quests, and the people you share it with.',
    subs: [
      { cat: 'account',     label: 'Adventurer' },
      { cat: 'progression', label: 'Progression' },
      { cat: 'social',      label: 'Social' },
    ],
  },
  {
    key: 'character', emoji: '🎭', label: 'Character',
    blurb: 'Spin for and claim iconic characters and anime cards to fight beside you.',
    subs: [
      { cat: 'character', label: 'Character' },
      { cat: 'cards',     label: 'Cards' },
    ],
  },
  {
    key: 'pokemon', emoji: '🐾', label: 'Pokémon',
    blurb: 'Wild Pokémon roam the Astra Kingdom too: catch them, raise them, evolve them, battle them.',
    subs: [
      { cat: 'pokemon',   label: 'Pokémon' },
      { cat: 'evolution', label: 'Evolution' },
    ],
  },
  {
    key: 'combat', emoji: '⚔️', label: 'Combat',
    blurb: 'Where blades meet, glory is forged. Elemental Bending, monsters, bosses, party runs, and duels.',
    subs: [
      { cat: 'combat',  label: 'Combat' },
      { cat: 'bending', label: 'Elemental Bending & Four Nations' },
      { cat: 'battle',  label: 'Battle' },
      { cat: 'party',   label: 'Party' },
      { cat: 'pvp',     label: 'PvP' },
    ],
  },
  {
    key: 'dungeon', emoji: '🗺️', label: 'Dungeon',
    blurb: 'Deep beneath Astral, ancient rifts hide treasure and terror in equal measure. The story unfolds on the way down.',
    subs: [
      { cat: 'dungeon', label: 'Dungeon' },
      { cat: 'story',   label: 'Story' },
    ],
  },
  {
    key: 'economy', emoji: '💰', label: 'Economy',
    blurb: 'Solars make the world go round: pay, tip, bank, trade, and carry everything you earn.',
    subs: [
      { cat: 'economy',   label: 'Economy' },
      { cat: 'inventory', label: 'Inventory' },
      { cat: 'town',      label: 'Town' },
    ],
  },
  {
    key: 'empire', emoji: '🏰', label: 'Empire',
    blurb: 'Found your own empire, raise it up, and rule it. Build rooms, furnish them, and make a home of it.',
    subs: [
      { cat: 'empire',  label: 'Empire' },
      { cat: 'housing', label: 'Housing' },
    ],
  },
  {
    key: 'season', emoji: '🌸', label: 'Season',
    blurb: 'All things seasonal in one place: passes, checkpoints, packs, limited spins, and the events that come with them.',
    subs: [
      { cat: 'season', label: 'Season' },
      { cat: 'packs',  label: 'Season Packs' },
      { cat: 'event',  label: 'Events' },
    ],
  },
  {
    key: 'sanctum', emoji: '🛠️', label: 'Sanctum',
    blurb: 'The caretaker layer: group tools, moderation, and the controls kept behind the scenes.',
    subs: [
      { cat: 'group',      label: 'Group' },
      { cat: 'moderation', label: 'Moderation' },
      { cat: 'admin',      label: 'Sanctum' },
    ],
  },
  {
    key: 'utility', emoji: '🔧', label: 'Utility',
    blurb: 'The tools that keep your journey running: stickers, helpers, and everything else under the sun.',
    subs: [
      { cat: 'utility',  label: 'Utility' },
      { cat: 'misc',     label: 'Misc' },
    ],
  },
]

/** raw category key -> owning section (built from SECTIONS, plus the misc fallback). */
const SECTION_BY_CAT = new Map()
for (const section of SECTIONS) {
  for (const sub of section.subs) SECTION_BY_CAT.set(sub.cat, section)
}
const FALLBACK_SECTION = SECTIONS[SECTIONS.length - 1] // Utility (its Misc sub hosts strays)

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1)
}

/**
 * Which of the bot's two WhatsApp numbers this message came in on, read off
 * ctx.botName (see handler.js's makeHandler / config.js's botName / botName2).
 * This is the only remaining consumer of the sun/moon identity — the
 * per-command auto-react it used to keep in sync with was removed 2026-09.
 */
function instanceIdentity(botName) {
  const n = (botName ?? '').toLowerCase()
  if (n.includes('moon')) return { emoji: '🌙', name: 'Moon' }
  if (n.includes('sun'))  return { emoji: '☀️', name: 'Sun' }
  return { emoji: '🪽', name: botName || 'Astral' }
}

/**
 * The prefix a player on this platform actually types. Telegram's UI
 * autocompletes `/`, so a menu full of `.` there teaches the wrong thing —
 * same reasoning as plugins/connect.js's prefixFor().
 */
function prefixFor(platform) {
  return platform === 'telegram' ? config.telegramPrefix : config.prefix
}

/**
 * Group this platform's plugins by raw category.
 *
 * Takes the platform-filtered list, NOT the raw registry: in combined mode all
 * three platforms share one registry, so reading it directly is what put
 * WhatsApp-only entries (.mute, .setgoodbye, .antilink) and Telegram-only ones
 * (.quiz) into Discord's menu. See lib/plugin-manager.js's isPluginAvailableOn.
 */
function buildCategories(plugins) {
  const seen = new Set()
  const categories = {}
  for (const plugin of plugins) {
    if (seen.has(plugin.name)) continue
    seen.add(plugin.name)
    const cat = (plugin.category ?? 'misc').toLowerCase()
    if (!categories[cat]) categories[cat] = []
    categories[cat].push(plugin)
  }
  return categories
}

/** Focused topic metadata so sub-section queries (e.g. `.menu bending` / `.menu benidng`) show ONLY that topic. */
const FOCUSED_TOPICS = Object.freeze({
  bending: {
    emoji: '🔥🌊🪨🌪️',
    label: 'Elemental Bending & Four Nations',
    blurb: 'Awaken your Affinity from the Sacred 100-Vessel Box, train under Avatar Masters, and unleash Bending Arts in PvE, Party, and PvP.',
    aliases: ['bending', 'bend', 'avatar', 'element', 'elements', 'affinity', 'nations', 'four nations', 'temple', 'firebending', 'waterbending', 'earthbending', 'airbending', 'subbending', 'freezing', 'bloodbending', 'metalbending', 'lavabending'],
    relatedLines: (pr) => [
      `── Related Bending Actions ──`,
      `▹ *${pr}pbend [element]*: unleash your Bending Strike in Co-op Party Dungeons`,
      `▹ *${pr}pvp bend [element]*: unleash your Bending Strike in 1v1 PvP Duels`,
      `▹ *${pr}skills bending* / *${pr}skillslot bending*: view & equip your unlocked Bending Forms`,
      `▹ *${pr}scout [@user]*: check Elemental Cycle advantage (+15% / -8%)`,
    ],
  },
  pvp: {
    emoji: '🥊',
    label: 'PvP & Duels',
    blurb: '1v1 duels, wagers, Astral League fixtures, scouting, spectating, and bracket tournaments.',
    aliases: ['pvp', 'duel', 'duels', 'arena', 'ladder', 'league'],
  },
  party: {
    emoji: '🤝',
    label: 'Co-op Party',
    blurb: 'Form a dungeon party and climb floors together with shared turns and shortcuts.',
    aliases: ['party', 'coop', 'co-op', 'dparty'],
  },
  story: {
    emoji: '📖',
    label: 'Story',
    blurb: 'Unfold the main story chapters and lore of the Astra Kingdom.',
    aliases: ['story', 'chapters', 'lore'],
  },
  inventory: {
    emoji: '🎒',
    label: 'Inventory & Gear',
    blurb: 'Carry, inspect, use, equip, and manage your items and weapons.',
    aliases: ['inventory', 'bag', 'gear', 'items'],
  },
  town: {
    emoji: '🏘️',
    label: 'Town & NPCs',
    blurb: 'Walk town spots, talk to townsfolk and Avatar Masters, and take local jobs.',
    aliases: ['town', 'towns', 'npcs', 'spots'],
  },
  housing: {
    emoji: '🏠',
    label: 'Housing',
    blurb: 'Build rooms, furnish your home, and customize your estate.',
    aliases: ['housing', 'house', 'home', 'rooms'],
  },
  cards: {
    emoji: '🃏',
    label: 'Cards',
    blurb: 'Collect, trade, and inspect anime cards.',
    aliases: ['cards', 'card', 'tcg'],
  },
  evolution: {
    emoji: '✨',
    label: 'Pokémon Evolution',
    blurb: 'Evolve and ascend your Pokémon roster.',
    aliases: ['evolution', 'evolve'],
  },
  packs: {
    emoji: '🎁',
    label: 'Season Packs',
    blurb: 'Limited seasonal packs and exclusive bundles.',
    aliases: ['packs', 'season packs'],
  },
  event: {
    emoji: '🎉',
    label: 'Events',
    blurb: 'Live seasonal and community events.',
    aliases: ['event', 'events'],
  },
  progression: {
    emoji: '📈',
    label: 'Progression',
    blurb: 'Leveling, ranks, classes, skills, and growth milestones.',
    aliases: ['progression', 'leveling', 'progress'],
  },
  social: {
    emoji: '💬',
    label: 'Social',
    blurb: 'Bonds, marriage, guilds, profiles, and player interactions.',
    aliases: ['social', 'friends', 'marriage'],
  },
  group: {
    emoji: '👥',
    label: 'Group Tools',
    blurb: 'Group settings, welcomes, and chat utilities.',
    aliases: ['group', 'groups'],
  },
  moderation: {
    emoji: '🛡️',
    label: 'Moderation',
    blurb: 'Moderation controls for group staff and caretakers.',
    aliases: ['moderation', 'mod', 'mods'],
  },
})

/**
 * Resolve `.menu <query>` with full fuzzy support:
 *   1. Focused sub-section / topic (so `.menu bending` or `.menu benidng` shows ONLY Bending!)
 *   2. Top-level section (`.menu combat` or `.menu dungon`)
 *   3. Fuzzy command/keyword search across all available commands
 */
function resolveMenuQuery(query, allPlugins) {
  const q = query.trim().toLowerCase()
  if (!q) return null

  // 1. Exact top-level section vs exact focused topic
  const exactTop = SECTIONS.find(s => s.key === q || s.label.toLowerCase() === q)
  if (exactTop) return { kind: 'section', section: exactTop }

  for (const section of SECTIONS) {
    for (const sub of section.subs) {
      if (sub.cat === section.key) continue
      const meta = FOCUSED_TOPICS[sub.cat]
      const aliases = meta?.aliases ?? [sub.cat, sub.label.toLowerCase()]
      if (sub.cat === q || sub.label.toLowerCase() === q || aliases.includes(q)) {
        return { kind: 'topic', section, sub, meta }
      }
    }
  }

  // 2. Fuzzy match across focused topics AND top-level sections (picks whichever scores higher!)
  let bestMatch = null
  let bestScore = 0

  for (const section of SECTIONS) {
    const topScore = Math.max(fuzzyMatchScore(q, section.key), fuzzyMatchScore(q, section.label))
    if (topScore >= 0.82 && topScore > bestScore) {
      bestScore = topScore
      bestMatch = { kind: 'section', section }
    }
    for (const sub of section.subs) {
      if (sub.cat === section.key) continue
      const meta = FOCUSED_TOPICS[sub.cat]
      const candidates = [sub.cat, sub.label, ...(meta?.aliases ?? [])]
      for (const cand of candidates) {
        const sc = fuzzyMatchScore(q, cand)
        // Slight tie-breaker toward specific focused topics (e.g. "benidng" -> bending)
        const adjusted = sc + 0.005
        if (sc >= 0.82 && adjusted > bestScore) {
          bestScore = adjusted
          bestMatch = { kind: 'topic', section, sub, meta }
        }
      }
    }
  }

  // Check if query is an exact command/alias name first (e.g. `.menu skillslot` or `.menu dragon`)
  const visiblePlugins = allPlugins.filter(p => !p.hidden && !isOwnerCommand(p))
  const exactCmd = visiblePlugins.find(p =>
    p.name.toLowerCase() === q || (p.aliases ?? []).some(a => a.toLowerCase() === q)
  )
  if (exactCmd && (!bestMatch || bestScore < 0.95)) {
    // Gather exactCmd + closely related commands
    const scored = visiblePlugins
      .map(p => ({ plugin: p, score: scorePluginQuery(p, q) }))
      .filter(x => x.score >= 0.78)
      .sort((a, b) => b.score - a.score || a.plugin.name.localeCompare(b.plugin.name))
      .slice(0, 10)
    return { kind: 'search', plugins: scored.map(x => x.plugin) }
  }

  if (bestMatch) return bestMatch

  // 3. General fuzzy command & keyword search across all visible plugins
  const scored = visiblePlugins
    .map(p => ({ plugin: p, score: scorePluginQuery(p, q) }))
    .filter(x => x.score >= 0.74)
    .sort((a, b) => b.score - a.score || a.plugin.name.localeCompare(b.plugin.name))
    .slice(0, 12)

  if (scored.length) {
    return { kind: 'search', plugins: scored.map(x => x.plugin) }
  }

  return null
}

/**
 * Telegram's menu: a different card from WhatsApp's, by request.
 *
 * Same ten sections and the same registry (so it can never advertise a
 * command it does not have), different shape:
 *   • a photo, because Telegram renders one inline with the caption;
 *   • every section as a BUTTON, so a section is one tap instead of
 *     `/menu Adventurer` typed out;
 *   • no "about me" block — a footer line carries the credit, and the space
 *     goes to the section list instead.
 *
 * Buttons go through the adapter's `c:<command>` callback path, i.e. the exact
 * same runCommand() a typed `/menu Adventurer` takes. A button can never mean
 * something the text command does not.
 */
function telegramOverview(ctx, { pr, displayName, categories }) {
  const available = SECTIONS.filter((section) =>
    section.subs.some((sub) => (categories[sub.cat] ?? []).length > 0),
  )

  const lines = [
    '✦ ── 🪽 *ASTRAL* 🪽 ── ✦',
    '',
    `Welcome, *${displayName}*.`,
    '_The Sun World of the Astra Kingdom._',
    '',
    '📂 *SECTIONS*',
    `Tap one below, or type \`${pr}menu <section>\`.`,
    '',
  ]
  for (const section of available) lines.push(`${section.emoji} ${section.label}`)
  lines.push(
    '',
    `📋 \`${pr}allcommands\` · 🧳 \`${pr}me\` · 🛟 \`${pr}support\``,
    `📨 \`${pr}contactteam <msg>\``,
    '',
    '_Owner ⌁ Yato · Built by ⌁ team-Flow_',
  )

  // Three per row: ten sections fit in four rows, and the longest label
  // ("🛠️ Sanctum") stays well inside Telegram's 64-byte button text.
  const buttons = []
  for (let i = 0; i < available.length; i += 3) {
    buttons.push(available.slice(i, i + 3).map((section) => ({
      text: `${section.emoji} ${section.label}`,
      data: `c:menu ${section.label}`,
    })))
  }

  return ctx.replyPhotoButtons(TELEGRAM_MENU_ART, lines.join('\n'), buttons)
}

/** One plugin's menu entry: the command line, the description, then any subcommands. */
function pluginLines(pr, p) {
  const lines = []
  const aliases = p.aliases?.length ? ` _(${p.aliases.map(a => `${pr}${a}`).join(', ')})_` : ''
  lines.push(`▹ *${pr}${p.name}*${aliases}`)
  lines.push(`   ↳ ${p.description}`)

  // Plugins that expose a `subcommands` array get their full subcommand list
  // expanded here too, instead of leaving the person to guess from the
  // one-line description alone. (The separator is a colon on purpose: this
  // is player-facing copy and the house rule is no em or en dashes.)
  //
  // Through playerSubcommands(): it normalises the two shapes plugins declare
  // (objects `{cmd, desc}` and the older bare strings `['status', …]`) and
  // drops owner-only entries. Reading `sc.cmd` straight off the array is what
  // printed "• *.league undefined*: undefined" for the 52 string subcommands
  // in league, ladmin and adventurers (2026-10).
  for (const sc of playerSubcommands(p)) {
    const dash = sc.desc ? `: ${cleanCopy(sc.desc)}` : ''
    lines.push(`      • *${pr}${p.name} ${sc.cmd}*${dash}`)
  }
  return lines
}

export default {
  name: 'menu',
  aliases: ['help', 'commands'],
  category: 'utility',
  cooldown: 5,
  description: 'Show the ten command sections, or <prefix>menu <section> for its commands',

  async run(ctx) {
    // ── The Sect Empire answers with its own guide ─────────────────────────
    // The ten-section menu is the kingdom's: nearly every command on it is
    // refused by the sect world lock, so up the mountain .menu/.help/.commands
    // show the mountain's own words instead of a wall of things that do not
    // work here (lib/sect-help.js).
    if (isInSectEmpire(ctx.player)) {
      return ctx.reply(sectHelpLines(prefixFor(ctx.platform)).join('\n'))
    }

    // The kingdom's list: a plugin tagged `category: 'sect'` belongs to the
    // other world and refuses here, so it is not advertised on this menu.
    const kingdomPlugins = listKingdomPluginsFor(ctx.platform)
    const categories = buildCategories(kingdomPlugins)
    const pr         = prefixFor(ctx.platform)
    const query      = ctx.args?.join(' ').trim().toLowerCase()

    // ── Drill-down / Focused Topic / Fuzzy Search: <prefix>menu <query> ────
    if (query) {
      const art = ctx.platform === 'telegram'
        ? TELEGRAM_MENU_ART
        : bannerFor(ctx.botName || config.botName)

      const resolved = resolveMenuQuery(query, kingdomPlugins)
      if (!resolved) {
        return ctx.reply(
          `❌ Nothing in the menu matched *"${query}"*.\n` +
          `Try *${pr}menu bending*, *${pr}menu combat*, *${pr}menu dungeon*, or *${pr}menu* to see all sections.`,
        )
      }

      // A. Focused Topic / Sub-section (e.g. `.menu bending` or `.menu benidng` -> ONLY Bending!)
      if (resolved.kind === 'topic') {
        const { section, sub, meta } = resolved
        const emoji = meta?.emoji ?? section.emoji
        const label = meta?.label ?? sub.label
        const blurb = meta?.blurb ?? section.blurb
        const topicPlugins = [...(categories[sub.cat] ?? [])].sort((a, b) => a.name.localeCompare(b.name))

        const lines = [`${emoji} *${label.toUpperCase()}*`]
        if (blurb) lines.push(`_${blurb}_`)
        lines.push('')

        if (topicPlugins.length) {
          lines.push(`── ${sub.label} ──`)
          for (const p of topicPlugins) lines.push(...pluginLines(pr, p))
          lines.push('')
        } else {
          lines.push(`_No ${label} commands are available on this platform._\n`)
        }

        if (typeof meta?.relatedLines === 'function') {
          lines.push(...meta.relatedLines(pr), '')
        }

        lines.push(`_Full ${section.label} section: *${pr}menu ${section.key}* · All sections: *${pr}menu*_`)
        return sendImage(ctx, art, lines.join('\n'))
      }

      // B. Fuzzy Command / Keyword Search (e.g. `.menu dragon`, `.menu tourny`, `.menu shop`)
      if (resolved.kind === 'search') {
        const lines = [
          `🔎 *MENU SEARCH: "${query.toUpperCase()}"*`,
          `_Showing ${resolved.plugins.length} matching command${resolved.plugins.length === 1 ? '' : 's'}:_`,
          '',
        ]
        for (const p of resolved.plugins) {
          lines.push(...pluginLines(pr, p))
        }
        lines.push('', `_See all sections: *${pr}menu*_`)
        return sendImage(ctx, art, lines.join('\n'))
      }

      // C. Full Top-Level Section (e.g. `.menu combat`, `.menu dungeon`, `.menu econmy`)
      const section = resolved.section
      const lines = [`${section.emoji} *${section.label.toUpperCase()}*`]
      if (section.blurb) lines.push(`_${section.blurb}_`)
      lines.push('')

      const groups = []
      for (const sub of section.subs) {
        groups.push({ label: sub.label, plugins: [...(categories[sub.cat] ?? [])] })
      }
      if (section === FALLBACK_SECTION) {
        const claimed = new Set(section.subs.map((s) => s.cat))
        const miscGroup = groups[groups.length - 1]
        for (const cat of Object.keys(categories).sort()) {
          if (claimed.has(cat) || SECTION_BY_CAT.has(cat)) continue
          miscGroup.plugins.push(...categories[cat])
        }
      }

      let shown = 0
      for (const group of groups) {
        const plugins = group.plugins.sort((a, b) => a.name.localeCompare(b.name))
        if (!plugins.length) continue
        lines.push(`── ${group.label} ──`)
        for (const p of plugins) {
          lines.push(...pluginLines(pr, p))
          shown++
        }
        lines.push('')
      }

      if (!shown) lines.push(`_No ${section.label} commands are available on this platform._\n`)
      lines.push(`\n_Back to sections: *${pr}menu*_`)
      return sendImage(ctx, art, lines.join('\n'))
    }

    // ── Telegram gets its own card ─────────────────────────────────────────
    // Placed before the WhatsApp overview so the two can never half-share copy:
    // see telegramOverview() for what differs and why.
    if (ctx.platform === 'telegram' && typeof ctx.replyPhotoButtons === 'function') {
      return telegramOverview(ctx, {
        pr,
        displayName: ctx.player?.name ?? 'traveler',
        categories,
      })
    }

    // ── Overview: <prefix>menu ──────────────────────────────────────────────
    const displayName = ctx.player?.name ?? 'traveler'
    const identity = instanceIdentity(ctx.botName || config.botName)

    const lines = [
      `─────── ${identity.emoji} *ASTRAL* ${identity.emoji} ───────`,
      `Welcome *${displayName}*. You have entered the *Sun World* of the Astra Kingdom.`,
      `My name is *${identity.name}*, ask me anything. I know everything tehe :)`,
      ``,
      `✦ ── [ 💫 about me! ] ── ✦`,
      `👑 Owner ⌁ *Yato*`,
      `🛠️ Made by ⌁ *team-Flow*`,
      `⌨️ Command prefix ⌁ ${pr}`,
      ``,
      `📂 *SECTIONS* 📂`,
      `↴`,
    ]

    // Exactly the ten sections. A section with nothing on THIS platform is
    // hidden rather than advertised empty (the old per-category behavior).
    for (const section of SECTIONS) {
      const hasAny = section.subs.some((sub) => (categories[sub.cat] ?? []).length > 0)
      if (!hasAny) continue
      lines.push(`${section.emoji} ▹ *${pr}menu ${section.label}*`)
    }

    lines.push('↴')
    lines.push('')
    lines.push(`> 📚 ${pr}menu <section>: every command in that section`)
    lines.push(`> 📋 ${pr}allcommands: every command you can type`)
    lines.push(`> 🧳 ${pr}me: view your profile`)
    lines.push(`> 🛟 ${pr}support: get help`)
    lines.push(`> 📨 ${pr}contactteam <msg>: message the dev team`)
    lines.push(`> 🌐 ${ctx.botName || config.botName} · Type *${pr}<command>* to use one directly.`)

    const overviewText = lines.join('\n')
    // Plain banner + text on every platform. (The tappable WhatsApp quick-action
    // buttons were removed by request; the sections above already cover it.)
    return sendImage(ctx, bannerFor(ctx.botName || config.botName), overviewText)
  },
}
