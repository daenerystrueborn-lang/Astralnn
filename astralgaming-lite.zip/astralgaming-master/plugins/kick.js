/**
 * kick.js — .kick   (reply to a member's message to remove them)
 * Staff tool. Requires the bot owner or a bot mod (see lib/group-settings.js
 * isBotStaff). WhatsApp group admins are refused. Never kicks an admin or the
 * bot owner.
 *
 * No upfront "am I admin?" check — attempts the removal directly and only
 * reports "not admin" if WhatsApp actually rejects it. This is faster and,
 * since checkBotAdmin's LID/jid matching can still occasionally miss an edge
 * case, avoids a false "not admin" block on an action that would have
 * actually succeeded.
 */
import { jidNormalizedUser } from '#wa'
import { extractTarget, isOwnerJid, NOT_GROUP, NOT_ALLOWED, invalidateGroupMetadata, NOT_STAFF, isGroupAdmin, participantIdForKick } from '../lib/group-helpers.js'
import { isGroupOrBotOwnerOrMod } from '../lib/group-settings.js'
import { isMod } from '../lib/mod-repo.js'
import { config } from '../config.js'

export default {
  name:        'kick',
  aliases:     [],
  category:    'utility',
  platforms:    ['whatsapp'],   // sock.groupMetadata / groupParticipantsUpdate — WhatsApp-only
  description: 'Remove a member from the group (reply to their message)',

  async run(ctx) {
    const { reply, sock, sender, msg, isGroup } = ctx
    if (!isGroup) return reply(NOT_GROUP)
    if (!(await isGroupOrBotOwnerOrMod(ctx))) return reply(NOT_STAFF)

    const target = extractTarget(msg)
    if (!target) {
      return reply('❌ Reply to the member\'s message.\n\n*Usage:* .kick (reply to user)')
    }

    const targetJid = jidNormalizedUser(target)

    // Still worth blocking these two up front — they're not "am I admin"
    // questions, they're "should this ever happen" questions regardless of
    // permissions.
    if (isOwnerJid(targetJid)) {
      return reply('❌ Cannot kick the bot owner.')
    }
    if (!isOwnerJid(ctx.from) && isMod(ctx.db, targetJid)) {
      return reply('❌ Mods cannot kick another bot mod — only the bot owner can do that.')
    }
    let kickJid = targetJid
    try {
      const meta = await sock.groupMetadata(sender)
      if (isGroupAdmin(meta, targetJid)) {
        return reply('❌ Cannot kick a group admin.')
      }
      // Resolve to the group's addressing-mode JID (LID vs phone). Using the raw
      // quoted participant directly fails in LID groups with a misleading
      // “not admin” error from WhatsApp.
      kickJid = participantIdForKick(meta, targetJid)
    } catch {
      // If metadata fetch fails here, fall through — the actual remove call
      // below will fail too and report a clear reason.
    }

    const bareTarget = kickJid.replace(/@.*$/, '')
    try {
      await sock.groupParticipantsUpdate(sender, [kickJid], 'remove')
      // Participant list changed: forget the cached metadata.
      invalidateGroupMetadata(sender)
      return reply(`✅ Removed @${bareTarget}`)
    } catch (e) {
      // WhatsApp's own error message for a non-admin bot is distinctive
      // enough to surface directly rather than guessing.
      return reply(`❌ Failed to kick @${bareTarget} — I'm likely not an admin here (or lack permission). Use *.botadmin* to check.\n_Error: ${e.message}_`)
    }
  },
}
