import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { getActiveSeason, getSeasonRuntime } from '../lib/season-engine.js'
import {
  listRegressorMemories, readRegressorMemory, relevantRegressorHint,
} from '../lib/regressor-memory.js'

export default {
  name: 'memory',
  aliases: ['memories', 'regressormemory'],
  category: 'season',
  requiresPlayer: true,
  description: 'Read the real Tower observations recorded by Regressor Memory',

  async run(ctx) {
    const season = getActiveSeason(ctx.db)
    if (season?.id !== 'season_02') {
      return ctx.reply('🌙 Regressor Memory opens during Season 2, Life of a Regressor.')
    }
    const runtime = getSeasonRuntime(ctx.db)
    const runNumber = runtime.runNumber ?? 0
    const action = String(ctx.args[0] ?? 'list').toLowerCase()
    let result = null
    await updatePlayer(ctx.db, ctx.from, player => {
      if (action === 'hint') {
        result = relevantRegressorHint(player, player.dungeonFloor || player.seasonProgress?.currentFloor || 1, { runNumber })
      } else if (action === 'read' || action === 'open') {
        result = readRegressorMemory(player, ctx.args.slice(1).join(' '), { runNumber })
      } else {
        result = listRegressorMemories(player, { runNumber })
      }
      return player
    })

    if (action === 'hint') {
      return ctx.reply(result
        ? `「 🧠 REGRESSOR MEMORY 」\n\n*${result.title}* · Floor ${result.floor}\n_${result.hint}_\n\nRead it with *${config.prefix}memory read ${result.floor}*.`
        : `「 🧠 REGRESSOR MEMORY 」\n\n_No Tower observation is recorded yet._\n\nClear a scenario boss at floors 100, 200, 300, 400 or 500 to record a real hint.`)
    }
    if (action === 'read' || action === 'open') {
      if (!result?.ok) {
        const message = result?.reason === 'undiscovered'
          ? `That memory is not recorded yet. Clear the Tower boss at floor ${result.memory.floor} first.`
          : `No recorded memory matches that. Use *${config.prefix}memory list*.`
        return ctx.reply(`「 🧠 REGRESSOR MEMORY 」\n\n${message}`)
      }
      return ctx.reply(
        `「 🧠 REGRESSOR MEMORY 」\n\n*${result.entry.title}* · Floor ${result.entry.floor}\n\n` +
        `_${result.entry.observation}_\n\n` +
        `💡 *Before the next attempt:* ${result.entry.hint}\n` +
        (result.firstRead ? `_The System records this observation in your seasonal quest board._` : `_This is a replay. No reward is issued twice._`),
      )
    }

    if (!result?.length) {
      return ctx.reply(
        `「 🧠 REGRESSOR MEMORY 」\n\n_No Tower observations recorded._\n` +
        `Clear one of the five scenario bosses to record what it taught you.\n\n` +
        `⌁ _${config.prefix}memory hint_ · the next relevant observation`,
      )
    }
    const rows = result.map(entry =>
      `${entry.read ? '☑️' : '🧠'} *${entry.title}* · Floor ${entry.floor}\n   _${entry.hint}_`,
    )
    return ctx.reply(
      `「 🧠 REGRESSOR MEMORY 」\n\n${rows.join('\n\n')}\n\n` +
      `⌁ _${config.prefix}memory read <floor>_ · replay an observation\n` +
      `⌁ _${config.prefix}memory hint_ · show the closest discovered hint`,
    )
  },
}
