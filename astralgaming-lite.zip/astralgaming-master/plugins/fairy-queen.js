/**
 * fairy-queen.js — the in-chat commands of the Queen of Fairies.
 *
 * ONE file, twelve commands. The plugin registers under `.encore` and lists
 * every other token as an alias; run() reads ctx.cmd to pick the move, the
 * same pattern plugins/pvp.js uses for its alias sets. Ten separate files
 * would have been ten copies of a 200-line battle turn.
 *
 *   .encore                     lock the enemy into its last move (3 turns)
 *   .seal                       read-only: what the court has taken this fight
 *   .abracadabra .hocuspocus    the ten Creative Magic incantations
 *   .alakazam .opensesame
 *   .presto .shazam
 *   .klaatu .mumbojumbo
 *   .bibbidi .simsalabim
 *
 * Every one of them works on ordinary monsters, dungeon floors and anime
 * bosses (this file), and hands off to plugins/pvp.js when the battleState is
 * a duel (pvpFairyEncore / pvpFairySpell). The Seal itself needs no command:
 * lib/fairy-court.js counts enemy moves and lib/character-abilities.js,
 * lib/boss-engine.js and pvp.js each act on the fourth use.
 *
 * Passives live outside this file, on the funnels every fight already uses:
 *   - 10% damage healed back  → applyIncomingDamage + processStatusTurn
 *   - +10,000 max MP          → data/characters.json statBonuses.maxMp
 *   - race → fairy            → makeFairy() on acquisition (plugins/character.js)
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import {
  calcPlayerDamage, applyDefense, calcPlayerHitChance,
  calcMonsterHitChance, calcMonsterDamage, hpBar,
} from '../lib/combat-engine.js'
import {
  handleVictory,
  processStatusTurn,
  resolvePlayerHpZero,
  checkCatFormOngoingTurn,
  resolveCatFormDefeat,
} from '../lib/combat-handlers.js'
import { getEffectiveStat } from '../lib/effects.js'
import {
  applyBossSpecial, checkBossPhase, buildEnemyAttack,
  getBossTaunt, getBossHitLine, getBossDodgeLine,
  incrementBossTurn, cleanupBossFight, EVENT,
} from '../lib/boss-engine.js'
import {
  applyIncomingDamage,
  sendWillowAdvisory,
  tickPermanentSever,
} from '../lib/character-abilities.js'
import { heroesAnswerHit, heroesTurnBoundary } from '../lib/witch-heroes-pve.js'
import { graceHoldsEnemyTurn, graceEnemyHeldLine } from '../lib/king-yato.js'
import { pvpFairySpell, pvpFairyEncore } from './pvp.js'
import { sendBattleTurnReply } from '../lib/battle-frame-render.mjs'
import {
  hasFairyQueen,
  fairySpellByCommand,
  fairySpellGate,
  consumeFairySpell,
  applyFairySpellSelf,
  applyFairySpellEnemy,
  buildFairySpellReveal,
  activateFairyEncore,
  fairySealStatus,
  lastEnemyMove,
  FAIRY_SPELLS,
  FAIRY_SPELL_MAP,
  FAIRY_COMMANDS,
  FAIRY_COMMAND_ALIASES,
} from '../lib/fairy-queen.js'

function isBossFight(player) {
  return !!(player.battleState?.enemy?.isBoss && player.battleState?.bossState)
}

/**
 * The enemy's half of the turn. Lifted from plugins/atomic.js so every spell
 * and the encore share one implementation: status tick → incapacitation →
 * King Yato's hold → boss build/apply → retaliation → hp-zero resolution.
 *
 * Returns { msg, ended, returnValue } — `ended` means a caller must stop
 * mutating and return `returnValue` untouched.
 */
async function enemyTurn(player, ctx, msg, boss) {
  const bs = player.battleState
  const e = bs.enemy

  const enemyStatus = processStatusTurn(e, { bossState: player.battleState?.bossState })
  if (enemyStatus.lines.length) msg += enemyStatus.lines.join('\n') + '\n'
  if (e.hp <= 0) {
    if (boss) cleanupBossFight(player)
    return { ended: true, returnValue: await handleVictory(player, e, ctx), msg }
  }

  if (graceHoldsEnemyTurn(player)) {
    msg += `\n${graceEnemyHeldLine(e, player)}\n`
  } else if (enemyStatus.incapacitated) {
    msg += `💫 *${e.name}* is unable to attack this turn!\n`
  } else if (boss) {
    const bossAtk = buildEnemyAttack(player)
    if (bossAtk.staggered) {
      msg += `\n${bossAtk.narrativeLines.join('\n')}\n`
    } else {
      const dealResult = applyBossSpecial(player, EVENT.ENEMY_DEAL_DAMAGE, { damage: bossAtk.damage, isHit: true })
      const rawBossAtk = (dealResult.modified && dealResult.damage !== undefined) ? dealResult.damage : bossAtk.damage
      const incoming = bossAtk.bypassDefense
        ? rawBossAtk
        : calcMonsterDamage(rawBossAtk, getEffectiveStat(player, 'def'), false)
      const witchHit = heroesAnswerHit({ player, enemy: e, ctx, msg: '', damage: incoming, directAttack: true, boss })
      if (witchHit.returnValue !== undefined) return { ended: true, returnValue: witchHit.returnValue, msg }
      if (witchHit.lines.length) msg += witchHit.lines.map(l => l + '\n').join('')
      const applied = applyIncomingDamage(player, witchHit.damage)
      if (applied.message) msg += applied.message + '\n'
      msg += `\n${e.emoji ?? '👾'} *${e.name}* uses *${bossAtk.attackName}*!\n`
      if (!witchHit.turned) msg += `🩸 *${applied.damage}* damage!${bossAtk.bypassDefense ? ' _(bypasses DEF)_' : ''}\n`
      if (dealResult.narrativeLine) msg += `_${dealResult.narrativeLine}_\n`
      if (bossAtk.narrativeLines?.length) msg += bossAtk.narrativeLines.map(l => `_${l}_`).join('\n') + '\n'
      msg += `\n💬 _"${getBossTaunt(player)}"_\n`
      if (applied.catFormDefeated) {
        return { ended: true, returnValue: await resolveCatFormDefeat(player, ctx, { boss: true }), msg }
      }
      if (player.hp <= 0) {
        const res = await resolvePlayerHpZero(player, ctx, msg, { boss: true })
        if (!res.fallThrough) return { ended: true, returnValue: res.returnValue, msg }
        msg = res.msg
      }
    }
  } else if (Math.random() > calcMonsterHitChance(e, player)) {
    msg += `\n${e.emoji ?? '👾'} *${e.name}* retaliates... and *MISSES!*`
  } else {
    const enemyDmg = calcMonsterDamage(e.atk, getEffectiveStat(player, 'def'), false)
    const witchHit = heroesAnswerHit({ player, enemy: e, ctx, msg: '', damage: enemyDmg, directAttack: true, boss })
    if (witchHit.returnValue !== undefined) return { ended: true, returnValue: witchHit.returnValue, msg }
    if (witchHit.lines.length) msg += witchHit.lines.map(l => l + '\n').join('')
    const applied = applyIncomingDamage(player, witchHit.damage)
    if (applied.message) msg += applied.message + '\n'
    if (!witchHit.turned) msg += `\n${e.emoji ?? '👾'} *${e.name}* retaliates!\n🩸 *${applied.damage}* damage!`
    if (applied.catFormDefeated) {
      return { ended: true, returnValue: await resolveCatFormDefeat(player, ctx), msg }
    }
    if (player.hp <= 0) {
      const res = await resolvePlayerHpZero(player, ctx, msg, {})
      if (!res.fallThrough) return { ended: true, returnValue: res.returnValue, msg }
      msg = res.msg
    }
  }

  if (boss) {
    const teResult = applyBossSpecial(player, EVENT.TURN_END, {})
    if (teResult.narrativeLine) msg += `\n_${teResult.narrativeLine}_`
  }
  return { ended: false, msg }
}

/** Shared closing: the board, the Heroes' clock, the turn counter, the send. */
async function closeTurn(player, ctx, msg, boss, { hpBeforeTurn, eHpBeforeTurn } = {}) {
  const bs = player.battleState
  const e = bs.enemy
  const p = config.prefix
  msg += `\n\n👤 *${player.name}*\n❤️ ${hpBar(player.hp, player.maxHp)}  💧 ${player.mp}/${player.maxMp} MP\n` +
         `${e.emoji ?? '👾'} *${e.name}*\n❤️ ${hpBar(e.hp, e.maxHp)}\n\n` +
         `*${p}attack* · *${p}skill <name>* · *${p}defend* · *${p}encore* · *${p}seal*`
  const witchTurn = await heroesTurnBoundary({ player, enemy: e, ctx, msg, turnId: bs.turn ?? 1, boss })
  if (witchTurn.returnValue !== undefined) return await witchTurn.returnValue
  msg = witchTurn.msg
  bs.turn = (bs.turn ?? 1) + 1
  player.battleState = bs
  await sendWillowAdvisory(ctx, player, e, boss)
  await sendBattleTurnReply(ctx, {
    bs, player, e, msg,
    hpBeforeTurn: hpBeforeTurn ?? player.hp,
    eHpBeforeTurn: eHpBeforeTurn ?? e.hp,
    boss,
  })
  return player
}

/** The opening half every battle move shares: cat form, boss clock, status. */
async function openTurn(player, ctx, { boss, msg }) {
  const catTurn = await checkCatFormOngoingTurn(player, ctx, { boss })
  if (catTurn.intercepted) return { intercepted: true, returnValue: catTurn.returnValue, msg }

  player.battleState.playerDefending = false
  const permaSeverLine = tickPermanentSever(player)
  if (permaSeverLine) msg += permaSeverLine + '\n'
  if (player.hp <= 0) {
    const res = await resolvePlayerHpZero(player, ctx, msg, {})
    if (!res.fallThrough) return { intercepted: true, returnValue: res.returnValue, msg, player }
    msg = res.msg
  }

  if (boss) {
    incrementBossTurn(player)
    const tsResult = applyBossSpecial(player, EVENT.TURN_START, {})
    if (tsResult.narrativeLine) msg += `_${tsResult.narrativeLine}_\n`
  }
  const playerStatus = processStatusTurn(player)
  if (playerStatus.incapacitated && player.battleState?.enemy?.tower) player.battleState.towerTacticIncapacitatedTurn = player.battleState.turn ?? 1
  if (!playerStatus.incapacitated && player.hp > 0 && player.battleState?.bossState?._def?.orv) applyBossSpecial(player, EVENT.PLAYER_ABILITY, {})
  if (playerStatus.lines.length) msg += playerStatus.lines.join('\n') + '\n'
  if (player.hp <= 0) {
    const res = await resolvePlayerHpZero(player, ctx, msg, { boss })
    if (!res.fallThrough) return { intercepted: true, returnValue: res.returnValue, msg, player }
    msg = res.msg
  }
  return { intercepted: false, msg, playerStatus }
}

/** One Creative Magic cast: the whole turn, enemy retaliation included. */
async function runSpell(ctx, spell) {
  if (ctx.player?.battleState?.type === 'pvp') return pvpFairySpell(ctx, spell.id)
  if (!ctx.player?.battleState?.enemy) {
    return ctx.reply(
      `🧚‍♀️ *Creative Magic is cast in battle.*\n` +
      `_Draw a blade, open a dungeon floor, or challenge someone first._`,
    )
  }

  await updatePlayer(ctx.db, ctx.from, async player => {
    const hpBeforeTurn = player.hp
    const eHpBeforeTurn = player.battleState?.enemy?.hp
    const boss = isBossFight(player)
    const opened = await openTurn(player, ctx, { boss, msg: '' })
    if (opened.intercepted) return opened.returnValue
    let msg = opened.msg
    const playerStatus = opened.playerStatus

    const gate = fairySpellGate(player, spell)
    if (!gate.ok) {
      await ctx.reply(gate.message)
      return player
    }

    const bs = player.battleState
    const e = bs.enemy
    msg += buildFairySpellReveal(spell, player.name, e.name) + '\n\n'

    if (playerStatus.incapacitated) {
      msg += `💫 *${player.name}* is unable to act this turn!\n`
    } else if (spell.enemy && Math.random() > calcPlayerHitChance(player, e)) {
      consumeFairySpell(player, spell, bs)
      msg += `💨 The words scatter past *${e.name}* — *MISSED!*\n`
      if (boss) {
        applyBossSpecial(player, EVENT.PLAYER_MISS, { isMiss: true })
        msg += `💬 _"${getBossDodgeLine(player)}"_\n`
      }
    } else {
      consumeFairySpell(player, spell, bs)
      const self = applyFairySpellSelf(spell, player)
      if (self.lines.length) msg += self.lines.join('\n') + '\n'

      if (spell.enemy) {
        const result = applyFairySpellEnemy(spell, player, e, {
          boss,
          sealState: bs,
          lastMove: lastEnemyMove(player, bs),
        })
        if (result.lines.length) msg += result.lines.join('\n') + '\n'

        if (boss && result.damage > 0) {
          const takeResult = applyBossSpecial(player, EVENT.ENEMY_TAKE_DAMAGE, {
            damage: result.damage, element: 'none', isCrit: false, isHit: true,
          })
          if (takeResult.narrativeLine) msg += `_${takeResult.narrativeLine}_\n`
          msg += `💬 _"${getBossHitLine(player)}"_\n`
        }

        if (e.hp <= 0) {
          if (boss) cleanupBossFight(player)
          return handleVictory(player, e, ctx)
        }
        if (boss) {
          const phase = checkBossPhase(player)
          if (phase?.triggered && phase.lines?.length) {
            msg += `\n⚡ *— PHASE SHIFT —*\n` + phase.lines.map(l => `_${l}_`).join('\n') + '\n'
          }
        }
      }
    }

    if (e.hp <= 0) {
      if (boss) cleanupBossFight(player)
      return handleVictory(player, e, ctx)
    }

    const enemyHalf = await enemyTurn(player, ctx, msg, boss)
    if (enemyHalf.ended) return enemyHalf.returnValue
    return closeTurn(player, ctx, enemyHalf.msg, boss, { hpBeforeTurn, eHpBeforeTurn })
  })
}

/** `.encore` — the whole turn is the clap; the enemy then acts under it. */
async function runEncore(ctx) {
  if (ctx.player?.battleState?.type === 'pvp') return pvpFairyEncore(ctx)
  if (!ctx.player?.battleState?.enemy) {
    return ctx.reply(
      `🎼 *An encore needs a stage.*\n` +
      `_Start a fight with *${config.prefix}attack*, *${config.prefix}enter*, or a duel._`,
    )
  }

  await updatePlayer(ctx.db, ctx.from, async player => {
    const hpBeforeTurn = player.hp
    const eHpBeforeTurn = player.battleState?.enemy?.hp
    const boss = isBossFight(player)
    const opened = await openTurn(player, ctx, { boss, msg: '' })
    if (opened.intercepted) return opened.returnValue
    let msg = opened.msg

    const gate = activateFairyEncore(player, player.battleState, lastEnemyMove(player, player.battleState))
    if (!gate.ok) {
      await ctx.reply(gate.message)
      return player
    }
    msg += gate.lines.join('\n') + '\n'

    const bs = player.battleState
    const e = bs.enemy
    if (opened.playerStatus?.incapacitated) {
      msg += `💫 *${player.name}* cannot hold the note — the court's encore dies in the air.\n`
    }

    const enemyHalf = await enemyTurn(player, ctx, msg, boss)
    if (enemyHalf.ended) return enemyHalf.returnValue
    return closeTurn(player, ctx, enemyHalf.msg, boss, { hpBeforeTurn, eHpBeforeTurn })
  })
}

/** `.seal` — a read-only board. Costs no turn and touches no state. */
async function runSeal(ctx) {
  await ctx.reply(fairySealStatus(ctx.player, ctx.player?.battleState))
}

const SPELL_ALIASES = FAIRY_SPELLS.flatMap(s => s.aliases ?? [])

export default {
  name: 'encore',
  aliases: ['seal', ...FAIRY_COMMANDS.filter(c => c !== 'encore' && c !== 'seal'), ...SPELL_ALIASES],
  category: 'combat',
  requiresPlayer: true,
  description: `${config.prefix}encore / ${config.prefix}seal + ten Creative Magic spells — Queen of Fairies kit`,

  async run(ctx) {
    const cmd = String(ctx.cmd ?? 'encore').toLowerCase()

    if (cmd === 'seal') return runSeal(ctx)

    const spell = fairySpellByCommand(cmd)
    if (spell) return runSpell(ctx, spell)

    if (!hasFairyQueen(ctx.player)) {
      return ctx.reply(
        `🧚‍♀️ *The court does not answer.*\n` +
        `_Equip the *Queen of Fairies* to command the dark elf court._`,
      )
    }
    return runEncore(ctx)
  },
}

export { FAIRY_SPELLS, FAIRY_SPELL_MAP }
