/**
 * road.js — `.road` : the mountain road into the Sect Empire.
 *
 * A player standing in an Astra Kingdom town finds an old gatekeeper sitting at
 * the end of the road. He talks, he asks two questions, he weighs them, and at
 * the end of it they are standing at the foot of the mountain as a cultivator.
 * The words live in data/sect-road.json and the state machine in
 * lib/sect-road.js; this file is the door and the two refusals in front of it.
 *
 * ELIGIBILITY (all of it in lib/sect-road.js's roadRefusal): a town, not a
 * dungeon, not a fight, not a dimension, not frozen, not asleep, not jailed,
 * not mid-trade and not holding a live auction bid. And the Sect Empire must be
 * OPEN — see plugins/openworld.js — except for the owner, who may walk it while
 * the switch is off to test the whole road.
 *
 * Mid-conversation, `.road` reads out the question they were standing on,
 * whether that is a second later or a restart later: the conversation lives on
 * the player record, not in this process.
 */
import { config } from '../config.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import { updatePlayer } from '../lib/player-repo.js'
import { isFactionPending } from '../lib/faction-choice.js'
import { isOnRoad, roadOpen, roadRefusal } from '../lib/sect-road.js'
import { isInSectEmpire, ASTRA_KINGDOM, SECT_EMPIRE } from '../lib/worlds.js'
// The beat every arrival gets, on the roads and on the world screens alike:
// the picture of the tear, with the welcome under it (lib/world-arrival.js).
import { sendWorldTear } from '../lib/world-arrival.js'
import {
  isOnWayBack, wayBackOpen, convertStones, commitWayUp,
} from '../lib/sect-wayback.js'
import { currentAuctionBidder } from './auction.js'

export default {
  name: 'road',
  aliases: ['mountainroad', 'climb'],
  category: 'event',
  requiresPlayer: true,
  description: `${config.prefix}road — walk the mountain road into the Sect Empire`,

  async run(ctx) {
    const owner = isOwnerJid(ctx.from)
    const auction = currentAuctionBidder()
    const args = (ctx.args ?? []).map(a => String(a))

    // The mountain road crosses worlds a player has not chosen yet — the
    // faction pick itself places sect players at its foot for free.
    if (isFactionPending(ctx.player)) {
      return ctx.reply(
        `🧭 *Choose your world first.*\n\n` +
        `_${config.prefix}faction kingdom_ — Astra Kingdom\n` +
        `_${config.prefix}faction sect_ — Sect Empire_`,
      )
    }

    const sub = String(args[0] ?? '').toLowerCase()

    // ── The way back down (Prompt 8) ─────────────────────────────────────
    if (isInSectEmpire(ctx.player)) {
      if (['cancel', 'leave', 'back', 'stop', 'wait'].includes(sub) && isOnWayBack(ctx.player)) {
        await updatePlayer(ctx.db, ctx.from, pl => { pl.sectWayBack = null; return pl })
        return ctx.reply(`🪨 *You step back from the mountain road.* _Use_ *${config.prefix}road* _whenever you are ready to walk down._`)
      }
      if (sub === 'convert') {
        let out = null
        await updatePlayer(ctx.db, ctx.from, pl => { out = convertStones(pl, args[1] ?? 'all', { now: Date.now() }); return pl })
        return ctx.reply((out?.lines ?? []).join('\n'))
      }
      let out = null
      await updatePlayer(ctx.db, ctx.from, pl => { out = wayBackOpen(pl, { now: Date.now() }); return pl })
      return ctx.reply((out?.lines ?? []).join('\n\n'))
    }

    // Already talking to him: the state is the answer, whatever the world
    // switch says now. The last step is where a closed world is refused.
    if (isOnRoad(ctx.player)) {
      if (['cancel', 'leave', 'back', 'stop', 'wait'].includes(sub)) {
        await updatePlayer(ctx.db, ctx.from, pl => { pl.sectRoad = null; return pl })
        return ctx.reply(`🪨 *You step back from the gatekeeper.* _Use_ *${config.prefix}road* _whenever you are ready to walk it._`)
      }
      let out = null
      await updatePlayer(ctx.db, ctx.from, pl => { out = roadOpen(pl); return pl })
      return ctx.reply(out.lines.join('\n\n'))
    }

    // Through the door once already: never the conversation again, never a
    // second roll. The climb back is a crossing like any other (Prompt 8):
    // the card's clock is stamped inside the same mutator as the thaw and
    // the world move, so it all lands or none does. The Solars toll is the
    // way down only (lib/sect-crossing.js).
    if (ctx.player?.sect) {
      let out = null
      let crossed = null
      await updatePlayer(ctx.db, ctx.from, pl => {
        crossed = commitWayUp(pl, { now: Date.now() })
        if (!crossed.ok) { out = crossed; return pl }
        out = roadOpen(pl, { charged: true })
        return pl
      })
      if (out && out.kind === 'refused') return ctx.reply((out.lines ?? []).join('\n'))
      // They are through, so the arrival gets the arrival's beat: the world
      // tore, they came out of the shadows, and the mountain is named. A
      // refusal above never reaches this line and never shows the picture.
      if (out?.ok) await sendWorldTear(ctx, SECT_EMPIRE, { from: ASTRA_KINGDOM })
      return ctx.reply((out?.lines ?? []).join('\n\n'))
    }

    const refusal = roadRefusal(ctx.player, ctx.db, {
      from: ctx.from,
      isOwner: owner,
      auctionBidderId: auction?.bidderId ?? null,
    })
    if (refusal) return ctx.reply(refusal)

    let out = null
    await updatePlayer(ctx.db, ctx.from, pl => { out = roadOpen(pl); return pl })
    if (!out?.ok) return ctx.reply(`🚧 *The road is not listening right now.* _Try again in a moment._`)
    return ctx.reply(out.lines.join('\n\n'))
  },
}
