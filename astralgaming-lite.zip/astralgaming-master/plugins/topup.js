/**
 * topup.js — Gem and Solar top-ups (Naira, screenshot-confirmed). Naira only:
 * gems are never purchasable with Solars or any in-game currency.
 *
 * DM ONLY, like .monds/.promo: every subcommand except the owner's confirm
 * and reject is refused in a group. Prices, bank details and pending orders
 * stay out of group chats, where copycats can use them to scam buyers. The
 * owner can still confirm/reject from a mod group, as with .monds.
 *
 * Usage (in DM unless noted):
 *   .topup                         — gem AND Solar package list
 *   .topup gems | .topup solars    — just one of the two lists (.buysolars too)
 *   .topup buy <packageId>         — shows payment details
 *                                    (`.topup buy popular`, `.topup buy 100m`)
 *   .topup confirm <name>          — owner-only, works anywhere
 *   .topup reject <name>           — owner-only, works anywhere
 *
 * ── Solar packs (owner's call, 2026-10-15) ─────────────────────────────────
 * Solars sell on the very same flow as gems, from data/solar-packages.json:
 * a Solar buy writes player.topupPending with `solars` (and its price) where a
 * gem buy writes `gems`, so the DM screenshot hook, the owner's caption and
 * `.topup confirm` all work unchanged. Confirm credits whichever the pending
 * holds. No new pending kind and no new owner command to learn.
 *
 * Because one field now carries two currencies, a new order never replaces a
 * receipt that is already with the owner (state 'pending_confirmation'): a
 * `.topup buy popular` typed after paying for 100m Solars would otherwise
 * swap the order the owner is about to confirm. plugins/promo.js already
 * worked this way.
 *
 * See lib/pending-purchase.js for the shared DM-screenshot flow (also used
 * by plugins/premium.js) and handler.js for the surrounding DM lock.
 */
import { config } from '../config.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import { updatePlayer, getPlayer } from '../lib/player-repo.js'
import { roundGems, fmtGems } from '../lib/format.js'
import { topupPackages as pkgData, solarPackages as solarData } from '../lib/game-data.js'
import { offerLines, solarOfferLines, findSolarPackage, formatNaira, formatSolars } from '../lib/topup-offers.js'
import { findPendingForOwner, pendingFailureText, pendingKinds, PURCHASE_KINDS } from '../lib/pending-confirm.js'
import { sendImage, sendImageTo } from '../lib/image.js'

// Shared top-up art: every package-list view (gems, monds, season offers) and
// every "you got what you paid for" confirmation DM uses these (2026-09-21
// drop, resolved via lib/image.js's remote map).
const TOPUP_PLANS_IMAGE = 'top-up.jpg'
const PAYMENT_DONE_IMAGE = 'payment_done.jpg'

/** The Solar packs, smallest first (data/solar-packages.json). */
export const SOLAR_PACKAGES = Object.freeze((solarData.solarPackages ?? []).map(p => Object.freeze({ ...p })))

/** Words that mean "the Solar list" after `.topup`, or before a pack id in `.topup buy`. */
const SOLAR_WORDS = new Set(['solar', 'solars', 'sol'])

// Who the owner means, and what they have pending, is entirely
// lib/pending-confirm.js's business — see that file's header for why a
// purchase plugin must not resolve a buyer by name on its own.

/**
 * The gem offer list, rendered by lib/topup-offers.js so `.topup`, `.gm offers`
 * and the site's /api/premium all read the same ten rows the same way — rate
 * included, ⭐ on the best one (see that module for why the rate is shown).
 */
function gemLines() {
  return offerLines(pkgData.gemPackages).join('\n')
}

function solarLines() {
  return solarOfferLines(SOLAR_PACKAGES).join('\n')
}

/** The default `.topup` screen: both ladders, one buy line. Kept under WhatsApp's caption limit. */
export function fullListText(pr) {
  return (
    `📦 *Gem Packages:*\n${gemLines()}\n\n` +
    `☀️ *Solar Packages:*\n${solarLines()}\n\n` +
    `Buy with *${pr}topup buy <id>* _(DM only)_, e.g. *${pr}topup buy popular* or *${pr}topup buy 100m*.`
  )
}

function gemListText(pr) {
  return `📦 *Gem Packages:*\n${gemLines()}\n\nBuy with *${pr}topup buy <package id>* _(DM only)_.`
}

function solarListText(pr) {
  return `☀️ *Solar Packages:*\n${solarLines()}\n\nBuy with *${pr}topup buy <id>* _(DM only, e.g. ${pr}topup buy 100m)_.`
}

function paymentDetails() {
  const pay = config.payment ?? {}
  return (
    `💳 *Payment Details:*\n` +
    `  🏦 Bank: *${pay.bankName || '(not configured)'}*\n` +
    `  🔢 Account: *${pay.accountNumber || '(not configured)'}*\n` +
    `  👤 Name: *${pay.accountName || '(not configured)'}*\n\n` +
    `📸 Once paid, send a screenshot of the transfer *right here in this DM* to confirm.`
  )
}

/** "Come to my DM" reply for any .topup form used in a group, with a link
 *  to the bot's own chat so nobody has to hunt for the number. Mirrors the
 *  .monds notice — same reason, same shape. */
function dmOnlyNotice(ctx) {
  const pr = config.prefix
  const botJid = ctx.sock?.user?.id ?? ''
  const botNumber = String(botJid).split(':')[0].replace(/@.*$/, '').replace(/\D/g, '')
  const link = botNumber ? `\n🔗 wa.me/${botNumber}` : ''
  return (
    `💬 *Top-ups are DM only.*\n` +
    `─────────────────────\n` +
    `Prices and payment details don't belong in a group chat.${link}\n\n` +
    `Open my chat and send:\n` +
    `  ▸ *${pr}topup* — gem and Solar packs\n` +
    `  ▸ *${pr}topup buy <id>* — payment details\n\n` +
    `_Your account and wallet are the same in my DM_`
  )
}

async function handleBuy(ctx) {
  const pr = config.prefix
  // Kept as a local backstop: the whole command is gated in run(), but a
  // future caller must never be able to leak payment details into a group.
  if (ctx.isGroup) {
    return ctx.reply(`💬 DM me *${pr}topup buy <package id>* to see payment details.`)
  }

  // `.topup buy solars 100m` reads the same as `.topup buy 100m`.
  const words = ctx.args.slice(1)
  const typed = SOLAR_WORDS.has(String(words[0] ?? '').toLowerCase()) ? (words[1] ?? '') : (words[0] ?? '')
  const pkgId = String(typed).toLowerCase()
  const gemPkg = pkgData.gemPackages.find(p => p.id === pkgId) ?? null
  const solarPkg = gemPkg ? null : findSolarPackage(SOLAR_PACKAGES, typed)
  if (!gemPkg && !solarPkg) {
    return ctx.reply(`❌ Unknown package *"${typed}"*.\n\n${fullListText(pr)}`)
  }

  let busy = false
  await updatePlayer(ctx.db, ctx.from, p => {
    // A receipt already with the owner is never replaced by a new order: that
    // is how a paid purchase turns into a different one (see the header).
    if (p.topupPending?.state === 'pending_confirmation') { busy = true; return }
    p.topupPending = gemPkg
      ? { packageId: gemPkg.id, gems: gemPkg.gems, state: 'awaiting_screenshot', at: Date.now() }
      : {
        packageId: `solars_${solarPkg.id}`, gems: 0, solars: solarPkg.solars, priceNaira: solarPkg.priceNaira,
        state: 'awaiting_screenshot', at: Date.now(),
      }
  })
  if (busy) {
    return ctx.reply(`⏳ Your last top-up payment is still waiting for the owner to confirm. You can order again once it is done.`)
  }

  const heading = gemPkg
    ? `💎 *${gemPkg.gems} Gems* — ₦${gemPkg.priceNaira.toLocaleString()}`
    : `☀️ *${formatSolars(solarPkg.solars)} Solars* — ₦${formatNaira(solarPkg.priceNaira)}`
  return ctx.reply(`${heading}\n\n${paymentDetails()}`)
}

async function handleConfirm(ctx) {
  if (!isOwnerJid(ctx.from)) return ctx.reply(`❌ Owner only.`)

  // Accepts the buyer's WhatsApp number (what the screenshot caption now
  // prints) or their display name. No `db.read()` first: player state is in
  // this process's RAM, and re-reading db.json here is what used to make a
  // perfectly good pending vanish the moment the owner typed confirm.
  const query = ctx.args.slice(1).join(' ')
  const found = findPendingForOwner(ctx.db, query, 'topup')
  if (!found.ok) return ctx.reply(pendingFailureText(ctx.db, { prefix: config.prefix, result: found }))

  const target = found.target
  const { packageId } = found.pending
  // A gem order holds `gems`, a Solar order holds `solars` (and gems: 0).
  const gems = Number(found.pending.gems ?? 0)
  const solars = Number(found.pending.solars ?? 0)
  await updatePlayer(ctx.db, found.key, p => {
    p.wallet = p.wallet ?? {}
    if (gems > 0) p.wallet.gems = roundGems((p.wallet.gems ?? 0) + gems)
    if (solars > 0) p.wallet.solars = (p.wallet.solars ?? 0) + solars
    p.topupPending = null
  }, { critical: true })

  const fresh = getPlayer(ctx.db, found.key)
  const credited = [
    gems > 0 ? `💎${gems} gems` : '',
    solars > 0 ? `☀️${formatSolars(solars)} Solars` : '',
  ].filter(Boolean).join(' + ') || '💎0 gems'
  const balance = [
    gems > 0 || !solars ? `💎${fmtGems(fresh.wallet.gems)}` : '',
    solars > 0 ? `☀️${formatSolars(fresh.wallet.solars)}` : '',
  ].filter(Boolean).join(' · ')
  // Payment-completion image on the confirmation DM (degrades to text).
  await sendImageTo(ctx, PAYMENT_DONE_IMAGE,
    `🎉 *Top-up confirmed!* ${credited} credited (package: *${packageId}*).\nYour balance: ${balance}.`,
    found.key,
  ).catch(() => {})

  return ctx.reply(`✅ Credited ${credited} to *${target.name}* (package: *${packageId}*).`)
}

async function handleReject(ctx) {
  if (!isOwnerJid(ctx.from)) return ctx.reply(`❌ Owner only.`)

  const query = ctx.args.slice(1).join(' ')
  // anyKind: cancelling is the safe direction, so a pending of any currency on
  // that record gets cleared rather than the owner being told to use a
  // different command.
  const found = findPendingForOwner(ctx.db, query, 'topup', { anyKind: true })
  if (!found.ok) return ctx.reply(pendingFailureText(ctx.db, { prefix: config.prefix, result: found }))

  const wasSolars = found.kind === 'topup' && Number(found.pending?.solars ?? 0) > 0
  await updatePlayer(ctx.db, found.key, p => { p[PURCHASE_KINDS[found.kind].field] = null })

  await ctx.sock.sendMessage(found.key, {
    text: `❌ Your ${wasSolars ? 'Solar' : 'gem'} top-up couldn't be confirmed. Please double-check the payment and try *${config.prefix}topup buy <package id>* again, or contact support.`,
  }).catch(() => {})

  const cleared = PURCHASE_KINDS[found.kind]
  const other = pendingKinds(getPlayer(ctx.db, found.key))
  return ctx.reply(`✅ Cleared *${found.target.name}*'s ${cleared.noun}.` +
    (other.length
      ? `\n\n⚠️ They still have ${other.length} other pending purchase(s) on the same record — clear or confirm those with *${config.prefix}${PURCHASE_KINDS[other[0]].command} ${found.key}*.`
      : ''))
}

export default {
  name: 'topup',
  aliases: ['gems', 'buygems', 'buysolars'],
  category: 'economy',
  description: `${config.prefix}topup — DM only · buy gems or Solars with Naira via bank transfer`,

  async run(ctx) {
    const sub = (ctx.args[0] ?? '').toLowerCase()
    const pr  = config.prefix

    // One gate for the whole command and every alias (.gems/.buygems/
    // .buysolars) — previously only `buy` was private, so the price lists
    // still worked in groups. Owner moderation stays available anywhere.
    const ownerOnlySub = sub === 'confirm' || sub === 'reject'
    if (ctx.isGroup && !(ownerOnlySub && isOwnerJid(ctx.from))) {
      return ctx.reply(dmOnlyNotice(ctx))
    }

    if (sub === 'buy')     return handleBuy(ctx)
    if (sub === 'confirm') return handleConfirm(ctx)
    if (sub === 'reject')  return handleReject(ctx)

    if (SOLAR_WORDS.has(sub) || (!sub && ctx.cmd === 'buysolars')) {
      return sendImage(ctx, TOPUP_PLANS_IMAGE, solarListText(pr))
    }
    // `.gems` / `.buygems` keep meaning just the gem list, as they always did.
    if (sub === 'gems' || sub === 'gem' || (!sub && (ctx.cmd === 'gems' || ctx.cmd === 'buygems'))) {
      return sendImage(ctx, TOPUP_PLANS_IMAGE, gemListText(pr))
    }
    return sendImage(ctx, TOPUP_PLANS_IMAGE, fullListText(pr))
  },
}
