/**
 * profession.js — `.profession`: the four trades, and learning one.
 *
 *   .profession                  the four, what you have in each, today's points
 *   .profession <trade>          what it is, where it is taught, whether you know it
 *   .profession learn <trade>    start learning it (three hours), or finish
 *   .profession collect          finish a lesson whose hours are in
 *
 * WHERE. The Wayfarer's Academy's library teaches ALL FOUR to anybody standing
 * in it. A sect's own hall teaches the one that hall is known for. Learning
 * costs the hours in data/sect-conversion.json `professions.learnHours` and
 * nothing else; levels come from working (lib/sect-craft.js).
 */
import { config } from '../config.js'
import { sectDoorRefusal, missingSectRecordRefusal } from '../lib/world-guards.js'
import { updatePlayer } from '../lib/player-repo.js'
import { withGrowthLock } from '../lib/sect-progress.js'
import { BUSY } from '../lib/sect-fight.js'
import {
  PROFESSIONS, matchProfession, professionLines, learnRefusal, beginLesson, finishLesson,
  lessonOf, lessonLeft, learnRefusal as refusalFor, teachPlaces, knows, levelOf, LEARN_HOURS,
  profWords,
} from '../lib/sect-professions.js'


const p = config.prefix
const fill = (text, values = {}) => String(text ?? '').replace(/\{(\w+)\}/g, (_, key) => String(values[key] ?? ''))

/** "2h 10m" — how long a lesson has left. */
function leftText(ms) {
  const minutes = Math.max(0, Math.ceil(Number(ms) / 60_000))
  if (minutes < 60) return `${minutes} minutes`
  const hours = Math.floor(minutes / 60)
  return hours >= 24 ? `${Math.floor(hours / 24)} days` : `${hours} hours`
}

function screen(player) {
  const profile = player.sect
  const lines = [
    profWords.title ?? '🛠️ *PROFESSIONS*',
    profWords.subtitle ?? '',
    '',
    ...professionLines(profile, { now: Date.now() }),
    '',
  ]
  const lesson = lessonOf(profile)
  if (lesson) {
    const record = PROFESSIONS.find(r => r.id === lesson.id)
    const left = lessonLeft(profile, Date.now())
    lines.push(left > 0
      ? fill(profWords.learnRunning ?? '', { name: record?.name ?? lesson.id, left: leftText(left) })
      : fill(profWords.learnDone ?? '', { name: record?.name ?? lesson.id, level: 1 }))
    lines.push(`_*${p}profession collect* when the hours are in._`)
  }
  lines.push(fill(profWords.foot ?? '', { prefix: p }))
  return lines.filter(l => l !== '').join('\n')
}

function card(player, record) {
  const profile = player.sect
  const known = knows(profile, record.id)
  return [
    fill(profWords.learnTitle ?? '', { name: record.name }),
    fill(profWords.learnScene ?? '', { description: record.description }),
    fill(profWords.learnWhere ?? '', { places: teachPlaces(record.id).join('  ·  ') }),
    '',
    known
      ? fill(profWords.learned ?? '', { name: record.name, level: levelOf(profile, record.id) })
      : `_Not learned yet._ *${p}profession learn ${record.id}* _— ${LEARN_HOURS}h of it._`,
    '',
    fill(profWords.foot ?? '', { prefix: p }),
  ].filter(l => l !== '').join('\n')
}

export default {
  name: 'profession',
  aliases: ['professions', 'trades'],
  category: 'event',
  requiresPlayer: true,
  description: `${config.prefix}profession [learn <trade>|collect] — the four trades of the sect world`,

  async run(ctx) {
    const player = ctx.player
    const wrongWorld = sectDoorRefusal(player, {
      emoji: '📖', title: '*The mountain trades belong to the Sect Empire.*',
      here: { cmd: 'jobs', label: 'look at Astra jobs instead' },
    })
    if (wrongWorld) return ctx.reply(wrongWorld)
    if (!player.sect) return ctx.reply(missingSectRecordRefusal())

    const words = (ctx.args ?? []).map(a => String(a).toLowerCase()).filter(Boolean)
    const first = words[0] ?? ''

    if (!first) return ctx.reply(screen(player))

    const learning = first === 'learn' || first === 'study' || first === 'collect' || first === 'finish'

    if (first === 'collect' || first === 'finish') {
      let out = null
      let failed = null
      const ran = await withGrowthLock(ctx.from, async () => {
        await updatePlayer(ctx.db, ctx.from, fresh => {
          out = finishLesson(fresh, { now: Date.now() })
          if (!out.ok) {
            failed = out.reason === 'notYet'
              ? fill(profWords.learnRunning ?? '', {
                name: PROFESSIONS.find(r => r.id === out.lesson?.id)?.name ?? '', left: leftText(out.left),
              })
              : fill(profWords.noLesson ?? '📖 *You are not in the middle of a lesson.*', { prefix: p })
          }
          return fresh
        })
      })
      if (!ran) return ctx.reply(BUSY)
      if (failed) return ctx.reply(failed)
      if (!out?.ok) return ctx.reply(fill(profWords.noLesson ?? '📖 *You are not in the middle of a lesson.*', { prefix: p }))
      return ctx.reply([
        fill(profWords.learnDone ?? '', { name: out.record.name, level: out.level }),
        '',
        fill(profWords.foot ?? '', { prefix: p }),
      ].join('\n'))
    }

    const rest = learning ? words.slice(1).join(' ') : words.join(' ')
    const record = matchProfession(rest)
    if (!record && rest) {
      return ctx.reply(fill(profWords.noSuch ?? '', {
        count: PROFESSIONS.length,
        names: PROFESSIONS.map(r => r.name.toLowerCase()).join(', '),
      }))
    }
    if (!record) return ctx.reply(screen(player))

    // `.profession <trade>` — the card, and whether it can be learned HERE.
    if (!learning) return ctx.reply(card(player, record))

    let out = null
    let failed = null
    let busyLine = null
    const ran = await withGrowthLock(ctx.from, async () => {
      await updatePlayer(ctx.db, ctx.from, fresh => {
        // A lesson whose hours are already in is FINISHED by the same word:
        // saying "learn alchemy" again when the three hours are up is how a
        // disciple hands in the work.
        const lesson = lessonOf(fresh.sect)
        if (lesson && lesson.id === record.id) {
          const done = finishLesson(fresh, { now: Date.now() })
          if (done.ok) { out = { ok: true, done: true, record: done.record, level: done.level }; return fresh }
          busyLine = fill(profWords.learnRunning ?? '', { name: record.name, left: leftText(done.left) })
          return fresh
        }
        const refusal = refusalFor(fresh, record, { now: Date.now() })
        if (refusal) { failed = refusal; return fresh }
        out = { ...beginLesson(fresh, record, { now: Date.now() }), done: false }
        return fresh
      })
    })
    if (!ran) return ctx.reply(BUSY)
    if (busyLine) return ctx.reply(busyLine)
    if (failed) return ctx.reply(failed)
    if (!out?.ok) return ctx.reply(profWords.needPlace ?? '')

    if (out.done) {
      return ctx.reply([
        fill(profWords.learnDone ?? '', { name: out.record.name, level: out.level }),
        '',
        fill(profWords.foot ?? '', { prefix: p }),
      ].join('\n'))
    }
    return ctx.reply([
      fill(profWords.learnTitle ?? '', { name: record.name }),
      fill(profWords.learnScene ?? '', { description: record.description }),
      '',
      fill(profWords.learnNow ?? '', { name: record.name, hours: LEARN_HOURS }),
    ].join('\n'))
  },
}

export { learnRefusal }
