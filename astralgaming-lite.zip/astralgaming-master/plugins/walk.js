/**
 * walk.js — walking the Dreamlands, and the message that walks with you.
 *
 *   <prefix>dreamwalk             where you are in the walk, and where you are
 *   <prefix>dreamwalk cancel      abandon a walk that has died (crash safety)
 *   <prefix>dreamwalk <place>     the same walk .travel starts
 *   (<prefix>travel <place>    starts one — see plugins/travel.js)
 *
 * WHY THIS IS NOT `.journey` OR `.walk`: both words already have owners
 * (plugins/guide.js answers to 'journey', plugins/roam.js to 'walk'), and the
 * alias collision test is right to refuse a second owner. `.dreamwalk` is
 * unambiguous and names the realm it belongs to.
 *
 * THE MESSAGE (§10.1): one message per walk, EDITED once per step, exactly the
 * shape plugins/reborn.js uses for the Aura. lib/platform/whatsapp-edits.js is
 * the WhatsApp half; Telegram and Discord get their own branch; a platform that
 * cannot edit falls back to plain messages and the walk still works.
 *
 * THE CLOCK: JOURNEY.stepMs (3s) per step, or JOURNEY.sleepStepMs (4.5s) if you
 * are asleep — and a sleeper also eats a free hit from whatever is following
 * them. No potions mid-walk, no turning around, 1 stamina a step (2 if you are
 * carrying somebody).
 *
 * CRASH SAFETY: every step is persisted through updatePlayer() before the next
 * sleep, so a restart mid-walk leaves a journey with an old `lastStepAt`. The
 * handler's journey gate calls clearStaleJourney() on read, which drops any
 * walk older than JOURNEY.staleMs (5 minutes) instead of stranding the player.
 */

import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { editOwnWhatsAppText } from '../lib/platform/whatsapp-edits.js'
import { refreshStamina } from '../lib/combat-engine.js'
import {
  DREAMLAND_PLACES, JOURNEY, VOICE, dreamlandsArt, isDreamlandsLocation, stepsBetween,
} from '../lib/dreamlands-core.js'
import {
  arrivalCard, clearStaleJourney, finishJourney, isJourneying, journeyFrame, journeyStep,
  startJourney,
} from '../lib/dreamlands-journey.js'
import { handleDreamlandsDeath } from '../lib/dreamlands-death.js'
import { hasSleepWard } from '../lib/dreamlands-monsters.js'

const sleep = (ms) => new Promise(res => setTimeout(res, ms))

/**
 * openTicker(ctx, text) -> { edit(next) }
 * The same per-platform editing contract plugins/reborn.js uses; the WhatsApp
 * branch goes through lib/platform/whatsapp-edits.js so there is one place that
 * knows how to edit an own message.
 */
async function openTicker(ctx, text) {
  try {
    if (ctx.platform === 'whatsapp' && ctx.sock?.sendMessage) {
      const sent = await ctx.sock.sendMessage(ctx.sender, { text }, { quoted: ctx.msg })
      if (sent?.key) {
        return {
          edit: (next) => editOwnWhatsAppText(ctx.sock, ctx.sender, sent, next).catch(() => {}),
        }
      }
    } else if (ctx.platform === 'discord' && ctx.discordMessage?.channel) {
      const sent = await ctx.discordMessage.channel.send(text)
      if (typeof sent?.edit === 'function') return { edit: (next) => sent.edit(next).catch(() => {}) }
    } else if (ctx.platform === 'telegram' && ctx.bot?.api) {
      const sent = await ctx.bot.api.sendMessage(ctx.sender, text)
      if (sent?.message_id) {
        return { edit: (next) => ctx.bot.api.editMessageText(ctx.sender, sent.message_id, next).catch(() => {}) }
      }
    }
  } catch {
    // fall through to the plain message below
  }
  await ctx.reply(text).catch(() => {})
  return { edit: async () => {} }
}

/** The line for a refused start. */
function startRefusal(error, place, extra = {}) {
  const name = DREAMLAND_PLACES[place]?.name ?? place
  switch (error) {
    case 'already_here':
      return `🌫️ *You are already in ${name}.*\n_${VOICE.noJourney}_`
    case 'no_stamina':
      return `⚡ *You cannot make that walk.*\n_It is *${extra.steps}* step${extra.steps === 1 ? '' : 's'} and ` +
        `*${extra.cost}* stamina${extra.cost === 1 ? '' : '.'} You have *${extra.have}*. The fog does not carry anyone._`
    case 'in_battle':
      return `⚔️ *Finish the fight first.* _You cannot outwalk it._`
    case 'already_walking':
      return `🚶 *You are already walking somewhere.* _One foot at a time._`
    case 'too_far':
      return `🌫️ *That is farther than anyone walks in one go.* _Break it into shorter walks._`
    case 'unreachable':
      return `🌫️ *There is no way to walk there from here.* _Report this — the journey graph is broken._`
    case 'not_in_realm':
      return `🌫️ *That is on the other side of the door.* _Use_ *${config.prefix}portal* _to get there._`
    default:
      return `❌ *Unknown place* "_${place}_".`
  }
}

/**
 * canWalkTo(player, placeId) → null when the walk is legal, or a refusal line.
 *
 * The champion lock (§3.4) lives here: a place whose `lockedBy` place has not
 * been conquered yet cannot be walked into, and the refusal names the champion
 * that is still standing.
 */
export function canWalkTo(player, placeId) {
  const dest = DREAMLAND_PLACES[placeId]
  if (!dest) return `❌ *Unknown place* "_${placeId}_".`
  if (!isDreamlandsLocation(player.location)) {
    return (
      `🌫️ *You cannot walk there from here.*\n` +
      `_The Dreamlands are on the other side of the door in the square:_ *${config.prefix}portal*_._`
    )
  }
  const lockedBy = dest.lockedBy ?? null
  if (lockedBy && dest.alwaysOpen !== true) {
    const beaten = player.dungeonProgress?.[lockedBy]?.conquered === true
    if (!beaten) {
      const gate = DREAMLAND_PLACES[lockedBy]
      return VOICE.lockedPlace(dest.name, gate?.name ?? lockedBy)
    }
  }
  return null
}

/**
 * travelToPlace(ctx, placeId) — the whole walk, message and all.
 * Called by plugins/travel.js for a Dreamlands destination.
 */
export async function travelToPlace(ctx, placeId) {
  const { reply } = ctx
  const place = DREAMLAND_PLACES[placeId]
  if (!place) return reply(`❌ *Unknown place* "_${placeId}_".`)

  const blocked = canWalkTo(ctx.player, placeId)
  if (blocked) return reply(blocked)

  // A rescuer carrying a body walks the body home; the flag is on the player.
  const carries = ctx.player?.carryingBody?.name ?? null

  let started = null
  await updatePlayer(ctx.db, ctx.from, pl => {
    clearStaleJourney(pl)
    started = startJourney(pl, placeId, { carries })
    return pl
  })
  if (!started?.ok) return reply(startRefusal(started?.error, placeId, started ?? {}))

  let player = ctx.player
  const from = player.location
  const open = await openTicker(ctx, journeyFrame(player))
  const stepMs = JOURNEY.stepMs

  let arrived = false
  let died = false

  for (let step = 1; step <= started.steps; step++) {
    const asleep = (player.activeEffects ?? []).some(e => e.type === 'sleep' && e.remaining > 0)
    await sleep(asleep ? JOURNEY.sleepStepMs : stepMs)

    let result = null
    await updatePlayer(ctx.db, ctx.from, async pl => {
      result = journeyStep(pl, { ctx })
      if (result.dead) {
        died = true
        // Straight to the realm's ONE death path — no totem, no pearl, no
        // Premium save (§11.6). handleDreamlandsDeath does the freeze + art +
        // announcement itself.
        //
        // The step's own lines (what came out of the fog, what it hit for,
        // what its ability took, the HP it left) lead the death card. They used
        // to be dropped here: the ticker is only edited for a walker who
        // survives the step, so a walker killed on it read "FROZE." with no
        // hit, no damage and no HP. That was the "froze up with 4.9k HP"
        // report, with nothing on screen to show it was a real death.
        player = await handleDreamlandsDeath(pl, ctx, {
          cause: 'journey',
          msg: result.lines.join('\n').trim(),
        })
        return player
      }
      player = pl
      return pl
    })

    if (died) return player

    if (result.lines.length) await open.edit(journeyFrame(player, { note: result.lines.join('\n') }))

    if (result.arrived) { arrived = true; break }
  }

  if (!arrived) {
    // The walk was interrupted by something the loop does not own (a restart,
    // an admin clear). Leave the player where they stand, not in limbo.
    await updatePlayer(ctx.db, ctx.from, pl => { pl.journey = null; return pl })
    return reply(`🌫️ *The walk stopped.* _You are still in ${DREAMLAND_PLACES[from]?.name ?? from}._`)
  }

  let card = null
  await updatePlayer(ctx.db, ctx.from, async pl => {
    const checkpoint = pl.dungeonProgress?.[placeId]?.highestFloor ?? 0
    const startFloor = place.type === 'dungeon' ? Math.max(1, checkpoint) : 1
    const dest = finishJourney(pl, { startFloor })
    pl.stamina = refreshStamina(pl.stamina)
    card = arrivalCard(pl, dest ?? place)
    return pl
  })

  const art = card?.art
  const bodyNote = ctx.player?.carryingBody
    ? `\n\n🧊 _You are still carrying *${ctx.player.carryingBody.name}*. Get them through the door:_ *${config.prefix}portal exit*_._`
    : ''
  const text = `${card?.text ?? ''}${bodyNote}`
  if (art && typeof ctx.replyImage === 'function') {
    await ctx.replyImage(art, text).catch(() => reply(text))
  } else {
    await reply(text)
  }
  return player
}

/** The `.dreamwalk` readout. */
function statusText(player) {
  if (!isJourneying(player)) {
    const place = DREAMLAND_PLACES[player.location]
    if (!place) {
      return `🚶 *You are not walking anywhere.*\n_${config.prefix}travel <place> starts a walk._`
    }
    const home = stepsBetween(player.location, 'cradlehold')
    return (
      `🚶 *THE JOURNEY*\n\n` +
      `📍 *${place.name}*${place.type === 'dungeon' ? `  ·  Floor ${player.dungeonFloor ?? 1}/${place.floors}` : ''}\n` +
      `_${place.description ?? ''}_\n\n` +
      `🔙 Cradlehold is *${home}* step${home === 1 ? '' : 's'} away.\n` +
      `${hasSleepWard(player) ? '🌙 _The Draught is still in you._' : ''}\n` +
      `_Walk somewhere with *${config.prefix}travel <place>*._`
    )
  }
  return journeyFrame(player)
}

export default {
  name:           'dreamwalk',
  aliases:        [],
  category:       'dungeon',
  requiresPlayer: true,
  description:    `${config.prefix}dreamwalk [cancel|<place>] — where you are on the long walk between the Dreamlands' places.`,

  subcommands: [
    { cmd: 'cancel', desc: 'abandon a walk that has stopped moving' },
    { cmd: '<place>', desc: 'walk to a place (same as travel)' },
  ],

  async run(ctx) {
    const { args, reply, player } = ctx
    const sub = (args[0] ?? '').toLowerCase()

    if (sub === 'cancel' || sub === 'stop' || sub === 'abandon') {
      if (!isJourneying(player)) return reply(`🚶 *You are not walking anywhere.*`)
      await updatePlayer(ctx.db, ctx.from, pl => { pl.journey = null; return pl })
      return reply(
        `🌫️ *You stop walking.*\n` +
        `_The fog closes the distance you already covered. You are still in_ ` +
        `*${DREAMLAND_PLACES[player.location]?.name ?? player.location}*_._`,
      )
    }

    if (sub) {
      // Convenience: `.walk <place>` is the same walk `.travel <place>` starts.
      return travelToPlace(ctx, sub.replace(/\s+/g, '_'))
    }

    return reply(statusText(player))
  },
}
