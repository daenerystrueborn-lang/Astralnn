/**
 * followers.js — `.followers`, the audience side of fame.
 *
 * THE OWNER'S RULE: FOLLOWERS ARE FAME.
 *
 * One number, two readings. `player.fame` is the stat; `.fame` reads it as
 * clout (tiers, event history, payout rank) and `.followers` reads the same
 * number as an AUDIENCE (who is watching, what the next milestone unlocks, how
 * the last stream did). Nothing here writes a second counter, so the two
 * commands can never disagree and a dungeon clear can never be earned twice.
 *
 * That is why this file is thin: it is a lens, not a system. The streaming half
 * lives in plugins/stream.js and lib/astratok/.
 *
 * USAGE
 *   .followers            your following, tier, milestones and last stream
 *   .followers <player>   someone else's
 *   .followers top        the most followed players in the realm
 */
import { config } from '../config.js'
import { getPlayer } from '../lib/player-repo.js'
import { getFameTier, getNextFameTier, formatFame } from '../lib/fame-engine.js'
import { followersCard, n } from '../lib/astratok/cards.js'
import { MILESTONES } from '../lib/astratok/economy.js'
import { getProfile, getLastStream } from '../lib/astratok/store.js'

function findPlayerByName(allUsers, query) {
  const q = query.toLowerCase()
  return allUsers.find(u => u.name?.toLowerCase() === q)
    || allUsers.find(u => u.name?.toLowerCase().includes(q))
}

async function topFollowers(ctx) {
  const { db, reply } = ctx
  await db.read()
  const all = Object.values(db.data.users ?? {})
    .filter(u => (u.fame ?? 0) > 0)
    .sort((a, b) => (b.fame ?? 0) - (a.fame ?? 0))
    .slice(0, 10)

  if (!all.length) return reply(`⭐ *Nobody has an audience yet.*\n_Go and win something._`)

  const lines = [`⭐ *MOST FOLLOWED*`, '━━━━━━━━━━━━━━━━━━━━']
  all.forEach((u, i) => {
    const tier = getFameTier(u.fame ?? 0)
    lines.push(`  ${i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i + 1}.`} *${u.name}* · ${n(u.fame)} ${tier.emoji}`)
  })
  lines.push('', `_Followers are fame. Stream, fight and clear floors to grow them._`)
  lines.push(`📺 *${config.prefix}stream board* — who is live now`)
  return reply(lines.join('\n'))
}

export default {
  name: 'followers',
  aliases: ['audience', 'following'],
  category: 'social',
  requiresPlayer: true,
  description: 'Your followers, tier and milestones. Followers are fame',

  async run(ctx) {
    const { player, args, db, reply } = ctx
    const sub = args[0]?.toLowerCase()

    if (sub === 'top' || sub === 'leaderboard') return topFollowers(ctx)

    await db.read()
    let target = player
    if (args.length) {
      const found = findPlayerByName(Object.values(db.data.users ?? {}), args.join(' '))
      if (found) target = found
    }

    const followers = Math.max(0, Math.floor(target.fame ?? 0))
    const profile = await getProfile(target.id).catch(() => null)
    const last = await getLastStream(target.id).catch(() => null)
    const reached = profile?.milestones ?? []

    // A live stream is public information: it is the point of the board.
    let live = null
    if (target.id === player.id) {
      const { isStreaming, getStreamViewers } = await import('./stream.js')
      if (isStreaming(target.id)) live = { live: true, viewers: getStreamViewers(target.id), hype: 0 }
    }

    if (target.id !== player.id) {
      // Someone else's card is the public half only: no money, no last stream.
      const tier = getFameTier(followers)
      const next = getNextFameTier(followers)
      const lines = [
        `⭐ *${target.name.toUpperCase()}*`,
        '━━━━━━━━━━━━━━━━━━━━',
        `👥 *${formatFame(followers)}* followers · ${tier.emoji} *${tier.label}*`,
      ]
      if (next) lines.push(`📈 Next tier at *${formatFame(next.min)}*`)
      const done = MILESTONES.filter(m => m.at <= followers).length
      lines.push(`🏆 Milestones reached: *${done}/${MILESTONES.length}*`)
      if (profile?.career?.streams) {
        lines.push('', `📺 Streams run: *${n(profile.career.streams)}*`)
        lines.push(`📈 Best stream: *${n(profile.career.bestPeak)}* viewers`)
      }
      return reply(lines.join('\n'))
    }

    return reply(followersCard({
      followers,
      tier: getFameTier(followers),
      nextTier: getNextFameTier(followers),
      stream: { live: live?.live ?? false, viewers: live?.viewers ?? 0, hype: live?.hype ?? 0, lastStream: last },
      reached,
      prefix: config.prefix,
    }))
  },
}
