/**
 * breakthrough.js — `.breakthrough` : try the wall at the peak of a realm.
 *
 * One attempt, one roll, one outcome, and it is all inside the player's own
 * mutator: the bar is re-read, the realm is re-read, the requirement is read
 * out of data/cultivation-ladder.json and only then does anything move. A
 * refused attempt writes nothing, and two taps produce one result (the second
 * finds a cooldown, or a new stage, or a bar that is no longer full).
 */
import { cultivationNextStep } from '../lib/sect-guidance.js'
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { sectDoorRefusal } from '../lib/world-guards.js'
import { attemptBreakthrough, breakthroughInfo, breakthroughRefusal } from '../lib/sect-breakthrough.js'
import { withGrowthLock } from '../lib/sect-progress.js'
// The ascent has a picture, and only a WIN gets it: the art is the reward, so a
// refused attempt, a failure and a Qi deviation all go out as words alone.
import { ascensionPicture, replyWithSectPicture } from '../lib/sect-images.js'
import '../lib/sect-hooks.js'


export default {
  name: 'breakthrough',
  aliases: ['break'],
  category: 'event',
  requiresPlayer: true,
  description: `${config.prefix}breakthrough — try the next realm, when the bar is full at a peak`,

  async run(ctx) {
    const player = ctx.player
    const wrongWorld = sectDoorRefusal(player, {
      emoji: '⚡', title: '*Breakthroughs are a Sect Empire trial.*',
    })
    if (wrongWorld) return ctx.reply(wrongWorld)
    if (!player.sect) return ctx.reply('🔒 *Nothing to break through.* _You have no cultivation record._')

    // Preview and typo help never spend a pill; only explicit attempts roll.
    const first = String((ctx.args ?? [])[0] ?? '').toLowerCase()
    if (first && !['info', 'chance', 'attempt'].includes(first)) return ctx.reply(`📜 *${config.prefix}breakthrough info* previews the requirements. Use *${config.prefix}breakthrough* to attempt — the required pill is consumed even on failure.`)
    if (first === 'info' || first === 'chance') {
      const info = breakthroughInfo(player.sect, { now: Date.now() })
      return ctx.reply([
        `🔮 *${info.target ? `Into ${info.target}` : 'Nothing above you'}*`,
        info.target ? `🎬 *Trial: ${info.type === 'fight+tribulation' ? 'Heart Demon + Heavenly Tribulation' : info.type === 'fight' ? 'Heart Demon duel' : 'Realm breakthrough roll'}*` : '',
        info.type === 'roll' && info.base ? `_Base chance *${info.base}%*, plus *${info.fortuneBonus.toFixed(1)}%* from your fortune${info.aidBonus ? `, plus *${info.aidBonus.toFixed(0)}%* from your carried aid` : ''}${info.fateBonus ? `, plus *${info.fateBonus.toFixed(0)}%* from the sky and your boon` : ''}: *${info.chance.toFixed(1)}%*._` : '',
        info.type !== 'roll' && info.fateBonus ? `🌌 _The sky and your boon will weaken this trial by *${Math.min(50, info.fateBonus + info.aidBonus).toFixed(0)}%*._` : '',
        info.aid ? `🔥 *Aid ready: ${String(info.aid).replace(/_/g, ' ')} — it will be spent on the next attempt.*` : '',
        info.need ? `_Bar: *${info.have}/${info.need}* (${info.percent}%)._` : '',
        info.pill ? `💊 *Required pill: ${info.pill} — consumed when you attempt, even if you fail.*` : '🌿 *No entry pill required.*',
        breakthroughRefusal(player) || `✅ *Ready! ${config.prefix}breakthrough* to begin.`,
        `🎒 *${config.prefix}inventory* to check supplies · *${config.prefix}sectshop* to browse sect stock`,
      ].filter(Boolean).join('\n'))
    }

    let out = null
    let next = ''
    const ran = await withGrowthLock(ctx.from, async () => {
      await updatePlayer(ctx.db, ctx.from, pl => { out = attemptBreakthrough(pl, { now: Date.now() }); next = cultivationNextStep(pl, config.prefix); return pl })
    })
    if (!ran) return ctx.reply('🌩️ *One attempt at a time.* _The mountain is already listening._')
    if (!out) return ctx.reply('🔒 *Nothing to break through.*')
    if (!out.ok) return ctx.reply([...(out.lines ?? []), next].filter(Boolean).join('\n\n'))

    // A heart demon trial answers with the fight itself, not a chance line:
    // there is no roll to report, and the fight commands take it from here.
    if (out.kind === 'fight' || out.kind === 'tribulation') {
      return ctx.reply((out.lines ?? []).join('\n'))
    }
    const footer = out.outcome === 'success'
      ? `_Chance was *${out.chance.toFixed(1)}%*${out.forced ? ' (the owner called it)' : ''}._`
      : `_Chance was *${out.chance.toFixed(1)}%*, and the roll went against you${out.forced ? ' (the owner called it)' : ''}._`
    const text = [...out.lines, '', footer, next].join('\n')
    // The realms that are cleared by a roll land here: the stage moved, so the
    // ascent goes out under its picture. A loss keeps the words and nothing else.
    if (out.outcome === 'success') return replyWithSectPicture(ctx, ascensionPicture(), text)
    return ctx.reply(text)
  },
}
