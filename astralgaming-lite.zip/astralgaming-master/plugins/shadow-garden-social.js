import { config } from '../config.js'
import { characterMap } from '../lib/game-data.js'

/** No battle turn or currency cost. Only the exclusive holder gets her scene. */
export default {
  name: 'pat',
  aliases: ['compliment'],
  category: 'character',
  requiresPlayer: true,
  description: 'Pat Delta or compliment Alpha (exclusive holders): .pat delta · .compliment alpha',
  async run(ctx) {
    const isPat = ctx.cmd === 'pat'
    const id = isPat ? 'delta' : 'alpha'
    if (String(ctx.args?.[0] ?? '').toLowerCase() !== id) {
      return ctx.reply(`Try *${config.prefix}${ctx.cmd} ${id}*.`)
    }
    if (!(ctx.player?.ownedCharacters ?? []).includes(id)) {
      return ctx.reply(`🔒 Only ${characterMap[id]?.name ?? id}'s holder can do that.`)
    }
    const character = characterMap[id]
    const art = isPat ? character.patGif : character.complimentImage
    const text = isPat
      ? '🐺 _You pat Delta. She freezes for half a breath, then leans into your hand like she meant to do it all along._'
      : '🌑 _You compliment Alpha. Her composure holds; the small smile she cannot quite hide does not._'
    const send = isPat ? ctx.replyGif : ctx.replyImage
    if (art && typeof send === 'function') {
      try { return await send.call(ctx, art, text) } catch { /* keep the scene even if media fails */ }
    }
    return ctx.reply(text)
  },
}
