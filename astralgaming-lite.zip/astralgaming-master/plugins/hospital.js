/**
 * hospital.js — the Astral Town Hospital ward, and the only way out of it.
 *
 *   <prefix>hospital            your bed card: the bill, the bracket, and why
 *                               you are in it
 *   <prefix>hospital pay        settle the bill and walk out, healed to full
 *   <prefix>hospital work       take a shift for a tenth of your own bill
 *
 * THE BILL IS BY LEVEL (lib/hospital.js):
 *   below 30        5,000 Solars
 *   30 to 100      50,000 Solars
 *   above 100     500,000 Solars
 *
 * Every death now admits a player here (lib/combat-handlers.js's
 * handleDeath → hospitalAdmit), and lib/plugin-manager.js's dispatch holds the
 * door shut: while `player.hospital.admitted` is true, every command except this
 * one and a short info allowlist is refused. That lock is why `.hospital` is
 * the only command in the bot that has to be reachable from the inside.
 *
 * `.hospital work` exists so the bill is never a soft ban. A player with an
 * empty purse earns their way out a shift at a time, on a cooldown, and the
 * shift pays a quarter of their own bracket's bill, so every bracket is four
 * shifts from the door no matter what level the player died at. The ward is
 * deliberately not a faster farm than the rest of the game either: the shift
 * pays toward the bill, not into a career.
 *
 * Balance discipline: the discharge heals HP and MP to full. A death already
 * stripped gear and half the pools, and the bill is the penalty; charging twice
 * by also leaving them half dead would just make the next death automatic.
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import {
  HOSPITAL_NAME,
  HOSPITAL_FEE_TIERS,
  HOSPITAL_WORK_COOLDOWN_MS,
  hospitalBill,
  hospitalDischarge,
  hospitalWorkPay,
  isHospitalized,
} from '../lib/hospital.js'

const RULE = '━━━━━━━━━━━━━━━━━━━━'

const NOT_ADMITTED_LINES = [
  `🏥 *${HOSPITAL_NAME}*\n${RULE}\n` +
  `_The ward is quiet. You are not in one of its beds._\n\n` +
  `_Every death in the kingdom ends here now, and the door only opens once the bill is paid._`,
  `🏥 *${HOSPITAL_NAME}*\n${RULE}\n` +
  `_A nurse looks up, decides you are not bleeding, and goes back to her ledger._\n\n` +
  `_You are not admitted. Fight, and the ward will see you._`,
]

const WARD_LINES = [
  'Someone is crying two beds over. Nobody is coming to help them, because they have not paid either.',
  'The window is barred, which is strange for a hospital, and nobody here mentions it.',
  'A nurse counts coins at the desk. She does not look up when you walk past.',
  'The sheets are clean. The ward is not. There is a queue for the door.',
  'A man in the next bed keeps saying he only died a little. The nurse keeps writing it down anyway.',
]

function solars(n) {
  return Math.max(0, Math.round(Number(n) || 0)).toLocaleString()
}

function wardCard(player, p) {
  const bill = hospitalBill(player)
  if (!bill) return NOT_ADMITTED_LINES[Math.floor(Math.random() * NOT_ADMITTED_LINES.length)]
  const shift = hospitalWorkPay(bill.fee)
  const line = WARD_LINES[Math.floor((player.hospital?.visits ?? 0) % WARD_LINES.length)]
  return (
    `🏥 *${HOSPITAL_NAME.toUpperCase()}*\n${RULE}\n` +
    `_${line}_\n\n` +
    `🛏️ Admitted for: *${bill.cause ?? 'a death'}*\n` +
    `🏷️ Bracket: *${bill.tier.label}* _(Lv.${player.level ?? 1})_\n` +
    `❤️ HP: ${player.hp}/${player.maxHp}  ·  💧 MP: ${player.mp}/${player.maxMp}\n\n` +
    `💵 *Bill: ${solars(bill.fee)} Solars*\n` +
    `💰 You carry: *${solars(player.wallet?.solars)} Solars*\n` +
    (bill.paid > 0 ? `✅ Already paid: *${solars(bill.paid)} Solars*\n` : '') +
    `\n*${p}hospital pay*  settle it and walk out\n` +
    `*${p}hospital work*  take a ward shift for *${solars(shift)} Solars* ` +
    `_(every ${Math.round(HOSPITAL_WORK_COOLDOWN_MS / 60000)} minutes)_\n\n` +
    `_Nothing else answers while you are in this bed, not even the door._`
  )
}

export default {
  name: 'hospital',
  aliases: ['clinic', 'hosp'],
  category: 'town',
  requiresPlayer: true,
  description: 'The Astral Town Hospital: pay your death bill, or work a shift toward it',
  subcommands: [
    { cmd: 'pay', desc: 'settle the bill and walk out, healed to full' },
    { cmd: 'work', desc: 'take a ward shift for a share of your own bill' },
  ],

  async run(ctx) {
    const p = config.prefix
    if (!ctx.player) return ctx.reply(`⚠️ Register first with *${p}register*.`)

    const word = (ctx.args[0] ?? '').toLowerCase()

    // ── Not in a bed: the ward as scenery ──────────────────────────────────
    if (!isHospitalized(ctx.player) && !['pay', 'work'].includes(word)) {
      const ladder = HOSPITAL_FEE_TIERS
        .map(t => `  • ${t.label}: *${solars(t.fee)} Solars*`)
        .join('\n')
      return ctx.reply(
        `🏥 *${HOSPITAL_NAME.toUpperCase()}*\n${RULE}\n` +
        `_Every death in the kingdom ends here. The ward is warm, the door is locked, ` +
        `and the bill is by rank._\n\n` +
        `*The bill, by level*\n${ladder}\n\n` +
        `_${p}hospital pay* settles it once you are in a bed.\n` +
        `_${p}hospital work* earns toward it, a shift at a time, on a cooldown.\n\n` +
        `_You are not admitted. Go and be careful._`,
      )
    }

    if (word === 'work') return runWork(ctx, p)
    if (word === 'pay' || word === 'leave' || word === 'discharge') return runPay(ctx, p)

    return ctx.reply(wardCard(ctx.player, p))
  },
}

async function runPay(ctx, p) {
  let out = null

  await updatePlayer(ctx.db, ctx.from, (player) => {
    const bill = hospitalBill(player)
    if (!bill) {
      out = { reason: 'free' }
      return
    }
    const purse = Math.max(0, Number(player.wallet?.solars) || 0)
    if (purse < bill.owed) {
      out = { reason: 'poor', owed: bill.owed, purse, shift: hospitalWorkPay(bill.fee) }
      return
    }
    player.wallet.solars = purse - bill.owed
    const paid = bill.owed
    const cause = bill.cause
    hospitalDischarge(player)
    player.hp = player.maxHp
    player.mp = player.maxMp
    out = { reason: 'paid', paid, cause, purse: player.wallet.solars }
  })

  if (!out || out.reason === 'free') {
    return ctx.reply(
      `🏥 _You are not in a bed. There is nothing to pay._\n` +
      `_The nurse waves you toward the door, mildly offended on your behalf._`,
    )
  }

  if (out.reason === 'poor') {
    return ctx.reply(
      `🏥 *The desk will not open the door.*\n${RULE}\n` +
      `💵 Owed: *${solars(out.owed)} Solars*\n` +
      `💰 You carry: *${solars(out.purse)} Solars*\n\n` +
      `_Short by *${solars(out.owed - out.purse)}*. Take a shift instead:_\n` +
      `*${p}hospital work* pays *${solars(out.shift)} Solars* per shift.`,
    )
  }

  return ctx.reply(
    `🏥 *DISCHARGED*\n${RULE}\n` +
    `_The desk counts the coin twice, stamps the ledger, and the bolt finally turns._\n\n` +
    `💵 Paid: *${solars(out.paid)} Solars*\n` +
    `💰 Left in your purse: *${solars(out.purse)} Solars*\n` +
    `❤️ Restored to full: *${ctx.player?.maxHp ?? 'full'} HP*\n` +
    (out.cause ? `🛏️ You were in for: *${out.cause}*\n` : '') +
    `\n🏛️ *You are standing back in Astral Town.*\n` +
    `_The door is open. Try to keep it that way: *${p}travel*, *${p}attack*, *${p}dungeon* all answer again._`,
  )
}

async function runWork(ctx, p) {
  let out = null

  await updatePlayer(ctx.db, ctx.from, (player) => {
    const bill = hospitalBill(player)
    if (!bill) {
      out = { reason: 'free' }
      return
    }
    const now = Date.now()
    const last = Number(player.hospital?.lastWorkAt) || 0
    const wait = HOSPITAL_WORK_COOLDOWN_MS - (now - last)
    if (last && wait > 0) {
      out = { reason: 'cooldown', wait, owed: bill.owed }
      return
    }
    const pay = hospitalWorkPay(bill.fee)
    player.wallet = player.wallet ?? {}
    player.wallet.solars = Math.max(0, Number(player.wallet.solars) || 0) + pay
    if (player.hospital) player.hospital.lastWorkAt = now
    out = { reason: 'worked', pay, owed: bill.owed, purse: player.wallet.solars, canPay: player.wallet.solars >= bill.owed }
  })

  if (!out || out.reason === 'free') {
    return ctx.reply(`🏥 _There is no shift for you. You are not admitted._`)
  }

  if (out.reason === 'cooldown') {
    const mins = Math.ceil(out.wait / 60000)
    return ctx.reply(
      `🏥 *The sister shoos you back to bed.*\n` +
      `_You have already worked this hour. Try again in *${mins} minute${mins === 1 ? '' : 's'}*._\n` +
      `💵 Still owed: *${solars(out.owed)} Solars*`,
    )
  }

  return ctx.reply(
    `🏥 *A shift on the ward*\n${RULE}\n` +
    `_You carry water, fold sheets and hold a man's hand while he counts his own toes. ` +
    `The sister pays you out of the desk drawer without a word._\n\n` +
    `💵 Earned: *${solars(out.pay)} Solars*\n` +
    `💰 Purse: *${solars(out.purse)} Solars*\n` +
    `💵 Still owed: *${solars(out.owed)} Solars*\n\n` +
    (out.canPay
      ? `_That covers it._ *${p}hospital pay* _and the door opens._`
      : `_Take another shift when it comes back:_ *${p}hospital work*`),
  )
}
