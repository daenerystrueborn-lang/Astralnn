import { runRegressorSpin } from '../lib/regressor-spin-runner.js'

export default {
  name: 'alenious-spin',
  aliases: ['aleniousspin'],
  category: 'character',
  requiresPlayer: true,
  description: 'god series — 10 Gems per spin, guaranteed by spin 300; currently staged',
  async run(ctx) { return runRegressorSpin(ctx, 'alenious') },
}
