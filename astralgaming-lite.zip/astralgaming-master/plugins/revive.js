/**
 * revive.js — use a Revival Stone on a character Yelan has killed.
 *
 *   <prefix>revive <character>     bring one fallen companion back
 *
 * THE ONLY DOOR. This command and plugins/revival.js are the whole revival
 * system, on purpose: `player.slainCharacters` cannot be cleared by any other
 * effect in the bot — not a cure, not a Phoenix Down, not Mei's self-revival,
 * not a full heal, not a level-up. That is what makes losing a character to
 * Yelan mean something, so if you are reading this because you want to add a
 * second way back, don't; change REVIVAL_STONE_PRICE instead.
 *
 * ATOMICITY: one stone out and the slain flag cleared in ONE updatePlayer()
 * mutator, so the stone can never be consumed without the character coming back
 * (and the flag can never clear for free).
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { characters, characterMap } from '../lib/game-data.js'
import { reviveCharacter, slainCharacters } from '../lib/yelan-engine.js'
// ── The Dreamlands' revive (§12.7), sharing this command's name ────────────
// Same collision as `.rescue`: `.revive` already means "use a Revival Stone on
// a companion Yelan killed". The Dreamlands reading is claimed by ANY typed
// name that is a real player — frozen, carried, asleep or awake — and each
// state gets its true answer. Only a name matching nobody falls through to the
// companion roster.
import { config as botConfig } from '../config.js'
import { updatePlayer as updateDreamPlayer } from '../lib/player-repo.js'
import { REVIVAL_DRINK_ITEM, CONSCIOUSNESS, dreamlandsArt, isFrozen } from '../lib/dreamlands-core.js'
import { findPersonByName, grantConsciousness, isUnconscious } from '../lib/dreamlands-death.js'

/**
 * maybeDreamlandsRevive(ctx) — the Dreamlands half of `.revive`.
 *
 * A typed name that is ANY player claims this command — frozen in the ice,
 * carried on a shoulder, asleep in the square, or already awake. Each state
 * gets the true answer ("still in the ice", "on X's shoulder", the pour
 * itself, "already awake"). Only a name that matches no player at all falls
 * through to the companion roster, because "you don't own a character called
 * Absolute Jester_MH" is a nonsense answer about a real person.
 */
async function maybeDreamlandsRevive(ctx) {
  const p = botConfig.prefix
  const query = ctx.args.join(' ').trim()
  if (!query) return null

  const target = findPersonByName(ctx.db, query, { exceptJid: ctx.from })
  if (!target) return null

  // Still in the ice (not lifted): a drink into a body in the ice goes into
  // the ice. They need the rescue first, not a pour.
  if (isFrozen(target) && !target.frozen?.carried) {
    return ctx.reply(
      `🧊 *${target.name} is still in the ice.*\n` +
      `_A Drink poured out there goes into the ice. Lift them first:_ *${p}rescue ${target.name}*_. ` +
      `_Then get them home, then pour._`,
    )
  }
  // Out of the ice but still on a shoulder: nothing to pour into yet.
  if (isFrozen(target) && target.frozen?.carried) {
    return ctx.reply(
      `🫂 *${target.name} is on *${target.frozen.rescuer ?? 'someone'}*'s shoulder.*\n` +
      `_They are out of the ice but not home yet. Get them to the Astral Town square first ` +
      `(_*${p}travel cradlehold*_ then _*${p}portal exit*_), then pour:_ *${p}revive ${target.name}*_._`,
    )
  }
  // Already awake and on their own: this also answers "what drink do I give
  // them" when the owner's .take-to town already woke them outright.
  if (!isUnconscious(target)) {
    return ctx.reply(
      `👁️ *${target.name} is already awake and on their own.*\n` +
      `_No drink needed. The Revival Drink is only for someone lying in the square._`,
    )
  }

  const player = ctx.player
  const drinks = (player.inventory ?? []).filter(id => id === REVIVAL_DRINK_ITEM).length

  if (player.location !== CONSCIOUSNESS.wakeLocationId) {
    return ctx.reply(
      `🚪 *They are lying in the Astral Town square.*\n` +
      `_You are not there. Get back to town first._`,
    )
  }
  if (drinks < 1) {
    return ctx.reply(
      `🧪 *No Revival Drink.*\n` +
      `_Nothing else in the bot brings a rescued climber round — the Drink is the only way, ` +
      `and it is sold in the ordinary shop for 800 ☀️ (_*${p}shop buy revival drink*_)._`,
    )
  }

  let outcome = null
  await updateDreamPlayer(ctx.db, ctx.from, pl => {
    pl.inventory = pl.inventory ?? []
    const idx = pl.inventory.indexOf(REVIVAL_DRINK_ITEM)
    if (idx === -1) { outcome = { reason: 'no_drink' }; return pl }
    // findPersonByName returns the LIVE record; the id (not a stray .jid
    // field, which players have never had) is the db key.
    const live = ctx.db.data.users[target.id] ?? target
    if (!live) { outcome = { reason: 'gone' }; return pl }
    pl.inventory.splice(idx, 1)
    // The drink is poured into the TARGET's record, so the meter lives on the
    // person being woken rather than on whoever happens to be holding the bag.
    const res = grantConsciousness(live, { drinks: 1, by: pl.name })
    outcome = { reason: 'ok', ...res, left: pl.inventory.filter(id => id === REVIVAL_DRINK_ITEM).length }
    return pl
  })

  if (outcome?.reason === 'no_drink') return ctx.reply(`🧪 *No Revival Drink.* Buy one: *${p}shop buy revival drink*.`)
  if (outcome?.reason === 'gone') return ctx.reply(`⚠️ *They are not there anymore.* _Nothing was consumed._`)
  if (outcome?.reason !== 'ok') return ctx.reply(`⚠️ *The Drink did not take.* _Nothing was consumed._`)

  const art = dreamlandsArt('rescue_scene')
  const text =
    `${outcome.line}\n\n` +
    (outcome.woken
      ? `_They are awake. They are going to be very cold for a while, and they have lost everything they were carrying._`
      : `_Keep going. ${CONSCIOUSNESS.max - (outcome.consciousness ?? 0)} to go._\n_(Drinks left: *${outcome.left}*)_`)
  if (art && typeof ctx.replyImage === 'function' && outcome.woken) {
    return ctx.replyImage(art, text).catch(() => ctx.reply(text))
  }
  return ctx.reply(text)
}

export const REVIVAL_STONE_ITEM = 'revival_stone'

const RULE = '━━━━━━━━━━━━━━━━━━━━'

/**
 * Loose id/name match over the player's OWN roster, so `.revive witch of envy`
 * and `.revive yato` both work — and so naming someone else's character is
 * answered with "you don't own that" rather than by looking up a stranger's
 * record. OWNERSHIP IS THE FILTER, not a check bolted on afterwards: a lookup
 * that can return a character the player does not have is one refused-branch
 * away from being a leak.
 */
function findOwnedCharacter(query, player) {
  const q = String(query ?? '').toLowerCase().trim()
  if (!q) return null
  const owned = (player?.ownedCharacters ?? [])
    .map((id) => characterMap[id])
    .filter(Boolean)
  return owned.find((c) => c.id === q)
    ?? owned.find((c) => c.name.toLowerCase() === q)
    ?? owned.find((c) => c.name.toLowerCase().includes(q))
    ?? null
}

export default {
  name: 'revive',
  aliases: ['revivecharacter', 'revivestone'],
  category: 'combat',
  requiresPlayer: true,
  description: `${config.prefix}revive <character> — use a Revival Stone on a companion Yelan has slain`,

  async run(ctx) {
    const pr = config.prefix
    const player = ctx.player

    // The Dreamlands first — but only for a name that is a person in the square.
    const dreamlands = await maybeDreamlandsRevive(ctx)
    if (dreamlands !== null && dreamlands !== undefined) return dreamlands

    if (!String(ctx.args[0] ?? '').trim()) {
      const fallen = slainCharacters(player)
      const names = fallen.map((id) => characterMap[id]?.name ?? id)
      return ctx.reply(
        (names.length
          ? `🖤 *Fallen:* ${names.map((n) => `*${n}*`).join(', ')}\n\n`
          : `🖤 _None of your companions have been slain._\n\n`) +
        `_Use a Revival Stone: *${pr}revive <character>*._\n` +
        `_Buy one: *${pr}revival buy*._`,
      )
    }

    const target = findOwnedCharacter(ctx.args.join(' '), player)
    const stones = (player.inventory ?? []).filter((id) => id === REVIVAL_STONE_ITEM).length

    // ── Refusals, each named so the player always knows which one bit ─────────
    if (player.inBattle) {
      return ctx.reply(`⚔️ *Not mid-fight.*\n_A Revival Stone is used between battles._`)
    }
    if (!target) {
      return ctx.reply(
        `❌ You don't own a character called *${ctx.args.join(' ')}*.\n_See *${pr}character* for your roster._`,
      )
    }
    if (!slainCharacters(player).includes(target.id)) {
      return ctx.reply(
        `🩹 *${target.name}* is not slain.\n_They are standing, and they do not need the stone._`,
      )
    }
    if (stones <= 0) {
      return ctx.reply(
        `🪨 *No Revival Stone.*\n${RULE}\n` +
        `_Nothing else in the bot can bring *${target.name}* back — the stone is the only way._\n\n` +
        `📥 *${pr}revival buy* — 💎50 gems.`,
      )
    }

    let outcome = null
    await updatePlayer(ctx.db, ctx.from, (p) => {
      // Re-validate on the live record: the fight may have ended, and another
      // command may have spent the stone, between the read above and here.
      if (p.inBattle) { outcome = { reason: 'in_battle' }; return }
      p.inventory = p.inventory ?? []
      const idx = p.inventory.indexOf(REVIVAL_STONE_ITEM)
      if (idx === -1) { outcome = { reason: 'no_stone' }; return }
      if (!reviveCharacter(p, target.id)) { outcome = { reason: 'not_slain' }; return }
      p.inventory.splice(idx, 1)
      outcome = { reason: 'ok', left: p.inventory.filter((id) => id === REVIVAL_STONE_ITEM).length }
    })

    if (outcome?.reason === 'in_battle') return ctx.reply(`⚔️ *Not mid-fight.*`)
    if (outcome?.reason === 'no_stone') return ctx.reply(`🪨 *No Revival Stone.* Buy one: *${pr}revival buy*.`)
    if (outcome?.reason === 'not_slain') return ctx.reply(`🩹 *${target.name}* is not slain.`)
    if (outcome?.reason !== 'ok') return ctx.reply(`⚠️ The stone did not take. Nothing was consumed.`)

    return ctx.reply(
      `🪨 *THE STONE TAKES.*\n${RULE}\n` +
      `${target.emoji ?? '🖤'} *${target.name}* draws a breath they should not have had, and stands up.\n` +
      `✅ _Equippable again: *${pr}character equip ${target.id}*_\n` +
      `_(Stones left: *${outcome.left}*)_`,
    )
  },
}
