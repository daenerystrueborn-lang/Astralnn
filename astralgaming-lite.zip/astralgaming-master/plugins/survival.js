import { config } from '../config.js'
import { personalFloorCount, preparationShifts, preparationQuestClaimed, hasTradeMastery, preparationReady, gearRequiredLevel, levelGap, targetFights } from '../lib/survival-progression.js'
import { allItems } from '../lib/game-data.js'
import { survivalReadout } from '../lib/endless-survival.js'
import { creatorDailyAllowance } from '../lib/creator-budget.js'

export default {
  name: 'survival', aliases: ['readiness'], category: 'dungeon', requiresPlayer: true,
  description: 'See personal progression, equipment attunement and survival combat rules',
  async run(ctx) {
    const p=ctx.player, pr=config.prefix
    const id=ctx.args?.join(' ').toLowerCase()
    const item=id ? allItems.find(i=>i.id===id || i.name?.toLowerCase()===id) : null
    const floors=personalFloorCount(p)
    const shifts=preparationShifts(p)
    const quests=preparationQuestClaimed(p) ? 1:0
    const lines=[
      '⚔️ *SURVIVAL READINESS*',
      `Level: ${p.level} · Personal dungeon floors: ${floors}/10`,
      `Player-funded trade: ${hasTradeMastery(p)?'unlocked':'locked (Level 20 + 10 personal floors)'}`,
      `Field preparation: ${shifts}/3 job shifts · ${quests}/1 quest claimed · ${preparationReady(p)?'ready':'not ready'}`,
      `Use ${pr}jobs, ${pr}work and ${pr}quest. New party victories do not count as personal floors. Legacy checkpoints are credited for compatibility.`,
      '',
      'New equipment activation: bonuses impose Level 15/30/60 gates. Tier 30+ also needs personal floors and field preparation. Ownership is never removed by these gates.',
      ...(item?[`${item.name}: Level ${gearRequiredLevel(item)} attunement.`]:[]),
      '',
      `Level XP gap: ${levelGap(p.level)} · baseline appropriate fights/level: ${targetFights(p.level)} (ordinary solo progression dungeons).`,
      'Wage XP: 10% of a level per 24 hours; only the latest 10 hours accrue.',
      `Creator wallet allowance: ${creatorDailyAllowance(p)} Solars per UTC day across streams and milestones.`,
      '',
      'From Level 11: 3 consumables per regular encounter, 7 per boss; wait two of your combat turns between uses. Bag and inventory share the budget.',
      'Only one prepared meal buff set at a time. Survival enemies break repeated stun/freeze/sleep after two lost turns.',
      'Read the intent: guard cleaves, manage exposure, use recovery openings. Long fights build pressure.',
      'Repeating an offensive action three times invites a warned counterstrike. Change action to break the read.',
      'Party: defend to close formation gaps and cover allies. Rotate defenders; one player cannot provide full cover forever.',
      survivalReadout(p.battleState?.enemy),
      '',
      '☠️ Endless final death: carried items and ALL equipment, including protected/Reborn gear, are lost under the new entry policy. Ordinary chest contents also vanish after accepting the entry policy. Existing revives remain; Ender/home/guild storage are excluded.',
    ]
    return ctx.reply(lines.filter(x=>x!==undefined).join('\n'))
  },
}
