/**
 * dreamlandsrescue — `.rescue <name>` : pull a frozen player out of the ice.
 *
 * This used to share a plugin with Guardian of the Innocent's pen raids. That
 * event has been removed, and the two were never related: the Dreamlands wall
 * is the endgame rescue where a Level 100 climber walks out to a body in the
 * ice, fights off the fifty nightmares standing over it, and carries them home.
 * Splitting it out keeps that path alive instead of deleting it along with a
 * beastkin event that happened to use the same verb.
 *
 *   .rescue              the bodies in the ice (and the carry status if you
 *                        are already carrying someone)
 *   .rescue <name>       walk out to them, fight the wall, lift them
 *
 * The fight it starts is typed 'dreamlands_rescue' so handleVictory() routes
 * the win to handleDreamlandsRescueWin() (lib/combat-handlers.js), which
 * decrements the wall on the body's LIVE record and chains the next guardian.
 *
 * Copy is player facing: no dashes.
 */
import { config as botConfig } from '../config.js'
import { updatePlayer as updateDreamPlayer, getPlayer as getDreamPlayer } from '../lib/player-repo.js'
import {
  DREAMLAND_PLACES, VOICE, buildBodyGuardian, dreamlandsArt, isDreamlandsLocation, stepsBetween,
} from '../lib/dreamlands-core.js'
import {
  findFrozenByName, findPersonByName, frozenBodiesText, guardianWallOf, liftBody,
  reconcileCarry, isUnconscious,
} from '../lib/dreamlands-death.js'
import { travelToPlace } from './walk.js'
import { hasSleepWard } from '../lib/dreamlands-monsters.js'
import { nightmareEncounterBrief, nightmareTierLabel } from '../lib/dreamlands-presentation.js'
import { levelTag } from '../lib/level-display.js'

/** The status a rescuer mid-carry gets from a bare `.rescue`, wherever they are. */
function carryStatusText(player) {
  const p = botConfig.prefix
  const name = player.carryingBody?.name ?? 'them'
  return (
    `🫂 *YOU ARE CARRYING ${name.toUpperCase()}.*\n\n` +
    `_Get them home:_ *${p}travel cradlehold* _then_ *${p}portal exit*_.\n` +
    `_Once you are through the door, a Revival Drink sets them free:_ *${p}revive ${name}*_._`
  )
}

/**
 * maybeDreamlandsRescue(ctx) — the Dreamlands half of `.rescue`.
 * Returns null when this is not a Dreamlands rescue (no name given, or the name
 * belongs to nobody in the ice), so the Guardian event keeps the command.
 */
async function maybeDreamlandsRescue(ctx) {
  const p = botConfig.prefix
  const player = ctx.player
  const name = ctx.args.join(' ').trim()

  // A bare `.rescue` (or `.rescue list`) shows the ice. Nothing else claims
  // this verb any more, so the list is always the answer.
  if (!name || name.toLowerCase() === 'list') {
    // Mid-carry: the carry status is the only honest answer, wherever the
    // rescuer is standing. They are literally doing the rescue right now.
    if (player.carryingBody?.name) return ctx.reply(carryStatusText(player))

    // The ice list answers a bare `.rescue`, from town or from out in the
    // realm. The Guardian event used to claim the bare command when it was
    // running; with it gone, listing the ice is the only meaning it has left.
    const bodies = frozenBodiesText(ctx.db)
    const art = dreamlandsArt('rescue_scene')
    if (art && typeof ctx.replyImage === 'function') {
      return ctx.replyImage(art, bodies).catch(() => ctx.reply(bodies))
    }
    return ctx.reply(bodies)
  }

  const body = findFrozenByName(ctx.db, name, { exceptJid: ctx.from })
  if (!body) {
    // Not a body in the ice. A name that is a real player still claims the
    // command: say where they actually are rather than a flat "not found".
    const person = findPersonByName(ctx.db, name, { exceptJid: ctx.from })
    if (!person) return null
    if (isUnconscious(person)) {
      return ctx.reply(
        `🏠 *${person.name} is already home.*\n` +
        `_They are lying in the Astral Town square. The rescue is done. ` +
        `Pour a Revival Drink into them:_ *${p}revive ${person.name}*_._`,
      )
    }
    return ctx.reply(
      `👁️ *${person.name} is already awake and on their own.*\n` +
      `_Nothing to rescue. The ice has no claim on them._`,
    )
  }

  // ── Refusals ────────────────────────────────────────────────────────────
  if (player.level < 100) {
    return ctx.reply(`🔒 *Only a Level 100 climber can go out to the ice.*\n_You are Level ${player.level}._`)
  }
  if (!player.portal?.unlocked) {
    return ctx.reply(
      `🚪 *You have never been through the door.*\n` +
      `_The ice is in the Dreamlands. Open the door first:_ *${p}portal*_._`,
    )
  }
  if (!isDreamlandsLocation(player.location)) {
    return ctx.reply(
      `🌫️ *You are on the wrong side of the door.*\n` +
      `_Go through first (_*${p}portal enter*_) and then walk out to the ice._`,
    )
  }
  if (player.inBattle) return ctx.reply(`⚔️ *Finish the fight first.*`)
  if (player.carryingBody) {
    return ctx.reply(
      `🧊 *You are already carrying someone.*\n` +
      `_Get them home first:_ *${p}travel cradlehold* _then_ *${p}portal exit*_._`,
    )
  }

  // A body whose rescuer died or walked away is free again (lazy reconcile).
  const reconcile = reconcileCarry(ctx.db.data.users, body)
  if (reconcile.frozen?.carried && reconcile.frozen.rescuer !== player.name) {
    return ctx.reply(
      `🧊 *Someone else already has them.*\n` +
      `_*${reconcile.frozen.rescuer}* lifted *${body.name}* out of the ice. There is only one body and only one pair of arms._`,
    )
  }

  const iceId = body.locationId ?? 'ice_wastelands'
  const where = DREAMLAND_PLACES[iceId]?.name ?? 'the ice'

  // ── Walk out there if we are not there ──────────────────────────────────
  if (player.location !== iceId) {
    const steps = stepsBetween(player.location, iceId)
    const stamina = (steps ?? 0) * 1
    if ((player.stamina?.current ?? 0) < stamina) {
      return ctx.reply(
        `⚡ *You cannot make the walk out to ${where}.*\n` +
        `_It is *${steps}* step${steps === 1 ? '' : 's'} and you have *${player.stamina?.current ?? 0}* stamina._`,
      )
    }
    await ctx.reply(
      `🧊 *${body.name} is out in ${where}.*\n` +
      `_You start walking. Something will follow you the whole way._`,
    )
    await travelToPlace(ctx, iceId)
    // Re-read: the walk may have ended in the ice, in a fight, or not at all.
    const after = getDreamPlayer(ctx.db, ctx.from)
    if (!after || after.location !== iceId || after.inBattle) return null
    return engageTheBody(ctx, body)
  }

  return engageTheBody(ctx, body)
}

/**
 * engageTheBody(ctx, body) — standing over the body, so what happens next is
 * decided by the wall: nightmares still standing → the next guardian fight;
 * wall broken → the lift. The wall is re-read from the LIVE record so a
 * rescuer who walked out here behind someone else's half-finished wall sees
 * the true count, and a wall broken by a third party mid-walk reads broken.
 */
async function engageTheBody(ctx, body) {
  const liveBody = ctx.db.data.users?.[body.id] ?? body
  const wall = guardianWallOf(liveBody)
  if (wall.standing) return startGuardianFight(ctx, liveBody, wall)
  return liftAndReport(ctx, liveBody)
}

/**
 * startGuardianFight(ctx, body, wall) — one fight of the fifty.
 *
 * An ordinary realm fight against one lesser nightmare, typed
 * 'dreamlands_rescue' so handleVictory() routes the win to
 * handleDreamlandsRescueWin() (lib/combat-handlers.js), which decrements the
 * wall on the body's LIVE record and chains the next guardian. No stamina is
 * charged: the wall is a wall, not a treadmill — the realm's other prices
 * (potions spent, decay stacked, the walk, the risk of joining them) are what
 * fifty fights cost, and a rescuer with 30 stamina could not otherwise clear
 * a 50-wall in one campaign at all.
 */
async function startGuardianFight(ctx, body, wall) {
  const p = botConfig.prefix
  const enemy = buildBodyGuardian()
  const remaining = wall?.remaining ?? guardianWallOf(body).remaining
  const total = wall?.total ?? guardianWallOf(body).total

  await updateDreamPlayer(ctx.db, ctx.from, pl => {
    if (pl.inBattle || pl.carryingBody) return pl
    pl.inBattle = true
    pl.battleState = {
      type: 'dreamlands_rescue',
      locationId: 'ice_wastelands',
      floor: 0,
      enemy,
      bossState: null,
      playerDefending: false,
      turn: 1,
      abilityCooldowns: {},
      lastMoveAt: Date.now(),
      // Which body this fight is for. The wall count is re-read LIVE on every
      // win, so this is bookkeeping and narration, never the source of truth.
      rescue: { bodyJid: body.jid ?? null, bodyName: body.name, remaining, total },
    }
    return pl
  })
  if (!ctx.db.data.users?.[ctx.from]?.inBattle) {
    return ctx.reply(`⚔️ *Finish the fight you are already in first.*`)
  }

  const down = total - remaining
  const art = dreamlandsArt('ice_wastelands')
  const livePlayer = ctx.db.data.users?.[ctx.from] ?? ctx.player
  const nightmareBrief = nightmareEncounterBrief(enemy, {
    sleepWardActive: hasSleepWard(livePlayer),
    statusImmune: !!(livePlayer.statusImmune || livePlayer.statusImmuneSilent),
  })
  const nightmareTier = nightmareTierLabel(enemy) || 'Nightmare'
  const msg =
    `🧊 ━━━ *THE WALL AROUND ${body.name.toUpperCase()}* ━━━ 🧊\n\n` +
    `_${VOICE.guardianWallIntro}_\n` +
    (remaining === 1 ? `_${VOICE.guardianWallLast}_\n` : '') +
    `\n🧊 _Guardians standing: *${remaining}* of ${total}_` +
    (down > 0 ? ` _(${down} already down)_` : '') + `\n` +
    `_Every one of them has to die before the ice will let ${body.name} go._\n\n` +
    `${enemy.emoji} *${enemy.name}* _(🌫️ ${nightmareTier})_\n` +
    `${nightmareBrief}\n` +
    `❤️ ${hpBar(enemy.hp, enemy.maxHp)}\n` +
    `⚔️ ATK: *${enemy.atk}*  🛡️ DEF: *${enemy.def}*\n\n` +
    `👤 *${ctx.player.name}* (${levelTag(ctx.player, { prefix: 'Lv ' })})\n` +
    `❤️ ${hpBar(ctx.player.hp, ctx.player.maxHp)}\n\n` +
    `*${p}attack* · *${p}skill <name>* · *${p}defend* · *${p}flee*`
  if (art && typeof ctx.replyImage === 'function') {
    return ctx.replyImage(art, msg).catch(() => ctx.reply(msg))
  }
  return ctx.reply(msg)
}

/** The lift itself, once the rescuer is standing over the body. */
async function liftAndReport(ctx, body) {
  const p = botConfig.prefix
  // Re-read the LIVE body: every caller but the last one is holding an object
  // from an earlier read, and the lift has to land on the record. The db key
  // is the player's `id` — records have never carried a `.jid` field.
  const liveBody = ctx.db.data.users?.[body.id] ?? body
  let lifted = null
  await updateDreamPlayer(ctx.db, ctx.from, pl => {
    const fresh = reconcileCarry(ctx.db.data.users, liveBody)
    lifted = liftBody(pl, fresh)
    if (lifted.ok) {
      pl.carryingBody = { name: body.name, jid: body.id ?? body.jid ?? null, since: Date.now() }
    }
    return pl
  })
  if (lifted?.ok) {
    const art = dreamlandsArt('rescue_scene')
    const text =
      `🧊 *YOU LIFT ${body.name.toUpperCase()} OUT OF THE ICE.*\n\n` +
      `_They are breathing. It is very slow, and very far apart, and it is there._\n` +
      `_The cold comes off them like something that has been waiting to be put down._\n\n` +
      `🚶 *Carry them home:* *${p}travel cradlehold*\n` +
      `🚪 _Then through the door:_ *${p}portal exit*  _(the door wants 10,000 ☀️ from you, and nothing from them.)_\n` +
      `_While you carry them every step costs double stamina, and whatever is following you hits 25% harder._`
    if (art && typeof ctx.replyImage === 'function') {
      return ctx.replyImage(art, text).catch(() => ctx.reply(text))
    }
    return ctx.reply(text)
  }
  if (lifted?.error === 'self') return ctx.reply(`🧊 *You cannot carry yourself.*`)
  if (lifted?.error === 'not_frozen') return ctx.reply(`🧊 *${body.name} is not in the ice anymore.*`)
  if (lifted?.error === 'already_lifted') {
    return ctx.reply(`🧊 *${lifted.by} already has them.*`)
  }
  if (lifted?.error === 'not_at_body') {
    return ctx.reply(`🧊 *You are not standing next to the body.*`)
  }
  return ctx.reply(`⚠️ *The ice did not let go.* _Nothing was consumed._`)
}

export default {
  name: 'rescue',
  aliases: ['freecaptives', 'rescues'],
  category: 'dreamlands',
  requiresPlayer: true,
  description: 'Rescue a frozen player out of the Dreamlands ice, one guardian at a time',

  async run(ctx) {
    const p = botConfig.prefix
    const result = await maybeDreamlandsRescue(ctx)
    if (result !== null && result !== undefined) return result
    // Nothing in the ice by that name, and not a bare call either. Say so
    // rather than falling through to a feature that no longer exists.
    const name = ctx.args.join(' ').trim()
    if (name && name.toLowerCase() !== 'list') {
      return ctx.reply(
        `🧊 *There is nobody called "${name}" in the ice.*\n` +
        `_Type *${p}rescue* on its own to see who is out there._`,
      )
    }
    return null
  },
}

