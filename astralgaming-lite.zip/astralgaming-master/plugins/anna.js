/**
 * anna.js — speak to Anna, the Vanguard receptionist.
 *
 *   <prefix>anna <anything>   talk to her — AI powered, in character, knows
 *                              your name, the guild leader, every player on the
 *                              hall ledger, and remembers your conversations
 *                              (Vanguard-only; she dismisses everyone else)
 *   <prefix>anna forget       clear your conversation thread with her
 *   <prefix>anna              her desk card (who she is, hall leader, what the hall costs, how the gate works)
 *
 * She has one shared portrait (the lady in https://i.ibb.co/4n2p6RC7/Anna.jpg)
 * and she knows your name, the guild leader, and the other players because
 * liveFacts injects the live hall ledger before every reply.
 * That portrait is attached by replyWithPortrait() — the URL is never given to
 * the model and never survives sanitizeAnnaSpeech(), so she can't "send a
 * picture" by pasting a raw link into her caption.
 * Outside Vanguard she gives one sweet, absolute dismissal and spends no AI call.
 * Inside Vanguard she is heavy yandere + sadistic maniac, receptionist first.
 */

import { config } from '../config.js'
import { getPlayer, updatePlayer } from '../lib/player-repo.js'
import { ensureGuildsInitialized } from '../lib/guild-repo.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import { replyWithPortrait } from '../lib/portrait-reply.js'
import { askAI, hasAIKey } from '../lib/ai.js'
import {
  ANNA_IMAGE,
  ANNA_GUILD_ID,
  renderAnnaSystemPrompt,
  chatHistory,
  rememberTurn,
  forget,
  isVanguard,
  sanitizeAnnaSpeech,
  checkAnnaLedger,
  annaOfflineReply,
  getAnnaMemory,
} from '../lib/anna-persona.js'

const RULE = '━━━━━━━━━━━━━━━━━━━━'
const FORGET_WORDS = new Set(['forget', 'reset'])

const STRANGER_LINES = [
  `🔷 _Anna looks up from the ledger, smile still on, eyes not._ "That desk is for Vanguard, love. Yours is elsewhere — *${config.prefix}guild shop* will show you your own hall."`,
  `💙 "Oh. You're not mine." _She slides the ledger shut with one finger._ "The Vanguard hall doesn't take visits. Your own shop is waiting — try *${config.prefix}guild shop <your guild>*."`,
  `⛓️ _A soft laugh, a neat stack of papers._ "Vanguard only, darling. You don't wear our tag, so I don't have your name on my paper. Not yet."`,
]

function mentionedJids(ctx) {
  const info = ctx.msg?.message?.extendedTextMessage?.contextInfo
    ?? ctx.msg?.message?.imageMessage?.contextInfo
    ?? ctx.msg?.message?.buttonsResponseMessage?.contextInfo
  return [...(info?.mentionedJid ?? [])]
}

async function persistTurn(ctx, player, userText, aiText, meta = {}) {
  if (ctx.db?.data?.users) {
    try {
      await updatePlayer(ctx.db, ctx.from, (pl) => {
        rememberTurn(ctx.from, userText, aiText, pl, meta)
        return pl
      })
      return
    } catch {
      // Fall through to in-memory if player is not in db.data.users
    }
  }
  rememberTurn(ctx.from, userText, aiText, player, meta)
}

function deskCard(ctx, playerOverride = null) {
  const pr = ctx.prefix ?? config.prefix
  const player = playerOverride ?? ctx.player
  const vanguard = isVanguard(player)
  const name = player?.name ?? 'you'
  const ledger = checkAnnaLedger('', { player, db: ctx.db })
  const leaderLine = ledger.leader
    ? `👑 *Leader:* *${ledger.leader.name}* (Lv.${ledger.leader.level} · ${ledger.leader.floors}f) · 👥 *Members:* ${ledger.members.length}\n`
    : ''
  const rememberedTurns = chatHistory(ctx.from, player).filter(t => t.role === 'user').length
  const mem = getAnnaMemory(ctx.from, player)
  const memoryLine = vanguard && (rememberedTurns > 0 || mem.totalTalks > 0)
    ? `\n🗂️ _Her second ledger holds *${Math.max(rememberedTurns, mem.totalTalks)}* exchange(s) with you${mem.askedAbout?.length ? ` and *${mem.askedAbout.length}* name(s) you asked her to check` : ''}._`
    : ''

  return (
    `💙 *ANNA — VANGUARD RECEPTIONIST*  ⛓️\n` +
    `${RULE}\n` +
    `The lady behind the marble desk. She stamps papers, counts Solars, knows every name on the hall roll, and keeps a second ledger with your name in it until the paper tears.\n\n` +
    `🏰 *Hall:* Astral Vanguard — #1 by oath and by math. She makes sure it stays there.\n` +
    leaderLine +
    `💰 *Armory:* chest 1,000,000☀️ (520+ DEF) · star relic 1,500,000☀️ · every armor 500+ DEF peak · guild-bound, no gift, no trade.\n` +
    `🌟 *Effects:* EXTREME and universal — pvp, boss, dungeon, armor too. -45% ward, +42% fire, 30% dodge, thunder true — the hall keeps you everywhere.\n` +
    `⛓️ *Her gate:* *${pr}guild shop buy <item>* as Vanguard goes through her desk. She may **allow** it, or **reject** and spend the same Solars on what you need instead. She is right. She is always right.\n\n` +
    (vanguard
      ? `✅ _${name}, you wear Vanguard. Your seat is warm. Talk to her:_ *${pr}anna <message>*\n_She knows your name, your guild leader, and everyone on the roll._${memoryLine}`
      : `🔷 _You don't wear Vanguard._ She will not be yours until you are: *${pr}guild join astral vanguard* — then *${pr}anna hi*.\n_One line, sweet, absolute. The desk is closed to you._`) +
    `\n\n💬 _Vanguard only:_ *${pr}anna <message>* · 🛒 _Shop:_ *${pr}guild shop* · _Info:_ *${pr}guild shop info <name>*`
  )
}

async function replyWithAnna(ctx, text) {
  if (!ANNA_IMAGE) return ctx.reply(text)
  return replyWithPortrait(ctx, ANNA_IMAGE, text)
}

export default {
  name: 'anna',
  aliases: ['receptionist', 'vanguard-anna'],
  category: 'guild',
  requiresPlayer: true,
  description: `${config.prefix}anna <message>: talk to Anna (Vanguard only). No message shows her desk card`,

  async run(ctx) {
    if (ctx.db?.data) {
      try { await ensureGuildsInitialized(ctx.db) } catch {}
    }
    const fresh = (ctx.db?.data ? getPlayer(ctx.db, ctx.from) : null) ?? ctx.db?.data?.users?.[ctx.from] ?? ctx.player
    const text = ctx.args.join(' ').trim()
    if (!text) return replyWithAnna(ctx, deskCard(ctx, fresh))

    // Gate: Vanguard only. No AI call for strangers.
    if (!isVanguard(fresh) && !isOwnerJid(ctx.from)) {
      const line = STRANGER_LINES[(ctx.from?.length ?? 0) % STRANGER_LINES.length]
      return replyWithAnna(ctx, line)
    }

    if (FORGET_WORDS.has(text.toLowerCase())) {
      forget(ctx.from, fresh)
      if (ctx.db?.data?.users) {
        try {
          await updatePlayer(ctx.db, ctx.from, (pl) => {
            forget(ctx.from, pl)
            return pl
          })
        } catch {}
      }
      return replyWithAnna(
        ctx,
        `💙 _Anna tears a single page from her second ledger, folds it neatly into her drawer, and smiles up at you._\n\n"A fresh sheet for you, *${fresh?.name ?? 'love'}*. Tell me everything again — I'll write it down twice this time." ⛓️`,
      )
    }

    const quiet = `💙 _Anna neatens your papers without looking up._ "Give me a breath, ${fresh?.name ?? 'love'} — I was counting your Solars and lost track when you spoke."`
    const mentions = mentionedJids(ctx)
    const ledgerCheck = checkAnnaLedger(text, { player: fresh, db: ctx.db, mentionedJids: mentions })
    const fallback = annaOfflineReply(fresh, text, { db: ctx.db, mentionedJids: mentions }) || quiet

    if (!hasAIKey()) {
      await persistTurn(ctx, fresh, text, fallback, { db: ctx.db, mentionedJids: mentions, ledgerCheck })
      return replyWithAnna(ctx, fallback)
    }

    try {
      const history = chatHistory(ctx.from, fresh)
      const res = await askAI({
        system: renderAnnaSystemPrompt(fresh, { db: ctx.db, query: text, mentionedJids: mentions }),
        messages: [...history, { role: 'user', content: text }],
        temperature: 0.97,
        maxTokens: 500,
      })
      // Her portrait goes out as the image; her words go out as the caption.
      // A model that "sends" a picture of itself pastes the URL instead, and a
      // caption renders it literally — so nothing with a link in it leaves here.
      const answer = sanitizeAnnaSpeech(res.text) || fallback
      await persistTurn(ctx, fresh, text, answer, { db: ctx.db, mentionedJids: mentions, ledgerCheck })
      return replyWithAnna(ctx, answer)
    } catch {
      await persistTurn(ctx, fresh, text, fallback, { db: ctx.db, mentionedJids: mentions, ledgerCheck })
      return replyWithAnna(ctx, fallback)
    }
  },
}
