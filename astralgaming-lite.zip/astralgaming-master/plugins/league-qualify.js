import {finiteNumber} from '../lib/vitals.js'
/**
 * plugins/league-qualify.js — how a player earns a League seat.
 *
 * The owner's rule, as given: no level gate at all, you pay to enter, and you
 * face one character, Master Del Astra, who is not meant to be beaten. 100k a
 * try, no refund.
 *
 *   .qualify enter     pay 100k and open the trial (any level)
 *   .qualify fight     re open the trial if you walked away from it
 *   .qualify status    where your attempt stands
 *   .qualify rules     how the qualifier trial works from start to finish
 */
import { config } from '../config.js'
import { getPlayer, updatePlayer, updateWorldState } from '../lib/player-repo.js'
import { leagueOn, leagueGate } from '../lib/league/league-repo.js'
import { buildStandIn, resetStandInForFight, standinJid } from '../lib/league/league-standin.js'
import {
  isSealed,
  canEnterTrial,
  canAffordTrial,
  enterTrial,
  trialOf,
  trialStatusLine,
  qualifiersOpen,
  qualifierWindowCard,
  trialTag,
  loadMaster,
  scoreAttempt,
  recordTrial,
  sealedRows,
  MASTER_STANDIN_JID,
  TRIAL_ENTRY_COST_SOLARS,
  TRIAL_RETRY_COST_SOLARS,
  TRIAL_VERDICTS,
  findTrialFight,
} from '../lib/league/league-trial.js'
import { LEAGUE_PLAYER_SEATS, LEAGUE_ADVENTURER_SEATS } from '../lib/league/league-rules.js'
import { qualifierRulesCard } from '../lib/league/league-copy.js'
import { renderQualifierTrialCard } from '../lib/league-qualifier-render.mjs'
import { hpBar } from '../lib/combat-engine.js'
import { sendBattleTurnReply, ARENA_BACKGROUND_URL } from '../lib/battle-frame-render.mjs'
import { armLeagueCombatant } from '../lib/league/league-match.js'

async function replyTrialCard(ctx, caption, headerOpts = {}) {
  if (typeof ctx.replyImage === 'function') {
    try {
      const me = getPlayer(ctx.db, ctx.from)
      const league = ctx.db?.data?.league
      const trial = headerOpts.trial ?? trialOf(league, ctx.from)
      const png = await renderQualifierTrialCard(league, me, trial, headerOpts)
      if (png) return ctx.replyImage(png, caption)
    } catch {}
  }
  return ctx.reply(caption)
}

/**
 * Put the Master on the board for one challenger.
 */
async function ensureMasterStandIn(db, challengerJid, { myTurn, now, tag }) {
  const npc = loadMaster()
  if (!npc) return null
  const jid = standinJid(npc.id)
  await updateWorldState(db, 'league', (data) => {
    data.npcs = data.npcs ?? { schemaVersion: 1, adventurers: {}, arena: {} }
    data.npcs.arena = data.npcs.arena ?? {}
    const rec = buildStandIn(npc, null)
    resetStandInForFight(rec, challengerJid, { myTurn, now })
    rec.battleState.league = tag
    rec.battleState.cinematicBackground = ARENA_BACKGROUND_URL
    data.npcs.arena[jid] = rec
  })
  return jid
}

/** Open the trial for one challenger. */
async function openTrial(db, ctx) {
  const standInJid = await ensureMasterStandIn(db, ctx.from, {
    myTurn: false,
    now: Date.now(),
    tag: trialTag(ctx.from),
  })
  if (!standInJid) return null

  await updatePlayer(db, ctx.from, (p) => {
    p.inBattle = true
    p.hp = p.maxHp
    p.mp = p.maxMp
    p.battleState = {
      type: 'pvp',
      opponentJid: standInJid,
      myTurn: true,
      defending: false,
      turn: 1,
      startedAt: Date.now(),
      lastMoveAt: Date.now(),
      league: trialTag(ctx.from),
      cinematicBackground: ARENA_BACKGROUND_URL,
    }
    armLeagueCombatant(p)
  })
  return { standInJid }
}

export default {
  name: 'qualify',
  aliases: ['qualifier', 'qualifiers', 'trial'],
  category: 'league',
  requiresPlayer: true,
  description: `${config.prefix}qualify — face Master Del Astra for a League seat. Any level. ${TRIAL_ENTRY_COST_SOLARS.toLocaleString()} solars a try.`,
  subcommands: ['enter', 'fight', 'status', 'board', 'rules'],

  async run(ctx) {
    const { db, args } = ctx

    // The League master flag first, every time. Off means no League at all.
    const gate = leagueGate(db)
    if (!gate.open) return ctx.reply(gate.message)

    const sub = String(args?.[0] ?? '').toLowerCase().trim()

    // ── Qualifier rules work even when between seasons ──────────────────────
    if (sub === 'rules' || sub === 'rule' || sub === 'help' || sub === 'how' || sub === 'info' || sub === 'guide') {
      const trial = trialOf(db?.data?.league, ctx.from)
      const statusBlock = trial ? `\n\n${trialStatusLine(trial, config.prefix, { league: db.data.league, jid: ctx.from })}` : ''
      return replyTrialCard(ctx, `${qualifierRulesCard(config.prefix)}${statusBlock}`, {
        headerTitle: 'THE ASTRAL LEAGUE · QUALIFIER RULES',
      })
    }

    if (!leagueOn(db)) {
      return ctx.reply([
        '🛑🏟️ *The Astral League is not running.*',
        '━━━━━━━━━━━━━━━━━━━━',
        `📖 _Type *${config.prefix}qualify rules* to read how qualification works._`,
      ].join('\n'))
    }

    // Refuse before charging or opening/resuming a trial. Read-only status
    // and rules remain available throughout the season and its break.
    if ((sub === 'enter' || sub === 'fight') && !qualifiersOpen(db.data.league)) {
      return ctx.reply(qualifierWindowCard(db.data.league, ctx.from, config.prefix))
    }

    // ── Status, or the bare call ────────────────────────────────────────────
    if (!sub || sub === 'status') {
      const trial = trialOf(db.data.league, ctx.from)
      if (!qualifiersOpen(db.data.league)) {
        return replyTrialCard(ctx, trialStatusLine(trialOf(db.data.league, ctx.from), config.prefix, { league: db.data.league, jid: ctx.from }))
      }
      const sealed = sealedRows(db.data.league, LEAGUE_PLAYER_SEATS)
      const totalSealed = sealed.seated.length + sealed.waiting.length
      const openSpots = Math.max(0, LEAGUE_PLAYER_SEATS - sealed.seated.length)
      const boardNote = `\n\n🪑 *Challenger Seats (#14 to #20):* *${sealed.seated.length}/${LEAGUE_PLAYER_SEATS}* filled (*${openSpots}* open) · *${totalSealed}* total passed · *${sealed.waiting.length}* waitlisted\n📋 _Type *${config.prefix}qualify board* to see the full qualifier standings._`
      return replyTrialCard(ctx, `${trialStatusLine(trial, config.prefix, { league: db.data.league, jid: ctx.from })}${boardNote}`, { trial })
    }

    // ── Board / Waitlist standings ──────────────────────────────────────────
    if (sub === 'board' || sub === 'list' || sub === 'seats' || sub === 'waitlist') {
      if (!qualifiersOpen(db.data.league)) {
        return replyTrialCard(ctx, trialStatusLine(trialOf(db.data.league, ctx.from), config.prefix, { league: db.data.league, jid: ctx.from }))
      }
      const sealed = sealedRows(db.data.league, LEAGUE_PLAYER_SEATS)
      const totalSealed = sealed.seated.length + sealed.waiting.length
      const openSpots = Math.max(0, LEAGUE_PLAYER_SEATS - sealed.seated.length)
      const lines = [
        '🏅👑 *THE ASTRAL LEAGUE · QUALIFIER STANDINGS* 👑🏅',
        '━━━━━━━━━━━━━━━━━━━━',
        `✅ *Total Passed (Sealed):* *${totalSealed}*`,
        `🪑 *Challenger Seats (#14 to #20):* *${sealed.seated.length}/${LEAGUE_PLAYER_SEATS}* filled (*${openSpots}* open)`,
        `⏳ *Waitlist:* *${sealed.waiting.length}*`,
        '',
        `🪑 *TOP ${LEAGUE_PLAYER_SEATS} CHALLENGER SEATS (#14 TO #20)*`,
      ]
      if (!sealed.seated.length) {
        lines.push('   _No challenger has earned Master Del Astra\'s seal yet._')
      } else {
        sealed.seated.forEach((row, idx) => {
          const seatNo = LEAGUE_ADVENTURER_SEATS + idx + 1
          const name = row.name || getPlayer(db, row.jid)?.name || row.jid?.split('@')[0] || 'Challenger'
          const dmg = Number(row.best?.damage ?? 0).toLocaleString()
          const turns = Number(row.best?.turns ?? 0)
          lines.push(`   *#${seatNo}*  🎮 *${name}*  ·  💥 *${dmg} DMG*  ·  🔄 *${turns} turn${turns === 1 ? '' : 's'}*`)
        })
      }
      if (sealed.waiting.length) {
        lines.push('')
        lines.push('⏳ *WAITLIST*')
        sealed.waiting.forEach((row, idx) => {
          const name = row.name || getPlayer(db, row.jid)?.name || row.jid?.split('@')[0] || 'Challenger'
          const dmg = Number(row.best?.damage ?? 0).toLocaleString()
          const turns = Number(row.best?.turns ?? 0)
          lines.push(`   *W${idx + 1}*  🎮 *${name}*  ·  💥 *${dmg} DMG*  ·  🔄 *${turns} turn${turns === 1 ? '' : 's'}*`)
        })
      }
      return replyTrialCard(ctx, lines.join('\n'), {
        headerTitle: 'THE ASTRAL LEAGUE · QUALIFIER STANDINGS',
      })
    }

    // ── Enter: pay, then open the fight ─────────────────────────────────────
    if (sub === 'enter') {
      const me = getPlayer(db, ctx.from)
      const allowed = canEnterTrial(me)
      if (!allowed.ok) return ctx.reply(`🛑 *${allowed.problem}*`)
      const afford = canAffordTrial(me, trialOf(db.data.league, ctx.from))
      if (!afford.ok) return ctx.reply(`🛑 *${afford.problem}*`)
      if (isSealed(db.data.league, ctx.from)) {
        return ctx.reply([
          '🌟👑 *Master Del Astra already acknowledges you.*',
          '━━━━━━━━━━━━━━━━━━━━',
          '🪑 _You cannot buy another attempt. Your seal is already on the board!_',
        ].join('\n'))
      }
      if (me.inBattle) {
        return ctx.reply([
          '⚔️🔥 *Finish what you are in first.*',
          '━━━━━━━━━━━━━━━━━━━━',
          '_Your current fight has to end before the trial opens._',
        ].join('\n'))
      }

      const fee = afford.cost
      let short = false
      await updatePlayer(db, ctx.from, (p) => {
        const wallet = p.wallet ?? (p.wallet = {})
        const solars = Number(wallet.solars) || 0
        if (solars < fee) { short = true; return }
        wallet.solars = solars - fee
      })
      if (short) {
        return ctx.reply(`🛑☀️ *The trial costs ${fee.toLocaleString()} solars.*`)
      }

      let res = null
      await updateWorldState(db, 'league', (data) => {
        if (!data.league) { res = { ok: false, problem: 'The league is not ready.' }; return }
        res = enterTrial(data.league, ctx.from, me?.name ?? '', { now: Date.now() })
      })
      if (!res?.ok) {
        await updatePlayer(db, ctx.from, (p) => {
          const wallet = p.wallet ?? (p.wallet = {})
          wallet.solars = (Number(wallet.solars) || 0) + fee
        })
        return ctx.reply(`⚠️ *${res?.problem ?? 'That did not work.'}* _Your solars are back._`)
      }

      const opened = await openTrial(db, ctx)
      if (!opened) return ctx.reply(`❌ *The trial could not open.*\n\n_A mod will need to look._`)
      const meNow = getPlayer(db, ctx.from)
      const masterNow = getPlayer(db, opened.standInJid)
      const caption = [
        '⚔️🔥 *THE TRIAL OF MASTER DEL ASTRA* 🔥⚔️',
        '━━━━━━━━━━━━━━━━━━━━',
        `☀️ _You paid *${fee.toLocaleString()} solars*. There is no level to reach and no way to win. He will not fall._`,
        '💥 _What is measured is how much of him you take down or how many turns you stand before he takes you down._',
        '',
        '🩸 *BATTLE STATUS* 🩸',
        `❤️ *${meNow?.name ?? 'You'}*: ${hpBar(meNow?.hp ?? 0, meNow?.maxHp ?? 1)}  💧 ${meNow?.mp ?? 0}/${meNow?.maxMp ?? 0} MP`,
        `💙 *${masterNow?.name ?? 'Master Del Astra'}*: ${hpBar(masterNow?.hp ?? 0, masterNow?.maxHp ?? 1)}  💧 ${masterNow?.mp ?? 0}/${masterNow?.maxMp ?? 0} MP`,
        '',
        `🗡️ *${config.prefix}battle atk*  ·  *strike with your weapon*`,
        `🛡️ *${config.prefix}battle def*  ·  *brace and guard*`,
        `✨ *${config.prefix}battle sk <name>*  ·  *unleash a class or character skill*`,
        '',
        '🛡️ _Nobody loses gear or solars in the fight itself._',
      ].join('\n')
      return sendBattleTurnReply(ctx, {
        player: meNow,
        e: masterNow,
        msg: caption,
        hpBeforeTurn: meNow?.hp ?? 0,
        eHpBeforeTurn: masterNow?.hp ?? 0,
        isPvp: true,
        isLeague: true,
        lastAction: null,
      })
    }

    // ── Fight: re open an attempt that is already paid for ──────────────────
    if (sub === 'fight' || sub === 'play') {
      const me = getPlayer(db, ctx.from)
      if (me?.inBattle) {
        return ctx.reply([
          '⚔️🔥 *Finish what you are in first.*',
          '━━━━━━━━━━━━━━━━━━━━',
          '_Your current fight has to end before a new one opens._',
        ].join('\n'))
      }
      const trial = trialOf(db.data.league, ctx.from)
      if (!trial) {
        return ctx.reply([
          '⚔️🚪 *No trial on the board.*',
          '━━━━━━━━━━━━━━━━━━━━',
          `🎟️ _Enter with *${config.prefix}qualify enter* or read the guide with *${config.prefix}qualify rules*._`,
        ].join('\n'))
      }
      if (trial.status !== 'active') return replyTrialCard(ctx, trialStatusLine(trial, config.prefix, { league: db.data.league, jid: ctx.from }), { trial })

      const opened = await openTrial(db, ctx)
      if (!opened) return ctx.reply(`❌ *The trial could not open.*\n\n_A mod will need to look._`)
      const meNow = getPlayer(db, ctx.from)
      const masterNow = getPlayer(db, opened.standInJid)
      const caption = [
        '⚔️🔥 *THE TRIAL CONTINUES* 🔥⚔️',
        '━━━━━━━━━━━━━━━━━━━━',
        '👹 *Master Del Astra stands before you at full strength.*',
        '',
        '🩸 *BATTLE STATUS* 🩸',
        `❤️ *${meNow?.name ?? 'You'}*: ${hpBar(meNow?.hp ?? 0, meNow?.maxHp ?? 1)}  💧 ${meNow?.mp ?? 0}/${meNow?.maxMp ?? 0} MP`,
        `💙 *${masterNow?.name ?? 'Master Del Astra'}*: ${hpBar(masterNow?.hp ?? 0, masterNow?.maxHp ?? 1)}  💧 ${masterNow?.mp ?? 0}/${masterNow?.maxMp ?? 0} MP`,
        '',
        `🗡️ *${config.prefix}battle atk*  ·  *strike*`,
        `🛡️ *${config.prefix}battle def*  ·  *guard*`,
        `✨ *${config.prefix}battle sk <name>*  ·  *skill*`,
      ].join('\n')
      return sendBattleTurnReply(ctx, {
        player: meNow,
        e: masterNow,
        msg: caption,
        hpBeforeTurn: meNow?.hp ?? 0,
        eHpBeforeTurn: masterNow?.hp ?? 0,
        isPvp: true,
        isLeague: true,
        lastAction: null,
      })
    }

    return ctx.reply([
      '❓⚔️ *Not a trial command.*',
      '━━━━━━━━━━━━━━━━━━━━',
      `⚔️ *${config.prefix}qualify enter*  ·  *pay ${TRIAL_ENTRY_COST_SOLARS.toLocaleString()} solars (${TRIAL_RETRY_COST_SOLARS.toLocaleString()} retry) and face him*`,
      `🗡️ *${config.prefix}qualify fight*  ·  *re open an attempt already paid for*`,
      `📊 *${config.prefix}qualify status*  ·  *check where you stand*`,
      `📖 *${config.prefix}qualify rules*  ·  *read how the 7 player seats are won*`,
    ].join('\n'))
  },
}

/** The duel end hook reads the same finder the plugin opened the fight with. */
export { findTrialFight }

/**
 * Settle a trial at the end of its duel.
 */
export async function concludeTrialFight(db, winnerJid, loserJid, ctx, reasonLine = '') {
  const found = findTrialFight(db, winnerJid, loserJid)
  if (!found) return false
  const { jid } = found

  const master = getPlayer(db, MASTER_STANDIN_JID)
  const challenger = getPlayer(db, jid)
  const attempt = scoreAttempt(master, challenger)

  let settled = null
  await updateWorldState(db, 'league', (data) => {
    settled = recordTrial(data.league, jid, attempt, Date.now())
  })

  await updatePlayer(db, jid, (p) => {
    p.inBattle = false
    p.battleState = null
  })
  if (master) {
    await updatePlayer(db, MASTER_STANDIN_JID, (p) => { p.inBattle = false; p.battleState = null })
  }

  if (!settled?.ok) {
    await ctx?.reply?.(`⚠️ *${settled?.problem ?? 'That trial could not be settled.'}*`)
    return true
  }

  const verdict = settled.verdict
  const head = verdict === 'sealed'
    ? '🌟👑 *MASTER DEL ASTRA ACKNOWLEDGES YOU.* 👑🌟'
    : verdict === 'marked'
      ? '🥀⚔️ *MASTER DEL ASTRA NOTICES YOU.* ⚔️🥀'
      : '🪦💀 *MASTER DEL ASTRA DOES NOT NOTICE YOU.* 💀🪦'
  const tail = verdict === 'sealed'
    ? (qualifiersOpen(db.data.league)
      ? '🪑 _Your seat is drawn when a season opens. Check *.qualify status* anytime._'
      : qualifierWindowCard(db.data.league, jid, config.prefix))
    : `🔁 _Enter again at half price (*${TRIAL_RETRY_COST_SOLARS.toLocaleString()} solars*) with *${config.prefix}qualify enter*. Read the full guide with *${config.prefix}qualify rules*._`

  const caption = [
    ...(reasonLine ? [String(reasonLine).trim(), ''] : []),
    head,
    '━━━━━━━━━━━━━━━━━━━━',
    `💥 *Damage Dealt:* You dealt *${attempt.dealt.toLocaleString()}* damage.`,
    `⏳ *Endurance:* You stood for *${attempt.turns}* turns.`,
    `🩸 *Master HP:* He is still standing at *${Math.max(0, finiteNumber(master?.hp)).toLocaleString()}* of *${finiteNumber(master?.maxHp).toLocaleString()}*.`,
    '',
    tail,
  ].join('\n')

  if (typeof ctx?.replyImage === 'function') {
    try {
      const png = await renderQualifierTrialCard(db.data.league, challenger, settled.trial, {
        headerTitle: 'THE TRIAL OF MASTER DEL ASTRA · VERDICT',
        attempt,
      })
      if (png) {
        await ctx.replyImage(png, caption)
        return true
      }
    } catch {}
  }
  await ctx?.reply?.(caption)
  return true
}

/** Re exported so a caller can name the verdicts without importing the rules. */
export { TRIAL_VERDICTS }
