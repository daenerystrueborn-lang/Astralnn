/**
 * blaze-heart.js — Rengoku's finishing move.
 *
 * "Set your heart ablaze." Once per battle, no MP, and only from the owner's
 * 3rd move of the fight (BLAZE_HEART_FROM_TURN). All three walls are enforced
 * by activateBlazeHeart() in lib/rengoku.js, which is a gate only: it burns the
 * charge and hands back the multiplier, and this file runs it through the
 * stock damage pipeline.
 *
 * The turn is the same shape as plugins/cinderverdict.js with two deliberate
 * differences:
 *
 *   1. IT IS STRONGER THAN CINDER VERDICT. BLAZE_HEART_MULT sits above Wither's
 *      8x by design (the brief). DEF still applies through applyDefense(), so
 *      this is a very heavy hit and not a scripted kill.
 *   2. IT DOES NOT ROLL ACCURACY. By the time the damage is rolled the charge
 *      is already burned and the owner has already waited two moves for it; a
 *      whiff there reads as the command being broken. Crit still rolls.
 *
 * ART: this is the one place in PvE that sends BLAZE_HEART_IMAGE, and only on
 * the turn the move actually fires, as its own splash ahead of the battle
 * screen. Every refusal (too early, already used, wrong character) is plain
 * text, on purpose: art on a "no" reads as if the move went off.
 *
 * ROUTES, in the order they are tried:
 *   League fixture   playLeagueMove() -> runPvpTurn('blazeheart')
 *   Duel             pvp.js's pvpBlazeHeart() ('blazeheart' action there)
 *   Party fight      party.js's battleBlazeHeart() (members carry no battleState)
 *   Swarm floor      folded into ONE swarm turn against the nearest threat
 *   1v1 dungeon/boss the turn below
 *
 * Flame Breathing (his combo) never follows Blaze Heart itself: the finisher
 * is the end of the string, not another link in it. The gate holds the chain
 * open across this turn, so firing it does not cost the combo either.
 *
 * Usage: <prefix>blaze-heart
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import {
  calcPlayerDamage, applyDefense,
  calcMonsterHitChance, calcMonsterDamage, hpBar,
} from '../lib/combat-engine.js'
import {
  handleVictory,
  processStatusTurn,
  resolvePlayerHpZero,
  checkCatFormOngoingTurn,
  resolveCatFormDefeat,
} from '../lib/combat-handlers.js'
import { getEffectiveStat, hasEffect } from '../lib/effects.js'
import {
  applyBossSpecial, checkBossPhase, buildEnemyAttack,
  getBossTaunt, getBossHitLine,
  incrementBossTurn, cleanupBossFight, EVENT,
} from '../lib/boss-engine.js'
import {
  applyTearOnHit,
  sendWillowAdvisory,
  tickPermanentSever,
  applyIncomingDamage,
} from '../lib/character-abilities.js'
import {
  hasRengoku, activateBlazeHeart, refundBlazeHeart, blazeHeartOpening, sendBlazeHeartImage,
  BLAZE_HEART_NAME, BLAZE_HEART_FROM_TURN,
} from '../lib/rengoku.js'
import { pvpBlazeHeart } from './pvp.js'
import { battleBlazeHeart, findPartyForPlayer } from './party.js'
import { playLeagueMove } from './league-battle.js'
import { resolveSwarmAbility } from '../lib/swarm-combat.js'
import { sendBattleTurnReply } from '../lib/battle-frame-render.mjs'
import { heroesAnswerHit, heroesTurnBoundary } from '../lib/witch-heroes-pve.js'
import { graceHoldsEnemyTurn, graceEnemyHeldLine } from '../lib/king-yato.js'

function isBossFight(player) {
  return !!(player.battleState?.enemy?.isBoss && player.battleState?.bossState)
}

const SPLASH_CAPTION = `🔥❤️‍🔥 *${BLAZE_HEART_NAME.toUpperCase()}*`

/** Stunned, frozen or asleep: the three states that cost a player their turn. */
function isHeld(player) {
  return hasEffect(player, 'stun') || hasEffect(player, 'freeze') || hasEffect(player, 'sleep')
}

export default {
  name: 'blaze-heart',
  aliases: ['blazeheart', 'blaze', 'bh', 'flameheart', 'ninthform'],
  category: 'combat',
  requiresPlayer: true,
  description: `${config.prefix}blaze-heart: Rengoku's finishing move (once per battle, no MP, from your move ${BLAZE_HEART_FROM_TURN})`,

  async run(ctx) {
    const p = config.prefix

    // ── Astral League fixture ─────────────────────────────────────────
    // A fixture plays this through the League path: the same runPvpTurn()
    // action as the duel handoff below, plus the turn limit, the stand in
    // answer and the table. BEFORE the duel handoff and before updatePlayer():
    // playLeagueMove() sends and writes, and neither is safe inside a mutator.
    if (await playLeagueMove(ctx, 'blazeheart', '')) return

    // Duels run their own two-player engine (no bs.enemy).
    if (ctx.player?.battleState?.type === 'pvp') {
      return pvpBlazeHeart(ctx)
    }

    // A party fight: members carry no battleState of their own, so the move is
    // gated and resolved on the party's per-member state.
    if (ctx.player?.inBattle && !ctx.player.battleState && findPartyForPlayer(ctx.db, ctx.from)?.battle) {
      return battleBlazeHeart(ctx)
    }

    await updatePlayer(ctx.db, ctx.from, async player => {
      const catTurn = await checkCatFormOngoingTurn(player, ctx, {
        boss: isBossFight(player),
      })
      if (catTurn.intercepted) return catTurn.returnValue

      // A held owner cannot throw it, and trying must not cost the charge. This
      // is asked BEFORE the gate (which burns it) and refused outright, so the
      // finisher is still there on the turn they can move again. The turn itself
      // is not spent either: the stun is paid with whatever they type next.
      if (hasRengoku(player) && player.inBattle && player.battleState && isHeld(player)) {
        await ctx.reply(
          `💫 *${BLAZE_HEART_NAME}* needs a body that can move.\n` +
          `_You are held this turn. Nothing was spent. Take the turn with *${p}attack* or *${p}defend*._`,
        )
        return player
      }

      // The gate. Wrong character, not in a fight, already used, or too early:
      // each is a plain-text refusal that spends neither the charge nor the turn.
      const gate = activateBlazeHeart(player)
      if (!gate.ok) {
        if (gate.message) await ctx.reply(gate.message)
        return player
      }

      // Swarm floors: fold the move into ONE swarm turn against the nearest
      // threat (the same shape kamehameha.js / kurama.js use). Without this
      // branch the 1v1 turn below ran against bs.enemy and a kill called
      // handleVictory while other monsters were still alive, wiping the pack for
      // free. The charge was already burned by the gate, so it is paid once
      // either way.
      if (player.battleState?.mode === 'swarm') {
        let thrown = false
        const swarmBs = player.battleState
        const settled = await resolveSwarmAbility(player, ctx, (target) => {
          thrown = true
          // The art goes out HERE, from inside the blow, and nowhere earlier:
          // the swarm engine only calls this once the owner really is acting on
          // a live target, so a turn it skips (nothing left to reach, a hold the
          // check above could not see) sends no art. apply() is synchronous, so
          // the send is started and not awaited, the same way the engine sends
          // its other in-turn art; it is on the wire before the frame is drawn.
          void sendBlazeHeartImage(ctx, SPLASH_CAPTION, ctx.sender)
          // Stock pipeline, same as the 1v1 turn: no accuracy roll, DEF applies.
          const { rawDmg, isCrit } = calcPlayerDamage(player, null, gate.multiplier)
          let dmg = applyDefense(rawDmg, getEffectiveStat(target, 'def'), player, target)
          target.hp = Math.max(0, target.hp - dmg)
          return {
            lines: [
              blazeHeartOpening(target.name),
              ``,
              `🩸 *${dmg.toLocaleString('en-US')}* damage!${isCrit ? ' 💥 *CRITICAL!*' : ''}`,
            ],
            damage: dmg,
            // Named so nothing follows it: his own combo (and Texas's cut, for
            // symmetry) only ever follow an 'owner' hit.
            source: 'blaze_heart',
          }
        })
        // Backstop: the swarm engine skips the owner's action when they turn
        // out to be unable to act. A finisher that was never thrown is handed
        // back, on the same record the gate burned it on (and, per the note in
        // apply() above, it showed no art).
        if (!thrown) refundBlazeHeart(swarmBs)
        return settled
      }

      const bs   = player.battleState
      const e    = bs.enemy
      const boss = isBossFight(player)
      const hpBeforeTurn  = player.hp
      const eHpBeforeTurn = e.hp

      bs.playerDefending = false
      let msg = ''

      // Urahara's permanent Tear: action-triggered tick, same as every other
      // combat entry point.
      const permaSeverLine = tickPermanentSever(player)
      if (permaSeverLine) msg += permaSeverLine + '\n'
      if (player.hp <= 0) {
        const res = await resolvePlayerHpZero(player, ctx, msg, {})
        if (!res.fallThrough) return res.returnValue
        msg = res.msg
      }

      if (boss) {
        incrementBossTurn(player)
        const tsResult = applyBossSpecial(player, EVENT.TURN_START, {})
        if (tsResult.narrativeLine) msg += `_${tsResult.narrativeLine}_\n`
      }

      const playerStatus = processStatusTurn(player)
      if (playerStatus.incapacitated && player.battleState?.enemy?.tower) player.battleState.towerTacticIncapacitatedTurn = player.battleState.turn ?? 1
      if (!playerStatus.incapacitated && player.hp > 0 && player.battleState?.bossState?._def?.orv) applyBossSpecial(player, EVENT.PLAYER_ABILITY, {})
      if (playerStatus.lines.length) msg += playerStatus.lines.join('\n') + '\n'
      if (player.hp <= 0) {
        const res = await resolvePlayerHpZero(player, ctx, msg, { boss })
        if (!res.fallThrough) return res.returnValue
        msg = res.msg
      }

      let fired = false
      if (playerStatus.incapacitated) {
        // Backstop for a hold the check above could not see. The move never
        // left the sheath, so the charge goes back.
        refundBlazeHeart(bs)
        msg += `💫 *${player.name}* is unable to act this turn! _${BLAZE_HEART_NAME} stays unspent._\n`
      } else {
        msg += blazeHeartOpening(e.name) + '\n\n'
        // Stock damage pipeline: the multiplier goes in as damageMultiplier and
        // applyDefense() still mitigates the result. No accuracy roll.
        const { rawDmg, isCrit } = calcPlayerDamage(player, null, gate.multiplier)
        let dmg = applyDefense(rawDmg, getEffectiveStat(e, 'def'), player, e)
        if (boss) {
          const takeResult = applyBossSpecial(player, EVENT.ENEMY_TAKE_DAMAGE, {
            damage: dmg, element: 'fire', isCrit, isHit: true,
          })
          if (takeResult.damage !== undefined) dmg = takeResult.damage
          if (takeResult.reflectDamage) {
            const reflected = applyIncomingDamage(player, takeResult.reflectDamage)
            if (reflected.message) msg += reflected.message + '\n'
            if (reflected.catFormDefeated) return resolveCatFormDefeat(player, ctx, { boss })
            if (player.hp <= 0) {
              const resolved = await resolvePlayerHpZero(player, ctx, msg, { boss: true })
              if (!resolved.fallThrough) return resolved.returnValue
              msg = resolved.msg
            }
          }
          if (takeResult.narrativeLine) msg += `_${takeResult.narrativeLine}_\n`
          msg += `💬 _"${getBossHitLine(player)}"_\n`
        }
        e.hp = Math.max(0, e.hp - dmg)
        fired = true

        msg += `🩸 *${dmg.toLocaleString('en-US')}* damage!${isCrit ? ' 💥 *CRITICAL!*' : ''}\n`

        if (e.hp > 0) {
          const tearLine = applyTearOnHit(player, e, ctx)
          if (tearLine) msg += tearLine + '\n'
        }



        if (e.hp <= 0) {
          // The kill is the finisher's: show the art and the blow before the
          // victory screen takes over, or the move that ended the fight is the
          // one turn nobody saw.
          await sendBlazeHeartImage(ctx, SPLASH_CAPTION, ctx.sender)
          try { await ctx.reply(msg.trimEnd()) } catch { /* the kill still settles */ }
          if (boss) cleanupBossFight(player)
          return handleVictory(player, e, ctx)
        }

        if (boss) {
          const phase = checkBossPhase(player)
          if (phase?.triggered && phase.lines?.length) {
            msg += `\n⚡ *— PHASE SHIFT —*\n` + phase.lines.map(l => `_${l}_`).join('\n') + '\n'
          }
        }
      }

      const enemyStatus = processStatusTurn(e, { bossState: player.battleState?.bossState })
      if (enemyStatus.lines.length) msg += enemyStatus.lines.join('\n') + '\n'
      if (e.hp <= 0) {
        if (boss) cleanupBossFight(player)
        return handleVictory(player, e, ctx)
      }

      // 👑 King Yato's grace hold is asked here like every other PvE turn; it is
      // a no-op for a Rengoku owner (one equipped character at a time) and kept
      // so this turn stays line-for-line comparable with the others.
      if (graceHoldsEnemyTurn(player)) {
        msg += `\n${graceEnemyHeldLine(e, player)}\n`
      } else if (enemyStatus.incapacitated) {
        msg += `💫 *${e.name}* is unable to attack this turn!\n`
      } else if (boss) {
        const bossAtk    = buildEnemyAttack(player)
        const dealResult = applyBossSpecial(player, EVENT.ENEMY_DEAL_DAMAGE, { damage: bossAtk.damage, isHit: true })
        const rawBossAtk = (dealResult.modified && dealResult.damage !== undefined) ? dealResult.damage : bossAtk.damage
        const incoming   = bossAtk.bypassDefense
          ? rawBossAtk
          : calcMonsterDamage(rawBossAtk, getEffectiveStat(player, 'def'), false)
        const witchHit = heroesAnswerHit({ player, enemy: e, ctx, msg: '', damage: incoming, directAttack: true, boss })
        if (witchHit.returnValue !== undefined) return witchHit.returnValue
        if (witchHit.lines.length) msg += witchHit.lines.map(l => l + '\n').join('')
        const applied = applyIncomingDamage(player, witchHit.damage)
        if (applied.message) msg += applied.message + '\n'
        msg += `\n${e.emoji ?? '👾'} *${e.name}* uses *${bossAtk.attackName}*!\n`
        if (!witchHit.turned) msg += `🩸 *${applied.damage}* damage!${bossAtk.bypassDefense ? ' _(bypasses DEF)_' : ''}\n`
        if (dealResult.narrativeLine) msg += `_${dealResult.narrativeLine}_\n`
        msg += `\n💬 _"${getBossTaunt(player)}"_\n`
        if (applied.catFormDefeated) {
          return resolveCatFormDefeat(player, ctx, { boss: true })
        }
        if (player.hp <= 0) {
          const res = await resolvePlayerHpZero(player, ctx, msg, { boss: true })
          if (!res.fallThrough) return res.returnValue
          msg = res.msg
        }
      } else if (Math.random() > calcMonsterHitChance(e, player)) {
        msg += `\n${e.emoji ?? '👾'} *${e.name}* retaliates... and *MISSES!*`
      } else {
        const enemyDmg = calcMonsterDamage(e.atk, getEffectiveStat(player, 'def'), false)
        const witchHit = heroesAnswerHit({ player, enemy: e, ctx, msg: '', damage: enemyDmg, directAttack: true, boss })
        if (witchHit.returnValue !== undefined) return witchHit.returnValue
        if (witchHit.lines.length) msg += witchHit.lines.map(l => l + '\n').join('')
        const applied = applyIncomingDamage(player, witchHit.damage)
        if (applied.message) msg += applied.message + '\n'
        if (!witchHit.turned) msg += `\n${e.emoji ?? '👾'} *${e.name}* retaliates!\n🩸 *${applied.damage}* damage!`
        if (applied.catFormDefeated) {
          return resolveCatFormDefeat(player, ctx)
        }
        if (player.hp <= 0) {
          const res = await resolvePlayerHpZero(player, ctx, msg, {})
          if (!res.fallThrough) return res.returnValue
          msg = res.msg
        }
      }

      if (boss) {
        const teResult = applyBossSpecial(player, EVENT.TURN_END, {})
        if (teResult.narrativeLine) msg += `\n_${teResult.narrativeLine}_`
      }

      msg += `\n\n👤 *${player.name}*\n❤️ ${hpBar(player.hp, player.maxHp)}  💧 ${player.mp}/${player.maxMp} MP\n` +
             `${e.emoji ?? '👾'} *${e.name}*\n❤️ ${hpBar(e.hp, e.maxHp)}\n\n` +
             `*${p}attack* · *${p}skill <name>* · *${p}defend* · *${p}flee*`

      // The shared completed-turn clock (lib/witch-heroes-pve.js). A turn that
      // skips this is a turn the rest of the roster's kits never saw.
      const witchTurn = await heroesTurnBoundary({ player, enemy: e, ctx, msg, turnId: bs.turn ?? 1, boss })
      if (witchTurn.returnValue !== undefined) return await witchTurn.returnValue
      msg = witchTurn.msg
      bs.turn = (bs.turn ?? 1) + 1
      player.battleState = bs
      await sendWillowAdvisory(ctx, player, e, boss)

      // The finishing-move art on its own splash, then the turn on the battle
      // screen every dungeon and boss fight renders in. Sending the art INSTEAD
      // of the frame would make this the one turn in the fight with no HP bars.
      // No art on a turn the owner was too stunned to swing in.
      if (fired) await sendBlazeHeartImage(ctx, SPLASH_CAPTION, ctx.sender)
      const dealt = Math.max(0, Math.round(eHpBeforeTurn - e.hp))
      await sendBattleTurnReply(ctx, {
        bs, player, e, msg, hpBeforeTurn, eHpBeforeTurn, boss, isDungeon: true,
        lastAction: fired
          ? { actor: 'left', kind: 'skill', damage: dealt, skillName: BLAZE_HEART_NAME }
          : null,
      })
      return player
    })
  },
}
