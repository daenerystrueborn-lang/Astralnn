/**
 * you.js — .you [@player | reply | name | phone]
 * Shows a player's full details: rank, level, gems, solars, vault, bank,
 * monds, stats, characters, pets, beasts, equipped gear, abilities, and record.
 */
import { config } from '../config.js'
import { fmtGems, formatTitle } from '../lib/format.js'
import { fmtMonds } from '../lib/monds.js'
import { rarityStars } from '../lib/rarity.js'
import {
  classes,
  races,
  levelsData,
  locationsMap,
  allItems,
  abilities as abilityDefs,
  premiumAbilityMap,
  characterMap,
  petMap,
  beastMap,
} from '../lib/game-data.js'
import { hpBar } from '../lib/combat-engine.js'
import { getRankForLevel } from '../lib/rank-engine.js'
import { isAsleep } from '../lib/sleep-engine.js'
import { hungerBar } from '../lib/hunger-engine.js'
import { formatTimeLeft } from '../lib/time-format.js'
import { getInventoryCap } from '../lib/inventory-limits.js'
import { enchantBadge } from '../lib/enchantments.js'
import { getBeastStats } from '../lib/beast-engine.js'
import { extractTarget, isOwnerJid } from '../lib/group-helpers.js'
import { getPlayer } from '../lib/player-repo.js'
import { isPremiumActive } from '../lib/premium.js'
import { getWaifu, tierStars } from '../lib/card-engine.js'
import { ensureStatPoints, statPointCap } from '../lib/stat-progression.js'
import { isReborn, playerLevelCap } from '../lib/reborn-engine.js'
import { isTitled, ensurePrestige, getTierForXp } from '../lib/title-engine.js'
import { endStatusBadge } from '../lib/end-event.js'
import { getGuildTag } from '../lib/guild-repo.js'
import { achievementSummary } from '../lib/achievement-engine.js'
import { renderProfileCard } from '../lib/profile-card-render.mjs'
import { findPlayerIdByQuery } from './admin.js'
import { hidesLevel, levelTag, titleTier } from '../lib/level-display.js'
import { getActiveSeason } from '../lib/season-engine.js'

function slotEmoji(slot) {
  return { weapon: '⚔️', offhand: '🛡️', helmet: '🪖', chestplate: '🧥', boots: '👢', accessory: '💍', relic: '💍' }[slot] ?? '•'
}

function padSlot(slot) {
  const labels = {
    weapon: 'Weapon    ',
    offhand: 'Offhand   ',
    helmet: 'Helmet    ',
    chestplate: 'Chestplate',
    boots: 'Boots     ',
    relic: 'Relic     ',
  }
  return labels[slot] ?? slot
}

export default {
  name: 'you',
  aliases: ['whois', 'checkplayer'],
  category: 'admin',
  requiresPlayer: false,
  description: 'Owner-only: reply to or mention a player to view all their details, wallet, bank, rank, stats, and loadout',

  async run(ctx) {
    if (!ctx.from || !isOwnerJid(ctx.from)) {
      return ctx.reply('❌ This command is restricted to the bot owner.')
    }

    const { db, reply, args } = ctx
    const pr = config.prefix
    const activeSeason = getActiveSeason(db)
    const seasonCurrency = activeSeason?.currencyLabel ?? (activeSeason?.id === 'season_02' ? 'Stars' : 'Season Points')

    let targetId = extractTarget(ctx)
    const query = (args ?? []).filter(a => a && !a.startsWith('@')).join(' ').trim()
    if (!targetId && query) {
      targetId = findPlayerIdByQuery(db, query)
      if (!targetId) {
        return reply(`❌ Could not find player *"${query}"*.`)
      }
    }

    if (!targetId) {
      return reply(`❌ Reply to someone's message or mention them: *${pr}you @user*`)
    }

    const p = getPlayer(db, targetId)
    if (!p) {
      return reply(`❌ That user isn't registered as a player yet.`)
    }

    let statPoints = { unallocated: p.statPoints?.unallocated ?? 0, earned: p.statPoints?.earned ?? 0 }
    try {
      statPoints = ensureStatPoints(p)
    } catch {
      // Partial/legacy player records without classId/raceId still render cleanly.
    }
    const className = classes[p.classId]?.name ?? p.classId ?? 'Adventurer'
    const raceName = races[p.raceId]?.name ?? p.raceId ?? 'Human'

    const nextLevel = (p.level ?? 1) + 1
    const nextLevelXp = levelsData.xpTable[String(nextLevel)]
    const xpToNext = nextLevelXp != null ? nextLevelXp - (p.xp ?? 0) : null
    const xpNeeded = nextLevelXp == null
      ? 'MAX'
      : xpToNext > 0 ? `${xpToNext} to next` : 'level up ready'

    const rank = getRankForLevel(p.level ?? 1)
    const cap = playerLevelCap(p)
    const titled = isTitled(p, cap)
    const prestigeTier = titled ? getTierForXp(ensurePrestige(p).xp) : null
    const prestigeBadge = prestigeTier ? `  ${prestigeTier.glyph} *${prestigeTier.name}*` : ''

    // Wallet & Net Worth
    const w = p.wallet ?? {}
    const solars = Number(w.solars) || 0
    const vault = Number(w.vault) || 0
    const bankGold = Number(w.bankGold) || 0
    let empireBank = 0
    for (const emp of Object.values(db?.data?.empires ?? {})) {
      empireBank += Math.max(0, Math.floor(Number(emp?.bank?.accounts?.[targetId]?.balance) || 0))
    }
    const netWorth = solars + vault + bankGold + empireBank
    const gems = Number(w.gems) || 0
    const monds = Number(w.monds) || 0

    // Equipment
    const eq = p.equipped ?? {}
    const slots = ['weapon', 'offhand', 'helmet', 'chestplate', 'boots', ...(eq.accessory ? ['accessory'] : [])]
    const eqLines = slots.map(slot => {
      const id = slot === 'offhand' ? (eq.offhand ?? eq.relic) : eq[slot]
      const item = id ? allItems.find(i => i.id === id) : null
      const name = item ? item.name : '— empty —'
      const rar = item ? ` ${rarityStars(item.rarity)}` : ''
      const ench = item ? enchantBadge(p, item.id) : ''
      return `  ${slotEmoji(slot)} ${padSlot(slot)} ${name}${rar}${ench ? `  ${ench}` : ''}`
    }).join('\n')

    // Abilities
    const abilitySlots = p.abilitySlots ?? 1
    const equippedAbilities = p.equippedAbilities ?? []
    const abilityLines = Array.from({ length: abilitySlots }, (_, i) => {
      const id = equippedAbilities[i]
      const ab = id ? abilityDefs.find(a => a.id === id) : null
      if (!ab) return `  ☆☆☆☆☆ — empty slot —`
      const rar = rarityStars(ab.rarity)
      const cd = ab.type === 'active' ? `, ${ab.cooldownTurns}-turn CD` : ''
      return `  ${rar} *${ab.name}* [${ab.rarity}, ${ab.type}${cd}]`
    }).join('\n')
    const premiumAbilityDef = p.premiumAbility ? premiumAbilityMap[p.premiumAbility] : null
    const premiumAbilityLine = premiumAbilityDef
      ? `\n  👑 *${premiumAbilityDef.name}* _[premium one-of-one]_`
      : ''

    // Characters
    const ownedCharIds = [...new Set([
      ...(p.ownedCharacters ?? []),
      ...(p.seasonOwned?.characters ?? []),
    ])]
    const activeCharId = p.equipped?.character ?? p.activeCharacter ?? null
    const activeCharName = activeCharId ? (characterMap[activeCharId]?.name ?? activeCharId) : 'none'
    const ownedCharNames = ownedCharIds.length > 0
      ? ownedCharIds.map(id => characterMap[id]?.name ?? id).join(', ')
      : 'none'

    // Pets
    const ownedPetIds = [...new Set(p.pets ?? [])]
    const activePetId = p.equipped?.pet ?? null
    const activePetName = activePetId ? (petMap[activePetId]?.name ?? activePetId) : 'none'
    const ownedPetNames = ownedPetIds.length > 0
      ? ownedPetIds.map(id => petMap[id]?.name ?? id).join(', ')
      : 'none'

    // Active Beast
    const activeBeastEntry = p.activeBeast
      ? (p.summonedBeasts ?? []).find((b) => b.beastId === p.activeBeast)
      : null
    const activeBeastDef = activeBeastEntry ? beastMap[activeBeastEntry.beastId] : null
    const beastLine = activeBeastDef
      ? `${activeBeastDef.emoji} *${activeBeastDef.name}* _(Lv.${getBeastStats(activeBeastDef, activeBeastEntry.cp).level})_`
      : 'none'

    // Waifu & Achievements
    const waifuCard = getWaifu(p)
    const waifuLine = waifuCard
      ? `${tierStars(waifuCard.tier)} *${waifuCard.title}* _(${waifuCard.series})_`
      : 'none set'
    const ach = achievementSummary(p)

    // Battle Record
    const wins = p.battleRecord?.wins ?? 0
    const losses = p.battleRecord?.losses ?? 0
    const totalBattles = wins + losses
    const winRatio = totalBattles > 0 ? `${(wins / totalBattles * 100).toFixed(0)}%` : '0%'

    // Stamina & Location
    const st = p.stamina ?? { current: 30, max: 30 }
    let locationLine = `📍 *Location:* ${locationsMap[p.location]?.name ?? p.location ?? 'Astral Town'}`
    if (p.inDungeon && p.dungeonFloor) {
      locationLine += ` — Floor *${p.dungeonFloor}*`
    }
    if (p.inBattle && (p.battleState?.enemy || p.battleState?.type === 'pvp')) {
      locationLine += p.battleState?.type === 'pvp' ? `  🥊 _(in a duel)_` : `  ⚔️ _(in battle)_`
    }
    if (isAsleep(p)) {
      locationLine += `  😴 _(wakes up in ${formatTimeLeft(p.sleepUntil - Date.now())})_`
    }

    const bioLine = p.bio ? `📝 _${p.bio}_\n\n` : ''
    const endLine = endStatusBadge(db, p)
    const pTag = getGuildTag(p)
    const pDisplayName = pTag ? `${pTag} ${p.name}` : p.name
    const stats = p.stats ?? {}

    const fullText =
      `👤 *${pDisplayName}*` +
      (isPremiumActive(p) ? `  👑 *PREMIUM*` : '') +
      (isReborn(p) ? `  🌟 *REBORN*` : '') +
      (p.title ? `  [${formatTitle(p.title)}]` : '') + `\n` +
      `⚔️ ${className}  |  🧬 ${raceName}\n\n` +
      bioLine +

      (hidesLevel(p)
        ? `🏅 ${titleTier(p).glyph} *${titleTier(p).name}*\n`
        : `${rank.emoji} *${rank.title}* _(${rank.epithet})_${prestigeBadge}\n` +
          `🏅 *Level ${p.level}*/${cap}  ✨ XP: ${p.xp ?? 0} _(${xpNeeded})_\n`) +
      `❤️ ${hpBar(p.hp ?? 100, p.maxHp ?? 100)}\n` +
      `💧 MP: ${p.mp ?? 50}/${p.maxMp ?? 50}  •  ⚡ Stamina: ${st.current}/${st.max}\n` +
      hungerBar(p) + `\n\n` +

      `💰 *Wallet & Balances*\n` +
      `  ☀️ Solars: *${solars.toLocaleString()}*  💎 Gems: *${fmtGems(gems)}*  🪙 Monds: *${fmtMonds(monds)}*\n` +
      `  🔒 Vault: *${vault.toLocaleString()}*  🏦 Bank: *${bankGold.toLocaleString()}*` +
      (empireBank > 0 ? `  🏰 Empire Bank: *${empireBank.toLocaleString()}*` : '') + `\n` +
      `  💵 Net Worth: *☀️ ${netWorth.toLocaleString()}*\n` +
      `  ${activeSeason?.id === 'season_02' ? '⭐' : '✨'} ${seasonCurrency}: *${p.seasonPoints ?? 0}*  🌌 Starfall Spins: *${p.starfall?.spins ?? 0}*\n\n` +

      `📊 *Stats & Record*\n` +
      (endLine ? `${endLine}\n` : '') +
      `  💪 STR ${stats.str ?? 0}  🏃 AGI ${stats.agi ?? 0}  🧠 INT ${stats.int ?? 0}\n` +
      `  🛡️ DEF ${stats.def ?? 0}  🍀 LCK ${stats.lck ?? 0}\n` +
      `  ✨ Stat Points: ${statPoints.unallocated} unallocated (${statPoints.earned}/${statPointCap(p.level, p)} earned)\n` +
      `  🏆 Battle Record: *${wins}W / ${losses}L* _(${winRatio} win rate)_\n` +
      `  🎖️ Badges: *${ach.unlocked}/${ach.total}* _(${ach.points} pts)_\n\n` +

      `🎭 *Characters & Companions*\n` +
      `  🦸 Active Character: *${activeCharName}*\n` +
      `  📜 Owned Characters (${ownedCharIds.length}): ${ownedCharNames}\n` +
      `  🐾 Active Pet: *${activePetName}*  _(Owned: ${ownedPetNames})_\n` +
      `  🐲 Active Beast: ${beastLine}\n` +
      `  💘 Waifu: ${waifuLine}\n\n` +

      `🗡️ *Equipped*\n${eqLines}\n\n` +

      `✨ *Abilities (${equippedAbilities.length}/${abilitySlots} slots)*\n${abilityLines}${premiumAbilityLine}\n\n` +

      `🎒 Inventory: ${p.inventory?.length ?? 0}/${getInventoryCap(p)}  •  ✨ Skills: ${p.skills?.length ?? 0} learned\n` +
      locationLine

    try {
      const cardBuffer = await renderProfileCard(p)
      return await ctx.replyImage(cardBuffer, fullText)
    } catch (err) {
      return reply(fullText)
    }
  },
}
