/**
 * pick — claim a face-up reward chest choice (R2).
 * Boss kills can leave a pending chest of three options; this pays the one
 * the player chooses. An unclaimed chest simply stays pending.
 * Usage: .pick 1|2|3
 */
import { updatePlayer } from '../lib/player-repo.js'
import { resolveChoice } from '../lib/reward-choice.js'
import { awardBossToken } from '../lib/boss-tokens.js'
import { recordFaucet } from '../lib/economy-ledger.js'
import { settlePlayerXp, xpLevelLine } from '../lib/player-xp.js'

export default {
  name: 'pick',
  aliases: ['choose'],
  category: 'economy',
  requiresPlayer: true,
  description: 'Choose a reward from a pending chest (1, 2, or 3)',

  async run(ctx) {
    const choice = ctx.args?.[0]
    let reply
    await updatePlayer(ctx.db, ctx.from, (player) => {
      const chest = player.pendingChest
      if (!chest || !chest.options?.length) {
        reply = '❌ No reward chest is waiting for you. Boss kills can leave one after the fight.'
        return player
      }
      const resolved = resolveChoice(chest, choice)
      if (!resolved.ok) {
        reply = `❌ Pick 1, 2 or 3 — this chest has ${chest.options.length} options.`
        return player
      }
      const opt = resolved.option
      player.wallet = player.wallet ?? {}
      const granted = []
      if (opt.kind === 'solars') {
        player.wallet.solars = (player.wallet.solars ?? 0) + opt.amount
        recordFaucet(ctx.db, 'reward_chest', { solars: opt.amount })
        granted.push(`☀️ ${opt.amount.toLocaleString()} Solars`)
      } else if (opt.kind === 'gems') {
        player.wallet.gems = (player.wallet.gems ?? 0) + opt.amount
        recordFaucet(ctx.db, 'reward_chest', { gems: opt.amount })
        granted.push(`💎 ${opt.amount} Gems`)
      } else if (opt.kind === 'xp') {
        player.xp = (player.xp ?? 0) + opt.amount
        granted.push(`📖 ${opt.amount.toLocaleString()} XP`)
      } else if (opt.kind === 'boss_token') {
        const bossId = chest.id.split(':')[1] ?? 'unknown'
        const balance = awardBossToken(player, bossId, opt.amount)
        granted.push(`🎟️ ${opt.amount} boss tokens (${balance} held)`)
      } else {
        reply = '❌ That reward could not be granted.'
        return player
      }
      player.pendingChest = null
      reply = `🎁 *Reward claimed:* ${granted.join(' · ')}${xpLevelLine(settlePlayerXp(player))}`
      return player
    })
    return ctx.reply(reply)
  },
}
