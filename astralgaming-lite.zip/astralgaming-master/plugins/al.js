import { config } from '../config.js'
import { playLeagueMove } from './league-battle.js'
import { updatePlayer, getPlayer } from '../lib/player-repo.js'
import { checkLucidOngoingTurn } from '../lib/yu-miaoyi.js'
import { resolveSwarmDirectionalAttack } from '../lib/swarm-combat.js'

export default {
  name: 'al', aliases: ['attackleft'],
  category: 'combat', requiresPlayer: true,
  description: 'Strike the monster on your left in a swarm fight',

  async run(ctx) {
    if (await playLeagueMove(ctx, 'attack', '')) return
    // Yu Miaoyi — the owner's battle commands are refused while she is
    // driving, and her auto-fight resumes. Runs BEFORE updatePlayer below:
    // the driver writes through updatePlayer itself and must never nest.
    {
      const lucid = await checkLucidOngoingTurn(getPlayer(ctx.db, ctx.from), ctx)
      if (lucid.intercepted) return
    }
    const p = config.prefix
    await updatePlayer(ctx.db, ctx.from, async (player) => {
      if (player.battleState?.mode !== 'swarm') {
        await ctx.reply(`◀ *${p}al* only works in a swarm fight. _In a 1v1 fight use ${p}attack._`)
        return player
      }
      return resolveSwarmDirectionalAttack(player, ctx, 'left')
    })
  },
}
