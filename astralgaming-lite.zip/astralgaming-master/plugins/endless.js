import { ENDLESS_LOSS_WARNING } from '../lib/endless-loss.js'
import { config } from '../config.js'
import { sendImage } from '../lib/image.js'
import { activeEndlessRun, endlessState, rankName, badgeName, winsForPromotion, ENDLESS_RANKS, ENDLESS_ID } from '../lib/endless-dungeon.js'

export default {
  name: 'endless',
  aliases: ['endlessrank', 'srank'],
  category: 'dungeon',
  requiresPlayer: true,
  description: 'View your seasonal Endless Dungeon rank and climb',
  async run(ctx) {
    const active = activeEndlessRun(ctx.db) !== null
    const state = endlessState(ctx.player, ctx.db)
    const required = winsForPromotion(state.index)
    const highest = active && ctx.player.endlessRank?.runNumber === state.runNumber
      ? ctx.player.dungeonProgress?.[ENDLESS_ID]?.highestFloor ?? 0 : 0
    const remaining = required === null ? null : Math.max(0, required - state.wins)
    const progress = required === null
      ? 'Divine is the highest rank.'
      : `⚔️ Progress: *${state.wins}/${required} wins*\n🎯 Next: *${rankName(state.index + 1)}* · *${remaining}* more win${remaining === 1 ? '' : 's'}`
    const list = ctx.args?.[0]?.toLowerCase() === 'list' ? `\n\n${ENDLESS_RANKS.join(' · ')}` : ''
    const rankLine = active ? `🏅 Rank: *${rankName(state.index)}*` : '🌙 No Endless season is active. Starting rank next season: *Novice I*'
    const text = `🌌 *ENDLESS SEASONAL RANK*\n\n${rankLine}\n${progress}\n🪜 Highest floor this season: *${highest}*\n\nRank advances through wins on new Endless floors, not XP. Wins reset after each promotion; rank and floors reset each season. Higher ranks strengthen regular dungeon enemies.\n\nEnter: *${config.prefix}enter ${ENDLESS_ID}* · All ranks: *${config.prefix}sranks*${list}\n\n${ENDLESS_LOSS_WARNING}`
    return sendImage(ctx, badgeName(state.index), text)
  },
}
