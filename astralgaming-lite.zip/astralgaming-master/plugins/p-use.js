/**
 * p-use.js — Pokémon overhaul §4.1: consume a data/pokemon-items.json
 * "battle" item on one of your Pokémon, mid-battle or out of battle.
 *
 * Named `.p-use` (short form) rather than `.pokemon useitem` — every other
 * Pokémon command in this overhaul has a long canonical form buried under
 * `.pokemon <subcommand>`, but this one gets called constantly mid-battle
 * under a 60s turn clock, so it gets its own short top-level command,
 * same reasoning as why `.move` (not `.pokemon move`) exists standalone.
 *
 * Mirrors plugins/use.js's item-consumption pattern (find in inventory →
 * validate → applyItemEffect via lib/effects.js → splice one copy →
 * updatePlayer) but targets an owned Pokémon (mon.currentHp/mon.maxHp/
 * mon.activeEffects) instead of the player object itself. Only items from
 * data/pokemon-items.json with category: "battle" are usable here —
 * cosmetic items are never "used", they're purely display (see
 * .p-poke info / plugins/pokeshop.js).
 *
 * Usage:
 *   .p-use <item> <mon>   — consume a battle item on that Pokémon
 *
 * <mon> resolution: same query the rest of the Pokémon system already uses
 * (lib/pokemon-engine.js's findOwnedPokemon — exact id, nickname, or name/
 * partial-name match).
 */
import { config } from '../config.js'
import { createRequire } from 'module'
import { updatePlayer } from '../lib/player-repo.js'
import { findOwnedPokemon } from '../lib/pokemon-engine.js'
import { applyEffect, addStatusEffect } from '../lib/effects.js'

const require = createRequire(import.meta.url)
const pokemonItems = require('../data/pokemon-items.json')

const pokeItemMap = new Map(pokemonItems.map((i) => [i.id, i]))

// Effect types lib/effects.js treats as instant (handled by applyEffect) —
// same split plugins/use.js already uses for the general item system.
const INSTANT_TYPES = new Set(['heal', 'cure'])

/**
 * Thin shim so lib/effects.js's entity-agnostic heal/regen/shield handlers
 * (which read/write entity.hp / entity.maxHp) work against an owned
 * Pokémon's actual field names (currentHp / maxHp). Only 'hp' is ever a
 * valid `stat` for a Pokémon item's heal effect — there's no MP on a
 * Pokémon — so this only needs to shim that one field, applied both ways
 * around the call.
 */
function applyItemEffectToMon(mon, eff) {
  if (eff.stat === 'hp') {
    const shim = { hp: mon.currentHp, maxHp: mon.maxHp, activeEffects: mon.activeEffects ?? [] }
    const line = INSTANT_TYPES.has(eff.type) ? applyEffect(shim, eff) : (addStatusEffect(shim, eff), null)
    mon.currentHp = shim.hp
    mon.activeEffects = shim.activeEffects
    return line ?? `✨ ${eff.type} effect applied.`
  }

  // Non-hp effects (strengthen/cure targeting non-hp stats/status types)
  // only ever touch activeEffects, which already exists directly on mon —
  // no field-name shim needed.
  if (INSTANT_TYPES.has(eff.type)) {
    return applyEffect(mon, eff)
  }
  addStatusEffect(mon, eff)
  return `✨ ${eff.type === 'strengthen' ? `${eff.stat?.toUpperCase()} rose` : eff.type} for ${eff.duration} turn(s).`
}

const USABLE_CATEGORIES = new Set(['battle', 'revive', 'cosmetic'])

const TRAINER_TITLES = {
  poke_trainer_title_ace:      'Ace Trainer',
  poke_trainer_title_champion: 'Pokémon Champion',
}

const MON_COSMETICS = {
  poke_ribbon_basic:    { icon: '🎀', label: 'Cool Ribbon', happiness: 5 },
  poke_ribbon_champ:    { icon: '🏅', label: 'Champion Ribbon', happiness: 10 },
  poke_spotlight_charm: { icon: '✨', label: 'Spotlight Charm', happiness: 15 },
}

/** Find a usable Pokémon-shop item in the player's inventory by exact id or partial name. */
function findUsablePokeItem(inventory, query) {
  const q = String(query ?? '').toLowerCase().trim()
  if (!q) return null
  const withPrefix = q.startsWith('poke_') ? q : `poke_${q.replace(/\s+/g, '_')}`

  for (const candidate of [q, withPrefix]) {
    if (inventory.includes(candidate) && USABLE_CATEGORIES.has(pokeItemMap.get(candidate)?.category)) {
      return candidate
    }
  }
  for (const id of inventory) {
    const item = pokeItemMap.get(id)
    if (USABLE_CATEGORIES.has(item?.category) && item.name.toLowerCase().includes(q)) return id
  }
  return null
}

function isTrainerSelfCosmetic(itemId) {
  return Boolean(TRAINER_TITLES[itemId] || itemId === 'poke_prestige_aura')
}

export default {
  name: 'p-use',
  aliases: ['puse', 'pokeuse'],
  category: 'pokemon',
  requiresPlayer: true,
  description: `${config.prefix}p-use <item> [mon] — use a Pokémon battle item, revive, ribbon, or trainer flair`,
  subcommands: [
    { cmd: '<item> <mon>', desc: 'use a battle item, revive, or ribbon on that Pokémon' },
    { cmd: '<title|aura>', desc: 'activate a trainer title scroll or Prestige Aura' },
  ],

  async run(ctx) {
    const { player, args, db, reply } = ctx
    const pr = config.prefix

    if (!args.length) {
      return reply(`❓ Usage: *${pr}p-use <item> <mon>*\n_e.g._ *${pr}p-use oran berry pikachu*, *${pr}p-use revive charizard*, or *${pr}p-use ace trainer*`)
    }

    const full = args.join(' ')
    const invNow = player.inventory ?? []

    // 1. Check trainer-level cosmetics first (no <mon> needed).
    const directItem = findUsablePokeItem(invNow, full)
    if (directItem && isTrainerSelfCosmetic(directItem)) {
      const item = pokeItemMap.get(directItem)
      let selfOutcome = null
      await updatePlayer(db, player.id, (p) => {
        const inv = p.inventory ?? []
        const idx = inv.indexOf(directItem)
        if (idx === -1) { selfOutcome = { ok: false, reason: 'gone' }; return p }
        if (directItem === 'poke_prestige_aura') {
          if (p.pokePrestigeAura) { selfOutcome = { ok: false, reason: 'already_aura' }; return p }
          p.pokePrestigeAura = true
          inv.splice(idx, 1)
          p.inventory = inv
          selfOutcome = { ok: true, kind: 'aura' }
          return p
        }
        const title = TRAINER_TITLES[directItem]
        p.unlockedTitles = Array.isArray(p.unlockedTitles) ? p.unlockedTitles : []
        if (p.unlockedTitles.includes(title)) {
          p.title = title
          selfOutcome = { ok: false, reason: 'already_title', title }
          return p
        }
        p.unlockedTitles.push(title)
        p.title = title
        inv.splice(idx, 1)
        p.inventory = inv
        selfOutcome = { ok: true, kind: 'title', title }
        return p
      })
      if (!selfOutcome?.ok) {
        if (selfOutcome?.reason === 'already_aura') {
          return reply(`⚠️ Your *Prestige Aura* 🌟 is already active — save or sell the duplicate!`)
        }
        if (selfOutcome?.reason === 'already_title') {
          return reply(`✅ You already unlocked *[${selfOutcome.title}]* — equipped it as your active title without consuming another scroll.`)
        }
        return reply(`❌ *${item.name}* is no longer in your inventory.`)
      }
      if (selfOutcome.kind === 'aura') {
        return reply(`🌟 *Prestige Aura unlocked!* Your profile and Pokémon party now carry the radiant trainer aura.`)
      }
      return reply(`🎖️ *Trainer Title unlocked & equipped:* *[${selfOutcome.title}]*!\n_Switch titles anytime with *${pr}title*._`)
    }

    if (args.length < 2) {
      return reply(`❓ Usage: *${pr}p-use <item> <mon>*\n_e.g._ *${pr}p-use oran berry pikachu*`)
    }

    let itemId = null
    let monQuery = null

    for (let split = args.length - 1; split >= 1; split--) {
      const itemCandidate = args.slice(0, split).join(' ')
      const monCandidate  = args.slice(split).join(' ')
      const found = findUsablePokeItem(invNow, itemCandidate)
      if (found) {
        itemId = found
        monQuery = monCandidate
        break
      }
    }

    if (!itemId) {
      return reply(
        `❌ Couldn't find a usable Pokémon item matching *"${full}"*.\n` +
        `Check *${pr}inventory* or browse *${pr}p-shop*.`,
      )
    }

    const item = pokeItemMap.get(itemId)
    const mon = findOwnedPokemon(player, monQuery)
    if (!mon) {
      return reply(`🚫 You don't own a Pokémon matching *"${monQuery}"*.`)
    }

    let resultLines = []
    let outcome = null

    await updatePlayer(db, player.id, (p) => {
      const inv = p.inventory ?? []
      const idx = inv.indexOf(itemId)
      if (idx === -1) { outcome = { ok: false, reason: 'gone' }; return }

      const freshMon = findOwnedPokemon(p, monQuery)
      if (!freshMon) { outcome = { ok: false, reason: 'no_mon' }; return }

      // Revives: only consume when the Pokémon is actually fainted (0 HP).
      if (item.category === 'revive') {
        const cur = freshMon.currentHp ?? freshMon.maxHp ?? 0
        if (cur > 0) {
          outcome = { ok: false, reason: 'not_fainted', mon: freshMon }
          return
        }
        const pct = itemId === 'poke_max_revive' ? 1 : 0.5
        freshMon.currentHp = Math.max(1, Math.floor((freshMon.maxHp ?? 1) * pct))
        if (itemId === 'poke_max_revive') freshMon.activeEffects = []
        resultLines.push(`💛 Revived to *${freshMon.currentHp}/${freshMon.maxHp} HP*!`)
      } else if (MON_COSMETICS[itemId]) {
        const meta = MON_COSMETICS[itemId]
        freshMon.cosmetics = Array.isArray(freshMon.cosmetics) ? freshMon.cosmetics : []
        if (freshMon.cosmetics.includes(itemId)) {
          outcome = { ok: false, reason: 'already_cosmetic', mon: freshMon, meta }
          return
        }
        freshMon.cosmetics.push(itemId)
        freshMon.happiness = Math.min(100, (freshMon.happiness ?? 50) + meta.happiness)
        resultLines.push(`${meta.icon} Adorned with *${meta.label}*! (+${meta.happiness} happiness)`)
      } else {
        const effectList = Array.isArray(item.effect) ? item.effect : [item.effect]
        for (const eff of effectList) {
          if (eff) resultLines.push(applyItemEffectToMon(freshMon, eff))
        }
      }

      inv.splice(idx, 1)
      p.inventory = inv
      outcome = { ok: true, mon: freshMon }
    })

    if (!outcome?.ok) {
      if (outcome?.reason === 'no_mon') return reply(`🚫 You don't own a Pokémon matching *"${monQuery}"*.`)
      if (outcome?.reason === 'not_fainted') {
        return reply(`⚠️ *${outcome.mon.nickname ?? outcome.mon.name}* isn't fainted (${outcome.mon.currentHp}/${outcome.mon.maxHp} HP) — save your *${item.name}*!`)
      }
      if (outcome?.reason === 'already_cosmetic') {
        return reply(`⚠️ *${outcome.mon.nickname ?? outcome.mon.name}* is already wearing ${outcome.meta.icon} *${outcome.meta.label}*!`)
      }
      return reply(`❌ *${item.name}* is no longer in your inventory — please try again.`)
    }

    return reply(
      `✨ You used *${item.name}* on *${outcome.mon.nickname ?? outcome.mon.name}*!\n` +
      resultLines.join('\n'),
    )
  },
}
