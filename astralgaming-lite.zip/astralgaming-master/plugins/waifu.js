/**
 * waifu.js — show your currently set waifu card, or toggle card auto-spawn
 * for this group.
 * Usage: .waifu             — show your waifu card
 *        .cards on / off    — bot mods/owner only, toggles hourly spawns
 *                              (.waifu on/off remains a compatible spelling)
 */
import { config } from '../config.js'
import { getWaifu, tierStars, cardSellPrice, fetchSpawnCard, hasCardSeries } from '../lib/card-engine.js'
import { isGifUrl } from '../lib/card-media.js'
import { getGroupSettings, saveGroupSettings, saveFailedMessage, isBotStaff } from '../lib/group-settings.js'
import { addCardSpawnGroup, removeCardSpawnGroup } from '../lib/card-spawn-groups.js'
import { NOT_GROUP, NOT_ALLOWED, NOT_STAFF } from '../lib/group-helpers.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import { setActiveSpawn } from '../lib/card-spawn-state.js'
import { cardSpawnCaption } from '../lib/card-spawn-caption.js'
import { CARD_SPAWN_INTERVAL_MS, humanInterval } from '../lib/spawn-intervals.js'

const SPAWN_EVERY = humanInterval(CARD_SPAWN_INTERVAL_MS)

export default {
  name: 'waifu',
  aliases: ['wife'],
  category: 'cards',
  requiresPlayer: true,
  description: 'Show your waifu card, or toggle hourly group spawns (.cards on/off)',

  async run(ctx) {
    const { args, reply, replyImage, replyGif, player } = ctx
    const sub = (args[0] ?? '').toLowerCase()

    // ── SPAWN (bot owner only) — manually force a card spawn right now ────
    if (sub === 'spawn') {
      if (!ctx.isGroup) return reply(NOT_GROUP)
      if (!isOwnerJid(ctx.from)) return reply(NOT_ALLOWED)

      const card = await fetchSpawnCard()
      if (!card) return reply(`❌ Couldn't reach the card API — try again shortly.`)

      setActiveSpawn(ctx.sender, card)
      const spawnText = cardSpawnCaption(card, { prefix: config.prefix })

      // ── One tap instead of a typed code ──────────────────────────────
      // A spawn is a race: the code is six characters, and on a phone in a
      // busy group every second matters. The button's data is the exact
      // `collect <code>` the caption asks for, so tapping it IS typing it
      // (the adapter routes `c:` back through runCommand).
      const catchButtons = [[{ text: '🎴 Catch it!', data: `c:collect ${card.claim}` }]]

      // GIF cards loop via replyGif (MP4 transcode + gifPlayback), stills via
      // replyImage — same split lib/card-media.js makes for the auto-spawns.
      // Only the still path can carry a keyboard today; the GIF keeps the
      // typed instruction that is already in the caption.
      if (isGifUrl(card.imageUrl)) return replyGif(card.imageUrl, spawnText)
      if (typeof ctx.replyImageButtons === 'function') {
        return ctx.replyImageButtons(card.imageUrl, spawnText, catchButtons)
      }
      return replyImage(card.imageUrl, spawnText)
    }

    // Read-only delivery setting, also available as `.cards status`.
    if (sub === 'status') {
      if (!ctx.isGroup) return reply(NOT_GROUP)
      const settings = await getGroupSettings(ctx.sender)
      return reply(
        `🎴 *Hourly card spawns: ${settings.cardsEnabled ? 'ON' : 'OFF'}*\n\n` +
        (settings.cardsEnabled
          ? `Cadence: one card every *${SPAWN_EVERY}* while the bot is running.\nNight mode pauses delivery.`
          : `A bot owner/mod can enable them with *${config.prefix}cards on*.`),
      )
    }

    // ── ON / OFF (bot staff only) — toggles hourly card auto-spawn ────
    if (sub === 'on' || sub === 'off') {
      if (!ctx.isGroup) return reply(NOT_GROUP)
      if (!(await isBotStaff(ctx))) return reply(NOT_STAFF)

      const enable = sub === 'on'
      // Save FIRST and bail if it didn't land. The spawn-group list and this
      // flag have to agree — registering the group for spawns after a failed
      // settings write leaves cards spawning in a group whose saved setting
      // says they're off, which is unfixable from chat.
      const res = await saveGroupSettings(ctx.sender, (s) => { s.cardsEnabled = enable })
      if (!res.ok) return reply(saveFailedMessage('card auto-spawn', res.error))

      const stored = res.settings.cardsEnabled === true
      if (stored) await addCardSpawnGroup(ctx.sender)
      else await removeCardSpawnGroup(ctx.sender)

      return reply(
        stored
          ? `🎴 *Card Auto-Spawn — ON*\n` +
            `━━━━━━━━━━━━━━━━━\n` +
            `⏱️ A card appears here every *${SPAWN_EVERY}* while the bot is running.\n` +
            `🎯 Catch it with *${config.prefix}collect <code>*.\n` +
            `_Night mode pauses spawns. The owner can test with ${config.prefix}cards spawn._`
          : `🚫 *Card Auto-Spawn — OFF*\n` +
            `━━━━━━━━━━━━━━━━━\n` +
            `No more cards will appear in this group.\n` +
            `Re-enable with *${config.prefix}cards on*.`
      )
    }

    // ── Group gate — viewing/using waifu cards also requires .waifu on ────
    if (ctx.isGroup) {
      const settings = await getGroupSettings(ctx.sender)
      if (!settings.cardsEnabled) {
        return reply(
          `🚫 Cards are disabled in this group.\n` +
          `_A bot mod can turn them on with *${config.prefix}cards on*._`,
        )
      }
    }

    // ── Show current waifu ────────────────────────────────────────────────
    const card = getWaifu(player)

    if (!card) {
      return reply(
        `💔 *You haven't set a waifu yet.*\n\n` +
        `_Collect cards as they spawn with *${config.prefix}collect <code>*, then_\n` +
        `_*${config.prefix}setwaifu <card name>* to pick one._`
      )
    }

    const caption =
      `💘 *${player.name}'s Waifu*\n\n` +
      `${tierStars(card.tier)} *${card.title}*\n` +
      (hasCardSeries(card.series) ? `📺 _${card.series}_` : '')

    if (card.imageUrl) {
      const send = isGifUrl(card.imageUrl) ? replyGif : replyImage
      return send(card.imageUrl, caption)
    }
    return reply(caption)
  },
}
