/**
 * cage.js — Seong-ha's signature: Cage of the World.
 *
 * She does not throw a blow this turn. She writes the world a small, sealed
 * room with one enemy inside it, for six turns (ten in the Astral Witch
 * form). The prisoner cannot act or be cleansed out of the cage; the party
 * hits it as hard as it likes the whole time. Once per battle.
 *
 * Party fights carry no battleState of their own and duels run a two-player
 * engine — both get a plain refusal for now rather than a half-wired second
 * engine. The cage REQUIRES her: it is her skill, not a consumable.
 *
 * Usage: <prefix>cage
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { hpBar } from '../lib/combat-engine.js'
import {
  handleVictory,
  processStatusTurn,
  resolvePlayerHpZero,
  checkCatFormOngoingTurn,
} from '../lib/combat-handlers.js'
import { hasEffect } from '../lib/effects.js'
import {
  applyBossSpecial, incrementBossTurn, cleanupBossFight, EVENT,
} from '../lib/boss-engine.js'
import { tickPermanentSever } from '../lib/character-abilities.js'
import { sendBattleTurnReply } from '../lib/battle-frame-render.mjs'
import { findPartyForPlayer } from './party.js'
import { seongHaEquipped, castCage } from '../lib/starfall-champion.js'

function isBossFight(player) {
  return !!(player.battleState?.enemy?.isBoss && player.battleState?.bossState)
}

export default {
  name: 'cage',
  aliases: ['cageoftheworld', 'cage-world', 'worldcage', 'imprison'],
  category: 'combat',
  requiresPlayer: true,
  description: `${config.prefix}cage — Seong-ha's Cage of the World: seal one enemy where it stands, once per battle`,

  async run(ctx) {
    const p = config.prefix

    if (ctx.player?.battleState?.type === 'pvp') {
      return ctx.reply('⛓️ _The cage answers in the dungeon, not across a duel table._')
    }
    if (ctx.player?.inBattle && !ctx.player.battleState && findPartyForPlayer(ctx.db, ctx.from)?.battle) {
      return ctx.reply('⛓️ _The cage answers on a single road. Party battles close it for now._')
    }
    if (!seongHaEquipped(ctx.player)) {
      return ctx.reply('⛓️ *Cage of the World* belongs to Seong-ha. Equip her first.')
    }

    return updatePlayer(ctx.db, ctx.from, async player => {
      const bs = player.battleState
      if (!player.inBattle || !bs?.enemy) {
        await ctx.reply(`❌ Not in battle. Use *${p}dungeon* to find an enemy.`)
        return player
      }
      const boss = isBossFight(player)
      const catTurn = await checkCatFormOngoingTurn(player, ctx, { boss })
      if (catTurn.intercepted) return catTurn.returnValue

      if (bs.cageUsed) {
        await ctx.reply('⛓️ The cage has already been spent this battle. One room, one prisoner.')
        return player
      }

      const e = bs.enemy
      const hpBeforeTurn  = player.hp
      const eHpBeforeTurn = e.hp
      bs.cageUsed = true
      bs.playerDefending = false
      let msg = ''

      const permaSeverLine = tickPermanentSever(player)
      if (permaSeverLine) msg += permaSeverLine + '\n'
      if (player.hp <= 0) {
        const res = await resolvePlayerHpZero(player, ctx, msg, { boss })
        if (!res.fallThrough) return res.returnValue
        msg = res.msg
      }

      if (boss) {
        incrementBossTurn(player)
        const tsResult = applyBossSpecial(player, EVENT.TURN_START, {})
        if (tsResult.narrativeLine) msg += `_${tsResult.narrativeLine}_\n`
      }

      const playerStatus = processStatusTurn(player)
      if (playerStatus.lines.length) msg += playerStatus.lines.join('\n') + '\n'
      if (player.hp <= 0) {
        const res = await resolvePlayerHpZero(player, ctx, msg, { boss })
        if (!res.fallThrough) return res.returnValue
        msg = res.msg
      }
      if (playerStatus.incapacitated) {
        msg += `💫 *${player.name}* is unable to act this turn! The cage holds its shape anyway — it is already written.\n`
      }

      msg += castCage(player, e).lines.join('\n') + '\n'

      // The prisoner's own clock still runs — burn and rot do not wait for a
      // guard to unlock. If it dies inside the cage, the fight is over and
      // the victory screen is the narration.
      const enemyStatus = processStatusTurn(e, { bossState: player.battleState?.bossState })
      if (enemyStatus.lines.length) msg += enemyStatus.lines.join('\n') + '\n'
      if (e.hp <= 0) {
        if (boss) cleanupBossFight(player)
        return handleVictory(player, e, ctx)
      }
      if (boss) {
        const teResult = applyBossSpecial(player, EVENT.TURN_END, {})
        if (teResult.narrativeLine) msg += `\\n_${teResult.narrativeLine}_`
      }

      msg += `\n\n👤 *${player.name}*\n❤️ ${hpBar(player.hp, player.maxHp)}  💧 ${player.mp}/${player.maxMp} MP${'\n'}` +
        `${e.emoji ?? '👾'} *${e.name}*${hasEffect(e, 'cage') ? ' ⛓️ _caged_' : ''}\n❤️ ${hpBar(e.hp, e.maxHp)}\n\n` +
        `*${p}attack* · *${p}skill <name>* · *${p}defend* · *${p}flee*`

      bs.turn = (bs.turn ?? 1) + 1
      player.battleState = bs

      await sendBattleTurnReply(ctx, { bs, player, e, msg, hpBeforeTurn, eHpBeforeTurn, boss })
      return player
    })
  },
}
