/**
 * delpfp.js — .delpfp
 * Removes your custom profile picture (set via .setpfp), reverting .me /
 * .profile back to the plain text-only display.
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { deleteProfilePicture } from '../lib/pfp.js'
import { PFP_CHANGE_GEMS } from './setpfp.js'

export default {
  name:           'delpfp',
  aliases:        ['removepfp', 'clearpfp', 'delavatar'],
  category:       'account',
  requiresPlayer: true,
  description:    'Remove your profile picture',

  async run(ctx) {
    const { player, db, from, reply } = ctx

    if (!player.pfp) {
      return reply(`❌ You don't have a profile picture set. Use *${config.prefix}setpfp* to add one.`)
    }

    await deleteProfilePicture(player.pfp)
    await updatePlayer(db, from, (p) => { p.pfp = null })

    // Removing a picture is free, but it does not reset the free first set:
    // plugins/setpfp.js charges once a player has had one (player.pfpSets, and
    // the very picture just deleted). Say so here rather than surprising them
    // there.
    return reply(
      `✅ Profile picture removed. Check *${config.prefix}me* — back to the default look.` +
      `\n_Setting a new picture costs 💎${PFP_CHANGE_GEMS}._`,
    )
  },
}
