import { selectProfileCosmeticCommand } from './profile-cosmetics.js'
export default {
  name: 'pickframe', aliases: ['equipframe'], category: 'account', requiresPlayer: true,
  description: 'Select an unlocked animated Fluid Frame for .me',
  async run(ctx) { return selectProfileCosmeticCommand(ctx, 'frame') },
}
