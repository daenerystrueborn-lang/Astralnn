/**
 * setbanner.js — .setbanner
 * Sets your custom profile banner, shown on the .me / .profile card.
 *
 * Usage:
 *   Send an image with the caption ".setbanner"       — direct attach
 *   Reply ".setbanner" to a message that has an image  — quoted/reply
 */
import { config } from '../config.js'
import { updatePlayer } from '../lib/player-repo.js'
import { getActiveSeason } from '../lib/season-engine.js'
import { profileUploadDisabledForSeason } from '../lib/profile-cosmetics.js'
import { readProfileBannerBuffer, saveProfileBannerBuffer } from '../lib/banner.js'

export default {
  name:           'setbanner',
  aliases:        ['setprofilebanner'],
  category:       'account',
  requiresPlayer: true,
  description:    'Set your profile banner (attach or reply to an image)',

  async run(ctx) {
    const { db, from, reply } = ctx
    if (profileUploadDisabledForSeason(getActiveSeason(db))) {
      return reply(`🚫 Custom banner uploads are disabled for Season 2. Earn and select a banner with *${config.prefix}cosmetics* / *${config.prefix}pickbanner <id|default>*.`)
    }

    // Same platform-neutral read as .setpfp — the Baileys-only version could
    // never succeed on Telegram. See lib/pfp.js.
    let buffer = null
    try {
      buffer = await readProfileBannerBuffer(ctx)
    } catch (err) {
      return reply(`❌ Couldn't read that image — please try again.\n_Error: ${err.message}_`)
    }
    if (!buffer) {
      return reply(
        `❌ *Usage:* send an image with caption *${config.prefix}setbanner*, ` +
        `or reply *${config.prefix}setbanner* to an existing image.`,
      )
    }

    let filePath
    try {
      filePath = await saveProfileBannerBuffer(buffer, from)
    } catch (err) {
      return reply(`❌ Couldn't save that image — please try again.\n_Error: ${err.message}_`)
    }

    await updatePlayer(db, from, (p) => { p.banner = filePath })

    return reply(`✅ Banner updated! Check it with *${config.prefix}me* or *${config.prefix}profile*.`)
  },
}
