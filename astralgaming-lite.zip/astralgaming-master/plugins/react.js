/**
 * react — combine two raw materials into a deterministic reaction product.
 * Usage: .react <material one> + <material two> | .react list
 */
import { config } from '../config.js'
import { noServicesRefusal } from '../lib/dreamlands-core.js'
import { allItems, materialReactions, materials } from '../lib/game-data.js'
import { hasInventoryRoom, inventoryFullMessage } from '../lib/inventory-limits.js'
import {
  applyMaterialReaction,
  findMaterialReaction,
  resolveMaterialQuery,
} from '../lib/material-reactions.js'
import { updatePlayer } from '../lib/player-repo.js'

const itemById = Object.fromEntries(allItems.map(item => [item.id, item]))

function ingredientsText(reaction) {
  return reaction.ingredients.map(({ itemId, qty }) => {
    const name = itemById[itemId]?.name ?? itemId
    return `${name} ×${qty}`
  }).join(' + ')
}

export default {
  name: 'react',
  aliases: ['reaction', 'combine'],
  category: 'town',
  requiresPlayer: true,
  description: `${config.prefix}react <material> + <material> — combine materials at the blacksmith`,

  async run(ctx) {
    const { player, args = [] } = ctx
    const prefix = config.prefix

    if (player.inBattle) return ctx.reply('⚔️ You cannot combine materials during a battle.')
    if (player.inDungeon) return ctx.reply(`🗺️ Leave the dungeon first. Use *${prefix}dungeon leave*.`)
    const noServices = noServicesRefusal(player)
    if (noServices) return ctx.reply(noServices)
    if (player.location !== 'astral_town') {
      return ctx.reply(`🧪 Material reactions are available at the blacksmith in *Astral Town*.`)
    }

    const query = args.join(' ').trim()
    if (!query || query.toLowerCase() === 'list') {
      const rows = materialReactions.map(reaction => {
        const output = itemById[reaction.output.itemId]?.name ?? reaction.output.itemId
        return `• *${output}* — ${ingredientsText(reaction)}; ${reaction.solarsCost} ☀️`
      })
      return ctx.reply(
        `🧪 *MATERIAL REACTIONS*\n` +
        `Use *${prefix}react <material> + <material>* to combine two materials.\n\n` +
        (rows.length ? rows.join('\n') : 'No reactions are available yet.'),
      )
    }

    const parts = query.split(/\s*\+\s*/)
    if (parts.length !== 2 || parts.some(part => !part.trim())) {
      return ctx.reply(`Usage: *${prefix}react <material one> + <material two>*\nSee reactions: *${prefix}react list*`)
    }

    const first = resolveMaterialQuery(materials, parts[0])
    const second = resolveMaterialQuery(materials, parts[1])
    if (!first || !second) {
      const missing = !first ? parts[0].trim() : parts[1].trim()
      return ctx.reply(`❌ I could not find *${missing}* in the materials list.`)
    }

    const reaction = findMaterialReaction(materialReactions, first.id, second.id)
    if (!reaction) {
      return ctx.reply(`❌ *${first.name}* and *${second.name}* have no known reaction. Use *${prefix}react list* to see combinations.`)
    }

    const output = itemById[reaction.output.itemId]
    if (!output) return ctx.reply(`❌ Reaction data error: output *${reaction.output.itemId}* was not found.`)

    let outcome = null
    await updatePlayer(ctx.db, player.id, fresh => {
      outcome = applyMaterialReaction(fresh, reaction, {
        hasRoom: hasInventoryRoom(fresh, Math.max(1, Number(reaction.output.qty) || 1)),
      })
    })

    if (!outcome?.ok) {
      if (outcome?.reason === 'materials') {
        const list = outcome.missing.map(({ itemId, qty }) => `${itemById[itemId]?.name ?? itemId} ×${qty}`).join(', ')
        return ctx.reply(`❌ You need more materials: *${list}*.`)
      }
      if (outcome?.reason === 'solars') {
        return ctx.reply(`❌ You need *${outcome.missingSolars} more ☀️* for this reaction.`)
      }
      if (outcome?.reason === 'inventory_full') return ctx.reply(inventoryFullMessage(player))
      return ctx.reply('❌ That material reaction could not be completed. Nothing was changed.')
    }

    return ctx.reply(
      `🧪 *Reaction complete!* You made *${outcome.outputQty} ${output.name}*.\n` +
      `_(-${outcome.solarsSpent} ☀️ and ingredients consumed)_`,
    )
  },
}
