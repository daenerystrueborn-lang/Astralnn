/**
 * ban.js — .ban (reply to a member's message, or @mention them)
 * Bans a player account-wide: they cannot run ANY command (including
 * .register) until unbanned. Ban is stored independently of the player
 * record (lib/ban-repo.js), so it survives .admin resetplayer and can be
 * applied even to someone who has never registered.
 *
 * Permission: bot owner or a bot mod (same tier as .kick/.add). Group admins are refused.
 * Optional reason: .ban <reason text> (reply/mention the target)
 */
import { extractTarget, isOwnerJid, NOT_ALLOWED, NOT_STAFF } from '../lib/group-helpers.js'
import { isPlatformOwner } from '../lib/platform/permissions.js'
import { isGroupOrBotOwnerOrMod } from '../lib/group-settings.js'
import { banUser, getBan } from '../lib/ban-repo.js'
import { isMod } from '../lib/mod-repo.js'
import { resolvePlayerId } from '../lib/identity-resolver.js'
import { config } from '../config.js'

export default {
  name:        'ban',
  aliases:     [],
  category:    'admin',
  // WhatsApp-only: the target comes from Baileys' contextInfo, which does not
  // exist on Telegram. plugins-telegram/ban.js is the Telegram half (chat ban
  // via the Bot API), so both register 'ban' with disjoint platforms and the
  // registry hands each one its own.
  platforms:   ['whatsapp'],
  description: 'Ban a player account-wide (reply to their message or @mention them)',
  // Staff tool: mods and group admins run it, so mods see it in .allcommands.
  modTool: true,

  async run(ctx) {
    const { reply, msg, from, db, args, sock, sender } = ctx

    if (!(await isGroupOrBotOwnerOrMod(ctx))) return reply(NOT_STAFF)

    const target = extractTarget(msg)
    if (!target) {
      return reply(
        `❌ Reply to the member's message (or @mention them).\n\n` +
        `*Usage:* ${config.prefix}ban [reason] (reply to user)`,
      )
    }

    const canonicalTarget = resolvePlayerId(db, target)
    const canonicalCaller = resolvePlayerId(db, from)
    if (target === from || canonicalTarget === canonicalCaller) {
      return reply(`❌ You can't ban yourself.`)
    }
    if (isOwnerJid(target) || isOwnerJid(canonicalTarget) || isPlatformOwner(target) || isPlatformOwner(canonicalTarget)) {
      return reply(`❌ Can't ban the bot owner.`)
    }
    const callerIsOwner = isOwnerJid(from) || isPlatformOwner(from)
    if (!callerIsOwner && (isMod(db, target) || isMod(db, canonicalTarget))) {
      return reply(`❌ Mods cannot ban another mod — only the bot owner can do that.`)
    }

    const existing = getBan(db, target)
    const reason = args.join(' ').trim() || null

    await banUser(db, target, from, reason)

    const bareTarget = target.replace(/@.*$/, '')
    return sock.sendMessage(sender, {
      text:
        `🚫 ${existing ? 'Re-banned' : 'Banned'} @${bareTarget}.\n` +
        `They can no longer use any bot command until *${config.prefix}unban* is run on them.` +
        (reason ? `\nReason: _${reason}_` : '') +
        `\n\n📩 To appeal: DM the bot *${config.prefix}unban-me* — it sends the ` +
        `unban form, and the filled-in form comes back to the mod GC.`,
      mentions: [target],
    }, { quoted: msg })
  },
}
