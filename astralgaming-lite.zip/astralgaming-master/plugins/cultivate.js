/**
 * cultivate.js — `.cultivate` : sit in a mountain cave and grow.
 *
 * THE COMMAND, in three shapes:
 *   .cultivate                 the caves, and where your session stands
 *   .cultivate <cave>          start a session in that cave
 *   .cultivate collect         come out, and be paid for the hours
 *
 * Nothing is counted while a session runs: it is a cave id and a start time,
 * and lib/sect-progress.js works the hours out when the player collects. That
 * is why a session survives a restart, a long night and a bot redeploy, and why
 * collecting twice pays once (the second collect finds no session at all).
 *
 * WHILE A SESSION RUNS the player is in seclusion: lib/sect-lock.js refuses
 * everything off its seclusion list before dispatch ever reaches a plugin.
 */
import { cultivationNextStep } from '../lib/sect-guidance.js'
import { stageLabel } from '../lib/sect-cultivation.js'
import { config } from '../config.js'
import { isOwnerJid } from '../lib/group-helpers.js'
import { updatePlayer } from '../lib/player-repo.js'
import { sectDoorRefusal, missingSectRecordRefusal } from '../lib/world-guards.js'
import { rootLabel } from '../lib/sect-cultivation.js'
import { sectPicture, replyWithSectPicture } from '../lib/sect-images.js'
import {
  CAVES, caveById, collectSession, sessionCfg, sessionRate, sessionStatus,
  startSession, withGrowthLock,
} from '../lib/sect-progress.js'


/** Caves answer to their id, their name, and the first word of either. */
function matchCave(word) {
  const key = String(word ?? '').trim().toLowerCase()
  if (!key) return null
  const direct = caveById(key)
  if (direct) return direct
  return CAVES.find(c => c.name.toLowerCase().startsWith(key) || c.id.startsWith(key)) ?? null
}

export function caveScreen(player) {
  const profile = player.sect
  const session = sessionStatus(profile, Date.now())
  const lines = ['🧘✨ *YOUR TRAINING ARC*', '*Train safely, then collect to claim your progress. You can collect early; time beyond the session cap earns nothing.*']

  if (profile?.spiritRoot) {
    const speed = profile.spiritRoot.speedMultiplier ?? 1
    lines.push(`_Your roots: *${rootLabel(profile.spiritRoot)}* (x${speed} to everything you earn)._`)
  }
  lines.push('')

  for (const cave of CAVES) {
    const locked = profile ? (Number(profile.stage) || 0) < (Number(cave.minStage) || 0) : true
    const rate = profile ? sessionRate(profile, cave) : sessionRate({ spiritRoot: { speedMultiplier: 1 } }, cave)
    lines.push(`${cave.emoji} *${cave.name}*  _x${Number(cave.richness).toFixed(1)}_  ·  ${cave.requires}`)
    lines.push(locked ? `   🔒 *Reach ${stageLabel(cave.minStage)} to unlock.*` : `   ▶️ *${config.prefix}cultivate ${cave.id}*`)
    lines.push(`   _${locked ? 'Out of reach for now.' : cave.line}  ${locked ? '' : `*${rate.toFixed(2)}* progress an hour for you.`}_`)
  }

  if (session) {
    const elapsed = Date.now() - Number(profile.session.startedAt)
    lines.push('', `🧘 _In seclusion at *${session.cave.name}*: *${fmt(elapsed)}* in, *${fmt(session.leftMs)}* of the cap left._`)
    lines.push(`💠 *Banked: ${session.progress.toFixed(1)} progress.* ${session.leftMs <= 0 ? "Your session is capped — collect now!" : "Collect now or keep training up to the cap."}`)
  } else {
    const cap = Number(sessionCfg.maxHours) || 12
    lines.push('', `_Start with_ *${config.prefix}cultivate best*  ·  _come out with_ *${config.prefix}cultivate collect*  _(${cap}h a session before the rest is lost)._`)
  }
  lines.push('', cultivationNextStep(player, config.prefix))
  return lines.filter(line => line !== undefined).join('\n')
}

function fmt(ms) {
  const minutes = Math.max(0, Math.floor((Number(ms) || 0) / 60_000))
  if (minutes < 60) return `${minutes}m`
  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `${hours}h ${minutes % 60}m`
  const days = Math.floor(hours / 24)
  return hours % 24 ? `${days}d ${hours % 24}h` : `${days}d`
}

export default {
  name: 'cultivate',
  aliases: ['meditate', 'caves'],
  category: 'event',
  requiresPlayer: true,
  description: `${config.prefix}cultivate <cave|best|collect> — sit in a mountain cave and grow`,

  async run(ctx) {
    const player = ctx.player
    const wrongWorld = sectDoorRefusal(player, {
      emoji: '🧘', title: '*The cultivation caves belong to the Sect Empire.*',
      here: { cmd: 'dungeon', label: 'earn XP in Astra’s dungeons instead' },
    })
    if (wrongWorld) return ctx.reply(wrongWorld)
    if (!player.sect) return ctx.reply(missingSectRecordRefusal())

    const words = (ctx.args ?? []).map(a => String(a).toLowerCase()).filter(Boolean)
    const first = words[0] ?? ''

    // ── The screen ──────────────────────────────────────────────────────────
    if (!first) return replyWithSectPicture(ctx, sectPicture('cave'), caveScreen(player))

    // ── Collect ─────────────────────────────────────────────────────────────
    if (first === 'collect' || first === 'stop' || first === 'end') {
      let out = null
      let next = ''
      const ran = await withGrowthLock(ctx.from, async () => {
        await updatePlayer(ctx.db, ctx.from, pl => { out = collectSession(pl, { now: Date.now() }); next = cultivationNextStep(pl, config.prefix); return pl })
      })
      if (!ran) return ctx.reply('🧘 *One collection at a time.* _The hours are being counted._')
      return ctx.reply([...(out?.lines ?? []), next].filter(Boolean).join('\n\n'))
    }

    // ── Start ───────────────────────────────────────────────────────────────
    const cave = first === 'best'
      ? CAVES.filter(c => Number(c.minStage) <= Number(player.sect.stage || 0)).sort((a, b) => b.richness - a.richness)[0]
      : matchCave(words.join(' '))
    if (!cave) {
      return ctx.reply(`❓ *No cave called that.*\n${caveScreen(player)}`)
    }

    let out = null
    const ran = await withGrowthLock(ctx.from, async () => {
      await updatePlayer(ctx.db, ctx.from, pl => { out = startSession(pl, cave.id, { now: Date.now() }); return pl })
    })
    if (!ran) return ctx.reply('🧘 *One session at a time.* _You are already settling in somewhere._')
    if (!out?.ok) return ctx.reply((out?.lines ?? []).join('\n\n'))
    out.lines.push(`🧘 *${config.prefix}cultivate* to check progress · *${config.prefix}cultivate collect* to finish.`)
    return replyWithSectPicture(ctx, sectPicture('cave'), out.lines.join('\n\n'))
  },
}
