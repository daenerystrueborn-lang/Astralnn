// ── Multi-number setup ───────────────────────────────────────────────────
// Both WhatsApp numbers run as sockets INSIDE ONE PM2 process (main.js
// loops over config.js's `bots` array and opens one Baileys connection per
// entry) — deliberately not one PM2 process per number, because that would
// mean two Node processes both reading/writing the same db.json with no
// shared write queue between them, which is a known way to silently lose
// player data (gold/items vanishing) under concurrent writes. See the
// comment at the top of main.js and in lib/player-repo.js for the full
// explanation.
//
// To add a third number, add an entry to the `bots` array in config.js
// (with matching AUTH_FOLDER_3 / PHONE_FILE_3 / BOT_NAME_3 env vars) — no
// changes needed here, since everything still runs as this single process.
// ── WhatsApp-only ─────────────────────────────────────────────────────────
// This launches main.js, which runs the WhatsApp number(s) plus the website
// API in one process. Telegram is NOT started by main.js — its boot block was
// removed (see the note at the bottom of main.js), and main-all.js is the entry
// point that adds it back.
//
// Telegram needs no change here: main.js starts it automatically when
// TELEGRAM_TOKEN is set (startTelegramIfConfigured), on this process's own
// database — one writer, one lock, one character everywhere.
//
// Do NOT add a second PM2 app running main-telegram.js against the same
// DB_PATH: two writers on one database is the corruption lib/player-repo.js
// documents, and the lock refuses to start anyway. Two pollers on one token
// get 409 Conflict from Telegram.
module.exports = {
  apps: [
    {
      name: 'rpg-bot',
      script: 'main.js',
      interpreter: 'node',
      node_args: '--max-old-space-size=512',
      watch: false,
      autorestart: true,
      // Backstop for the case lib/memory-guard.js cannot handle: memory held
      // OUTSIDE the V8 heap (Buffers, ArrayBuffers, canvas/ffmpeg natives) can
      // grow the process past the machine's RAM while the heap still reads
      // healthy, and the kernel's OOM-killer answers with SIGKILL — no flush,
      // no log line. PM2 restarting at a set RSS is the same idea as the
      // guard's deliberate exit, just enforced from outside the process.
      //
      // Sized against the 512 MB heap ceiling: the heap plus external buffers
      // normally stays well under this. Lower it on a small box — a limit
      // above the machine's free RAM never fires, it just lets the kernel win.
      max_memory_restart: process.env.MAX_MEMORY_RESTART || '900M',
      max_restarts: 999,
      min_uptime: '10s',
      restart_delay: 5000,
      kill_timeout: 10000,
      log_date_format: 'YYYY-MM-DD HH:mm:ss',
      merge_logs: true,
      out_file: './logs/pm2-out.log',
      error_file: './logs/pm2-err.log',
      env: {
        NODE_ENV: 'production',
      },
    },
  ],
}
