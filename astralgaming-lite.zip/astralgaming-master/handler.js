import { editOwnWhatsAppText } from './lib/platform/whatsapp-edits.js'
import { logger, config } from './config.js'
import { gifSourceToVideo } from './lib/converter.js'
import { normalizeMessageContent } from '#wa'
import { dispatch, suggestCommand, getRegistry } from './lib/plugin-manager.js'
import { invertedGate } from './lib/inverted-gate.js'
import { gateCommandGate } from './lib/gate-actions.js'
import { incrementCommandCount } from './lib/server-stats.js'
import { getPlayer, savePlayer, updatePlayer, refreshPlayerFromCluster, registerPlayerIdentity } from './lib/player-repo.js'
import { resolveSenderPlayer, senderPhoneDigits, asPhoneJid } from './lib/identity-resolver.js'
import { wakeIfDue } from './lib/sleep-engine.js'
import { applyEndEventTick, END_SLEEP_MSG } from './lib/end-event.js'
import { formatTimeLeft } from './lib/time-format.js'
import { getGroupSettings, getGroupSettingsForAccess, isGroupOrBotOwnerOrMod, saveGroupSettings } from './lib/group-settings.js'
import { levelGateBlock, PRO_MIN_LEVEL } from './lib/level-gate.js'
import { isOwnerJid } from './lib/group-helpers.js'
import { getBan, unbanUser, banExpired, isBanned } from './lib/ban-repo.js'
import { isMod } from './lib/mod-repo.js'
import {
  isNightMode, shouldNotifyNight, nightNotice, isNightModeAllowed, LOCKOUT_EXEMPT_COMMANDS,
} from './lib/night-mode.js'
// Gates shared with the Discord/Telegram pipeline. They used to be defined in
// this file; keeping a copy here is how the two drifted apart five times.
import {
  isNonRpgCommand, isCollapseBlocked,
  hungerGate, bossFightGate, bossTurnTimeoutGate,
  noteDungeonActivity, refreshBossTurnClock,
  BATTLE_ALLOWED_COMMANDS,
} from './lib/platform/gates.js'
// Still importable from here: they were exported from this module before the
// move, and a caller elsewhere may still reach for them.
export { isNonRpgCommand, isCollapseBlocked }
import {
  isSectHallAllowed as hallAllows, isSectWord, isSectHallControl, isStaffControlCommand, isSectAccountCommand,
  isSectGameplayCommand, isNightCommandAllowed, sectHallRequiredLine,
} from './lib/sect-access.js'

import { getJailRecord, releasePlayer } from './lib/jail-repo.js'
import { hasOpenPurchase, handlePendingScreenshot } from './lib/pending-purchase.js'
import { hasOpenUnbanAppeal, handleUnbanFormImage } from './lib/unban-appeal.js'
import { hasPendingStoryChoice, handleStoryChoiceReply } from './plugins/story.js'
import { extractButtonReplyId } from './lib/interactive-buttons.js'
import { isPremiumActive } from './lib/premium.js'
import {
  dmAllowanceForPlayer,
  consumePremiumDmSlot,
  formatTimeUntilReset,
  PREMIUM_DM_LIMIT,
} from './lib/premium-perks.js'
import { resolveOverflowNotice, inventoryOverflow } from './lib/inventory-limits.js'
import { storageCap } from './lib/housing-engine.js'
import { getActiveSpawn } from './lib/card-spawn-state.js'
import { awardPetCommandSolars } from './lib/pet-bond.js'
import { petMap, allItems } from './lib/game-data.js'
import { runModerationScans, handleRevocation } from './lib/moderation-scan.js'
import { runAfkScan } from './lib/afk-scan.js'
// The Dreamlands' two player-state locks: a body in the ice / not yet awake, and
// a walk in progress. Both are read here because this is the one place every
// command passes through — a plugin that forgets to check cannot bypass them.
import {
  handleDreamlandsDeath, FROZEN_ALLOWED_COMMANDS, autoThawDue, immobileRefusal, isUnconscious, thawPlayer,
} from './lib/dreamlands-death.js'
import {
  needsCharacterStow, needsCharacterUnstow, reconcileDreamlandsCharacter,
} from './lib/dreamlands-characters.js'
import { applyDreamlandsIdleTick, touchDreamlandsActivity } from './lib/dreamlands-idle.js'
import { tickRealmTime } from './lib/dreamstep.js'
import { JOURNEY_ALLOWED_COMMANDS, clearStaleJourney, isJourneying, journeyLockLine } from './lib/dreamlands-journey.js'
// The mountain road into the Sect Empire: while the gatekeeper is talking, the
// character is locked into the conversation the same way a Dreamlands walk locks
// it — one small allowlist, checked here so no plugin can be reached around it.
import { ROAD_ALLOWED_COMMANDS, isOnRoad, roadLockLine } from './lib/sect-road.js'
import {
  NO_SERVICES_LINE, TOWN_ONLY_COMMANDS, isDreamlandsLocation, isFrozen,
} from './lib/dreamlands-core.js'
// The Sect Empire: the second playable world. `isInSectEmpire` answers "is this
// player over there" once, for the command lock AND for every Astra-side tick
// below, so the two can never disagree about who lives where.
import { isInSectEmpire } from './lib/worlds.js'
import {
  sectFightGate, sectGate, seclusionGate, sectTribulationGate, sectWayBackGate,
} from './lib/sect-lock.js'
// A group turned into a SECT HALL with `.sect on` (lib/sect-hall.js). Its
// word-predicate is the world lock's own allowlist, so a hall and the mountain
// can never disagree about what a sect command is.
import { sectHallLine } from './lib/sect-hall.js'
// The growth a master/student (kingdom) or sensei/student (sect) bond pays. It
// settles AFTER dispatch, once per handled command, off the student's own
// watermark — see lib/lineage-dividends.js for why it lives here and not in the
// fight engines.
import { settleLineageDividends } from './lib/lineage-dividends.js'

// Preserve the public predicate for callers that imported it from the handler.
export { isNightModeAllowed } from './lib/night-mode.js'

// Commands still reachable in a locked DM even though the sender isn't the
// owner — buying Premium/gems/Monds and checking status must work for everyone,
// not just people the owner has already DM'd first. The Mond commands and
// `.character` are here so the whole buy-a-character-with-Monds flow works in a
// DM: `.monds buy` for the currency (the plugin is DM-only by design anyway),
// `.character buy` to spend it.
//
// `.register` (and its `signup` alias) is here because registration is the ONE
// thing a person can only do before they have a record: a stranger who DMs the
// bot is met by the DM lock below, and a "DMs are closed" notice that will not
// let them sign up is a door with no handle. It was missing from this list,
// which is the first half of why `.register` in a DM used to answer nothing at
// all (the second half is the null guard in lib/premium.js isPremiumActive —
// without it the gate threw before it could even send the refusal).
//
// `.story` is the whole of Story Mode: the
// volumes are read in a DM with the bot (plugins/story.js), so the command has
// to be reachable here or the feature is unreachable, period. The unban appeal
// (plugins/unban-me.js) is exempt for the same reason in reverse — a banned
// user has nowhere else to start one.
const DM_ALLOWED_COMMANDS = new Set(['premium', 'vip', 'topup', 'gems', 'buygems', 'buysolars', 'code', 'mycode', 'linkcode', 'connectcode', 'season', 'seasons', 'seasoninfo', 'gm', 'gameshop', 'unban-me', 'unbanme', 'appeal', 'monds', 'mond', 'buymonds', 'mondshop', 'character', 'characters', 'char', 'victoria', 'story', 'story-mode', 'astral-pass', 'astralpass', 'apass', 'ap', 'elite', 'elitepass', 'buyelite', 'promo', 'promos', 'promogems', 'preorder', 'pre-order', 'register', 'signup', 'gate', 'gates', 'gateboard'])

// Commands that survive EVERY lockout gate below (ban, jail, inn sleep,
// mid-battle). `unban` so an admin/owner near a banned user can always reverse
// a ban, and the `.unban-me` appeal trio (name + aliases, see
// plugins/unban-me.js) so the person themselves has a way back in — a ban that
// blocks its own appeal route leaves the user with nothing but silence, and
// "you were banned while asleep at the inn" must not become a dead end either.
// The shared lockout and night-only spawn-claim exemptions live in
// lib/night-mode.js so WhatsApp and the other platform pipeline agree.

// How often the "your bag is over the limit" notice may repeat on a player's own
// commands while their 48h grace runs. Long enough not to be spam, short enough
// that nobody can claim they were never told before items moved.
const OVERFLOW_WARN_COOLDOWN_MS = 6 * 60 * 60_000

// Utility-command and collapse policy now live in lib/platform/gates.js, so
// WhatsApp and the Discord/Telegram pipeline cannot disagree about them.

// ── Music-only group gate ──────────────────────────────────────────────
// `.music on` (plugins/musicmode.js) turns a group into a music-listening
// room: for regular members, ONLY the music command (.song/.mp3) and the
// group-directory commands (category 'group': submit/join/leave/gclist/...)
// run — everything else is refused. Group admins/mods bypass (checked at the
// call site so the async admin lookup is only paid on a would-be block), and
// the bot owner never reaches the gate at all (isOwnerJid short-circuits it).
// Keyed off the plugin's own category so a new group command is covered here
// without editing this list. LOCKOUT_EXEMPT_COMMANDS (ban appeals) always pass.

// ── Sect-hall group gate (.sect on) ─────────────────────────────────────────
// `.sect on` (plugins/sect.js, lib/sect-hall.js) makes a group a SECT HALL:
// regular members may run ONLY the Sect Empire's words — grow, fight, work,
// sect life — and every kingdom command is refused with a reply. The predicate
// is the world lock's own allowlist (lib/sect-command-list.js), so a word that
// answers on the mountain answers in the hall, and nothing else does.
//
// Ban appeals (LOCKOUT_EXEMPT_COMMANDS) always pass, exactly as they do in
// every other gate, and so does `.register`: a stranger who joins a hall has to
// be able to make a character, or the group is a locked door for new people.
// Bot mods and the owner bypass at the call site so the hall can always be
// closed again.
export function isSectHallAllowed(cmd, platform = 'whatsapp') {
  return hallAllows(cmd, getRegistry(platform).get(cmd))
}

// ── The End: deep-sleep gate ───────────────────────────────────────────
// During the Blue Band event (lib/end-event.js) a weak, unbanded player is
// dragged into the End's deep sleep and locked out of almost everything — the
// same shape as the hunger collapse gate above. Everything on this list is the
// self-rescue path or read-only reference, so a sleeper always has a route
// back onto their feet:
//   • shop/buy — beg the old woman in Astral Town for a Blue Band
//   • answer   — answer her riddle ("no")
//   • equip    — put the band on for good once you hold one
//   • travel/enter — a WRONG answer bars her door until you leave town and
//     return, so movement MUST stay reachable or the sleeper softlocks with no
//     way to re-ask (this is the "go to a dungeon and back" mechanic itself)
// Battle commands are deliberately absent: like collapse, an inBattle player is
// exempt from the gate entirely (below) so the aura can never trap someone
// mid-fight with no way to finish or flee.
const END_SLEEP_ALLOWED_COMMANDS = new Set([
  // the way out — get a Blue Band and put it on
  'shop', 'buy', 'gm', 'gameshop',
  'answer',
  'equip', 'unequip',
  // self-rescue movement (see note above)
  'travel', 'enter',
  // read-only reference / status
  'profile', 'stats', 'stat', 'inventory', 'inv', 'balance', 'bal', 'wallet',
  'event', 'menu', 'help', 'ping',
  // escape hatch — a broken battleState must never be unfixable
  'cb', 'clearbattle', 'resetbattle', 'unstuck',
])



// Link detection lives in lib/group-helpers.js (containsLink) and is applied by
// the antilink rule in lib/moderation-scan.js. Nothing in this file needs it.

// NOTE (2026-09): the per-command auto-react (⚔️/☀️/🌙 on every command
// message) was removed on owner request. It was a decoration that doubled
// outbound traffic (a command burst = a react burst on top of the replies),
// which is how WhatsApp's spam heuristics kept reading the bot as a spammer
// — see the reaction-lane note in lib/send-rate-limiter.js. Plugins that
// react to their OWN results (downloader ✅/❌, gif2mp4, manga) still do.
// The Sun/Moon identity for the .menu banner lives in plugins/menu.js's
// instanceIdentity().

/**
 * LOCKDOWN MODE — while true, only the configured owner (via DM, not a
 * group) can run any command. Everyone else is silently ignored.
 * Currently OFF — the bot now responds to everyone / all groups.
 */
const OWNER_ONLY_MODE = false

// isOwnerJid now imported from lib/group-helpers.js (single source of truth —
// this used to be redefined separately in handler.js, group-settings.js, and
// validate.js, which is exactly how validate.js drifted out of sync and
// stopped recognizing the LID-based owner check).

/**
 * Middleware: looks up the sender in the player store and attaches the result
 * to ctx.player (null if not registered). Also wires ctx.save() so plugins
 * can persist mutations without touching the db directly.
 *
 * ── Why this resolves an identity instead of just reading ctx.from ────────
 *
 * `ctx.from` is the address WhatsApp used for THIS message: a phone jid in a
 * DM, a `@lid` id in a LID-addressed group. They are two spellings of one
 * person and share no digits (lib/identity-resolver.js), so reading
 * `db.data.users[ctx.from]` directly is what made the bot answer "you need to
 * .register first" to a registered player the moment they typed in a group.
 *
 * So: take every address the message carries (`senderIdentity`), resolve them
 * to the one key the record actually lives under (`resolvePlayerId`), and
 * remember the aliases so the next message is a single map lookup. The
 * resolved key is exposed as `ctx.playerId`; `ctx.from` deliberately keeps the
 * raw address, because it is what the protocol operations (revoke, kick,
 * mention) must keep using.
 */
async function resolvePlayer(ctx) {
  const { id: playerId, identity } = resolveSenderPlayer(ctx.db, ctx.msg)

  // Cluster read-half: make the acting player current from Mongo before we take
  // ctx.player, so a command served on THIS number reflects what another number
  // just committed (and a player who registered elsewhere becomes visible here).
  // No-op on single-VPS; best-effort so a Mongo hiccup never breaks the handler.
  // Runs against the RESOLVED key: the cluster document is keyed the same way
  // the local record is.
  await refreshPlayerFromCluster(ctx.db, playerId)
  ctx.playerId = playerId
  ctx.player = getPlayer(ctx.db, playerId)
  ctx.save = () => savePlayer(ctx.db, ctx.player)

  // One-time, best-effort: record the player's real phone number so the
  // website's OTP login can find THIS character by number instead of minting
  // a duplicate. LID-keyed accounts (see config.ownerLid) carry no phone in
  // their id at all, so without this stamp the site can't connect them — the
  // exact bug behind "logging in on the site made a new account". Only fills
  // when it's missing, so it's a no-op on every subsequent message and never
  // overwrites a number a site login already recorded.
  const phone = senderPhoneDigits(ctx)
  if (ctx.player) {
    // Bind this address to the record: the phone jid and the LID are both
    // spellings of the same person, and writing the link here (rather than
    // re-deriving it per message) is what makes the NEXT group message a
    // one-lookup hit. No write happens unless something actually changed.
    registerPlayerIdentity(ctx.db, playerId, [
      identity.phone,
      identity.lid,
      ctx.from,
      asPhoneJid(phone),
    ])

    const missing = []
    if (phone && !ctx.player.phone) missing.push(p => { p.phone = phone })
    if (identity.lid && !ctx.player.lid) missing.push(p => { p.lid = identity.lid })
    if (missing.length) {
      await updatePlayer(ctx.db, playerId, p => {
        for (const apply of missing) apply(p)
        return p
      }).catch(() => {})
    }
  }
}

/**
 * Returns a Baileys `messages.upsert` handler bound to `sock`.
 *
 * Responsibility: raw Baileys event → normalised ctx → plugin dispatch.
 * No command logic lives here.
 */
export function makeHandler(sock, db, botName) {
  return async function handleMessage({ messages, type }) {
    // 'notify' is a genuinely new inbound message. 'append' is normally
    // history sync / own-message echo from other devices — BUT Baileys also
    // uses 'append' for some live one-on-one DMs depending on account/LID
    // addressing, so filtering it out here silently ate real incoming DMs:
    // no log line above debug, no reply, indistinguishable from the bot
    // being offline. We no longer drop by type. Instead we rely on the
    // existing `msg.key.fromMe` check below to skip echoes of our own
    // messages. Logged at debug, not info — like the per-command trail
    // below, this fires on ordinary traffic and is pure noise at
    // LOG_LEVEL=info; flip to debug to get it back when actually chasing
    // a delivery-shape issue.
    if (type !== 'notify') {
      logger.debug({ type, count: messages?.length ?? 0 }, 'Non-notify upsert (processing anyway)')
    }

    for (const msg of messages) {
      // Per-message guard. Without it, one throw anywhere below rejects the
      // whole handleMessage promise: Baileys has no error handling on this
      // event, so the rest of the batch is dropped and nothing is logged.
      // Every message now fails independently, loudly, and in isolation.
      try {
        await handleOne(msg)
      } catch (err) {
        logger.error({
          err: err.message,
          stack: err.stack,
          jid: msg?.key?.remoteJid,
        }, 'Unhandled error while processing message')
      }
    }

    async function handleOne(msg) {
      // Ignore empty or own messages
      if (!msg.message || msg.key.fromMe) return

      // Extract plain text from common message types.
      //
      // normalizeMessageContent() first: a group with DISAPPEARING MESSAGES on
      // delivers every message wrapped as ephemeralMessage.message.<real type>,
      // and view-once/edited messages nest the same way. Reading msg.message
      // directly found only the wrapper, so body was '' for ordinary text —
      // no command in such a group ever matched the prefix, and antispam saw
      // nothing to measure. Unwrapping is what makes the bot work there.
      const content = normalizeMessageContent(msg.message) ?? msg.message
      const buttonReplyId = extractButtonReplyId(content)
      const body =
        content.conversation ||
        content.extendedTextMessage?.text ||
        content.imageMessage?.caption ||
        content.videoMessage?.caption ||
        buttonReplyId ||
        ''

      // Diagnostic: a button tap that extractButtonReplyId() couldn't parse
      // into an id logs the raw shape here instead of vanishing silently —
      // "the bot reacts (delivery receipt) but never runs the command" is
      // otherwise undebuggable, since nothing downstream of this line even
      // sees the message once body stays ''. Only fires for the specific
      // known reply-message keys, so it never fires on ordinary text/media.
      const looksLikeButtonReply =
        content?.interactiveResponseMessage || content?.buttonsResponseMessage || content?.listResponseMessage
      if (looksLikeButtonReply && !buttonReplyId) {
        logger.warn({ contentKeys: Object.keys(content ?? {}), raw: content }, 'Button tap received but id could not be extracted')
      }

      const sender = msg.key.remoteJid          // group or DM jid
      const isGroup = sender.endsWith('@g.us')
      const from = isGroup
        ? (msg.key.participant ?? sender)       // individual member in group
        : sender

      // Every inbound DM is logged with its RAW jid before any gate runs —
      // at debug, not info, same reasoning as the per-command trail further
      // down: one line per DM is noise in production and buries real
      // errors. Set LOG_LEVEL=debug when actually chasing "the bot doesn't
      // respond to anything in DM" — this proves whether the message
      // reached the handler at all, and exposes the addressing WhatsApp
      // actually used. If `sender` here ends in @lid rather than
      // @s.whatsapp.net, this account is on WhatsApp's LID addressing and
      // that is the thing to chase — player records keyed by phone jid
      // won't match, and sends may not route.
      if (!isGroup) {
        logger.debug({
          rawJid: sender,
          server: sender.replace(/^.*@/, '@'),
          senderPn: msg.key.senderPn ?? null,   // phone number, when LID is in use
          bodyPreview: body.slice(0, 40),
        }, 'DM received')
      }

      // ── Owner-only lockdown ──────────────────────────────────────────────
      // While OWNER_ONLY_MODE is on, silently drop everything except a DM
      // from the configured owner. No reply is sent to non-owners — this is
      // intentional so the bot doesn't reveal it's running/gated to anyone
      // probing it. Antilink is a bot behavior too, so it stays gated by
      // this exact same check rather than getting a bypass.
      if (OWNER_ONLY_MODE && !(!isGroup && isOwnerJid(from))) {
        return
      }

      // ── Antidelete: message-revoke events ───────────────────────────────
      // A deletion arrives as a protocolMessage, not as text, so it has to be
      // handled before anything that assumes `body` is meaningful. Consumes
      // the event either way — a revoke is never a command.
      if (msg.message?.protocolMessage) {
        await handleRevocation(sock, msg).catch(err =>
          logger.warn({ err: err.message, jid: sender }, 'Antidelete: revoke handling failed'))
        return
      }

      // ── Moderation scans ────────────────────────────────────────────────
      // antilink, grouplock, mute, antispam, antichannel, antistatus + the
      // antidelete capture. Runs before the prefix check because none of these
      // arrive as commands — they're ordinary messages. Returns true when it
      // consumed the message (deleted it / removed the sender), in which case
      // there is nothing left to dispatch.
      //
      // Antilink used to be a separate inline block right here, with its own
      // copy of the owner/admin checks. It now lives in the scan alongside the
      // other destructive rules — which fixed the admin exemption (the inline
      // copy compared `pt.id === from` only, so in any group whose addressing
      // mode differed from the incoming jid it kicked genuine admins), and got
      // it caption and disappearing-message coverage for free.
      //
      // Wrapped so a moderation failure can never stop a normal message from
      // being handled: a broken scan must degrade to "moderation is off", not
      // to "the bot stopped responding".
      try {
        if (await runModerationScans({ sock, db, msg, sender, from, body, isGroup })) return
      } catch (err) {
        logger.warn({ err: err.message, jid: sender }, 'Moderation scan failed')
      }

      // ── AFK ─────────────────────────────────────────────────────────────
      // Clears the sender's own AFK and answers for anyone they tagged.
      // Deliberately never consumes the message — an AFK player's command
      // still runs, and tagging someone away is still a normal message.
      // Fire-and-forget so a slow send can't delay the actual command.
      runAfkScan({ sock, msg, sender, from, body }).catch(err =>
        logger.warn({ err: err.message }, 'AFK scan failed'))

      // ── Unban-appeal form bypass ──────────────────────────────────────────
      // Same reason this sits above the prefix check as the screenshot hook: a
      // photo of the filled-in unban form carries no command. DM-only, and MUST
      // run BEFORE the pending-purchase screenshot bypass below — a banned
      // player who also has an old unclosed purchase on their record
      // (`mondPending` / `topupPending` / `premiumPending` / `seasonOfferPending`)
      // would otherwise have their unban form hijacked as "Another screenshot
      // for the same purchase" and forwarded to the owner with `.monds confirm`
      // instead of reaching the mod team as an unban appeal. Reads the
      // NORMALIZED content so a disappearing-messages or view-once wrapper
      // doesn't hide the image — Baileys' downloadMediaMessage unwraps the same
      // way, so the raw msg is still what gets downloaded.
      if (!isGroup && content.imageMessage && hasOpenUnbanAppeal(db, from)) {
        const appealCtx = {
          sock, db, msg, sender, from, isGroup,
          reply: (text) => sock.sendMessage(sender, { text: String(text) }, { quoted: msg }),
        }
        const consumed = await handleUnbanFormImage(appealCtx).catch(err => {
          logger.warn({ err: err.message, jid: from }, 'Unban appeal form handler failed')
          return false
        })
        if (consumed) return
      }

      // ── Pending-purchase screenshot bypass ────────────────────────────────
      // Must run before the "must start with a command prefix" bail-out
      // below — a payment screenshot has no prefix at all. DM-only: group
      // images are never treated as purchase confirmations, and banned accounts
      // never enter this flow. Shared by every Naira flow (premium/topup/monds/
      // season offer, see lib/pending-purchase.js) so there is one image hook,
      // not four.
      //
      // Gated on hasOpenPurchase rather than hasAwaitingScreenshot: once a
      // receipt is in, the state flips and a NARROW gate stops intercepting —
      // so a buyer re-sending a screenshot the owner said was unreadable got no
      // reply and no forward, and both sides believed the other was stalling.
      if (!isGroup && content.imageMessage && !isBanned(db, from)) {
        const maybePlayer = getPlayer(db, from)
        if (hasOpenPurchase(maybePlayer)) {
          const screenshotCtx = {
            sock, db, msg, sender, from, isGroup,
            reply: (text) => sock.sendMessage(sender, { text: String(text) }, { quoted: msg }),
          }
          const consumed = await handlePendingScreenshot(screenshotCtx, maybePlayer).catch(err => {
            logger.warn({ err: err.message }, 'Screenshot handler failed')
            return false
          })
          if (consumed) return
        }
      }

      // ── Story Mode choice-reply bypass ─────────────────────────────────────
      // Must also run before the prefix check — a choice reply is a bare "1",
      // "2", or "3" with no prefix. DM-only, same as Story Mode itself: a
      // story is read in a private DM with the bot, so a plain number typed
      // in a group is never interpreted as a story answer and is handled as
      // an ordinary message there. Only fires when the player actually has a
      // choice beat pending (hasPendingStoryChoice — see plugins/story.js),
      // which is a fact about that player's own save, and a DM is only ever
      // that player's conversation. Prefixed commands skip this entirely, so
      // mid-chapter `.premium`/`.monds`/`.story` still work.
      //
      // Banned accounts are excluded, the same way the screenshot hook above
      // excludes them: this gate sits above the ban lockout, so without it a
      // banned reader's pending choice would keep resolving and playing beats
      // (and granting the chapter rewards) right through their own ban.
      if (!isGroup && !isBanned(db, from) && body && !body.startsWith(config.prefix)) {
        const maybePlayer = getPlayer(db, from)
        if (hasPendingStoryChoice(maybePlayer)) {
          const storyCtx = {
            sock, db, msg, sender, from, isGroup,
            reply: (text) => sock.sendMessage(sender, { text: String(text) }, { quoted: msg }),
          }
          const consumed = await handleStoryChoiceReply(storyCtx, maybePlayer, body).catch(err => {
            logger.warn({ err: err.message }, 'Story choice handler failed')
            return false
          })
          if (consumed) return
        }
      }

      // ── DM lock ─────────────────────────────────────────────────────────
      // DMs are closed to everyone except the bot owner and the commands in
      // DM_ALLOWED_COMMANDS above (premium/vip/topup status + buy flows and
      // Story Mode must stay reachable for anyone). ACTIVE PREMIUM HOLDERS
      // GET A WIDER DOOR: most commands work in DMs, capped at
      // PREMIUM_DM_LIMIT (50) non-whitelisted commands per calendar day
      // (lib/premium-perks.js), consumed after resolvePlayer() once we know
      // the command actually ran. Sect gameplay still needs a group with
      // .sect on, independent of the Premium DM allowance. Whitelisted commands stay
      // free for everyone and never burn a premium slot (buying Premium,
      // reading Story Mode, etc. must always work).
      let dmPlayerPreview = null
      if (!isGroup && !isOwnerJid(from)) {
        const bodyAfterPrefix = body.startsWith(config.prefix) ? body.slice(config.prefix.length).trim() : ''
        const firstWord = bodyAfterPrefix.split(/\s+/)[0]?.toLowerCase()
        if (!DM_ALLOWED_COMMANDS.has(firstWord)) {
          // Lightweight player preview for the DM gate: we only need to know
          // if this sender is premium to decide whether to let them past.
          // resolvePlayer() does the full identity bind + cluster refresh
          // and runs below regardless, so we don't duplicate that work —
          // this is just enough state to answer the gate. Wrapped in try
          // because a malformed identity packet should not crash the DM gate.
          try {
            const { id: pid } = resolveSenderPlayer(db, msg)
            if (pid) dmPlayerPreview = getPlayer(db, pid)
          } catch {
            dmPlayerPreview = null
          }
          const allowance = dmAllowanceForPlayer(dmPlayerPreview)
          if (!allowance.isPremium || allowance.allowed <= 0) {
            let dmClosedText
            if (allowance.isPremium && allowance.allowed <= 0) {
              dmClosedText =
                `🔒 *You've used all ${PREMIUM_DM_LIMIT} DM commands today.*\n\n` +
                `Whitelisted DM commands (${config.prefix}premium, ${config.prefix}topup, ${config.prefix}story, ${config.prefix}preorder, etc.) still work, and your cap resets in *${formatTimeUntilReset(allowance.resetAt)}*.`
            } else {
              dmClosedText =
                `🔒 DMs are closed. Use *${config.prefix}register* to make your character (it works right here), *${config.prefix}premium*, *${config.prefix}topup*, *${config.prefix}promo*, *${config.prefix}elite*, *${config.prefix}preorder*, *${config.prefix}season offer*, or *${config.prefix}story* for Story Mode here, or head to a group to play.\n\n` +
                `👑 *Premium unlocks more commands in DMs* — ${PREMIUM_DM_LIMIT} commands a day, no spam timeouts, early character pre-orders, and more. Sect gameplay still needs a group with *${config.prefix}sect on*. DM *${config.prefix}premium buy <plan>* to get it.`
            }
            // Logged, not swallowed. This send used to end in `.catch(() => {})`,
            // so if the "DMs are closed" notice itself failed to deliver the
            // outcome was total silence — indistinguishable from the bot being
            // offline or ignoring the person, and invisible in the logs.
            await sock.sendMessage(sender, { text: dmClosedText }, { quoted: msg }).catch(err =>
              logger.warn({ err: err.message, jid: sender }, 'DM-closed notice failed to send'))
            return
          }
        }
      }

      if (!body.startsWith(config.prefix)) return

      const [rawCmd, ...args] = body
        .slice(config.prefix.length)
        .trim()
        .split(/\s+/)
      const cmd = rawCmd.toLowerCase()

      // ── Night mode lockout ───────────────────────────────────────────────
      // Appeals and existing spawn claims survive; bans/jail still apply below.
      // Sect gameplay is the one night-time play exception: an active Premium
      // player in the Sect Empire, in THIS group's enabled hall. Staff retain
      // their administrative controls, but are not exempt when playing Sect.
      // Resolve the individual (including a LID/phone alias), not the group JID;
      // ctx.player is not available until the later resolvePlayer() call.
      if (isNightMode()) {
        const plugin = getRegistry('whatsapp').get(cmd)
        const owner = isOwnerJid(from)
        let staff = isOwnerJid(from) || isMod(db, from)
        let player = null
        let groupSettings = null
        if (!isNightModeAllowed(cmd) && isSectWord(cmd, plugin) && !(staff && isSectHallControl(cmd, args, plugin))) {
          try {
            const { id } = resolveSenderPlayer(db, msg)
            const cachedPlayer = getPlayer(db, id)
            player = await refreshPlayerFromCluster(db, id, { requireFresh: true })
            // A deleted remote account is not an unregistered staff member;
            // do not authorize gameplay from its stale local record.
            if (!player && cachedPlayer) staff = false
          } catch (err) {
            // An unresolved account cannot receive a night-time exception.
            // Do not turn a failed read into a staff gameplay bypass either.
            staff = false
            logger.warn({ err: err.message, jid: from }, 'Night Sect player lookup failed')
          }
          if (isGroup && isInSectEmpire(player) && isPremiumActive(player)) {
            try {
              groupSettings = await getGroupSettingsForAccess(sender)
            } catch (err) {
              logger.warn({ err: err.message, jid: sender }, 'Night Sect hall lookup failed')
            }
          }
        }
        if (!isNightCommandAllowed({ player, cmd, args, plugin, isGroup, groupSettings, staff, isOwner: owner && staff })) {
          // Throttled per individual so a busy group is not flooded all night.
          if (shouldNotifyNight(from)) {
            await sock.sendMessage(sender, { text: nightNotice(config.prefix) }, { quoted: msg })
              .catch(() => {})
          }
          return
        }
      }

      // ── Ban lockout ──────────────────────────────────────────────────────
      // Banned accounts cannot run ANY command — including .register, so a
      // ban can't be dodged by wiping and re-registering. Checked by JID
      // (ctx.from), independent of the player record, so it also blocks
      // someone who was banned before ever registering. LOCKOUT_EXEMPT_COMMANDS
      // stays reachable: .unban so an admin/owner can always reverse it (the
      // unban plugin re-checks permissions itself, so a banned non-admin
      // typing it gets nowhere), and .unban-me so the banned person can start
      // an appeal — the notice below points them at it.
      const ban = getBan(db, from)
      if (ban && !LOCKOUT_EXEMPT_COMMANDS.has(cmd)) {
        if (banExpired(ban)) {
          // A timed ban (antispam auto-ban) whose time is up: clean up the
          // stale record and let the command through — exactly the shape of
          // the jail auto-release just below.
          await unbanUser(db, from)
          if (ban.auto) {
            sock.sendMessage(sender, {
              text: `✅ *Your spam timeout is over — you can use the bot again.* Keep it slower this time.`,
            }, { quoted: msg }).catch(() => {})
          }
        } else if (ban.expiresAt != null) {
          // Temporary ban still in force. No appeal-form CTA: it lifts itself
          // shortly, and only the owner or a mod can shorten it (plugins/unban.js).
          const minsLeft = Math.max(1, Math.ceil((ban.expiresAt - Date.now()) / 60000))
          await sock.sendMessage(sender, {
            text:
              `🚫 *You're timed out for spamming and can't use the bot.*\n\n` +
              `Time left: *${minsLeft} min*.` +
              (ban.reason ? `\nReason: _${ban.reason}_` : '') +
              `\n\n_It lifts on its own — only the bot owner or a mod can undo it sooner._`,
          }, { quoted: msg }).catch(() => {})
          return
        } else {
          const bannedAt = new Date(ban.bannedAt).toLocaleString()
          const byLabel  = ban.bannedBy ? `@${ban.bannedBy.replace(/@.*$/, '')}` : 'an admin'
          await sock.sendMessage(sender, {
            text:
              `🚫 *You are banned and cannot use this bot.*\n\n` +
              `Banned: *${bannedAt}*\n` +
              `By: ${byLabel}` +
              (ban.reason ? `\nReason: _${ban.reason}_` : '') +
              `\n\n📩 *Want it undone?* DM me *${config.prefix}unban-me* — ` +
              `I'll send you the unban form to fill in and send back, and the mod ` +
              `team reviews it from there.`,
            mentions: ban.bannedBy ? [ban.bannedBy] : [],
          }, { quoted: msg }).catch(() => {})
          return
        }
      }

      // ── Jail lockout ─────────────────────────────────────────────────────
      // Jail is a temporary full-lockout (same chokepoint as ban) — no commands
      // work while a sentence is active. Self-expires when releaseAt passes;
      // on the first command after expiry the record is cleaned up and a
      // release message is sent, then the command runs normally.
      // LOCKOUT_EXEMPT_COMMANDS pass through untouched, so someone who is both
      // jailed and banned can still file an appeal (their release just gets
      // announced on their next ordinary command instead).
      const jailRec = getJailRecord(db, from)
      if (jailRec && !LOCKOUT_EXEMPT_COMMANDS.has(cmd)) {
        if (Date.now() < jailRec.releaseAt) {
          const minsLeft = Math.ceil((jailRec.releaseAt - Date.now()) / 60000)
          await sock.sendMessage(sender, {
            text:
              `🔒 *You're locked up${jailRec.crime ? ` for ${jailRec.crime}` : ''}.*\n\n` +
              `Time left: *${minsLeft} min* on your sentence.\n` +
              `_Sit tight — you can't run commands from a cell._`,
          }, { quoted: msg }).catch(() => {})
          return
        } else {
          // Sentence served — clean up the record and let this command through
          await releasePlayer(db, from)
          sock.sendMessage(sender, {
            text:
              `🔓 *You've served your time and walked free.*\n\n` +
              `The cell door creaks open and morning light hits your face.\n` +
              `_Try not to make it a habit._`,
          }, { quoted: msg }).catch(() => {})
        }
      }

      /** ctx passed to every plugin */
      const ctx = {
        sock,
        db,
        // Every ctx must name its platform. The registry is SHARED across
        // WhatsApp/Discord/Telegram in combined mode, so this is what lets
        // .menu and dispatch() hide commands that belong to another platform.
        platform: 'whatsapp',
        botName,    // display name of THIS number's bot instance — see main.js
        msg,
        sender,     // jid of the chat (group or DM)
        from,       // jid of the actual sender, exactly as WhatsApp addressed it
        // Canonical storage identity for this sender (resolvePlayer): the key
        // the player record actually lives under, which is the same whether
        // the message came from a DM (phone jid) or a LID-addressed group
        // (@lid). `from` stays the raw address for protocol operations.
        playerId: null,   // filled in by resolvePlayer() below
        isGroup,
        cmd,
        args,
        body,
        reply: (text) =>
          sock.sendMessage(sender, { text: String(text) }, { quoted: msg })
            .catch(err => {
              // Never swallow a failed reply. Plugins call ctx.reply() and
              // mostly don't await the result, so a rejection here surfaces
              // nowhere — the command runs, the state changes, and the user
              // just sees nothing come back. Rethrow after logging so the
              // per-message guard records it too.
              if (err?.code === 'ERR_SEND_STALE') {
                logger.warn({ err: err.message, jid: sender, cmd }, 'ctx.reply timed out in rate-limiter queue')
              } else {
                logger.error({ err: err.message, jid: sender, cmd }, 'ctx.reply failed to send')
              }
              throw err
            }),
        // Cinematic edits must target our own message in this chat only.
        // Baileys returns a WAMessage from ctx.reply; preserve its full key.
        editReply: (sent, text) => editOwnWhatsAppText(sock, sender, sent, text),
        replyImage: (image, caption = '') =>
          sock.sendMessage(
            sender,
            {
              image: Buffer.isBuffer(image) ? image : { url: image },
              caption: String(caption),
            },
            { quoted: msg },
          ),
        /**
         * replyGif — sends a TRUE autoplaying/looping GIF. WhatsApp has no
         * native animated-image message type; an animated GIF is sent as a
         * video message with gifPlayback: true (Baileys/WhatsApp's actual
         * mechanism for this — confirmed against Baileys' message-type
         * docs). Using replyImage's { image: { url } } shape for a .gif URL
         * instead sends it as a STATIC photo — first frame only, no
         * animation — which is the bug this method exists to avoid.
         * image can be a remote http(s) URL or a Buffer, same convention
         * as replyImage.
         */
        replyGif: async (image, caption = '') => {
          // A raw .gif can't be sent straight as a WhatsApp video — Baileys
          // needs a real MP4 container. So transcode gifs (a .gif URL, or a
          // raw-gif Buffer) to MP4 first, cached. A non-gif URL (e.g. a
          // pre-converted .mp4, the recommended way to host character art) is
          // already a real video — loop it directly. On transcode failure
          // (ffmpeg missing, fetch error), fall back to a static still frame
          // rather than a video WhatsApp silently drops.
          if (typeof image === 'string' && !/\.gif(\?|$)/i.test(image)) {
            return sock.sendMessage(
              sender,
              { video: { url: image }, gifPlayback: true, caption: String(caption) },
              { quoted: msg },
            )
          }
          try {
            const mp4 = await gifSourceToVideo(image)
            return await sock.sendMessage(
              sender,
              { video: mp4, gifPlayback: true, caption: String(caption) },
              { quoted: msg },
            )
          } catch {
            return sock.sendMessage(
              sender,
              { image: Buffer.isBuffer(image) ? image : { url: image }, caption: String(caption) },
              { quoted: msg },
            )
          }
        },
        /**
         * replyCard — sends a WhatsApp "external ad reply" link-preview card:
         * a thumbnail image, bold title, description line, and a source URL,
         * attached above the given text. This is the card style used by
         * other Tensura-style bots (e.g. their "Daily Rewards" / "Shop" cards
         * that link to their companion site) — WhatsApp renders whatever
         * title/body/thumbnail/url it's handed, it doesn't have to actually
         * scrape a live page.
         *
         * Usage:
         *   await ctx.replyCard({
         *     text: '🎉 You claimed your daily reward...',
         *     title: 'Astral Daily Rewards',
         *     body: 'Maintain your streak and claim exclusive rewards!',
         *     thumbnailUrl: 'https://example.com/banner.jpg', // or a local images/ filename
         *     sourceUrl: 'https://example.com/daily',          // optional, shown as the link line
         *   })
         *
         * thumbnailUrl accepts either a full http(s) URL or a filename inside
         * ./images/ (resolved via lib/image.js's resolveImageSource so this
         * matches replyImage's local-file convention). If thumbnailUrl is
         * omitted entirely, WhatsApp still renders the title/body/link line
         * without a picture.
         */
        replyCard: ({ text = '', title = '', body = '', thumbnailUrl, sourceUrl, largeThumbnail = true }) =>
          sock.sendMessage(
            sender,
            {
              text: String(text),
              contextInfo: {
                externalAdReply: {
                  title: String(title),
                  body: String(body),
                  ...(thumbnailUrl ? { thumbnailUrl: resolveCardThumbnail(thumbnailUrl) } : {}),
                  ...(sourceUrl ? { sourceUrl: String(sourceUrl) } : {}),
                  mediaType: 1,
                  renderLargerThumbnail: !!largeThumbnail,
                  showAdAttribution: false,
                },
              },
            },
            { quoted: msg },
          ),
      }

      await resolvePlayer(ctx)

      // ── Dungeon idle clock: this command is a sign of life ───────────────
      // Shared with the Discord/Telegram pipeline (lib/platform/gates.js). It
      // sits here, ahead of every gate below, because several of them answer
      // the command themselves and return (the gate pillar, the Inverted
      // Dimension, the mid-battle filter), and a player whose commands are
      // being answered is not idle. It also no longer cares which chat this
      // is: the slot may be held in another group, or the player may be
      // typing in a DM. The old touch ran after dispatch, in groups only, for
      // a slot in THIS group only.
      noteDungeonActivity(ctx)

      // ── The Sect Empire: is the Astra side switched off for this player? ──
      // One read, taken once per command, before every tick below. While a
      // player is in the Sect Empire NOTHING from the kingdom reaches them:
      // the inn's clock, hunger, the End's aura, the Dreamlands' cold, the
      // bag overflow notice, pet income. Their Astral record is frozen exactly
      // as they left it, which is what keeps the two profiles separate.
      const sectSide = isInSectEmpire(ctx.player)
      const sectPlugin = getRegistry(ctx.platform).get(cmd)
      const staff = isOwnerJid(ctx.from) || isMod(db, ctx.from)
      let currentGroupSettings = null
      let sectGroupSettings = null
      if (ctx.isGroup) {
        try {
          currentGroupSettings = await getGroupSettings(ctx.sender)
          // The ordinary group gates may use their last known-good settings,
          // but stale settings must not authorize Sect gameplay.
          sectGroupSettings = await getGroupSettingsForAccess(ctx.sender)
        } catch (err) {
          logger.warn({ err: err.message, jid: ctx.sender }, 'Sect hall lookup failed')
        }
      }

      // Recheck against the fully resolved, cluster-refreshed player and the
      // current group flag. This also catches night being enabled while this
      // message was being processed, or Premium expiring between the gates.
      if (isNightMode() && !isNightCommandAllowed({
        player: ctx.player, cmd, args, plugin: sectPlugin, isGroup: ctx.isGroup,
        groupSettings: sectGroupSettings, staff, isOwner: isOwnerJid(ctx.from),
      })) {
        if (shouldNotifyNight(from)) await ctx.reply(nightNotice(config.prefix)).catch(() => {})
        return
      }

      // The inverse of the hall's sect-only filter: Sect gameplay cannot run
      // in an ordinary group or DM just because SOME OTHER group enabled it.
      // Read-only help/contact, setup, and the daytime road back to Astra are
      // kept reachable; shared Astra commands remain unchanged for Astra players.
      if (isSectGameplayCommand({ player: ctx.player, cmd, args, plugin: sectPlugin }) &&
          !(ctx.isGroup && sectGroupSettings?.sectOnly === true)) {
        await ctx.reply(sectHallRequiredLine(config.prefix)).catch(() => {})
        return
      }

      // ── Group command gates: premium-only, music-only, and sect-only ────
      // One settings read serves all three. The owner can always moderate, and
      // mods bypass these room gates ONLY when running moderation/setup controls
      // (never to play Astra commands inside a Sect hall or farm in Noob rooms).
      if (ctx.isGroup && !isOwnerJid(ctx.from)) {
        const groupSettings = currentGroupSettings ?? {}
        const modRunningControl = isMod(db, ctx.from) && isStaffControlCommand(cmd, args, sectPlugin)

        // Per-message removal of non-premium members is handled separately by
        // the periodic premium-group sweep in main.js.
        if (groupSettings.premiumOnly && !isPremiumActive(ctx.player) && !modRunningControl) {
          await ctx.reply(
            `🔒 This group is *Premium-only*. Get Premium with *${config.prefix}premium buy <plan>* (DM me), then try again.`,
          ).catch(() => {})
          return
        }

        // Clear legacy musicOnly flags left over from retired music mode so
        // groups that once ran `.music on` are never stranded.
        if (groupSettings.musicOnly) {
          saveGroupSettings(from, s => { s.musicOnly = false }).catch(() => {})
        }

        // Sect hall (.sect on) — only the Sect Empire's words answer here for
        // regular members; mods bypass ONLY for moderation/hall control commands.
        if (
          groupSettings.sectOnly &&
          !hallAllows(cmd, sectPlugin) &&
          !modRunningControl
        ) {
          await ctx.reply(sectHallLine(config.prefix)).catch(() => {})
          return
        }

        // Level gates (.pro on / .noob on) — a pro group answers only level
        // 100+, a noob group only below 100. Mods bypass ONLY for moderation
        // and setup controls, never to farm gameplay inside a restricted room.
        const levelBlock = levelGateBlock(groupSettings, ctx.player?.level)
        if (levelBlock && !modRunningControl) {
          await ctx.reply(
            levelBlock === 'pro'
              ? `🏆 This group is *Pro-only*.\nOnly players at *level ${PRO_MIN_LEVEL}+* can use commands here — you are level ${Math.max(0, Math.floor(Number(ctx.player?.level) || 0))}.\n_Level up, or play in another group meanwhile._`
              : `🐣 This group is *Noob-only*.\nOnly players below *level ${PRO_MIN_LEVEL}* can use commands here — you are level ${Math.max(0, Math.floor(Number(ctx.player?.level) || 0))}.\n_This room is for newer players; your commands still work everywhere else._`,
          ).catch(() => {})
          return
        }
      }

      // Owner recovery must run before sleep/battle gates and automatic loss,
      // hunger or inventory ticks. The plugin repeats the owner check.
      if (cmd === 'cb-state' && isOwnerJid(ctx.from)) {
        incrementCommandCount()
        await dispatch(cmd, ctx)
        return
      }

      // Inn sleep lockout — asleep players cannot run ANY command until
      // their sleep duration elapses. Waking is automatic: the first
      // message sent after sleepUntil has passed triggers the wake-up
      // (full stamina/HP/MP restore) and that message is otherwise
      // consumed just to trigger it — the player must send their real
      // command again once awake.
      //
      // The check-and-mutate happens inside updatePlayer's read→mutate→write
      // cycle (like every other stateful mutation in this bot) instead of
      // reading ctx.player once and saving it back later, which would race
      // against any other command touching the same player concurrently.
      //
      // LOCKOUT_EXEMPT_COMMANDS skip this entirely (they also skip the
      // auto-wake, which simply happens on the next ordinary command): being
      // asleep at the inn must not swallow a ban appeal or an admin's .unban.
      //
      // Utility commands skip it for the same reason and in the same way (see
      // isNonRpgCommand): your character being asleep is not a reason `.song`
      // can't fetch a track. The message above said "All commands are locked",
      // and it meant it — literally every one of the ~208 commands, including
      // the ones that never touch your character at all.
      if (ctx.player && !sectSide && !LOCKOUT_EXEMPT_COMMANDS.has(cmd) && !isNonRpgCommand(cmd)) {
        let stillAsleep = false
        let justWoke    = false
        let wakeAt      = null

        await updatePlayer(ctx.db, ctx.from, fresh => {
          if (fresh.sleepUntil == null) return fresh
          if (Date.now() < fresh.sleepUntil) {
            stillAsleep = true
            wakeAt = fresh.sleepUntil
            return fresh
          }
          justWoke = wakeIfDue(fresh)
          return fresh
        })

        ctx.player = getPlayer(ctx.db, ctx.from)

        if (stillAsleep) {
          await ctx.reply(
            `😴 *${ctx.player.name}* is fast asleep at the inn.\n` +
            `All commands are locked — you'll wake up in *${formatTimeLeft(wakeAt - Date.now())}*.`,
          ).catch(() => {})
          return
        }
        if (justWoke) {
          await ctx.reply(
            `☀️ *${ctx.player.name}* wakes up feeling fully rested!\n` +
            `❤️ HP ${ctx.player.maxHp}/${ctx.player.maxHp}  💧 MP ${ctx.player.maxMp}/${ctx.player.maxMp}  ` +
            `⚡ Stamina ${ctx.player.stamina?.current ?? '?'}/${ctx.player.stamina?.max ?? '?'}`,
          ).catch(() => {})
          return
        }
      }

      // ── Hunger tick ──────────────────────────────────────────────────────
      // Hunger drains by real elapsed time, applied lazily here on every
      // command — no background timer, the same "bake elapsed time on read"
      // trick the sleep block above and home crops use. Runs even mid-battle.
      // Starvation NEVER kills and never touches HP; it bleeds stamina, and a
      // player drained to 0 stamina COLLAPSES (gated just below). Silent unless
      // a throttled "you're starving" warning is due — a merely-hungry player
      // is never messaged. See lib/hunger-engine.js.
      //
      // Skipped wholesale on utility commands (isNonRpgCommand). Two reasons:
      // the "you're starving!" warning has no business interrupting `.song`, and
      // maybeWarn() BURNS its once-per-cooldown budget the moment it fires — so
      // merely suppressing the reply would silently eat the warning the player
      // was owed on their next real command. Skipping the tick instead is free:
      // it is purely lastTick-elapsed-time based and slices long gaps itself
      // (msToEmpty/starvingMs), so the next RPG command bakes an identical
      // result from the wider gap. Nothing decays slower, it just decays later.
      // Hunger tick + collapse — shared with every platform, so a Telegram
      // player starves on exactly the same clock as a WhatsApp one.
      if (await hungerGate(ctx, cmd, { skip: sectSide, isNonRpg: isNonRpgCommand(cmd) })) return

      // ── The End: aura tick + deep-sleep gate ──────────────────────────────
      // The Blue Band event (lib/end-event.js). Like the hunger tick above, we
      // bake the effect on read: applyEndEventTick refreshes player.endWeakened
      // (the cached boolean getEffectiveStat multiplies every stat by) and
      // reports whether the aura has dragged this player into its deep sleep.
      // When the event is off — or the moment the End is killed server-wide —
      // the tick clears the flag on the next command with no special-casing
      // here, because every predicate keys off the single global event flag.
      //
      // The sleep lockout mirrors the hunger collapse gate exactly: a sleeping
      // player is frozen out of everything except END_SLEEP_ALLOWED_COMMANDS
      // (the self-rescue path), inBattle is exempt so the aura can't trap a
      // player mid-fight, and LOCKOUT_EXEMPT_COMMANDS (ban appeals) pass through.
      // So do utility commands — the End's aura is on your character, not on the
      // YouTube downloader.
      //
      // The tick itself still runs on every command, unlike the hunger tick
      // above: it refreshes the cached `endWeakened` flag that getEffectiveStat
      // multiplies by, it has no throttled warning to burn, and leaving that
      // flag stale would mean stats read wrong for whoever looks next.
      if (ctx.player && !sectSide) {
        let endAsleep = false
        await updatePlayer(ctx.db, ctx.from, fresh => {
          endAsleep = applyEndEventTick(ctx.db, fresh, Date.now()).asleep
          return fresh
        })
        ctx.player = getPlayer(ctx.db, ctx.from)

        if (
          endAsleep &&
          !ctx.player.inBattle &&
          !END_SLEEP_ALLOWED_COMMANDS.has(cmd) &&
          !LOCKOUT_EXEMPT_COMMANDS.has(cmd) &&
          !isNonRpgCommand(cmd)
        ) {
          await ctx.reply(END_SLEEP_MSG.replaceAll('{prefix}', config.prefix)).catch(() => {})
          return
        }
      }

      // ── Boss turn timeout — shared (lib/platform/gates.js) ───────────────
      // The only exit from a boss fight now that `.cb` is blocked mid-boss, so
      // it must run everywhere or a player who walks away is stuck forever.
      if (ctx.player && !sectSide && await bossTurnTimeoutGate(ctx)) return

      // ── The Dreamlands: no services past the door (§3.3) ─────────────────
      // Past the portal there is no shop, no inn, no bank, no stall: whatever a
      // command needs a town for, it does not have here. Enforced centrally so
      // a plugin added later cannot quietly keep working out there, and worded
      // with the one line the realm uses everywhere.
      if (ctx.player && isDreamlandsLocation(ctx.player.location) && TOWN_ONLY_COMMANDS.has(cmd)) {
        await ctx.reply(`🌫️ ${NO_SERVICES_LINE}`).catch(() => {})
        return
      }

      // ── The Dreamlands: the ice, the waking, and the long walk ───────────
      // Three player states that lock a command surface, all checked in one
      // block because they share the same shape: a small allowlist, a refusal
      // written in the realm's voice, and no way for a plugin to skip them.
      //
      //   frozen      — a body in the Ice Wastelands. .help/.status only.
      //   unconscious — carried home, not awake yet. .help/.status only.
      //   journeying  — mid-walk. Movement and combat are refused; the walk
      //                 owns the character until it ends.
      //
      // The timed auto-thaw is DISABLED (FROZEN_AUTO_THAW_HOURS = null, the
      // owner's ruling): the check stays and stays lazy, but as shipped it can
      // never fire — a body leaves the ice through the guardian wall and a
      // rescue, or through the owner's .take-to town, and nothing else.
      if (ctx.player && !sectSide && (isDreamlandsLocation(ctx.player.location) || ctx.player.dreamlandsIdle)) {
        let coldDeath = false
        const now = Date.now()
        await updatePlayer(ctx.db, ctx.from, async pl => {
          const tick = applyDreamlandsIdleTick(pl, now)
          if (tick.dead) {
            await handleDreamlandsDeath(pl, null, { cause: 'idle' })
            coldDeath = true
          } else if (getRegistry(ctx.platform).has(cmd)) {
            touchDreamlandsActivity(pl, now)
          }
          return pl
        })
        ctx.player = getPlayer(ctx.db, ctx.from)
        if (coldDeath) {
          await ctx.reply(immobileRefusal(ctx.player)).catch(() => {})
          return
        }
      }

      // A player in the Sect Empire is not held by the kingdom's ice or by a
      // walk they left behind: those locks belong to the Astral character, and
      // their state is left exactly as it is until they come back.
      if (ctx.player && !sectSide && !LOCKOUT_EXEMPT_COMMANDS.has(cmd)) {
        if (isFrozen(ctx.player) && autoThawDue(ctx.player)) {
          let thawLine = null
          await updatePlayer(ctx.db, ctx.from, pl => { thawLine = thawPlayer(pl, { automatic: true }); return pl })
          ctx.player = getPlayer(ctx.db, ctx.from)
          if (thawLine) await ctx.reply(thawLine).catch(() => {})
        }

        const lockedOut = isFrozen(ctx.player) || isUnconscious(ctx.player)
        if (lockedOut && !FROZEN_ALLOWED_COMMANDS.has(cmd)) {
          const screen = immobileRefusal(ctx.player)
          if (screen) {
            await ctx.reply(screen).catch(() => {})
            return
          }
        }

        if (!lockedOut && isJourneying(ctx.player) && !JOURNEY_ALLOWED_COMMANDS.has(cmd)) {
          // A stale walk (crash, restart, killed process) is cleared rather than
          // left to hold the character forever — see clearStaleJourney().
          let wasStale = false
          await updatePlayer(ctx.db, ctx.from, pl => { wasStale = clearStaleJourney(pl); return pl })
          if (wasStale) {
            ctx.player = getPlayer(ctx.db, ctx.from)
          } else {
            const line = journeyLockLine(ctx.player)
            if (line) {
              await ctx.reply(line).catch(() => {})
              return
            }
          }
        }
      }

      // ── The mountain road: the gatekeeper is still talking ───────────────
      // A player mid-conversation is still in the Astra Kingdom, they are just
      // not free to wander off. Everything but the answer commands is refused
      // here, before dispatch, exactly like a Dreamlands walk. Nothing about
      // their record has changed yet, and nothing will until the last answer.
      if (ctx.player && !sectSide && isOnRoad(ctx.player) && !ROAD_ALLOWED_COMMANDS.has(cmd)) {
        await ctx.reply(roadLockLine(ctx.player)).catch(() => {})
        return
      }

      // ── The Dreamlands: the cold has their character ──────────────────────
      // A character that cannot withstand the cold is stowed while its player
      // stands in the realm and restored the moment they are out (see
      // lib/dreamlands-characters.js). The narrated crossings belong to the
      // portal; this is the SILENT lazy repair that runs on every command so
      // no path — an admin tool, a future feature — can strand a stowed
      // character in town or a live one in the cold. The predicate is checked
      // on the in-memory record first, so the write only happens on the one
      // command that crosses the line.
      // Dreamstep's clock: banks active time spent in the realm (30 min unlocks it).
      if (ctx.player && !sectSide) {
        const probe = { ...ctx.player }
        if (tickRealmTime(probe, Date.now(), isDreamlandsLocation(ctx.player.location))) {
          await updatePlayer(ctx.db, ctx.from, pl => {
            tickRealmTime(pl, Date.now(), isDreamlandsLocation(pl.location))
            return pl
          }).catch(() => {})
          ctx.player = getPlayer(ctx.db, ctx.from)
        }
      }
      if (ctx.player && !sectSide && (needsCharacterStow(ctx.player) || needsCharacterUnstow(ctx.player))) {
        await updatePlayer(ctx.db, ctx.from, pl => { reconcileDreamlandsCharacter(pl); return pl }).catch(() => {})
        ctx.player = getPlayer(ctx.db, ctx.from)
      }


      // ── The World That Never Ends (the Inverted Dimension) ───────────────
      // One gate for the whole dimension (lib/inverted-gate.js): inside a run
      // only the white's own commands work and attack/skill/defend fight the
      // reflection; a locked player keeps status/help/offering/top-up; nothing
      // can be sent to a locked or in-run player; a duel with a double takes
      // attack/skill/defend when no other battle is running. Lockout-exempt
      // commands (appeals) always pass. Lazy timers run here too.
      if (ctx.player && !LOCKOUT_EXEMPT_COMMANDS.has(cmd)) {
        const canonical = getRegistry(ctx.platform).get(cmd)?.name ?? cmd
        if (await invertedGate(ctx, cmd, canonical)) return
      }

      // ── Inside a gate (Season 2's gate pillar) ────────────────────────────
      // A claimed gate is a fight, so the ordinary fight verbs belong to it
      // while the hunter is inside and NOT in another battle. Nothing else is
      // locked: a gate can be walked away from (.flee), it expires on its own
      // after GATES.idleMinutes, and it must never be the thing that stops a
      // player using the rest of the bot. lib/gate-actions.js owns the rule.
      if (ctx.player?.gateRun && !LOCKOUT_EXEMPT_COMMANDS.has(cmd)) {
        const canonical = getRegistry(ctx.platform).get(cmd)?.name ?? cmd
        if (await gateCommandGate(ctx, cmd, canonical)) return
      }

      // ── The Sect Empire: the world lock ──────────────────────────────────
      // While a player is in the Sect Empire, every command is refused unless
      // it is on lib/sect-lock.js's allowlist. Same shape as the gates around
      // it: one check here covers all ~200 plugins, including whatever gets
      // added next month, instead of a guard in each plugin that would have to
      // be remembered forever. The owner and mods pass through untouched.
      if (ctx.player && !LOCKOUT_EXEMPT_COMMANDS.has(cmd) && !isSectAccountCommand(cmd, sectPlugin)) {
        const plugin = getRegistry(ctx.platform).get(cmd)
        const canonical = plugin?.name ?? cmd
        // The fight first, then the cave, then the world: each gate answers in
        // the words of the state the player is actually in, and a command
        // refused by more than one of them is refused by the narrowest.
        if (await sectTribulationGate(ctx, cmd, canonical)) return
        if (await sectWayBackGate(ctx, cmd, canonical)) return
        if (await sectFightGate(ctx, cmd, canonical)) return
        if (await seclusionGate(ctx, cmd, canonical)) return
        // The plugin's category rides along so a command tagged `sect` by its
        // own source can never be refused by a forgotten allowlist entry.
        if (await sectGate(ctx, cmd, canonical, {
          known: !!plugin,
          category: plugin?.category ?? null,
        })) return
      }

      // ── In-battle command gate ───────────────────────────────────────────
      // Mid-battle, only real battle actions (+ a small utility allowlist,
      // shop included so potions can be bought) are permitted. Everything
      // else — mine, craft, travel, another .enter, etc. — gets rejected
      // with a reminder instead of running against stale/conflicting state.
      // LOCKOUT_EXEMPT_COMMANDS pass too: a player banned mid-dungeon still
      // needs a route to appeal it.
      // League & Qualifier fights have their own dedicated command gate in
      // dispatch() (lib/league/league-block.js) where dungeon context (.flee,
      // .shop) does not apply.
      //
      // Check both the raw token and the resolved plugin's canonical name so
      // an alias added to an allowed battle plugin never hits this gate, and
      // give typo suggestions for mistyped battle commands instead of claiming
      // the battle command is forbidden.
      if (ctx.player?.inBattle && !ctx.player?.battleState?.league && !LOCKOUT_EXEMPT_COMMANDS.has(cmd)) {
        const battlePlugin = getRegistry(ctx.platform).get(cmd)
        const battleCanonical = battlePlugin?.name ?? null
        const isBattleAllowed =
          BATTLE_ALLOWED_COMMANDS.has(cmd) ||
          (battleCanonical !== null && BATTLE_ALLOWED_COMMANDS.has(battleCanonical))
        if (!isBattleAllowed) {
          if (!battlePlugin) {
            const suggestion = suggestCommand(cmd, ctx.platform)
            const suggestedCanonical = suggestion ? (getRegistry(ctx.platform).get(suggestion)?.name ?? null) : null
            if (suggestion && (BATTLE_ALLOWED_COMMANDS.has(suggestion) || (suggestedCanonical !== null && BATTLE_ALLOWED_COMMANDS.has(suggestedCanonical)))) {
              await ctx.reply(
                `❓ Unknown command *${config.prefix}${cmd}*. Did you mean *${config.prefix}${suggestion}*?`,
              ).catch(() => {})
              return
            }
          }
          await ctx.reply(
            `⚔️ You're mid-battle! Only battle commands work right now:\n` +
            `*${config.prefix}attack* · *${config.prefix}skill <name>* · *${config.prefix}defend* · *${config.prefix}flee*\n` +
            `_(${config.prefix}shop and ${config.prefix}profile also work if you need to check something.)_`,
          ).catch(() => {})
          return
        }
      }

      // ── Boss-fight lockdown — shared (lib/platform/gates.js) ─────────────
      if (await bossFightGate(ctx, cmd)) return

      // ── Bag overflow after a premium lapse ───────────────────────────────
      // Losing premium drops the bag cap from 50 to 30, which can leave a bag
      // stranded above its own limit: every hasInventoryRoom() check then fails,
      // so looting, crafting and buying are all dead until they get back under
      // it. lib/inventory-limits.js resolves that on a clock, and this is the
      // half the player actually sees.
      //
      // NEVER a lockout — it warns and falls through, exactly like the hunger
      // warning above, so the very command that triggers the notice (`.shop
      // sell`, `.home store`) still runs. Utility commands skip it: `.song` has
      // nothing to do with your bag.
      //
      // The handler stamps and sheds too, rather than leaving it all to the
      // 15-minute sweep in main.js: it means the 48h clock starts the moment
      // they play instead of up to 15 minutes later, and the receipt lands in
      // chat immediately. The helpers are pure, so both callers run identical
      // logic; whichever gets there first wins and the other sees 'clear'.
      // The pre-check reads ctx.player, which is already in hand, so the common
      // case (a bag under the cap, which is nearly every player on nearly every
      // command) costs one length comparison and never touches the write queue.
      if (
        ctx.player && !sectSide && !isNonRpgCommand(cmd) && !LOCKOUT_EXEMPT_COMMANDS.has(cmd) &&
        !isPremiumActive(ctx.player) &&
        (ctx.player.inventoryShed || ctx.player.inventoryGrace || inventoryOverflow(ctx.player).over > 0)
      ) {
        let notice = null
        await updatePlayer(ctx.db, ctx.from, fresh => {
          // One shared state machine (lib/inventory-limits.js) so the wording,
          // the ordering and the throttle are identical wherever it runs: it
          // delivers a receipt the sweep parked, stamps the grace on first
          // sight, repeats the warning at most every 6h, and sheds once the
          // deadline has passed.
          notice = resolveOverflowNotice(fresh, {
            allItems,
            storageCap: storageCap(fresh),
            prefix: config.prefix,
            cooldownMs: OVERFLOW_WARN_COOLDOWN_MS,
          }).notice
          return fresh
        })
        ctx.player = getPlayer(ctx.db, ctx.from)
        if (notice) await ctx.reply(notice).catch(() => {})
      }

      // debug, not info: one line per command is pure noise at LOG_LEVEL=info
      // and it buries the errors you actually need to see. Set LOG_LEVEL=debug
      // to get the per-command trail back.
      logger.debug({ cmd, from, isGroup }, 'Command dispatched')
      incrementCommandCount()
      const handled = await dispatch(cmd, ctx)

      // ── Premium DM allowance consumption ────────────────────────────────
      // A Premium user who just ran a non-whitelisted command in DM burns
      // one of today's 50 slots. Whitelisted commands are in
      // DM_ALLOWED_COMMANDS (premium/topup/story/preorder/etc.) and are
      // always free — buying Premium or Story Mode must never eat the
      // buyer's own cap. Typos/unknown commands (handled=false) never
      // charge either, same as the pet payout logic below (no work done =
      // no slot spent). The consumption is its own write so that a pet
      // payout failure can never roll back the slot charge, and vice
      // versa: both happen on the same post-dispatch path.
      if (handled && !isGroup && !isOwnerJid(from) && !DM_ALLOWED_COMMANDS.has(cmd) && ctx.player) {
        await updatePlayer(ctx.db, ctx.playerId ?? from, fresh => {
          const res = consumePremiumDmSlot(fresh)
          if (res.consumed) {
            // Nudge the player when they have <=5 slots left, so running
            // out doesn't come as a silent surprise mid-session. Only
            // fires once per threshold (the check for <=5 AND >0 means
            // it triggers on the command that takes them to 5,4,3,2,1).
            const left = res.allowance.allowed
            if (left <= 5 && left > 0 && (fresh.premium?.dmLastNudge ?? -1) !== left) {
              fresh.premium.dmLastNudge = left
              // Can't await inside the mutator; flag it and send after.
              fresh.premium._dmNudgePending = left
            } else if (left > 5) {
              fresh.premium.dmLastNudge = -1
              fresh.premium._dmNudgePending = null
            }
          }
          return fresh
        }).catch(err => logger.warn({ err: err.message }, 'Premium DM slot consume failed'))

        // Send the nudge (if any) OUTSIDE the mutator so we can actually
        // reply. Read back the flag and clear it in a small follow-up.
        const pAfter = getPlayer(ctx.db, ctx.playerId ?? from)
        const nudgeAt = pAfter?.premium?._dmNudgePending
        if (typeof nudgeAt === 'number' && nudgeAt > 0) {
          await ctx.reply(
            nudgeAt === 1
              ? `👑 *1 DM command left today.* Use it wisely — your cap resets in *${formatTimeUntilReset(dmAllowanceForPlayer(pAfter).resetAt)}*. Whitelisted commands (${config.prefix}premium, ${config.prefix}topup, ${config.prefix}story, etc.) stay free after that.`
              : `👑 *${nudgeAt} DM commands left today.* Your cap resets in *${formatTimeUntilReset(dmAllowanceForPlayer(pAfter).resetAt)}*.`,
          ).catch(() => {})
          await updatePlayer(ctx.db, ctx.playerId ?? from, fresh => {
            if (fresh.premium) fresh.premium._dmNudgePending = null
            return fresh
          }).catch(() => {})
        }
      }

      // ── Pet per-command passive income ──────────────────────────────────
      // Pets with a `solarsPerCommand` rate (data/pets.json — Emberpaw) pay
      // out here, the one place every command funnels through. Runs only for
      // commands that actually matched a plugin, so a typo'd command doesn't
      // pay. Fractions accrue in player.petSolarDust and only whole Solars
      // reach the wallet — see awardPetCommandSolars() in lib/pet-bond.js.
      // Silent by design: a notification on every single command would be
      // unusable spam.
      if (handled && ctx.player && !sectSide) {
        await updatePlayer(ctx.db, ctx.from, fresh => {
          awardPetCommandSolars(fresh, petMap)
          // Boss turn clock: a turn-consuming action taken during a live boss
          // fight resets the 5-minute idle timer. Read-only status checks
          // (BOSS_TURN_TIMER_EXEMPT) do not, so a player can't stall their turn
          // indefinitely by spamming `.profile`. Piggybacks this one write that
          // every handled command already funnels through. The rule itself is
          // in lib/platform/gates.js so the Discord/Telegram pipeline resets
          // the same clock; it used to be written out here and nowhere else.
          refreshBossTurnClock(fresh, cmd)
        }).catch(err => logger.warn({ err: err.message }, 'Pet command payout failed'))
      }

      // ── Lineage dividends (both worlds) ─────────────────────────────────
      // A student's climb pays them and their teacher; the level up happened
      // somewhere else (a fight, a PvP win, the API, a guild war), so the debt
      // is settled here, on their next handled command, from a watermark on
      // their own record. Silent when nothing is due — it is a comparison of
      // two numbers and no write at all in the common case.
      if (handled && ctx.player) {
        const dividendLines = await settleLineageDividends(ctx).catch(err => {
          logger.warn({ err: err.message }, 'Lineage dividend settlement failed')
          return []
        })
        if (dividendLines?.length) await ctx.reply(dividendLines.join('\n')).catch(() => {})
      }

      if (!handled) {
        // debug, not info — a typo'd/unknown command is ordinary user
        // traffic, not something worth a line in production logs. Same
        // reasoning as 'Command dispatched' above.
        logger.debug({ cmd, from, isGroup }, 'No plugin matched command')
        const suggestion = suggestCommand(cmd, 'whatsapp')
        await ctx.reply(
          suggestion
            ? `❓ Unknown command *${config.prefix}${cmd}*. Did you mean *${config.prefix}${suggestion}*?`
            : `❓ Unknown command *${config.prefix}${cmd}*. Use *${config.prefix}menu* to see everything available.`,
        ).catch(() => {})
      }
    }
  }
}
