# ✨ Astral Bot — Mandatory AI Instructions

Before writing or editing **any** bot message, menu, caption, item blurb, or character description, read and strictly follow **[`AGENTS.md`](./AGENTS.md)**:

  ▸ **Minimal & concise** — short lines, zero filler paragraphs, mobile-scannable (~10–16 lines max for menus).
  ▸ **Properly spaced** — blank lines (`\n\n`) between every section and `  ▸ ` indented bullets.
  ▸ **Emojis & text effects** — fitting header/row emojis, `━━━━━━━━━━━━━━━━━━━━` dividers, `*bold*` for titles/commands/stats, `_italics_` for atmosphere/subtitles.
  ▸ **Books, not Volumes** — Story Mode entries are **Books** (`Book 1`, `<book>`), never `Volumes`.
  ▸ **Ask for art** — never use AI-generated placeholder images unless explicitly asked; ask the owner for the image first.
  ▸ **No dashes in `lib/version.js` notes** — never use `-`, `–`, or `—` in player-facing changelog `notes`.
