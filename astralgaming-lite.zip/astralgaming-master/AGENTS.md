# ✨ Astral Bot — Mandatory AI Writing & Copy Style Guide

> **STOP & READ BEFORE WRITING ANY BOT TEXT OR DESCRIPTION.**
> Every AI working in this repository MUST follow these rules whenever writing or editing command replies, menus, help cards, story guides, item blurbs, or character descriptions.

---

## 1. Keep Copy Minimal & Scannable

  ▸ **Short & punchy** — cut filler paragraphs, repeated explanations, and walls of text.
  ▸ **Mobile-first** — menus and info cards must read cleanly on a phone screen without scrolling (~10–16 short lines max).
  ▸ **One line, one job** — if two sentences say the same thing, delete one.

## 2. Space Properly

  ▸ Put a **blank line (`\n\n`)** between the header block, each section, and the footer.
  ▸ Indent bullet lists with two spaces and a clean marker (`  ▸ `).
  ▸ Never stack 4+ dense prose lines together in a command menu.

## 3. Use Emojis & Text Effects Intentionally

  ▸ **Section headers** — pair an evocative emoji with bold text (`📖 *STORY MODE*`, `📚 *Books*`, `✨ *Commands*`, `⏳ *Pace*`).
  ▸ **Dividers** — anchor top-level card headers with `━━━━━━━━━━━━━━━━━━━━`.
  ▸ **Effects** — use `*bold*` for titles, commands, and key numbers; `_italics_` for taglines, atmosphere, and subtle notes; `` `code` `` for literal IDs.
  ▸ **Status icons** — make state readable at a glance (`📖` open · `🔒` locked · `✅` owned/done · `💎` gems · `🪙` monds · `☀️` solars).

## 4. Template Example

```
📖 *STORY MODE*
━━━━━━━━━━━━━━━━━━━━
_Private interactive fiction in your DM — every choice shapes the story._

📚 *Books*
  📖 *Beyond the Astral* — _The Boy Who Glided the Skies_ _(Book 1)_
  🔒 *Gods Among Us* — _GODS AMONG US_ _(Book 2 · 50💎)_

✨ *How to Play*
  ▸ *.story enter <book>* — open a book
  ▸ *.story buy <book>* — unlock a paid book
  ▸ *.story start* — begin or resume reading
  ▸ Reply with numbers during choices & battles

⏳ *Pace*
  ▸ *1 chapter/day* _(3 for Premium)_ · progress auto-saves
  ▸ Story battles use story kits only — defeats trigger recovery & lower that chapter's 💎 bonus
```

## 5. Hard Repository Rules

  ▸ **Books, not Volumes** — in player-facing Story Mode copy and shelf art, always say **Books** (`Book 1`, `Books`, `<book>`), never `Volumes`.
  ▸ **Never auto-generate images** — never call AI image generation for covers, characters, or items without asking the owner first; ask the owner to supply the artwork.
  ▸ **Changelog hygiene** — player-facing `notes` in `lib/version.js` must contain **zero dashes** (`-`, `–`, `—`).
  ▸ **Private odds** — never print Starfall drop rates or dead-zone numbers in player-facing text.
